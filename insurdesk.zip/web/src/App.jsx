import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import RoleGuard from '@/components/RoleGuard';
import { FeatureProvider, useFeatures } from '@/lib/FeatureContext';
import FeatureLocked from '@/components/FeatureLocked';
import { PAGES as CRM_PAGES, PUBLIC_PAGES as CRM_PUBLIC, pageFeature } from '@/modules/registry';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import SystemDataImport from './pages/SystemDataImport';
import Messaging from './pages/Messaging';
import UserManual from './pages/UserManual';
import ClientPortalLogin from './pages/ClientPortalLogin';
import ClientPortal from './pages/ClientPortal';
import Incentives from './pages/Incentives';
import ClaimReport from './pages/ClaimReport';
import DataAudit from './pages/DataAudit';
import PolicyTags from './pages/PolicyTags';
import MFASetup from './pages/MFASetup';
import DuplicatePolicies from './pages/DuplicatePolicies';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

// Main "/" route — no role guard (always accessible, each role sees its own dashboard content)
const MainLayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

// All other routes — role check + plan (feature) check before Layout renders
const LayoutWrapper = ({ children, currentPageName }) => {
  const { loaded, has, featureOfPage } = useFeatures();
  const { user } = useAuth();
  if (!Layout) return <>{children}</>;
  const feature = featureOfPage(currentPageName) || pageFeature(currentPageName);
  const isCrmPage = !!CRM_PAGES[currentPageName];
  if (feature && !loaded) {
    return <div className="fixed inset-0 flex items-center justify-center"><div className="w-8 h-8 border-4 border-muted border-t-foreground rounded-full animate-spin"></div></div>;
  }
  return (
    <RoleGuard pageName={currentPageName}>
      <Layout currentPageName={currentPageName}>
        {feature && !has(feature) ? <FeatureLocked feature={feature} /> : (isCrmPage && !user?.crm_access_enabled ? <div className="p-10 text-center text-muted-foreground">No tienes acceso al CRM. Pide a un administrador que lo active en tu usuario.</div> : children)}
      </Layout>
    </RoleGuard>
  );
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings } = useAuth();

  // Client portal routes are public — no auth required
  const isClientPortalRoute = window.location.pathname.startsWith('/ClientPortal');

  // Show loading spinner while checking app public settings or auth
  if (!isClientPortalRoute && (isLoadingPublicSettings || isLoadingAuth)) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-border border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Public auth routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* Client Portal - public, own auth */}
      <Route path="/ClientPortalLogin" element={<ClientPortalLogin />} />
      <Route path="/ClientPortal" element={<ClientPortal />} />
      {CRM_PUBLIC.map(({ path, Component }) => <Route key={path} path={path} element={<Component />} />)}

      {/* All app routes gated by ProtectedRoute */}
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route path="/" element={
          <MainLayoutWrapper currentPageName={mainPageKey}>
            <MainPage />
          </MainLayoutWrapper>
        } />
        {Object.entries(Pages).map(([path, Page]) => (
          <Route
            key={path}
            path={`/${path}`}
            element={
              <LayoutWrapper currentPageName={path}>
                <Page />
              </LayoutWrapper>
            }
          />
        ))}
        <Route path="/SystemDataImport" element={<LayoutWrapper currentPageName="SystemDataImport"><SystemDataImport /></LayoutWrapper>} />
        <Route path="/Messaging" element={<LayoutWrapper currentPageName="Messaging"><Messaging /></LayoutWrapper>} />
        <Route path="/UserManual" element={<LayoutWrapper currentPageName="UserManual"><UserManual /></LayoutWrapper>} />
        <Route path="/Incentives" element={<LayoutWrapper currentPageName="Incentives"><Incentives /></LayoutWrapper>} />
        <Route path="/ClaimReport" element={<LayoutWrapper currentPageName="ClaimReport"><ClaimReport /></LayoutWrapper>} />
        <Route path="/DataAudit" element={<LayoutWrapper currentPageName="DataAudit"><DataAudit /></LayoutWrapper>} />
        <Route path="/PolicyTags" element={<LayoutWrapper currentPageName="PolicyTags"><PolicyTags /></LayoutWrapper>} />
        <Route path="/DuplicatePolicies" element={<LayoutWrapper currentPageName="DuplicatePolicies"><DuplicatePolicies /></LayoutWrapper>} />
        {Object.entries(CRM_PAGES).map(([name, { Component }]) => (
          <Route key={name} path={`/${name}`} element={<LayoutWrapper currentPageName={name}><Component /></LayoutWrapper>} />
        ))}
        <Route path="/MFASetup" element={<MFASetup />} />

        <Route path="*" element={<PageNotFound />} />
      </Route>
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <FeatureProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <NavigationTracker />
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </FeatureProvider>
    </AuthProvider>
  )
}

export default App