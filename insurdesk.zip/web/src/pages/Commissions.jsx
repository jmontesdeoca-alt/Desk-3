import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import StatCard from '@/components/ui/StatCard';
import PullToRefresh from '@/components/ui/PullToRefresh';
import { TrendingUp, Loader2, Filter, CheckCircle, Clock, DollarSign, Users, FileText, Download, Pencil, Eye, EyeOff, RotateCcw, BarChart3, AlertCircle } from 'lucide-react';
import { exportToCSV, exportToExcel } from '@/components/ui/exportUtils';
import { format } from 'date-fns';
import { formatDate } from '@/lib/dateUtils';
import { formatMoney, round2 } from '@/lib/formatMoney';

import CommissionSettlementModal from '@/components/CommissionSettlementModal';
import CommissionReportDialog from '@/components/CommissionReportDialog';
import PendingCommissionsReport from '@/components/commissions/PendingCommissionsReport';
import CommissionForm from '@/components/forms/CommissionForm';
import jsPDF from 'jspdf';
import { toast } from 'sonner';

export default function Commissions() {
  const [commissions, setCommissions] = useState([]);
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [agentFilter, setAgentFilter] = useState('all');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [branchFilter, setBranchFilter] = useState('all');
  const [companies, setCompanies] = useState([]);
  const [branches, setBranches] = useState([]);
  const [settlementModalOpen, setSettlementModalOpen] = useState(false);
  const [generatingPDF, setGeneratingPDF] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [selectedCommissions, setSelectedCommissions] = useState([]);
  const [settlements, setSettlements] = useState([]);
  const [showSettlements, setShowSettlements] = useState(false);
  const [editFormOpen, setEditFormOpen] = useState(false);
  const [editingCommission, setEditingCommission] = useState(null);
  const [saving, setSaving] = useState(false);
  const [hidePaid, setHidePaid] = useState(false);
  const [policies, setPolicies] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [settlementsPage, setSettlementsPage] = useState(0);
  const [settlementAgentFilter, setSettlementAgentFilter] = useState('all');
  const SETTLEMENTS_PER_PAGE = 20;
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [pendingCommissionsOpen, setPendingCommissionsOpen] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadData();
    }
  }, [currentUser]);

  const loadUser = async () => {
    try {
      const user = await api.auth.me();
      const userRoleResp = await api.functions.invoke('getUserRoleInfo', {});
      const enrichedUser = { ...user, app_role: userRoleResp?.data?.app_role, agent_id: userRoleResp?.data?.agent_id };
      setCurrentUser(enrichedUser);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const loadData = async () => {
    setLoading(true);
    const [commissionsData, agentsData, settlementsData, companiesData, policiesData, branchesData] = await Promise.all([
      api.entities.Commission.list('-generation_date', 1000),
      api.entities.Agent.list('name', 1000),
      api.entities.CommissionSettlement.list('-settlement_date', 1000),
      api.entities.InsuranceCompany.list('name', 1000),
      api.entities.Policy.list('-created_date', 10000),
      api.entities.Branch.list('name', 100)
    ]);
    
    // Filter commissions for agents/gerencial with agent linked - only their structure
    let filteredCommissions = commissionsData;
    if (currentUser && (currentUser.app_role === 'agente' || currentUser.app_role === 'gerencial') && currentUser.agent_id && currentUser.app_role !== 'financiero') {
      const allowedAgentIds = getAgentStructure(currentUser.agent_id, agentsData);
      filteredCommissions = commissionsData.filter(c => allowedAgentIds.includes(c.agent_id));
    }
    
    setCommissions(filteredCommissions);
    setAgents(agentsData);
    setSettlements(settlementsData);
    setCompanies(companiesData);
    setPolicies(policiesData);
    setBranches(branchesData);
    setLoading(false);
  };

  const getAgentStructure = (agentId, agentsList) => {
    const agents = agentsList || [];
    const structure = [agentId];
    
    const findDownline = (id) => {
      const downline = agents.filter(a => a.upline_agent_id === id);
      downline.forEach(agent => {
        structure.push(agent.id);
        findDownline(agent.id);
      });
    };
    
    findDownline(agentId);
    return structure;
  };

  const checkAndSendNotifications = async (commissionsData, agentsData) => {
    const pendingRelease = commissionsData.filter(c => c.status === 'pendiente_liberar');
    const pendingPayment = commissionsData.filter(c => c.status === 'pendiente_pagar');
    
    // Group by agent
    const agentGroups = {};
    [...pendingRelease, ...pendingPayment].forEach(c => {
      if (!agentGroups[c.agent_id]) {
        agentGroups[c.agent_id] = { pendingRelease: 0, pendingPayment: 0, agent: c };
      }
      if (c.status === 'pendiente_liberar') agentGroups[c.agent_id].pendingRelease++;
      if (c.status === 'pendiente_pagar') agentGroups[c.agent_id].pendingPayment++;
    });
    
    // Create notifications for agents with pending commissions
    for (const agentId in agentGroups) {
      const group = agentGroups[agentId];
      const agent = agentsData.find(a => a.id === agentId);
      
      if (group.pendingRelease > 0) {
        await api.entities.Notification.create({
          notification_type: 'comision_generada',
          recipient_type: 'agente',
          recipient_id: agentId,
          recipient_email: agent?.email || '',
          recipient_name: agent?.name || '',
          title: 'Comisiones Pendientes de Liberación',
          message: `Tienes ${group.pendingRelease} comisión(es) pendiente(s) de liberación por un total aproximado.`,
          notification_date: new Date().toISOString().split('T')[0],
          related_entity_type: 'Commission'
        });
      }
    }
  };

  const toggleCommissionSelection = (commissionId) => {
    setSelectedCommissions(prev => {
      // If unchecking, just remove it
      if (prev.includes(commissionId)) {
        return prev.filter(id => id !== commissionId);
      }
      
      // If checking and there are already selections, verify same agent
      if (prev.length > 0) {
        const firstSelectedComm = commissions.find(c => c.id === prev[0]);
        const newComm = commissions.find(c => c.id === commissionId);
        
        if (firstSelectedComm && newComm && firstSelectedComm.agent_id !== newComm.agent_id) {
          alert('No puedes seleccionar comisiones de diferentes agentes. Deselecciona las actuales primero.');
          return prev;
        }
      }
      
      return [...prev, commissionId];
    });
  };

  const openReleaseModal = () => {
    if (selectedCommissions.length === 0) {
      alert('Seleccione al menos una comisión para liberar');
      return;
    }
    
    // Check if any selected commission is from a company with direct payment
    const selectedComms = commissions.filter(c => selectedCommissions.includes(c.id));
    const hasDirectPayment = selectedComms.some(c => {
      const company = companies.find(comp => comp.id === c.company_id);
      return company?.direct_payment_to_agents === true;
    });
    
    if (hasDirectPayment) {
      alert('No se pueden incluir comisiones de compañías con pago directo a agentes en liquidaciones');
      return;
    }
    
    const firstComm = commissions.find(c => c.id === selectedCommissions[0]);
    if (!firstComm) {
      alert('Error: No se encontró la comisión seleccionada');
      return;
    }
    
    console.log('Buscando agente:', firstComm.agent_id);
    console.log('Agentes disponibles:', agents.length);
    let agent = agents.find(a => a.id === firstComm.agent_id);
    
    // Si no se encuentra el agente, usar los datos desnormalizados de la comisión
    if (!agent) {
      console.warn('Agente no encontrado en la base de datos, usando datos de la comisión');
      agent = {
        id: firstComm.agent_id,
        name: firstComm.agent_name || 'Agente Desconocido'
      };
    }
    
    // Validar que todas las comisiones seleccionadas sean del mismo agente
    const allSameAgent = commissions
      .filter(c => selectedCommissions.includes(c.id))
      .every(c => c.agent_id === firstComm.agent_id);
    
    if (!allSameAgent) {
      alert('Error: Todas las comisiones seleccionadas deben ser del mismo agente');
      setSelectedCommissions([]);
      return;
    }
    
    setSelectedAgent(agent);
    setSettlementModalOpen(true);
  };

  const handleEdit = (commission) => {
    setEditingCommission(commission);
    setEditFormOpen(true);
  };

  const handleEditSubmit = async (data) => {
    setSaving(true);
    try {
      await api.entities.Commission.update(editingCommission.id, data);
      setEditFormOpen(false);
      setEditingCommission(null);
      loadData();
    } catch (error) {
      alert('Error al actualizar comisión: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const markAsPaid = async (commission) => {
    await api.entities.Commission.update(commission.id, {
      status: 'pagada',
      payment_date: new Date().toISOString().split('T')[0]
    });
    loadData();
  };

  const markSelectedAsPaid = async () => {
    const pending = filteredCommissions.filter(c => c.status === 'pendiente_pagar');
    for (const c of pending) {
      await api.entities.Commission.update(c.id, {
        status: 'pagada',
        payment_date: new Date().toISOString().split('T')[0]
      });
    }
    loadData();
  };

  const openSettlementModal = (agent) => {
    setSelectedAgent(agent);
    setSettlementModalOpen(true);
  };

  const generateSettlementPDF = async (settlementData) => {
    setGeneratingPDF(true);
    try {
      console.log('🔄 Iniciando generación de liquidación...');
      
      // Get selected commissions to release
      const agentCommissions = commissions.filter(
        c => selectedCommissions.includes(c.id)
      );

      console.log(`✅ ${agentCommissions.length} comisiones seleccionadas`);

      if (agentCommissions.length === 0) {
        throw new Error('No hay comisiones seleccionadas');
      }

      // Get next settlement number
      const existingSettlements = await api.entities.CommissionSettlement.list('-created_date', 1000);
      const nextNumber = `LIQ-${String(existingSettlements.length + 1).padStart(6, '0')}`;
      console.log(`✅ Número de liquidación: ${nextNumber}`);

      // Load PDF settings from AppSettings
      const settings = {
        company_name: 'InsurDesk',
        company_address: '',
        company_phone: '',
        company_email: '',
        header_notes: '',
        footer_notes: ''
      };
      try {
        const allSettings = await api.entities.AppSettings.list('setting_key', 200);
        allSettings.forEach(s => {
          if (s.setting_key && s.setting_key.startsWith('commission_pdf_')) {
            const key = s.setting_key.replace('commission_pdf_', '');
            settings[key] = s.setting_value;
          }
        });
      } catch (error) {
        console.warn('⚠️ No se pudieron cargar settings de PDF, usando valores por defecto', error);
      }

      console.log('✅ Settings cargados');

      // Generate PDF
      const doc = new jsPDF({ orientation: 'landscape', format: 'a4' });
      
      // Logo (opcional, si falla continua sin logo)
      try {
        const logoImg = new Image();
        logoImg.src = '/logo-icon.png';
        await new Promise((resolve, reject) => {
          logoImg.onload = resolve;
          logoImg.onerror = reject;
          setTimeout(reject, 5000); // timeout después de 5 segundos
        });
        doc.addImage(logoImg, 'PNG', 15, 10, 20, 20);
        console.log('✅ Logo agregado');
      } catch (error) {
        console.warn('⚠️ No se pudo cargar el logo, continuando sin él');
      }

      // Header - Company info from settings
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('LIQUIDACIÓN DE COMISIONES', 45, 20);
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(settings.company_name || 'InsurDesk', 45, 26);
      doc.text(settings.company_address || '', 45, 30);
      
      doc.setFontSize(10);
      doc.text(`Agente: ${selectedAgent.name}`, 15, 38);
      doc.text(`Liquidación N°: ${nextNumber}`, 200, 20);
      doc.text(`Fecha: ${format(new Date(), 'dd/MM/yyyy')}`, 200, 26);
      
      if (settings.company_phone) doc.text(`Tel: ${settings.company_phone}`, 200, 32);
      if (settings.company_email) doc.text(`Email: ${settings.company_email}`, 200, 38);

      // Header notes from settings
      let yPos = 45;
      if (settings.header_notes) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        const headerLines = doc.splitTextToSize(settings.header_notes, 260);
        doc.text(headerLines, 15, yPos);
        yPos += (headerLines.length * 4) + 5;
      }

      // Manual table drawing
      const pageWidth = 297;
      const margins = { left: 15, right: 15 };
      const tableWidth = pageWidth - margins.left - margins.right;
      
      // Table headers
      const headers = ['Póliza', 'Asegurado', 'Vendedor', 'Aseguradora', 'Cuota', 'Prima Total', 'Prima Com.', '% Com.', 'Valor Com.'];
      const colWidths = [28, 38, 35, 35, 15, 28, 28, 18, 42];
      
      doc.setFillColor(30, 58, 138);
      doc.rect(margins.left, yPos, tableWidth, 8, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      
      let xPos = margins.left + 2;
      headers.forEach((header, i) => {
        doc.text(header, xPos, yPos + 5.5);
        xPos += colWidths[i];
      });
      
      yPos += 8;
      doc.setTextColor(0, 0, 0);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      
      // Table rows — multi-line: rows grow taller when text wraps
      const lineH = 3.3; // mm per text line at font size 8
      agentCommissions.forEach((c, idx) => {
        const policy = policies.find(p => p.id === c.policy_id);

        const rowData = [
          c.policy_number || 'N/A',
          c.client_name || 'N/A',
          policy?.agent_name || 'N/A',
          policy?.company_name || c.company_name || 'N/A',
          c.installment_number || '-',
          `${c.currency} ${(c.base_amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          `${c.currency} ${(c.base_amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          `${parseFloat(c.commission_pct || 0).toFixed(2)}%`,
          `${c.currency} ${(c.commission_amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
        ];

        // Wrap each cell to its column width
        const wrapped = rowData.map((cell, i) =>
          doc.splitTextToSize(String(cell), colWidths[i] - 2)
        );
        const maxLines = Math.max(...wrapped.map(w => w.length));
        const rowHeight = Math.max(7, maxLines * lineH + 3);

        // Page break: if row would overflow page, start new page and redraw header
        if (yPos + rowHeight > 195) {
          doc.addPage();
          yPos = 20;
          doc.setFillColor(30, 58, 138);
          doc.rect(margins.left, yPos, tableWidth, 8, 'F');
          doc.setTextColor(255, 255, 255);
          doc.setFontSize(9);
          doc.setFont('helvetica', 'bold');
          let hxPos = margins.left + 2;
          headers.forEach((header, i) => {
            doc.text(header, hxPos, yPos + 5.5);
            hxPos += colWidths[i];
          });
          yPos += 8;
          doc.setTextColor(0, 0, 0);
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
        }

        if (idx % 2 === 0) {
          doc.setFillColor(245, 245, 245);
          doc.rect(margins.left, yPos, tableWidth, rowHeight, 'F');
        }

        let xPos = margins.left + 2;
        wrapped.forEach((lines, i) => {
          lines.forEach((line, li) => {
            doc.text(line, xPos, yPos + 4 + li * lineH);
          });
          xPos += colWidths[i];
        });

        yPos += rowHeight;
      });

      const finalY = yPos + 10;

      // Totals section
      doc.setFontSize(10);
      const rightX = 240;
      let totalsY = finalY;
      
      doc.text('Total a comisionar:', rightX, totalsY, { align: 'right' });
      doc.text(`$${settlementData.total_commissionable.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, totalsY, { align: 'right' });
      
      totalsY += 6;
      doc.text('Gastos administrativos:', rightX, totalsY, { align: 'right' });
      doc.text(`-$${settlementData.administrative_expenses_amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, totalsY, { align: 'right' });
      
      totalsY += 6;
      doc.text('Descuentos:', rightX, totalsY, { align: 'right' });
      doc.text(`-$${settlementData.discounts.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, totalsY, { align: 'right' });
      
      if (settlementData.pending_negative_amount && settlementData.pending_negative_amount > 0) {
        totalsY += 6;
        doc.text('Negativos pendientes:', rightX, totalsY, { align: 'right' });
        doc.text(`-$${settlementData.pending_negative_amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, totalsY, { align: 'right' });
      }
      
      totalsY += 4;
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.line(200, totalsY, 280, totalsY);
      
      totalsY += 6;
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      const totalColor = settlementData.total_to_collect < 0 ? [220, 38, 38] : [0, 0, 0];
      doc.setTextColor(...totalColor);
      doc.text('TOTAL A COBRAR:', rightX, totalsY, { align: 'right' });
      doc.text(`$${settlementData.total_to_collect.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, totalsY, { align: 'right' });
      doc.setTextColor(0, 0, 0);
      
      if (settlementData.total_to_collect < 0) {
        totalsY += 6;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(220, 38, 38);
        doc.text('* Este saldo negativo se trasladará a la próxima liquidación', 200, totalsY, { align: 'right' });
        doc.setTextColor(0, 0, 0);
      }

      // Notes section - Settlement specific notes
      let notesY = totalsY + 10;
      if (settlementData.notes) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text('NOTAS DE LIQUIDACIÓN:', 15, notesY);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        const splitNotes = doc.splitTextToSize(settlementData.notes, 260);
        doc.text(splitNotes, 15, notesY + 7);
        notesY += (splitNotes.length * 4) + 15;
      }

      // Footer notes from settings
      if (settings.footer_notes) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.text('TÉRMINOS Y CONDICIONES:', 15, notesY);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(60, 60, 60);
        const footerLines = doc.splitTextToSize(settings.footer_notes, 260);
        doc.text(footerLines, 15, notesY + 5);
        doc.setTextColor(0, 0, 0);
      }

      // Save PDF
      console.log('🔄 Generando archivo PDF...');
      const pdfBlob = doc.output('blob');
      const pdfFile = new File([pdfBlob], `liquidacion_${nextNumber}.pdf`, { type: 'application/pdf' });
      
      console.log('🔄 Subiendo PDF al servidor...');
      const { file_url } = await api.integrations.Core.UploadFile({ file: pdfFile });
      console.log('✅ PDF subido:', file_url);

      // Save settlement record
      console.log('🔄 Guardando registro de liquidación...');
      const settlement = await api.entities.CommissionSettlement.create({
        settlement_number: nextNumber,
        agent_id: selectedAgent.id,
        agent_name: selectedAgent.name,
        settlement_date: new Date().toISOString().split('T')[0],
        commission_ids: agentCommissions.map(c => c.id),
        total_commissionable: settlementData.total_commissionable,
        administrative_expenses_pct: settlementData.administrative_expenses_pct,
        administrative_expenses_amount: settlementData.administrative_expenses_amount,
        discounts: settlementData.discounts,
        total_to_collect: settlementData.total_to_collect,
        notes: settlementData.notes || '',
        pdf_url: file_url,
        currency: agentCommissions[0]?.currency || 'USD'
      });
      console.log('✅ Registro de liquidación guardado');
      
      // Handle negative balance
      if (settlementData.total_to_collect < 0) {
        console.log('⚠️ Total negativo detectado, creando/actualizando registro de negativo');
        
        // If there was a pending negative, update it
        if (settlementData.pending_negative_id) {
          await api.entities.AgentNegativeBalance.update(
            settlementData.pending_negative_id,
            {
              negative_amount: settlementData.total_to_collect,
              origin_settlement_id: settlement.id,
              origin_settlement_number: nextNumber,
              status: 'pendiente'
            }
          );
        } else {
          // Create new negative balance
          await api.entities.AgentNegativeBalance.create({
            agent_id: selectedAgent.id,
            agent_name: selectedAgent.name,
            negative_amount: settlementData.total_to_collect,
            currency: agentCommissions[0]?.currency || 'USD',
            origin_settlement_id: settlement.id,
            origin_settlement_number: nextNumber,
            status: 'pendiente'
          });
        }
        console.log('✅ Registro de negativo actualizado');
      } else if (settlementData.pending_negative_id) {
        // Total is positive or zero, close the pending negative
        console.log('✅ Saldo positivo, cerrando negativo pendiente');
        await api.entities.AgentNegativeBalance.update(
          settlementData.pending_negative_id,
          { status: 'saldado' }
        );
      }

      // Download PDF
      doc.save(`liquidacion_${nextNumber}.pdf`);

      // SOLO DESPUÉS DE GENERAR PDF: Cambiar estado a pendiente_pagar
      console.log('🔄 Actualizando estado de comisiones...');
      for (const comm of agentCommissions) {
        await api.entities.Commission.update(comm.id, {
          status: 'pendiente_pagar',
          released_date: new Date().toISOString().split('T')[0]
        });
      }
      console.log('✅ Comisiones actualizadas a pendiente_pagar');

      toast.success(`Liquidación ${nextNumber} generada exitosamente`);
      setSelectedCommissions([]);
      setSettlementModalOpen(false);
      setGeneratingPDF(false);
      loadData();
    } catch (error) {
      console.error('❌ Error completo:', error);
      console.error('❌ Error mensaje:', error.message);
      console.error('❌ Error stack:', error.stack);
      setGeneratingPDF(false);
      toast.error(`Error al generar la liquidación: ${error.message}`);
    }
  };

  const executeReverseSettlement = async (settlement) => {
    try {
      const res = await api.functions.invoke('deleteSettlement', { settlement_id: settlement.id });
      if (res?.data?.success) {
        toast.success(`Liquidación ${settlement.settlement_number} revertida. ${res.data.commissions_released} comisiones liberadas.`);
        loadData();
      } else {
        toast.error(`Error: ${res?.data?.error || 'No se pudo revertir'}`);
      }
    } catch (error) {
      toast.error(`Error al reversar: ${error.message}`);
    }
  };

  const handleReverseSettlement = (settlement) => {
    toast.warning(
      `¿Confirmas reversar la liquidación ${settlement.settlement_number}? Las ${settlement.commission_ids?.length || 0} comisiones volverán a estar disponibles y se eliminará el balance negativo asociado.`,
      {
        duration: 10000,
        action: {
          label: 'Reversar',
          onClick: () => executeReverseSettlement(settlement)
        },
        cancel: {
          label: 'Cancelar',
          onClick: () => {}
        }
      }
    );
  };

  // Stats
  const totalPendingRelease = commissions.filter(c => c.status === 'pendiente_liberar').reduce((sum, c) => sum + (c.commission_amount || 0), 0);
  const totalPendingPayment = commissions.filter(c => c.status === 'pendiente_pagar').reduce((sum, c) => sum + (c.commission_amount || 0), 0);
  const totalPaid = commissions.filter(c => c.status === 'pagada').reduce((sum, c) => sum + (c.commission_amount || 0), 0);



  // Build a set of company IDs that belong to the selected branch (companies have branch_id directly)
  const companyIdsByBranch = branchFilter !== 'all'
    ? new Set(companies.filter(comp => comp.branch_id === branchFilter).map(comp => comp.id))
    : null;

  // Filters - working together (AND logic)
  const filteredCommissions = commissions.filter(c => {
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    if (agentFilter !== 'all' && c.agent_id !== agentFilter) return false;
    if (companyFilter !== 'all' && c.company_id !== companyFilter) return false;
    if (companyIdsByBranch && !companyIdsByBranch.has(c.company_id)) return false;
    if (hidePaid && c.status === 'pagada') return false;
    return true;
  });
  
  // Separate commissions: direct payment companies vs regular
  const commissionsForSettlement = filteredCommissions.filter(c => {
    const company = companies.find(comp => comp.id === c.company_id);
    return !company?.direct_payment_to_agents;
  });
  
  const directPaymentCommissions = filteredCommissions.filter(c => {
    const company = companies.find(comp => comp.id === c.company_id);
    return company?.direct_payment_to_agents === true;
  });

  const pendingReleaseCommissions = commissionsForSettlement.filter(c => c.status === 'pendiente_liberar');
  
  // Get current selected agent
  const selectedAgentId = selectedCommissions.length > 0 
    ? commissions.find(c => c.id === selectedCommissions[0])?.agent_id 
    : null;

  // Filter pending release commissions by selected agent if any
  const selectableCommissions = selectedAgentId 
    ? pendingReleaseCommissions.filter(c => c.agent_id === selectedAgentId)
    : pendingReleaseCommissions;

  const columns = [
    {
      header: (
        <input 
          type="checkbox" 
          onChange={(e) => {
            if (e.target.checked) {
              setSelectedCommissions(selectableCommissions.map(c => c.id));
            } else {
              setSelectedCommissions([]);
            }
          }}
          checked={selectableCommissions.length > 0 && selectableCommissions.every(c => selectedCommissions.includes(c.id))}
        />
      ),
      cell: (row) => {
        const isSelectable = row.status === 'pendiente_liberar' && 
          (!selectedAgentId || row.agent_id === selectedAgentId);
        
        return row.status === 'pendiente_liberar' && (
          <input 
            type="checkbox" 
            checked={selectedCommissions.includes(row.id)}
            onChange={() => toggleCommissionSelection(row.id)}
            disabled={!isSelectable}
            className={!isSelectable ? 'opacity-50 cursor-not-allowed' : ''}
          />
        );
      }
    },
    {
      header: 'Póliza',
      cell: (row) => (
        <Link to={createPageUrl(`PolicyDetail?id=${row.policy_id}`)} className="text-foreground hover:underline">
          {row.policy_number}
        </Link>
      )
    },
    { header: 'Cliente', accessorKey: 'client_name' },
    { header: 'Producto', accessorKey: 'product_name' },
    { header: 'Agente', accessorKey: 'agent_name' },
    { header: 'Nivel', cell: (row) => `Nivel ${row.level}` },
    { header: 'Cuota', cell: (row) => row.installment_number || '-' },
    {
      header: 'Base',
      cell: (row) => `${row.currency} ${formatMoney(row.base_amount)}`
    },
    { header: '%', cell: (row) => `${row.commission_pct}%` },
    {
      header: 'Comisión',
      cell: (row) => (
        <span className="font-medium">{row.currency} {formatMoney(row.commission_amount)}</span>
      )
    },
    {
      header: 'Liquidación',
      cell: (row) => {
        if (row.status === 'pagada' || row.status === 'pendiente_pagar') {
          const settlement = settlements.find(s => s.commission_ids?.includes(row.id));
          return settlement ? (
            <a 
              href={settlement.pdf_url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm text-foreground font-medium hover:underline cursor-pointer"
            >
              {settlement.settlement_number}
            </a>
          ) : (
            <span className="text-xs text-muted-foreground/70">-</span>
          );
        }
        return <span className="text-xs text-muted-foreground/70">-</span>;
      }
    },
    {
      header: 'Fecha',
      accessorKey: 'generation_date',
      cell: (row) => row.generation_date ? formatDate(row.generation_date, 'dd/MM/yyyy') : '-'
    },
    { header: 'Estado', cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: 'Acciones',
      cell: (row) => (
        <div className="flex gap-1">
          {row.status === 'pendiente_liberar' && (
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={() => handleEdit(row)}
              title="Editar"
            >
              <Pencil className="h-4 w-4" />
            </Button>
          )}
          {row.status === 'pendiente_pagar' && (
            <Button size="sm" variant="outline" onClick={() => markAsPaid(row)}>
              Pagar
            </Button>
          )}
        </div>
      )
    }
  ];

  const getExportData = () => ({
    headers: ['Póliza', 'Producto', 'Agente', 'Nivel', 'Base', '%', 'Comisión', 'Moneda', 'Fecha', 'Estado', 'Origen'],
    rows: filteredCommissions.map(c => [
      c.policy_number, c.product_name, c.agent_name, c.level,
      round2(c.base_amount), c.commission_pct, round2(c.commission_amount), c.currency,
      c.generation_date, c.status, c.source_type
    ]),
    filename: 'comisiones'
  });

  const handleExportCSV = () => exportToCSV(getExportData());
  const handleExportExcel = () => exportToExcel({ ...getExportData(), sheetName: 'Comisiones' });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="min-h-screen bg-background p-4 sm:p-6">
        <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Comisiones"
          subtitle="Gestión de comisiones por agente"
          icon={TrendingUp}
          backTo="Dashboard"
          actions={
            <Button
              onClick={() => setPendingCommissionsOpen(true)}
              variant="outline"
              className="gap-2 border-orange-500/30 text-orange-600 dark:text-orange-400 hover:bg-orange-500/10"
            >
              <AlertCircle className="h-4 w-4" />
              Comisiones Pendientes de Cobro
            </Button>
          }
        />

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title="Pendientes Liberar"
            value={`$${formatMoney(totalPendingRelease)}`}
            subtitle="Cliente pagó, broker no cobró"
            icon={Clock}
            iconBg="bg-orange-500/10"
            iconColor="text-orange-600 dark:text-orange-400"
          />
          <StatCard
            title="Pendientes Pagar"
            value={`$${formatMoney(totalPendingPayment)}`}
            subtitle="Listo para liquidar"
            icon={DollarSign}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-600 dark:text-amber-400"
          />
          <StatCard
            title="Pagadas"
            value={`$${formatMoney(totalPaid)}`}
            subtitle="Agente cobró"
            icon={CheckCircle}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-600 dark:text-emerald-400"
          />
          <StatCard
            title="Agentes con Comisiones"
            value={new Set(commissions.map(c => c.agent_id)).size}
            icon={Users}
            iconBg="bg-muted"
            iconColor="text-foreground"
          />
        </div>



        {/* Filters */}
        <Card className="border-0 shadow-sm p-3 sm:p-4 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground/70" />
                <span className="text-sm text-muted-foreground">Filtros:</span>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pendiente_liberar">Pendiente Liberar</SelectItem>
                  <SelectItem value="pendiente_pagar">Pendiente Pagar</SelectItem>
                  <SelectItem value="pagada">Pagada</SelectItem>
                </SelectContent>
              </Select>
              <Select value={agentFilter} onValueChange={setAgentFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Agente" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los agentes</SelectItem>
                  {agents
                    .filter(agent => commissions.some(c => c.agent_id === agent.id && c.status === 'pendiente_liberar'))
                    .map(agent => (
                      <SelectItem key={agent.id} value={agent.id}>{agent.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
              <Select value={companyFilter} onValueChange={setCompanyFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Compañía" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las compañías</SelectItem>
                  {companies.map(company => (
                    <SelectItem key={company.id} value={company.id}>{company.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={branchFilter} onValueChange={setBranchFilter}>
                <SelectTrigger className="w-44">
                  <SelectValue placeholder="Sede" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las sedes</SelectItem>
                  {branches.map(branch => (
                    <SelectItem key={branch.id} value={branch.id}>{branch.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {(statusFilter !== 'all' || agentFilter !== 'all' || companyFilter !== 'all' || branchFilter !== 'all') && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => { setStatusFilter('all'); setAgentFilter('all'); setCompanyFilter('all'); setBranchFilter('all'); }}
                >
                  Limpiar
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => setHidePaid(!hidePaid)} 
                variant="outline"
                className="gap-2"
              >
                {hidePaid ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                {hidePaid ? 'Mostrar Pagadas' : 'Ocultar Pagadas'}
              </Button>
              {selectedCommissions.length > 0 && (
                <Button 
                  onClick={openReleaseModal} 
                  className="gap-2"
                >
                  <FileText className="h-4 w-4" /> Generar Liquidación ({selectedCommissions.length})
                </Button>
              )}
              {filteredCommissions.filter(c => c.status === 'pendiente_pagar').length > 0 && (
                <Button 
                  onClick={markSelectedAsPaid}
                  className="gap-2 bg-emerald-600 hover:bg-emerald-700"
                >
                  <CheckCircle className="h-4 w-4" />
                  Pagar Todas Pendientes ({filteredCommissions.filter(c => c.status === 'pendiente_pagar').length})
                </Button>
              )}
              <Button 
                onClick={() => setShowSettlements(!showSettlements)} 
                variant="outline"
                className="gap-2"
              >
                {showSettlements ? 'Ver Comisiones' : 'Ver Liquidaciones Pagadas'}
              </Button>
            </div>
          </div>
        </Card>

        {!showSettlements ? (
          <>
            <Card className="border-0 shadow-sm p-6">
              <DataTable
                columns={columns}
                data={commissionsForSettlement}
                searchPlaceholder="Buscar por póliza, producto o agente..."
                exportable
                onExport={handleExportCSV}
                onExportExcel={handleExportExcel}
                emptyMessage="No hay comisiones para liquidación"
                sortable={true}
                defaultSortField="generation_date"
                defaultSortOrder="desc"
              />
            </Card>
            
            {directPaymentCommissions.length > 0 && (
              <Card className="border-0 shadow-sm p-6 mt-6">
                <div className="bg-emerald-500/10 dark:bg-emerald-900/20 border border-emerald-500/30 dark:border-emerald-800 rounded-lg p-4 mb-4">
                  <h3 className="font-semibold text-emerald-600 dark:text-emerald-400 dark:text-emerald-400 mb-1">
                    Comisiones de Compañías con Pago Directo
                  </h3>
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 dark:text-emerald-300">
                    Estas comisiones se calculan para rentabilidad pero no requieren liquidación ya que la compañía paga directamente a los agentes.
                  </p>
                </div>
                <DataTable
                  columns={columns.filter(col => col.header !== '')}
                  data={directPaymentCommissions}
                  searchPlaceholder="Buscar..."
                  emptyMessage="No hay comisiones de pago directo"
                  sortable={true}
                  defaultSortField="generation_date"
                  defaultSortOrder="desc"
                />
              </Card>
            )}
          </>
        ) : (
          <Card className="border-0 shadow-sm p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <h3 className="text-lg font-semibold">Histórico de Liquidaciones Pagadas</h3>
              <div className="flex items-center gap-3">
                <Button onClick={() => setReportDialogOpen(true)} variant="outline" className="gap-2">
                  <BarChart3 className="h-4 w-4" /> Reporte de Comisiones
                </Button>
                <Select value={settlementAgentFilter} onValueChange={(v) => { setSettlementAgentFilter(v); setSettlementsPage(0); }}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filtrar por agente" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los agentes</SelectItem>
                    {[...new Map(settlements.map(s => [s.agent_id, s])).values()].map(s => (
                      <SelectItem key={s.agent_id} value={s.agent_id}>{s.agent_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {(() => {
              const filtered = settlements.filter(s => settlementAgentFilter === 'all' || s.agent_id === settlementAgentFilter);
              const totalPages = Math.max(1, Math.ceil(filtered.length / SETTLEMENTS_PER_PAGE));
              const paged = filtered.slice(settlementsPage * SETTLEMENTS_PER_PAGE, (settlementsPage + 1) * SETTLEMENTS_PER_PAGE);
              return (
                <>
                  <div className="space-y-3">
                    {paged.map(settlement => (
                      <div key={settlement.id} className="border rounded-lg p-4 hover:bg-muted/40 ">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-foreground dark:text-white">{settlement.settlement_number}</p>
                            <p className="text-sm text-muted-foreground ">Agente: {settlement.agent_name}</p>
                            <p className="text-sm text-muted-foreground ">Fecha: {settlement.settlement_date ? formatDate(settlement.settlement_date, 'dd/MM/yyyy') : '-'}</p>
                            <p className="text-sm font-medium text-green-600 dark:text-green-400 dark:text-green-400 mt-1">Total: {settlement.currency} {formatMoney(settlement.total_to_collect)}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <a 
                              href={settlement.pdf_url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90"
                            >
                              <Download className="h-4 w-4" />
                              Descargar PDF
                            </a>
                            <button
                              onClick={() => handleReverseSettlement(settlement)}
                              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                              title="Reversar liquidación y liberar comisiones"
                            >
                              <RotateCcw className="h-4 w-4" />
                              Reversar
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">{settlement.commission_ids?.length || 0} comisiones incluidas</p>
                      </div>
                    ))}
                    {filtered.length === 0 && (
                      <p className="text-center text-muted-foreground/70 py-8">No hay liquidaciones pagadas</p>
                    )}
                  </div>
                  {filtered.length > SETTLEMENTS_PER_PAGE && (
                    <div className="flex items-center justify-between mt-4 pt-4 border-t">
                      <p className="text-sm text-muted-foreground">{filtered.length} liquidaciones • Página {settlementsPage + 1} de {totalPages}</p>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => setSettlementsPage(p => Math.max(0, p - 1))} disabled={settlementsPage === 0}>Anterior</Button>
                        <Button size="sm" variant="outline" onClick={() => setSettlementsPage(p => Math.min(totalPages - 1, p + 1))} disabled={settlementsPage >= totalPages - 1}>Siguiente</Button>
                      </div>
                    </div>
                  )}
                </>
              );
            })()}
          </Card>
        )}

        <CommissionSettlementModal
          open={settlementModalOpen}
          onOpenChange={setSettlementModalOpen}
          commissions={commissions.filter(c => selectedCommissions.includes(c.id))}
          agentId={selectedAgent?.id}
          onGenerate={generateSettlementPDF}
          isLoading={generatingPDF}
        />

        <CommissionForm
          open={editFormOpen}
          onOpenChange={setEditFormOpen}
          onSubmit={handleEditSubmit}
          initialData={editingCommission}
          isLoading={saving}
        />

        <CommissionReportDialog
          open={reportDialogOpen}
          onOpenChange={setReportDialogOpen}
        />

        <PendingCommissionsReport
          open={pendingCommissionsOpen}
          onOpenChange={setPendingCommissionsOpen}
        />
        </div>
      </div>
    </PullToRefresh>
  );
}