import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PageHeader from '@/components/ui/PageHeader';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle2, Clock, AlertTriangle, Settings, Calendar, Loader2 } from 'lucide-react';
import TaskDetailModal from '@/components/tasks/TaskDetailModal';
import TaskKanbanBoard from '@/components/tasks/TaskKanbanBoard';
import { isPast, parseISO } from 'date-fns';
import TaskCalendar from '../components/tasks/TaskCalendar';

export default function MyTasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    setLoading(true);
    try {
      const [userData, tasksData] = await Promise.all([
        api.auth.me(),
        api.entities.Task.list()
      ]);
      setCurrentUser(userData);
      setIsAdmin(userData.role === 'admin' || userData.app_role === 'admin' || userData.app_role === 'operaciones');
      const myTasks = tasksData.filter(t => t.assigned_to_user_id === userData.id);
      setTasks(myTasks);
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (taskId, newStatus) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    setUpdatingId(taskId);
    // Optimistic update
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
    try {
      const updateData = { status: newStatus };
      if (newStatus === 'finalizado') {
        updateData.completed_at = new Date().toISOString();
      }
      if (newStatus === 'en_proceso' && !task.started_at) {
        updateData.started_at = new Date().toISOString();
      }
      await api.entities.Task.update(taskId, updateData);
    } catch (error) {
      console.error('Error updating task status:', error);
      // Revert on error
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: task.status } : t));
      alert('Error al actualizar el estado de la tarea');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleComplete = async (task) => {
    await handleStatusChange(task.id, 'finalizado');
  };

  const pendingTasks = tasks.filter(t => t.status === 'pendiente');
  const inProgressTasks = tasks.filter(t => t.status === 'en_proceso');
  const finalizadoTasks = tasks.filter(t => t.status === 'finalizado' || t.status === 'completada');
  const overdueCount = pendingTasks.filter(t => t.due_date && isPast(parseISO(t.due_date))).length;

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Mis Tareas"
          subtitle="Gestiona tus tareas asignadas"
          backTo="Dashboard"
          actions={
            isAdmin && (
              <Link to={createPageUrl('TaskManagement')}>
                <Button variant="outline" className="gap-2">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline">Gestión de Tareas</span>
                </Button>
              </Link>
            )
          }
        />

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground ">Pendientes</p>
                <p className="text-2xl font-bold text-foreground dark:text-white">{pendingTasks.length}</p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground " />
            </div>
          </div>

          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground ">Vencidas</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400 dark:text-red-400">{overdueCount}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-400 dark:text-red-400" />
            </div>
          </div>

          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground ">Finalizadas</p>
                <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 dark:text-emerald-400">{finalizadoTasks.length}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-emerald-600 dark:text-emerald-400 dark:text-emerald-400" />
            </div>
          </div>
        </div>

        {updatingId && (
          <div className="flex items-center gap-2 text-sm text-foreground mb-3">
            <Loader2 className="h-4 w-4 animate-spin" />
            Actualizando estado...
          </div>
        )}

        <Tabs defaultValue="board" className="space-y-4">
          <TabsList>
            <TabsTrigger value="board">
              <Clock className="h-4 w-4 mr-2" />
              Tablero
            </TabsTrigger>
            <TabsTrigger value="calendar">
              <Calendar className="h-4 w-4 mr-2" />
              Calendario
            </TabsTrigger>
          </TabsList>

          <TabsContent value="board">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground/70" />
              </div>
            ) : tasks.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground/70">
                No tienes tareas asignadas
              </div>
            ) : (
              <TaskKanbanBoard
                tasks={tasks}
                onTaskClick={setSelectedTask}
                onStatusChange={handleStatusChange}
              />
            )}
          </TabsContent>

          <TabsContent value="calendar">
            <TaskCalendar tasks={tasks} onTaskClick={setSelectedTask} />
          </TabsContent>
        </Tabs>
      </div>

      <TaskDetailModal
        task={selectedTask}
        open={!!selectedTask}
        onClose={() => setSelectedTask(null)}
        onComplete={currentUser?.app_role !== 'agente' ? handleComplete : undefined}
        onTaskUpdated={(updated) => setTasks(prev => prev.map(t => t.id === updated.id ? { ...t, ...updated } : t))}
      />
    </div>
  );
}