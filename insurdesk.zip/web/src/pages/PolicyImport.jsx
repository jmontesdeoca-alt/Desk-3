import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import { Upload, Download, FileSpreadsheet, CheckCircle, XCircle, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';

// ─── Helpers ─────────────────────────────────────────────────────────────────
const gv = (row, ...keys) => {
  for (const k of keys) {
    if (row[k] !== undefined && row[k] !== null && String(row[k]).trim() !== '') return String(row[k]).trim();
  }
  return '';
};

const parseDate = (val) => {
  if (!val) return null;
  const s = String(val).trim();
  // Excel serial number
  if (/^\d{4,5}$/.test(s)) {
    const date = new Date((parseInt(s) - 25569) * 86400 * 1000);
    return date.toISOString().split('T')[0];
  }
  // DD/MM/YYYY
  const dmyMatch = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (dmyMatch) {
    const [, d, m, y] = dmyMatch;
    const year = y.length === 2 ? `20${y}` : y;
    return `${year}-${m.padStart(2,'0')}-${d.padStart(2,'0')}`;
  }
  // YYYY-MM-DD already
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.substring(0, 10);
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d.toISOString().split('T')[0];
};

const normalizeFrequency = (val) => {
  const map = {
    'mensual': 'mensual', 'monthly': 'mensual', 'mes': 'mensual', 'month': 'mensual', 'mes': 'mensual',
    'trimestral': 'trimestral', 'quarterly': 'trimestral', 'trimestre': 'trimestral',
    'semestral': 'semestral', 'semiannual': 'semestral', 'semestre': 'semestral',
    'anual': 'anual', 'annual': 'anual', 'yearly': 'anual', 'año': 'anual',
    'unico': 'unico', 'único': 'unico', 'single': 'unico', 'one time': 'unico',
  };
  return map[String(val || '').toLowerCase().trim()] || 'anual';
};

const normalizeStatus = (val) => {
  const map = {
    'activa': 'activa', 'activo': 'activa', 'active': 'activa', 'vigente': 'activa',
    'vencida': 'vencida', 'expired': 'vencida', 'vencido': 'vencida',
    'cancelada': 'cancelada', 'cancelled': 'cancelada', 'cancelado': 'cancelada',
    'renovada': 'renovada', 'renewed': 'renovada',
    'en_riesgo': 'en_riesgo', 'riesgo': 'en_riesgo',
  };
  return map[String(val || '').toLowerCase().trim()] || 'activa';
};

const normalizePolicyType = (val) => {
  const map = {
    'nuevo_negocio': 'nuevo_negocio', 'nuevo negocio': 'nuevo_negocio', 'new': 'nuevo_negocio', 'nuevo': 'nuevo_negocio',
    'renovacion': 'renovacion', 'renovación': 'renovacion', 'renewal': 'renovacion', 'renov': 'renovacion',
    'cambio_broker': 'cambio_broker', 'cambio broker': 'cambio_broker', 'broker': 'cambio_broker',
    'cesion_cartera': 'cesion_cartera', 'cesión': 'cesion_cartera', 'cesion': 'cesion_cartera',
    'otro': 'otro', 'other': 'otro',
  };
  return map[String(val || '').toLowerCase().trim()] || 'nuevo_negocio';
};

const normalizeDocType = (val) => {
  const map = {
    'cedula': 'cedula', 'cédula': 'cedula', 'ci': 'cedula', 'cc': 'cedula', 'dni': 'cedula',
    'pasaporte': 'pasaporte', 'passport': 'pasaporte',
    'nit': 'nit', 'ruc': 'ruc',
  };
  return map[String(val || '').toLowerCase().trim()] || 'cedula';
};

// ─── Fields definition ────────────────────────────────────────────────────────
// Columnas de la tabla de resultados: { key, label, render } -> el formato de DataTable
const toColumns = (cols) => cols.map(c => ({ accessorKey: c.key, header: c.label, cell: c.render ? (row) => c.render(row[c.key], row) : undefined }));

const systemFields = [
  { key: 'policy_number',         label: 'Número de Póliza *',       required: true },
  { key: 'agent_code',            label: 'Código / Nombre de Agente *', required: true },
  { key: 'company_ref',           label: 'ID o código de Compañía *', required: false, incremental: true },
  { key: 'line_ref',              label: 'ID o código de Ramo *',     required: false, incremental: true },
  { key: 'product_ref',           label: 'ID o código de Producto *', required: false, incremental: true },
  { key: 'agent_ref',             label: 'ID o código de Agente *',   required: false, incremental: true },
  { key: 'client_document_id',    label: 'Documento de Cliente *',   required: true },
  { key: 'client_first_name',     label: 'Nombres del Cliente',      required: false },
  { key: 'client_last_name',      label: 'Apellidos del Cliente',    required: false },
  { key: 'client_email',          label: 'Email de Cliente',         required: false },
  { key: 'client_phone',          label: 'Teléfono de Cliente',      required: false },
  { key: 'client_document_type',  label: 'Tipo Documento Cliente',   required: false },
  { key: 'product_name',          label: 'Nombre de Producto *',     required: true },
  { key: 'annual_premium',        label: 'Prima Anual *',            required: true },
  { key: 'commissionable_premium',label: 'Prima Comisionable *',     required: true },
  { key: 'currency',              label: 'Moneda',                   required: false },
  { key: 'payment_frequency',     label: 'Frecuencia de Pago *',     required: true },
  { key: 'installment_months',    label: 'Meses de Pago (mensual)',  required: false },
  { key: 'start_date',            label: 'Fecha Inicio *',           required: true },
  { key: 'end_date',              label: 'Fecha Fin *',              required: true },
  { key: 'issue_date',            label: 'Fecha de Emisión',         required: false },
  { key: 'status',                label: 'Estado',                   required: false },
  { key: 'policy_type',           label: 'Tipo de Póliza',           required: false },
  { key: 'policy_category',       label: 'Categoría (INDIVIDUAL/CORPORATIVA)', required: false },
  { key: 'country',               label: 'País',                     required: false },
  { key: 'insured_amount',        label: 'Monto Asegurado (Salud)',  required: false },
  { key: 'deductible_1',          label: 'Deducible 1',              required: false },
  { key: 'deductible_2',          label: 'Deducible 2',              required: false },
  { key: 'sum_insured',           label: 'Suma Asegurada (Vida)',    required: false },
  { key: 'notes',                 label: 'Notas',                    required: false },
];

export default function PolicyImport() {
  const [companies, setCompanies]     = useState([]);
  const [agents, setAgents]           = useState([]);
  const [products, setProducts]       = useState([]);
  const [clients, setClients]         = useState([]);
  const [selectedCompany, setSelectedCompany] = useState('');
  const [file, setFile]               = useState(null);
  const [parsedData, setParsedData]   = useState([]);
  const [excelColumns, setExcelColumns] = useState([]);
  const [columnMapping, setColumnMapping] = useState({});
  const [validationResults, setValidationResults] = useState([]);
  const [loading, setLoading]         = useState(false);
  const [importing, setImporting]     = useState(false);
  const [importResults, setImportResults] = useState(null);
  const [step, setStep]               = useState(1);
  const [createMissingClients, setCreateMissingClients] = useState(true);
  const [importMode, setImportMode] = useState('inicial');
  const [initialClosed, setInitialClosed] = useState(false);
  const [lines, setLines] = useState([]);
  const incremental = importMode === 'incremental';
  // Inicial: enlaza por nombre. Incremental: el archivo trae los IDs (o códigos únicos) y no se adivina nada por nombre.
  const activeFields = systemFields
    .filter(f => (incremental ? !['agent_code', 'product_name'].includes(f.key) : !f.incremental))
    .map(f => (incremental && f.incremental ? { ...f, required: true } : f));
  const canUpload = incremental || !!selectedCompany;
  useEffect(() => {
    api.entities.InsuranceLine.list().then(setLines).catch(() => {});
    api.entities.AppSettings.filter({ setting_key: 'initial_import_closed' })
      .then(r => { if (r[0]?.setting_value === 'true') { setInitialClosed(true); setImportMode('incremental'); } }).catch(() => {});
  }, []);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const [companiesData, agentsData, productsData, clientsData] = await Promise.all([
      api.entities.InsuranceCompany.filter({ status: 'activa' }),
      api.entities.Agent.list(),
      api.entities.Product.list(),
      api.entities.Client.list(),
    ]);
    setCompanies(companiesData);
    setAgents(agentsData);
    setProducts(productsData);
    setClients(clientsData);
    setLoading(false);
  };

  const downloadTemplate = () => {
    const template = [{
      NUMERO_POLIZA:        'POL-2024-001',
      CODIGO_AGENTE:        'JUAN PEREZ',
      DOCUMENTO_CLIENTE:    '12345678',
      TIPO_DOCUMENTO:       'cedula',
      NOMBRES_CLIENTE:      'CARLOS',
      APELLIDOS_CLIENTE:    'RODRIGUEZ',
      EMAIL_CLIENTE:        'carlos@email.com',
      TELEFONO_CLIENTE:     '555-1234',
      PRODUCTO:             'SEGURO VIDA BASICO',
      PRIMA_ANUAL:          1200,
      PRIMA_COMISIONABLE:   1000,
      MONEDA:               'USD',
      FRECUENCIA_PAGO:      'mensual',
      MESES_PAGO:           12,
      FECHA_INICIO:         '2024-01-01',
      FECHA_FIN:            '2024-12-31',
      FECHA_EMISION:        '2024-01-01',
      ESTADO:               'activa',
      TIPO_POLIZA:          'nuevo_negocio',
      CATEGORIA:            'INDIVIDUAL',
      PAIS:                 'PANAMA',
      MONTO_ASEGURADO:      '',
      DEDUCIBLE_1:          '',
      DEDUCIBLE_2:          '',
      SUMA_ASEGURADA:       100000,
      NOTAS:                'MIGRACIÓN DE SISTEMA ANTERIOR',
    }];

    const instructions = [
      { Campo: 'NUMERO_POLIZA',      Obligatorio: 'Sí', Formato: 'Texto', Descripción: 'Número único de póliza' },
      { Campo: 'CODIGO_AGENTE',      Obligatorio: 'Sí', Formato: 'Texto', Descripción: 'Nombre o alias del agente (debe existir en el sistema)' },
      { Campo: 'DOCUMENTO_CLIENTE',  Obligatorio: 'Sí', Formato: 'Texto', Descripción: 'Número de documento del cliente' },
      { Campo: 'TIPO_DOCUMENTO',     Obligatorio: 'No', Formato: 'cedula/pasaporte/nit/ruc/otro', Descripción: 'Tipo de documento (default: cedula)' },
      { Campo: 'NOMBRES_CLIENTE',    Obligatorio: 'No*', Formato: 'Texto', Descripción: 'Nombres (requerido si cliente no existe)' },
      { Campo: 'APELLIDOS_CLIENTE',  Obligatorio: 'No', Formato: 'Texto', Descripción: 'Apellidos del cliente' },
      { Campo: 'EMAIL_CLIENTE',      Obligatorio: 'No', Formato: 'email@ejemplo.com', Descripción: 'Email del cliente' },
      { Campo: 'TELEFONO_CLIENTE',   Obligatorio: 'No', Formato: 'Texto', Descripción: 'Teléfono del cliente' },
      { Campo: 'PRODUCTO',           Obligatorio: 'Sí', Formato: 'Texto', Descripción: 'Nombre exacto del producto (debe existir en la compañía seleccionada)' },
      { Campo: 'PRIMA_ANUAL',        Obligatorio: 'Sí', Formato: 'Número', Descripción: 'Prima anual total' },
      { Campo: 'PRIMA_COMISIONABLE', Obligatorio: 'Sí', Formato: 'Número', Descripción: 'Prima base para cálculo de comisiones' },
      { Campo: 'MONEDA',             Obligatorio: 'No', Formato: 'USD/COP/MXN/EUR/PEN/CLP/ARS', Descripción: 'Moneda (default: USD)' },
      { Campo: 'FRECUENCIA_PAGO',    Obligatorio: 'Sí', Formato: 'mensual/trimestral/semestral/anual/unico', Descripción: 'Frecuencia de pago' },
      { Campo: 'MESES_PAGO',         Obligatorio: 'No', Formato: 'Número 1-12', Descripción: 'Solo para frecuencia mensual (default: 12)' },
      { Campo: 'FECHA_INICIO',       Obligatorio: 'Sí', Formato: 'YYYY-MM-DD o DD/MM/YYYY', Descripción: 'Fecha inicio de vigencia' },
      { Campo: 'FECHA_FIN',          Obligatorio: 'Sí', Formato: 'YYYY-MM-DD o DD/MM/YYYY', Descripción: 'Fecha fin de vigencia' },
      { Campo: 'FECHA_EMISION',      Obligatorio: 'No', Formato: 'YYYY-MM-DD o DD/MM/YYYY', Descripción: 'Fecha de emisión original (si no se indica, usa fecha inicio)' },
      { Campo: 'ESTADO',             Obligatorio: 'No', Formato: 'activa/vencida/cancelada/renovada/en_riesgo', Descripción: 'Estado de la póliza (default: activa)' },
      { Campo: 'TIPO_POLIZA',        Obligatorio: 'No', Formato: 'nuevo_negocio/renovacion/cambio_broker/cesion_cartera/otro', Descripción: 'Tipo (default: nuevo_negocio)' },
      { Campo: 'CATEGORIA',          Obligatorio: 'No', Formato: 'INDIVIDUAL/CORPORATIVA', Descripción: 'Categoría de póliza (default: INDIVIDUAL)' },
      { Campo: 'PAIS',               Obligatorio: 'No', Formato: 'Texto', Descripción: 'País' },
      { Campo: 'MONTO_ASEGURADO',    Obligatorio: 'No', Formato: 'Número', Descripción: 'Para ramo Salud' },
      { Campo: 'DEDUCIBLE_1',        Obligatorio: 'No', Formato: 'Número', Descripción: 'Para ramo Salud (dentro del país)' },
      { Campo: 'DEDUCIBLE_2',        Obligatorio: 'No', Formato: 'Número', Descripción: 'Para ramo Salud (fuera del país)' },
      { Campo: 'SUMA_ASEGURADA',     Obligatorio: 'No', Formato: 'Número', Descripción: 'Para ramo Vida' },
      { Campo: 'NOTAS',              Obligatorio: 'No', Formato: 'Texto', Descripción: 'Notas adicionales' },
    ];

    const ws   = XLSX.utils.json_to_sheet(template);
    ws['!cols'] = Object.keys(template[0]).map(() => ({ wch: 22 }));
    const wb   = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Plantilla');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(instructions), 'Instrucciones');
    XLSX.writeFile(wb, 'plantilla_importacion_polizas.xlsx');
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;
    if (!incremental && !selectedCompany) { toast.error('Primero selecciona una compañía aseguradora'); return; }

    setFile(selectedFile);
    const reader = new FileReader();
    reader.onload = (event) => {
      const workbook = XLSX.read(new Uint8Array(event.target.result), { type: 'array' });
      const json = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
      if (json.length === 0) { toast.error('El archivo no contiene datos'); return; }
      const columns = Object.keys(json[0]);
      setExcelColumns(columns);
      setParsedData(json);
      autoMapColumns(columns);
      setStep(2);
    };
    reader.readAsArrayBuffer(selectedFile);
  };

  const autoMapColumns = (columns) => {
    const mapping = {};
    const hints = {
      policy_number:          ['numero_poliza','npoliza','policy','poliza','numero'],
      agent_code:             ['codigo_agente','agente','agent','agent_code','codeagent'],
      client_document_id:     ['documento_cliente','documento','document','cedula','nit','ruc','doc'],
      client_first_name:      ['nombres_cliente','nombres','first_name','nombre','firstname'],
      client_last_name:       ['apellidos_cliente','apellidos','last_name','lastname','apellido'],
      client_email:           ['email_cliente','email','correo'],
      client_phone:           ['telefono_cliente','telefono','phone','tel'],
      client_document_type:   ['tipo_documento','tipodoc','doctype'],
      product_name:           ['producto','product','product_name','plan'],
      company_ref:            ['company_id','id_compania','id_compañia','codigo_compania','company_code'],
      line_ref:               ['line_id','id_ramo','codigo_ramo','line_code'],
      product_ref:            ['product_id','id_producto','codigo_producto','product_code'],
      agent_ref:              ['agent_id','id_agente','codigo_agente','agent_ref'],
      annual_premium:         ['prima_anual','prima','premium','annual'],
      commissionable_premium: ['prima_comisionable','comisionable','commissionable'],
      currency:               ['moneda','currency','divisa'],
      payment_frequency:      ['frecuencia_pago','frecuencia','frequency','frec'],
      installment_months:     ['meses_pago','meses','months','installments'],
      start_date:             ['fecha_inicio','inicio','start','vigencia_desde','fechainicio'],
      end_date:               ['fecha_fin','fin','end','vigencia_hasta','fechafin'],
      issue_date:             ['fecha_emision','emision','issue','fechaemision'],
      status:                 ['estado','status','estatus'],
      policy_type:            ['tipo_poliza','tipo','type','tipopoliza'],
      policy_category:        ['categoria','category','cat'],
      country:                ['pais','country','país'],
      insured_amount:         ['monto_asegurado','asegurado','insured'],
      deductible_1:           ['deducible_1','ded1','deducible1'],
      deductible_2:           ['deducible_2','ded2','deducible2'],
      sum_insured:            ['suma_asegurada','suma','sum_insured'],
      notes:                  ['notas','notes','observaciones'],
    };
    activeFields.forEach(field => {
      const fieldHints = hints[field.key] || [];
      const matched = columns.find(col => {
        const norm = col.toLowerCase().replace(/[\s_\-]/g, '');
        return fieldHints.some(h => norm.includes(h.replace(/[_]/g,'')) || h.replace(/[_]/g,'').includes(norm));
      });
      if (matched) mapping[field.key] = matched;
    });
    setColumnMapping(mapping);
  };

  const getMV = (row, fieldKey) => {
    const col = columnMapping[fieldKey];
    return col ? gv(row, col) : '';
  };

  const validateData = () => {
    const missing = activeFields.filter(f => f.required && !columnMapping[f.key]);
    if (missing.length > 0) {
      toast.error(`Campos requeridos sin mapear: ${missing.map(f => f.label).join(', ')}`);
      return;
    }
    const company = companies.find(c => c.id === selectedCompany);
    const results = parsedData.map((row, index) => {
      const errors = [];
      const warnings = [];

      const policyNumber  = getMV(row, 'policy_number');
      const agentCode     = getMV(row, 'agent_code');
      const clientDocId   = getMV(row, 'client_document_id');
      const clientFirstName = getMV(row, 'client_first_name');
      const clientEmail   = getMV(row, 'client_email');
      const productName   = getMV(row, 'product_name');
      const startDateRaw  = getMV(row, 'start_date');
      const endDateRaw    = getMV(row, 'end_date');
      const frequency     = getMV(row, 'payment_frequency');
      const annualPremium = getMV(row, 'annual_premium');
      const commPremium   = getMV(row, 'commissionable_premium');

      if (!policyNumber)  errors.push('Falta número de póliza');
      if (!incremental && !agentCode) errors.push('Falta agente');
      if (!clientDocId)   errors.push('Falta documento de cliente');
      if (!incremental && !productName) errors.push('Falta nombre de producto');
      if (!annualPremium) errors.push('Falta prima anual');
      if (!commPremium)   errors.push('Falta prima comisionable');
      if (!frequency)     errors.push('Falta frecuencia de pago');
      if (!startDateRaw)  errors.push('Falta fecha de inicio');
      if (!endDateRaw)    errors.push('Falta fecha de fin');

      // Validate dates
      const startDate = parseDate(startDateRaw);
      const endDate   = parseDate(endDateRaw);
      if (startDateRaw && !startDate) errors.push('Fecha de inicio inválida');
      if (endDateRaw   && !endDate)   errors.push('Fecha de fin inválida');

      // Agente: incremental = solo por ID o código único; inicial = por nombre, alias o email
      const refMatch = (list, v) => { const x = String(v ?? '').trim().toLowerCase(); return x ? list.find(i => i.id === String(v).trim() || (i.code && i.code.toLowerCase() === x)) : undefined; };
      const agentRef = incremental ? String(getMV(row, 'agent_ref') ?? '').trim() : '';
      const agent = incremental
        ? refMatch(agents, agentRef)
        : agents.find(a => a.name?.toLowerCase() === agentCode?.toLowerCase() || a.alias?.toLowerCase() === agentCode?.toLowerCase() || a.email?.toLowerCase() === agentCode?.toLowerCase());
      if (incremental && !agentRef) errors.push('Falta el ID o código del agente');
      else if (!agent && (incremental ? agentRef : agentCode)) errors.push(`Agente "${incremental ? agentRef : agentCode}" no encontrado${incremental ? ' (en modo incremental se exige el ID o el código, no el nombre)' : ''}`);

      // Find client
      const client = clients.find(c => c.document_id === clientDocId);
      if (!client && clientDocId) {
        if (createMissingClients) {
          if (!clientFirstName && !clientEmail) {
            errors.push('Cliente no existe: falta nombre o email para crearlo');
          } else {
            warnings.push('Cliente nuevo se creará al importar');
          }
        } else {
          errors.push('Cliente no encontrado en el sistema');
        }
      }

      // Producto, compañía y ramo: incremental = IDs del archivo (se valida que sean coherentes entre sí)
      const productRef = incremental ? String(getMV(row, 'product_ref') ?? '').trim() : '';
      const companyRef = incremental ? String(getMV(row, 'company_ref') ?? '').trim() : '';
      const lineRef = incremental ? String(getMV(row, 'line_ref') ?? '').trim() : '';
      const rowCompanyInc = incremental ? refMatch(companies, companyRef) : undefined;
      const rowLineInc = incremental ? refMatch(lines, lineRef) : undefined;
      const product = incremental
        ? refMatch(products, productRef)
        : products.find(p => p.product_name?.toLowerCase() === productName?.toLowerCase() && p.company_id === selectedCompany);
      if (incremental) {
        if (!rowCompanyInc) errors.push(companyRef ? `Compañía "${companyRef}" no encontrada` : 'Falta el ID o código de la compañía');
        if (!rowLineInc) errors.push(lineRef ? `Ramo "${lineRef}" no encontrado` : 'Falta el ID o código del ramo');
        if (!product) errors.push(productRef ? `Producto "${productRef}" no encontrado` : 'Falta el ID o código del producto');
        if (product && rowCompanyInc && product.company_id !== rowCompanyInc.id) errors.push('El producto no pertenece a la compañía indicada');
        if (product && rowLineInc && product.line_id !== rowLineInc.id) errors.push('El producto no pertenece al ramo indicado');
      } else if (!product && productName) errors.push(`Producto "${productName}" no encontrado en ${company?.name}`);

      return {
        row: index + 1,
        policyNumber,
        clientDoc:  clientDocId,
        clientName: client ? `${client.first_name || ''} ${client.last_name || ''}`.trim() || client.company_name : clientFirstName,
        agentCode,
        agentName:  agent?.name || agentCode,
        product:    product?.product_name || productName,
        startDate,
        endDate,
        status:     errors.length > 0 ? 'error' : warnings.length > 0 ? 'warning' : 'ok',
        errors:     errors.join(' | '),
        warnings:   warnings.join(' | '),
        data:       row,
        clientId:   client?.id,
        agentId:    agent?.id,
        productId:  product?.id,
        companyId:  incremental ? rowCompanyInc?.id : selectedCompany,
        needsClientCreation: !client && createMissingClients && clientDocId,
      };
    });

    setValidationResults(results);
    setStep(3);
  };

  const handleImport = async () => {
    const validRows = validationResults.filter(r => r.status === 'ok' || r.status === 'warning');
    if (validRows.length === 0) { toast.error('No hay registros válidos para importar'); return; }
    if (!confirm(`¿Importar ${validRows.length} pólizas?\n${createMissingClients ? 'Se crearán clientes nuevos automáticamente.\n' : ''}NOTA: No se generarán comisiones automáticas.`)) return;

    setImporting(true);
    const company = companies.find(c => c.id === selectedCompany);
    const results = { success: 0, failed: 0, errors: [], clientsCreated: 0, duplicates: 0, duplicateList: [] };
    // Cache of clients created during this import run to prevent duplicates (docId -> { id, name })
    const createdClientsCache = {};

    for (const validation of validRows) {
      try {
        const mv = (fieldKey) => getMV(validation.data, fieldKey);
        const rowCompany = companies.find(c => c.id === (validation.companyId || selectedCompany)) || company;

        // ── 1. Create client if needed ───────────────────────────────────────
        let clientId   = validation.clientId;
        let clientName = validation.clientName;

        if (validation.needsClientCreation) {
          const docId = mv('client_document_id');
          // If we already created this client in a previous row of this import, reuse it
          if (createdClientsCache[docId]) {
            clientId   = createdClientsCache[docId].id;
            clientName = createdClientsCache[docId].name;
          } else {
            const firstName   = mv('client_first_name') || 'PENDIENTE';
            const lastName    = mv('client_last_name') || '';
            const email       = mv('client_email') || `${docId.replace(/\s/g,'')}@importado.com`;
            const phone       = mv('client_phone');
            const docType     = normalizeDocType(mv('client_document_type'));
            const country     = mv('country') || rowCompany?.country || 'PANAMA';

            const newClient = await api.entities.Client.create({
              client_type:   'persona',
              document_type: docType,
              document_id:   docId,
              first_name:    firstName.toUpperCase(),
              last_name:     lastName.toUpperCase(),
              email:         email.toLowerCase(),
              phone:         phone || null,
              country,
              status:        'activo',
              notes:         'Creado automáticamente durante importación de pólizas',
            });

            clientId   = newClient.id;
            clientName = `${firstName} ${lastName}`.trim();
            createdClientsCache[docId] = { id: clientId, name: clientName };
            results.clientsCreated++;
          }
        }

        // ── 2. Resolve product & branch ──────────────────────────────────────
        const product   = products.find(p => p.id === validation.productId);
        const frequency = normalizeFrequency(mv('payment_frequency'));
        const annualPremium = parseFloat(mv('annual_premium')) || 0;
        const commPremium   = parseFloat(mv('commissionable_premium')) || 0;

        const freqDivisor = frequency === 'mensual' ? 12 :
                            frequency === 'trimestral' ? 4 :
                            frequency === 'semestral' ? 2 : 1;
        const installmentAmount = annualPremium / freqDivisor;
        const installmentMonths = frequency === 'mensual'
          ? parseInt(mv('installment_months') || '12') || 12
          : null;

        const startDate  = validation.startDate  || parseDate(mv('start_date'));
        const endDate    = validation.endDate    || parseDate(mv('end_date'));
        const issueDate  = parseDate(mv('issue_date')) || startDate;

        const currencyRaw = mv('currency');
        const validCurrencies = ['USD','COP','MXN','EUR','PEN','CLP','ARS'];
        const currency = validCurrencies.includes(currencyRaw?.toUpperCase()) ? currencyRaw.toUpperCase() : 'USD';

        const category = mv('policy_category')?.toUpperCase() === 'CORPORATIVA' ? 'CORPORATIVA' : 'INDIVIDUAL';

        // ── 3. Create policy ─────────────────────────────────────────────────
        const policyData = {
          policy_number:          mv('policy_number'),
          policy_category:        category,
          issue_date:             issueDate,
          client_id:              clientId,
          client_name:            clientName,
          product_id:             validation.productId,
          product_name:           product?.product_name || mv('product_name'),
          company_id:             rowCompany.id,
          company_name:           rowCompany.name,
          line_id:                product?.line_id  || '',
          line_name:              product?.line_name || '',
          branch_id:              rowCompany.branch_id  || '',
          branch_name:            rowCompany.branch_name || '',
          agent_id:               validation.agentId,
          agent_name:             validation.agentName,
          currency,
          annual_premium:         annualPremium,
          commissionable_premium: commPremium,
          payment_frequency:      frequency,
          installment_amount:     installmentAmount,
          ...(installmentMonths ? { installment_months: installmentMonths } : {}),
          start_date:             startDate,
          end_date:               endDate,
          status:                 normalizeStatus(mv('status')),
          policy_type:            normalizePolicyType(mv('policy_type')),
          country:                mv('country') || rowCompany?.country || 'PANAMA',
          insured_amount:         mv('insured_amount')  ? parseFloat(mv('insured_amount'))  : null,
          deductible_1:           mv('deductible_1')    ? parseFloat(mv('deductible_1'))    : null,
          deductible_2:           mv('deductible_2')    ? parseFloat(mv('deductible_2'))    : null,
          sum_insured:            mv('sum_insured')     ? parseFloat(mv('sum_insured'))     : null,
          notes:                  mv('notes') || 'Importado desde archivo Excel',
        };

        const createResp = await api.functions.invoke('createPolicy', { policyData });
        if (createResp?.data?.success) {
          results.success++;
        } else if (createResp?.data?.duplicate) {
          results.duplicates++;
          results.duplicateList.push(`Póliza ${validation.policyNumber}: duplicada (existe para ${createResp.data.existing.company_name})`);
        } else {
          throw new Error(createResp?.data?.error || 'Error al crear póliza');
        }
      } catch (error) {
        results.failed++;
        results.errors.push(`Póliza ${validation.policyNumber}: ${error.message}`);
      }
    }

    setImporting(false);
    setImportResults(results);
    setStep(4);
  };

  const resetImport = () => {
    setFile(null); setParsedData([]); setExcelColumns([]);
    setColumnMapping({}); setValidationResults([]); setImportResults(null); setStep(1);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <PageHeader
          title="Importación de Pólizas"
          subtitle="Migración masiva de pólizas sin generación de comisiones"
          backTo="AdminPanel"
          icon={FileSpreadsheet}
        />

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-8 gap-2">
          {['Preparación', 'Mapeo', 'Validación', 'Resultados'].map((label, i) => {
            const s = i + 1;
            return (
              <React.Fragment key={s}>
                <div className="flex flex-col items-center gap-1">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full font-bold text-sm ${
                    step > s ? 'bg-green-500 text-white' :
                    step === s ? 'bg-primary text-white' :
                    'bg-secondary text-muted-foreground'
                  }`}>
                    {step > s ? <CheckCircle className="h-5 w-5" /> : s}
                  </div>
                  <span className="text-xs text-muted-foreground hidden sm:block">{label}</span>
                </div>
                {s < 4 && <ArrowRight className={`mb-4 ${step > s ? 'text-green-500' : 'text-slate-300'}`} />}
              </React.Fragment>
            );
          })}
        </div>

        <div className="space-y-6">
          {/* ── Step 1: Upload ── */}
          {step === 1 && (
            <>
              <Card className="p-6 border-0 shadow-sm">
                <h3 className="text-lg font-semibold text-foreground mb-4">1. Preparación</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                  <div className="space-y-2 sm:col-span-2">
                    <Label>Tipo de importación</Label>
                    <Select value={importMode} onValueChange={setImportMode} disabled={initialClosed}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="inicial">Inicial: enlaza por nombre (después se repara)</SelectItem>
                        <SelectItem value="incremental">Incremental: el archivo trae los IDs</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {initialClosed
                        ? 'La importación inicial está cerrada: el archivo debe traer el ID (o código) de compañía, ramo, producto y agente.'
                        : incremental
                          ? 'El archivo debe traer el ID o código único de compañía, ramo, producto y agente. No se enlaza por nombre.'
                          : 'Solo para la carga inicial. Al terminar, corre «Reparar relaciones» en Importación de datos del sistema y cierra la importación inicial.'}
                    </p>
                  </div>
                  {!incremental && (
                  <div className="space-y-2">
                    <Label>Compañía Aseguradora *</Label>
                    <Select value={selectedCompany} onValueChange={setSelectedCompany}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar compañía" />
                      </SelectTrigger>
                      <SelectContent>
                        {companies.map(c => (
                          <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  )}
                  <div className="space-y-2">
                    <Label>Plantilla Excel</Label>
                    <Button onClick={downloadTemplate} variant="outline" className="w-full gap-2">
                      <Download className="h-4 w-4" /> Descargar Plantilla
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-6">
                  <Checkbox checked={createMissingClients} onCheckedChange={setCreateMissingClients} id="create-clients" />
                  <label htmlFor="create-clients" className="text-sm font-medium cursor-pointer">
                    Crear clientes automáticamente si no existen en el sistema
                  </label>
                </div>

                <div className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  canUpload ? 'border-input hover:border-border' : 'border-border bg-muted/40'
                }`}>
                  <Upload className={`h-12 w-12 mx-auto mb-4 ${canUpload ? 'text-muted-foreground/70' : 'text-slate-300'}`} />
                  <p className="text-sm text-muted-foreground mb-3">Selecciona un archivo Excel (.xlsx, .xls)</p>
                  <Input type="file" accept=".xlsx,.xls" onChange={handleFileChange}
                    disabled={!canUpload} className="max-w-sm mx-auto" />
                  {!canUpload && <p className="text-xs text-red-500 mt-2">Primero selecciona una compañía</p>}
                </div>
              </Card>

              <Alert className="border-border bg-muted">
                <AlertCircle className="h-4 w-4 text-foreground" />
                <AlertDescription className="text-foreground text-sm">
                  <strong>Características del importador:</strong>
                  <ul className="mt-2 ml-4 space-y-1">
                    <li>• Búsqueda de agente por nombre, alias o email</li>
                    <li>• Creación automática de clientes con todos sus campos</li>
                    <li>• Soporte de fechas en formato YYYY-MM-DD y DD/MM/YYYY</li>
                    <li>• Branch y ramo se toman automáticamente del producto/compañía</li>
                    <li>• Mapeo flexible de columnas con auto-detección</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </>
          )}

          {/* ── Step 2: Map Columns ── */}
          {step === 2 && (
            <Card className="p-6 border-0 shadow-sm">
              <h3 className="text-lg font-semibold text-foreground mb-2">2. Mapeo de Columnas</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Vincula las columnas de tu Excel con los campos del sistema.
                Los campos con * son obligatorios. El sistema auto-detectó algunas asignaciones.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                {activeFields.map(field => (
                  <div key={field.key} className="space-y-1">
                    <Label className={field.required ? 'font-semibold' : ''}>{field.label}</Label>
                    <Select
                      value={columnMapping[field.key] || '__none__'}
                      onValueChange={(value) => setColumnMapping({
                        ...columnMapping,
                        [field.key]: value === '__none__' ? undefined : value
                      })}
                    >
                      <SelectTrigger className={columnMapping[field.key] ? 'border-green-400' : field.required ? 'border-orange-500/30' : ''}>
                        <SelectValue placeholder="Sin asignar" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">-- Sin asignar --</SelectItem>
                        {excelColumns.map(col => (
                          <SelectItem key={col} value={col}>{col}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>Volver</Button>
                <Button onClick={validateData} className="gap-2">
                  Validar {parsedData.length} Filas
                </Button>
              </div>
            </Card>
          )}

          {/* ── Step 3: Validation ── */}
          {step === 3 && validationResults.length > 0 && (
            <Card className="p-6 border-0 shadow-sm">
              <h3 className="text-lg font-semibold text-foreground mb-4">3. Resultados de Validación</h3>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <Alert className="border-green-500/30 bg-green-500/10">
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <AlertDescription className="text-green-600 dark:text-green-400">
                    <span className="font-bold text-lg">{validationResults.filter(r => r.status === 'ok').length}</span> válidos
                  </AlertDescription>
                </Alert>
                <Alert className="border-yellow-500/30 bg-yellow-500/10">
                  <AlertCircle className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
                  <AlertDescription className="text-yellow-600 dark:text-yellow-400">
                    <span className="font-bold text-lg">{validationResults.filter(r => r.status === 'warning').length}</span> advertencias
                  </AlertDescription>
                </Alert>
                <Alert className="border-red-500/30 bg-red-500/10">
                  <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                  <AlertDescription className="text-red-600 dark:text-red-400">
                    <span className="font-bold text-lg">{validationResults.filter(r => r.status === 'error').length}</span> errores
                  </AlertDescription>
                </Alert>
              </div>
              <DataTable
                columns={toColumns([
                  { key: 'row', label: '#' },
                  { key: 'policyNumber', label: 'Póliza' },
                  { key: 'clientDoc', label: 'Doc' },
                  { key: 'clientName', label: 'Cliente' },
                  { key: 'agentName', label: 'Agente' },
                  { key: 'product', label: 'Producto' },
                  {
                    key: 'status', label: 'Estado',
                    render: (v) => (
                      <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${
                        v === 'ok' ? 'bg-green-500/10 text-green-600 dark:text-green-400' :
                        v === 'warning' ? 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400' :
                        'bg-red-500/10 text-red-600 dark:text-red-400'
                      }`}>
                        {v === 'ok' ? <CheckCircle className="h-3 w-3" /> :
                         v === 'warning' ? <AlertCircle className="h-3 w-3" /> :
                         <XCircle className="h-3 w-3" />}
                        {v === 'ok' ? 'OK' : v === 'warning' ? 'Advertencia' : 'Error'}
                      </span>
                    )
                  },
                  { key: 'errors', label: 'Detalle' },
                  { key: 'warnings', label: 'Notas' },
                ])}
                data={validationResults}
              />
              <div className="flex justify-between mt-6">
                <Button variant="outline" onClick={() => setStep(2)}>Volver al Mapeo</Button>
                {validationResults.filter(r => r.status !== 'error').length > 0 && (
                  <Button onClick={handleImport} disabled={importing} className="gap-2">
                    {importing && <Loader2 className="h-4 w-4 animate-spin" />}
                    Importar {validationResults.filter(r => r.status !== 'error').length} Pólizas
                  </Button>
                )}
              </div>
            </Card>
          )}

          {/* ── Step 4: Results ── */}
          {step === 4 && importResults && (
            <Card className="p-6 border-0 shadow-sm">
              <h3 className="text-lg font-semibold text-foreground mb-4">4. Importación Completada</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                <Alert className="border-green-500/30 bg-green-500/10">
                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <AlertDescription className="text-green-600 dark:text-green-400">
                    <span className="font-bold text-2xl block">{importResults.success}</span> pólizas importadas
                  </AlertDescription>
                </Alert>
                {importResults.clientsCreated > 0 && (
                  <Alert className="border-border bg-muted">
                    <CheckCircle className="h-4 w-4 text-foreground" />
                    <AlertDescription className="text-foreground">
                      <span className="font-bold text-2xl block">{importResults.clientsCreated}</span> clientes creados
                    </AlertDescription>
                  </Alert>
                )}
                {importResults.failed > 0 && (
                  <Alert className="border-red-500/30 bg-red-500/10">
                    <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                    <AlertDescription className="text-red-600 dark:text-red-400">
                      <span className="font-bold text-2xl block">{importResults.failed}</span> pólizas fallidas
                    </AlertDescription>
                  </Alert>
                )}
                {importResults.duplicates > 0 && (
                  <Alert className="border-amber-500/30 bg-amber-500/10">
                    <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                    <AlertDescription className="text-amber-600 dark:text-amber-400">
                      <span className="font-bold text-2xl block">{importResults.duplicates}</span> omitidas (duplicadas)
                    </AlertDescription>
                  </Alert>
                )}
              </div>
              {importResults.duplicateList.length > 0 && (
                <div className="p-4 bg-amber-500/10 rounded-lg mb-6 max-h-48 overflow-y-auto">
                  <h4 className="font-medium text-amber-600 dark:text-amber-400 mb-2 text-sm">Pólizas omitidas por duplicado:</h4>
                  {importResults.duplicateList.map((d, i) => <p key={i} className="text-xs text-amber-600 dark:text-amber-400">• {d}</p>)}
                </div>
              )}
              {importResults.errors.length > 0 && (
                <div className="p-4 bg-red-500/10 rounded-lg mb-6 max-h-48 overflow-y-auto">
                  <h4 className="font-medium text-red-600 dark:text-red-400 mb-2 text-sm">Errores detallados:</h4>
                  {importResults.errors.map((e, i) => <p key={i} className="text-xs text-red-600 dark:text-red-400">• {e}</p>)}
                </div>
              )}
              <Button onClick={resetImport} variant="outline">Nueva Importación</Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}