import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/lib/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import StatCard from '@/components/ui/StatCard';
import AlertCard from '@/components/ui/AlertCard';
import StatusBadge from '@/components/ui/StatusBadge';
import PullToRefresh from '@/components/ui/PullToRefresh';
import { 
  FileText, Users, TrendingUp, AlertTriangle, DollarSign, Shield, RefreshCw, ArrowRight, Settings, BarChart3, ClipboardList, Clock
} from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { es, enUS } from 'date-fns/locale';
import { formatDate, parseLocalDate } from '@/lib/dateUtils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, Legend } from 'recharts';
import BirthdayWidget from '@/components/dashboard/BirthdayWidget';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';
import { formatMoney } from '@/lib/formatMoney';

const COLORS = [
  '#4f7ee0', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
  '#06b6d4', '#f97316', '#84cc16', '#ec4899', '#14b8a6',
  '#a855f7', '#eab308', '#6366f1', '#22c55e', '#f43f5e'
];

export default function Dashboard() {
  const { t, i18n } = useTranslation();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const dateLocale = i18n.language === 'es' ? es : enUS;
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState(null);
  const [paymentKPIs, setPaymentKPIs] = useState(null);
  const [paymentKPIsLoading, setPaymentKPIsLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) return;
    if (currentUser.app_role === 'agente') {
      navigate(createPageUrl('AgentDashboard'), { replace: true });
      return;
    }
    loadData();
  }, [currentUser]);

  const loadData = async () => {
    setLoading(true);
    setPaymentKPIsLoading(true);

    // Phase 1: main dashboard data (fast — no payment records loaded)
    api.functions.invoke('getDashboardData', {})
      .then(res => setDashboardData(res.data))
      .catch(err => console.error('Error loading dashboard data:', err))
      .finally(() => setLoading(false));

    // Phase 2: payment KPIs (slow — loads all payment records, runs in parallel)
    api.functions.invoke('getDashboardPaymentKPIs', {})
      .then(res => setPaymentKPIs(res.data))
      .catch(err => console.error('Error loading payment KPIs:', err))
      .finally(() => setPaymentKPIsLoading(false));
  };

  // KPIs (pre-computed by backend function getDashboardData)
  const currentYear = new Date().getFullYear();
    const today = useMemo(() => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }, []);

  const kpis = useMemo(() => dashboardData?.kpis || {}, [dashboardData]);
  const { overdueTasks, todayTasks } = useMemo(() => dashboardData?.taskStats || {}, [dashboardData]);
  const upcomingRenewals = useMemo(() => dashboardData?.upcomingRenewals || [], [dashboardData]);
  const pieData = useMemo(() => dashboardData?.pieData || [], [dashboardData]);
  const agentProduction = useMemo(() => dashboardData?.agentProduction || [], [dashboardData]);
  const tasks = useMemo(() => dashboardData?.tasks || [], [dashboardData]);
  const recentPolicies = useMemo(() => dashboardData?.recentPolicies || [], [dashboardData]);
  const todayBirthdays = useMemo(() => dashboardData?.birthdays || [], [dashboardData]);
  const hasPolicies = dashboardData?.hasPolicies ?? false;

  const activePolicies = kpis.activePolicies || 0;
  const expiredPolicies = kpis.expiredPolicies || 0;
  const atRiskPolicies = kpis.atRiskPolicies || 0;
  const newBusinessCount = kpis.newBusinessCount || 0;
  const annualProduction = kpis.annualProduction || 0;
  const totalPremiums = kpis.totalPremiums || 0;
  const overduePayments = paymentKPIsLoading ? null : (paymentKPIs?.overduePayments || 0);
  const pendingPayments = paymentKPIsLoading ? null : (paymentKPIs?.pendingPayments || 0);
  const overdueAmountUSD = paymentKPIsLoading ? null : (paymentKPIs?.overdueAmountUSD || 0);
  const pendingAmountUSD = paymentKPIsLoading ? null : (paymentKPIs?.pendingAmountUSD || 0);
  const pendingClaims = kpis.pendingClaims || 0;
  const paidClaimsAmount = kpis.paidClaimsAmount || 0;
  const calculatedCommissions = kpis.calculatedCommissions || 0;
  const paidCommissions = kpis.paidCommissions || 0;

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="min-h-screen bg-background p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-6">
        {loading ? (
          <div className="space-y-6">
            <div className="h-8 w-48 bg-secondary rounded animate-pulse" />
            <div className="h-4 w-64 bg-secondary rounded animate-pulse" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1,2,3].map(i => <div key={i} className="h-24 bg-secondary rounded-lg animate-pulse" />)}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1,2,3,4].map(i => <div key={i} className="h-24 bg-secondary rounded-lg animate-pulse" />)}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[1,2].map(i => <div key={i} className="h-80 bg-secondary rounded-lg animate-pulse" />)}
            </div>
          </div>
        ) : dashboardData ? (
        <>
        {/* Header */}
        <div className="flex flex-col gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground dark:text-white">{t('dashboard.title')}</h1>
            <p className="text-sm sm:text-base text-muted-foreground ">{t('dashboard.summary')}</p>
          </div>
        </div>

        {/* Birthday Widget */}
        {todayBirthdays.length > 0 && (
          <BirthdayWidget birthdays={todayBirthdays} />
        )}

        {/* Alerts */}
        {(upcomingRenewals.length > 0 || overduePayments > 0 || atRiskPolicies > 0 || overdueTasks > 0 || todayTasks > 0) && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {upcomingRenewals.length > 0 && (
              <Link to={createPageUrl('Renewals')}>
                <AlertCard
                  variant="warning"
                  title={t('dashboard.upcomingRenewals')}
                  description={t('dashboard.upcomingRenewals')}
                  count={upcomingRenewals.length}
                />
              </Link>
            )}
            {overduePayments > 0 && (
              <Link to={createPageUrl('Payments')}>
                <AlertCard
                  variant="error"
                  title={t('payments.overdue')}
                  description={t('payments.overdue')}
                  count={overduePayments}
                />
              </Link>
            )}
            {atRiskPolicies > 0 && (
              <Link to={createPageUrl('Policies')}>
                <AlertCard
                  variant="error"
                  title={t('policies.atRisk')}
                  description={t('policies.atRisk')}
                  count={atRiskPolicies}
                />
              </Link>
            )}
            {overdueTasks > 0 && (
              <Link to={createPageUrl('MyTasks')}>
                <AlertCard
                  variant="error"
                  title={t('tasks.overdue')}
                  description={t('tasks.overdue')}
                  count={overdueTasks}
                />
              </Link>
            )}
            {todayTasks > 0 && (
              <Link to={createPageUrl('MyTasks')}>
                <AlertCard
                  variant="warning"
                  title={t('tasks.dueDate')}
                  description={t('tasks.dueDate')}
                  count={todayTasks}
                />
              </Link>
            )}
          </div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard
            title={`${t('policies.newBusiness')} ${currentYear}`}
            value={newBusinessCount}
            subtitle={`${t('policies.newBusiness')} ${currentYear}`}
            icon={FileText}
            iconBg="bg-muted"
            iconColor="text-foreground"
          />
          <StatCard
            title={t('dashboard.annualProduction')}
            value={`USD ${formatMoney(annualProduction)}`}
            subtitle={`${t('policies.newBusiness')} ${currentYear}`}
            icon={TrendingUp}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-600 dark:text-emerald-400"
          />
          <StatCard
            title={t('dashboard.totalAnnualPremium')}
            value={`USD ${formatMoney(totalPremiums)}`}
            subtitle={`${currentYear}`}
            icon={DollarSign}
            iconBg="bg-purple-500/10"
            iconColor="text-purple-600 dark:text-purple-400"
          />
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title={t('dashboard.myPortfolio')}
            value={activePolicies}
            subtitle={`${t('policies.active')} + ${t('policies.atRisk')} (${expiredPolicies} ${t('policies.expired')})`}
            icon={FileText}
            iconBg="bg-muted"
            iconColor="text-muted-foreground"
          />
          <StatCard
            title={t('dashboard.pendingCommissions')}
            value={`USD ${formatMoney(calculatedCommissions)}`}
            subtitle={`USD ${formatMoney(paidCommissions)} ${t('commissions.paid')}`}
            icon={TrendingUp}
            iconBg="bg-muted"
            iconColor="text-foreground"
          />
          <StatCard
            title={t('dashboard.activeClaims')}
            value={pendingClaims}
            subtitle={`USD ${formatMoney(paidClaimsAmount)} ${t('payments.paid')}`}
            icon={Shield}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-600 dark:text-amber-400"
          />
          <StatCard
            title={t('dashboard.overduePayments')}
            value={overduePayments === null ? <span className="inline-block w-8 h-5 bg-secondary rounded animate-pulse" /> : overduePayments}
            subtitle={pendingPayments === null ? '\u00a0' : `${pendingPayments} ${t('payments.pending')}`}
            icon={AlertTriangle}
            iconBg="bg-red-500/10"
            iconColor="text-red-600 dark:text-red-400"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">{t('policies.title')} / {t('policies.line')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPie>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={2}
                      minAngle={3}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </RechartsPie>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Top {t('agents.title')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={agentProduction}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip 
                      formatter={(value) => [`$${formatMoney(value)}`, t('dashboard.annualProduction')]}
                      labelFormatter={(label, payload) => {
                        const item = payload?.[0]?.payload;
                        return item?.fullName || label;
                      }}
                    />
                    <Bar dataKey="produccion" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tasks Widget */}
        {tasks.length > 0 && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <ClipboardList className="h-5 w-5 text-foreground" />
                {t('tasks.myTasks')}
              </CardTitle>
              <Link to={createPageUrl('MyTasks')}>
                <Button variant="ghost" size="sm" className="gap-1 text-foreground">
                  {t('dashboard.viewAll')} <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {tasks.slice(0, 5).map(task => {
                  const dueDate = parseLocalDate(task.due_date) || today;
                  const isOverdue = dueDate < today;
                  const isToday = dueDate.toDateString() === today.toDateString();
                  const daysLeft = differenceInDays(dueDate, today);
                  
                  return (
                    <div key={task.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-lg hover:bg-muted transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-foreground dark:text-white">{task.title}</p>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            task.priority === 'alta' ? 'bg-red-500/10 text-red-600 dark:text-red-400' :
                            task.priority === 'media' ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' :
                            'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          }`}>
                            {task.priority === 'alta' ? '🔴' : task.priority === 'media' ? '🟡' : '🟢'}
                          </span>
                        </div>
                        {task.description && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{task.description}</p>
                        )}
                      </div>
                      <div className="text-right ml-4">
                        <div className={`text-sm font-medium flex items-center gap-1 ${
                          isOverdue ? 'text-red-600 dark:text-red-400 dark:text-red-400' : isToday ? 'text-amber-600 dark:text-amber-400 dark:text-amber-400' : 'text-muted-foreground '
                        }`}>
                          <Clock className="h-3 w-3" />
                          {isOverdue ? t('tasks.overdue') : isToday ? t('common.today') : `${daysLeft}d`}
                        </div>
                        <p className="text-xs text-muted-foreground/70 mt-0.5">
                          {format(dueDate, 'dd MMM', { locale: dateLocale })}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Policies */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold">{t('dashboard.recentPolicies')}</CardTitle>
              <Link to={createPageUrl('Policies')}>
                <Button variant="ghost" size="sm" className="gap-1 text-foreground">
                  {t('dashboard.viewAll')} <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentPolicies.map(policy => (
                  <div key={policy.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-lg">
                    <div>
                      <p className="font-medium text-foreground dark:text-white">{policy.policy_number}</p>
                      <p className="text-sm text-muted-foreground ">{policy.client_name}</p>
                    </div>
                    <div className="text-right">
                      <StatusBadge status={policy.status} />
                      <p className="text-sm text-muted-foreground mt-1">{policy.currency} {formatMoney(policy.annual_premium)}</p>
                    </div>
                  </div>
                ))}
                {!hasPolicies && (
                  <p className="text-center text-muted-foreground/70 py-8">{t('common.noData')}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Pending Renewals */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold">{t('dashboard.upcomingRenewals')}</CardTitle>
              <Link to={createPageUrl('Renewals')}>
                <Button variant="ghost" size="sm" className="gap-1 text-foreground">
                  {t('dashboard.viewAll')} <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingRenewals.slice(0, 5).map(policy => {
                  const daysLeft = differenceInDays(parseLocalDate(policy.end_date), today);
                  return (
                    <div key={policy.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-lg">
                      <div>
                        <p className="font-medium text-foreground dark:text-white">{policy.policy_number}</p>
                        <p className="text-sm text-muted-foreground ">{policy.client_name}</p>
                      </div>
                      <div className="text-right">
                        <span className={`text-sm font-medium ${daysLeft <= 15 ? 'text-red-600 dark:text-red-400 dark:text-red-400' : daysLeft <= 30 ? 'text-amber-600 dark:text-amber-400 dark:text-amber-400' : 'text-muted-foreground '}`}>
                          {daysLeft} {t('dashboard.daysLeft')}
                        </span>
                        <p className="text-sm text-muted-foreground/70 ">
                          {formatDate(policy.end_date, 'dd MMM yyyy', { locale: dateLocale })}
                        </p>
                      </div>
                    </div>
                  );
                })}
                {upcomingRenewals.length === 0 && (
                  <p className="text-center text-muted-foreground/70 py-8">{t('common.noData')}</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">{t('dashboard.quickActions')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Link to={createPageUrl('Clients')}>
                <Button variant="outline" className="w-full h-16 sm:h-20 flex-col gap-1 sm:gap-2">
                  <Users className="h-5 w-5 sm:h-6 sm:w-6" />
                  <span className="text-xs sm:text-sm">{t('clients.new')}</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Policies')}>
                <Button variant="outline" className="w-full h-16 sm:h-20 flex-col gap-1 sm:gap-2">
                  <FileText className="h-5 w-5 sm:h-6 sm:w-6" />
                  <span className="text-xs sm:text-sm">{t('policies.new')}</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Payments')}>
                <Button variant="outline" className="w-full h-16 sm:h-20 flex-col gap-1 sm:gap-2">
                  <DollarSign className="h-5 w-5 sm:h-6 sm:w-6" />
                  <span className="text-xs sm:text-sm">{t('payments.new')}</span>
                </Button>
              </Link>

              <Link to={createPageUrl('Renewals')}>
                <Button variant="outline" className="w-full h-16 sm:h-20 flex-col gap-1 sm:gap-2">
                  <RefreshCw className="h-5 w-5 sm:h-6 sm:w-6" />
                  <span className="text-xs sm:text-sm">{t('renewals.new')}</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Reports')}>
                <Button variant="outline" className="w-full h-16 sm:h-20 flex-col gap-1 sm:gap-2">
                  <BarChart3 className="h-5 w-5 sm:h-6 sm:w-6" />
                  <span className="text-xs sm:text-sm">{t('reports.title')}</span>
                </Button>
              </Link>
              <Link to={createPageUrl('Settings')}>
                <Button variant="outline" className="w-full h-16 sm:h-20 flex-col gap-1 sm:gap-2">
                  <Settings className="h-5 w-5 sm:h-6 sm:w-6" />
                  <span className="text-xs sm:text-sm">{t('settings.title')}</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        </>
        ) : null}
        </div>
      </div>
    </PullToRefresh>
  );
}