import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Pencil, Trash2, Trophy, Calendar, Target, ChevronRight, Copy, User, Users } from 'lucide-react';
import { toast } from 'sonner';
import IncentiveForm from '@/components/incentives/IncentiveForm';
import IncentiveProgressTable from '@/components/incentives/IncentiveProgressTable';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';

const fmt = (n, currency = 'USD') =>
  new Intl.NumberFormat('es-EC', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n || 0);

const statusColors = {
  active: 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/30',
  pending: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/30',
  completed: 'bg-muted text-foreground border-border',
  cancelled: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30'
};
const statusLabel = { active: 'Activo', pending: 'Pendiente', completed: 'Completado', cancelled: 'Cancelado' };

export default function Incentives() {
  const [incentives, setIncentives] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [selectedIncentive, setSelectedIncentive] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    api.auth.me().then(u => setCurrentUser(u));
  }, []);

  const isGerencialWithAgent = currentUser?.data?.app_role === 'gerencial' && currentUser?.data?.agent_id;
  const canEdit = !isGerencialWithAgent;

  const load = async () => {
    setLoading(true);
    const data = await api.entities.Incentive.list('-created_date', 100);
    setIncentives(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleEdit = (inc, e) => { e.stopPropagation(); setEditing(inc); setFormOpen(true); };
  const handleDelete = async () => {
    await api.entities.Incentive.delete(deleteTarget.id);
    toast.success('Incentivo eliminado');
    setDeleteTarget(null);
    if (selectedIncentive?.id === deleteTarget.id) setSelectedIncentive(null);
    load();
  };

  const openNew = () => { setEditing(null); setFormOpen(true); };

  const handleClone = async (inc, e) => {
    e.stopPropagation();
    const cloned = {
      name: `${inc.name} (COPIA)`,
      description: inc.description,
      start_date: inc.start_date,
      end_date: inc.end_date,
      currency: inc.currency,
      target_amount: inc.target_amount,
      target_for: inc.target_for,
      stages: inc.stages || [],
      participants: inc.participants || { companies: [], products: [] },
      rules: inc.rules || [],
      status: 'pending'
    };
    await api.entities.Incentive.create(cloned);
    toast.success('Incentivo clonado — puedes editarlo ahora');
    load();
  };

  if (selectedIncentive) {
    const inc = incentives.find(i => i.id === selectedIncentive.id) || selectedIncentive;
    return (
      <div className="max-w-7xl mx-auto p-4 lg:p-6">
        <div className="flex items-center gap-2 mb-4">
          <Button variant="ghost" size="sm" onClick={() => setSelectedIncentive(null)}>
            ← Volver
          </Button>
          <ChevronRight className="h-4 w-4 text-muted-foreground/70" />
          <span className="text-muted-foreground">Incentivos</span>
          <ChevronRight className="h-4 w-4 text-muted-foreground/70" />
          <span className="font-semibold">{inc.name}</span>
        </div>
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between flex-wrap gap-2">
              <div>
                <CardTitle className="text-xl flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-amber-500" />
                  {inc.name}
                </CardTitle>
                {inc.description && <p className="text-sm text-muted-foreground mt-1">{inc.description}</p>}
              </div>
              <div className="flex gap-2 items-center flex-wrap">
                {inc.target_for?.includes('agent_individual') && (
                  <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/30">
                    <User className="h-3 w-3" />Individual
                  </span>
                )}
                {inc.target_for?.includes('agent_agency') && (
                  <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/30">
                    <Users className="h-3 w-3" />Agencia
                  </span>
                )}
                <Badge className={statusColors[inc.status]}>{statusLabel[inc.status]}</Badge>
                {canEdit && <Button variant="outline" size="sm" onClick={(e) => handleEdit(inc, e)}><Pencil className="h-4 w-4 mr-1" />Editar</Button>}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Período</p>
                <p className="font-medium">{inc.start_date} → {inc.end_date}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Meta principal</p>
                <p className="font-bold text-base text-green-600 dark:text-green-400">{fmt(inc.target_amount, inc.currency)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Etapas</p>
                <p className="font-medium">{inc.stages?.length || 0} hito(s)</p>
              </div>
              <div>
                <p className="text-muted-foreground">Reglas de ponderación</p>
                <p className="font-medium">{inc.rules?.length || 0} regla(s)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Cumplimiento por Agente / Agencia</CardTitle>
          </CardHeader>
          <CardContent>
            <IncentiveProgressTable incentive={inc} restrictToAgentId={isGerencialWithAgent ? currentUser.data.agent_id : null} />
          </CardContent>
        </Card>

        <IncentiveForm
          open={formOpen} onOpenChange={setFormOpen}
          incentive={editing}
          onSave={() => { load(); setSelectedIncentive(null); }}
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Trophy className="h-6 w-6 text-amber-500" />
            Incentivos
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Gestión y seguimiento de incentivos comerciales</p>
        </div>
        {canEdit && (
          <Button onClick={openNew} className="bg-brand hover:bg-[#007da8]">
            <Plus className="h-4 w-4 mr-1" />Nuevo incentivo
          </Button>
        )}
      </div>

      {/* List */}
      {loading ? (
        <div className="py-16 text-center text-muted-foreground">Cargando...</div>
      ) : incentives.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <Trophy className="h-12 w-12 mx-auto mb-3 text-slate-300" />
            <p className="text-lg font-medium">No hay incentivos creados</p>
            <p className="text-sm mt-1">Crea tu primer incentivo para empezar a medir el cumplimiento</p>
            <Button className="mt-4" onClick={openNew}>Crear incentivo</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {incentives.map(inc => (
            <Card
              key={inc.id}
              className="cursor-pointer hover:shadow-md transition-shadow border-l-4"
              style={{ borderLeftColor: inc.status === 'active' ? '#16a34a' : inc.status === 'pending' ? '#d97706' : '#64748b' }}
              onClick={() => setSelectedIncentive(inc)}
            >
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-base line-clamp-1">{inc.name}</CardTitle>
                  <Badge className={`text-xs shrink-0 ${statusColors[inc.status]}`}>{statusLabel[inc.status]}</Badge>
                </div>
                {inc.description && <p className="text-xs text-muted-foreground line-clamp-2">{inc.description}</p>}
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Target className="h-4 w-4 text-green-600 dark:text-green-400" />
                    <span className="font-semibold text-green-600 dark:text-green-400">{fmt(inc.target_amount, inc.currency)}</span>
                    <span className="text-muted-foreground">meta principal</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    {inc.start_date} → {inc.end_date}
                  </div>
                  {inc.stages?.length > 0 && (
                    <div className="text-xs text-muted-foreground">{inc.stages.length} etapa(s) intermedia(s)</div>
                  )}
                  {inc.rules?.length > 0 && (
                    <div className="text-xs text-muted-foreground">{inc.rules.length} regla(s) de ponderación</div>
                  )}
                </div>
                {/* Target type tags */}
                <div className="flex gap-1.5 mt-2">
                  {inc.target_for?.includes('agent_individual') && (
                    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/30">
                      <User className="h-3 w-3" />Individual
                    </span>
                  )}
                  {inc.target_for?.includes('agent_agency') && (
                    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/30">
                      <Users className="h-3 w-3" />Agencia
                    </span>
                  )}
                </div>
                <div className="flex gap-2 mt-3 pt-3 border-t">
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => setSelectedIncentive(inc)}>
                    Ver cumplimiento
                  </Button>
                  {canEdit && <Button size="sm" variant="ghost" title="Clonar" onClick={(e) => handleClone(inc, e)}><Copy className="h-4 w-4" /></Button>}
                  {canEdit && <Button size="sm" variant="ghost" onClick={(e) => handleEdit(inc, e)}><Pencil className="h-4 w-4" /></Button>}
                  {canEdit && (
                    <Button size="sm" variant="ghost" className="text-red-500 hover:text-red-600 dark:hover:text-red-400"
                      onClick={(e) => { e.stopPropagation(); setDeleteTarget(inc); }}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <IncentiveForm
        open={formOpen} onOpenChange={setFormOpen}
        incentive={editing}
        onSave={load}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={v => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar incentivo?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción no se puede deshacer. Se eliminará el incentivo "{deleteTarget?.name}".</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}