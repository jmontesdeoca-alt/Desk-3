import React, { useState } from 'react';
import { Settings } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useFeatures } from '@/lib/FeatureContext';
import { MODULE_FEATURE, settingsTabs } from '@/modules/registry';

export default function CrmSettings() {
  const { has } = useFeatures();
  const tabs = settingsTabs((id) => has(MODULE_FEATURE[id]));
  const [active, setActive] = useState(tabs[0]?.id);
  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto space-y-6">
      <PageHeader title="Configuración del CRM" subtitle="Pipelines, etiquetas, metas e integraciones" icon={Settings} backTo="AdminPanel" />
      <Tabs value={active} onValueChange={setActive}>
        <TabsList className="h-auto flex-wrap gap-1">
          {tabs.map((t) => (
            <TabsTrigger key={t.id} value={t.id} className="gap-2">{t.icon && <t.icon className="h-4 w-4" />}{t.label}</TabsTrigger>
          ))}
        </TabsList>
        {tabs.map((t) => (
          <TabsContent key={t.id} value={t.id} className={t.bare ? 'm-0 mt-6' : 'mt-4'}><t.Component /></TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
