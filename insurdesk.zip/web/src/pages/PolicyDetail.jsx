import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import PaymentForm from '@/components/forms/PaymentForm';
import ClaimForm from '@/components/forms/ClaimForm';
import EndorsementForm from '@/components/forms/EndorsementForm';
import CorporateMemberForm from '@/components/forms/CorporateMemberForm';
import DocumentList from '@/components/documents/DocumentList';
import AuditHistoryPopover from '@/components/AuditHistoryPopover';
import AgentInfoPopover from '@/components/policy/AgentInfoPopover';
import { 
  FileText, DollarSign, Shield, RefreshCw, TrendingUp, Plus, 
  Loader2, Calendar, Building2, User, Briefcase, FileEdit, History,
  Users, Eye, Pencil, Trash2, ChevronDown, ChevronRight, Search, Car, Home
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { differenceInDays, differenceInCalendarDays } from 'date-fns';
import RenewalFormDialog from '@/components/forms/RenewalFormDialog';
import { executeDirectRenewal } from '@/hooks/useDirectRenewal';
import { es } from 'date-fns/locale';
import { formatLocalDateTime, formatDate } from '@/components/dateUtils';
import { toast } from "sonner";
import { useTranslation } from 'react-i18next';
import '@/components/i18n';
import { enUS } from 'date-fns/locale';
import ClientQuickViewModal from '@/components/client/ClientQuickViewModal';
import PolicyTagBadges from '@/components/policy/PolicyTagBadges';
import { loadTRMsForPolicies, convertToUSD } from '@/lib/currencyConversion';

export default function PolicyDetail() {
  const { t, i18n } = useTranslation();
  const dateLocale = i18n.language === 'es' ? es : enUS;
  const [user, setUser] = useState(null);
  const [policy, setPolicy] = useState(null);
  const [payments, setPayments] = useState([]);
  const [claims, setClaims] = useState([]);
  const [commissions, setCommissions] = useState([]);
  const [renewals, setRenewals] = useState([]);
  const [endorsements, setEndorsements] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [corporateMembers, setCorporateMembers] = useState([]);
  const [corporateRates, setCorporateRates] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [paymentFormOpen, setPaymentFormOpen] = useState(false);
  const [claimFormOpen, setClaimFormOpen] = useState(false);
  const [endorsementFormOpen, setEndorsementFormOpen] = useState(false);
  const [renewalFormOpen, setRenewalFormOpen] = useState(false);
  const [manualCommissionOpen, setManualCommissionOpen] = useState(false);
  const [memberFormOpen, setMemberFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [memberDetailOpen, setMemberDetailOpen] = useState(false);
  const [selectedMemberDetail, setSelectedMemberDetail] = useState(null);
  const [expandedMembers, setExpandedMembers] = useState({});
  const [memberSearch, setMemberSearch] = useState('');
  const [pendingPayment, setPendingPayment] = useState(null);
  const [agentsForManualCommission, setAgentsForManualCommission] = useState([]);
  const [saving, setSaving] = useState(false);
  const [clientModalOpen, setClientModalOpen] = useState(false);
  const [selectedClientId, setSelectedClientId] = useState(null);
  const [renewalForm, setRenewalForm] = useState({
    new_premium: 0,
    new_commissionable_premium: 0,
    payment_frequency: 'mensual',
    new_start_date: '',
    new_end_date: '',
    mode: 'propuesta'
  });
  const [trmMap, setTrmMap] = useState(new Map());

  const urlParams = new URLSearchParams(window.location.search);
  const policyId = urlParams.get('id');

  useEffect(() => {
    api.auth.me().then(u => setUser(u)).catch(() => {});
    if (policyId) loadData();
  }, [policyId]);

  // Cargar TRM para pólizas en COP (misma lógica que los widgets de Reports)
  useEffect(() => {
    if (policy?.currency === 'COP' && policy.issue_date) {
      loadTRMsForPolicies([policy]).then(setTrmMap).catch(() => {});
    } else {
      setTrmMap(new Map());
    }
  }, [policy?.id, policy?.currency, policy?.issue_date]);

  // Helper para updates de Policy con updated_by automático
  const updatePolicy = async (id, data) => {
    const currentEmail = user?.email || (await api.auth.me().catch(() => null))?.email || 'sistema';
    return api.entities.Policy.update(id, { ...data, updated_by: currentEmail });
  };

  const loadData = async () => {
    if (!policyId) { setLoading(false); return; }
    setLoading(true);

    // Fetch policy via backend function to support agente hierarchy access
    const policyRes = await api.functions.invoke('getPolicyForAgent', { policy_id: policyId });
    const policyRecord = policyRes?.data?.policy || null;

    if (!policyRecord) {
      setPolicy(null);
      setLoading(false);
      return;
    }

    const [paymentsData, claimsData, commissionsData, renewalsData, endorsementsData, auditLogsData, membersData, ratesData] = await Promise.all([
      api.entities.Payment.filter({ policy_id: policyId }),
      api.entities.Claim.filter({ policy_id: policyId }),
      api.entities.Commission.filter({ policy_id: policyId }),
      api.entities.Renewal.filter({ original_policy_id: policyId }),
      api.entities.Endorsement.filter({ policy_id: policyId }),
      api.entities.AuditLog.filter({ entity_type: 'Policy', entity_id: policyId }),
      api.entities.CorporateMember.filter({ policy_id: policyId }),
      api.entities.CorporateRatePlan.filter({ policy_id: policyId })
    ]);
    setPolicy(policyRecord);
    setPayments(paymentsData.sort((a, b) => (a.installment_number || 0) - (b.installment_number || 0)));
    setClaims(claimsData);
    setCommissions(commissionsData);
    setRenewals(renewalsData);
    setEndorsements(endorsementsData);
    setAuditLogs(auditLogsData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
    setCorporateMembers(membersData);
    setCorporateRates(ratesData);
    
    // Check if policy was modified
    if (policyRecord && auditLogsData.length > 0) {
      const updateLogs = auditLogsData.filter(log => log.action === 'UPDATE').sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
      if (updateLogs.length > 0) {
        setPolicy({
          ...policyRecord,
          _last_modified_by: updateLogs[0].user_email,
          _last_modified_date: updateLogs[0].created_date,
          _was_modified: true
        });
      }
    }
    
    setLoading(false);
  };

  const handlePaymentSubmit = async (data) => {
    setSaving(true);
    await api.entities.Payment.create({
      ...data,
      policy_id: policyId,
      policy_number: policy.policy_number,
      client_name: policy.client_name
    });
    setSaving(false);
    setPaymentFormOpen(false);
    loadData();
  };

  const handleClaimSubmit = async (data) => {
    setSaving(true);
    await api.entities.Claim.create(data);
    setSaving(false);
    setClaimFormOpen(false);
    loadData();
  };

  const handleEndorsementSubmit = async (data) => {
    setSaving(true);
    try {
      const endorsement = await api.entities.Endorsement.create(data);

      // For inclusion/exclusion of dependientes or premium changes, generate endorsement installments
      const premiumChangingTypes = ['inclusion_dependiente', 'exclusion_dependiente', 'aumento_prima', 'reduccion_prima'];
      if (premiumChangingTypes.includes(data.endorsement_type) && data.premium_difference && data.premium_difference !== 0) {
        const difference = parseFloat(data.premium_difference);
        const effectiveDate = new Date(data.effective_date + 'T00:00:00');

        // Find pending payments from effective date onwards
        const pendingFromEffective = payments.filter(p => {
          if (p.status === 'pagado') return false;
          if (!p.due_date) return false;
          const dueDate = new Date(p.due_date + 'T00:00:00');
          return dueDate >= effectiveDate;
        });

        if (pendingFromEffective.length > 0) {
          const extraPerInstallment = difference / pendingFromEffective.length;

          for (let i = 0; i < pendingFromEffective.length; i++) {
            const originalPayment = pendingFromEffective[i];
            await api.entities.Payment.create({
              policy_id: policyId,
              policy_number: policy.policy_number,
              client_name: policy.client_name,
              due_date: originalPayment.due_date,
              period: originalPayment.period,
              amount: parseFloat(extraPerInstallment.toFixed(2)),
              currency: policy.currency,
              status: 'pendiente',
              installment_number: i + 1,
              payment_group: 'endorsement',
              endorsement_id: endorsement.id,
              endorsement_number: data.endorsement_number,
              notes: `Endoso ${data.endorsement_type?.replace(/_/g, ' ')} - ${data.endorsement_number}`
            });
          }

          const newPremium = (policy.annual_premium || 0) + difference;
          await updatePolicy(policyId, {
            annual_premium: parseFloat(newPremium.toFixed(2)),
            commissionable_premium: parseFloat(newPremium.toFixed(2))
          });
        }
      }

      // Si es endoso de cancelación, cambiar estado de la póliza a cancelada
      if (data.endorsement_type === 'cancelacion') {
        await updatePolicy(policyId, { status: 'cancelada' });
        toast.success('Endoso de cancelación guardado. Póliza marcada como cancelada.');
      } else {
        toast.success('Endoso guardado exitosamente');
      }

      setEndorsementFormOpen(false);
      loadData();
    } catch (error) {
      toast.error(`Error al guardar el endoso: ${error.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleMemberSubmit = async (data) => {
    setSaving(true);
    let result;
    if (editingMember) {
      await api.entities.CorporateMember.update(editingMember.id, data);
      toast.success('Afiliado actualizado exitosamente');
      result = { id: editingMember.id };
    } else {
      result = await api.entities.CorporateMember.create(data);
      toast.success('Afiliado creado exitosamente');
    }
    setSaving(false);
    setMemberFormOpen(false);
    setEditingMember(null);
    loadData();
    return result;
  };

  const handleEditMember = (member) => {
    setEditingMember(member);
    setMemberFormOpen(true);
  };

  const handleDeleteMember = async (member) => {
    const confirmed = confirm(`¿Eliminar al afiliado ${member.first_name} ${member.last_name}?`);
    if (!confirmed) return;
    
    setSaving(true);
    
    // If it's a titular, also delete their dependents
    if (member.member_type === 'TITULAR') {
      const dependents = corporateMembers.filter(m => m.parent_member_id === member.id);
      if (dependents.length > 0) {
        const confirmDeps = confirm(`Este titular tiene ${dependents.length} dependiente(s). ¿Eliminar también a los dependientes?`);
        if (confirmDeps) {
          for (const dep of dependents) {
            await api.entities.CorporateMember.delete(dep.id);
          }
        }
      }
    }
    
    await api.entities.CorporateMember.delete(member.id);
    setSaving(false);
    loadData();
    toast.success('Afiliado eliminado');
  };

  const viewMemberDetail = (member) => {
    setSelectedMemberDetail(member);
    setMemberDetailOpen(true);
  };

  const toggleMemberExpanded = (memberId) => {
    setExpandedMembers(prev => ({
      ...prev,
      [memberId]: !prev[memberId]
    }));
  };

  const generateInstallmentAmount = async (payment) => {
    if (!payment || payment.amount > 0) return;
    
    setSaving(true);
    
    // Get current rate plan
    const currentRate = corporateRates.find(r => {
      const today = new Date();
      const effectiveFrom = new Date(r.effective_from);
      const effectiveTo = r.effective_to ? new Date(r.effective_to) : new Date('2099-12-31');
      return today >= effectiveFrom && today <= effectiveTo;
    });
    
    if (!currentRate) {
      toast.error('No se encontró un plan de tarifas vigente para esta póliza');
      setSaving(false);
      return;
    }
    
    // Count members by coverage tier for the month
    const titulares = corporateMembers.filter(m => 
      m.member_type === 'TITULAR' && 
      m.status === 'activo'
    );
    
    const countTitularSolo = titulares.filter(t => t.coverage_tier === 'TITULAR_SOLO').length;
    const countTitularMas1 = titulares.filter(t => t.coverage_tier === 'TITULAR_MAS1').length;
    const countFamilia = titulares.filter(t => t.coverage_tier === 'FAMILIA').length;
    
    const totalAmount = 
      (countTitularSolo * currentRate.rate_titular_solo) +
      (countTitularMas1 * currentRate.rate_titular_mas1) +
      (countFamilia * currentRate.rate_familia);
    
    await api.entities.Payment.update(payment.id, {
      amount: totalAmount
    });
    
    // Update policy annual_premium by adding this installment amount
    const currentPremium = policy.annual_premium || 0;
    const newPremium = currentPremium + totalAmount;
    
    await updatePolicy(policy.id, {
      annual_premium: newPremium,
      commissionable_premium: newPremium
    });
    
    setSaving(false);
    loadData();
    toast.success(`Cuota generada: ${policy.currency} ${totalAmount.toLocaleString()}`);
  };

  const openRenewalForm = (mode = 'propuesta') => {
    // Calculate new start: day after current end_date
    const currentEnd = new Date(policy.end_date + 'T00:00:00');
    const newStartDate = new Date(currentEnd);
    newStartDate.setDate(newStartDate.getDate() + 1);

    // Respect original policy duration
    const currentStart = new Date(policy.start_date + 'T00:00:00');
    const durationDays = differenceInCalendarDays(currentEnd, currentStart);
    const newEndDate = new Date(newStartDate);
    newEndDate.setDate(newEndDate.getDate() + durationDays);

    setRenewalForm({
      new_premium: policy.annual_premium,
      new_commissionable_premium: policy.commissionable_premium,
      payment_frequency: policy.payment_frequency,
      new_start_date: newStartDate.toISOString().split('T')[0],
      new_end_date: newEndDate.toISOString().split('T')[0],
      mode
    });
    setRenewalFormOpen(true);
  };

  const handleCreateRenewal = async () => {
    if (!policy) return;
    setSaving(true);
    await api.entities.Renewal.create({
      original_policy_id: policy.id,
      original_policy_number: policy.policy_number,
      client_name: policy.client_name,
      product_name: policy.product_name,
      renewal_date: new Date().toISOString().split('T')[0],
      new_start_date: renewalForm.new_start_date,
      new_end_date: renewalForm.new_end_date,
      current_premium: policy.annual_premium,
      new_premium: parseFloat(renewalForm.new_premium),
      new_commissionable_premium: parseFloat(renewalForm.new_commissionable_premium),
      payment_frequency: renewalForm.payment_frequency,
      currency: policy.currency,
      status: 'propuesta'
    });
    
    await updatePolicy(policy.id, { status: 'en_renovacion' });
    setSaving(false);
    setRenewalFormOpen(false);
    loadData();
    toast.success('Propuesta de renovación creada exitosamente');
  };

  const handleDirectRenewal = async () => {
    if (!policy) return;
    setSaving(true);
    const newPolicyNumber = await executeDirectRenewal(policy, renewalForm);
    setSaving(false);
    setRenewalFormOpen(false);
    toast.success(`Póliza renovada. Nueva póliza: ${newPolicyNumber}`);
    loadData();
  };

  const markPaymentAsPaid = async (payment) => {
    // For corporate policies, validate amount > 0
    if (policy.policy_category === 'CORPORATIVA' && payment.amount === 0) {
      toast.error('Primero debe generar la cuota antes de marcar como pagado');
      return;
    }
    
    // TEMPORALMENTE DESACTIVADO: bloqueo de cuotas anteriores deshabilitado para liquidación
    // const previousPayments = payments.filter(
    //   p => p.installment_number && payment.installment_number &&
    //        p.installment_number < payment.installment_number
    // );
    // const unpaidPrevious = previousPayments.find(p => p.status !== 'pagado');
    // if (unpaidPrevious) {
    //   toast.error(`No se puede pagar la cuota ${payment.installment_number}. Primero debe pagar la cuota ${unpaidPrevious.installment_number}.`);
    //   return;
    // }

    // For CORPORATE policies, ALWAYS use "segun_cliente" payment type (ignore company setting)
    const companies = await api.entities.InsuranceCompany.list();
    const company = companies.find(c => c.id === policy.company_id);
    const isNewBusiness = policy.policy_type === 'nuevo_negocio';
    const paymentType = policy.policy_category === 'CORPORATIVA' 
      ? 'segun_cliente' 
      : (isNewBusiness ? company?.new_business_payment_type : company?.renewal_payment_type);
    
    if (paymentType === 'anualizada') {
      const existingCommissions = await api.entities.Commission.filter({ 
        policy_id: policy.id 
      });
      
      if (existingCommissions.length > 0) {
        toast.info('Esta póliza ya tiene comisión anualizada generada. No se generarán comisiones adicionales.');
        
        await api.entities.Payment.update(payment.id, {
          status: 'pagado',
          payment_date: new Date().toISOString().split('T')[0]
        });
        
        loadData();
        return;
      }
    }

    // Verificar si hay tabla de comisiones asignada
    const hasCommissionTable = await checkCommissionTableExists();
    
    if (!hasCommissionTable) {
      // Abrir diálogo de liquidación manual
      setPendingPayment(payment);
      await loadAgentsForManualCommission();
      setManualCommissionOpen(true);
      return;
    }

    await api.entities.Payment.update(payment.id, {
      status: 'pagado',
      payment_date: new Date().toISOString().split('T')[0]
    });
    
    // Generate commissions for this payment
    if (payment.installment_number) {
      await generateCommissionsForPayment(payment);
    }
    
    loadData();
  };

  const checkCommissionTableExists = async () => {
    const assignments = await api.entities.AgentCommissionAssignment.filter({
      agent_id: policy.agent_id,
      company_id: policy.company_id,
      line_id: policy.line_id
    });
    return assignments.length > 0;
  };

  const loadAgentsForManualCommission = async () => {
    const agents = await api.entities.Agent.list();
    let currentAgent = agents.find(a => a.id === policy.agent_id);
    const agentsList = [];
    let level = 1;
    
    while (currentAgent && level <= 10) {
      agentsList.push({
        id: currentAgent.id,
        name: currentAgent.name,
        level: level,
        percentage: 0
      });
      
      if (currentAgent.upline_agent_id) {
        currentAgent = agents.find(a => a.id === currentAgent.upline_agent_id);
        level++;
      } else {
        break;
      }
    }
    
    setAgentsForManualCommission(agentsList);
  };

  const handleManualCommissionSubmit = async () => {
    if (!pendingPayment) return;
    
    setSaving(true);
    
    // Verificar si ya existe comisión anualizada para esta póliza
    const companies = await api.entities.InsuranceCompany.list();
    const company = companies.find(c => c.id === policy.company_id);
    const isNewBusiness = policy.policy_type === 'nuevo_negocio';
    const paymentType = isNewBusiness ? company?.new_business_payment_type : company?.renewal_payment_type;
    
    if (paymentType === 'anualizada') {
      const existingCommissions = await api.entities.Commission.filter({ 
        policy_id: policy.id 
      });
      
      if (existingCommissions.length > 0) {
        toast.error('Esta póliza ya tiene comisión anualizada generada. No se generarán comisiones adicionales.');
        
        await api.entities.Payment.update(pendingPayment.id, {
          status: 'pagado',
          payment_date: new Date().toISOString().split('T')[0]
        });
        
        setSaving(false);
        setManualCommissionOpen(false);
        setPendingPayment(null);
        setAgentsForManualCommission([]);
        loadData();
        return;
      }
    }
    
    // Marcar pago como pagado
    await api.entities.Payment.update(pendingPayment.id, {
      status: 'pagado',
      payment_date: new Date().toISOString().split('T')[0]
    });
    
    // Generar comisiones manualmente
    let premiumToCommission = 0;
    if (paymentType === 'anualizada') {
      premiumToCommission = policy.commissionable_premium || policy.annual_premium;
    } else {
      premiumToCommission = pendingPayment.amount;
    }
    
    for (const agent of agentsForManualCommission) {
      if (agent.percentage > 0) {
        const commissionAmount = (premiumToCommission * agent.percentage) / 100;
        
        await api.entities.Commission.create({
          policy_id: policy.id,
          policy_number: policy.policy_number,
          product_id: policy.product_id,
          product_name: policy.product_name,
          company_id: policy.company_id,
          company_name: policy.company_name,
          agent_id: agent.id,
          agent_name: agent.name,
          client_name: policy.client_name,
          level: agent.level,
          base_amount: premiumToCommission,
          commission_pct: agent.percentage,
          commission_amount: commissionAmount,
          installment_number: pendingPayment.installment_number,
          currency: policy.currency,
          generation_date: new Date().toISOString().split('T')[0],
          status: 'pendiente_liberar',
          source_type: policy.policy_type === 'renovacion' ? 'renovacion' : 'nuevo_negocio'
        });
      }
    }
    
    setSaving(false);
    setManualCommissionOpen(false);
    setPendingPayment(null);
    setAgentsForManualCommission([]);
    loadData();
  };

  const updateAgentPercentage = (index, percentage) => {
    const updated = [...agentsForManualCommission];
    updated[index].percentage = parseFloat(percentage) || 0;
    setAgentsForManualCommission(updated);
  };

  const generateCommissionsForPayment = async (payment) => {
    // Load necessary data
    const [agents, companies, assignments, tables] = await Promise.all([
      api.entities.Agent.list(),
      api.entities.InsuranceCompany.list(),
      api.entities.AgentCommissionAssignment.list(),
      api.entities.CommissionTable.list()
    ]);

    const company = companies.find(c => c.id === policy.company_id);
    if (!company) return;

    // Get payment type
    const isNewBusiness = policy.policy_type === 'nuevo_negocio';
    const paymentType = isNewBusiness ? company.new_business_payment_type : company.renewal_payment_type;
    
    // Si es anualizada, verificar si ya existen comisiones para evitar duplicados
    if (paymentType === 'anualizada') {
      const existingCommissions = await api.entities.Commission.filter({ 
        policy_id: policy.id 
      });
      
      if (existingCommissions.length > 0) {
        return; // Ya se generó la comisión anualizada, no generar más
      }
    }
    
    // Get premium to commission based on payment type
    let premiumToCommission = 0;
    if (paymentType === 'anualizada') {
      premiumToCommission = policy.commissionable_premium || policy.annual_premium;
    } else {
      premiumToCommission = payment.amount;
    }

    // Find selling agent
    let currentAgent = agents.find(a => a.id === policy.agent_id);
    if (!currentAgent) return;

    let currentLevel = 1;
    const maxLevels = 10;

    while (currentAgent && currentLevel <= maxLevels) {
      // Get assignment for this agent
      const assignment = assignments.find(
        a => a.agent_id === currentAgent.id && 
             a.company_id === policy.company_id && 
             a.line_id === policy.line_id
      );

      if (assignment) {
        const table = tables.find(t => t.id === assignment.commission_table_id);
        if (table && table.product_commissions) {
          const productComm = table.product_commissions.find(pc => pc.product_id === policy.product_id);
          if (productComm) {
            const commissionPct = isNewBusiness ? productComm.new_business_percentage : productComm.renewal_percentage;
            
            const commissionAmount = (premiumToCommission * commissionPct) / 100;

            await api.entities.Commission.create({
              policy_id: policy.id,
              policy_number: policy.policy_number,
              product_id: policy.product_id,
              product_name: policy.product_name,
              company_id: policy.company_id,
              company_name: policy.company_name,
              agent_id: currentAgent.id,
              agent_name: currentAgent.name,
              client_name: policy.client_name,
              level: currentLevel,
              base_amount: premiumToCommission,
              commission_pct: commissionPct,
              commission_amount: commissionAmount,
              installment_number: payment.installment_number,
              currency: policy.currency,
              generation_date: new Date().toISOString().split('T')[0],
              status: 'pendiente_liberar',
              source_type: policy.policy_type === 'renovacion' ? 'renovacion' : 'nuevo_negocio'
            });
          }
        }
      }

      // Move to upline agent
      if (currentAgent.upline_agent_id) {
        currentAgent = agents.find(a => a.id === currentAgent.upline_agent_id);
        currentLevel++;
      } else {
        break;
      }
    }
  };

  const paymentColumns = [
    { header: '#', cell: (row) => row.installment_number || '-' },
    { header: t('payments.period'), accessorKey: 'period' },
    { 
      header: t('payments.dueDate'), 
      cell: (row) => row.due_date ? formatDate(row.due_date, 'dd/MM/yyyy') : '-'
    },
    { 
      header: t('common.amount'), 
      cell: (row) => `${row.currency} ${row.amount?.toLocaleString()}`
    },
    { header: t('common.status'), cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: '',
      cell: (row) => {
        if (row.status === 'pagado') return null;
        
        if (policy?.policy_category === 'CORPORATIVA' && row.amount === 0 && user?.app_role !== 'agente') {
          return (
            <Button size="sm" variant="outline" className="gap-2" onClick={() => generateInstallmentAmount(row)}>
              <Plus className="h-3 w-3" /> {t('policyDetail.generateInstallment')}
            </Button>
          );
        }
        
        if (user?.app_role !== 'agente') {
          return (
            <Button size="sm" variant="outline" onClick={() => markPaymentAsPaid(row)}>
              {t('payments.markAsPaid')}
            </Button>
          );
        }
        
        return null;
      }
    }
  ];

  const claimColumns = [
    { header: t('claims.claimNumber'), accessorKey: 'claim_number' },
    { 
      header: t('claims.eventDate'), 
      cell: (row) => row.event_date ? formatDate(row.event_date, 'dd/MM/yyyy') : '-'
    },
    { header: t('common.type'), accessorKey: 'claim_type' },
    { 
      header: t('claims.claimedAmount'), 
      cell: (row) => `${row.currency} ${row.claimed_amount?.toLocaleString()}`
    },
    { 
      header: t('claims.paidAmount'), 
      cell: (row) => `${row.currency} ${(row.paid_amount || 0).toLocaleString()}`
    },
    { header: t('common.status'), cell: (row) => <StatusBadge status={row.status} /> }
  ];

  const commissionColumns = [
    { header: t('commissions.agent'), accessorKey: 'agent_name' },
    { header: t('commissions.level'), cell: (row) => `${t('commissions.level')} ${row.level}` },
    { header: '%', cell: (row) => `${row.commission_pct}%` },
    { 
      header: t('common.amount'), 
      cell: (row) => `${row.currency} ${row.commission_amount?.toLocaleString()}`
    },
    { header: t('common.status'), cell: (row) => <StatusBadge status={row.status} /> },
    { header: t('policyDetail.origin'), cell: (row) => <span className="capitalize">{row.source_type}</span> }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  if (!policy) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">{t('policyDetail.notFound')}</p>
      </div>
    );
  }

  const paidPayments = payments.filter(p => p.status === 'pagado').length;
  const totalPayments = payments.length;
  const totalCommissions = commissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);

  // Check if policy expires soon (within 30 days)
  const today = new Date();
  const daysUntilExpiry = policy?.end_date ? differenceInDays(new Date(policy.end_date), today) : null;
  const canRenew = policy?.status === 'activa' && daysUntilExpiry !== null && daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  
  // Check if renewal already exists
  const hasRenewal = renewals.some(r => r.original_policy_id === policy?.id && r.status !== 'rechazada');

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title={
            <div className="flex items-center gap-3 flex-wrap">
              <span>{t('policies.title')} {policy.policy_number}</span>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                policy.policy_category === 'CORPORATIVA' 
                  ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400' 
                  : 'bg-muted text-foreground'
              }`}>
                {policy.policy_category === 'CORPORATIVA' ? 'CORPORATIVA' : 'INDIVIDUAL'}
              </span>
              <PolicyTagBadges tags={policy.tags} />
            </div>
          }
          subtitle={`${policy.product_name} · ${policy.company_name}`}
          icon={FileText}
          backTo="Policies"
          actions={
            user?.app_role !== 'agente' ? (
              <div className="flex gap-2">
                <Button variant="outline" className="gap-2" onClick={() => setEndorsementFormOpen(true)}>
                  <FileEdit className="h-4 w-4" /> {t('endorsements.title')}
                </Button>
                {!hasRenewal && policy?.status !== 'renovada' && policy?.status !== 'cancelada' && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button className="gap-2 bg-primary hover:bg-primary/90">
                        <RefreshCw className="h-4 w-4" /> {t('renewals.title')} <ChevronDown className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openRenewalForm('propuesta')}>
                        {t('policyDetail.createRenewalProposal')}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openRenewalForm('directa')}>
                        {t('policyDetail.renewDirectly')}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            ) : null
          }
        />

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {policy.policy_category === 'INDIVIDUAL' && (
            <>
              <Card className="border-0 shadow-sm p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <DollarSign className="h-5 w-5 text-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{t('policies.annualPremium')}</p>
                    <p className="text-lg font-bold">{policy.currency} {policy.annual_premium?.toLocaleString()}</p>
                    {policy.currency === 'COP' && (
                      <p className="text-xs text-muted-foreground/70 mt-0.5">
                        {trmMap.has(policy.issue_date)
                          ? <>TRM: {trmMap.get(policy.issue_date).toLocaleString()} · USD {convertToUSD(policy.annual_premium, policy.currency, policy.issue_date, trmMap).toLocaleString(undefined, { maximumFractionDigits: 2 })}</>
                          : 'TRM no disponible'}
                      </p>
                    )}
                  </div>
                </div>
              </Card>
              <Card className="border-0 shadow-sm p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-500/10">
                    <Calendar className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{t('nav.payments')}</p>
                    <p className="text-lg font-bold">{paidPayments} / {totalPayments}</p>
                  </div>
                </div>
              </Card>
            </>
          )}
          {policy.policy_category === 'CORPORATIVA' && (
            <>
              <Card className="border-0 shadow-sm p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-purple-500/10">
                    <Building2 className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{t('policyDetail.contractor')}</p>
                    <p className="text-sm font-bold">{policy.contractor_name}</p>
                  </div>
                </div>
              </Card>
              <Card className="border-0 shadow-sm p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-purple-500/10">
                    <Users className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{t('policyDetail.billing')}</p>
                    <p className="text-sm font-bold">{t('policies.byMembers')}</p>
                  </div>
                </div>
              </Card>
            </>
          )}
          <Card className="border-0 shadow-sm p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <TrendingUp className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('commissions.title')}</p>
                <p className="text-lg font-bold">{policy.currency} {totalCommissions.toLocaleString()}</p>
              </div>
            </div>
          </Card>
          <Card className="border-0 shadow-sm p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <Shield className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t('claims.title')}</p>
                <p className="text-lg font-bold">{claims.length}</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Info Card */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center justify-between">
                {t('common.details')}
                <StatusBadge status={policy.status} />
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {policy.policy_category === 'CORPORATIVA' ? (
                <div className="flex items-center gap-3">
                  <Building2 className="h-4 w-4 text-muted-foreground/70" />
                  <div>
                    <p className="text-xs text-muted-foreground">{t('policyDetail.contractor')}</p>
                    {user?.app_role === 'agente' ? (
                      <button
                        onClick={() => { setSelectedClientId(policy.contractor_id); setClientModalOpen(true); }}
                        className="text-foreground hover:underline text-sm text-left"
                      >
                        {policy.contractor_name}
                      </button>
                    ) : (
                      <Link to={createPageUrl(`ClientDetail?id=${policy.contractor_id}`)} className="text-foreground hover:underline">
                        {policy.contractor_name}
                      </Link>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-muted-foreground/70" />
                  <div>
                    <p className="text-xs text-muted-foreground">{t('policies.client')}</p>
                    {user?.app_role === 'agente' ? (
                      <button
                        onClick={() => { setSelectedClientId(policy.client_id); setClientModalOpen(true); }}
                        className="text-foreground hover:underline text-sm text-left"
                      >
                        {policy.client_name}
                      </button>
                    ) : (
                      <Link to={createPageUrl(`ClientDetail?id=${policy.client_id}`)} className="text-foreground hover:underline">
                        {policy.client_name}
                      </Link>
                    )}
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3">
                <Building2 className="h-4 w-4 text-muted-foreground/70" />
                <div>
                  <p className="text-xs text-muted-foreground">{t('policies.company')} / {t('policies.line')}</p>
                  <p className="text-sm">{policy.company_name} · {policy.line_name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Briefcase className="h-4 w-4 text-muted-foreground/70" />
                <div>
                  <p className="text-xs text-muted-foreground">{t('policies.agent')}</p>
                  <AgentInfoPopover agentId={policy.agent_id} agentName={policy.agent_name} />
                </div>
              </div>
              <div className="flex items-center gap-3">
                <FileText className="h-4 w-4 text-muted-foreground/70" />
                <div>
                  <p className="text-xs text-muted-foreground">{t('policies.policyType')}</p>
                  <p className="text-sm capitalize">{policy.policy_type?.replace(/_/g, ' ')}</p>
                </div>
              </div>
              {policy.country && (
                <div className="flex items-center gap-3">
                  <Building2 className="h-4 w-4 text-muted-foreground/70" />
                  <div>
                    <p className="text-xs text-muted-foreground">País</p>
                    <p className="text-sm">{policy.country}</p>
                  </div>
                </div>
              )}
              {policy.issue_date && (
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-muted-foreground/70" />
                  <div>
                    <p className="text-xs text-muted-foreground">{t('policies.issueDate')}</p>
                    <p className="text-sm font-medium">
                      {formatDate(policy.issue_date, 'dd/MM/yyyy', { locale: es })}
                    </p>
                    <p className="text-xs text-muted-foreground">
                        {t('policyDetail.year')} {formatDate(policy.issue_date, 'yyyy')}
                      </p>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground/70" />
                <div>
                  <p className="text-xs text-muted-foreground">{t('policyDetail.currentValidity')}</p>
                  <p className="text-sm">
                    {policy.start_date ? formatDate(policy.start_date, 'dd/MM/yyyy', { locale: dateLocale }) : '-'} - {' '}
                    {policy.end_date ? formatDate(policy.end_date, 'dd/MM/yyyy', { locale: dateLocale }) : '-'}
                  </p>
                  {policy.policy_type === 'renovacion' && policy.issue_date && policy.start_date && (() => {
                    const issueDate = new Date(policy.issue_date + 'T00:00:00');
                    const currentStartDate = new Date(policy.start_date + 'T00:00:00');
                    
                    // Calcular vigencias completas transcurridas
                    let vigenciasCompletas = 0;
                    let tempDate = new Date(issueDate);
                    
                    while (tempDate < currentStartDate) {
                      tempDate.setFullYear(tempDate.getFullYear() + 1);
                      if (tempDate <= currentStartDate) {
                        vigenciasCompletas++;
                      }
                    }
                    
                    const renovacionActual = vigenciasCompletas + 1;
                    
                    return (
                      <div className="mt-2 p-2 bg-purple-500/10 rounded border border-purple-500/30">
                        <p className="text-xs text-purple-600 dark:text-purple-400">
                          <span className="font-semibold">{t('policyDetail.seniority')}:</span> {vigenciasCompletas} {vigenciasCompletas === 1 ? t('policyDetail.fullYear') : t('policyDetail.fullYears')}
                        </p>
                        <p className="text-xs text-purple-600 dark:text-purple-400">
                          <span className="font-semibold">{t('policyDetail.currentRenewal')}:</span> {renovacionActual}ª
                        </p>
                      </div>
                    );
                  })()}
                </div>
              </div>
              {policy.policy_category === 'INDIVIDUAL' && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-1">{t('policies.paymentFrequency')}</p>
                  <p className="text-sm capitalize">{policy.payment_frequency}</p>
                  <p className="text-xs text-muted-foreground mt-2 mb-1">{t('policyDetail.installmentValue')}</p>
                  <p className="text-sm font-medium">{policy.currency} {policy.installment_amount?.toLocaleString()}</p>
                </div>
              )}
              {policy.policy_category === 'CORPORATIVA' && (
                <div className="pt-2 border-t">
                  <div className="p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                    <p className="text-sm text-purple-600 dark:text-purple-400 font-semibold mb-2">📋 {t('policyDetail.corporatePolicy')}</p>
                    <p className="text-xs text-purple-600 dark:text-purple-400">
                      • {t('policyDetail.monthlyBilling')}<br/>
                      • {t('policyDetail.configureRates')}<br/>
                      • {t('policyDetail.invoiceManagement')}
                    </p>

                  </div>
                </div>
              )}
              {policy.line_name?.toLowerCase().includes('salud') && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-1">{t('policies.insuredAmount')}</p>
                  {policy.insured_amount && policy.insured_amount > 0 ? (
                    <p className="text-sm font-medium">{policy.currency} {policy.insured_amount?.toLocaleString()}</p>
                  ) : (
                    <p className="text-sm font-bold text-foreground">{t('policyDetail.unlimited')}</p>
                  )}
                  {policy.deductible_1 && (
                    <>
                      <p className="text-xs text-muted-foreground mt-2 mb-1">{t('policyDetail.deductible1')}</p>
                      <p className="text-sm">{policy.currency} {policy.deductible_1?.toLocaleString()}</p>
                    </>
                  )}
                  {policy.deductible_2 && (
                    <>
                      <p className="text-xs text-muted-foreground mt-2 mb-1">{t('policyDetail.deductible2')}</p>
                      <p className="text-sm">{policy.currency} {policy.deductible_2?.toLocaleString()}</p>
                    </>
                  )}
                </div>
              )}
              {policy.line_name?.toLowerCase().includes('vida') && policy.sum_insured && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-1">{t('policies.sumInsured')}</p>
                  <p className="text-sm font-bold text-purple-600 dark:text-purple-400">{policy.currency} {policy.sum_insured?.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">{t('policyDetail.valueForDependents')}</p>
                </div>
              )}
              {policy.line_name &&
                !policy.line_name.toLowerCase().includes('salud') &&
                !policy.line_name.toLowerCase().includes('vida') &&
                !policy.line_name.toLowerCase().includes('auto') &&
                !policy.line_name.toLowerCase().includes('hogar') &&
                policy.sum_insured && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-1">{t('policies.sumInsured')}</p>
                  <p className="text-sm font-bold text-foreground/80">{policy.currency} {policy.sum_insured?.toLocaleString()}</p>
                </div>
              )}
              {policy.line_name?.toLowerCase().includes('auto') && policy.vehicle_data && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-3">{t('policies.vehicleData')}</p>
                  <div className="space-y-2 bg-orange-500/10 p-3 rounded-lg border border-orange-500/30">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-xs text-orange-600 dark:text-orange-400">{t('policyDetail.brand')}</p>
                        <p className="font-medium">{policy.vehicle_data.brand}</p>
                      </div>
                      <div>
                        <p className="text-xs text-orange-600 dark:text-orange-400">{t('policyDetail.model')}</p>
                        <p className="font-medium">{policy.vehicle_data.model}</p>
                      </div>
                      <div>
                        <p className="text-xs text-orange-600 dark:text-orange-400">{t('policyDetail.year')}</p>
                        <p className="font-medium">{policy.vehicle_data.year}</p>
                      </div>
                      <div>
                        <p className="text-xs text-orange-600 dark:text-orange-400">{t('policyDetail.plate')}</p>
                        <p className="font-medium text-orange-600 dark:text-orange-400">{policy.vehicle_data.plate}</p>
                      </div>
                    </div>
                    <div className="pt-2 border-t border-orange-500/30 grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-xs text-orange-600 dark:text-orange-400">{t('policies.sumInsured')}</p>
                        <p className="font-bold text-orange-600 dark:text-orange-400">{policy.currency} {policy.sum_insured?.toLocaleString()}</p>
                      </div>
                      {policy.deductible_1 && (
                        <div>
                          <p className="text-xs text-orange-600 dark:text-orange-400">{t('policyDetail.deductible1')}</p>
                          <p className="font-medium">{policy.currency} {policy.deductible_1?.toLocaleString()}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
              {policy.notes && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground mb-1">{t('common.notes')}</p>
                  <p className="text-sm">{policy.notes}</p>
                </div>
              )}
              
              {/* Audit Trail */}
              <div className="pt-2 border-t">
                <AuditHistoryPopover entityType="Policy" entityId={policy.id}>
                  <button className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground/80 transition-colors w-full text-left p-2 hover:bg-muted/40 rounded">
                    <History className="h-3 w-3" />
                    <div className="flex-1">
                      {policy._was_modified ? (
                        <>
                          <p className="font-medium text-foreground/80">{t('policyDetail.lastEditedBy')}:</p>
                          <p className="text-muted-foreground">{policy._last_modified_by}</p>
                          <p className="text-muted-foreground/70 text-xs">
                           {policy._last_modified_date ? formatLocalDateTime(policy._last_modified_date) : ''}
                          </p>
                        </>
                      ) : (
                        <>
                          <p className="font-medium text-foreground/80">{t('policyDetail.createdBy')}:</p>
                          <p className="text-muted-foreground">{policy.created_by}</p>
                          <p className="text-muted-foreground/70 text-xs">
                           {policy.created_date ? formatLocalDateTime(policy.created_date) : ''}
                          </p>
                        </>
                      )}
                    </div>
                  </button>
                </AuditHistoryPopover>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="payments">
              <TabsList className="mb-4 grid grid-cols-3 lg:grid-cols-6">
                <TabsTrigger value="payments" className="gap-2">
                  <DollarSign className="h-4 w-4" /> <span className="hidden sm:inline">{t('nav.payments')}</span> ({payments.length})
                </TabsTrigger>
                <TabsTrigger value="claims" className="gap-2">
                  <Shield className="h-4 w-4" /> <span className="hidden sm:inline">{t('nav.claims')}</span> ({claims.length})
                </TabsTrigger>
                <TabsTrigger value="endorsements" className="gap-2">
                  <FileEdit className="h-4 w-4" /> <span className="hidden sm:inline">{t('endorsements.title')}</span> ({endorsements.length})
                </TabsTrigger>
                <TabsTrigger value="commissions" className="gap-2">
                  <TrendingUp className="h-4 w-4" /> <span className="hidden sm:inline">{t('nav.commissions')}</span> ({commissions.length})
                </TabsTrigger>
                <TabsTrigger value="dependents" className="gap-2">
                  {policy?.policy_category === 'CORPORATIVA' ? (
                    <>
                      <Users className="h-4 w-4" /> <span className="hidden sm:inline">{t('policyDetail.members')}</span> ({corporateMembers.length})
                    </>
                  ) : policy?.line_name?.toLowerCase().includes('hogar') ? (
                    <>
                      <Home className="h-4 w-4" /> <span className="hidden sm:inline">{t('policyDetail.property')}</span>
                    </>
                  ) : policy?.line_name?.toLowerCase().includes('auto') ? (
                    <>
                      <Car className="h-4 w-4" /> <span className="hidden sm:inline">{t('policyDetail.vehicle')}</span>
                    </>
                  ) : (
                    <>
                      <User className="h-4 w-4" /> <span className="hidden sm:inline">{t('policyDetail.dependents')}</span>
                    </>
                  )}
                </TabsTrigger>
                <TabsTrigger value="history" className="gap-2">
                  <History className="h-4 w-4" /> <span className="hidden sm:inline">{t('policyDetail.history')}</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="payments">
                <Card className="border-0 shadow-sm p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold">
                      {policy.policy_category === 'CORPORATIVA' ? t('policyDetail.monthlyInstallments') : t('policyDetail.paymentPlan')}
                    </h3>
                    {policy.policy_category === 'INDIVIDUAL' && user?.app_role !== 'agente' && (
                      <Button size="sm" className="gap-2" onClick={() => setPaymentFormOpen(true)}>
                        <Plus className="h-4 w-4" /> {t('policyDetail.addPayment')}
                      </Button>
                    )}
                  </div>
                  <DataTable
                    columns={paymentColumns}
                    data={payments.filter(p => !p.payment_group || p.payment_group === 'base')}
                    searchable={false}
                    pageSize={12}
                    emptyMessage={t('policyDetail.noPayments')}
                  />

                  {/* Endorsement installments grouped by endorsement */}
                  {(() => {
                    const endorsementPayments = payments.filter(p => p.payment_group === 'endorsement');
                    if (endorsementPayments.length === 0) return null;

                    // Group by endorsement_id
                    const groups = {};
                    for (const p of endorsementPayments) {
                      const key = p.endorsement_id || 'sin_endoso';
                      if (!groups[key]) groups[key] = { number: p.endorsement_number || 'Endoso', items: [] };
                      groups[key].items.push(p);
                    }

                    return Object.entries(groups).map(([key, group]) => (
                      <div key={key} className="mt-6 border-t pt-4">
                        <div className="flex items-center gap-2 mb-3">
                          <FileEdit className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                          <h4 className="font-semibold text-amber-600 dark:text-amber-400">{t('policyDetail.endorsementInstallments')}: {group.number}</h4>
                          <span className="text-xs text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                            {group.items.filter(p => p.status !== 'pagado').length} {t('payments.pending')}
                          </span>
                        </div>
                        <DataTable
                          columns={paymentColumns}
                          data={group.items}
                          searchable={false}
                          pageSize={12}
                          emptyMessage=""
                        />
                      </div>
                    ));
                  })()}
                </Card>
              </TabsContent>

              <TabsContent value="claims">
                <Card className="border-0 shadow-sm p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold">{t('claims.title')}</h3>
                    {user?.app_role !== 'agente' && (
                      <Button size="sm" className="gap-2" onClick={() => setClaimFormOpen(true)}>
                        <Plus className="h-4 w-4" /> {t('claims.new')}
                      </Button>
                    )}
                  </div>
                  <DataTable
                    columns={claimColumns}
                    data={claims}
                    searchable={false}
                    pageSize={5}
                    emptyMessage={t('policyDetail.noClaims')}
                  />
                </Card>
              </TabsContent>

              <TabsContent value="endorsements">
                <Card className="border-0 shadow-sm p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold">{t('endorsements.title')}</h3>
                  </div>
                  <DataTable
                    columns={[
                      { header: t('endorsements.number'), accessorKey: 'endorsement_number' },
                      { 
                        header: t('common.type'), 
                        cell: (row) => <span className="capitalize text-sm">{row.endorsement_type?.replace(/_/g, ' ')}</span>
                      },
                      { 
                        header: t('common.date'), 
                        cell: (row) => formatDate(row.endorsement_date, 'dd/MM/yyyy')
                      },
                      { 
                        header: t('policyDetail.premiumDiff'), 
                        cell: (row) => row.premium_difference ? (
                          <span className={row.premium_difference > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                            {row.premium_difference > 0 ? '+' : ''}{row.premium_difference.toLocaleString()}
                          </span>
                        ) : '-'
                      },
                      { header: 'Estado', cell: (row) => <StatusBadge status={row.status} /> }
                    ]}
                    data={endorsements}
                    searchable={false}
                    pageSize={5}
                    emptyMessage={t('policyDetail.noEndorsements')}
                  />
                </Card>
              </TabsContent>

              <TabsContent value="commissions">
                <Card className="border-0 shadow-sm p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold">{t('policyDetail.generatedCommissions')}</h3>
                  </div>
                  <DataTable
                    columns={commissionColumns}
                    data={commissions}
                    searchable={false}
                    pageSize={10}
                    emptyMessage={t('policyDetail.noCommissions')}
                  />
                </Card>
              </TabsContent>

              <TabsContent value="dependents">
                <Card className="border-0 shadow-sm p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold flex items-center gap-2">
                      {policy.policy_category === 'CORPORATIVA' ? t('policyDetail.members') :
                       policy.line_name?.toLowerCase().includes('hogar') ? <><Home className="h-5 w-5" /> {t('policyDetail.property')}</> :
                       policy.line_name?.toLowerCase().includes('auto') ? <><Car className="h-5 w-5" /> {t('policyDetail.vehicle')}</> :
                       policy.line_name?.toLowerCase().includes('vida') ? t('policyDetail.beneficiaries') : t('policyDetail.dependents')}
                    </h3>
                    {policy.policy_category === 'CORPORATIVA' && user?.app_role !== 'agente' && (
                      <Button size="sm" className="gap-2" onClick={() => setMemberFormOpen(true)}>
                        <Plus className="h-4 w-4" /> {t('policyDetail.addMember')}
                      </Button>
                    )}
                  </div>
                  {policy.policy_category === 'CORPORATIVA' ? (
                    <div className="space-y-4">
                      {/* Corporate Rate Plan - Compact */}
                      {corporateRates.length > 0 && (
                        <div className="p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                          <p className="text-xs font-semibold text-purple-600 dark:text-purple-400 mb-2">📋 {t('policyDetail.currentRatePlan')}</p>
                          <div className="grid grid-cols-3 gap-3">
                            <div>
                              <p className="text-xs text-purple-600 dark:text-purple-400">{t('policyDetail.holderOnly')}</p>
                              <p className="text-sm font-bold text-purple-600 dark:text-purple-400">
                                {policy.currency} {corporateRates[0].rate_titular_solo?.toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-purple-600 dark:text-purple-400">{t('policyDetail.holderPlus1')}</p>
                              <p className="text-sm font-bold text-purple-600 dark:text-purple-400">
                                {policy.currency} {corporateRates[0].rate_titular_mas1?.toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-purple-600 dark:text-purple-400">Familia</p>
                              <p className="text-sm font-bold text-purple-600 dark:text-purple-400">
                                {policy.currency} {corporateRates[0].rate_familia?.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Members Summary - Compact */}
                      {corporateMembers.length > 0 ? (
                        <>
                          <div className="grid grid-cols-3 gap-3 mb-4">
                            <div className="p-2 bg-muted rounded-lg border border-border">
                              <p className="text-xs text-foreground">{t('policyDetail.holderOnly')}</p>
                              <p className="text-lg font-bold text-foreground">
                                {corporateMembers.filter(m => m.coverage_tier === 'TITULAR_SOLO' && m.status === 'activo').length}
                              </p>
                            </div>
                            <div className="p-2 bg-green-500/10 rounded-lg border border-green-500/30">
                              <p className="text-xs text-green-600 dark:text-green-400">{t('policyDetail.holderPlus1')}</p>
                              <p className="text-lg font-bold text-green-600 dark:text-green-400">
                                {corporateMembers.filter(m => m.coverage_tier === 'TITULAR_MAS1' && m.status === 'activo').length}
                              </p>
                            </div>
                            <div className="p-2 bg-purple-500/10 rounded-lg border border-purple-500/30">
                              <p className="text-xs text-purple-600 dark:text-purple-400">Familia</p>
                              <p className="text-lg font-bold text-purple-600 dark:text-purple-400">
                                {corporateMembers.filter(m => m.coverage_tier === 'FAMILIA' && m.status === 'activo').length}
                              </p>
                            </div>
                          </div>

                          {/* Search Bar */}
                          <div className="relative mb-3">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
                            <Input
                              placeholder={t('policyDetail.searchMember')}
                              value={memberSearch}
                              onChange={(e) => setMemberSearch(e.target.value)}
                              className="pl-10"
                            />
                          </div>
                          
                          <div className="space-y-2">
                            {corporateMembers
                              .filter(m => m.member_type === 'TITULAR')
                              .filter(m => {
                                if (!memberSearch) return true;
                                const search = memberSearch.toLowerCase();
                                return (
                                  m.first_name?.toLowerCase().includes(search) ||
                                  m.last_name?.toLowerCase().includes(search) ||
                                  m.document_id?.toLowerCase().includes(search)
                                );
                              })
                              .map(member => {
                              const memberDependents = corporateMembers.filter(m => m.parent_member_id === member.id);
                              const isExpanded = expandedMembers[member.id];
                              return (
                                <div key={member.id} className="border rounded-lg bg-card hover:shadow-sm transition-shadow">
                                  <div className="flex items-center justify-between p-2.5">
                                    <div className="flex items-center gap-2 flex-1 min-w-0">
                                      {memberDependents.length > 0 && (
                                        <button
                                          onClick={() => toggleMemberExpanded(member.id)}
                                          className="flex-shrink-0 text-muted-foreground/70 hover:text-muted-foreground"
                                        >
                                          {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                        </button>
                                      )}
                                      <div className="flex-1 min-w-0">
                                        <p className="font-medium text-sm truncate">{member.first_name} {member.last_name}</p>
                                        <p className="text-xs text-muted-foreground">{member.document_id}</p>
                                      </div>
                                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold flex-shrink-0 ${
                                        member.coverage_tier === 'TITULAR_SOLO' ? 'bg-muted text-foreground' :
                                        member.coverage_tier === 'TITULAR_MAS1' ? 'bg-green-500/10 text-green-600 dark:text-green-400' :
                                        'bg-purple-500/10 text-purple-600 dark:text-purple-400'
                                      }`}>
                                        {member.coverage_tier === 'TITULAR_SOLO' ? 'Solo' :
                                         member.coverage_tier === 'TITULAR_MAS1' ? '+1' : 'Fam'}
                                      </span>
                                    </div>
                                    <div className="flex gap-0.5 ml-2 flex-shrink-0">
                                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => viewMemberDetail(member)}>
                                        <Eye className="h-3 w-3" />
                                      </Button>
                                      {user?.app_role !== 'agente' && (
                                        <>
                                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => handleEditMember(member)}>
                                            <Pencil className="h-3 w-3" />
                                          </Button>
                                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => handleDeleteMember(member)}>
                                            <Trash2 className="h-3 w-3 text-red-500" />
                                          </Button>
                                        </>
                                      )}
                                    </div>
                                  </div>
                                  {isExpanded && memberDependents.length > 0 && (
                                    <div className="px-8 pb-2 border-t bg-muted/40">
                                      <p className="text-xs text-muted-foreground mb-1.5 mt-2">{t('policyDetail.dependents')} ({memberDependents.length}):</p>
                                      {memberDependents.map(dep => (
                                        <div key={dep.id} className="flex items-center justify-between text-xs py-1.5 hover:bg-card px-2 rounded">
                                          <div className="flex items-center gap-2 flex-1 min-w-0">
                                            <span className="text-muted-foreground truncate">{dep.first_name} {dep.last_name}</span>
                                            <span className="text-xs text-muted-foreground/70 flex-shrink-0">({dep.relationship})</span>
                                          </div>
                                          <div className="flex gap-0.5 ml-2 flex-shrink-0">
                                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => viewMemberDetail(dep)}>
                                              <Eye className="h-3 w-3" />
                                            </Button>
                                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => handleDeleteMember(dep)}>
                                              <Trash2 className="h-3 w-3 text-red-500" />
                                            </Button>
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </>
                      ) : (
                        <div className="text-center text-muted-foreground/70 py-12">
                          <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>{t('policyDetail.noMembers')}</p>
                          <p className="text-xs mt-2">{t('policyDetail.addMembersToStart')}</p>
                        </div>
                      )}
                    </div>
                  ) : policy.line_name?.toLowerCase().includes('hogar') && policy.property_data && policy.property_data.property_type ? (
                    <div className="p-6 bg-green-500/10 rounded-lg border border-green-500/30">
                      <div className="grid grid-cols-2 md:grid-cols-2 gap-6">
                        <div>
                          <p className="text-xs text-green-600 dark:text-green-400 mb-1">{t('policyDetail.propertyType')}</p>
                          <p className="font-semibold text-lg capitalize">{policy.property_data.property_type}</p>
                        </div>
                        <div>
                          <p className="text-xs text-green-600 dark:text-green-400 mb-1">{t('policyDetail.propertyValue')}</p>
                          <p className="font-semibold text-lg">{policy.currency} {policy.property_data.property_value?.toLocaleString()}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-xs text-green-600 dark:text-green-400 mb-1">{t('common.address')}</p>
                          <p className="font-semibold">{policy.property_data.address}</p>
                        </div>
                        {policy.property_data.protections && (
                          <div className="col-span-2">
                            <p className="text-xs text-green-600 dark:text-green-400 mb-1">{t('policyDetail.protections')}</p>
                            <p className="text-sm text-green-600 dark:text-green-400 whitespace-pre-wrap">{policy.property_data.protections}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ) : policy.line_name?.toLowerCase().includes('hogar') ? (
                    <div className="text-center text-muted-foreground/70 py-12">
                      <Home className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>{t('policyDetail.noPropertyData')}</p>
                    </div>
                  ) : policy.line_name?.toLowerCase().includes('auto') && policy.vehicle_data ? (
                    <div className="p-6 bg-orange-500/10 rounded-lg border border-orange-500/30">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                        <div>
                          <p className="text-xs text-orange-600 dark:text-orange-400 mb-1">{t('policyDetail.brand')}</p>
                          <p className="font-semibold text-lg">{policy.vehicle_data.brand}</p>
                        </div>
                        <div>
                          <p className="text-xs text-orange-600 dark:text-orange-400 mb-1">{t('policyDetail.model')}</p>
                          <p className="font-semibold text-lg">{policy.vehicle_data.model}</p>
                        </div>
                        <div>
                          <p className="text-xs text-orange-600 dark:text-orange-400 mb-1">{t('policyDetail.year')}</p>
                          <p className="font-semibold text-lg">{policy.vehicle_data.year}</p>
                        </div>
                        <div>
                          <p className="text-xs text-orange-600 dark:text-orange-400 mb-1">{t('policyDetail.plate')}</p>
                          <p className="font-semibold text-2xl text-orange-600 dark:text-orange-400">{policy.vehicle_data.plate}</p>
                        </div>
                      </div>
                    </div>
                  ) : policy.dependents && policy.dependents.length > 0 ? (
                    <div className="space-y-3">
                      {policy.dependents.map((dep, idx) => (
                        <div key={idx} className="p-4 border rounded-lg bg-muted/40">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <div>
                              <p className="text-xs text-muted-foreground">{t('common.name')}</p>
                              <p className="font-medium">{dep.name}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">{t('policyDetail.relationship')}</p>
                              <p className="capitalize">{dep.relationship}</p>
                            </div>
                            {dep.document_id && (
                              <div>
                                <p className="text-xs text-muted-foreground">{t('clients.documentId')}</p>
                                <p>{dep.document_id}</p>
                              </div>
                            )}
                            {policy.line_name?.toLowerCase().includes('vida') ? (
                              <>
                                <div>
                                  <p className="text-xs text-muted-foreground">{t('common.type')}</p>
                                  <StatusBadge status={dep.beneficiary_type === 'principal' ? 'activa' : 'inactiva'} />
                                  <p className="text-xs">{dep.beneficiary_type === 'principal' ? t('policyDetail.primary') : t('policyDetail.contingent')}</p>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground">{t('policyDetail.benefitPct')}</p>
                                  <p className="font-semibold text-purple-600 dark:text-purple-400">{dep.percentage}%</p>
                                </div>
                              </>
                            ) : (
                              dep.birth_date && (
                                <div>
                                  <p className="text-xs text-muted-foreground">{t('agents.birthDate')}</p>
                                  <p>{formatDate(dep.birth_date, 'dd/MM/yyyy')}</p>
                                </div>
                              )
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground/70 py-12">
                      <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>{t('policyDetail.noDependents', { type: policy.line_name?.toLowerCase().includes('vida') ? t('policyDetail.beneficiaries') : t('policyDetail.dependents') })}</p>
                    </div>
                  )}
                </Card>
              </TabsContent>

              <TabsContent value="history">
                <Card className="border-0 shadow-sm p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold">{t('policyDetail.changeHistory')}</h3>
                  </div>
                  {auditLogs.length > 0 ? (
                    <div className="space-y-3">
                      {auditLogs.map((log, idx) => (
                        <div key={idx} className="p-4 border rounded-lg bg-muted/40">
                          <div className="flex items-start gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <StatusBadge status={log.action === 'CREATE' ? 'activa' : log.action === 'UPDATE' ? 'vencida' : 'cancelada'} />
                                <span className="text-xs font-medium">
                                  {log.action === 'CREATE' ? t('policyDetail.creation') : log.action === 'UPDATE' ? t('policyDetail.modification') : t('policyDetail.deletion')}
                                </span>
                                <span className="text-xs text-muted-foreground">
                                  {formatLocalDateTime(log.created_date)}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground">
                                <span className="font-medium">{log.user_email}</span>
                                {log.details && ` - ${log.details}`}
                              </p>
                              {log.changes && Object.keys(log.changes).length > 0 && (
                                <div className="mt-2 text-xs bg-card rounded p-3 border">
                                  <p className="font-medium mb-2 text-foreground/80">{t('policyDetail.changesMade')}:</p>
                                  <div className="space-y-1">
                                    {Object.entries(log.changes).map(([field, change]) => (
                                      <div key={field} className="pl-2">
                                        <span className="text-muted-foreground font-medium">{field}:</span>{' '}
                                        <span className="text-red-600 dark:text-red-400">{String(change.old || 'N/A')}</span>
                                        {' → '}
                                        <span className="text-green-600 dark:text-green-400">{String(change.new || 'N/A')}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-muted-foreground/70 py-12">
                      <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>{t('policyDetail.noHistory')}</p>
                    </div>
                  )}
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Documents Section */}
        <DocumentList 
          entityType="Policy" 
          entityId={policy.id} 
          entityReference={policy.policy_number}
          currentUser={user}
        />

        <PaymentForm
          open={paymentFormOpen}
          onOpenChange={setPaymentFormOpen}
          onSubmit={handlePaymentSubmit}
          isLoading={saving}
          policyInfo={policy}
        />

        <ClaimForm
          open={claimFormOpen}
          onOpenChange={setClaimFormOpen}
          onSubmit={handleClaimSubmit}
          isLoading={saving}
          policyInfo={policy}
        />

        <EndorsementForm
          open={endorsementFormOpen}
          onOpenChange={setEndorsementFormOpen}
          onSubmit={handleEndorsementSubmit}
          isLoading={saving}
          policyInfo={policy}
        />

        <CorporateMemberForm
          open={memberFormOpen}
          onOpenChange={(open) => {
            setMemberFormOpen(open);
            if (!open) setEditingMember(null);
          }}
          onSubmit={handleMemberSubmit}
          initialData={editingMember}
          isLoading={saving}
          policyInfo={policy}
        />

        {/* Member Detail Dialog */}
        <Dialog open={memberDetailOpen} onOpenChange={setMemberDetailOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{t('policyDetail.memberDetail')}</DialogTitle>
            </DialogHeader>
            
            {selectedMemberDetail && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('common.type')}</Label>
                    <p className="font-medium">{selectedMemberDetail.member_type}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('common.status')}</Label>
                    <StatusBadge status={selectedMemberDetail.status} />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('clients.firstName')}</Label>
                    <p className="font-medium">{selectedMemberDetail.first_name}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('clients.lastName')}</Label>
                    <p className="font-medium">{selectedMemberDetail.last_name}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('clients.documentType')}</Label>
                    <p className="font-medium capitalize">{selectedMemberDetail.document_type}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('clients.documentId')}</Label>
                    <p className="font-medium">{selectedMemberDetail.document_id}</p>
                  </div>
                </div>
                
                {selectedMemberDetail.birth_date && (
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('agents.birthDate')}</Label>
                    <p className="font-medium">{formatDate(selectedMemberDetail.birth_date, 'dd/MM/yyyy')}</p>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-4">
                  {selectedMemberDetail.email && (
                    <div>
                      <Label className="text-xs text-muted-foreground">{t('common.email')}</Label>
                      <p className="font-medium">{selectedMemberDetail.email}</p>
                    </div>
                  )}
                  {selectedMemberDetail.phone && (
                    <div>
                      <Label className="text-xs text-muted-foreground">{t('common.phone')}</Label>
                      <p className="font-medium">{selectedMemberDetail.phone}</p>
                    </div>
                  )}
                </div>
                
                {selectedMemberDetail.member_type === 'TITULAR' && (
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('policyDetail.coverage')}</Label>
                    <p className="font-medium">{selectedMemberDetail.coverage_tier === 'TITULAR_SOLO' ? t('policyDetail.holderOnly') :
                     selectedMemberDetail.coverage_tier === 'TITULAR_MAS1' ? t('policyDetail.holderPlus1') : t('policyDetail.family')}</p>
                  </div>
                )}
                
                {selectedMemberDetail.member_type === 'DEPENDIENTE' && (
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('policyDetail.relationship')}</Label>
                    <p className="font-medium capitalize">{selectedMemberDetail.relationship}</p>
                  </div>
                )}
                
                {selectedMemberDetail.notes && (
                  <div>
                    <Label className="text-xs text-muted-foreground">{t('common.notes')}</Label>
                    <p className="text-sm">{selectedMemberDetail.notes}</p>
                  </div>
                )}
                
                <div className="flex justify-end gap-3 pt-4 border-t">
                  <Button variant="outline" onClick={() => setMemberDetailOpen(false)}>
                    {t('common.close')}
                  </Button>
                  {user?.app_role !== 'agente' && (
                    <Button onClick={() => {
                      setMemberDetailOpen(false);
                      handleEditMember(selectedMemberDetail);
                    }}>
                      {t('common.edit')}
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Manual Commission Dialog */}
        <Dialog open={manualCommissionOpen} onOpenChange={setManualCommissionOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{t('policyDetail.manualCommissionSettlement')}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="p-4 bg-amber-500/10 rounded-lg border border-amber-500/30">
                <p className="text-sm text-amber-600 dark:text-amber-400">
                  <strong>⚠️ {t('policyDetail.manualSettlement')}:</strong> {t('policyDetail.noCommissionTable')}
                </p>
              </div>
              
              {pendingPayment && (
                <div className="p-4 bg-muted/40 rounded-lg">
                  <p className="text-sm text-muted-foreground">{t('policyDetail.paymentToSettle')}</p>
                  <p className="font-semibold">{t('policyDetail.installmentNum')} #{pendingPayment.installment_number}</p>
                  <p className="text-sm">{t('common.amount')}: {policy.currency} {pendingPayment.amount?.toLocaleString()}</p>
                </div>
              )}
              
              <div className="space-y-3">
                <Label className="text-base">{t('policyDetail.agentsAndPercentages')}</Label>
                {agentsForManualCommission.map((agent, index) => (
                  <div key={agent.id} className="grid grid-cols-3 gap-4 p-3 bg-muted/40 rounded-lg">
                    <div className="col-span-2">
                      <Label className="text-xs text-muted-foreground">{t('commissions.level')} {agent.level}</Label>
                      <p className="font-medium">{agent.name}</p>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">% {t('commissions.title')}</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        value={agent.percentage}
                        onChange={(e) => updateAgentPercentage(index, e.target.value)}
                        placeholder="0.00"
                      />
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="p-3 bg-muted rounded-lg border border-border">
                <p className="text-sm text-foreground">
                  {t('policyDetail.totalCommissions')}: <span className="font-bold">
                    {agentsForManualCommission.reduce((sum, a) => sum + a.percentage, 0).toFixed(2)}%
                  </span>
                </p>
              </div>
              
              <div className="flex justify-end gap-3 pt-4">
                <Button variant="outline" onClick={() => {
                  setManualCommissionOpen(false);
                  setPendingPayment(null);
                  setAgentsForManualCommission([]);
                }}>
                  {t('common.cancel')}
                </Button>
                <Button onClick={handleManualCommissionSubmit} disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {t('policyDetail.settleAndMarkPaid')}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <RenewalFormDialog
          open={renewalFormOpen}
          onOpenChange={setRenewalFormOpen}
          policy={policy}
          form={renewalForm}
          onFormChange={setRenewalForm}
          onCreateProposal={handleCreateRenewal}
          onRenewDirect={handleDirectRenewal}
          saving={saving}
        />

        {/* Client Quick View Modal - solo para rol agente */}
        <ClientQuickViewModal
          clientId={selectedClientId}
          open={clientModalOpen}
          onOpenChange={(val) => { setClientModalOpen(val); if (!val) setSelectedClientId(null); }}
        />
      </div>
    </div>
  );
}