import React, { useState, useEffect, useRef, useMemo } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MobileSelect } from "@/components/ui/MobileSelect";
import {
  SelectItem,
} from "@/components/ui/select";
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import PolicyForm from '@/components/forms/PolicyForm';
import PullToRefresh from '@/components/ui/PullToRefresh';
import { useSearchCache } from '@/components/SearchCache';
import { FileText, Plus, Eye, Pencil, Trash2, Loader2, X, ChevronDown } from 'lucide-react';
import { Label } from "@/components/ui/label";
import { format } from 'date-fns';
import { exportToCSV, exportToExcel } from '@/components/ui/exportUtils';
import DeleteSafetyDialog from '@/components/ui/DeleteSafetyDialog';
import PolicyTagBadges from '@/components/policy/PolicyTagBadges';
import PolicyTagFilter from '@/components/policy/PolicyTagFilter';
import { useTranslation } from 'react-i18next';
import { toast } from "sonner";
import '@/components/i18n';

export default function Policies() {
  const { t } = useTranslation();
  const { searchQuery, updateSearch, clearSearch } = useSearchCache('policies');
  const { user: authUser, isLoadingAuth } = useAuth();
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingPolicy, setEditingPolicy] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [policyToDelete, setPolicyToDelete] = useState(null);
  const currentUser = authUser;
  
  // Filters
  const [statusFilter, setStatusFilter] = useState('all');
  const [lineFilter, setLineFilter] = useState('all');
  const [agentFilter, setAgentFilter] = useState('all');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [policyTypeFilter, setPolicyTypeFilter] = useState('all');
  const [tagFilterInclude, setTagFilterInclude] = useState([]);
  const [tagFilterExclude, setTagFilterExclude] = useState([]);
  const [lines, setLines] = useState([]);
  const [agents, setAgents] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [allowedAgentIds, setAllowedAgentIds] = useState(null);

  // Agent dropdown with search
  const [agentSearch, setAgentSearch] = useState('');
  const [agentDropdownOpen, setAgentDropdownOpen] = useState(false);
  const agentDropdownRef = useRef(null);

  // Company dropdown with search
  const [companySearch, setCompanySearch] = useState('');
  const [companyDropdownOpen, setCompanyDropdownOpen] = useState(false);
  const companyDropdownRef = useRef(null);

  useEffect(() => {
    if (!isLoadingAuth && authUser) {
      loadData();
    }
  }, [isLoadingAuth, authUser]);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClick = (e) => {
      if (agentDropdownRef.current && !agentDropdownRef.current.contains(e.target)) setAgentDropdownOpen(false);
      if (companyDropdownRef.current && !companyDropdownRef.current.contains(e.target)) setCompanyDropdownOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const loadData = async () => {
    if (!authUser) return;
    setLoading(true);

    // Branch A: policies (depends on role); Branch B: filter lists (independent) — run in parallel
    const isAgentOrGerencial = (authUser.app_role === 'agente' || authUser.app_role === 'gerencial') && authUser.agent_id && authUser.app_role !== 'financiero';

    let structureAgentIds = null;
    const policiesPromise = isAgentOrGerencial
      ? api.functions.invoke('getAgentHierarchy', { agentId: authUser.agent_id, includePolicies: true })
          .then(resp => {
            structureAgentIds = resp?.data?.agentIds || [authUser.agent_id];
            return resp?.data?.policies || [];
          })
      : api.functions.invoke('getAllPolicies')
          .then(resp => resp?.data?.policies || []);

    const [policiesData, linesData, agentsData, companiesData] = await Promise.all([
      policiesPromise,
      api.entities.InsuranceLine.list(),
      api.entities.Agent.list('name', 1000),
      api.entities.InsuranceCompany.list('name', 1000),
    ]);

    setPolicies(policiesData);
    setLines(linesData);
    setAgents(agentsData);
    setCompanies(companiesData);
    setAllowedAgentIds(structureAgentIds);
    setLoading(false);
  };

  const handleSubmit = async (data) => {
    setSaving(true);
    try {
      let createdPolicy = null;
      if (editingPolicy) {
        const user = await api.auth.me();
        
        // Detect changes in payment frequency or premium
        const freqChanged = data.payment_frequency !== editingPolicy.payment_frequency;
        const premiumChanged = parseFloat(data.annual_premium) !== parseFloat(editingPolicy.annual_premium || 0);
        const monthsChanged = parseInt(data.installment_months || 12) !== parseInt(editingPolicy.installment_months || 12);
        const needsRecalculate = (freqChanged || premiumChanged || monthsChanged) && data.policy_category !== 'CORPORATIVA';

        // Update policy first
        await api.entities.Policy.update(editingPolicy.id, { ...data, updated_by: user?.email });
        createdPolicy = editingPolicy;

        // Recalculate payments if frequency, premium or installment months changed
        if (needsRecalculate) {
          const result = await api.functions.invoke('recalculatePolicyPayments', {
            policyId: editingPolicy.id,
            paymentFrequency: data.payment_frequency,
            annualPremium: parseFloat(data.annual_premium),
            installmentMonths: parseInt(data.installment_months || 12),
            installmentAmount: parseFloat(data.installment_amount || 0),
            startDate: data.start_date,
            currency: data.currency,
            clientName: data.client_name,
            policyNumber: data.policy_number,
            policyCategory: data.policy_category || 'INDIVIDUAL',
            contractorName: data.contractor_name
          });
          
          if (result?.data?.success) {
            toast.success(result.data.message || 'Cuotas recalculadas exitosamente');
          } else if (result?.data?.blocked) {
            toast.error(result.data.error);
          }
        }
      } else {
        // Create policy via centralized backend function (validates company + number uniqueness)
        const createResp = await api.functions.invoke('createPolicy', { policyData: data });
        if (createResp?.data?.duplicate) {
          const ex = createResp.data.existing;
          toast.error(`Póliza duplicada: ya existe "${ex.policy_number}" para ${ex.company_name} — cliente ${ex.client_name || ex.contractor_name || 'N/A'}, estado ${ex.status}, creada el ${(ex.created_date || '').split('T')[0]}.`);
          return null;
        }
        if (!createResp?.data?.success) {
          throw new Error(createResp?.data?.error || 'Error al crear póliza');
        }
        createdPolicy = createResp.data.policy;

        // Generate payment schedule (works for both INDIVIDUAL and CORPORATIVA)
        await generatePaymentSchedule(createdPolicy, data);
      }
      setFormOpen(false);
      setEditingPolicy(null);
      loadData();
      return createdPolicy;
    } catch (error) {
      console.error('Error saving policy:', error);
      throw error;
    } finally {
      setSaving(false);
    }
  };

  const generatePaymentSchedule = async (policy, data) => {
    // For corporate policies, generate 12 monthly payments with amount 0
    if (data.policy_category === 'CORPORATIVA') {
      const startDate = new Date(data.start_date + 'T00:00:00');
      const payments = [];
      
      for (let i = 0; i < 12; i++) {
        const dueDate = new Date(startDate.getFullYear(), startDate.getMonth() + i, startDate.getDate());
        
        payments.push({
          policy_id: policy.id,
          policy_number: data.policy_number,
          client_name: data.contractor_name,
          due_date: dueDate.toISOString().split('T')[0],
          period: format(dueDate, 'MMMM yyyy'),
          amount: 0,
          currency: data.currency,
          status: 'pendiente',
          installment_number: i + 1
        });
      }
      
      if (payments.length > 0) {
        await api.entities.Payment.bulkCreate(payments);
      }
      return;
    }
    
    const frequencies = {
      mensual: parseInt(data.installment_months) || 12,
      trimestral: 4,
      semestral: 2,
      anual: 1,
      unico: 1
    };
    
    const numPayments = frequencies[data.payment_frequency] || 1;
    const startDate = new Date(data.start_date + 'T00:00:00');
    const originalDay = startDate.getDate();
    const payments = [];
    
    for (let i = 0; i < numPayments; i++) {
      // Calcular el mes de destino desde el mes de inicio
      let targetMonth, targetYear;
      if (data.payment_frequency === 'mensual') {
        targetMonth = startDate.getMonth() + i;
      } else if (data.payment_frequency === 'trimestral') {
        targetMonth = startDate.getMonth() + (i * 3);
      } else if (data.payment_frequency === 'semestral') {
        targetMonth = startDate.getMonth() + (i * 6);
      } else {
        targetMonth = startDate.getMonth();
      }
      targetYear = startDate.getFullYear() + Math.floor(targetMonth / 12);
      targetMonth = targetMonth % 12;

      // Calcular el último día del mes destino
      const lastDayOfTargetMonth = new Date(targetYear, targetMonth + 1, 0).getDate();
      // Usar el día original o el último del mes si el original no existe (ej: 31 en febrero)
      const targetDay = Math.min(originalDay, lastDayOfTargetMonth);

      const dueDate = new Date(targetYear, targetMonth, targetDay);
      
      payments.push({
        policy_id: policy.id,
        policy_number: data.policy_number,
        client_name: data.client_name,
        due_date: dueDate.toISOString().split('T')[0],
        period: format(dueDate, 'MMMM yyyy'),
        amount: parseFloat(data.installment_amount),
        currency: data.currency,
        status: 'pendiente',
        installment_number: parseInt(i + 1)
      });
    }
    
    if (payments.length > 0) {
      await api.entities.Payment.bulkCreate(payments);
    }
  };

  const generateCommissionsForFirstPayment = async (policy, data) => {
    const agentData = await api.entities.Agent.filter({ id: data.agent_id });
    if (agentData.length === 0) return;
    
    let currentAgent = agentData[0];
    const commissions = [];
    let level = 1;
    let previousPct = 0;
    
    const baseAmount = data.commissionable_premium || data.annual_premium;
    const isRenewal = data.policy_type === 'renovacion';
    
    while (currentAgent) {
      const assignments = await api.entities.AgentCommissionAssignment.filter({
        agent_id: currentAgent.id,
        company_id: data.company_id,
        line_id: data.line_id
      });
      
      if (assignments.length > 0) {
        const assignment = assignments[0];
        const tables = await api.entities.CommissionTable.filter({ 
          id: assignment.commission_table_id 
        });
        
        if (tables.length > 0) {
          const table = tables[0];
          const productComm = table.product_commissions?.find(pc => pc.product_id === data.product_id);
          
          if (productComm) {
            const fullPct = isRenewal ? productComm.renewal_percentage : productComm.new_business_percentage;
            const effectivePct = level === 1 ? fullPct : Math.max(fullPct - previousPct, 0);
            
            if (effectivePct > 0) {
              const commissionAmount = (baseAmount * effectivePct) / 100;
              
              commissions.push({
                policy_id: policy.id,
                policy_number: data.policy_number,
                product_id: data.product_id,
                product_name: data.product_name,
                company_id: data.company_id,
                company_name: data.company_name,
                agent_id: currentAgent.id,
                agent_name: currentAgent.name,
                client_name: data.client_name,
                level: level,
                base_amount: baseAmount,
                commission_pct: effectivePct,
                commission_amount: commissionAmount,
                installment_number: 1,
                currency: data.currency,
                generation_date: new Date().toISOString().split('T')[0],
                status: 'pendiente_liberar',
                source_type: isRenewal ? 'renovacion' : 'nuevo_negocio'
              });
              
              previousPct = fullPct;
            }
          }
        }
      }
      
      if (currentAgent.upline_agent_id) {
        const uplineData = await api.entities.Agent.filter({ id: currentAgent.upline_agent_id });
        currentAgent = uplineData[0] || null;
        level++;
      } else {
        currentAgent = null;
      }
    }
    
    if (commissions.length > 0) {
      await api.entities.Commission.bulkCreate(commissions);
    }
  };

  // This function is now called from Payments page when a payment is marked as paid
  const generateCommissionsForPayment = async (policy, data) => {
    // Get the selling agent
    const agentData = await api.entities.Agent.filter({ id: data.agent_id });
    if (agentData.length === 0) return;
    
    let currentAgent = agentData[0];
    const commissions = [];
    let level = 1;
    let previousPct = 0;  // Track previous level percentage for differential (override)
    
    // Use commissionable premium for calculations
    const baseAmount = data.commissionable_premium || data.annual_premium;
    
    // Walk up the hierarchy
    while (currentAgent) {
      // Get the commission assignment for this agent, company and line
      const assignments = await api.entities.AgentCommissionAssignment.filter({
        agent_id: currentAgent.id,
        company_id: data.company_id,
        line_id: data.line_id
      });
      
      if (assignments.length > 0) {
        const assignment = assignments[0];
        
        // Get the commission table
        const tables = await api.entities.CommissionTable.filter({ 
          id: assignment.commission_table_id 
        });
        
        if (tables.length > 0) {
          const table = tables[0];
          
          // Find the product commission in the table
          const productComm = table.product_commissions?.find(pc => pc.product_id === data.product_id);
          
          if (productComm) {
            // Determine if it's new business or renewal
            const isRenewal = data.policy_type === 'renovacion';
            const fullPct = isRenewal ? productComm.renewal_percentage : productComm.new_business_percentage;
            
            // LÓGICA DE DIFERENCIAL (OVERRIDE)
            // Si es el primer nivel (vendedor directo), recibe su porcentaje completo
            // Si es un upline, recibe solo el diferencial (su % - % nivel anterior)
            const effectivePct = level === 1 ? fullPct : Math.max(fullPct - previousPct, 0);
            
            if (effectivePct > 0) {
              const commissionAmount = (baseAmount * effectivePct) / 100;
              
              commissions.push({
                policy_id: policy.id,
                policy_number: data.policy_number,
                product_id: data.product_id,
                product_name: data.product_name,
                agent_id: currentAgent.id,
                agent_name: currentAgent.name,
                level: level,
                base_amount: baseAmount,
                commission_pct: effectivePct,  // Store effective percentage (differential)
                commission_amount: commissionAmount,
                currency: data.currency,
                generation_date: new Date().toISOString().split('T')[0],
                status: 'pendiente_liberar',
                source_type: isRenewal ? 'renovacion' : 'nuevo_negocio'
              });
              
              // Update previous percentage for next level
              previousPct = fullPct;
            }
          }
        }
      }
      
      // Move to upline
      if (currentAgent.upline_agent_id) {
        const uplineData = await api.entities.Agent.filter({ id: currentAgent.upline_agent_id });
        currentAgent = uplineData[0] || null;
        level++;
      } else {
        currentAgent = null;
      }
    }
    
    if (commissions.length > 0) {
      await api.entities.Commission.bulkCreate(commissions);
    }
  };

  const handleEdit = async (policy) => {
    const currentUser = await api.auth.me();
    const canEdit = currentUser?.role === 'admin' || 
                   currentUser?.app_role === 'admin' || 
                   currentUser?.app_role === 'operativo';
    
    if (!canEdit) {
      alert('No tienes permisos para editar pólizas');
      return;
    }
    
    setEditingPolicy(policy);
    setFormOpen(true);
  };

  const checkPolicyUsage = async () => {
    const [commissions, settlements, payments, claims, endorsements] = await Promise.all([
      api.entities.Commission.filter({ policy_id: policyToDelete.id }),
      api.entities.CommissionSettlement.list(),
      api.entities.Payment.filter({ policy_id: policyToDelete.id }),
      api.entities.Claim.filter({ policy_id: policyToDelete.id }),
      api.entities.Endorsement.filter({ policy_id: policyToDelete.id }),
    ]);

    const usageItems = [];

    const paidCommissions = commissions.filter(c => c.status === 'pagada');
    if (paidCommissions.length > 0) {
      usageItems.push({ label: t('policies.usage.paidCommissions'), count: paidCommissions.length, detail: t('policies.usage.paidCommissionsDetail') });
    }

    const relatedSettlements = settlements.filter(s =>
      s.commission_ids?.some(cId => commissions.find(c => c.id === cId))
    );
    if (relatedSettlements.length > 0) {
      usageItems.push({ label: t('policies.usage.settlements'), count: relatedSettlements.length, detail: t('policies.usage.settlementsDetail') });
    }

    const pendingPayments = payments.filter(p => p.status === 'pagado');
    if (pendingPayments.length > 0) {
      usageItems.push({ label: t('policies.usage.registeredPayments'), count: pendingPayments.length, detail: t('policies.usage.registeredPaymentsDetail') });
    }

    if (claims.length > 0) {
      usageItems.push({ label: t('policies.usage.claims'), count: claims.length, detail: t('policies.usage.claimsDetail') });
    }

    if (endorsements.length > 0) {
      usageItems.push({ label: t('policies.usage.endorsements'), count: endorsements.length, detail: t('policies.usage.endorsementsDetail') });
    }

    return { usageItems };
  };

  const handleDeletePolicy = async () => {
    const [commissions, payments, claims, endorsements] = await Promise.all([
      api.entities.Commission.filter({ policy_id: policyToDelete.id }),
      api.entities.Payment.filter({ policy_id: policyToDelete.id }),
      api.entities.Claim.filter({ policy_id: policyToDelete.id }),
      api.entities.Endorsement.filter({ policy_id: policyToDelete.id }),
    ]);

    for (const p of payments) await api.entities.Payment.delete(p.id);
    for (const c of commissions) await api.entities.Commission.delete(c.id);
    for (const c of claims) await api.entities.Claim.delete(c.id);
    for (const e of endorsements) await api.entities.Endorsement.delete(e.id);

    if (policyToDelete.policy_category === 'CORPORATIVA') {
      const members = await api.entities.CorporateMember.filter({ policy_id: policyToDelete.id });
      for (const m of members) await api.entities.CorporateMember.delete(m.id);
      const rates = await api.entities.CorporateRatePlan.filter({ policy_id: policyToDelete.id });
      for (const r of rates) await api.entities.CorporateRatePlan.delete(r.id);
    }

    await api.entities.Policy.delete(policyToDelete.id);
    setPolicyToDelete(null);
    loadData();
  };

  // Apply filters — memoized so it only recalculates when policies or a filter changes
  const filteredPolicies = useMemo(() => policies.filter(p => {
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (lineFilter !== 'all' && p.line_name !== lineFilter) return false;
    if (agentFilter !== 'all' && p.agent_id !== agentFilter) return false;
    if (companyFilter !== 'all' && p.company_id !== companyFilter) return false;
    if (policyTypeFilter !== 'all' && p.policy_type !== policyTypeFilter) return false;
    // Tag filters: include = must have at least one; exclude = must not have any
    if (tagFilterInclude.length > 0) {
      const policyTagIds = (p.tags || []).map(t => t.id);
      if (!tagFilterInclude.some(id => policyTagIds.includes(id))) return false;
    }
    if (tagFilterExclude.length > 0) {
      const policyTagIds = (p.tags || []).map(t => t.id);
      if (tagFilterExclude.some(id => policyTagIds.includes(id))) return false;
    }
    return true;
  }), [policies, statusFilter, lineFilter, agentFilter, companyFilter, policyTypeFilter, tagFilterInclude, tagFilterExclude]);

  const columns = [
    {
      header: t('policies.title'),
      cell: (row) => (
        <div>
          <p className="font-medium text-foreground">{row.policy_number}</p>
          <p className="text-sm text-muted-foreground">{row.product_name}</p>
          {row.tags && row.tags.length > 0 && (
            <PolicyTagBadges tags={row.tags} size="xs" showName={false} className="mt-1" />
          )}
        </div>
      )
    },
    {
      header: t('policies.client'),
      cell: (row) => {
        const displayName = row.policy_category === 'CORPORATIVA' ? row.contractor_name : row.client_name;
        return (
          <div>
            <p className="text-sm">{displayName}</p>
            {row.policy_category === 'CORPORATIVA' && (
              <span className="text-xs px-2 py-0.5 rounded bg-purple-500/10 text-purple-600 dark:text-purple-400">{t('policies.corporate')}</span>
            )}
          </div>
        );
      }
    },
    {
      header: t('policies.policyType'),
      cell: (row) => <span className="text-sm capitalize">{row.policy_type?.replace(/_/g, ' ')}</span>
    },
    {
      header: t('policies.company'),
      cell: (row) => (
        <div>
          <p className="text-sm">{row.company_name}</p>
          <p className="text-xs text-muted-foreground">{row.line_name}</p>
        </div>
      )
    },
    {
      header: t('policies.premium'),
      cell: (row) => (
        <div>
          <span className="font-medium">{row.currency} {(row.annual_premium || 0).toLocaleString()}</span>
          {row.policy_category === 'CORPORATIVA' && (
            <p className="text-xs text-purple-600 dark:text-purple-400">{t('policies.byMembers')}</p>
          )}
        </div>
      )
    },
    {
      header: t('policies.validity'),
      accessorKey: 'start_date',
      cell: (row) => {
        const safeFormat = (dateStr) => {
          if (!dateStr) return '-';
          const d = new Date(dateStr + 'T00:00:00');
          return isNaN(d.getTime()) ? '-' : format(d, 'dd/MM/yyyy');
        };
        return (
          <div className="text-sm">
            <p>{safeFormat(row.start_date)}</p>
            <p className="text-muted-foreground">{safeFormat(row.end_date)}</p>
          </div>
        );
      }
    },
    {
      header: t('policies.agent'),
      accessorKey: 'agent_name'
    },
    {
      header: t('common.status'),
      cell: (row) => <StatusBadge status={row.status} />
    },
    {
      header: t('common.actions'),
      cell: (row) => {
        const canEdit = currentUser?.role === 'admin' || 
                       currentUser?.app_role === 'admin' || 
                       currentUser?.app_role === 'operativo';
        
        const canDelete = currentUser?.role === 'admin' || 
                         currentUser?.app_role === 'admin';
        
        return (
          <div className="flex items-center gap-2">
            <Link to={createPageUrl(`PolicyDetail?id=${row.id}`)}>
              <Button variant="ghost" size="icon">
                <Eye className="h-4 w-4" />
              </Button>
            </Link>
            {canEdit && (
              <Button variant="ghost" size="icon" onClick={() => handleEdit(row)}>
                <Pencil className="h-4 w-4" />
              </Button>
            )}
            {canDelete && (currentUser?.role === 'admin' || currentUser?.app_role === 'admin') && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => { setPolicyToDelete(row); setDeleteDialogOpen(true); }}
              >
                <Trash2 className="h-4 w-4 text-red-500" />
              </Button>
            )}
          </div>
        );
      }
    }
  ];

  const getExportData = () => ({
    headers: ['Número', 'Cliente', 'Producto', 'Compañía', 'Prima', 'Moneda', 'Inicio', 'Fin', 'Agente', 'Estado'],
    rows: filteredPolicies.map(p => [
      p.policy_number, p.client_name, p.product_name, p.company_name,
      p.annual_premium, p.currency, p.start_date, p.end_date, p.agent_name, p.status
    ]),
    filename: 'polizas'
  });

  const handleExportCSV = () => exportToCSV(getExportData());
  const handleExportExcel = () => exportToExcel({ ...getExportData(), sheetName: 'Pólizas' });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadData}>
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <BackButton className="mt-1" />
          <div className="flex-1">
            <PageHeader
              title={t('policies.title')}
              subtitle={`${filteredPolicies.length} ${t('policies.title').toLowerCase()}`}
              icon={FileText}
              actions={
                <Button 
                  onClick={() => { setEditingPolicy(null); setFormOpen(true); }} 
                  className="gap-2"
                  disabled={currentUser?.app_role === 'agente' || currentUser?.app_role === 'jefatura'}
                >
                  <Plus className="h-4 w-4" /> {t('policies.new')}
                </Button>
              }
            />
          </div>
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="flex flex-wrap items-end gap-4">
            <div className="space-y-1.5 min-w-[140px]">
              <Label className="text-xs text-muted-foreground">Estado</Label>
              <MobileSelect 
                value={statusFilter} 
                onValueChange={setStatusFilter}
                placeholder={t('common.status')}
                label={t('common.status')}
              >
                <SelectItem value="all">{t('common.all')}</SelectItem>
                <SelectItem value="activa">{t('policies.active')}</SelectItem>
                <SelectItem value="vencida">{t('policies.expired')}</SelectItem>
                <SelectItem value="cancelada">{t('policies.cancelled')}</SelectItem>
                <SelectItem value="en_renovacion">{t('policies.renewal')}</SelectItem>
                <SelectItem value="en_riesgo">{t('policies.atRisk')}</SelectItem>
              </MobileSelect>
            </div>

            <div className="space-y-1.5 min-w-[140px]">
              <Label className="text-xs text-muted-foreground">Ramo</Label>
              <MobileSelect 
                value={lineFilter} 
                onValueChange={setLineFilter}
                placeholder={t('policies.line')}
                label={t('policies.line')}
              >
                <SelectItem value="all">{t('common.all')}</SelectItem>
                {lines.map(line => (
                  <SelectItem key={line.id} value={line.name}>{line.name}</SelectItem>
                ))}
              </MobileSelect>
            </div>

            {/* Agente con búsqueda */}
            <div className="space-y-1.5 min-w-[180px]" ref={agentDropdownRef}>
              <Label className="text-xs text-muted-foreground">Agente</Label>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => { setAgentDropdownOpen(!agentDropdownOpen); setAgentSearch(''); }}
                  className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  <span className="truncate">
                    {agentFilter === 'all' ? 'Todos' : agents.find(a => a.id === agentFilter)?.name || 'Todos'}
                  </span>
                  <ChevronDown className="h-4 w-4 opacity-50 shrink-0 ml-2" />
                </button>
                {agentDropdownOpen && (
                  <div className="absolute z-50 mt-1 w-full min-w-[200px] rounded-md border bg-card shadow-lg">
                    <div className="p-2 border-b">
                      <input
                        autoFocus
                        className="w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-1 focus:ring-ring"
                        placeholder="Buscar agente..."
                        value={agentSearch}
                        onChange={e => setAgentSearch(e.target.value)}
                      />
                    </div>
                    <div className="max-h-52 overflow-auto">
                      <div
                        className="px-3 py-2 text-sm hover:bg-muted/40 cursor-pointer"
                        onClick={() => { setAgentFilter('all'); setAgentDropdownOpen(false); }}
                      >
                        Todos
                      </div>
                      {agents
                        .filter(a => allowedAgentIds === null || allowedAgentIds.includes(a.id))
                        .filter(a => !agentSearch || a.name?.toLowerCase().includes(agentSearch.toLowerCase()) || a.alias?.toLowerCase().includes(agentSearch.toLowerCase()))
                        .map(a => (
                          <div
                            key={a.id}
                            className={`px-3 py-2 text-sm hover:bg-muted/40 cursor-pointer ${agentFilter === a.id ? 'bg-muted text-foreground font-medium' : ''}`}
                            onClick={() => { setAgentFilter(a.id); setAgentDropdownOpen(false); setAgentSearch(''); }}
                          >
                            {a.name}{a.alias ? <span className="text-muted-foreground/70 ml-1 text-xs">({a.alias})</span> : null}
                          </div>
                        ))
                      }
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Compañía con búsqueda */}
            <div className="space-y-1.5 min-w-[180px]" ref={companyDropdownRef}>
              <Label className="text-xs text-muted-foreground">Compañía</Label>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => { setCompanyDropdownOpen(!companyDropdownOpen); setCompanySearch(''); }}
                  className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  <span className="truncate">
                    {companyFilter === 'all' ? 'Todas' : companies.find(c => c.id === companyFilter)?.name || 'Todas'}
                  </span>
                  <ChevronDown className="h-4 w-4 opacity-50 shrink-0 ml-2" />
                </button>
                {companyDropdownOpen && (
                  <div className="absolute z-50 mt-1 w-full min-w-[200px] rounded-md border bg-card shadow-lg">
                    <div className="p-2 border-b">
                      <input
                        autoFocus
                        className="w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-1 focus:ring-ring"
                        placeholder="Buscar compañía..."
                        value={companySearch}
                        onChange={e => setCompanySearch(e.target.value)}
                      />
                    </div>
                    <div className="max-h-52 overflow-auto">
                      <div
                        className="px-3 py-2 text-sm hover:bg-muted/40 cursor-pointer"
                        onClick={() => { setCompanyFilter('all'); setCompanyDropdownOpen(false); }}
                      >
                        Todas
                      </div>
                      {companies
                        .filter(c => !companySearch || c.name?.toLowerCase().includes(companySearch.toLowerCase()))
                        .map(c => (
                          <div
                            key={c.id}
                            className={`px-3 py-2 text-sm hover:bg-muted/40 cursor-pointer ${companyFilter === c.id ? 'bg-muted text-foreground font-medium' : ''}`}
                            onClick={() => { setCompanyFilter(c.id); setCompanyDropdownOpen(false); setCompanySearch(''); }}
                          >
                            {c.name}
                          </div>
                        ))
                      }
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-1.5 min-w-[150px]">
              <Label className="text-xs text-muted-foreground">Tipo de póliza</Label>
              <MobileSelect
                value={policyTypeFilter}
                onValueChange={setPolicyTypeFilter}
                placeholder="Tipo"
                label="Tipo de póliza"
              >
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="nuevo_negocio">Nuevo negocio</SelectItem>
                <SelectItem value="renovacion">Renovación</SelectItem>
                <SelectItem value="cambio_broker">Cambio de broker</SelectItem>
                <SelectItem value="cesion_cartera">Cesión de cartera</SelectItem>
                <SelectItem value="otro">Otro</SelectItem>
              </MobileSelect>
            </div>

            <div className="space-y-1.5 min-w-[180px]">
              <Label className="text-xs text-muted-foreground">Etiquetas</Label>
              <PolicyTagFilter
                includeTagIds={tagFilterInclude}
                excludeTagIds={tagFilterExclude}
                onIncludeChange={setTagFilterInclude}
                onExcludeChange={setTagFilterExclude}
              />
            </div>

            {(statusFilter !== 'all' || lineFilter !== 'all' || agentFilter !== 'all' || companyFilter !== 'all' || policyTypeFilter !== 'all' || tagFilterInclude.length > 0 || tagFilterExclude.length > 0) && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => { setStatusFilter('all'); setLineFilter('all'); setAgentFilter('all'); setCompanyFilter('all'); setPolicyTypeFilter('all'); setTagFilterInclude([]); setTagFilterExclude([]); }}
              >
                {t('common.reset')}
              </Button>
            )}
          </div>
        </Card>

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            columns={columns}
            data={filteredPolicies}
            searchPlaceholder={`${t('common.search')}...`}
            searchKeys={['policy_number', 'client_name', 'product_name', 'company_name', 'agent_name']}
            initialSearch={searchQuery}
            onSearchChange={updateSearch}
            exportable
            onExport={handleExportCSV}
            onExportExcel={handleExportExcel}
            emptyMessage={t('common.noData')}
            sortable={true}
            defaultSortField="created_date"
            defaultSortOrder="desc"
            actions={
              searchQuery && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={clearSearch}
                  className="text-muted-foreground hover:text-foreground/80 gap-1"
                >
                  <X className="h-4 w-4" /> {t('common.clearSearch')}
                </Button>
              )
            }
          />
        </Card>

        <PolicyForm
           open={formOpen}
           onOpenChange={(open) => {
             setFormOpen(open);
             if (!open) {
               setEditingPolicy(null);
               setSaving(false);
             }
           }}
           onSubmit={handleSubmit}
           initialData={editingPolicy}
           isLoading={saving}
           lines={lines}
           agents={agents}
           companies={companies}
         />

        <DeleteSafetyDialog
          open={deleteDialogOpen}
          onOpenChange={(open) => { setDeleteDialogOpen(open); if (!open) setPolicyToDelete(null); }}
          title={t('policies.deleteTitle')}
          entityDescription={policyToDelete ? `${t('policies.deleteDesc')} "${policyToDelete.policy_number}"` : t('policies.deleteDescGeneric')}
          checkUsage={policyToDelete ? checkPolicyUsage : null}
          onConfirm={handleDeletePolicy}
        />
        </div>
      </div>
    </PullToRefresh>
  );
}