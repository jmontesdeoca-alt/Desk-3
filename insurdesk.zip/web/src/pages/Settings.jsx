import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import BackButton from '@/components/ui/BackButton';
import { 
  Building2, 
  Layers, 
  Package, 
  Users, 
  Table2,
  Settings as SettingsIcon,
  ChevronRight,
  TestTube
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

const settingsItems = [
  {
    title: 'Branches',
    description: 'Branches / Offices',
    icon: Building2,
    page: 'SettingsBranches',
    color: 'bg-muted text-foreground'
  },
  {
    title: 'Insurance Lines',
    description: 'Insurance lines and categories',
    icon: Layers,
    page: 'SettingsLines',
    color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400'
  },
  {
    title: 'Insurance Companies',
    description: 'Insurance companies',
    icon: Building2,
    page: 'SettingsCompanies',
    color: 'bg-muted text-foreground'
  },
  {
    title: 'Products',
    description: 'Insurance products by company',
    icon: Package,
    page: 'SettingsProducts',
    color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
  },
  {
    title: 'Commission Tables',
    description: 'Commission tables by company and product',
    icon: Table2,
    page: 'SettingsCommissionTables',
    color: 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
  },
  {
    title: 'Agents & Agencies',
    description: 'Manage agents, agencies and their hierarchy',
    icon: Users,
    page: 'Agents',
    color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
  },

  {
    title: 'User Management',
    description: 'Manage users, roles and permissions',
    icon: Users,
    page: 'UserManagement',
    color: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400'
  },
  {
    title: 'QA End-to-End Runner',
    description: 'Run automated system tests (Admin only)',
    icon: TestTube,
    page: 'QARunner',
    color: 'bg-orange-500/10 text-orange-600 dark:text-orange-400'
  }
];

export default function Settings() {
  const { t } = useTranslation();
  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-4xl mx-auto">
        {/* Sticky Mobile Header */}
        <div className="sticky top-0 z-40 bg-muted/40 pb-4 mb-2 lg:static lg:pb-0 lg:mb-6 sm:mb-8" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
          <div className="flex items-center gap-3 sm:gap-4">
            <BackButton />
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="p-2 sm:p-2.5 rounded-xl bg-muted ">
                <SettingsIcon className="h-5 w-5 sm:h-6 sm:w-6 text-muted-foreground " />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-foreground ">{t('settings.title')}</h1>
                <p className="text-xs sm:text-sm text-muted-foreground ">{t('settings.title')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-4">
          {settingsItems.map((item) => (
            <Link key={item.page} to={createPageUrl(item.page)}>
              <Card className="border-0 shadow-sm hover:shadow-md transition-all cursor-pointer group ">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${item.color}`}>
                      <item.icon className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg font-semibold text-foreground mb-1">
                        {item.title}
                      </CardTitle>
                      <CardDescription className="text-muted-foreground ">
                        {item.description}
                      </CardDescription>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground/70 group-hover:text-muted-foreground group-hover:translate-x-1 transition-all" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}

        </div>
      </div>
    </div>
  );
}