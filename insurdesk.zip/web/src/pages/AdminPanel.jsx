import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import StatCard from '@/components/ui/StatCard';
import NotificationSystem from '@/components/NotificationSystem';
import { 
  Shield, Users, Settings, Activity, AlertTriangle, 
  TrendingUp, FileText, DollarSign, Loader2, ChevronRight,
  Trophy, Target, Award, Upload, Mail, FileSpreadsheet, Tag
} from 'lucide-react';
import StorageMeter from '@/components/admin/StorageMeter';
import { Switch } from "@/components/ui/switch";
import { toast } from 'sonner';
import { formatLocalDateTime } from '@/components/dateUtils';
import { useFeatures } from '@/lib/FeatureContext';

export default function AdminPanel() {
  const { pageEnabled } = useFeatures();
  const [loading, setLoading] = useState(true);
  const [emailsEnabled, setEmailsEnabled] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalAgents: 0,
    totalPolicies: 0,
    activePolicies: 0,
    totalCommissions: 0,
    pendingCommissions: 0,
    totalClients: 0,
    recentActivity: []
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    
    const user = await api.auth.me();
    const userRoleResp = await api.functions.invoke('getUserRoleInfo', {});
    const enrichedUser = { ...user, app_role: userRoleResp?.data?.app_role, agent_id: userRoleResp?.data?.agent_id };
    setCurrentUser(enrichedUser);
    
    const isUserAdmin = enrichedUser?.role === 'admin' || enrichedUser?.app_role === 'admin';
    
    const [users, agents, policies, commissions, clients, auditLogs, settings] = await Promise.all([
      isUserAdmin ? api.entities.User.list().catch(() => []) : Promise.resolve([]),
      api.entities.Agent.list(),
      api.entities.Policy.list(),
      api.entities.Commission.list(),
      api.entities.Client.list(),
      api.entities.AuditLog ? api.entities.AuditLog.list('-created_date', 10).catch(() => []) : Promise.resolve([]),
      isUserAdmin ? api.entities.AppSettings.filter({ setting_key: 'automatic_emails_enabled' }).catch(() => []) : Promise.resolve([])
    ]);

    const activePolicies = policies.filter(p => p.status === 'activa').length;
    const totalCommissionAmount = commissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);
    const pendingCommissionAmount = commissions
      .filter(c => c.status === 'pendiente_liberar' || c.status === 'pendiente_pagar')
      .reduce((sum, c) => sum + (c.commission_amount || 0), 0);

    // Load email setting
    if (settings.length > 0) {
      setEmailsEnabled(settings[0].setting_value === 'true');
    }

    setStats({
      totalUsers: users.length,
      totalAgents: agents.length,
      totalPolicies: policies.length,
      activePolicies,
      totalCommissions: totalCommissionAmount,
      pendingCommissions: pendingCommissionAmount,
      totalClients: clients.length,
      recentActivity: auditLogs
    });

    setLoading(false);
  };

  const toggleAutomaticEmails = async () => {
    try {
      const settings = await api.entities.AppSettings.filter({ setting_key: 'automatic_emails_enabled' });
      
      if (settings.length > 0) {
        await api.entities.AppSettings.update(settings[0].id, {
          setting_value: (!emailsEnabled).toString()
        });
        setEmailsEnabled(!emailsEnabled);
        toast.success(`Correos automáticos ${!emailsEnabled ? 'activados' : 'desactivados'}`);
      }
    } catch (error) {
      console.error('Error toggling emails:', error);
      toast.error('Error al cambiar configuración');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  const isAdmin = currentUser?.role === 'admin' || currentUser?.app_role === 'admin';
  const isJefatura = currentUser?.app_role === 'jefatura';
  const isGerencial = currentUser?.app_role === 'gerencial';
  // Gerencial vinculado a agente: solo ve módulos de su estructura
  const isGerencialWithAgent = isGerencial && !!currentUser?.agent_id;

  const adminModules = isGerencialWithAgent ? [
    // Gerencial vinculado solo ve estos módulos
    {
      title: 'Gestión de Agentes',
      description: 'Ver agentes de tu estructura',
      icon: Users,
      color: 'bg-brand-strong/10 text-brand-strong',
      path: 'Agents',
      count: stats.totalAgents
    },
    {
      title: 'Estructura de Agencias',
      description: 'Visualiza la jerarquía de tu estructura',
      icon: Users,
      color: 'bg-muted text-foreground',
      path: 'AgentStructure'
    },
    {
      title: 'Incentivos',
      description: 'Ver incentivos y cumplimiento de tu estructura',
      icon: Trophy,
      color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
      path: 'Incentives'
    },
    {
      title: 'Tabla de Clasificación',
      description: 'Rankings y desempeño de agentes',
      icon: Award,
      color: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
      path: 'LeaderboardAgents'
    },
    {
      title: 'Objetivos de Ventas',
      description: 'Ver objetivos de tu estructura',
      icon: Target,
      color: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400',
      path: 'SalesTargets'
    },
    {
      title: 'Gestión de Insignias',
      description: 'Ver insignias de gamificación',
      icon: Award,
      color: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
      path: 'SettingsBadges'
    },
    {
      title: 'Rentabilidad por Agente',
      description: 'Análisis de margen y costos de tu estructura',
      icon: TrendingUp,
      color: 'bg-muted text-foreground',
      path: 'AgentProfitability'
    }
  ] : [
    {
      title: 'Gestión de Usuarios',
      description: 'Administrar usuarios, roles y permisos',
      icon: Users,
      color: 'bg-brand-soft/20 text-brand',
      path: 'UserManagement',
      count: stats.totalUsers
    },
    {
      title: 'Gestión de Agentes',
      description: 'Administrar estructura y jerarquía de agentes',
      icon: Users,
      color: 'bg-brand-strong/10 text-brand-strong',
      path: 'Agents',
      count: stats.totalAgents
    },
    {
      title: 'Estructura de Agencias',
      description: 'Visualiza la jerarquía y estructura organizacional',
      icon: Users,
      color: 'bg-muted text-foreground',
      path: 'AgentStructure'
    },
    {
      title: 'Auditoría del Sistema',
      description: 'Ver historial de cambios y actividad',
      icon: Activity,
      color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400',
      path: 'AuditLogs'
    },
    {
      title: 'Configuración Global',
      description: 'Ajustes generales de la aplicación',
      icon: Settings,
      color: 'bg-muted text-muted-foreground',
      path: 'Settings'
    },
    {
      title: 'Incentivos',
      description: 'Gestionar incentivos y medir cumplimiento por agente y agencia',
      icon: Trophy,
      color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
      path: 'Incentives'
    },
    {
      title: 'Tabla de Clasificación',
      description: 'Rankings y desempeño de agentes',
      icon: Award,
      color: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
      path: 'LeaderboardAgents'
    },
    {
      title: 'Objetivos de Ventas',
      description: 'Gestionar objetivos por agente o equipo',
      icon: Target,
      color: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400',
      path: 'SalesTargets'
    },
    {
      title: 'Gestión de Insignias',
      description: 'Crear y administrar insignias de gamificación',
      icon: Award,
      color: 'bg-pink-500/10 text-pink-600 dark:text-pink-400',
      path: 'SettingsBadges'
    },
    {
      title: 'Importación de Pólizas',
      description: 'Migración masiva de pólizas desde Excel',
      icon: Upload,
      color: 'bg-green-500/10 text-green-600 dark:text-green-400',
      path: 'PolicyImport'
    },
    {
      title: 'Importación de Datos del Sistema',
      description: 'Carga masiva de branches, compañías, ramos, productos, agentes y tablas de comisiones',
      icon: FileSpreadsheet,
      color: 'bg-teal-500/10 text-teal-600 dark:text-teal-400',
      path: 'SystemDataImport'
    },
    {
      title: 'Registro de Correos',
      description: 'Ver logs de envío de correos',
      icon: Mail,
      color: 'bg-muted text-foreground',
      path: 'EmailLog'
    },
    {
      title: 'Configuración de PDFs',
      description: 'Personalizar liquidaciones de comisiones',
      icon: FileText,
      color: 'bg-muted text-muted-foreground',
      path: 'CommissionPDFSettings'
    },
    ...(isAdmin ? [{
      title: 'Rentabilidad por Agente',
      description: 'Análisis de margen y costos por agente',
      icon: TrendingUp,
      color: 'bg-muted text-foreground',
      path: 'AgentProfitability'
    }] : []),
    ...(isAdmin ? [{
      title: 'Plan y módulos',
      description: 'Funciones incluidas en tu licencia y cambio de plan',
      icon: Shield,
      color: 'bg-muted text-foreground',
      path: 'PlanSettings'
    }] : []),
    {
      title: 'Auditoría de Datos',
      description: 'Cargar Excel y validar pólizas contra la base de datos',
      icon: FileSpreadsheet,
      color: 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
      path: 'DataAudit'
    },
    {
      title: 'Etiquetas de Pólizas',
      description: 'Configurar etiquetas para clasificar pólizas',
      icon: Tag,
      color: 'bg-teal-500/10 text-teal-600 dark:text-teal-400',
      path: 'PolicyTags'
    },
    ...(isAdmin ? [{
      title: 'Pólizas Duplicadas',
      description: 'Revisar y eliminar pólizas duplicadas por compañía + número',
      icon: AlertTriangle,
      color: 'bg-red-500/10 text-red-600 dark:text-red-400',
      path: 'DuplicatePolicies'
    }] : [])
  ];

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <div className="flex items-center gap-2 sm:gap-3 mb-2">
            <div className="p-2 rounded-lg bg-brand/10 dark:bg-brand/20">
              <Shield className="h-5 w-5 sm:h-6 sm:w-6 text-brand" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground dark:text-white">Panel de Administración</h1>
          </div>
          <p className="text-sm sm:text-base text-muted-foreground ">Gestión y supervisión del sistema</p>
        </div>

        {/* Email Settings Card - Only for Admin */}
        {isAdmin && (
          <Card className="border-0 shadow-sm mb-6">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium text-foreground">Correos Automáticos</p>
                    <p className="text-sm text-muted-foreground">
                      Controla el envío de correos de nueva póliza y renovaciones
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      (Los correos del sistema como login e invitaciones siempre se envían)
                    </p>
                  </div>
                </div>
                <Switch checked={emailsEnabled} onCheckedChange={toggleAutomaticEmails} />
              </div>
            </CardContent>
          </Card>
        )}

        {/* System Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Total Usuarios"
            value={stats.totalUsers}
            icon={Users}
            iconBg="bg-brand-soft/20"
            iconColor="text-brand"
          />
          <StatCard
            title="Pólizas Activas"
            value={stats.activePolicies}
            subtitle={`de ${stats.totalPolicies} totales`}
            icon={FileText}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-600 dark:text-emerald-400"
          />
          <StatCard
            title="Comisiones Totales"
            value={`USD ${stats.totalCommissions.toLocaleString()}`}
            icon={DollarSign}
            iconBg="bg-brand-strong/10"
            iconColor="text-brand-strong"
          />
          <StatCard
            title="Clientes Registrados"
            value={stats.totalClients}
            icon={TrendingUp}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-600 dark:text-amber-400"
          />
        </div>

        {/* Storage Meter - Only for Admin */}
        {isAdmin && (
          <div className="mb-8">
            <StorageMeter />
          </div>
        )}

        {/* Admin Modules */}
        <Card className="border-0 shadow-sm mb-8">
          <CardHeader>
            <CardTitle>Módulos de Administración</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {adminModules.filter((module) => pageEnabled(module.path)).map((module) => {
                const Icon = module.icon;
                return (
                  <Link key={module.path} to={createPageUrl(module.path)}>
                    <Card className="border border-border hover:border-brand hover:shadow-md transition-all cursor-pointer">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4 flex-1">
                            <div className={`p-3 rounded-lg ${module.color}`}>
                              <Icon className="h-6 w-6" />
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold text-foreground dark:text-white mb-1">{module.title}</h3>
                              <p className="text-sm text-muted-foreground ">{module.description}</p>
                              {module.count !== undefined && (
                                <p className="text-xs text-muted-foreground mt-2">
                                  {module.count} registros
                                </p>
                              )}
                            </div>
                          </div>
                          <ChevronRight className="h-5 w-5 text-muted-foreground/70 " />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <NotificationSystem recipientType="admin" />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* System Health */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-brand" />
                Estado del Sistema
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-emerald-500/10 dark:bg-emerald-900/20 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="h-3 w-3 rounded-full bg-emerald-500" />
                  <span className="text-sm font-medium text-foreground dark:text-white">Sistema Operativo</span>
                </div>
                <span className="text-xs text-emerald-600 dark:text-emerald-400 dark:text-emerald-400 font-medium">100% Uptime</span>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground ">Usuarios Activos</span>
                  <span className="text-sm font-semibold text-foreground dark:text-white">{stats.totalUsers}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground ">Agentes Activos</span>
                  <span className="text-sm font-semibold text-foreground dark:text-white">{stats.totalAgents}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground ">Comisiones Pendientes</span>
                  <span className="text-sm font-semibold text-amber-600 dark:text-amber-400 dark:text-amber-400">
                    USD {stats.pendingCommissions.toLocaleString()}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-brand" />
                Actividad Reciente
              </CardTitle>
              <Link to={createPageUrl('AuditLogs')}>
                <Button variant="outline" size="sm">Ver Todo</Button>
              </Link>
            </CardHeader>
            <CardContent>
              {stats.recentActivity.length === 0 ? (
                <p className="text-center text-muted-foreground/70 py-8 text-sm">
                  No hay actividad reciente registrada
                </p>
              ) : (
                <div className="space-y-3">
                  {stats.recentActivity.map((log, idx) => (
                    <div key={idx} className="p-3 bg-muted/40 rounded-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-foreground dark:text-white">{log.action}</p>
                          <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                          <p className="text-xs text-muted-foreground/70 mt-1">
                            {log.user_email} • {formatLocalDateTime(log.created_date)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="border-0 shadow-sm mt-6">
          <CardHeader>
            <CardTitle>Acciones Rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Link to={createPageUrl('UserManagement')}>
                <Button variant="outline" className="w-full gap-2">
                  <Users className="h-4 w-4" />
                  Invitar Usuario
                </Button>
              </Link>
              <Link to={createPageUrl('Agents')}>
                <Button variant="outline" className="w-full gap-2">
                  <Users className="h-4 w-4" />
                  Nuevo Agente
                </Button>
              </Link>
              <Link to={createPageUrl('AuditLogs')}>
                <Button variant="outline" className="w-full gap-2">
                  <Activity className="h-4 w-4" />
                  Ver Auditoría
                </Button>
              </Link>
              <Link to={createPageUrl('Settings')}>
                <Button variant="outline" className="w-full gap-2">
                  <Settings className="h-4 w-4" />
                  Configuración
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}