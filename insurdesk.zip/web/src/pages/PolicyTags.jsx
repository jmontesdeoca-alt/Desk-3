import React from 'react';
import PolicyTagManager from '@/components/admin/PolicyTagManager';

export default function PolicyTags() {
  return <PolicyTagManager />;
}