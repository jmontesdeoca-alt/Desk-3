import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import BackButton from '@/components/ui/BackButton';
import { Users, Plus, Trash2, Loader2, Building2, Table2 } from 'lucide-react';

export default function AgentCommissions() {
  const urlParams = new URLSearchParams(window.location.search);
  const agentId = urlParams.get('id');
  
  const [agent, setAgent] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [commissionTables, setCommissionTables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [assignmentToDelete, setAssignmentToDelete] = useState(null);
  
  const [selectedLine, setSelectedLine] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [selectedTable, setSelectedTable] = useState('');
  const [lines, setLines] = useState([]);

  useEffect(() => {
    if (agentId) loadData();
  }, [agentId]);

  const loadData = async () => {
    setLoading(true);
    const [agentData, assignmentsData, companiesData, tablesData, linesData] = await Promise.all([
      api.entities.Agent.filter({ id: agentId }),
      api.entities.AgentCommissionAssignment.filter({ agent_id: agentId }),
      api.entities.InsuranceCompany.filter({ status: 'activa' }),
      api.entities.CommissionTable.filter({ status: 'activa' }),
      api.entities.InsuranceLine.filter({ status: 'activo' })
    ]);
    setAgent(agentData[0]);
    setAssignments(assignmentsData);
    setCompanies(companiesData);
    setCommissionTables(tablesData);
    setLines(linesData);
    setLoading(false);
  };

  const selectedLineName = lines.find(l => l.id === selectedLine)?.name;
  const availableCompanies = selectedLine && selectedLineName
    ? companies.filter(c => {
        if (!c.lines || c.lines.length === 0) return false;
        return c.lines.some(cl => cl.toLowerCase().trim() === selectedLineName.toLowerCase().trim());
      }).sort((a, b) => a.name.localeCompare(b.name))
    : [];

  const filteredTables = (selectedLine && selectedCompany)
    ? commissionTables.filter(t => t.line_id === selectedLine && t.company_id === selectedCompany)
    : [];

  const handleAddAssignment = async () => {
    if (!selectedLine || !selectedCompany || !selectedTable) return;
    
    // Check if already exists
    const exists = assignments.find(a => 
      a.line_id === selectedLine && a.company_id === selectedCompany && a.commission_table_id === selectedTable
    );
    if (exists) return;
    
    setSaving(true);
    const line = lines.find(l => l.id === selectedLine);
    const company = companies.find(c => c.id === selectedCompany);
    const table = commissionTables.find(t => t.id === selectedTable);
    
    await api.entities.AgentCommissionAssignment.create({
      agent_id: agentId,
      agent_name: agent?.name || '',
      line_id: selectedLine,
      line_name: line?.name || '',
      company_id: selectedCompany,
      company_name: company?.name || '',
      commission_table_id: selectedTable,
      commission_table_name: table?.name || ''
    });
    
    setSelectedLine('');
    setSelectedCompany('');
    setSelectedTable('');
    setSaving(false);
    loadData();
  };

  const handleDeleteAssignment = async () => {
    if (assignmentToDelete) {
      await api.entities.AgentCommissionAssignment.delete(assignmentToDelete.id);
      setDeleteDialogOpen(false);
      setAssignmentToDelete(null);
      loadData();
    }
  };

  // Group assignments by line then company
  const assignmentsByLine = assignments.reduce((acc, assignment) => {
    const lineName = assignment.line_name || 'Sin ramo';
    if (!acc[lineName]) acc[lineName] = {};
    const companyName = assignment.company_name || 'Sin compañía';
    if (!acc[lineName][companyName]) acc[lineName][companyName] = [];
    acc[lineName][companyName].push(assignment);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-4xl mx-auto">
          <BackButton />
          <Card className="border-0 shadow-sm p-12 mt-6">
            <div className="text-center text-muted-foreground/70">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Agente no encontrado</p>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <BackButton />
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10">
              <Table2 className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Tablas de Comisiones</h1>
              <p className="text-sm text-muted-foreground">{agent.name}</p>
            </div>
          </div>
        </div>

        {/* Add new assignment */}
        <Card className="border-0 shadow-sm p-6 mb-6">
          <h3 className="font-semibold text-foreground mb-4">Asignar Tabla de Comisiones</h3>
          <div className="flex flex-wrap items-end gap-4">
            <div className="flex-1 min-w-[180px]">
              <Label className="mb-2 block">Ramo</Label>
              <Select 
                value={selectedLine} 
                onValueChange={(v) => { setSelectedLine(v); setSelectedCompany(''); setSelectedTable(''); }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar ramo" />
                </SelectTrigger>
                <SelectContent>
                  {lines.map(l => (
                    <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 min-w-[180px]">
              <Label className="mb-2 block">Compañía</Label>
              <Select 
                value={selectedCompany} 
                onValueChange={(v) => { setSelectedCompany(v); setSelectedTable(''); }}
                disabled={!selectedLine}
              >
                <SelectTrigger>
                  <SelectValue placeholder={selectedLine ? "Seleccionar compañía" : "Primero seleccione ramo"} />
                </SelectTrigger>
                <SelectContent>
                  {availableCompanies.length === 0 && selectedLine ? (
                    <SelectItem value="__none__" disabled>No hay compañías para este ramo</SelectItem>
                  ) : (
                    availableCompanies.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 min-w-[180px]">
              <Label className="mb-2 block">Tabla de Comisiones</Label>
              <Select 
                value={selectedTable} 
                onValueChange={setSelectedTable}
                disabled={!selectedCompany}
              >
                <SelectTrigger>
                  <SelectValue placeholder={selectedCompany ? "Seleccionar tabla" : "Seleccione compañía"} />
                </SelectTrigger>
                <SelectContent>
                  {filteredTables.map(t => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} (Nv. {t.level})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={handleAddAssignment} 
              disabled={!selectedLine || !selectedCompany || !selectedTable || saving}
              className="gap-2"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              <Plus className="h-4 w-4" /> Asignar
            </Button>
          </div>
        </Card>

        {/* Current assignments */}
        <div className="space-y-6">
          {Object.entries(assignmentsByLine).map(([lineName, lineCompanies]) => (
            <div key={lineName}>
              <div className="flex items-center gap-2 mb-4">
                <div className="p-1.5 rounded bg-purple-500/10">
                  <Table2 className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                </div>
                <h2 className="font-bold text-foreground">{lineName}</h2>
              </div>
              {Object.entries(lineCompanies).map(([companyName, companyAssignments]) => (
                <div key={companyName} className="ml-6 mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Building2 className="h-4 w-4 text-muted-foreground/70" />
                    <h3 className="font-semibold text-foreground/80">{companyName}</h3>
                  </div>
                  <div className="grid gap-3 ml-6">
                    {companyAssignments.map((assignment) => {
                      const table = commissionTables.find(t => t.id === assignment.commission_table_id);
                      return (
                        <Card key={assignment.id} className="border-0 shadow-sm p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h4 className="font-semibold text-foreground">{assignment.commission_table_name}</h4>
                              {table && table.product_commissions && table.product_commissions.length > 0 ? (
                                <div className="mt-2 overflow-x-auto">
                                  <table className="w-full text-xs">
                                    <thead>
                                      <tr className="border-b">
                                        <th className="text-left py-1">Producto</th>
                                        <th className="text-center py-1 text-emerald-600 dark:text-emerald-400">Nuevo</th>
                                        <th className="text-center py-1 text-foreground">Renov.</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {table.product_commissions.map((pc, idx) => (
                                        <tr key={idx} className="border-b">
                                          <td className="py-1">{pc.product_name}</td>
                                          <td className="text-center py-1 font-medium text-emerald-600 dark:text-emerald-400">{pc.new_business_percentage}%</td>
                                          <td className="text-center py-1 font-medium text-foreground">{pc.renewal_percentage}%</td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              ) : (
                                <p className="text-xs text-muted-foreground/70 mt-2">Sin productos configurados</p>
                              )}
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => { setAssignmentToDelete(assignment); setDeleteDialogOpen(true); }}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ))}
          {assignments.length === 0 && (
            <Card className="border-0 shadow-sm p-12">
              <div className="text-center text-muted-foreground/70">
                <Table2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No hay tablas de comisiones asignadas</p>
                <p className="text-sm mt-2">Usa el formulario de arriba para asignar tablas</p>
              </div>
            </Card>
          )}
        </div>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar asignación?</AlertDialogTitle>
              <AlertDialogDescription>
                Se eliminará la asignación de la tabla de comisiones 
                {assignmentToDelete && ` "${assignmentToDelete.commission_table_name}"`} para este agente.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteAssignment} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}