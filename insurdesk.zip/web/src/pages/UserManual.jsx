import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  FileText, Users, DollarSign, Shield, TrendingUp, BarChart3,
  Settings, RefreshCw, ClipboardList, ChevronDown, ChevronRight,
  BookOpen, AlertTriangle, CheckCircle, Info,
  Building2, UserCheck, MessageSquare, Star, Target, Zap
} from 'lucide-react';

const sections = [
  {
    id: 'intro',
    icon: BookOpen,
    color: 'bg-primary',
    title: '¿Qué es InsurDesk?',
    content: `InsurDesk es el sistema de gestión integral para corredores y agencias de seguros. Centraliza toda la operación: pólizas, clientes, pagos, comisiones, siniestros y más — en un solo lugar, accesible desde cualquier dispositivo.

El sistema está diseñado para que los equipos de ventas, operaciones y administración trabajen de forma coordinada, con información en tiempo real y sin duplicar datos.`
  },
  {
    id: 'roles',
    icon: UserCheck,
    color: 'bg-purple-500',
    title: 'Roles de Usuario',
    subsections: [
      {
        title: 'Admin',
        description: 'Acceso total al sistema. Puede ver, crear, editar y eliminar cualquier dato. Gestiona usuarios, configuraciones, comisiones y reportes completos.'
      },
      {
        title: 'Gerencial',
        description: 'Visión ejecutiva completa. Ve todos los módulos incluyendo siniestros, comisiones y reportes. No puede eliminar registros críticos.'
      },
      {
        title: 'Jefatura',
        description: 'Puede gestionar agentes y ver comisiones. Tiene acceso al Panel de Administración para configurar el sistema.'
      },
      {
        title: 'Operativo',
        description: 'Gestiona el día a día: crea pólizas, registra pagos, sube documentos, atiende siniestros. No ve comisiones ni reportes financieros.'
      },
      {
        title: 'Financiero',
        description: 'Enfocado en la parte económica: ve pólizas, pagos, comisiones y reportes. No puede modificar pólizas.'
      },
      {
        title: 'Agente',
        description: 'Ve únicamente sus propias pólizas y las de su estructura (agentes que están debajo de él en la jerarquía). Tiene su propio Dashboard personalizado.'
      }
    ]
  },
  {
    id: 'dashboard',
    icon: BarChart3,
    color: 'bg-indigo-500',
    title: 'Dashboard (Inicio)',
    content: `El Dashboard es la pantalla principal al ingresar al sistema. Muestra un resumen ejecutivo de toda la operación en tiempo real.`,
    items: [
      {
        title: 'Alertas automáticas',
        detail: 'En la parte superior aparecen tarjetas de alerta para: Renovaciones próximas (pólizas que vencen en 60 días), Pagos atrasados, Pólizas en riesgo y Tareas vencidas. Al hacer clic en cada alerta, el sistema te lleva directamente al módulo correspondiente.'
      },
      {
        title: 'Nuevos Negocios del Año',
        detail: 'Cuenta solo las pólizas de tipo "nuevo_negocio" cuya fecha de inicio (vigencia desde) está dentro del año calendario actual.'
      },
      {
        title: 'Producción Anual',
        detail: 'Suma de primas anuales de todos los nuevos negocios del año en curso. Representa la producción bruta de la agencia en el período.'
      },
      {
        title: 'Prima Total Anual',
        detail: 'Suma de primas de TODAS las pólizas activas (sin importar el tipo: nuevo negocio, renovación, cambio de broker) cuya vigencia inició en el año actual.'
      },
      {
        title: 'Gráfico "Pólizas por Ramo"',
        detail: 'Dona interactiva que muestra la distribución del portafolio por ramo de seguro (Salud, Vida, Auto, Hogar, etc.).'
      },
      {
        title: 'Top Agentes por Producción',
        detail: 'Ranking de los 5 agentes con mayor prima acumulada en su portafolio completo.'
      },
      {
        title: 'Mis Tareas Pendientes',
        detail: 'Solo aparece si tienes tareas asignadas. Muestra las 5 más urgentes con indicador de vencimiento.'
      },
      {
        title: 'Cumpleaños del día',
        detail: 'Al inicio de la sesión, el sistema detecta si algún cliente o agente cumple años hoy y muestra una notificación festiva.'
      }
    ]
  },
  {
    id: 'clients',
    icon: Users,
    color: 'bg-teal-500',
    title: 'Módulo: Clientes',
    content: `El módulo de Clientes centraliza toda la información de las personas o empresas aseguradas. Un cliente puede tener múltiples pólizas asociadas.`,
    items: [
      {
        title: 'Tipos de cliente',
        detail: 'PERSONA: persona natural con nombre, apellido y documento de identidad (cédula, pasaporte). EMPRESA: persona jurídica con razón social y NIT/RUC.'
      },
      {
        title: 'Cómo crear un cliente',
        detail: '1. Ve al módulo "Clientes" en el menú. 2. Clic en "Nuevo Cliente". 3. Selecciona el tipo (Persona o Empresa). 4. Completa nombre, documento, país, email y teléfono. 5. Guarda. El sistema valida automáticamente si ya existe un cliente con nombre similar y te advierte de posibles duplicados.'
      },
      {
        title: 'Ficha del cliente',
        detail: 'Al hacer clic en un cliente, accedes a su ficha completa que muestra: Información personal, Historial de pólizas, Pagos realizados, Siniestros, Dependientes registrados, Documentos adjuntos y Timeline de actividad.'
      },
      {
        title: 'Dependientes',
        detail: 'Desde la ficha del cliente puedes agregar dependientes (familiares). Cada dependiente tiene: nombre completo, parentesco, fecha de nacimiento y documento. Los dependientes también aparecen automáticamente en las pólizas de salud del titular.'
      }
    ]
  },
  {
    id: 'policies',
    icon: FileText,
    color: 'bg-primary',
    title: 'Módulo: Pólizas',
    content: `El módulo de Pólizas es el corazón del sistema. Aquí se registran y gestionan todos los contratos de seguro.`,
    subsections: [
      {
        title: 'Categorías de póliza',
        description: 'INDIVIDUAL: póliza contratada por una persona natural. Requiere: cliente, prima anual, prima comisionable y cuotas. CORPORATIVA: póliza contratada por una empresa para un grupo de empleados. Usa un tarifario mensual por tipo de afiliado y no tiene prima fija — se calcula en base a los miembros activos.'
      },
      {
        title: 'Flujo para crear una póliza',
        description: '1. Seleccionar RAMO (Salud, Vida, Auto, Hogar, etc.) → 2. El sistema filtra las compañías que trabajan ese ramo → 3. Seleccionar COMPAÑÍA → 4. El sistema filtra los productos disponibles → 5. Seleccionar PRODUCTO → 6. El sistema detecta si es Individual o Corporativa → 7. Completar datos financieros y fechas → 8. Guardar.'
      }
    ],
    items: [
      {
        title: 'Prima Total Anual vs Prima Comisionable',
        detail: 'Prima Total Anual: es el valor bruto que paga el cliente por el año completo (incluye todos los cargos). Prima Comisionable: es la base sobre la que se calculan las comisiones. Generalmente es menor a la prima total porque excluye impuestos, recargos administrativos, etc. IMPORTANTE: siempre ingresar ambas por separado.'
      },
      {
        title: 'Cálculo automático de cuotas',
        detail: 'El sistema calcula automáticamente el valor de cada cuota: Mensual: Prima Anual ÷ Número de meses (2 a 12, por defecto 12). Trimestral: Prima Anual ÷ 4. Semestral: Prima Anual ÷ 2. Anual: Prima Anual (un solo pago). Único: Prima Anual (pago único, diferente a anual en la contabilidad).'
      },
      {
        title: 'Fechas importantes',
        detail: 'Fecha de Emisión: fecha original en que se emitió la póliza por primera vez (histórica). Si no se especifica, el sistema usa la fecha de inicio de vigencia. Vigencia Desde: inicio del período de cobertura. Vigencia Hasta: fin del período. Se auto-calcula sumando 365 días a la fecha de inicio cuando la ingresas.'
      },
      {
        title: 'Estados de póliza',
        detail: 'Activa: póliza vigente y al día. Vencida: pasó su fecha de fin sin renovarse. Cancelada: fue dada de baja antes de vencer. Renovada: fue reemplazada por una nueva póliza de renovación. En Riesgo: tiene problemas (pagos atrasados, siniestro pendiente, etc.).'
      },
      {
        title: 'Datos específicos por ramo',
        detail: 'SALUD: Monto Asegurado (cobertura máxima), Deducible 1 (dentro del país), Deducible 2 (fuera del país). VIDA: Suma Asegurada (capital que reciben los beneficiarios), Beneficiarios con porcentaje (deben sumar 100% por tipo). AUTO: Marca, Modelo, Año, Placa del vehículo + Suma Asegurada y Deducible. HOGAR: Tipo de bien, Dirección, Valor del bien, Protecciones.'
      },
      {
        title: 'Tarifario Corporativo',
        detail: 'Para pólizas corporativas debes definir tres tarifas mensuales: Titular Solo (solo el empleado, sin familia), Titular +1 (empleado + 1 dependiente), Familia (empleado + 2 o más dependientes). Estas tarifas se usan para calcular automáticamente la prima mensual de cada afiliado corporativo.'
      },
      {
        title: 'Emails automáticos',
        detail: 'Al crear una nueva póliza, el sistema envía automáticamente un email de notificación al agente vendedor y a su supervisor Nivel 2 (si existe). Esto se puede activar/desactivar desde Configuración → Correos Automáticos.'
      }
    ]
  },
  {
    id: 'payments',
    icon: DollarSign,
    color: 'bg-emerald-500',
    title: 'Módulo: Pagos',
    content: `El módulo de Pagos permite registrar y dar seguimiento a las cuotas de cada póliza. Al crear una póliza individual, el sistema genera automáticamente el calendario de pagos.`,
    items: [
      {
        title: 'Generación automática de cuotas',
        detail: 'Cuando creas una póliza individual, el sistema genera automáticamente todas las cuotas según la frecuencia elegida. Ejemplo: Póliza mensual de $1,200 anuales a 12 meses → genera 12 cuotas de $100 cada una, con fecha de vencimiento mes a mes a partir de la vigencia.'
      },
      {
        title: 'Estados de pago',
        detail: 'Pendiente: cuota generada pero aún no pagada (y no vencida). Pagado: cuota registrada como cobrada. Atrasado: cuota cuya fecha de vencimiento ya pasó sin pago.'
      },
      {
        title: 'Cómo registrar un pago',
        detail: '1. Busca la póliza o cuota en el módulo Pagos. 2. Haz clic en "Registrar Pago". 3. Indica la fecha de pago efectivo, el monto y el método (efectivo, transferencia, tarjeta, cheque). 4. Guarda. El sistema actualiza el estado a "Pagado" y, si la compañía está configurada para ello, libera la comisión correspondiente.'
      },
      {
        title: 'Pagos atrasados',
        detail: 'El sistema marca automáticamente como "Atrasado" cualquier cuota cuya fecha de vencimiento haya pasado sin registrar pago. Aparecen en el Dashboard como alerta y en el módulo de Pagos filtrados como "Atrasados".'
      },
      {
        title: 'Cuotas de endoso',
        detail: 'Cuando se aprueba un endoso que modifica la prima, el sistema puede generar cuotas adicionales (o de diferencia) marcadas como "endorsement" para distinguirlas de las cuotas base de la póliza.'
      }
    ]
  },
  {
    id: 'claims',
    icon: Shield,
    color: 'bg-amber-500',
    title: 'Módulo: Siniestros',
    content: `El módulo de Siniestros permite registrar y dar seguimiento a los eventos de reclamación de las pólizas. Solo accesible para roles Admin, Gerencial y Operativo.`,
    items: [
      {
        title: 'Cómo registrar un siniestro',
        detail: '1. Ve al módulo "Siniestros". 2. Clic en "Nuevo Siniestro". 3. Busca la póliza afectada. 4. Selecciona la persona afectada (titular o dependiente). 5. Ingresa la fecha del evento, tipo de siniestro, monto reclamado. 6. Guarda con estado "En Proceso".'
      },
      {
        title: 'Estados de siniestro',
        detail: 'En Proceso: el siniestro está siendo tramitado. Aprobado: la compañía aprobó el pago. Rechazado: la compañía rechazó la reclamación. Pagado: el monto fue desembolsado al asegurado.'
      },
      {
        title: 'Siniestros corporativos',
        detail: 'Para pólizas corporativas, el sistema permite especificar qué afiliado (miembro corporativo) fue el afectado, además del titular de la póliza.'
      },
      {
        title: 'Seguimiento',
        detail: 'El monto reclamado y el monto pagado se registran por separado, permitiendo controlar la diferencia entre lo que el cliente reclamó y lo que efectivamente fue cubierto.'
      }
    ]
  },
  {
    id: 'renewals',
    icon: RefreshCw,
    color: 'bg-cyan-500',
    title: 'Módulo: Renovaciones',
    content: `El módulo de Renovaciones facilita la gestión proactiva del vencimiento de pólizas. El sistema detecta automáticamente las pólizas que están próximas a vencer y las muestra como oportunidades de renovación.`,
    items: [
      {
        title: 'Detección automática',
        detail: 'El sistema calcula diariamente las pólizas activas cuya fecha de fin está dentro de los próximos 60 días y las lista como "próximas a vencer". También detecta las que ya vencieron (hasta 30 días atrás) y las muestra como "vencidas sin renovar".'
      },
      {
        title: 'Proceso de renovación',
        detail: '1. En el módulo Renovaciones, ubica la póliza a renovar. 2. Haz clic en "Proponer Renovación". 3. Ingresa las nuevas fechas de vigencia y la nueva prima. 4. El sistema crea una "propuesta de renovación" en estado "Propuesta". 5. Cuando se confirme, el sistema crea automáticamente la nueva póliza, actualiza la póliza anterior a "Renovada" y genera el nuevo calendario de pagos.'
      },
      {
        title: 'Recordatorios automáticos',
        detail: 'Existe una automatización que envía emails de recordatorio de renovación a los agentes cuando sus pólizas están próximas a vencer. Esto se configura desde el Panel de Administración.'
      }
    ]
  },
  {
    id: 'commissions',
    icon: TrendingUp,
    color: 'bg-violet-500',
    title: 'Módulo: Comisiones',
    content: `El módulo de Comisiones calcula, controla y liquida las comisiones de los agentes. Es uno de los módulos más sofisticados del sistema.`,
    subsections: [
      {
        title: 'Cómo funciona el cálculo de comisiones',
        description: `Las comisiones se calculan por niveles jerárquicos. Cada nivel de la jerarquía de agentes puede tener un porcentaje diferente definido en la "Tabla de Comisiones" de cada compañía/ramo.

EJEMPLO: Si un agente vende una póliza de $1,000 de prima comisionable:
- Nivel 1 (agente vendedor): 10% = $100
- Nivel 2 (supervisor del agente): 3% = $30
- Nivel 3 (gerente estructura): 1% = $10

El sistema genera automáticamente un registro de comisión por cada nivel de la cadena jerárquica del agente vendedor.`
      },
      {
        title: 'Cuándo se generan las comisiones',
        description: `Depende de la configuración de la compañía aseguradora:
- Anualizada: la comisión de todo el año se genera de una sola vez cuando se registra el primer pago de la póliza.
- Según cliente: la comisión se genera proporcionalmente cada vez que el cliente paga una cuota.

Esto se configura en el módulo de Administración → Compañías, con los campos "Tipo pago nuevo negocio" y "Tipo pago renovación".`
      }
    ],
    items: [
      {
        title: 'Estados del workflow de comisiones',
        detail: 'Pendiente Liberar: comisión calculada pero el broker aún no ha cobrado a la aseguradora. Pendiente Pagar: el broker ya cobró a la aseguradora pero aún no pagó al agente. Pagada: el agente recibió su comisión.'
      },
      {
        title: 'Liquidación de comisiones',
        detail: 'La liquidación es el proceso de pasar comisiones de "Pendiente Pagar" a "Pagada". Se puede hacer de forma masiva (liquidación grupal) o individual por agente. El sistema genera un comprobante de liquidación descargable en PDF.'
      },
      {
        title: 'Tabla de Comisiones',
        detail: 'Antes de que el sistema calcule comisiones, debes configurar la Tabla de Comisiones en Administración → Tablas de Comisiones. Define: Compañía, Ramo, Nivel de agente y porcentaje de nuevo negocio vs renovación.'
      },
      {
        title: 'Asignación de comisiones a agentes',
        detail: 'Cada agente puede tener asignada una tabla de comisiones específica (puede ser diferente a la tabla estándar). Esto permite negociaciones personalizadas con agentes de alto rendimiento.'
      }
    ]
  },
  {
    id: 'tasks',
    icon: ClipboardList,
    color: 'bg-orange-500',
    title: 'Módulo: Tareas',
    content: `El módulo de Tareas es el gestor de actividades del equipo. Permite asignar, dar seguimiento y completar tareas relacionadas con la operación diaria.`,
    items: [
      {
        title: 'Crear una tarea',
        detail: '1. Ve a "Tareas" en el menú. 2. Clic en "Nueva Tarea". 3. Define: Título, Descripción, Fecha límite, Prioridad (Alta, Media, Baja) y a quién asignarla. 4. Opcionalmente puedes relacionarla con una póliza específica.'
      },
      {
        title: 'Prioridades',
        detail: 'Alta 🔴: debe atenderse de inmediato. Aparece destacada en rojo. Media 🟡: importante pero no urgente. Baja 🟢: puede esperar. El Dashboard de cada usuario muestra sus tareas pendientes ordenadas por prioridad y fecha.'
      },
      {
        title: 'Mis Tareas vs Gestión de Tareas',
        detail: '"Mis Tareas" muestra solo las tareas asignadas al usuario logueado. "Gestión de Tareas" (solo Admin y Jefatura) muestra todas las tareas del equipo y permite reasignarlas.'
      },
      {
        title: 'Notificaciones de tareas',
        detail: 'Cuando se te asigna una nueva tarea, el sistema envía una notificación automática por email. Las tareas vencidas (pasaron su fecha límite sin completarse) aparecen como alerta roja en el Dashboard.'
      }
    ]
  },
  {
    id: 'reports',
    icon: BarChart3,
    color: 'bg-rose-500',
    title: 'Módulo: Reportes',
    content: `El módulo de Reportes genera vistas y exportaciones analíticas de los datos del sistema.`,
    items: [
      {
        title: 'Reporte de Pólizas',
        detail: 'Listado completo de pólizas con filtros por: ramo, compañía, agente, estado, fecha de inicio/fin, tipo de póliza. Se puede exportar a Excel o CSV. Incluye: número de póliza, cliente, prima, fechas y estado.'
      },
      {
        title: 'Reporte de Producción',
        detail: 'Análisis de ventas por agente, ramo, compañía y período de tiempo. Muestra comparativas de producción y permite identificar tendencias de crecimiento o caída.'
      },
      {
        title: 'Reportes personalizados',
        detail: 'Puedes crear reportes a medida seleccionando qué columnas quieres ver y guardando la configuración como "Plantilla" para reutilizarla. Las plantillas son personales (solo las ves tú).'
      },
      {
        title: 'Mapa de ventas',
        detail: 'Visualización geográfica de la producción por país, útil para agencias con operación en varios países.'
      }
    ]
  },
  {
    id: 'agents',
    icon: Star,
    color: 'bg-yellow-500',
    title: 'Módulo: Agentes',
    content: `El módulo de Agentes gestiona la fuerza de ventas: agentes individuales y agencias.`,
    items: [
      {
        title: 'Tipos de agente',
        detail: 'Agente: persona natural que vende seguros. Agencia: entidad que agrupa a varios agentes.'
      },
      {
        title: 'Jerarquía de agentes (Upline)',
        detail: 'Cada agente puede tener un "upline" (agente superior). Esto define la cadena jerárquica para el cálculo de comisiones. Ejemplo: Agente A → Supervisor B → Director C. Cuando el Agente A vende, las comisiones se distribuyen a A, B y C según sus niveles.'
      },
      {
        title: 'Niveles especiales',
        detail: 'Nivel 2: agente con categoría de supervisor. Recibe copia de los emails de nuevas pólizas de sus agentes. GAPartner: categoría especial de asociado con condiciones diferentes.'
      },
      {
        title: 'Dashboard del agente',
        detail: 'Los usuarios con rol "agente" tienen acceso a un Dashboard personalizado que muestra solo sus pólizas, comisiones y tareas. No pueden ver datos de otros agentes.'
      },
      {
        title: 'Costos del agente',
        detail: 'El sistema permite registrar costos asociados a cada agente (gastos operativos, capacitaciones, etc.) para calcular la rentabilidad neta por agente.'
      }
    ]
  },
  {
    id: 'endorsements',
    icon: Zap,
    color: 'bg-lime-500',
    title: 'Módulo: Endosos',
    content: `Los endosos son modificaciones a una póliza existente que cambian alguna condición de cobertura o prima.`,
    items: [
      {
        title: 'Tipos de endoso',
        detail: 'Aumento de prima, Reducción de prima, Cancelación, Cambio de beneficiarios, Cambio de cobertura, Inclusión de dependiente, Exclusión de dependiente, Cambio de datos, Otro.'
      },
      {
        title: 'Cómo crear un endoso',
        detail: '1. Ve a la póliza afectada (módulo Pólizas → clic en la póliza). 2. En la ficha de la póliza, ve a la pestaña "Endosos". 3. Clic en "Nuevo Endoso". 4. Selecciona el tipo, fecha del endoso y fecha efectiva del cambio. 5. Si cambia la prima, ingresa la prima anterior y la nueva. El sistema calcula automáticamente la diferencia.'
      },
      {
        title: 'Cálculo de diferencia de prima',
        detail: 'Si un endoso cambia la prima anual, el sistema calcula la diferencia proporcional al período restante de la póliza (desde la fecha efectiva hasta el fin de vigencia). Ejemplo: Quedan 6 meses de 12 → diferencia proporcional = 50% de la diferencia anual.'
      },
      {
        title: 'Cuotas de endoso',
        detail: 'Si el endoso genera una diferencia de prima, el sistema puede generar cuotas adicionales para cobrar/devolver esa diferencia al cliente.'
      }
    ]
  },
  {
    id: 'corporate',
    icon: Building2,
    color: 'bg-sky-500',
    title: 'Pólizas Corporativas - Detalle',
    content: `Las pólizas corporativas tienen un flujo de trabajo especial porque la prima no es fija — varía según el número de afiliados activos cada mes.`,
    items: [
      {
        title: 'Afiliados corporativos (Miembros)',
        detail: 'Desde la ficha de una póliza corporativa, puedes gestionar los "Miembros" (empleados y sus familias). Cada miembro es un "Titular" que puede tener sus propios dependientes (familia).'
      },
      {
        title: 'Categorías de cobertura',
        detail: 'El sistema calcula automáticamente la categoría de cada titular según sus dependientes: Titular Solo (sin dependientes), Titular +1 (un dependiente), Familia (2 o más dependientes). Esta categoría determina la tarifa mensual a cobrar.'
      },
      {
        title: 'Cálculo de prima mensual corporativa',
        detail: 'Cada mes, la prima se calcula sumando: (Nº de titulares solos × Tarifa Solo) + (Nº de titulares+1 × Tarifa +1) + (Nº de familias × Tarifa Familia). El resultado es la factura mensual que se cobra al contratante.'
      },
      {
        title: 'Facturación corporativa',
        detail: 'Desde la ficha de la póliza corporativa puedes generar la factura mensual con el detalle de todos los afiliados y sus tarifas. Esta factura se puede exportar.'
      }
    ]
  },
  {
    id: 'admin',
    icon: Settings,
    color: 'bg-muted-foreground',
    title: 'Panel de Administración',
    content: `El Panel de Administración (accesible para Admin y Jefatura) permite configurar todos los catálogos y parámetros del sistema.`,
    items: [
      {
        title: 'Ramos (InsuranceLine)',
        detail: 'Configura los ramos de seguro disponibles (Salud, Vida, Auto, Hogar, Viajes, etc.). Los ramos activos aparecen en el formulario de nueva póliza.'
      },
      {
        title: 'Compañías (InsuranceCompany)',
        detail: 'Registra las aseguradoras con las que trabaja la agencia. Debes asociar qué ramos trabaja cada compañía. También configuras aquí el tipo de pago de comisiones (anualizado vs según cliente) y si la compañía paga directamente a los agentes.'
      },
      {
        title: 'Productos',
        detail: 'Cada compañía tiene productos específicos por ramo. El producto define: nombre comercial, categoría (Individual/Corporativa), monto asegurado y opciones de deducibles para salud.'
      },
      {
        title: 'Tablas de Comisiones',
        detail: 'Define los porcentajes de comisión por compañía, ramo y nivel jerárquico. Separa los porcentajes de nuevo negocio vs renovación. Es fundamental configurar esto antes de usar el módulo de Comisiones.'
      },
      {
        title: 'Branches (Sucursales)',
        detail: 'Permite organizar la operación por sucursales o regiones. Las compañías se asocian a un branch.'
      },
      {
        title: 'Usuarios y roles',
        detail: 'Gestiona los usuarios del sistema: invita nuevos usuarios, asigna roles y vincula cada usuario con su agente correspondiente (si aplica).'
      },
      {
        title: 'Correos automáticos',
        detail: 'Activa o desactiva el envío automático de emails al crear nuevas pólizas. También puedes ver el log de todos los correos enviados.'
      },
      {
        title: 'Presupuestos (Budgets)',
        detail: 'Define metas de producción por compañía y período. El sistema compara la producción real vs el presupuesto y muestra el porcentaje de cumplimiento.'
      },
      {
        title: 'Metas de ventas',
        detail: 'Similar a presupuestos pero a nivel de agente. Define cuánto debe producir cada agente en un período y monitorea el avance.'
      }
    ]
  },
  {
    id: 'documents',
    icon: FileText,
    color: 'bg-fuchsia-500',
    title: 'Documentos',
    content: `El sistema permite adjuntar documentos a pólizas, clientes, pagos, siniestros y endosos.`,
    items: [
      {
        title: 'Tipos de documento',
        detail: 'Certificado de seguro, Endoso, Pago escaneado, Recibo, Póliza original, Identificación, Evidencia de siniestro, Informe médico, Factura, Otro.'
      },
      {
        title: 'Cómo subir un documento',
        detail: '1. Ve a la póliza o cliente donde quieres adjuntar el archivo. 2. En la pestaña "Documentos", clic en "Subir Documento". 3. Selecciona el archivo (PDF, JPG, PNG). 4. Elige el tipo de documento. 5. El archivo se sube a Azure Storage y queda disponible para descarga en cualquier momento.'
      },
      {
        title: 'Versionado',
        detail: 'Puedes subir versiones actualizadas de un documento. El sistema conserva el historial de versiones y marca cuál es la versión actual.'
      },
      {
        title: 'Herencia de documentos',
        detail: 'En renovaciones, los documentos de la póliza original se heredan automáticamente a la nueva póliza para mantener el historial completo.'
      }
    ]
  },
  {
    id: 'messaging',
    icon: MessageSquare,
    color: 'bg-pink-500',
    title: 'Módulo: Mensajería',
    content: `El módulo de Mensajería permite la comunicación interna entre los usuarios del portal.`,
    items: [
      {
        title: 'Tipos de conversación',
        detail: 'General: conversación libre entre usuarios. Por Póliza: conversación asociada a una póliza específica (el número de póliza aparece como referencia). Por Tarea: conversación sobre una tarea específica.'
      },
      {
        title: 'Menciones (@)',
        detail: 'Puedes mencionar a usuarios con @ en los mensajes. El usuario mencionado recibirá una notificación.'
      },
      {
        title: 'Indicador de no leídos',
        detail: 'En la barra de navegación aparece un punto rojo cuando tienes mensajes sin leer.'
      }
    ]
  },
  {
    id: 'search',
    icon: Target,
    color: 'bg-slate-600',
    title: 'Búsqueda Global',
    content: `El sistema tiene una búsqueda global que puedes activar con el ícono de lupa en la barra de navegación, o con el atajo de teclado Ctrl+K (Cmd+K en Mac).`,
    items: [
      {
        title: 'Qué puedes buscar',
        detail: 'La búsqueda global encuentra: Pólizas por número, Clientes por nombre o documento, Agentes por nombre, Pagos y Siniestros. Los resultados aparecen categorizados y al hacer clic te lleva directamente al registro.'
      }
    ]
  }
];

function SectionCard({ section, isOpen, onToggle }) {
  const Icon = section.icon;
  return (
    <Card className="border border-border overflow-hidden">
      <button
        className="w-full text-left"
        onClick={onToggle}
      >
        <CardHeader className="py-4 px-6 hover:bg-muted/40 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`${section.color} p-2 rounded-lg`}>
                <Icon className="h-5 w-5 text-white" />
              </div>
              <CardTitle className="text-base font-semibold text-foreground">{section.title}</CardTitle>
            </div>
            {isOpen ? <ChevronDown className="h-4 w-4 text-muted-foreground/70" /> : <ChevronRight className="h-4 w-4 text-muted-foreground/70" />}
          </div>
        </CardHeader>
      </button>

      {isOpen && (
        <CardContent className="px-6 pb-6 pt-0 space-y-5">
          {section.content && (
            <p className="text-muted-foreground text-sm leading-relaxed whitespace-pre-line">{section.content}</p>
          )}

          {section.subsections && (
            <div className="space-y-3">
              {section.subsections.map((sub, i) => (
                <div key={i} className="bg-muted border border-blue-100 rounded-lg p-4">
                  <h4 className="font-semibold text-foreground text-sm mb-1">{sub.title}</h4>
                  <p className="text-foreground text-sm leading-relaxed whitespace-pre-line">{sub.description}</p>
                </div>
              ))}
            </div>
          )}

          {section.items && (
            <div className="space-y-3">
              {section.items.map((item, i) => (
                <div key={i} className="flex gap-3">
                  <div className="mt-0.5 flex-shrink-0">
                    <CheckCircle className="h-4 w-4 text-emerald-500" />
                  </div>
                  <div>
                    <span className="font-semibold text-foreground text-sm">{item.title}: </span>
                    <span className="text-muted-foreground text-sm leading-relaxed">{item.detail}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
}

export default function UserManual() {
  const [openSections, setOpenSections] = useState({ intro: true, roles: true });

  const toggleSection = (id) => {
    setOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const openAll = () => {
    const all = {};
    sections.forEach(s => { all[s.id] = true; });
    setOpenSections(all);
  };

  const closeAll = () => setOpenSections({});

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-brand-deep via-brand-mid to-brand-deep rounded-xl p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="h-8 w-8 text-brand-soft" />
            <div>
              <h1 className="text-2xl font-bold">Manual de Usuario — InsurDesk</h1>
              <p className="text-slate-300 text-sm">Guía completa de uso del sistema de gestión de seguros</p>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge className="bg-brand-soft/20 text-brand-soft border border-brand-soft/30">v1.0</Badge>
            <Badge className="bg-white/10 text-white border border-white/20">Abril 2026</Badge>
          </div>
        </div>

        {/* Quick Nav */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold text-foreground/80 flex items-center gap-2">
                <Info className="h-4 w-4 text-foreground" />
                Navega por el manual
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={openAll}>Expandir todo</Button>
                <Button variant="outline" size="sm" onClick={closeAll}>Colapsar todo</Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {sections.map(s => {
                const Icon = s.icon;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      setOpenSections(prev => ({ ...prev, [s.id]: true }));
                      setTimeout(() => {
                        document.getElementById(`section-${s.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }, 100);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-muted hover:bg-secondary rounded-full text-xs text-foreground/80 transition-colors"
                  >
                    <Icon className="h-3 w-3" />
                    {s.title.replace('Módulo: ', '')}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Tip */}
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 flex gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-600 dark:text-amber-400">
            <strong>Consejo:</strong> Lee primero las secciones "¿Qué es InsurDesk?", "Roles de Usuario" y "Dashboard" para entender la estructura del sistema. Luego ve directamente al módulo que necesitas usar.
          </div>
        </div>

        {/* Sections */}
        <div className="space-y-3">
          {sections.map(section => (
            <div key={section.id} id={`section-${section.id}`}>
              <SectionCard
                section={section}
                isOpen={!!openSections[section.id]}
                onToggle={() => toggleSection(section.id)}
              />
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="text-center text-sm text-muted-foreground/70 pb-6">
          Manual de Usuario InsurDesk — Generado automáticamente. Para soporte, contacta al administrador del sistema.
        </div>
      </div>
    </div>
  );
}