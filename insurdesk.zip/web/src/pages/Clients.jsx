import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import ClientForm from '@/components/forms/ClientForm';
import { useSearchCache } from '@/components/SearchCache';
import { Users, Plus, Eye, Pencil, Trash2, Loader2, X } from 'lucide-react';
import { exportToCSV, exportToExcel } from '@/components/ui/exportUtils';
import DeleteSafetyDialog from '@/components/ui/DeleteSafetyDialog';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function Clients() {
  const { t } = useTranslation();
  const { searchQuery, updateSearch, clearSearch } = useSearchCache('clients');
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [clientToDelete, setClientToDelete] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  // Duplicate warning dialog
  const [duplicateDialogOpen, setDuplicateDialogOpen] = useState(false);
  const [pendingClientData, setPendingClientData] = useState(null);
  const [duplicateName, setDuplicateName] = useState('');



  useEffect(() => {
    loadClients();
    
    // Check if we should open the form automatically
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'new') {
      setEditingClient(null);
      setFormOpen(true);
    }
  }, []);

  const loadClients = async () => {
    setLoading(true);
    const currentUser = await api.auth.me();
    setCurrentUser(currentUser);
    
    // Get agent structure if user is an agent
    let allowedAgentIds = [];
    if (currentUser.app_role === 'agente' && currentUser.agent_id) {
      allowedAgentIds = await getAgentStructure(currentUser.agent_id);
    }
    
    const clientsData = await api.entities.Client.list('-created_date');
    
    // Filter clients for agents - only clients with policies from their structure
    let filteredClients = clientsData;
    if (currentUser.app_role === 'agente' && allowedAgentIds.length > 0) {
      const policies = await api.entities.Policy.list();
      const clientIdsWithPolicies = new Set(
        policies
          .filter(p => allowedAgentIds.includes(p.agent_id))
          .map(p => p.client_id)
      );
      filteredClients = clientsData.filter(c => clientIdsWithPolicies.has(c.id));
    }
    
    setClients(filteredClients);
    setLoading(false);
  };

  const getAgentStructure = async (agentId) => {
    const agents = await api.entities.Agent.list();
    const structure = [agentId];
    
    const findDownline = (id) => {
      const downline = agents.filter(a => a.upline_agent_id === id);
      downline.forEach(agent => {
        structure.push(agent.id);
        findDownline(agent.id);
      });
    };
    
    findDownline(agentId);
    return structure;
  };

  const handleSubmit = async (data) => {
    if (saving) return; // guard against double submit
    setSaving(true);
    try {
      if (editingClient) {
        await api.entities.Client.update(editingClient.id, data);
      } else {
        // Check for duplicate by exact name
        const fullName = data.client_type === 'persona'
          ? `${data.first_name || ''} ${data.last_name || ''}`.trim().toUpperCase()
          : (data.company_name || '').trim().toUpperCase();

        const duplicate = clients.find(c => {
          const existingName = c.client_type === 'persona'
            ? `${c.first_name || ''} ${c.last_name || ''}`.trim().toUpperCase()
            : (c.company_name || '').trim().toUpperCase();
          return existingName === fullName && fullName !== '';
        });

        if (duplicate) {
          setSaving(false);
          setPendingClientData(data);
          setDuplicateName(fullName);
          setDuplicateDialogOpen(true);
          return;
        }

        await api.entities.Client.create(data);
      }
      setFormOpen(false);
      setEditingClient(null);
      loadClients();
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (client) => {
    setEditingClient(client);
    setFormOpen(true);
  };

  const checkClientUsage = async () => {
    const policies = await api.entities.Policy.filter({ client_id: clientToDelete.id });
    const policyIds = policies.map(p => p.id);

    // Only fetch claims/commissions if there are policies
    const [claims, allCommissions] = await Promise.all([
      api.entities.Claim.filter({ client_id: clientToDelete.id }),
      policyIds.length > 0 ? api.entities.Commission.list() : Promise.resolve([]),
    ]);

    // Commissions linked to this client's policies with status "pagada"
    const settledCommissions = allCommissions.filter(
      c => policyIds.includes(c.policy_id) && c.status === 'pagada'
    );

    const usageItems = [];

    const activePolicies = policies.filter(p => p.status === 'activa');
    if (activePolicies.length > 0) {
      usageItems.push({ label: 'Pólizas activas', count: activePolicies.length, detail: 'El cliente tiene pólizas con vigencia activa.' });
    } else if (policies.length > 0) {
      usageItems.push({ label: 'Pólizas (vencidas/canceladas)', count: policies.length, detail: 'El cliente tiene historial de pólizas en el sistema.' });
    }

    if (settledCommissions.length > 0) {
      usageItems.push({ label: 'Comisiones liquidadas', count: settledCommissions.length, detail: 'El cliente tiene comisiones pagadas asociadas a sus pólizas.' });
    }

    if (claims.length > 0) {
      usageItems.push({ label: 'Siniestros registrados', count: claims.length, detail: 'Reclamaciones asociadas a este cliente.' });
    }

    return { usageItems };
  };

  const handleDeleteClient = async () => {
    await api.entities.Client.delete(clientToDelete.id);
    setClientToDelete(null);
    loadClients();
  };

  const handleConfirmDuplicate = async () => {
    setSaving(true);
    await api.entities.Client.create(pendingClientData);
    setDuplicateDialogOpen(false);
    setPendingClientData(null);
    setSaving(false);
    setFormOpen(false);
    setEditingClient(null);
    loadClients();
  };

  const getClientName = (client) => {
    return client.client_type === 'persona' 
      ? `${client.first_name || ''} ${client.last_name || ''}`.trim() 
      : client.company_name || '';
  };

  const columns = [
    {
      header: 'Cliente',
      cell: (row) => (
        <Link to={createPageUrl(`ClientDetail?id=${row.id}`)} className="block group">
          <p className="font-medium text-foreground group-hover:text-foreground transition-colors">{getClientName(row)}</p>
          <p className="text-sm text-muted-foreground">{row.document_id}</p>
        </Link>
      )
    },
    {
      header: 'Tipo',
      cell: (row) => (
        <span className="capitalize">{row.client_type}</span>
      )
    },
    {
      header: 'Contacto',
      cell: (row) => (
        <div>
          <p className="text-sm">{row.email}</p>
          <p className="text-sm text-muted-foreground">{row.phone}</p>
        </div>
      )
    },
    {
      header: 'Ubicación',
      cell: (row) => (
        <div>
          <p className="text-sm">{row.city}</p>
          <p className="text-sm text-muted-foreground">{row.country}</p>
        </div>
      )
    },
    {
      header: 'Estado',
      cell: (row) => <StatusBadge status={row.status} />
    },
    {
      header: 'Acciones',
      cell: (row) => {
        const canDelete = currentUser?.role === 'admin' || currentUser?.app_role === 'admin';
        return (
          <div className="flex items-center gap-1">
            <Link to={createPageUrl(`ClientDetail?id=${row.id}`)}>
              <Button variant="ghost" size="icon" title="Ver detalle">
                <Eye className="h-4 w-4" />
              </Button>
            </Link>
            {currentUser?.app_role !== 'agente' && (
              <Button variant="ghost" size="icon" title="Editar" onClick={() => handleEdit(row)}>
                <Pencil className="h-4 w-4" />
              </Button>
            )}
            {canDelete && (
              <Button
                variant="ghost"
                size="icon"
                title="Eliminar"
                onClick={() => { setClientToDelete(row); setDeleteDialogOpen(true); }}
              >
                <Trash2 className="h-4 w-4 text-red-500" />
              </Button>
            )}
          </div>
        );
      }
    }
  ];

  const getExportData = () => ({
    headers: ['Nombre', 'Tipo', 'Documento', 'Email', 'Teléfono', 'País', 'Ciudad', 'Estado'],
    rows: clients.map(c => [
      getClientName(c), c.client_type, c.document_id, c.email, c.phone, c.country, c.city, c.status
    ]),
    filename: 'clientes'
  });

  const handleExportCSV = () => exportToCSV(getExportData());
  const handleExportExcel = () => exportToExcel({ ...getExportData(), sheetName: 'Clientes' });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <BackButton className="mt-1" />
          <div className="flex-1">
            <PageHeader
              title={t('clients.title')}
              subtitle={`${clients.length} ${t('clients.title').toLowerCase()}`}
              icon={Users}
              actions={
                currentUser?.app_role !== 'agente' && (
                  <Button onClick={() => { setEditingClient(null); setFormOpen(true); }} className="gap-2">
                    <Plus className="h-4 w-4" /> {t('clients.new')}
                  </Button>
                )
              }
            />
          </div>
        </div>

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            columns={columns}
            data={clients}
            searchPlaceholder={`${t('common.search')}...`}
            searchKeys={['first_name', 'last_name', 'company_name', 'document_id', 'email', 'phone', 'city', 'country']}
            initialSearch={searchQuery}
            onSearchChange={updateSearch}
            exportable
            onExport={handleExportCSV}
            onExportExcel={handleExportExcel}
            emptyMessage={t('common.noData')}
            actions={
              searchQuery && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={clearSearch}
                  className="text-muted-foreground hover:text-foreground/80 gap-1"
                >
                  <X className="h-4 w-4" /> Limpiar búsqueda
                </Button>
              )
            }
          />
        </Card>

        <ClientForm
          open={formOpen}
          onOpenChange={setFormOpen}
          onSubmit={handleSubmit}
          initialData={editingClient}
          isLoading={saving}
        />

        <DeleteSafetyDialog
          open={deleteDialogOpen}
          onOpenChange={(open) => { setDeleteDialogOpen(open); if (!open) setClientToDelete(null); }}
          title="Eliminar cliente"
          entityDescription={clientToDelete ? `el cliente "${getClientName(clientToDelete)}"` : 'este cliente'}
          checkUsage={clientToDelete ? checkClientUsage : null}
          onConfirm={handleDeleteClient}
        />

        {/* Duplicate name warning */}
        <DeleteSafetyDialog
          open={duplicateDialogOpen}
          onOpenChange={(open) => { setDuplicateDialogOpen(open); if (!open) setPendingClientData(null); }}
          title="Cliente duplicado"
          entityDescription={`el cliente "${duplicateName}"`}
          checkUsage={async () => ({ usageItems: [{ label: 'Nombre duplicado', count: 1, detail: `Ya existe un cliente con el nombre "${duplicateName}".` }] })}
          onConfirm={handleConfirmDuplicate}
        />
      </div>
    </div>
  );
}