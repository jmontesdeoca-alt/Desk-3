import React, { useState } from 'react';
import { Check, X, Infinity as InfinityIcon, KeyRound, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import PageHeader from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useFeatures } from '@/lib/FeatureContext';
import { useAuth } from '@/lib/AuthContext';
import { appParams } from '@/lib/app-params';

export default function PlanSettings() {
  const { planName, tagline, customer, expires, source, warning, features, reload } = useFeatures();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.app_role === 'admin';
  const [key, setKey] = useState('');
  const [saving, setSaving] = useState(false);

  const install = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${appParams.apiUrl}/api/license`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${appParams.token}` }, body: JSON.stringify({ key }) });
      const j = await res.json();
      if (!res.ok) throw new Error(j.message || 'Licencia inválida');
      toast.success(`Plan actualizado: ${j.planName}`);
      setKey(''); await reload();
    } catch (e) { toast.error(e.message); } finally { setSaving(false); }
  };

  const list = Object.entries(features || {});
  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <PageHeader title="Plan y módulos" subtitle="Funciones incluidas en tu licencia" icon={ShieldCheck} backTo="AdminPanel" />

      <Card className="p-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs text-muted-foreground">Plan activo</p>
          <p className="text-2xl font-semibold tracking-tight">{planName || '—'}</p>
          <p className="text-sm text-muted-foreground">{tagline}{customer ? ` · ${customer}` : ''}</p>
        </div>
        <div className="text-right text-sm text-muted-foreground">
          {expires ? <p>Vence: {new Date(expires).toLocaleDateString('es-EC')}</p> : <p>Sin vencimiento</p>}
          {source === 'unlicensed' && <Badge variant="outline" className="mt-1 border-amber-500/40 text-amber-500">Sin licencia instalada</Badge>}
          {source === 'env' && <Badge variant="outline" className="mt-1">Modo desarrollo</Badge>}
        </div>
      </Card>
      {warning && <p className="text-sm text-amber-500">⚠ {warning}</p>}

      <Card className="divide-y divide-border">
        {list.map(([k, f]) => (
          <div key={k} className="flex items-start gap-3 p-4">
            <div className={`mt-0.5 h-6 w-6 rounded-full grid place-items-center shrink-0 ${f.enabled ? 'bg-emerald-500/15 text-emerald-500' : 'bg-muted text-muted-foreground'}`}>
              {f.enabled ? <Check className="h-3.5 w-3.5" /> : <X className="h-3.5 w-3.5" />}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium">{f.name}{f.external && <Badge variant="outline" className="ml-2 text-[10px]">módulo externo</Badge>}</p>
              <p className="text-xs text-muted-foreground">{f.description}</p>
            </div>
            {f.type === 'limit' && (
              <span className="text-sm font-medium inline-flex items-center gap-1 shrink-0">
                {f.limit === null ? <><InfinityIcon className="h-4 w-4" /> ilimitado</> : f.limit <= 1 ? 'sin estructura' : `hasta ${f.limit} ${f.unit}`}
              </span>
            )}
          </div>
        ))}
      </Card>

      {isAdmin && (
        <Card className="p-5 space-y-3">
          <div className="flex items-center gap-2"><KeyRound className="h-4 w-4 text-muted-foreground" /><p className="text-sm font-medium">Instalar o cambiar de licencia</p></div>
          <p className="text-xs text-muted-foreground">Pega la clave que te entregó tu proveedor (empieza con GA1.). Se aplica de inmediato, sin reiniciar.</p>
          <Textarea value={key} onChange={(e) => setKey(e.target.value)} placeholder="GA1.eyJ2IjoxLC..." className="font-mono text-xs normal-case min-h-[84px]" />
          <Button onClick={install} disabled={saving || !key.trim()}>{saving ? 'Verificando…' : 'Aplicar licencia'}</Button>
        </Card>
      )}
    </div>
  );
}
