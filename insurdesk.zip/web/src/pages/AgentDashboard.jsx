import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import StatCard from '@/components/ui/StatCard';
import StatusBadge from '@/components/ui/StatusBadge';
import AgentCalendar from '@/components/calendar/AgentCalendar';
import { 
  FileText, DollarSign, TrendingUp, Bell, AlertTriangle, 
  Calendar, Loader2, Eye, RefreshCw, Clock
} from 'lucide-react';
import { differenceInDays } from 'date-fns';
import { es } from 'date-fns/locale';
import { formatDate, parseLocalDate } from '@/lib/dateUtils';
import { loadTRMsForPolicies, convertToUSD } from '@/lib/currencyConversion';
import { formatMoney } from '@/lib/formatMoney';

export default function AgentDashboard() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [policies, setPolicies] = useState([]);
  const [agents, setAgents] = useState([]);
  const [ownAgentId, setOwnAgentId] = useState(null);
  const [commissions, setCommissions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [renewals, setRenewals] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [trmMap, setTrmMap] = useState(new Map());

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);

    const [currentUser, userRoleResponse] = await Promise.all([
      api.auth.me(),
      api.functions.invoke('getUserRoleInfo', {})
    ]);

    const userRoleInfo = userRoleResponse?.data;
    const agentId = userRoleInfo?.agent_id || currentUser?.data?.agent_id;

    const enrichedUser = {
      ...currentUser,
      app_role: userRoleInfo?.app_role,
      agent_id: agentId,
    };
    setUser(enrichedUser);
    setOwnAgentId(agentId);

    if (!agentId) {
      setLoading(false);
      return;
    }

    // Use backend to get full hierarchy + all structure policies (bypasses RLS)
    const hierarchyResponse = await api.functions.invoke('getAgentHierarchy', {
      agentId,
      includePolicies: true
    });
    const agentIds = hierarchyResponse?.data?.agentIds || [agentId];
    const policiesData = hierarchyResponse?.data?.policies || [];

    const [agentsData, commissionsData, notificationsData, renewalsData, tasksData] = await Promise.all([
      api.entities.Agent.list(),
      api.entities.Commission.filter({ agent_id: { $in: agentIds } }),
      api.entities.Notification.list('-created_date'),
      api.entities.Renewal.list('-created_date'),
      api.entities.Task.list()
    ]);

    setPolicies(policiesData);
    setAgents(agentsData);
    setCommissions(commissionsData);
    setTasks(tasksData);

    // Cargar TRMs para conversión COP → USD
    const trmMap = await loadTRMsForPolicies(policiesData);
    setTrmMap(trmMap);
    
    const userNotifications = notificationsData.filter(n => 
      n.recipient_email === currentUser.email || n.recipient_id === agentId
    ).slice(0, 5);
    setNotifications(userNotifications);

    const agentRenewals = renewalsData.filter(r => {
      const policy = policiesData.find(p => p.id === r.original_policy_id);
      return policy !== undefined;
    });
    setRenewals(agentRenewals);

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  // Calculate metrics
    const today = new Date();
  today.setHours(0, 0, 0, 0);
  const activePolicies = policies.filter(p => p.status === 'activa').length;
  const expiredPolicies = policies.filter(p => p.status === 'vencida').length;
  const atRiskPolicies = policies.filter(p => p.status === 'en_riesgo').length;
  
  // Mapa de pólizas para obtener currency/issue_date desde comisiones
  const policyMap = new Map(policies.map(p => [p.id, p]));

  const totalPremiums = policies
    .filter(p => p.status === 'activa')
    .reduce((sum, p) => sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0);

  // Primas año en curso: nuevos negocios activos desde el 1/1 del año actual hasta hoy
  const currentYear = today.getFullYear();
  const yearStart = new Date(currentYear, 0, 1); // 1/1 del año en curso
  const yearPremiums = policies
    .filter(p => {
      if (p.policy_type !== 'nuevo_negocio') return false;
      if (p.status !== 'activa') return false;
      if (!p.start_date) return false;
      const startDate = parseLocalDate(p.start_date);
      return startDate >= yearStart && startDate <= today;
    })
    .reduce((sum, p) => sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0);

  const pendingCommissions = commissions
    .filter(c => c.status === 'pendiente_pagar')
    .reduce((sum, c) => {
      const policy = policyMap.get(c.policy_id);
      return sum + convertToUSD(c.commission_amount || 0, c.currency || policy?.currency, policy?.issue_date, trmMap);
    }, 0);

  const paidCommissions = commissions
    .filter(c => c.status === 'pagada')
    .reduce((sum, c) => {
      const policy = policyMap.get(c.policy_id);
      return sum + convertToUSD(c.commission_amount || 0, c.currency || policy?.currency, policy?.issue_date, trmMap);
    }, 0);

  const unreadNotifications = notifications.filter(n => !n.read).length;

  // Policies expiring soon
  const expiringPolicies = policies.filter(p => {
    if (!p.end_date || p.status !== 'activa') return false;
    const daysUntilEnd = differenceInDays(parseLocalDate(p.end_date), today);
    return daysUntilEnd > 0 && daysUntilEnd <= 60;
  }).sort((a, b) => parseLocalDate(a.end_date) - parseLocalDate(b.end_date));

  const recentPolicies = policies
    .filter(p => p.status === 'activa')
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 10);

  // Build a consistent color map per agent_id for visual differentiation
  const AGENT_COLORS = [
    'bg-primary', 'bg-emerald-500', 'bg-violet-500', 'bg-orange-500',
    'bg-pink-500', 'bg-teal-500', 'bg-indigo-500', 'bg-rose-500',
    'bg-cyan-500', 'bg-amber-500', 'bg-lime-500', 'bg-fuchsia-500',
  ];
  const agentColorMap = {};
  let colorIdx = 0;
  policies.forEach(p => {
    if (p.agent_id && !(p.agent_id in agentColorMap)) {
      agentColorMap[p.agent_id] = AGENT_COLORS[colorIdx % AGENT_COLORS.length];
      colorIdx++;
    }
  });

  const currency = 'USD';

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Mi Dashboard
          </h1>
          <p className="text-muted-foreground">Bienvenido, {user?.full_name}</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
          <StatCard
            title="Pólizas Activas"
            value={activePolicies}
            icon={FileText}
            iconBg="bg-brand-soft/20"
            iconColor="text-brand"
          />
          <StatCard
            title="Primas Anuales"
            value={`${currency} ${formatMoney(totalPremiums)}`}
            icon={DollarSign}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-600 dark:text-emerald-400"
          />
          <StatCard
            title={`Primas ${currentYear}`}
            value={`${currency} ${formatMoney(yearPremiums)}`}
            icon={TrendingUp}
            iconBg="bg-violet-500/10"
            iconColor="text-violet-600 dark:text-violet-400"
          />
          <StatCard
            title="Comisiones Pendientes"
            value={`${currency} ${formatMoney(pendingCommissions)}`}
            icon={Clock}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-600 dark:text-amber-400"
          />
          <StatCard
            title="Comisiones Pagadas"
            value={`${currency} ${formatMoney(paidCommissions)}`}
            icon={TrendingUp}
            iconBg="bg-brand-strong/10"
            iconColor="text-brand-strong"
          />
        </div>

        {/* Alerts */}
        {(expiringPolicies.length > 0 || atRiskPolicies > 0) && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
            {expiringPolicies.length > 0 && (
              <Card className="border-l-4 border-l-amber-500 bg-amber-50/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2 text-amber-600 dark:text-amber-400">
                    <Calendar className="h-5 w-5" />
                    Próximas Renovaciones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mb-1">
                    {expiringPolicies.length}
                  </p>
                  <p className="text-sm text-amber-600 dark:text-amber-400">
                    pólizas vencen en los próximos 60 días
                  </p>
                  <Link to={createPageUrl('Renewals')}>
                    <Button size="sm" className="mt-3 bg-amber-600 hover:bg-amber-700">
                      Ver Renovaciones
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}

            {atRiskPolicies > 0 && (
              <Card className="border-l-4 border-l-red-500 bg-red-50/50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2 text-red-600 dark:text-red-400">
                    <AlertTriangle className="h-5 w-5" />
                    Pólizas en Riesgo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-red-600 dark:text-red-400 mb-1">
                    {atRiskPolicies}
                  </p>
                  <p className="text-sm text-red-600 dark:text-red-400">
                    pólizas requieren atención inmediata
                  </p>
                  <Link to={createPageUrl('Policies')}>
                    <Button size="sm" variant="destructive" className="mt-3">
                      Ver Pólizas
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Calendar */}
        <Card className="border-0 shadow-sm mb-6">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="h-5 w-5 text-brand" />
              Calendario de Tareas y Renovaciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <AgentCalendar tasks={tasks} policies={policies} agents={agents} ownAgentId={ownAgentId} />
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Policies */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Pólizas Recientes</CardTitle>
                <Link to={createPageUrl('Policies')}>
                  <Button variant="outline" size="sm" disabled>Ver Todas (Solo lectura)</Button>
                </Link>
              </CardHeader>
              <CardContent>
                {recentPolicies.length === 0 ? (
                  <p className="text-center text-muted-foreground/70 py-8">No hay pólizas activas</p>
                ) : (
                  <div className="space-y-3">
                    {recentPolicies.map(policy => {
                      const isOwn = policy.agent_id === ownAgentId;
                      const dotColor = agentColorMap[policy.agent_id] || 'bg-muted-foreground/50';
                      return (
                        <div key={policy.id} className={`p-3 rounded-lg hover:bg-muted transition-colors border-l-4 ${dotColor.replace('bg-', 'border-l-')} bg-muted/40`}>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <Link 
                                  to={createPageUrl(`PolicyDetail?id=${policy.id}`)}
                                  className="font-semibold text-brand hover:underline"
                                >
                                  {policy.policy_number}
                                </Link>
                                <StatusBadge status={policy.status} />
                              </div>
                              <p className="text-sm text-muted-foreground">{policy.client_name}</p>
                              <div className="flex items-center gap-1 mt-0.5">
                                <div className={`w-2 h-2 rounded-full ${dotColor}`}></div>
                                <p className="text-xs text-muted-foreground">
                                  {isOwn ? 'Mi póliza' : policy.agent_name}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-semibold text-foreground">
                                {policy.currency} {formatMoney(policy.annual_premium)}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {policy.end_date ? formatDate(policy.end_date, 'dd/MM/yyyy') : ''}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Upcoming Renewals */}
            {expiringPolicies.length > 0 && (
              <Card className="border-0 shadow-sm mt-6">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <RefreshCw className="h-5 w-5 text-brand" />
                    Próximas Renovaciones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {expiringPolicies.slice(0, 3).map(policy => {
                      const daysLeft = differenceInDays(parseLocalDate(policy.end_date), today);
                      return (
                        <div key={policy.id} className="p-3 bg-muted/40 rounded-lg">
                          <div className="flex items-start justify-between">
                            <div>
                              <Link 
                                to={createPageUrl(`PolicyDetail?id=${policy.id}`)}
                                className="font-medium text-foreground hover:text-brand"
                              >
                                {policy.policy_number}
                              </Link>
                              <p className="text-sm text-muted-foreground">{policy.client_name}</p>
                            </div>
                            <div className="text-right">
                              <span className={`text-sm font-medium ${
                                daysLeft <= 15 ? 'text-red-600 dark:text-red-400' : daysLeft <= 30 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground'
                              }`}>
                                {daysLeft} días
                              </span>
                              <p className="text-xs text-muted-foreground/70">
                                {formatDate(policy.end_date, 'dd MMM', { locale: es })}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Notifications Panel */}
          <div>
            <Card className="border-0 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Bell className="h-5 w-5 text-brand" />
                  Notificaciones
                  {unreadNotifications > 0 && (
                    <span className="px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded-full">
                      {unreadNotifications}
                    </span>
                  )}
                </CardTitle>
                <Link to={createPageUrl('Notifications')}>
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {notifications.length === 0 ? (
                  <p className="text-center text-muted-foreground/70 py-8 text-sm">
                    No hay notificaciones
                  </p>
                ) : (
                  <div className="space-y-3">
                    {notifications.map(notification => (
                      <div 
                        key={notification.id}
                        className={`p-3 rounded-lg transition-colors ${
                          notification.read 
                            ? 'bg-muted/40' 
                            : 'bg-brand-soft/10 border border-brand-soft/30'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <div className="text-xl">
                            {notification.notification_type === 'renovacion_disponible' && '🔄'}
                            {notification.notification_type === 'vencimiento_poliza' && '📅'}
                            {notification.notification_type === 'pago_proximo' && '💰'}
                            {notification.notification_type === 'comision_generada' && '💵'}
                            {!['renovacion_disponible', 'vencimiento_poliza', 'pago_proximo', 'comision_generada'].includes(notification.notification_type) && '📬'}
                          </div>
                          <div className="flex-1">
                            <p className={`text-sm font-medium ${!notification.read && 'text-brand-strong'}`}>
                              {notification.title}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {notification.message}
                            </p>
                            <p className="text-xs text-muted-foreground/70 mt-1">
                              {formatDate(notification.notification_date, 'dd MMM', { locale: es })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="border-0 shadow-sm mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Resumen Rápido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Pólizas Activas</span>
                  <span className="text-sm font-semibold text-foreground">{activePolicies}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Pólizas Vencidas</span>
                  <span className="text-sm font-semibold text-red-600 dark:text-red-400">{expiredPolicies}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">En Riesgo</span>
                  <span className="text-sm font-semibold text-orange-600 dark:text-orange-400">{atRiskPolicies}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Próximas Renovaciones (60d)</span>
                  <span className="text-sm font-semibold text-amber-600 dark:text-amber-400">{expiringPolicies.length}</span>
                </div>
                <div className="flex items-center justify-between border-t pt-3">
                  <span className="text-sm text-muted-foreground">Total Comisiones</span>
                  <span className="text-sm font-semibold text-brand-strong">
                    {currency} {formatMoney(pendingCommissions + paidCommissions)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}