import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import BackButton from '@/components/ui/BackButton';
import StatusBadge from '@/components/ui/StatusBadge';
import { Package, Plus, Pencil, Trash2, Loader2, Building2, X, ChevronDown, ChevronRight } from 'lucide-react';

export default function SettingsProducts() {
  const [products, setProducts] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [lines, setLines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [filterCompany, setFilterCompany] = useState('all');
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [branches, setBranches] = useState([]);
  const [expandedCompanies, setExpandedCompanies] = useState({});
  const [currentUser, setCurrentUser] = useState(null);
  const [deductible1Options, setDeductible1Options] = useState([]);
  const [deductible2Options, setDeductible2Options] = useState([]);
  const [newDeductible1, setNewDeductible1] = useState('');
  const [newDeductible2, setNewDeductible2] = useState('');
  const [formData, setFormData] = useState({
    line_id: '',
    company_id: '',
    product_name: '',
    product_category: 'INDIVIDUAL',
    allows_renewal: true,
    default_renewal_period: 'anual',
    status: 'activo',
    insured_amount: ''
  });

  useEffect(() => {
    const loadUser = async () => {
      const user = await api.auth.me();
      setCurrentUser(user);
    };
    loadUser();
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [productsData, companiesData, linesData, branchesData] = await Promise.all([
      api.entities.Product.list('-created_date'),
      api.entities.InsuranceCompany.filter({ status: 'activa' }),
      api.entities.InsuranceLine.filter({ status: 'activo' }),
      api.entities.Branch.filter({ status: 'activo' })
    ]);
    setProducts(productsData);
    setCompanies(companiesData);
    setLines(linesData);
    const sortedBranches = branchesData.sort((a, b) => a.name.localeCompare(b.name));
    setBranches(sortedBranches);
    if (sortedBranches.length > 0 && !selectedBranch) {
      setSelectedBranch(sortedBranches[0].id);
    }
    setLoading(false);
  };

  // Filter companies by selected line
  const availableCompanies = formData.line_id 
    ? companies.filter(c => (c.line_ids?.includes(formData.line_id) || c.lines?.includes(lines.find(l => l.id === formData.line_id)?.name)))
    : [];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    const company = companies.find(c => c.id === formData.company_id);
    const line = lines.find(l => l.id === formData.line_id);
    
    const dataToSave = {
      ...formData,
      company_name: company?.name || '',
      line_name: line?.name || '',
      insured_amount: formData.insured_amount ? parseFloat(formData.insured_amount) : null,
      deductible_1_options: deductible1Options,
      deductible_2_options: deductible2Options
    };
    
    if (editingItem) {
      // Update product
      await api.entities.Product.update(editingItem.id, dataToSave);
      
      // Update product name in existing commission tables
      if (editingItem.product_name !== dataToSave.product_name) {
        const allTables = await api.entities.CommissionTable.list();
        for (const table of allTables) {
          if (table.product_commissions && table.product_commissions.length > 0) {
            const updatedCommissions = table.product_commissions.map(pc => {
              if (pc.product_id === editingItem.id) {
                return { ...pc, product_name: dataToSave.product_name };
              }
              return pc;
            });
            
            // Only update if there was a change
            if (JSON.stringify(updatedCommissions) !== JSON.stringify(table.product_commissions)) {
              await api.entities.CommissionTable.update(table.id, {
                product_commissions: updatedCommissions
              });
            }
          }
        }
      }
    } else {
      // Create new product
      const newProduct = await api.entities.Product.create(dataToSave);
      
      // Add new product to all existing commission tables for this company and line
      const allTables = await api.entities.CommissionTable.filter({
        company_id: dataToSave.company_id,
        line_id: dataToSave.line_id
      });
      
      for (const table of allTables) {
        const existingCommissions = table.product_commissions || [];
        const updatedCommissions = [
          ...existingCommissions,
          {
            product_id: newProduct.id,
            product_name: dataToSave.product_name,
            new_business_percentage: 0,
            renewal_percentage: 0
          }
        ];
        
        await api.entities.CommissionTable.update(table.id, {
          product_commissions: updatedCommissions
        });
      }
    }
    setSaving(false);
    setFormOpen(false);
    setEditingItem(null);
    resetForm();
    loadData();
  };

  const handleEdit = (item) => {
    const canEdit = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canEdit) return;
    
    setEditingItem(item);
    setFormData({
      line_id: item.line_id || '',
      company_id: item.company_id || '',
      product_name: item.product_name || '',
      product_category: item.product_category || 'INDIVIDUAL',
      allows_renewal: item.allows_renewal !== false,
      default_renewal_period: item.default_renewal_period || 'anual',
      status: item.status || 'activo',
      insured_amount: item.insured_amount || ''
    });
    
    // Migrar valores antiguos si existen
    let ded1Opts = item.deductible_1_options || [];
    let ded2Opts = item.deductible_2_options || [];
    
    if (ded1Opts.length === 0 && typeof item.deductible_1 === 'number') {
      ded1Opts = [item.deductible_1];
    }
    if (ded2Opts.length === 0 && typeof item.deductible_2 === 'number') {
      ded2Opts = [item.deductible_2];
    }
    
    setDeductible1Options(ded1Opts);
    setDeductible2Options(ded2Opts);
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (itemToDelete) {
      await api.entities.Product.delete(itemToDelete.id);
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      loadData();
    }
  };

  const resetForm = () => {
    setFormData({
      line_id: '',
      company_id: '',
      product_name: '',
      product_category: 'INDIVIDUAL',
      allows_renewal: true,
      default_renewal_period: 'anual',
      status: 'activo',
      insured_amount: ''
    });
    setDeductible1Options([]);
    setDeductible2Options([]);
    setNewDeductible1('');
    setNewDeductible2('');
  };

  const addDeductible1 = () => {
    const value = parseFloat(newDeductible1);
    if (!isNaN(value) && value > 0 && !deductible1Options.includes(value)) {
      setDeductible1Options([...deductible1Options, value].sort((a, b) => a - b));
      setNewDeductible1('');
    }
  };

  const removeDeductible1 = (value) => {
    setDeductible1Options(deductible1Options.filter(v => v !== value));
  };

  const addDeductible2 = () => {
    const value = parseFloat(newDeductible2);
    if (!isNaN(value) && value > 0 && !deductible2Options.includes(value)) {
      setDeductible2Options([...deductible2Options, value].sort((a, b) => a - b));
      setNewDeductible2('');
    }
  };

  const removeDeductible2 = (value) => {
    setDeductible2Options(deductible2Options.filter(v => v !== value));
  };

  const openNewForm = () => {
    const canCreate = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canCreate) return;
    
    setEditingItem(null);
    resetForm();
    setFormOpen(true);
  };

  const filteredProducts = filterCompany === 'all' 
    ? products 
    : products.filter(p => p.company_id === filterCompany);

  // Filter by branch
  const companiesInBranch = companies.filter(c => c.branch_id === selectedBranch);
  const productsInBranch = filteredProducts.filter(p => {
    const company = companies.find(c => c.id === p.company_id);
    return company?.branch_id === selectedBranch;
  });

  // Group products by company - ordenado alfabéticamente
  const productsByCompany = productsInBranch.reduce((acc, product) => {
    const companyId = product.company_id || 'no_company';
    const companyName = product.company_name || 'Sin compañía';
    if (!acc[companyId]) {
      acc[companyId] = {
        name: companyName,
        products: []
      };
    }
    acc[companyId].products.push(product);
    return acc;
  }, {});

  // Ordenar productos dentro de cada compañía alfabéticamente
  Object.keys(productsByCompany).forEach(companyId => {
    productsByCompany[companyId].products.sort((a, b) => 
      a.product_name.localeCompare(b.product_name)
    );
  });

  const toggleCompany = (companyId) => {
    setExpandedCompanies(prev => ({
      ...prev,
      [companyId]: !prev[companyId]
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <BackButton />
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/10">
                <Package className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Productos</h1>
                <p className="text-sm text-muted-foreground">{products.length} productos</p>
              </div>
            </div>
          </div>
          {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
            <Button onClick={openNewForm} className="gap-2">
              <Plus className="h-4 w-4" /> Nuevo Producto
            </Button>
          )}
        </div>

        <Tabs value={selectedBranch} onValueChange={setSelectedBranch} className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 mb-6">
            {branches.map(b => (
              <TabsTrigger key={b.id} value={b.id} className="text-xs lg:text-sm">
                {b.name.length > 12 ? `${b.name.substring(0, 10)}...` : b.name}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={selectedBranch} className="space-y-4">
            {Object.entries(productsByCompany).length === 0 ? (
              <Card className="border-0 shadow-sm p-12">
                <div className="text-center text-muted-foreground/70">
                  <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No hay productos en este branch</p>
                  <Button onClick={openNewForm} variant="outline" className="mt-4">
                    Agregar primer producto
                  </Button>
                </div>
              </Card>
            ) : (
              Object.entries(productsByCompany)
                .sort(([, a], [, b]) => a.name.localeCompare(b.name))
                .map(([companyId, companyData]) => (
                <Collapsible
                  key={companyId}
                  open={expandedCompanies[companyId]}
                  onOpenChange={() => toggleCompany(companyId)}
                >
                  <Card className="border-0 shadow-sm overflow-hidden">
                    <CollapsibleTrigger className="w-full p-4 hover:bg-muted/40 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {expandedCompanies[companyId] ? (
                            <ChevronDown className="h-5 w-5 text-muted-foreground/70" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-muted-foreground/70" />
                          )}
                          <Building2 className="h-5 w-5 text-foreground" />
                          <h2 className="font-semibold text-foreground">{companyData.name}</h2>
                          <span className="text-sm text-muted-foreground bg-muted px-2 py-1 rounded-full">
                            {companyData.products.length} {companyData.products.length === 1 ? 'producto' : 'productos'}
                          </span>
                        </div>
                      </div>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="border-t border-border">
                        <div className="p-4 space-y-3">
                          {companyData.products.map((product) => (
                            <Card key={product.id} className="border shadow-none bg-muted/40 p-4">
                              <div className="flex items-center justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-3 mb-1">
                                    <h3 className="font-semibold text-foreground">{product.product_name}</h3>
                                    <StatusBadge status={product.status} />
                                  </div>
                                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                    <span>Ramo: {product.line_name}</span>
                                    {product.product_category && (
                                      <>
                                        <span>•</span>
                                        <span>Categoría: {product.product_category === 'INDIVIDUAL' ? 'Individual' : 'Corporativa'}</span>
                                      </>
                                    )}
                                    {product.line_name?.toLowerCase().includes('salud') && product.insured_amount && (
                                      <>
                                        <span>•</span>
                                        <span>Monto Aseg.: {product.insured_amount?.toLocaleString()}</span>
                                      </>
                                    )}
                                  </div>
                                </div>
                                {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
                                  <div className="flex items-center gap-2">
                                    <Button variant="ghost" size="icon" onClick={() => handleEdit(product)}>
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      onClick={() => { setItemToDelete(product); setDeleteDialogOpen(true); }}
                                    >
                                      <Trash2 className="h-4 w-4 text-red-500" />
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </Card>
                          ))}
                        </div>
                      </div>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              ))
            )}
          </TabsContent>
        </Tabs>

        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar Producto' : 'Nuevo Producto'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Ramo *</Label>
                  <Select 
                    value={formData.line_id} 
                    onValueChange={(v) => setFormData({...formData, line_id: v, company_id: ''})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar ramo" />
                    </SelectTrigger>
                    <SelectContent>
                      {lines.sort((a, b) => a.name.localeCompare(b.name)).map(l => (
                        <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Compañía *</Label>
                  <Select 
                    value={formData.company_id} 
                    onValueChange={(v) => setFormData({...formData, company_id: v})}
                    disabled={!formData.line_id}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={formData.line_id ? "Seleccionar compañía" : "Primero seleccione ramo"} />
                    </SelectTrigger>
                    <SelectContent>
                      {availableCompanies.sort((a, b) => a.name.localeCompare(b.name)).map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre del Producto *</Label>
                  <Input 
                    value={formData.product_name} 
                    onChange={(e) => setFormData({...formData, product_name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Categoría de Producto *</Label>
                  <Select 
                    value={formData.product_category} 
                    onValueChange={(v) => setFormData({...formData, product_category: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="INDIVIDUAL">Individual</SelectItem>
                      <SelectItem value="CORPORATIVA">Corporativa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {lines.find(l => l.id === formData.line_id)?.name?.toLowerCase().includes('salud') && (
                <>
                  <div className="space-y-2">
                    <Label>Monto Asegurado *</Label>
                    <Input 
                      type="number"
                      step="0.01"
                      value={formData.insured_amount} 
                      onChange={(e) => setFormData({...formData, insured_amount: e.target.value})}
                      required={lines.find(l => l.id === formData.line_id)?.name?.toLowerCase().includes('salud')}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <Label>Deducibles Dentro del País</Label>
                      <div className="flex gap-2">
                        <Input 
                          type="number" 
                          step="0.01"
                          min="0"
                          value={newDeductible1}
                          onChange={(e) => setNewDeductible1(e.target.value)}
                          placeholder="Ej: 500"
                          onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addDeductible1())}
                        />
                        <Button type="button" onClick={addDeductible1} variant="outline" size="icon">
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      {deductible1Options.length > 0 && (
                        <div className="flex flex-wrap gap-2 p-3 bg-muted/40 rounded-lg min-h-[60px]">
                          {deductible1Options.map((value, idx) => (
                            <div key={idx} className="flex items-center gap-1 px-3 py-1 bg-muted text-foreground rounded-md h-fit">
                              <span className="text-sm font-medium">${value.toLocaleString()}</span>
                              <button type="button" onClick={() => removeDeductible1(value)} className="ml-1">
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="space-y-3">
                      <Label>Deducibles Fuera del País</Label>
                      <div className="flex gap-2">
                        <Input 
                          type="number" 
                          step="0.01"
                          min="0"
                          value={newDeductible2}
                          onChange={(e) => setNewDeductible2(e.target.value)}
                          placeholder="Ej: 1000"
                          onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addDeductible2())}
                        />
                        <Button type="button" onClick={addDeductible2} variant="outline" size="icon">
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      {deductible2Options.length > 0 && (
                        <div className="flex flex-wrap gap-2 p-3 bg-muted/40 rounded-lg min-h-[60px]">
                          {deductible2Options.map((value, idx) => (
                            <div key={idx} className="flex items-center gap-1 px-3 py-1 bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-md h-fit">
                              <span className="text-sm font-medium">${value.toLocaleString()}</span>
                              <button type="button" onClick={() => removeDeductible2(value)} className="ml-1">
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Período de Renovación</Label>
                  <Select 
                    value={formData.default_renewal_period} 
                    onValueChange={(v) => setFormData({...formData, default_renewal_period: v})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mensual">Mensual</SelectItem>
                      <SelectItem value="trimestral">Trimestral</SelectItem>
                      <SelectItem value="semestral">Semestral</SelectItem>
                      <SelectItem value="anual">Anual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Estado</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(v) => setFormData({...formData, status: v})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activo">Activo</SelectItem>
                      <SelectItem value="inactivo">Inactivo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingItem ? 'Guardar' : 'Crear'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar producto?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará permanentemente el producto 
                {itemToDelete && ` "${itemToDelete.product_name}"`}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}