import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FileText, DollarSign, ShieldAlert, Users, LogOut, Loader2,
  CheckCircle2, Clock, AlertTriangle, Calendar, ChevronRight,
  User, Building2, Phone, Mail
} from 'lucide-react';
import { format } from 'date-fns';

const statusColors = {
  activa: 'bg-green-100 text-green-700 border-green-200',
  vencida: 'bg-red-100 text-red-700 border-red-200',
  cancelada: 'bg-slate-100 text-slate-600 border-slate-200',
  renovada: 'bg-muted text-foreground border-border',
  en_riesgo: 'bg-orange-100 text-orange-700 border-orange-200',
  pagado: 'bg-green-100 text-green-700 border-green-200',
  pendiente: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  atrasado: 'bg-red-100 text-red-700 border-red-200',
  en_proceso: 'bg-muted text-foreground border-border',
  aprobado: 'bg-green-100 text-green-700 border-green-200',
  rechazado: 'bg-red-100 text-red-700 border-red-200',
};

const statusLabels = {
  activa: 'Activa', vencida: 'Vencida', cancelada: 'Cancelada',
  renovada: 'Renovada', en_riesgo: 'En riesgo',
  pagado: 'Pagado', pendiente: 'Pendiente', atrasado: 'Atrasado',
  en_proceso: 'En proceso', aprobado: 'Aprobado', rechazado: 'Rechazado',
};

const fmt = (d) => {
  if (!d) return '—';
  try { return format(new Date(d + 'T00:00:00'), 'dd/MM/yyyy'); } catch { return d; }
};

const currency = (n, cur = 'USD') => {
  if (n == null) return '—';
  return new Intl.NumberFormat('es-EC', { style: 'currency', currency: cur, minimumFractionDigits: 2 }).format(n);
};

export default function ClientPortal() {
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [sessionToken, setSessionToken] = useState(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedPolicy, setSelectedPolicy] = useState(null);

  useEffect(() => {
    const raw = sessionStorage.getItem('clientPortalSession');
    if (!raw) { navigate('/ClientPortalLogin'); return; }
    const sess = JSON.parse(raw);
    if (!sess.sessionToken) { navigate('/ClientPortalLogin'); return; }
    setSession(sess);
    // Guardar el token solo en memoria (estado), no en localStorage
    setSessionToken(sess.sessionToken);
    loadData(sess.client.id, sess.sessionToken);
  }, []);

  const loadData = async (clientId, token) => {
    setLoading(true);
    try {
      const res = await api.functions.invoke('clientPortalData', { clientId, sessionToken: token });
      setData(res.data);
    } catch {
      navigate('/ClientPortalLogin');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('clientPortalSession');
    navigate('/ClientPortalLogin');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-brand-deep via-brand-mid to-brand-deep flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="h-10 w-10 animate-spin mx-auto mb-4 text-brand-soft" />
          <p className="text-slate-300">Cargando tu información...</p>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const { client, dependents, policies, payments, claims } = data;

  const clientName = client.client_type === 'persona'
    ? `${client.first_name || ''} ${client.last_name || ''}`.trim()
    : client.company_name || '';

  const activePolicies = policies.filter(p => p.status === 'activa');
  const pendingPayments = payments.filter(p => p.status === 'pendiente' || p.status === 'atrasado');
  const totalPremium = activePolicies.reduce((s, p) => s + (p.annual_premium || 0), 0);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Header */}
      <header className="bg-gradient-to-r from-brand-deep via-brand-mid to-brand-deep sticky top-0 z-50 shadow-lg">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-1">
            <img
              src="/logo-dark.png"
              alt="InsurDesk"
              className="h-8 w-auto"
            />
            <h1 className="text-xl font-bold text-white">
              GA<span className="text-brand-soft">Portal</span>
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-300 text-sm hidden sm:block">{clientName}</span>
            <Button variant="ghost" size="sm" onClick={handleLogout}
              className="text-slate-300 hover:text-white hover:bg-brand/30 gap-2">
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Salir</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">

        {/* Welcome Card */}
        <div className="bg-gradient-to-r from-brand-deep to-brand-mid rounded-2xl p-6 text-white">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-brand-soft text-sm font-medium mb-1">Bienvenido/a de vuelta</p>
              <h2 className="text-2xl font-bold">{clientName}</h2>
              <p className="text-slate-400 text-sm mt-1">{client.email} · {client.document_id}</p>
            </div>
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              {client.client_type === 'persona' ? <User className="h-6 w-6 text-white" /> : <Building2 className="h-6 w-6 text-white" />}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={FileText} color="blue" label="Pólizas activas" value={activePolicies.length} />
          <StatCard icon={DollarSign} color="green" label="Prima anual total" value={currency(totalPremium)} small />
          <StatCard icon={Clock} color="orange" label="Pagos pendientes" value={pendingPayments.length} alert={pendingPayments.length > 0} />
          <StatCard icon={ShieldAlert} color="purple" label="Siniestros" value={claims.length} />
        </div>

        {/* Tabs */}
        <Tabs defaultValue="policies">
          <TabsList className="bg-white border shadow-sm w-full sm:w-auto">
            <TabsTrigger value="policies" className="gap-2">
              <FileText className="h-4 w-4" /> Pólizas
            </TabsTrigger>
            <TabsTrigger value="payments" className="gap-2">
              <DollarSign className="h-4 w-4" /> Pagos
            </TabsTrigger>
            <TabsTrigger value="claims" className="gap-2">
              <ShieldAlert className="h-4 w-4" /> Siniestros
            </TabsTrigger>
            <TabsTrigger value="profile" className="gap-2">
              <User className="h-4 w-4" /> Mi perfil
            </TabsTrigger>
          </TabsList>

          {/* PÓLIZAS */}
          <TabsContent value="policies" className="mt-4 space-y-3">
            {policies.length === 0 ? (
              <EmptyState icon={FileText} message="No tienes pólizas registradas aún." />
            ) : (
              policies.map(policy => (
                <PolicyCard
                  key={policy.id}
                  policy={policy}
                  selected={selectedPolicy?.id === policy.id}
                  onSelect={() => setSelectedPolicy(selectedPolicy?.id === policy.id ? null : policy)}
                  payments={payments.filter(p => p.policy_id === policy.id)}
                />
              ))
            )}
          </TabsContent>

          {/* PAGOS */}
          <TabsContent value="payments" className="mt-4">
            <Card className="shadow-sm border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-semibold text-slate-800">Historial de Pagos</CardTitle>
              </CardHeader>
              <CardContent>
                {payments.length === 0 ? (
                  <EmptyState icon={DollarSign} message="No hay pagos registrados." />
                ) : (
                  <div className="space-y-2">
                    {payments
                      .sort((a, b) => new Date(b.due_date) - new Date(a.due_date))
                      .map(p => (
                        <div key={p.id} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              p.status === 'pagado' ? 'bg-green-100' : p.status === 'atrasado' ? 'bg-red-100' : 'bg-yellow-100'
                            }`}>
                              {p.status === 'pagado'
                                ? <CheckCircle2 className="h-4 w-4 text-green-600" />
                                : p.status === 'atrasado'
                                ? <AlertTriangle className="h-4 w-4 text-red-600" />
                                : <Clock className="h-4 w-4 text-yellow-600" />
                              }
                            </div>
                            <div>
                              <p className="text-sm font-medium text-slate-800">{p.policy_number || 'Póliza'}</p>
                              <p className="text-xs text-slate-500">
                                {p.period || `Cuota ${p.installment_number || ''}`} · Vence {fmt(p.due_date)}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-bold text-slate-800">{currency(p.amount, p.currency)}</p>
                            <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[p.status] || ''}`}>
                              {statusLabels[p.status] || p.status}
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* SINIESTROS */}
          <TabsContent value="claims" className="mt-4 space-y-3">
            {claims.length === 0 ? (
              <EmptyState icon={ShieldAlert} message="No tienes siniestros registrados." />
            ) : (
              claims.map(claim => (
                <Card key={claim.id} className="shadow-sm border-0">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-semibold text-slate-800 text-sm">
                            {claim.claim_number || 'Siniestro'}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[claim.status] || ''}`}>
                            {statusLabels[claim.status] || claim.status}
                          </span>
                        </div>
                        <p className="text-sm text-slate-600 mb-1">
                          <span className="font-medium">Tipo:</span> {claim.claim_type}
                        </p>
                        <p className="text-sm text-slate-600 mb-1">
                          <span className="font-medium">Póliza:</span> {claim.policy_number || '—'}
                        </p>
                        <p className="text-xs text-slate-400">
                          Fecha: {fmt(claim.event_date)}
                        </p>
                        {claim.observations && (
                          <p className="text-xs text-slate-500 mt-2 bg-slate-50 rounded-lg p-2">{claim.observations}</p>
                        )}
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-xs text-slate-400">Reclamado</p>
                        <p className="font-bold text-slate-800">{currency(claim.claimed_amount, claim.currency)}</p>
                        {claim.paid_amount != null && (
                          <>
                            <p className="text-xs text-slate-400 mt-1">Pagado</p>
                            <p className="font-semibold text-green-700 text-sm">{currency(claim.paid_amount, claim.currency)}</p>
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          {/* PERFIL */}
          <TabsContent value="profile" className="mt-4 space-y-4">
            <Card className="shadow-sm border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-semibold text-slate-800">Información Personal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <InfoRow icon={User} label="Nombre" value={clientName} />
                <InfoRow icon={Mail} label="Correo" value={client.email} />
                {client.phone && <InfoRow icon={Phone} label="Teléfono" value={client.phone} />}
                <InfoRow icon={ShieldAlert} label="Documento" value={`${client.document_type?.toUpperCase() || ''} ${client.document_id}`} />
                {client.city && <InfoRow icon={Building2} label="Ciudad" value={`${client.city}, ${client.country}`} />}
                {client.birth_date && <InfoRow icon={Calendar} label="Fecha de nacimiento" value={fmt(client.birth_date)} />}
              </CardContent>
            </Card>

            {dependents.length > 0 && (
              <Card className="shadow-sm border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-semibold text-slate-800 flex items-center gap-2">
                    <Users className="h-4 w-4" /> Dependientes ({dependents.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {dependents.map(dep => (
                    <div key={dep.id} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-0">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{dep.full_name}</p>
                        <p className="text-xs text-slate-500 capitalize">{dep.relationship} · {dep.document_id}</p>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[dep.status] || ''}`}>
                        {dep.status === 'activo' ? 'Activo' : 'Inactivo'}
                      </span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

function StatCard({ icon: IconComp, color, label, value, small, alert }) {
  const Icon = IconComp;
  const colors = {
    blue: 'bg-muted text-foreground',
    green: 'bg-green-50 text-green-600',
    orange: 'bg-orange-50 text-orange-600',
    purple: 'bg-purple-50 text-purple-600',
  };
  return (
    <Card className="shadow-sm border-0">
      <CardContent className="p-4">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${colors[color]}`}>
          <Icon className="h-5 w-5" />
        </div>
        <p className={`font-bold text-slate-800 ${small ? 'text-base' : 'text-2xl'}`}>
          {value}
          {alert && <span className="ml-1 w-2 h-2 bg-red-500 rounded-full inline-block mb-1"></span>}
        </p>
        <p className="text-xs text-slate-500 mt-1">{label}</p>
      </CardContent>
    </Card>
  );
}

function PolicyCard({ policy, selected, onSelect, payments }) {
  const statusColor = {
    activa: 'bg-green-100 text-green-700 border-green-200',
    vencida: 'bg-red-100 text-red-700 border-red-200',
    cancelada: 'bg-slate-100 text-slate-600 border-slate-200',
    renovada: 'bg-muted text-foreground border-border',
    en_riesgo: 'bg-orange-100 text-orange-700 border-orange-200',
  };

  const pendingPay = payments.filter(p => p.status === 'pendiente' || p.status === 'atrasado');

  return (
    <Card className="shadow-sm border-0 overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between cursor-pointer" onClick={onSelect}>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="font-bold text-slate-800">{policy.policy_number || 'Sin número'}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColor[policy.status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                {policy.status?.replace('_', ' ')}
              </span>
              {pendingPay.length > 0 && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-red-50 text-red-600 border border-red-200">
                  {pendingPay.length} pago{pendingPay.length > 1 ? 's' : ''} pendiente{pendingPay.length > 1 ? 's' : ''}
                </span>
              )}
            </div>
            <p className="text-sm text-slate-600">{policy.product_name || '—'}</p>
            <p className="text-xs text-slate-400 mt-1">{policy.company_name} · {policy.line_name}</p>
          </div>
          <div className="text-right shrink-0 ml-4">
            <p className="font-bold text-slate-800 text-sm">
              {policy.annual_premium ? new Intl.NumberFormat('es-EC', { style: 'currency', currency: policy.currency || 'USD' }).format(policy.annual_premium) : '—'}
            </p>
            <p className="text-xs text-slate-400">por año</p>
          </div>
          <ChevronRight className={`h-4 w-4 text-slate-400 ml-3 mt-1 transition-transform shrink-0 ${selected ? 'rotate-90' : ''}`} />
        </div>

        {selected && (
          <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 gap-x-6 gap-y-3">
            <DetailRow label="Vigencia desde" value={policy.start_date ? format(new Date(policy.start_date + 'T00:00:00'), 'dd/MM/yyyy') : '—'} />
            <DetailRow label="Vigencia hasta" value={policy.end_date ? format(new Date(policy.end_date + 'T00:00:00'), 'dd/MM/yyyy') : '—'} />
            <DetailRow label="Frecuencia de pago" value={policy.payment_frequency?.charAt(0).toUpperCase() + policy.payment_frequency?.slice(1) || '—'} />
            <DetailRow label="Monto por cuota" value={policy.installment_amount ? new Intl.NumberFormat('es-EC', { style: 'currency', currency: policy.currency || 'USD' }).format(policy.installment_amount) : '—'} />
            {policy.agent_name && <DetailRow label="Asesor" value={policy.agent_name} />}
            {policy.insured_amount && <DetailRow label="Monto asegurado" value={new Intl.NumberFormat('es-EC', { style: 'currency', currency: policy.currency || 'USD' }).format(policy.insured_amount)} />}
            {policy.deductible_1 && <DetailRow label="Deducible local" value={`$${policy.deductible_1}`} />}
            {policy.deductible_2 && <DetailRow label="Deducible internacional" value={`$${policy.deductible_2}`} />}
            {policy.notes && <div className="col-span-2"><DetailRow label="Notas" value={policy.notes} /></div>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function DetailRow({ label, value }) {
  return (
    <div>
      <p className="text-xs text-slate-400">{label}</p>
      <p className="text-sm font-medium text-slate-700">{value}</p>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-3 py-2 border-b border-slate-100 last:border-0">
      <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center shrink-0">
        <Icon className="h-4 w-4 text-slate-500" />
      </div>
      <div>
        <p className="text-xs text-slate-400">{label}</p>
        <p className="text-sm font-medium text-slate-700">{value}</p>
      </div>
    </div>
  );
}

function EmptyState({ icon: Icon, message }) {
  return (
    <div className="py-12 text-center">
      <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
        <Icon className="h-6 w-6 text-slate-400" />
      </div>
      <p className="text-slate-500 text-sm">{message}</p>
    </div>
  );
}