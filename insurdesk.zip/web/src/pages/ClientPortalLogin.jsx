import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Mail, ShieldCheck, ArrowLeft } from 'lucide-react';

export default function ClientPortalLogin() {
  const navigate = useNavigate();
  const [step, setStep] = useState('email'); // 'email' | 'otp'
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [clientName, setClientName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSendOTP = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api.functions.invoke('clientPortalOTP', { action: 'send', email: email.trim() });
      setClientName(res.data?.clientName || '');
      setStep('otp');
    } catch (err) {
      setError(err?.response?.data?.error || 'Error al enviar el código. Verifica tu correo.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api.functions.invoke('clientPortalOTP', { action: 'verify', email: email.trim(), otp: otp.trim() });
      const client = res.data?.client;
      const sessionToken = res.data?.sessionToken;
      // Store session in sessionStorage (NO localStorage). sessionToken se mantiene solo en memoria en ClientPortal.
      sessionStorage.setItem('clientPortalSession', JSON.stringify({ client, email: email.trim(), sessionToken }));
      navigate('/ClientPortal');
    } catch (err) {
      setError(err?.response?.data?.error || 'Código incorrecto. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-deep via-brand-mid to-brand-deep flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-1 mb-1">
            <img
              src="/logo-dark.png"
              alt="InsurDesk"
              className="h-10 w-auto"
            />
            <h1 className="text-4xl font-bold text-white tracking-tight">
              GA<span className="text-brand-soft">Portal</span>
            </h1>
          </div>
          <p className="text-slate-400 mt-2 text-sm">Portal de Cliente</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          {step === 'email' ? (
            <>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-muted rounded-xl flex items-center justify-center">
                  <Mail className="h-5 w-5 text-brand" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-800 text-lg">Acceder</h2>
                  <p className="text-slate-500 text-sm">Ingresa tu correo registrado</p>
                </div>
              </div>

              <form onSubmit={handleSendOTP} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-slate-700">Correo electrónico</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="tu@correo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-11"
                    style={{ textTransform: 'none' }}
                  />
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm">
                    {error}
                  </div>
                )}

                <Button type="submit" className="w-full h-11 bg-brand hover:bg-brand-hover text-white" disabled={loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Enviar código de acceso
                </Button>
              </form>
            </>
          ) : (
            <>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center">
                  <ShieldCheck className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-800 text-lg">Verificar código</h2>
                  <p className="text-slate-500 text-sm">
                    {clientName ? `Hola, ${clientName}` : 'Código enviado'}
                  </p>
                </div>
              </div>

              <p className="text-slate-500 text-sm mb-5">
                Enviamos un código de 6 dígitos a <strong className="text-slate-700">{email}</strong>. Revisa tu bandeja de entrada.
              </p>

              <form onSubmit={handleVerifyOTP} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="otp" className="text-slate-700">Código de acceso</Label>
                  <Input
                    id="otp"
                    type="text"
                    inputMode="numeric"
                    placeholder="000000"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    required
                    maxLength={6}
                    className="h-14 text-center text-2xl font-bold tracking-widest"
                    style={{ textTransform: 'none' }}
                    autoFocus
                  />
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm">
                    {error}
                  </div>
                )}

                <Button type="submit" className="w-full h-11 bg-brand hover:bg-brand-hover text-white" disabled={loading || otp.length !== 6}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Ingresar al portal
                </Button>

                <button
                  type="button"
                  onClick={() => { setStep('email'); setOtp(''); setError(''); }}
                  className="w-full flex items-center justify-center gap-2 text-slate-500 hover:text-slate-700 text-sm mt-2 transition-colors"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Cambiar correo o reenviar código
                </button>
              </form>
            </>
          )}
        </div>

        <p className="text-center text-slate-500 text-xs mt-6">
          ¿Problemas para acceder? Contacta a tu asesor.
        </p>
      </div>
    </div>
  );
}