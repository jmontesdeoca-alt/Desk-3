import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import DataTable from '@/components/ui/DataTable';
import { Activity, Loader2, Search, Filter } from 'lucide-react';
import { formatLocalDateTime } from '@/components/dateUtils';

export default function AuditLogs() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const data = await api.entities.AuditLog.list('-created_date');
    setLogs(data);
    setLoading(false);
  };

  const filteredLogs = logs.filter(log => {
    if (filter !== 'all' && log.entity_type !== filter) return false;
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      return log.action?.toLowerCase().includes(search) ||
             log.user_email?.toLowerCase().includes(search) ||
             log.entity_type?.toLowerCase().includes(search) ||
             log.details?.toLowerCase().includes(search);
    }
    return true;
  });

  const getActionColor = (action) => {
    if (action.includes('create') || action.includes('CREATE')) return 'text-emerald-600 dark:text-emerald-400';
    if (action.includes('update') || action.includes('UPDATE')) return 'text-brand';
    if (action.includes('delete') || action.includes('DELETE')) return 'text-red-600 dark:text-red-400';
    return 'text-muted-foreground';
  };

  const columns = [
    {
      header: 'Fecha',
      cell: (row) => formatLocalDateTime(row.created_date),
      className: 'w-36'
    },
    {
      header: 'Usuario',
      accessorKey: 'user_email',
      cellClassName: 'font-medium'
    },
    {
      header: 'Acción',
      cell: (row) => (
        <span className={`font-medium ${getActionColor(row.action)}`}>
          {row.action}
        </span>
      )
    },
    {
      header: 'Entidad',
      accessorKey: 'entity_type',
      cellClassName: 'text-muted-foreground'
    },
    {
      header: 'Detalles',
      cell: (row) => (
        <span className="text-sm text-muted-foreground line-clamp-1">{row.details}</span>
      )
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <BackButton className="mt-1" />
          <div className="flex-1">
            <PageHeader
              title="Auditoría del Sistema"
              subtitle="Historial de cambios y actividad"
              icon={Activity}
            />
          </div>
        </div>

        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="relative flex-1 min-w-[250px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
              <Input
                placeholder="Buscar por usuario, acción, entidad o detalle..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Todas las entidades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las entidades</SelectItem>
                  <SelectItem value="Policy">Pólizas</SelectItem>
                  <SelectItem value="Client">Clientes</SelectItem>
                  <SelectItem value="Agent">Agentes</SelectItem>
                  <SelectItem value="Commission">Comisiones</SelectItem>
                  <SelectItem value="Payment">Pagos</SelectItem>
                  <SelectItem value="Endorsement">Endosos</SelectItem>
                  <SelectItem value="User">Usuarios</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            columns={columns}
            data={filteredLogs}
            searchable={false}
            pageSize={20}
            emptyMessage="No hay registros de auditoría"
            sortable={true}
            defaultSortField="created_date"
            defaultSortOrder="desc"
          />
        </Card>
      </div>
    </div>
  );
}