import InitialImportCard from '@/components/admin/InitialImportCard';
import React, { useState } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import PageHeader from '@/components/ui/PageHeader';
import {
  Upload, Download, CheckCircle, XCircle, AlertCircle,
  Loader2, FileSpreadsheet, Building2, Package, Users, Table2, GitBranch, Layers
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';

// ─── Helpers ─────────────────────────────────────────────────────────────────
const gv = (row, ...keys) => {
  for (const k of keys) {
    if (row[k] !== undefined && row[k] !== null && row[k] !== '') return String(row[k]).trim();
  }
  return '';
};
const lower = (v) => String(v || '').toLowerCase().trim();

// ─── Generic Importer ────────────────────────────────────────────────────────
function EntityImporter({ entityName, label, description, fields, templateRows, buildRecords, findExisting }) {
  const [file, setFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [results, setResults] = useState(null);
  const [updateMode, setUpdateMode] = useState(!!findExisting);

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(templateRows, { header: fields.map(f => f.key) });
    ws['!cols'] = fields.map(() => ({ wch: 24 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Plantilla');
    const instrRows = fields.map(f => ({
      Campo: f.key,
      Obligatorio: f.required ? 'Sí' : 'No',
      Formato: f.format || 'Texto',
      Descripción: f.description || ''
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(instrRows), 'Instrucciones');
    XLSX.writeFile(wb, `plantilla_${entityName.toLowerCase()}.xlsx`);
  };

  const handleImport = async () => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      setImporting(true);
      try {
        const workbook = XLSX.read(new Uint8Array(event.target.result), { type: 'array' });
        const rows = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
        if (rows.length === 0) { toast.error('El archivo no contiene datos'); setImporting(false); return; }

        // buildRecords receives ALL rows at once so it can pre-load references once
        const { records, errors } = await buildRecords(rows);

        const existing = (updateMode && findExisting) ? await api.entities[entityName].list() : [];
        const res = { created: 0, updated: 0, failed: errors.length, errors: [...errors] };
        for (const { record, rowNum } of records) {
          try {
            const match = (updateMode && findExisting) ? findExisting(record, existing) : null;
            if (match) {
              await api.entities[entityName].update(match.id, record);
              res.updated++;
            } else {
              await api.entities[entityName].create(record);
              res.created++;
            }
          } catch (err) {
            res.failed++;
            res.errors.push(`Fila ${rowNum}: ${err.message}`);
          }
        }

        setResults(res);
        const okMsg = findExisting
          ? `${res.created} creados, ${res.updated} actualizados`
          : `${res.created} ${label} importados`;
        if (res.created > 0 || res.updated > 0) toast.success(okMsg);
        if (res.failed > 0) toast.error(`${res.failed} fallaron`);
      } catch (err) {
        toast.error('Error al procesar archivo: ' + err.message);
      } finally {
        setImporting(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const reset = () => { setFile(null); setResults(null); };

  return (
    <div className="space-y-4">
      <Alert className="border-border bg-muted">
        <AlertCircle className="h-4 w-4 text-foreground" />
        <AlertDescription className="text-foreground text-sm">{description}</AlertDescription>
      </Alert>
      <Card className="p-6 border-0 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Importar {label}</h3>
          <Button onClick={downloadTemplate} variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" /> Descargar Plantilla
          </Button>
        </div>

        {findExisting && !results && (
          <label className="flex items-center gap-2 mb-4 text-sm text-foreground/80 cursor-pointer select-none">
            <Checkbox checked={updateMode} onCheckedChange={setUpdateMode} />
            <span>Modo actualización (actualiza registros existentes en lugar de duplicar)</span>
          </label>
        )}

        {!results ? (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-input rounded-lg p-8 text-center hover:border-border transition-colors">
              <Upload className="h-10 w-10 text-muted-foreground/70 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-3">Selecciona un archivo Excel (.xlsx)</p>
              <Input type="file" accept=".xlsx,.xls"
                onChange={e => { setFile(e.target.files[0]); setResults(null); }}
                className="max-w-xs mx-auto" />
            </div>
            {file && (
              <div className="flex items-center justify-between p-3 bg-muted/40 rounded-lg">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <span className="text-sm font-medium">{file.name}</span>
                  <span className="text-xs text-muted-foreground/70">({(file.size / 1024).toFixed(1)} KB)</span>
                </div>
                <Button onClick={handleImport} disabled={importing} className="gap-2">
                  {importing && <Loader2 className="h-4 w-4 animate-spin" />}
                  {importing ? 'Importando...' : 'Importar'}
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className={`grid ${findExisting ? 'grid-cols-3' : 'grid-cols-2'} gap-4`}>
              <Alert className="border-green-500/30 bg-green-500/10">
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-600 dark:text-green-400">
                  <span className="font-bold text-xl">{results.created}</span> creados
                </AlertDescription>
              </Alert>
              {findExisting && (
                <Alert className="border-border bg-muted">
                  <CheckCircle className="h-4 w-4 text-foreground" />
                  <AlertDescription className="text-foreground">
                    <span className="font-bold text-xl">{results.updated}</span> actualizados
                  </AlertDescription>
                </Alert>
              )}
              <Alert className={results.failed > 0 ? 'border-red-500/30 bg-red-500/10' : 'border-border bg-muted/40'}>
                <XCircle className={`h-4 w-4 ${results.failed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground/70'}`} />
                <AlertDescription className={results.failed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground'}>
                  <span className="font-bold text-xl">{results.failed}</span> fallidos
                </AlertDescription>
              </Alert>
            </div>
            {results.errors.length > 0 && (
              <div className="p-3 bg-red-500/10 rounded-lg max-h-44 overflow-y-auto">
                <p className="font-medium text-red-600 dark:text-red-400 text-sm mb-2">Errores:</p>
                {results.errors.map((e, i) => <p key={i} className="text-xs text-red-600 dark:text-red-400">• {e}</p>)}
              </div>
            )}
            <Button onClick={reset} variant="outline" size="sm">Nueva Importación</Button>
          </div>
        )}
      </Card>
    </div>
  );
}

// ─── Branch Importer ─────────────────────────────────────────────────────────
// Entity required fields: name, code
function BranchesTab() {
  return (
    <EntityImporter
      entityName="Branch"
      label="Branches / Sucursales"
      description="Importa branches. Campos requeridos: name (nombre), code (código único, ej: GAPANAMA)."
      fields={[
        { key: 'name',    required: true,  description: 'Nombre del branch' },
        { key: 'code',    required: true,  description: 'Código único (ej: GAPANAMA, GAECUADOR)' },
        { key: 'country', required: false, description: 'País principal' },
        { key: 'status',  required: false, format: 'activo/inactivo', description: 'Estado (default: activo)' },
      ]}
      templateRows={[
        { name: 'GA PANAMA',  code: 'GAPANAMA',  country: 'PANAMA',  status: 'activo' },
        { name: 'GA ECUADOR', code: 'GAECUADOR', country: 'ECUADOR', status: 'activo' },
      ]}
      findExisting={(record, existing) => existing.find(b => lower(b.code) === lower(record.code))}
      buildRecords={async (rows) => {
        const records = [];
        const errors = [];
        rows.forEach((row, idx) => {
          const name = gv(row, 'name', 'NAME', 'Nombre', 'NOMBRE');
          const code = gv(row, 'code', 'CODE', 'Codigo', 'CODIGO');
          if (!name || !code) {
            errors.push(`Fila ${idx + 2}: name y code son obligatorios`);
            return;
          }
          records.push({
            rowNum: idx + 2,
            record: {
              name,
              code: code.toUpperCase(),
              country: gv(row, 'country', 'COUNTRY', 'Pais', 'País', 'PAIS'),
              status: lower(gv(row, 'status', 'STATUS') || 'activo'),
            }
          });
        });
        return { records, errors };
      }}
    />
  );
}

// ─── InsuranceCompany Importer ────────────────────────────────────────────────
// Entity required fields: name, country, branch_id
function CompaniesTab() {
  return (
    <EntityImporter
      entityName="InsuranceCompany"
      label="Compañías Aseguradoras"
      description="Importa compañías. branch_name debe coincidir exactamente con un branch existente. lines: lista separada por comas."
      fields={[
        { key: 'name',                    required: true,  description: 'Nombre de la compañía' },
        { key: 'branch_name',             required: true,  description: 'Nombre del branch (debe existir)' },
        { key: 'country',                 required: true,  description: 'País' },
        { key: 'lines',                   required: false, format: 'VIDA,SALUD,AUTO', description: 'Ramos separados por coma' },
        { key: 'contact_email',           required: false, description: 'Email de contacto' },
        { key: 'contact_phone',           required: false, description: 'Teléfono' },
        { key: 'new_business_payment_type', required: false, format: 'anualizada/segun_cliente', description: 'Pago nuevo negocio (default: anualizada)' },
        { key: 'renewal_payment_type',    required: false, format: 'anualizada/segun_cliente', description: 'Pago renovaciones (default: segun_cliente)' },
        { key: 'direct_payment_to_agents', required: false, format: 'TRUE/FALSE', description: 'Pago directo a agentes' },
        { key: 'status',                  required: false, format: 'activa/inactiva', description: 'Estado' },
      ]}
      templateRows={[
        { name: 'ASEGURADORA EJEMPLO SA', branch_name: 'GA PANAMA', country: 'PANAMA', lines: 'VIDA,SALUD', contact_email: 'ops@aseguradora.com', new_business_payment_type: 'anualizada', renewal_payment_type: 'segun_cliente', direct_payment_to_agents: 'FALSE', status: 'activa' },
      ]}
      findExisting={(record, existing) => existing.find(c => lower(c.name) === lower(record.name))}
      buildRecords={async (rows) => {
        const branches = await api.entities.Branch.list();
        const records = [];
        const errors = [];
        rows.forEach((row, idx) => {
          const name        = gv(row, 'name', 'NAME', 'Nombre', 'NOMBRE');
          const branchName  = gv(row, 'branch_name', 'BRANCH_NAME', 'Branch', 'BRANCH');
          const country     = gv(row, 'country', 'COUNTRY', 'Pais', 'País', 'PAIS');
          if (!name || !branchName || !country) {
            errors.push(`Fila ${idx + 2}: name, branch_name y country son obligatorios`);
            return;
          }
          const branch = branches.find(b => lower(b.name) === lower(branchName) || lower(b.code) === lower(branchName));
          if (!branch) {
            errors.push(`Fila ${idx + 2}: branch "${branchName}" no encontrado`);
            return;
          }
          const linesRaw = gv(row, 'lines', 'LINES', 'Ramos', 'RAMOS');
          const lines = linesRaw ? linesRaw.split(',').map(l => l.trim()).filter(Boolean) : [];
          const directPayment = lower(gv(row, 'direct_payment_to_agents', 'DIRECT_PAYMENT_TO_AGENTS')) === 'true';
          records.push({
            rowNum: idx + 2,
            record: {
              name,
              branch_id:   branch.id,
              branch_name: branch.name,
              country,
              lines,
              contact_email: gv(row, 'contact_email', 'CONTACT_EMAIL'),
              contact_phone: gv(row, 'contact_phone', 'CONTACT_PHONE'),
              new_business_payment_type: gv(row, 'new_business_payment_type', 'NEW_BUSINESS_PAYMENT_TYPE') || 'anualizada',
              renewal_payment_type:      gv(row, 'renewal_payment_type', 'RENEWAL_PAYMENT_TYPE') || 'segun_cliente',
              direct_payment_to_agents:  directPayment,
              status: lower(gv(row, 'status', 'STATUS') || 'activa'),
            }
          });
        });
        return { records, errors };
      }}
    />
  );
}

// ─── InsuranceLine Importer ───────────────────────────────────────────────────
// Entity required fields: name
function LinesTab() {
  return (
    <EntityImporter
      entityName="InsuranceLine"
      label="Ramos de Seguro"
      description="Importa ramos de seguro. Solo se requiere el nombre."
      fields={[
        { key: 'name',        required: true,  description: 'Nombre del ramo' },
        { key: 'description', required: false, description: 'Descripción' },
        { key: 'status',      required: false, format: 'activo/inactivo', description: 'Estado (default: activo)' },
      ]}
      templateRows={[
        { name: 'VIDA',    description: 'SEGUROS DE VIDA',      status: 'activo' },
        { name: 'SALUD',   description: 'SEGUROS DE SALUD',     status: 'activo' },
        { name: 'AUTO',    description: 'SEGUROS DE VEHICULOS', status: 'activo' },
        { name: 'HOGAR',   description: 'SEGUROS DE HOGAR',     status: 'activo' },
        { name: 'ACCIDENTES', description: 'ACCIDENTES PERSONALES', status: 'activo' },
      ]}
      findExisting={(record, existing) => existing.find(l => lower(l.name) === lower(record.name))}
      buildRecords={async (rows) => {
        const records = [];
        const errors = [];
        rows.forEach((row, idx) => {
          const name = gv(row, 'name', 'NAME', 'Nombre', 'NOMBRE');
          if (!name) { errors.push(`Fila ${idx + 2}: name es obligatorio`); return; }
          records.push({
            rowNum: idx + 2,
            record: {
              name,
              description: gv(row, 'description', 'DESCRIPTION', 'Descripcion', 'DESCRIPCION'),
              status: lower(gv(row, 'status', 'STATUS') || 'activo'),
            }
          });
        });
        return { records, errors };
      }}
    />
  );
}

// ─── Product Importer ─────────────────────────────────────────────────────────
// Entity required fields: company_id, line_id, product_name
function ProductsTab() {
  return (
    <EntityImporter
      entityName="Product"
      label="Productos"
      description="Importa productos. company_name y line_name deben coincidir exactamente con registros existentes."
      fields={[
        { key: 'product_name',     required: true,  description: 'Nombre del producto' },
        { key: 'company_name',     required: true,  description: 'Nombre de la compañía (debe existir)' },
        { key: 'line_name',        required: true,  description: 'Nombre del ramo (debe existir)' },
        { key: 'product_category', required: false, format: 'INDIVIDUAL/CORPORATIVA', description: 'Categoría (default: INDIVIDUAL)' },
        { key: 'insured_amount',   required: false, format: 'Número', description: 'Monto asegurado (solo ramo Salud)' },
        { key: 'deductible_1_options', required: false, format: 'Números separados por coma (ej: 100,200,500)', description: 'Opciones Deducible 1 dentro del país (Salud)' },
        { key: 'deductible_2_options', required: false, format: 'Números separados por coma (ej: 500,1000,2000)', description: 'Opciones Deducible 2 fuera del país (Salud)' },
        { key: 'allows_renewal',   required: false, format: 'TRUE/FALSE', description: 'Permite renovación (default: TRUE)' },
        { key: 'default_renewal_period', required: false, format: 'mensual/trimestral/semestral/anual', description: 'Período renovación (default: anual)' },
        { key: 'status',           required: false, format: 'activo/inactivo', description: 'Estado (default: activo)' },
      ]}
      templateRows={[
        { product_name: 'SEGURO VIDA BASICO',  company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA',  product_category: 'INDIVIDUAL', insured_amount: '', deductible_1_options: '', deductible_2_options: '', allows_renewal: 'TRUE', default_renewal_period: 'anual', status: 'activo' },
        { product_name: 'PLAN SALUD PREMIUM',  company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'SALUD', product_category: 'INDIVIDUAL', insured_amount: 50000, deductible_1_options: '100,200,500', deductible_2_options: '500,1000,2000', allows_renewal: 'TRUE', default_renewal_period: 'anual', status: 'activo' },
        { product_name: 'SEGURO AUTO TOTAL',   company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'AUTO',  product_category: 'INDIVIDUAL', insured_amount: '', deductible_1_options: '', deductible_2_options: '', allows_renewal: 'TRUE', default_renewal_period: 'anual', status: 'activo' },
      ]}
      findExisting={(record, existing) => existing.find(p =>
        p.company_id === record.company_id &&
        lower(p.product_name) === lower(record.product_name)
      )}
      buildRecords={async (rows) => {
        const [companies, lines] = await Promise.all([
          api.entities.InsuranceCompany.list(),
          api.entities.InsuranceLine.list()
        ]);
        const records = [];
        const errors = [];
        rows.forEach((row, idx) => {
          const productName = gv(row, 'product_name', 'PRODUCT_NAME', 'Producto', 'PRODUCTO');
          const companyName = gv(row, 'company_name', 'COMPANY_NAME', 'Compania', 'COMPANIA');
          const lineName    = gv(row, 'line_name', 'LINE_NAME', 'Ramo', 'RAMO');
          if (!productName || !companyName || !lineName) {
            errors.push(`Fila ${idx + 2}: product_name, company_name y line_name son obligatorios`);
            return;
          }
          const company = companies.find(c => lower(c.name) === lower(companyName));
          const line    = lines.find(l => lower(l.name) === lower(lineName));
          if (!company) { errors.push(`Fila ${idx + 2}: compañía "${companyName}" no encontrada`); return; }
          if (!line)    { errors.push(`Fila ${idx + 2}: ramo "${lineName}" no encontrado`); return; }

          const allowsRenewal = lower(gv(row, 'allows_renewal', 'ALLOWS_RENEWAL') || 'true') !== 'false';
          const insuredAmount = gv(row, 'insured_amount', 'INSURED_AMOUNT');
          const ded1Raw = gv(row, 'deductible_1_options', 'DEDUCTIBLE_1_OPTIONS');
          const ded2Raw = gv(row, 'deductible_2_options', 'DEDUCTIBLE_2_OPTIONS');
          const parseNumArray = (s) => s ? s.split(',').map(x => parseFloat(x.trim())).filter(n => !isNaN(n)) : [];
          records.push({
            rowNum: idx + 2,
            record: {
              product_name: productName,
              company_id:   company.id,
              company_name: company.name,
              line_id:      line.id,
              line_name:    line.name,
              product_category: (gv(row, 'product_category', 'PRODUCT_CATEGORY') || 'INDIVIDUAL').toUpperCase(),
              ...(insuredAmount ? { insured_amount: parseFloat(insuredAmount) } : {}),
              deductible_1_options: parseNumArray(ded1Raw),
              deductible_2_options: parseNumArray(ded2Raw),
              allows_renewal: allowsRenewal,
              default_renewal_period: lower(gv(row, 'default_renewal_period', 'DEFAULT_RENEWAL_PERIOD') || 'anual'),
              status: lower(gv(row, 'status', 'STATUS') || 'activo'),
            }
          });
        });
        return { records, errors };
      }}
    />
  );
}

// ─── Agent Importer ───────────────────────────────────────────────────────────
// Entity required fields: agent_type, name, email, country
function AgentsTab() {
  return (
    <EntityImporter
      entityName="Agent"
      label="Agentes"
      description="Importa agentes. Primero importa agencias/uplines antes que sus subordinados. upline_name debe coincidir con el nombre de un agente existente."
      fields={[
        { key: 'name',       required: true,  description: 'Nombre completo (único)' },
        { key: 'agent_type', required: true,  format: 'agente/agencia', description: 'Tipo' },
        { key: 'email',      required: true,  description: 'Email del agente' },
        { key: 'country',    required: true,  description: 'País' },
        { key: 'phone',      required: false, description: 'Teléfono' },
        { key: 'alias',      required: false, description: 'Alias o código de agente' },
        { key: 'upline_name',required: false, description: 'Nombre del agente upline (debe existir)' },
        { key: 'level',      required: false, format: 'Número entero', description: 'Nivel jerárquico (1=base)' },
        { key: 'is_nivel_2', required: false, format: 'TRUE/FALSE', description: 'Es agente Nivel 2' },
        { key: 'is_gapartner',required: false,format: 'TRUE/FALSE', description: 'Es GAPartner' },
        { key: 'birth_date', required: false, format: 'YYYY-MM-DD', description: 'Fecha de nacimiento' },
        { key: 'user_email', required: false, description: 'Email del usuario del sistema asociado' },
        { key: 'status',     required: false, format: 'activo/inactivo', description: 'Estado (default: activo)' },
      ]}
      templateRows={[
        { name: 'AGENCIA PRINCIPAL GA', agent_type: 'agencia', email: 'agencia@ga.com',  country: 'PANAMA',  level: 5, is_nivel_2: 'FALSE', is_gapartner: 'FALSE', status: 'activo' },
        { name: 'JUAN PEREZ',           agent_type: 'agente',  email: 'juan@ga.com',     country: 'PANAMA',  phone: '555-1234', alias: 'JP-001', upline_name: 'AGENCIA PRINCIPAL GA', level: 1, is_nivel_2: 'FALSE', is_gapartner: 'FALSE', status: 'activo' },
        { name: 'MARIA GOMEZ',          agent_type: 'agente',  email: 'maria@ga.com',    country: 'ECUADOR', phone: '555-5678', alias: 'MG-002', upline_name: 'AGENCIA PRINCIPAL GA', level: 1, is_nivel_2: 'TRUE',  is_gapartner: 'FALSE', status: 'activo' },
      ]}
      findExisting={(record, existing) => existing.find(a =>
        lower(a.name) === lower(record.name) || lower(a.email) === lower(record.email)
      )}
      buildRecords={async (rows) => {
        // Pre-load ALL agents once (including ones created earlier in this batch won't be here,
        // so uplines must exist BEFORE this import or be higher up in the same file)
        const existingAgents = await api.entities.Agent.list();
        const records = [];
        const errors = [];
        rows.forEach((row, idx) => {
          const name      = gv(row, 'name', 'NAME', 'Nombre', 'NOMBRE');
          const agentType = lower(gv(row, 'agent_type', 'AGENT_TYPE', 'Tipo', 'TIPO') || 'agente');
          const email     = gv(row, 'email', 'EMAIL', 'Email');
          const country   = gv(row, 'country', 'COUNTRY', 'Pais', 'País', 'PAIS');
          if (!name || !email || !country) {
            errors.push(`Fila ${idx + 2}: name, email y country son obligatorios`);
            return;
          }
          if (!['agente', 'agencia'].includes(agentType)) {
            errors.push(`Fila ${idx + 2}: agent_type debe ser "agente" o "agencia"`);
            return;
          }
          const uplineName = gv(row, 'upline_name', 'UPLINE_NAME', 'Upline', 'UPLINE');
          let uplineId = null, uplineAgentName = null;
          if (uplineName) {
            const upline = existingAgents.find(a => lower(a.name) === lower(uplineName));
            if (upline) { uplineId = upline.id; uplineAgentName = upline.name; }
            else { errors.push(`Fila ${idx + 2}: upline "${uplineName}" no encontrado (¿ya fue importado?)`); return; }
          }
          const birthDate = gv(row, 'birth_date', 'BIRTH_DATE', 'FechaNacimiento');
          records.push({
            rowNum: idx + 2,
            record: {
              name,
              agent_type: agentType,
              email,
              country,
              phone:             gv(row, 'phone', 'PHONE', 'Telefono', 'TELEFONO'),
              alias:             gv(row, 'alias', 'ALIAS') || null,
              upline_agent_id:   uplineId,
              upline_agent_name: uplineAgentName,
              level:             parseInt(gv(row, 'level', 'LEVEL', 'Nivel') || '1') || 1,
              is_nivel_2:        lower(gv(row, 'is_nivel_2', 'IS_NIVEL_2') || 'false') === 'true',
              is_gapartner:      lower(gv(row, 'is_gapartner', 'IS_GAPARTNER') || 'false') === 'true',
              birth_date:        birthDate || null,
              user_email:        gv(row, 'user_email', 'USER_EMAIL') || null,
              status:            lower(gv(row, 'status', 'STATUS') || 'activo'),
            }
          });
        });
        return { records, errors };
      }}
    />
  );
}

// ─── CommissionTable Importer (special: groups rows into tables) ──────────────
// Entity required fields: name, company_id, line_id, level, product_commissions
function CommissionTablesTab() {
  const [file, setFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [results, setResults] = useState(null);

  const fields = [
    { key: 'name',            required: true,  description: 'Nombre de la tabla (filas con mismo nombre se agrupan)' },
    { key: 'company_name',    required: true,  description: 'Nombre de la compañía (debe existir)' },
    { key: 'line_name',       required: true,  description: 'Nombre del ramo (debe existir)' },
    { key: 'level',           required: true,  format: 'Número', description: 'Nivel del agente' },
    { key: 'level_name',      required: true,  description: 'Nombre del nivel (ej: Vendedor, Supervisor)' },
    { key: 'product_name',    required: true,  description: 'Nombre del producto (debe existir)' },
    { key: 'new_business_pct',required: true,  format: 'Número (ej: 15.5)', description: '% comisión nuevo negocio' },
    { key: 'renewal_pct',     required: true,  format: 'Número (ej: 10)',   description: '% comisión renovación' },
    { key: 'is_master',       required: false, format: 'TRUE/FALSE', description: 'Es tabla master de agencia' },
    { key: 'status',          required: false, format: 'activa/inactiva', description: 'Estado (default: activa)' },
  ];

  const templateRows = [
    { name: 'TABLA VIDA N1',     company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA',  level: 1, level_name: 'VENDEDOR',   product_name: 'SEGURO VIDA BASICO', new_business_pct: 15,   renewal_pct: 10,  is_master: 'FALSE', status: 'activa' },
    { name: 'TABLA VIDA N1',     company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA',  level: 1, level_name: 'VENDEDOR',   product_name: 'PLAN SALUD PREMIUM', new_business_pct: 12,   renewal_pct: 8,   is_master: 'FALSE', status: 'activa' },
    { name: 'TABLA VIDA N2',     company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA',  level: 2, level_name: 'SUPERVISOR', product_name: 'SEGURO VIDA BASICO', new_business_pct: 3,    renewal_pct: 2,   is_master: 'FALSE', status: 'activa' },
    { name: 'TABLA VIDA MASTER', company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA',  level: 5, level_name: 'AGENCIA',    product_name: 'SEGURO VIDA BASICO', new_business_pct: 20,   renewal_pct: 15,  is_master: 'TRUE',  status: 'activa' },
  ];

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(templateRows, { header: fields.map(f => f.key) });
    ws['!cols'] = fields.map(() => ({ wch: 24 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Plantilla');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(fields.map(f => ({
      Campo: f.key, Obligatorio: f.required ? 'Sí' : 'No', Formato: f.format || 'Texto', Descripción: f.description
    }))), 'Instrucciones');
    XLSX.writeFile(wb, 'plantilla_CommissionTable.xlsx');
  };

  const handleImport = async () => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      setImporting(true);
      try {
        const workbook = XLSX.read(new Uint8Array(event.target.result), { type: 'array' });
        const rows = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
        if (rows.length === 0) { toast.error('Archivo vacío'); setImporting(false); return; }

        const [companies, lines, products, existingTables] = await Promise.all([
          api.entities.InsuranceCompany.list(),
          api.entities.InsuranceLine.list(),
          api.entities.Product.list(),
          api.entities.CommissionTable.list()
        ]);

        // Group rows by table name key = "name|level"
        const tableMap = new Map();
        const rowErrors = [];

        rows.forEach((row, idx) => {
          const name        = gv(row, 'name', 'NAME', 'Nombre', 'NOMBRE');
          const companyName = gv(row, 'company_name', 'COMPANY_NAME', 'Compania', 'COMPANIA');
          const lineName    = gv(row, 'line_name', 'LINE_NAME', 'Ramo', 'RAMO');
          const productName = gv(row, 'product_name', 'PRODUCT_NAME', 'Producto', 'PRODUCTO');
          const newPct      = parseFloat(gv(row, 'new_business_pct', 'NEW_BUSINESS_PCT', 'NuevoNegocio') || '0');
          const renewalPct  = parseFloat(gv(row, 'renewal_pct', 'RENEWAL_PCT', 'Renovacion') || '0');
          const level       = parseInt(gv(row, 'level', 'LEVEL', 'Nivel') || '1') || 1;
          const levelName   = gv(row, 'level_name', 'LEVEL_NAME', 'NombreNivel');
          const isMaster    = lower(gv(row, 'is_master', 'IS_MASTER') || 'false') === 'true';
          const status      = lower(gv(row, 'status', 'STATUS') || 'activa');

          if (!name || !companyName || !lineName || !productName) {
            rowErrors.push(`Fila ${idx + 2}: name, company_name, line_name y product_name son obligatorios`);
            return;
          }

          const company = companies.find(c => lower(c.name) === lower(companyName));
          const line    = lines.find(l => lower(l.name) === lower(lineName));
          const product = products.find(p =>
            lower(p.product_name) === lower(productName) &&
            (company ? p.company_id === company.id : true)
          );

          if (!company) { rowErrors.push(`Fila ${idx + 2}: compañía "${companyName}" no encontrada`); return; }
          if (!line)    { rowErrors.push(`Fila ${idx + 2}: ramo "${lineName}" no encontrado`); return; }
          if (!product) { rowErrors.push(`Fila ${idx + 2}: producto "${productName}" no encontrado para esa compañía`); return; }

          const key = `${name}|||${level}`;
          if (!tableMap.has(key)) {
            tableMap.set(key, {
              name,
              company_id:   company.id,
              company_name: company.name,
              line_id:      line.id,
              line_name:    line.name,
              level,
              level_name:   levelName,
              is_master:    isMaster,
              status,
              product_commissions: []
            });
          }
          tableMap.get(key).product_commissions.push({
            product_id:              product.id,
            product_name:            product.product_name,
            new_business_percentage: newPct,
            renewal_percentage:      renewalPct
          });
        });

        const res = { created: 0, updated: 0, failed: rowErrors.length, errors: [...rowErrors] };
        for (const [, tableData] of tableMap) {
          try {
            const existing = existingTables.find(t =>
              lower(t.name) === lower(tableData.name) && t.level === tableData.level
            );
            if (existing) {
              await api.entities.CommissionTable.update(existing.id, tableData);
              res.updated++;
            } else {
              await api.entities.CommissionTable.create(tableData);
              res.created++;
            }
          } catch (err) {
            res.failed++;
            res.errors.push(`Tabla "${tableData.name}" nivel ${tableData.level}: ${err.message}`);
          }
        }

        setResults(res);
        if (res.created > 0 || res.updated > 0) toast.success(`${res.created} creadas, ${res.updated} actualizadas`);
        if (res.failed > 0) toast.error(`${res.failed} errores`);
      } catch (err) {
        toast.error('Error: ' + err.message);
      } finally {
        setImporting(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const reset = () => { setFile(null); setResults(null); };

  return (
    <div className="space-y-4">
      <Alert className="border-border bg-muted">
        <AlertCircle className="h-4 w-4 text-foreground" />
        <AlertDescription className="text-foreground text-sm">
          Cada fila es un producto dentro de una tabla. Filas con el mismo <strong>name + level</strong> se agrupan en una sola tabla con múltiples productos. Compañías, ramos y productos deben existir previamente.
        </AlertDescription>
      </Alert>
      <Card className="p-6 border-0 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Importar Tablas de Comisiones</h3>
          <Button onClick={downloadTemplate} variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" /> Descargar Plantilla
          </Button>
        </div>
        {!results ? (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-input rounded-lg p-8 text-center hover:border-border transition-colors">
              <Upload className="h-10 w-10 text-muted-foreground/70 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-3">Selecciona un archivo Excel (.xlsx)</p>
              <Input type="file" accept=".xlsx,.xls"
                onChange={e => { setFile(e.target.files[0]); setResults(null); }}
                className="max-w-xs mx-auto" />
            </div>
            {file && (
              <div className="flex items-center justify-between p-3 bg-muted/40 rounded-lg">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <span className="text-sm font-medium">{file.name}</span>
                  <span className="text-xs text-muted-foreground/70">({(file.size / 1024).toFixed(1)} KB)</span>
                </div>
                <Button onClick={handleImport} disabled={importing} className="gap-2">
                  {importing && <Loader2 className="h-4 w-4 animate-spin" />}
                  {importing ? 'Importando...' : 'Importar'}
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <Alert className="border-green-500/30 bg-green-500/10">
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-600 dark:text-green-400">
                  <span className="font-bold text-xl">{results.created}</span> creadas
                </AlertDescription>
              </Alert>
              <Alert className="border-border bg-muted">
                <CheckCircle className="h-4 w-4 text-foreground" />
                <AlertDescription className="text-foreground">
                  <span className="font-bold text-xl">{results.updated}</span> actualizadas
                </AlertDescription>
              </Alert>
              <Alert className={results.failed > 0 ? 'border-red-500/30 bg-red-500/10' : 'border-border bg-muted/40'}>
                <XCircle className={`h-4 w-4 ${results.failed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground/70'}`} />
                <AlertDescription className={results.failed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground'}>
                  <span className="font-bold text-xl">{results.failed}</span> errores
                </AlertDescription>
              </Alert>
            </div>
            {results.errors.length > 0 && (
              <div className="p-3 bg-red-500/10 rounded-lg max-h-44 overflow-y-auto">
                <p className="font-medium text-red-600 dark:text-red-400 text-sm mb-2">Errores:</p>
                {results.errors.map((e, i) => <p key={i} className="text-xs text-red-600 dark:text-red-400">• {e}</p>)}
              </div>
            )}
            <Button onClick={reset} variant="outline" size="sm">Nueva Importación</Button>
          </div>
        )}
      </Card>
    </div>
  );
}

// ─── AgentCommissionAssignment Importer ────────────────────────────────────────
// Entity required fields: agent_id, company_id, line_id, commission_table_id
function AssignmentsTab() {
  const [file, setFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [results, setResults] = useState(null);

  const fields = [
    { key: 'agent_name',            required: true,  description: 'Nombre del agente (debe existir)' },
    { key: 'company_name',           required: true,  description: 'Nombre de la compañía (debe existir)' },
    { key: 'line_name',              required: true,  description: 'Nombre del ramo (debe existir)' },
    { key: 'commission_table_name',  required: true,  description: 'Nombre de la tabla de comisión (debe existir)' },
  ];

  const templateRows = [
    { agent_name: 'JUAN PEREZ', company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA', commission_table_name: 'TABLA VIDA N1' },
    { agent_name: 'JUAN PEREZ', company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'SALUD', commission_table_name: 'TABLA SALUD N1' },
    { agent_name: 'MARIA GOMEZ', company_name: 'ASEGURADORA EJEMPLO SA', line_name: 'VIDA', commission_table_name: 'TABLA VIDA N2' },
  ];

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(templateRows, { header: fields.map(f => f.key) });
    ws['!cols'] = fields.map(() => ({ wch: 28 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Plantilla');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(fields.map(f => ({
      Campo: f.key, Obligatorio: f.required ? 'Sí' : 'No', Formato: f.format || 'Texto', Descripción: f.description
    }))), 'Instrucciones');
    XLSX.writeFile(wb, 'plantilla_AgentCommissionAssignment.xlsx');
  };

  const handleImport = async () => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      setImporting(true);
      try {
        const workbook = XLSX.read(new Uint8Array(event.target.result), { type: 'array' });
        const rows = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
        if (rows.length === 0) { toast.error('Archivo vacío'); setImporting(false); return; }

        // Pre-load all references in parallel
        const [agents, companies, lines, tables, existingAssignments] = await Promise.all([
          api.entities.Agent.list(),
          api.entities.InsuranceCompany.list(),
          api.entities.InsuranceLine.list(),
          api.entities.CommissionTable.list(),
          api.entities.AgentCommissionAssignment.list(),
        ]);

        // Index lookups by lowercased name
        const agentMap = new Map(agents.map(a => [lower(a.name), a]));
        const companyMap = new Map(companies.map(c => [lower(c.name), c]));
        const lineMap = new Map(lines.map(l => [lower(l.name), l]));
        // Tables keyed by lowercased name (names are unique enough for human-readable matching)
        const tableMap = new Map(tables.map(t => [lower(t.name), t]));

        // Index existing assignments by agent_id|company_id|line_id to enable upsert
        const existingKey = (a) => `${a.agent_id}|${a.company_id}|${a.line_id}`;
        const existingMap = new Map(existingAssignments.map(a => [existingKey(a), a]));

        const res = { success: 0, updated: 0, failed: 0, errors: [] };

        for (const [idx, row] of rows.entries()) {
          const agentName       = gv(row, 'agent_name', 'AGENT_NAME', 'Agente', 'AGENTE');
          const companyName     = gv(row, 'company_name', 'COMPANY_NAME', 'Compania', 'COMPANIA');
          const lineName        = gv(row, 'line_name', 'LINE_NAME', 'Ramo', 'RAMO');
          const commissionTableName = gv(row, 'commission_table_name', 'COMMISSION_TABLE_NAME', 'TablaComision', 'TABLA_COMISION', 'Tabla');

          if (!agentName || !companyName || !lineName || !commissionTableName) {
            res.failed++;
            res.errors.push(`Fila ${idx + 2}: todos los campos son obligatorios`);
            continue;
          }

          const agent   = agentMap.get(lower(agentName));
          const company = companyMap.get(lower(companyName));
          const line    = lineMap.get(lower(lineName));
          const table   = tableMap.get(lower(commissionTableName));

          if (!agent)   { res.failed++; res.errors.push(`Fila ${idx + 2}: agente "${agentName}" no encontrado`); continue; }
          if (!company) { res.failed++; res.errors.push(`Fila ${idx + 2}: compañía "${companyName}" no encontrada`); continue; }
          if (!line)    { res.failed++; res.errors.push(`Fila ${idx + 2}: ramo "${lineName}" no encontrado`); continue; }
          if (!table)   { res.failed++; res.errors.push(`Fila ${idx + 2}: tabla de comisión "${commissionTableName}" no encontrada`); continue; }

          const payload = {
            agent_id:             agent.id,
            agent_name:           agent.name,
            company_id:           company.id,
            company_name:         company.name,
            line_id:              line.id,
            line_name:           line.name,
            commission_table_id:  table.id,
            commission_table_name: table.name,
          };

          const key = existingKey(payload);
          const existing = existingMap.get(key);
          try {
            if (existing) {
              // Only update if the table reference actually changed
              if (existing.commission_table_id !== table.id) {
                await api.entities.AgentCommissionAssignment.update(existing.id, {
                  commission_table_id: table.id,
                  commission_table_name: table.name,
                });
                res.updated++;
              }
            } else {
              await api.entities.AgentCommissionAssignment.create(payload);
              res.success++;
              existingMap.set(key, { ...payload, id: 'pending' });
            }
          } catch (err) {
            res.failed++;
            res.errors.push(`Fila ${idx + 2} (${agentName}/${companyName}/${lineName}): ${err.message}`);
          }
        }

        setResults(res);
        if (res.success > 0 || res.updated > 0) toast.success(`${res.success} creadas, ${res.updated} actualizadas`);
        if (res.failed > 0) toast.error(`${res.failed} errores`);
      } catch (err) {
        toast.error('Error: ' + err.message);
      } finally {
        setImporting(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const reset = () => { setFile(null); setResults(null); };

  return (
    <div className="space-y-4">
      <Alert className="border-border bg-muted">
        <AlertCircle className="h-4 w-4 text-foreground" />
        <AlertDescription className="text-foreground text-sm">
          Asigna tablas de comisión específicas por agente + compañía + ramo. Un agente puede tener múltiples asignaciones (una por compañía/ramo) o ninguna.
          Si ya existe una asignación para esa combinación, se actualiza la tabla. Agentes, compañías, ramos y tablas deben existir previamente.
        </AlertDescription>
      </Alert>
      <Card className="p-6 border-0 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Importar Asignaciones de Comisiones</h3>
          <Button onClick={downloadTemplate} variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" /> Descargar Plantilla
          </Button>
        </div>
        {!results ? (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-input rounded-lg p-8 text-center hover:border-border transition-colors">
              <Upload className="h-10 w-10 text-muted-foreground/70 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-3">Selecciona un archivo Excel (.xlsx)</p>
              <Input type="file" accept=".xlsx,.xls"
                onChange={e => { setFile(e.target.files[0]); setResults(null); }}
                className="max-w-xs mx-auto" />
            </div>
            {file && (
              <div className="flex items-center justify-between p-3 bg-muted/40 rounded-lg">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <span className="text-sm font-medium">{file.name}</span>
                  <span className="text-xs text-muted-foreground/70">({(file.size / 1024).toFixed(1)} KB)</span>
                </div>
                <Button onClick={handleImport} disabled={importing} className="gap-2">
                  {importing && <Loader2 className="h-4 w-4 animate-spin" />}
                  {importing ? 'Importando...' : 'Importar'}
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <Alert className="border-green-500/30 bg-green-500/10">
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertDescription className="text-green-600 dark:text-green-400">
                  <span className="font-bold text-xl">{results.success}</span> creadas
                </AlertDescription>
              </Alert>
              <Alert className="border-border bg-muted">
                <CheckCircle className="h-4 w-4 text-foreground" />
                <AlertDescription className="text-foreground">
                  <span className="font-bold text-xl">{results.updated}</span> actualizadas
                </AlertDescription>
              </Alert>
              <Alert className={results.failed > 0 ? 'border-red-500/30 bg-red-500/10' : 'border-border bg-muted/40'}>
                <XCircle className={`h-4 w-4 ${results.failed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground/70'}`} />
                <AlertDescription className={results.failed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground'}>
                  <span className="font-bold text-xl">{results.failed}</span> errores
                </AlertDescription>
              </Alert>
            </div>
            {results.errors.length > 0 && (
              <div className="p-3 bg-red-500/10 rounded-lg max-h-44 overflow-y-auto">
                <p className="font-medium text-red-600 dark:text-red-400 text-sm mb-2">Errores:</p>
                {results.errors.map((e, i) => <p key={i} className="text-xs text-red-600 dark:text-red-400">• {e}</p>)}
              </div>
            )}
            <Button onClick={reset} variant="outline" size="sm">Nueva Importación</Button>
          </div>
        )}
      </Card>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
const TABS = [
  { id: 'branches',   label: 'Branches',   icon: GitBranch  },
  { id: 'lines',      label: 'Ramos',      icon: Layers     },
  { id: 'companies',  label: 'Compañías',  icon: Building2  },
  { id: 'products',   label: 'Productos',  icon: Package    },
  { id: 'agents',     label: 'Agentes',    icon: Users      },
  { id: 'commtables', label: 'Comisiones', icon: Table2     },
  { id: 'assign',     label: 'Asignaciones', icon: Users    },
];

export default function SystemDataImport() {
  const [activeTab, setActiveTab] = useState('branches');

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-5xl mx-auto">
        <PageHeader
          title="Importación de Datos del Sistema"
          subtitle="Carga masiva de configuración inicial desde Excel"
          backTo="AdminPanel"
          icon={FileSpreadsheet}
        />

        <Alert className="border-amber-500/30 bg-amber-500/10 mb-6">
          <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          <AlertDescription className="text-amber-600 dark:text-amber-400 text-sm">
            <strong>Orden recomendado:</strong> Branches → Ramos → Compañías → Productos → Agentes → Tablas de Comisiones → Asignaciones.
            Cada entidad depende de las anteriores.
          </AlertDescription>
        </Alert>

        <InitialImportCard />

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-7 mb-6">
            {TABS.map(tab => {
              const Icon = tab.icon;
              return (
                <TabsTrigger key={tab.id} value={tab.id} className="gap-1.5 text-xs">
                  <Icon className="h-3.5 w-3.5" />
                  {tab.label}
                </TabsTrigger>
              );
            })}
          </TabsList>

          <TabsContent value="branches">   <BranchesTab /> </TabsContent>
          <TabsContent value="lines">      <LinesTab /> </TabsContent>
          <TabsContent value="companies">  <CompaniesTab /> </TabsContent>
          <TabsContent value="products">   <ProductsTab /> </TabsContent>
          <TabsContent value="agents">     <AgentsTab /> </TabsContent>
          <TabsContent value="commtables"> <CommissionTablesTab /> </TabsContent>
          <TabsContent value="assign">     <AssignmentsTab /> </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}