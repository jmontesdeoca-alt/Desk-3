import React, { useState, useMemo } from 'react';
import { api } from '@/api/client';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, FileSpreadsheet, Loader2, CheckCircle2, AlertTriangle, XCircle, Download, Search, ArrowRight, Pencil, ChevronDown } from 'lucide-react';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const statusConfig = {
  correct: { label: 'Correcta', icon: CheckCircle2, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-500/10', badge: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30' },
  warning: { label: 'Advertencia', icon: AlertTriangle, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-500/10', badge: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30' },
  error: { label: 'Error', icon: XCircle, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-500/10', badge: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30' }
};

const FIELDS = [
  { key: 'numero_poliza', label: 'N° Póliza', required: true, keywords: ['poliza', 'póliza', 'numero', 'número', 'no.', 'n°', 'num'] },
  { key: 'titular', label: 'Titular / Cliente', required: true, keywords: ['titular', 'cliente', 'nombre', 'asegurado', 'razon', 'razón'] },
  { key: 'prima', label: 'Prima', required: false, keywords: ['prima', 'premium', 'valor', 'monto', 'annual'] },
  { key: 'agente', label: 'Agente', required: false, keywords: ['agente', 'agent', 'vendedor', 'ejecutivo', 'asesor'] },
  { key: 'compania', label: 'Compañía', required: false, keywords: ['compania', 'compañía', 'aseguradora', 'company', 'insurance', 'cia'] }
];

const autoDetectColumn = (headers, field) => {
  for (const h of headers) {
    const lower = h.toString().toLowerCase().trim();
    if (field.keywords.some(kw => lower.includes(kw))) return h;
  }
  return '';
};

export default function DataAudit() {
  const [file, setFile] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [allRows, setAllRows] = useState([]);
  const [parsing, setParsing] = useState(false);
  const [mapping, setMapping] = useState({});
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [editRow, setEditRow] = useState(null);
  const [editField, setEditField] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [saving, setSaving] = useState(false);

  const handleFileChange = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setResults(null);
    setHeaders([]);
    setAllRows([]);
    setMapping({});
    setParsing(true);

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(firstSheet, { defval: '' });
        if (jsonData.length === 0) {
          toast.error('El archivo no tiene datos');
          setParsing(false);
          return;
        }
        const cols = Object.keys(jsonData[0]);
        setHeaders(cols);
        setAllRows(jsonData);
        // Auto-detectar columnas
        const auto = {};
        for (const field of FIELDS) {
          auto[field.key] = autoDetectColumn(cols, field);
        }
        setMapping(auto);
        setParsing(false);
      } catch (err) {
        console.error('Error parsing:', err);
        toast.error('No se pudo leer el archivo Excel');
        setParsing(false);
      }
    };
    reader.readAsArrayBuffer(f);
  };

  const mappingReady = mapping.numero_poliza && mapping.titular;

  const runAudit = async () => {
    if (!mappingReady) {
      toast.error('Selecciona las columnas de N° Póliza y Titular');
      return;
    }
    setLoading(true);
    setResults(null);
    try {
      // Mapear filas usando las columnas seleccionadas
      const policies = allRows.map(row => {
        const mapped = {
          numero_poliza: row[mapping.numero_poliza] ?? '',
          titular: row[mapping.titular] ?? ''
        };
        if (mapping.prima) mapped.prima = row[mapping.prima] ?? '';
        if (mapping.agente) mapped.agente = row[mapping.agente] ?? '';
        if (mapping.compania) mapped.compania = row[mapping.compania] ?? '';
        return mapped;
      }).filter(p => p.numero_poliza || p.titular);

      if (policies.length === 0) {
        toast.error('No hay datos válidos con el mapeo seleccionado');
        setLoading(false);
        return;
      }

      // Enviar datos ya mapeados al backend
      const resp = await api.functions.invoke('auditoriaDeDatos', { policies });
      const data = resp?.data || resp;
      if (data?.error) throw new Error(data.error);
      setResults(data);
      toast.success(`Auditoría completada: ${data.total} pólizas revisadas`);
    } catch (error) {
      console.error('Error:', error);
      toast.error(error.message || 'Error al ejecutar la auditoría');
    } finally {
      setLoading(false);
    }
  };

  const exportExcel = () => {
    if (!results?.results) return;
    const data = results.results.map(r => ({
      'Fila': r.fila,
      'N° Póliza (Excel)': r.numero_poliza,
      'Titular (Excel)': r.titular,
      'Prima (Excel)': r.prima,
      'Agente (Excel)': r.agente,
      'Compañía (Excel)': r.compania,
      'Póliza en BD': r.poliza_bd || '-',
      'Estado BD': r.estado_bd || '-',
      'Estado Auditoría': statusConfig[r.status]?.label || r.status,
      'Novedades': r.findings
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Auditoría');
    XLSX.writeFile(wb, `auditoria_polizas_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const openEdit = (row, field) => {
    setEditRow(row);
    setEditField(field);
    // Pre-llenar con el valor del Excel (lo que se quiere aplicar)
    setEditValue(row[field] ?? '');
  };

  const applyCorrection = async () => {
    if (!editRow?.policy_id || !editField) return;
    setSaving(true);
    try {
      const fieldMap = { prima: 'annual_premium', titular: 'client_name', agente: 'agent_name' };
      const backendField = fieldMap[editField];
      const resp = await api.functions.invoke('actualizarPolizaAuditada', {
        policy_id: editRow.policy_id,
        field: backendField,
        value: editValue
      });
      const data = resp?.data || resp;
      if (data?.error) throw new Error(data.error);

      // Actualizar el resultado en la UI
      setResults(prev => {
        const updated = { ...prev };
        updated.results = updated.results.map(r => {
          if (r.fila === editRow.fila) {
            const newFindings = r.findings + ` | ✅ Corregido: ${backendField} = ${data.new_value}`;
            return { ...r, [editField]: editValue, findings: newFindings, status: 'correct' };
          }
          return r;
        });
        updated.errors = updated.results.filter(r => r.status === 'error').length;
        updated.warnings = updated.results.filter(r => r.status === 'warning').length;
        updated.correct = updated.results.filter(r => r.status === 'correct').length;
        return updated;
      });

      toast.success(`${backendField === 'annual_premium' ? 'Prima' : backendField === 'client_name' ? 'Titular' : 'Agente'} actualizado correctamente`);
      setEditRow(null);
      setEditField(null);
      setEditValue('');
    } catch (error) {
      console.error('Error:', error);
      toast.error(error.message || 'Error al actualizar');
    } finally {
      setSaving(false);
    }
  };

  const filteredResults = useMemo(() => {
    return (results?.results || []).filter(r => {
      if (filter !== 'all' && r.status !== filter) return false;
      if (search) {
        const q = search.toLowerCase();
        return (r.numero_poliza || '').toLowerCase().includes(q) ||
               (r.titular || '').toLowerCase().includes(q) ||
               (r.agente || '').toLowerCase().includes(q) ||
               (r.findings || '').toLowerCase().includes(q);
      }
      return true;
    });
  }, [results, filter, search]);

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center gap-2 sm:gap-3 mb-2">
            <div className="p-2 rounded-lg bg-brand/10 dark:bg-brand/20">
              <FileSpreadsheet className="h-5 w-5 sm:h-6 sm:w-6 text-brand" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground dark:text-white">Auditoría de Datos</h1>
          </div>
          <p className="text-sm sm:text-base text-muted-foreground ">
            Carga un Excel, mapea las columnas y valida las pólizas contra la base de datos.
          </p>
        </div>

        {/* Upload Card */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground/80 mb-2">
                  Archivo Excel de pólizas
                </label>
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleFileChange}
                    className="block w-full text-sm text-muted-foreground file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-brand/10 file:text-brand hover:file:bg-brand/20 cursor-pointer"
                  />
                </div>
                {file && (
                  <p className="text-xs text-muted-foreground mt-2">
                    Archivo: <span className="font-medium">{file.name}</span> ({(file.size / 1024).toFixed(1)} KB)
                    {allRows.length > 0 && <span> · {allRows.length} filas detectadas</span>}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Column Mapping */}
        {parsing && (
          <Card className="border-0 shadow-sm mb-6">
            <CardContent className="p-6 flex items-center gap-3 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              Leyendo archivo...
            </CardContent>
          </Card>
        )}

        {headers.length > 0 && !parsing && (
          <Card className="border-0 shadow-sm mb-6">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <ArrowRight className="h-4 w-4 text-brand" />
                <h2 className="text-base font-semibold text-foreground ">Mapeo de Columnas</h2>
                <span className="text-xs text-muted-foreground">Selecciona qué columna del Excel corresponde a cada campo</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {FIELDS.map(field => (
                  <div key={field.key}>
                    <label className="block text-sm font-medium text-foreground/80 mb-1.5">
                      {field.label}
                      {field.required && <span className="text-red-500 ml-1">*</span>}
                    </label>
                    <select
                      value={mapping[field.key] || ''}
                      onChange={(e) => setMapping(prev => ({ ...prev, [field.key]: e.target.value }))}
                      className="w-full px-3 py-2 text-sm border border-border rounded-md bg-card text-foreground dark:text-white focus:ring-2 focus:ring-brand/30 focus:border-brand outline-none"
                    >
                      <option value="">— No mapear —</option>
                      {headers.map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                <p className="text-xs text-muted-foreground">
                  {mappingReady
                    ? <span className="text-emerald-600 dark:text-emerald-400">✓ Mapeo listo. Se procesarán {allRows.filter(r => r[mapping.numero_poliza] || r[mapping.titular]).length} filas.</span>
                    : <span className="text-red-500">⚠ Selecciona al menos N° Póliza y Titular.</span>
                  }
                </p>
                <Button onClick={runAudit} disabled={!mappingReady || loading} className="gap-2">
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  {loading ? 'Auditando...' : 'Ejecutar Auditoría'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {results && (
          <>
            {results.extraction_warning && (
              <div className="mb-4 p-3 rounded-lg bg-amber-500/10 dark:bg-amber-900/20 border border-amber-500/30 dark:border-amber-800 text-sm text-amber-600 dark:text-amber-400 dark:text-amber-400">
                ⚠️ {results.extraction_warning}
              </div>
            )}
            {/* Summary Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Total Revisadas</p>
                  <p className="text-2xl font-bold text-foreground dark:text-white">{results.total}</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4 flex items-center gap-3">
                  <CheckCircle2 className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Correctas</p>
                    <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{results.correct}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4 flex items-center gap-3">
                  <AlertTriangle className="h-8 w-8 text-amber-600 dark:text-amber-400" />
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Advertencias</p>
                    <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{results.warnings}</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4 flex items-center gap-3">
                  <XCircle className="h-8 w-8 text-red-600 dark:text-red-400" />
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Errores</p>
                    <p className="text-2xl font-bold text-red-600 dark:text-red-400">{results.errors}</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Filters & Export */}
            <Card className="border-0 shadow-sm mb-4">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" variant={filter === 'all' ? 'default' : 'outline'} onClick={() => setFilter('all')}>
                      Todos ({results.total})
                    </Button>
                    <Button size="sm" variant={filter === 'correct' ? 'default' : 'outline'} onClick={() => setFilter('correct')}
                      className={filter === 'correct' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}>
                      Correctas ({results.correct})
                    </Button>
                    <Button size="sm" variant={filter === 'warning' ? 'default' : 'outline'} onClick={() => setFilter('warning')}
                      className={filter === 'warning' ? 'bg-amber-600 hover:bg-amber-700' : ''}>
                      Advertencias ({results.warnings})
                    </Button>
                    <Button size="sm" variant={filter === 'error' ? 'default' : 'outline'} onClick={() => setFilter('error')}
                      className={filter === 'error' ? 'bg-red-600 hover:bg-red-700' : ''}>
                      Errores ({results.errors})
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <div className="relative">
                      <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
                      <input
                        type="text"
                        placeholder="Buscar..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="pl-8 pr-3 py-1.5 text-sm border border-border rounded-md bg-card w-full sm:w-48"
                      />
                    </div>
                    <Button size="sm" variant="outline" onClick={exportExcel} className="gap-2 shrink-0">
                      <Download className="h-4 w-4" />
                      Exportar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Results Table */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/40 border-b border-border ">
                      <tr>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">Fila</th>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">N° Póliza</th>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">Titular</th>
                        <th className="text-right px-3 py-3 font-medium text-muted-foreground ">Prima</th>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">Agente</th>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">Póliza BD</th>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">Estado</th>
                        <th className="text-left px-3 py-3 font-medium text-muted-foreground ">Novedades</th>
                        <th className="text-center px-3 py-3 font-medium text-muted-foreground ">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border ">
                      {filteredResults.map((r, idx) => {
                        const cfg = statusConfig[r.status];
                        const Icon = cfg.icon;
                        return (
                          <tr key={idx} className="hover:bg-muted/40 ">
                            <td className="px-3 py-2 text-muted-foreground">{r.fila}</td>
                            <td className="px-3 py-2 font-medium text-foreground dark:text-white">{r.numero_poliza || '-'}</td>
                            <td className="px-3 py-2 text-foreground/80 ">{r.titular || '-'}</td>
                            <td className="px-3 py-2 text-right text-foreground/80 ">{r.prima ?? '-'}</td>
                            <td className="px-3 py-2 text-foreground/80 ">{r.agente || '-'}</td>
                            <td className="px-3 py-2 text-foreground/80 ">{r.poliza_bd || '-'}</td>
                            <td className="px-3 py-2">
                              <Badge variant="outline" className={cfg.badge + ' gap-1'}>
                                <Icon className="h-3 w-3" />
                                {cfg.label}
                              </Badge>
                            </td>
                            <td className="px-3 py-2 text-xs text-muted-foreground max-w-md">{r.findings}</td>
                            <td className="px-3 py-2 text-center">
                              {r.policy_id && r.status !== 'correct' && (() => {
                                const options = [];
                                if (r.titular && r.findings.includes('Titular no coincide')) options.push({ field: 'titular', label: 'Titular' });
                                if (r.prima != null && r.findings.includes('Prima no coincide')) options.push({ field: 'prima', label: 'Prima' });
                                if (r.agente && r.findings.includes('Agente no coincide')) options.push({ field: 'agente', label: 'Agente' });
                                if (options.length === 0) return null;
                                return (
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button size="sm" variant="outline" className="h-7 px-2 text-xs gap-1">
                                        <Pencil className="h-3 w-3" /> Corregir
                                        <ChevronDown className="h-3 w-3" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end" className="w-36">
                                      {options.map(opt => (
                                        <DropdownMenuItem key={opt.field} onClick={() => openEdit(r, opt.field)} className="text-xs cursor-pointer">
                                          {opt.label}
                                        </DropdownMenuItem>
                                      ))}
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                );
                              })()}
                            </td>
                          </tr>
                        );
                      })}
                      {filteredResults.length === 0 && (
                        <tr>
                          <td colSpan={9} className="px-3 py-8 text-center text-muted-foreground/70">
                            No hay resultados para el filtro seleccionado
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {/* Modal de corrección */}
        <Dialog open={!!editRow} onOpenChange={(open) => { if (!open) { setEditRow(null); setEditField(null); } }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Corregir {editField === 'prima' ? 'Prima' : editField === 'titular' ? 'Titular' : 'Agente'}</DialogTitle>
            </DialogHeader>
            {editRow && (
              <div className="space-y-4 py-2">
                <div className="text-sm text-muted-foreground space-y-1">
                  <p><span className="font-medium">Póliza BD:</span> {editRow.poliza_bd}</p>
                  <p><span className="font-medium">Valor actual en BD:</span> {editRow[editField === 'prima' ? 'prima_bd' : editField === 'titular' ? 'titular_bd' : 'agente_bd'] ?? '-'}</p>
                </div>
                <div>
                  <Label className="mb-1.5 block">Nuevo valor</Label>
                  <Input
                    type={editField === 'prima' ? 'number' : 'text'}
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    autoFocus
                  />
                </div>
                <p className="text-xs text-amber-600 dark:text-amber-400 dark:text-amber-400">
                  ⚠️ Esta acción actualizará la póliza en la base de datos y quedará registrada en el log de auditoría.
                </p>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => { setEditRow(null); setEditField(null); }} disabled={saving}>
                Cancelar
              </Button>
              <Button onClick={applyCorrection} disabled={saving || !editValue}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                Aplicar corrección
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}