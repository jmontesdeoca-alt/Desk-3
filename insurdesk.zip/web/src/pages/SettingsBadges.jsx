import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import PageHeader from '@/components/ui/PageHeader';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useForm } from 'react-hook-form';
import { Plus, Trash2, Award } from 'lucide-react';

const BADGE_ICONS = ['⭐', '🏆', '🎖️', '👑', '💎', '🔥', '⚡', '🚀'];

export default function SettingsBadges() {
  const [badges, setBadges] = useState([]);
  const [open, setOpen] = useState(false);
  const [editingBadge, setEditingBadge] = useState(null);
  const [loading, setLoading] = useState(true);
  const { register, handleSubmit, reset, setValue, watch } = useForm();

  useEffect(() => {
    loadBadges();
  }, []);

  const loadBadges = async () => {
    try {
      const data = await api.entities.Badge.list();
      setBadges(data);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenForm = (badge = null) => {
    if (badge) {
      setEditingBadge(badge);
      Object.keys(badge).forEach(key => setValue(key, badge[key]));
    } else {
      setEditingBadge(null);
      reset();
    }
    setOpen(true);
  };

  const onSubmit = async (data) => {
    try {
      if (editingBadge) {
        await api.entities.Badge.update(editingBadge.id, data);
      } else {
        await api.entities.Badge.create(data);
      }
      setOpen(false);
      loadBadges();
    } catch (error) {
      console.error('Error saving badge:', error);
    }
  };

  const handleDelete = async (id) => {
    if (confirm('¿Eliminar esta insignia?')) {
      try {
        await api.entities.Badge.delete(id);
        loadBadges();
      } catch (error) {
        console.error('Error deleting badge:', error);
      }
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <PageHeader 
          title="Gestión de Insignias" 
          subtitle="Crea y administra insignias para los agentes"
          icon={Award}
          backTo="AdminPanel"
          actions={
            <Button onClick={() => handleOpenForm()} className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Insignia
            </Button>
          }
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {badges.map(badge => (
            <Card key={badge.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex gap-3 flex-1">
                  <span className="text-4xl">{badge.icon}</span>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{badge.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{badge.description}</p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant="outline">{badge.badge_type}</Badge>
                      <Badge variant="outline">{badge.tier}</Badge>
                      <Badge variant={badge.status === 'activa' ? 'default' : 'secondary'}>
                        {badge.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => handleOpenForm(badge)}
                  >
                    ✏️
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => handleDelete(badge.id)}
                    className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingBadge ? 'Editar Insignia' : 'Nueva Insignia'}</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre *</Label>
                <Input {...register('name', { required: true })} placeholder="Ej: Top Vendedor" />
              </div>

              <div className="space-y-2">
                <Label>Descripción *</Label>
                <Input {...register('description', { required: true })} placeholder="Descripción breve" />
              </div>

              <div className="space-y-2">
                <Label>Emoji/Icono *</Label>
                <div className="grid grid-cols-4 gap-2">
                  {BADGE_ICONS.map(icon => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setValue('icon', icon)}
                      className={`p-2 text-2xl rounded border transition ${
                        watch('icon') === icon ? 'border-primary bg-muted' : 'border-border'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Criterios *</Label>
                <Input {...register('criteria', { required: true })} placeholder="Ej: 50 pólizas en el mes" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tipo *</Label>
                  <Select value={watch('badge_type') || ''} onValueChange={(v) => setValue('badge_type', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="performance">Rendimiento</SelectItem>
                      <SelectItem value="milestone">Hito</SelectItem>
                      <SelectItem value="special">Especial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Nivel</Label>
                  <Select value={watch('tier') || ''} onValueChange={(v) => setValue('tier', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bronze">Bronce</SelectItem>
                      <SelectItem value="silver">Plata</SelectItem>
                      <SelectItem value="gold">Oro</SelectItem>
                      <SelectItem value="platinum">Platino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Estado</Label>
                <Select value={watch('status') || 'activa'} onValueChange={(v) => setValue('status', v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activa">Activa</SelectItem>
                    <SelectItem value="inactiva">Inactiva</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90">
                  {editingBadge ? 'Guardar Cambios' : 'Crear Insignia'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}