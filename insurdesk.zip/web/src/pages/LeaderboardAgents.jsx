import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import PageHeader from '@/components/ui/PageHeader';
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Trophy, TrendingUp, DollarSign, Target } from 'lucide-react';
import AgentDetailModal from '@/components/leaderboard/AgentDetailModal';

export default function LeaderboardAgents() {
  const [policies, setPolicies] = useState([]);
  const [commissions, setCommissions] = useState([]);
  const [badges, setBadges] = useState([]);
  const [agentBadges, setAgentBadges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('year');
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [currentMetric, setCurrentMetric] = useState('policies');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [policiesData, commissionsData, badgesData, badgesAgentData, agentsData] = await Promise.all([
        api.entities.Policy.list(),
        api.entities.Commission.list(),
        api.entities.Badge.list(),
        api.entities.AgentBadge.list(),
        api.entities.Agent.list()
      ]);

      // Check if gerencial with agent - limit to structure
      const userRoleResp = await api.functions.invoke('getUserRoleInfo', {});
      const appRole = userRoleResp?.data?.app_role;
      const agentId = userRoleResp?.data?.agent_id;

      if (appRole === 'gerencial' && agentId) {
        const structureIds = [];
        const findStructure = (id) => {
          structureIds.push(id);
          agentsData.filter(a => a.upline_agent_id === id).forEach(child => findStructure(child.id));
        };
        findStructure(agentId);
        setPolicies(policiesData.filter(p => structureIds.includes(p.agent_id)));
        setCommissions(commissionsData.filter(c => structureIds.includes(c.agent_id)));
      } else {
        setPolicies(policiesData);
        setCommissions(commissionsData);
      }

      setBadges(badgesData);
      setAgentBadges(badgesAgentData);
    } finally {
      setLoading(false);
    }
  };

  const getDateRange = () => {
    const now = new Date();
    let startDate = new Date();

    if (period === 'year') {
      startDate.setFullYear(now.getFullYear(), 0, 1);
    } else if (period === 'quarter') {
      const currentQuarter = Math.floor(now.getMonth() / 3);
      startDate = new Date(now.getFullYear(), currentQuarter * 3, 1);
    } else if (period === 'month') {
      startDate.setFullYear(now.getFullYear(), now.getMonth(), 1);
    } else if (period === 'previous_month') {
      startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      now.setFullYear(now.getFullYear(), now.getMonth(), 0);
    } else if (period === 'historic') {
      return { startDate: null, endDate: null };
    }

    return { startDate, endDate: now };
  };

  const isInDateRange = (dateStr) => {
    if (!dateStr) return false;
    if (period === 'historic') return true;
    
    const date = new Date(dateStr);
    const { startDate, endDate } = getDateRange();
    return date >= startDate && date <= endDate;
  };

  const getLeaderboardByMetric = (metric) => {
    const agentStats = {};

    if (metric === 'policies') {
      policies.forEach(p => {
        if (p.agent_id && isInDateRange(p.start_date)) {
          if (!agentStats[p.agent_id]) {
            agentStats[p.agent_id] = { name: p.agent_name || 'N/A', count: 0, value: 0 };
          }
          agentStats[p.agent_id].count += 1;
          agentStats[p.agent_id].value = agentStats[p.agent_id].count;
        }
      });
    } else if (metric === 'premium') {
      policies.forEach(p => {
        if (p.agent_id && isInDateRange(p.start_date)) {
          if (!agentStats[p.agent_id]) {
            agentStats[p.agent_id] = { name: p.agent_name || 'N/A', count: 0, value: 0 };
          }
          agentStats[p.agent_id].value += p.annual_premium || 0;
          agentStats[p.agent_id].count += 1;
        }
      });
    } else if (metric === 'commissions') {
      commissions.forEach(c => {
        if (c.agent_id && isInDateRange(c.generation_date)) {
          if (!agentStats[c.agent_id]) {
            agentStats[c.agent_id] = { name: c.agent_name || 'N/A', count: 0, value: 0 };
          }
          agentStats[c.agent_id].value += c.commission_amount || 0;
          agentStats[c.agent_id].count += 1;
        }
      });
    }

    return Object.entries(agentStats)
      .map(([id, stats]) => ({ id, ...stats }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  };

  const getAgentBadges = (agentId) => {
    return agentBadges
      .filter(ab => ab.agent_id === agentId)
      .map(ab => badges.find(b => b.id === ab.badge_id))
      .filter(Boolean);
  };

  const getAgentStats = (agentId) => {
    const agentPolicies = policies.filter(p => p.agent_id === agentId && isInDateRange(p.start_date));
    const agentCommissions = commissions.filter(c => c.agent_id === agentId && isInDateRange(c.generation_date));
    
    const totalPolicies = agentPolicies.length;
    const totalPremium = agentPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
    const totalCommissions = agentCommissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);

    return { policies: totalPolicies, premium: totalPremium, commissions: totalCommissions };
  };

  const getAgentChartData = (agentId, metric) => {
    const monthlyData = {};

    if (metric === 'policies') {
      policies.filter(p => p.agent_id === agentId).forEach(p => {
        const date = new Date(p.start_date);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        monthlyData[monthKey] = (monthlyData[monthKey] || 0) + 1;
      });
    } else if (metric === 'premium') {
      policies.filter(p => p.agent_id === agentId).forEach(p => {
        const date = new Date(p.start_date);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        monthlyData[monthKey] = (monthlyData[monthKey] || 0) + (p.annual_premium || 0);
      });
    } else if (metric === 'commissions') {
      commissions.filter(c => c.agent_id === agentId).forEach(c => {
        const date = new Date(c.generation_date);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        monthlyData[monthKey] = (monthlyData[monthKey] || 0) + (c.commission_amount || 0);
      });
    }

    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, value]) => ({
        month: new Date(month).toLocaleDateString('es-ES', { month: 'short', year: '2-digit' }),
        value
      }));
  };

  const handleAgentClick = (agent, metric) => {
    setSelectedAgent(agent);
    setCurrentMetric(metric);
    setDetailModalOpen(true);
  };

  const LeaderboardTable = ({ metric, label, unit }) => {
    const leaderboard = getLeaderboardByMetric(metric);
    const medals = ['🥇', '🥈', '🥉'];

    return (
      <div className="space-y-3">
        {leaderboard.map((agent, index) => (
          <div 
            key={agent.id} 
            className="flex items-center justify-between p-4 bg-card rounded-lg border hover:border-border hover:shadow-md cursor-pointer transition-all"
            onClick={() => handleAgentClick(agent, metric)}
          >
            <div className="flex items-center gap-4 flex-1">
              <span className="text-2xl w-8 text-center">{medals[index] || `#${index + 1}`}</span>
              <div>
                <p className="font-semibold text-foreground">{agent.name}</p>
                <div className="flex gap-1.5 mt-1">
                  {getAgentBadges(agent.id).slice(0, 3).map(badge => (
                    <span key={badge.id} title={badge.name} className="text-lg">
                      {badge.icon}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-foreground">
                {metric === 'commissions' 
                  ? `$${agent.value.toFixed(2)}` 
                  : metric === 'premium'
                  ? `$${agent.value.toFixed(0)}`
                  : agent.value}
              </p>
              <p className="text-xs text-muted-foreground">{label}</p>
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <PageHeader 
          title="Tabla de Clasificación de Agentes" 
          subtitle="Desempeño y reconocimientos de agentes"
          icon={Trophy}
          backTo="AdminPanel"
        />

        <div className="mb-6 flex items-center gap-3 flex-wrap">
          <span className="text-sm font-medium text-foreground/80">Período:</span>
          <div className="flex gap-2 flex-wrap">
            <Button 
              variant={period === 'year' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPeriod('year')}
            >
              Año en Curso
            </Button>
            <Button 
              variant={period === 'quarter' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPeriod('quarter')}
            >
              Último Trimestre
            </Button>
            <Button 
              variant={period === 'month' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPeriod('month')}
            >
              Último Mes
            </Button>
            <Button 
              variant={period === 'previous_month' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPeriod('previous_month')}
            >
              Mes Anterior
            </Button>
            <Button 
              variant={period === 'historic' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPeriod('historic')}
            >
              Histórico
            </Button>
          </div>
        </div>

        <Tabs defaultValue="policies" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="policies" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Pólizas
            </TabsTrigger>
            <TabsTrigger value="premium" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Prima
            </TabsTrigger>
            <TabsTrigger value="commissions" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Comisiones
            </TabsTrigger>
          </TabsList>

          <TabsContent value="policies" className="mt-6">
            <Card className="p-6">
              <LeaderboardTable metric="policies" label="Pólizas nuevas" />
            </Card>
          </TabsContent>

          <TabsContent value="premium" className="mt-6">
            <Card className="p-6">
              <LeaderboardTable metric="premium" label="Prima total" />
            </Card>
          </TabsContent>

          <TabsContent value="commissions" className="mt-6">
            <Card className="p-6">
              <LeaderboardTable metric="commissions" label="Comisiones generadas" />
            </Card>
          </TabsContent>
        </Tabs>

        <AgentDetailModal 
          open={detailModalOpen}
          onOpenChange={setDetailModalOpen}
          agent={selectedAgent}
          badges={selectedAgent ? getAgentBadges(selectedAgent.id) : []}
          stats={selectedAgent ? getAgentStats(selectedAgent.id) : null}
          metric={currentMetric}
          chartData={selectedAgent ? getAgentChartData(selectedAgent.id, currentMetric) : []}
        />
      </div>
    </div>
  );
}