import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MobileSelect } from "@/components/ui/MobileSelect";
import {
  SelectItem,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import StatCard from '@/components/ui/StatCard';
import { useSearchCache } from '@/components/SearchCache';
import { DollarSign, Loader2, Filter, Calendar, CheckCircle, AlertCircle, Clock, X, CheckSquare } from 'lucide-react';
import { exportToCSV, exportToExcel } from '@/components/ui/exportUtils';
import { format, isAfter, isBefore } from 'date-fns';
import { es } from 'date-fns/locale';
import { formatDate } from '@/lib/dateUtils';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function Payments() {
  const { t } = useTranslation();
  const { searchQuery, updateSearch, clearSearch } = useSearchCache('payments');
  const [payments, setPayments] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [showPaid, setShowPaid] = useState(true);
  const [showFuture, setShowFuture] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [manualCommissionOpen, setManualCommissionOpen] = useState(false);
  const [pendingPayment, setPendingPayment] = useState(null);
  const [agentsForManualCommission, setAgentsForManualCommission] = useState([]);
  const [saving, setSaving] = useState(false);
  const [selectedPayments, setSelectedPayments] = useState([]);
  const [bulkActionOpen, setBulkActionOpen] = useState(false);
  const [bulkProcessing, setBulkProcessing] = useState(false);
  const [tableResetKey, setTableResetKey] = useState(0);
  const isBulkOperationActive = React.useRef(false);

  useEffect(() => {
    loadPayments();
  }, []);

  const loadPayments = async () => {
    setLoading(true);
    const user = await api.auth.me();
    const companiesData = await api.entities.InsuranceCompany.list();
    const data = await api.entities.Payment.list('due_date', 10000);
    const policies = await api.entities.Policy.list('-created_date', 5000);
    
    setCurrentUser(user);
    // Only keep companies that have actual payment records
    const companyIdsWithPayments = new Set(data.map(p => {
      const policy = new Map(policies.map(pol => [pol.id, pol])).get(p.policy_id);
      return policy?.company_id;
    }).filter(Boolean));
    const filteredCompanies = companiesData
      .filter(c => companyIdsWithPayments.has(c.id))
      .sort((a, b) => a.name.localeCompare(b.name));
    setCompanies(filteredCompanies);
    
    // Build a map for O(1) lookups
    const policyMap = new Map(policies.map(p => [p.id, p]));
    
    // Filter out orphaned payments (payments whose policy doesn't exist)
    const validPayments = data.filter(payment => policyMap.has(payment.policy_id));
    
    // Check for overdue payments and update status in memory only (no API calls on load)
    const today = new Date();
    const updatedPayments = validPayments.map(payment => {
      if (payment.status === 'pendiente' && payment.due_date) {
        const dueDate = new Date(payment.due_date);
        if (isBefore(dueDate, today)) {
          return { ...payment, status: 'atrasado', _needsUpdate: true };
        }
      }
      return payment;
    });

    // Fire-and-forget sequential update in background (one at a time to avoid rate limit)
    const toUpdate = updatedPayments.filter(p => p._needsUpdate);
    if (toUpdate.length > 0) {
      (async () => {
        // Wait for initial data load to settle before starting updates
        await new Promise(resolve => setTimeout(resolve, 3000));
        for (const p of toUpdate) {
          // Pause if a bulk operation is running to avoid rate limit conflicts
          while (isBulkOperationActive.current) {
            await new Promise(resolve => setTimeout(resolve, 500));
          }
          try {
            await api.entities.Payment.update(p.id, { status: 'atrasado' });
            await new Promise(resolve => setTimeout(resolve, 500));
          } catch {
            // Ignore individual update failures silently
          }
        }
      })();
    }
    
    // Enrich payments with company info using map (O(1) vs O(n) find)
    const enrichedPayments = updatedPayments.map(payment => {
      const policy = policyMap.get(payment.policy_id);
      return {
        ...payment,
        company_name: policy?.company_name || '',
        company_id: policy?.company_id || ''
      };
    });
    
    // Filter payments for agents/gerencial - only their structure's policies
    let filteredPayments = enrichedPayments;
    if ((user.app_role === 'agente' || user.app_role === 'gerencial') && user.agent_id && user.app_role !== 'financiero') {
      const allowedAgentIds = await getAgentStructure(user.agent_id);
      const policyIdsInStructure = new Set(
        policies
          .filter(p => allowedAgentIds.includes(p.agent_id))
          .map(p => p.id)
      );
      filteredPayments = enrichedPayments.filter(pay => policyIdsInStructure.has(pay.policy_id));
    }
    
    setPayments(filteredPayments);
    setLoading(false);
  };

  const cleanOrphanedPayments = async () => {
    if (!confirm('¿Eliminar todos los pagos de pólizas eliminadas? Esta acción no se puede deshacer.')) {
      return;
    }
    
    try {
      const [allPayments, policies] = await Promise.all([
        api.entities.Payment.list(),
        api.entities.Policy.list()
      ]);
      const policyIds = new Set(policies.map(p => p.id));
      const orphanedPayments = allPayments.filter(payment => !policyIds.has(payment.policy_id));
      
      if (orphanedPayments.length === 0) {
        toast.info('No hay pagos huérfanos para eliminar');
        return;
      }

      for (const payment of orphanedPayments) {
        await api.entities.Payment.delete(payment.id);
      }
      
      toast.success(`Se eliminaron ${orphanedPayments.length} pagos huérfanos`);
      loadPayments();
    } catch (error) {
      toast.error('Error al limpiar pagos huérfanos: ' + error.message);
    }
  };

  const getAgentStructure = async (agentId) => {
    const agents = await api.entities.Agent.list();
    const structure = [agentId];
    
    const findDownline = (id) => {
      const downline = agents.filter(a => a.upline_agent_id === id);
      downline.forEach(agent => {
        structure.push(agent.id);
        findDownline(agent.id);
      });
    };
    
    findDownline(agentId);
    return structure;
  };

  const checkCommissionTableExists = async (policyId) => {
    const policies = await api.entities.Policy.filter({ id: policyId });
    if (policies.length === 0) return false;
    
    const policy = policies[0];
    const assignments = await api.entities.AgentCommissionAssignment.filter({
      agent_id: policy.agent_id,
      company_id: policy.company_id,
      line_id: policy.line_id
    });
    
    return assignments.length > 0;
  };

  const loadAgentsForManualCommission = async (policyId) => {
    const policies = await api.entities.Policy.filter({ id: policyId });
    if (policies.length === 0) return;
    
    const policy = policies[0];
    const agents = await api.entities.Agent.list();
    let currentAgent = agents.find(a => a.id === policy.agent_id);
    
    const agentList = [];
    let level = 1;
    
    while (currentAgent && level <= 10) {
      agentList.push({
        id: currentAgent.id,
        name: currentAgent.name,
        level: level,
        percentage: 0
      });
      
      if (currentAgent.upline_agent_id) {
        currentAgent = agents.find(a => a.id === currentAgent.upline_agent_id);
        level++;
      } else {
        break;
      }
    }
    
    setAgentsForManualCommission(agentList);
  };

  const markAsPaid = async (payment) => {
    try {
      // Get policy
      const policies = await api.entities.Policy.filter({ id: payment.policy_id });
      if (policies.length === 0) {
        toast.error('No se encontró la póliza');
        return;
      }
      const policy = policies[0];
      
      // TEMPORALMENTE DESACTIVADO: bloqueo de cuotas anteriores deshabilitado para liquidación
      // const allPayments = await api.entities.Payment.filter({ policy_id: payment.policy_id });
      // const previousPayments = allPayments.filter(
      //   p => p.installment_number && payment.installment_number &&
      //        p.installment_number < payment.installment_number
      // );
      // const unpaidPrevious = previousPayments.find(p => p.status !== 'pagado');
      // if (unpaidPrevious) {
      //   toast.error(`No se puede pagar la cuota ${payment.installment_number}. Primero debe pagar la cuota ${unpaidPrevious.installment_number}.`);
      //   return;
      // }

      // Verificar si ya existe comisión anualizada
      const companies = await api.entities.InsuranceCompany.list();
      const company = companies.find(c => c.id === policy.company_id);
      const isNewBusiness = policy.policy_type === 'nuevo_negocio';
      const paymentType = isNewBusiness ? company?.new_business_payment_type : company?.renewal_payment_type;
      
      if (paymentType === 'anualizada') {
        const existingCommissions = await api.entities.Commission.filter({ 
          policy_id: policy.id 
        });
        
        if (existingCommissions.length > 0) {
          toast.info('Esta póliza ya tiene comisión anualizada generada. No se generarán comisiones adicionales.');
          
          await api.entities.Payment.update(payment.id, {
            status: 'pagado',
            payment_date: new Date().toISOString().split('T')[0]
          });
          
          await loadPayments();
          return;
        }
      }

      // Verificar si hay tabla de comisiones asignada
      const hasCommissionTable = await checkCommissionTableExists(payment.policy_id);
      
      if (!hasCommissionTable) {
        // Abrir diálogo de liquidación manual
        setPendingPayment({ ...payment, policy });
        await loadAgentsForManualCommission(payment.policy_id);
        setManualCommissionOpen(true);
        return;
      }

      await api.entities.Payment.update(payment.id, {
        status: 'pagado',
        payment_date: new Date().toISOString().split('T')[0]
      });
      
      // Generate commissions for this payment
      await generateCommissionsForPayment(payment);
      
      await loadPayments();
    } catch (error) {
      console.error('Error marking as paid:', error);
      toast.error('Error al procesar el pago: ' + error.message);
    }
  };

  const generateCommissionsForPayment = async (payment) => {
    try {
      // Get the policy
      const policies = await api.entities.Policy.filter({ id: payment.policy_id });
      if (policies.length === 0) {
        console.log('No policy found for payment:', payment.id);
        return;
      }
    
    const policy = policies[0];
    
    // Get the company to check payment type
    const companyData = await api.entities.InsuranceCompany.filter({ id: policy.company_id });
    const company = companyData[0];
    
    const isRenewal = policy.policy_type === 'renovacion';
    const paymentType = isRenewal ? company?.renewal_payment_type : company?.new_business_payment_type;
    
    // Si es anualizada, verificar si ya existen comisiones
    if (paymentType === 'anualizada') {
      const existingCommissions = await api.entities.Commission.filter({ 
        policy_id: policy.id 
      });
      
      if (existingCommissions.length > 0) {
        return; // Ya se generó la comisión anualizada
      }
    }
    
    // Check if commissions already exist for this policy + installment number
    const existingComms = await api.entities.Commission.filter({ 
      policy_id: policy.id,
      installment_number: payment.installment_number
    });
    if (existingComms.length > 0) {
      console.log(`Commissions already exist for policy ${policy.policy_number}, installment ${payment.installment_number}`);
      return; // Already generated for this installment
    }
    
    // Get the selling agent
    const agentData = await api.entities.Agent.filter({ id: policy.agent_id });
    if (agentData.length === 0) return;
    
    let currentAgent = agentData[0];
    const commissions = [];
    let level = 1;
    let previousPct = 0;
    
    // Calculate base amount based on payment type
    let baseAmount;
    
    const fullCommissionableAmount = policy.commissionable_premium || policy.annual_premium;
    
    if (paymentType === 'segun_cliente') {
      // Commission calculated per installment paid
      const frequencies = { mensual: 12, trimestral: 4, semestral: 2, anual: 1, unico: 1 };
      const numInstallments = frequencies[policy.payment_frequency] || 1;
      baseAmount = fullCommissionableAmount / numInstallments;
    } else {
      // Annualized payment type - full amount on first payment only
      if (payment.installment_number !== 1) {
        console.log(`Anualizada payment type - no commission for installment ${payment.installment_number}`);
        return;
      }
      baseAmount = fullCommissionableAmount;
    }
    
    // Collect all agents and their tables first
    const agentChain = [];
    let tempAgent = currentAgent;
    let tempLevel = 1;
    
    while (tempAgent && tempLevel <= 10) {
      const assignments = await api.entities.AgentCommissionAssignment.filter({
        agent_id: tempAgent.id,
        company_id: policy.company_id,
        line_id: policy.line_id
      });
      
      let agentTable = null;
      let agentPct = 0;
      
      if (assignments.length > 0) {
        const tables = await api.entities.CommissionTable.filter({ 
          id: assignments[0].commission_table_id 
        });
        
        if (tables.length > 0) {
          const productComm = tables[0].product_commissions?.find(pc => pc.product_id === policy.product_id);
          if (productComm) {
            agentPct = isRenewal ? productComm.renewal_percentage : productComm.new_business_percentage;
            agentTable = tables[0];
          }
        }
      }
      
      agentChain.push({
        agent: tempAgent,
        level: tempLevel,
        fullPct: agentPct,
        table: agentTable
      });
      
      if (tempAgent.upline_agent_id) {
        const uplineData = await api.entities.Agent.filter({ id: tempAgent.upline_agent_id });
        tempAgent = uplineData[0] || null;
        tempLevel++;
      } else {
        tempAgent = null;
      }
    }
    
    // Calculate commissions based on differentials
    for (let i = 0; i < agentChain.length; i++) {
      const current = agentChain[i];
      
      // For level 1 (selling agent), they get their full percentage
      if (i === 0) {
        if (current.fullPct > 0) {
          const commissionAmount = (baseAmount * current.fullPct) / 100;
          
          commissions.push({
            policy_id: policy.id,
            policy_number: policy.policy_number,
            product_id: policy.product_id,
            product_name: policy.product_name,
            company_id: policy.company_id,
            company_name: policy.company_name,
            agent_id: current.agent.id,
            agent_name: current.agent.name,
            client_name: policy.client_name,
            level: current.level,
            base_amount: baseAmount,
            commission_pct: current.fullPct,
            commission_amount: commissionAmount,
            installment_number: payment.installment_number,
            currency: policy.currency,
            generation_date: new Date().toISOString().split('T')[0],
            status: 'pendiente_liberar',
            source_type: isRenewal ? 'renovacion' : 'nuevo_negocio'
          });
        }
      } else {
        // For upline agents, they get the differential (their % - subordinate's %)
        const subordinate = agentChain[i - 1];
        const differential = current.fullPct - subordinate.fullPct;
        
        if (differential > 0) {
          const commissionAmount = (baseAmount * differential) / 100;
          
          commissions.push({
            policy_id: policy.id,
            policy_number: policy.policy_number,
            product_id: policy.product_id,
            product_name: policy.product_name,
            company_id: policy.company_id,
            company_name: policy.company_name,
            agent_id: current.agent.id,
            agent_name: current.agent.name,
            client_name: policy.client_name,
            level: current.level,
            base_amount: baseAmount,
            commission_pct: differential,
            commission_amount: commissionAmount,
            installment_number: payment.installment_number,
            currency: policy.currency,
            generation_date: new Date().toISOString().split('T')[0],
            status: 'pendiente_liberar',
            source_type: isRenewal ? 'renovacion' : 'nuevo_negocio'
          });
        }
      }
    }
    
      if (commissions.length > 0) {
        await api.entities.Commission.bulkCreate(commissions);
        console.log(`Generated ${commissions.length} commissions for policy ${policy.policy_number}`);
      } else {
        console.log('No commissions generated - check agent assignments and commission tables');
      }
    } catch (error) {
      console.error('Error generating commissions:', error);
      throw error;
    }
  };

  // Stats
  const totalPending = payments.filter(p => p.status === 'pendiente').reduce((sum, p) => sum + (p.amount || 0), 0);
  const totalOverdue = payments.filter(p => p.status === 'atrasado').reduce((sum, p) => sum + (p.amount || 0), 0);
  const totalPaid = payments.filter(p => p.status === 'pagado').reduce((sum, p) => sum + (p.amount || 0), 0);
  const overdueCount = payments.filter(p => p.status === 'atrasado').length;

  // Filters
  const filteredPayments = payments.filter(p => {
    if (!showPaid && p.status === 'pagado') return false;
    if (!showFuture && p.due_date && isAfter(new Date(p.due_date), new Date())) return false;
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (companyFilter !== 'all' && p.company_id !== companyFilter) return false;
    if (monthFilter !== 'all' && p.due_date) {
      const paymentDate = new Date(p.due_date);
      const filterDate = new Date(monthFilter);
      if (paymentDate.getMonth() !== filterDate.getMonth() || 
          paymentDate.getFullYear() !== filterDate.getFullYear()) {
        return false;
      }
    }
    return true;
  });

  // Generate month options dynamically based on actual payment dates
  const getMonthOptions = () => {
    if (payments.length === 0) return [];

    // Find earliest and latest due_date in payments
    const dates = payments
      .filter(p => p.due_date)
      .map(p => new Date(p.due_date));
    
    const minDate = new Date(Math.min(...dates));
    const maxDate = new Date(Math.max(...dates));

    // Extend max by 12 months into the future
    maxDate.setMonth(maxDate.getMonth() + 12);

    const months = [];
    const cursor = new Date(minDate.getFullYear(), minDate.getMonth(), 1);
    const end = new Date(maxDate.getFullYear(), maxDate.getMonth(), 1);

    while (cursor <= end) {
      months.push({
        value: new Date(cursor).toISOString(),
        label: format(cursor, 'MMMM yyyy', { locale: es })
      });
      cursor.setMonth(cursor.getMonth() + 1);
    }

    return months;
  };

  const columns = [
    {
      header: 'Póliza',
      cell: (row) => (
        <Link to={createPageUrl(`PolicyDetail?id=${row.policy_id}`)} className="text-foreground hover:underline">
          {row.policy_number}
        </Link>
      )
    },
    { header: t('policies.client'), accessorKey: 'client_name' },
    { header: t('policies.company'), accessorKey: 'company_name' },
    { 
      header: 'Cuota / Período', 
      cell: (row) => (
        <div>
          <p className="font-medium text-foreground">Cuota #{row.installment_number || '-'}</p>
          <p className="text-sm text-muted-foreground">{row.period}</p>
        </div>
      )
    },
    {
      header: 'Vencimiento',
      accessorKey: 'due_date',
      cell: (row) => (
        <span className={row.status === 'atrasado' ? 'text-red-600 dark:text-red-400 font-medium' : ''}>
          {row.due_date ? formatDate(row.due_date, 'dd/MM/yyyy') : '-'}
        </span>
      )
    },
    {
      header: 'Monto',
      cell: (row) => (
        <span className="font-medium">{row.currency} {row.amount?.toLocaleString()}</span>
      )
    },
    { header: t('payments.method'), cell: (row) => <span className="capitalize">{row.payment_method || '-'}</span> },
    { header: t('common.status'), cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: 'Acciones',
      cell: (row) => {
        const canPay = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin' || currentUser.app_role === 'operativo' || currentUser.app_role === 'financiero');
        
        return row.status !== 'pagado' && canPay ? (
          <Button size="sm" onClick={() => markAsPaid(row)} className="gap-2">
            <CheckCircle className="h-4 w-4" /> {t('payments.markAsPaid')}
          </Button>
        ) : null;
      }
    }
  ];

  const getExportData = () => ({
    headers: ['Póliza', 'Cliente', 'Período', 'Vencimiento', 'Monto', 'Moneda', 'Método', 'Estado'],
    rows: filteredPayments.map(p => [
      p.policy_number, p.client_name, p.period, p.due_date,
      p.amount, p.currency, p.payment_method, p.status
    ]),
    filename: 'pagos'
  });

  const handleExportCSV = () => exportToCSV(getExportData());
  const handleExportExcel = () => exportToExcel({ ...getExportData(), sheetName: 'Pagos' });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  const handleManualCommissionSubmit = async () => {
    if (!pendingPayment) return;
    
    setSaving(true);
    
    const payment = pendingPayment;
    const policy = payment.policy;
    
    try {
      // Verificar si ya existe comisión anualizada
      const companies = await api.entities.InsuranceCompany.list();
      const company = companies.find(c => c.id === policy.company_id);
      const isNewBusiness = policy.policy_type === 'nuevo_negocio';
      const paymentType = isNewBusiness ? company?.new_business_payment_type : company?.renewal_payment_type;
      
      if (paymentType === 'anualizada') {
        const existingCommissions = await api.entities.Commission.filter({ 
          policy_id: policy.id 
        });
        
        if (existingCommissions.length > 0) {
          toast.error('Esta póliza ya tiene comisión anualizada generada. No se generarán comisiones adicionales.');
          
          await api.entities.Payment.update(payment.id, {
            status: 'pagado',
            payment_date: new Date().toISOString().split('T')[0]
          });
          
          setSaving(false);
          setManualCommissionOpen(false);
          setPendingPayment(null);
          setAgentsForManualCommission([]);
          await loadPayments();
          return;
        }
      }
      
      // Marcar pago como pagado
      await api.entities.Payment.update(payment.id, {
        status: 'pagado',
        payment_date: new Date().toISOString().split('T')[0]
      });
      
      // Generar comisiones manualmente
      let premiumToCommission = 0;
      if (paymentType === 'anualizada') {
        premiumToCommission = policy.commissionable_premium || policy.annual_premium;
      } else {
        premiumToCommission = payment.amount;
      }
      
      for (const agent of agentsForManualCommission) {
        if (agent.percentage > 0) {
          const commissionAmount = (premiumToCommission * agent.percentage) / 100;
          
          await api.entities.Commission.create({
            policy_id: policy.id,
            policy_number: policy.policy_number,
            product_id: policy.product_id,
            product_name: policy.product_name,
            company_id: policy.company_id,
            company_name: policy.company_name,
            agent_id: agent.id,
            agent_name: agent.name,
            client_name: policy.client_name,
            level: agent.level,
            base_amount: premiumToCommission,
            commission_pct: agent.percentage,
            commission_amount: commissionAmount,
            installment_number: payment.installment_number,
            currency: policy.currency,
            generation_date: new Date().toISOString().split('T')[0],
            status: 'pendiente_liberar',
            source_type: policy.policy_type === 'renovacion' ? 'renovacion' : 'nuevo_negocio'
          });
        }
      }
      
      toast.success('Comisiones generadas exitosamente');
      setSaving(false);
      setManualCommissionOpen(false);
      setPendingPayment(null);
      setAgentsForManualCommission([]);
      await loadPayments();
    } catch (error) {
      console.error('Error generating manual commissions:', error);
      toast.error('Error al generar comisiones: ' + error.message);
      setSaving(false);
    }
  };

  const handleBulkMarkAsPaid = async () => {
    setBulkProcessing(true);
    isBulkOperationActive.current = true;
    const today = new Date().toISOString().split('T')[0];
    let successCount = 0;
    const errors = [];

    const paymentsToProcess = selectedPayments.filter(p => p.status !== 'pagado');

    for (let i = 0; i < paymentsToProcess.length; i++) {
      const payment = paymentsToProcess[i];
      try {
        await api.entities.Payment.update(payment.id, {
          status: 'pagado',
          payment_date: today
        });
        successCount++;
        // Delay between updates to avoid rate limiting
        if (i < paymentsToProcess.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      } catch (err) {
        errors.push(`${payment.policy_number} (${payment.client_name}): ${err.message}`);
      }
    }

    isBulkOperationActive.current = false;
    setBulkProcessing(false);
    setBulkActionOpen(false);
    setSelectedPayments([]);
    setTableResetKey(k => k + 1);

    if (successCount > 0) toast.success(`${successCount} pago(s) marcados como pagados.`);
    if (errors.length > 0) {
      console.error('Bulk payment errors:', errors);
      toast.error(`${errors.length} pago(s) no pudieron procesarse: ${errors[0]}${errors.length > 1 ? ` y ${errors.length - 1} más` : ''}`);
    }

    await loadPayments();
  };

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title={t('payments.title')}
          subtitle={t('payments.title')}
          icon={DollarSign}
          backTo="Dashboard"
          actions={
            (currentUser?.role === 'admin' || currentUser?.app_role === 'admin') && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={cleanOrphanedPayments}
                className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-500/10"
              >
                Limpiar Pagos Huérfanos
              </Button>
            )
          }
        />

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title={t('payments.pending')}
            value={`$${totalPending.toLocaleString()}`}
            icon={Clock}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-600 dark:text-amber-400"
          />
          <StatCard
            title={t('payments.overdue')}
            value={`$${totalOverdue.toLocaleString()}`}
            subtitle={`${overdueCount} pagos`}
            icon={AlertCircle}
            iconBg="bg-red-500/10"
            iconColor="text-red-600 dark:text-red-400"
          />
          <StatCard
            title={t('payments.paid')}
            value={`$${totalPaid.toLocaleString()}`}
            icon={CheckCircle}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-600 dark:text-emerald-400"
          />
          <StatCard
            title={t('common.total')}
            value={payments.length}
            icon={Calendar}
            iconBg="bg-muted"
            iconColor="text-foreground"
          />
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground/70" />
              <span className="text-sm text-muted-foreground">Filtros:</span>
            </div>
            <MobileSelect 
              value={companyFilter} 
              onValueChange={setCompanyFilter}
              placeholder="Aseguradora"
              label="Aseguradora"
            >
              <SelectItem value="all">Todas las aseguradoras</SelectItem>
              {companies.map(company => (
                <SelectItem key={company.id} value={company.id}>
                  {company.name}
                </SelectItem>
              ))}
            </MobileSelect>
            <MobileSelect 
              value={statusFilter} 
              onValueChange={setStatusFilter}
              placeholder="Estado"
              label="Estado de pago"
            >
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="pendiente">Pendiente</SelectItem>
              <SelectItem value="atrasado">Atrasado</SelectItem>
              <SelectItem value="pagado">Pagado</SelectItem>
            </MobileSelect>
            <MobileSelect 
              value={monthFilter} 
              onValueChange={setMonthFilter}
              placeholder="Mes"
              label="Mes de pago"
            >
              <SelectItem value="all">Todos los meses</SelectItem>
              {getMonthOptions().map(opt => (
                <SelectItem key={opt.value} value={opt.value} className="capitalize">
                  {opt.label}
                </SelectItem>
              ))}
            </MobileSelect>
            <Button 
              variant={showPaid ? "outline" : "default"}
              size="sm"
              onClick={() => setShowPaid(!showPaid)}
              className="gap-2"
            >
              {showPaid ? 'Ocultar Pagados' : 'Mostrar Pagados'}
            </Button>
            <Button 
              variant={showFuture ? "outline" : "default"}
              size="sm"
              onClick={() => setShowFuture(!showFuture)}
              className="gap-2"
            >
              {showFuture ? 'Ocultar Futuros' : 'Mostrar Futuros'}
            </Button>
            {(statusFilter !== 'all' || monthFilter !== 'all' || companyFilter !== 'all') && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => { setStatusFilter('all'); setMonthFilter('all'); setCompanyFilter('all'); }}
              >
                Limpiar
              </Button>
            )}
          </div>
        </Card>

        {/* Bulk Action Bar */}
        {selectedPayments.length > 0 && (
          <div className="mb-4 flex items-center justify-between gap-4 bg-muted border border-border rounded-xl px-4 py-3">
            <span className="text-sm font-medium text-foreground">
              {selectedPayments.length} pago(s) seleccionado(s)
            </span>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => { setSelectedPayments([]); setTableResetKey(k => k + 1); }}
                className="gap-1"
              >
                <X className="h-4 w-4" /> Cancelar
              </Button>
              {(currentUser?.role === 'admin' || currentUser?.app_role === 'admin' || currentUser?.app_role === 'operativo' || currentUser?.app_role === 'financiero') && (
                <Button
                  size="sm"
                  onClick={() => setBulkActionOpen(true)}
                  className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <CheckSquare className="h-4 w-4" /> Marcar como Pagados
                </Button>
              )}
            </div>
          </div>
        )}

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            key={tableResetKey}
            columns={columns}
            data={filteredPayments}
            searchPlaceholder="Buscar por póliza, cliente o aseguradora..."
            searchKeys={['policy_number', 'client_name', 'company_name']}
            initialSearch={searchQuery}
            onSearchChange={updateSearch}
            exportable
            onExport={handleExportCSV}
            onExportExcel={handleExportExcel}
            emptyMessage={t('common.noData')}
            sortable={true}
            defaultSortField="due_date"
            defaultSortOrder="asc"
            selectable={!!(currentUser?.role === 'admin' || currentUser?.app_role === 'admin' || currentUser?.app_role === 'operativo' || currentUser?.app_role === 'financiero')}
            selectableFilter={(row) => row.status === 'pendiente' || row.status === 'atrasado'}
            onSelectionChange={setSelectedPayments}
            actions={
              searchQuery && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={clearSearch}
                  className="text-muted-foreground hover:text-foreground/80 gap-1"
                >
                  <X className="h-4 w-4" /> Limpiar búsqueda
                </Button>
              )
            }
          />
        </Card>

        {/* Bulk Payment Confirmation Dialog */}
        <Dialog open={bulkActionOpen} onOpenChange={setBulkActionOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{t('payments.markAsPaid')}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 py-2">
              <p className="text-sm text-muted-foreground">
                Estás a punto de marcar <strong>{selectedPayments.length} pago(s)</strong> como pagados.
              </p>
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
                <p className="text-sm text-amber-600 dark:text-amber-400 font-medium">⚠️ Sin generación de comisiones</p>
                <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                  Esta acción masiva marcará los pagos como pagados sin generar comisiones. 
                  Si necesitas generar comisiones, procesa cada pago individualmente.
                </p>
              </div>
              <div className="max-h-48 overflow-y-auto space-y-1">
                {selectedPayments.map(p => (
                  <div key={p.id} className="flex justify-between text-xs text-foreground/80 bg-muted/40 rounded px-2 py-1">
                    <span>{p.policy_number} - {p.client_name}</span>
                    <span className="font-medium">{p.currency} {p.amount?.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setBulkActionOpen(false)} disabled={bulkProcessing}>
                Cancelar
              </Button>
              <Button
                onClick={handleBulkMarkAsPaid}
                disabled={bulkProcessing}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {bulkProcessing ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Procesando...</> : 'Confirmar Pago Masivo'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Manual Commission Dialog */}
        <Dialog open={manualCommissionOpen} onOpenChange={setManualCommissionOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{t('commissions.settlement')}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                El agente no tiene tabla de comisiones asignada. Ingrese los porcentajes manualmente.
              </p>
              {agentsForManualCommission.map((agent, index) => (
                <div key={agent.id} className="flex items-center gap-4 p-3 bg-muted/40 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">Nivel {agent.level}: {agent.name}</p>
                  </div>
                  <div className="w-32">
                    <Label>Porcentaje %</Label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      value={agent.percentage}
                      onChange={(e) => {
                        const updated = [...agentsForManualCommission];
                        updated[index].percentage = parseFloat(e.target.value) || 0;
                        setAgentsForManualCommission(updated);
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setManualCommissionOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleManualCommissionSubmit} disabled={saving}>
                {saving ? 'Procesando...' : 'Generar Comisiones'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}