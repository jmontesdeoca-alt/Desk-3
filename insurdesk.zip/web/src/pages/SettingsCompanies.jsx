import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import BackButton from '@/components/ui/BackButton';
import StatusBadge from '@/components/ui/StatusBadge';
import { Building2, Plus, Pencil, Trash2, Loader2, Search, ChevronDown, ChevronRight } from 'lucide-react';

export default function SettingsCompanies() {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    country: '',
    branch_id: '',
    contact_email: '',
    contact_phone: '',
    lines: [],
    new_business_payment_type: 'anualizada',
    renewal_payment_type: 'segun_cliente',
    direct_payment_to_agents: false,
    status: 'activa',
    notes: ''
  });
  const [allLines, setAllLines] = useState([]);
  const [branches, setBranches] = useState([]);
  const [companiesPersistence, setCompaniesPersistence] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [expandedCards, setExpandedCards] = useState({});

  useEffect(() => {
    const loadUser = async () => {
      const user = await api.auth.me();
      setCurrentUser(user);
    };
    loadUser();
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [companiesData, linesData, branchesData] = await Promise.all([
      api.entities.InsuranceCompany.list('-created_date'),
      api.entities.InsuranceLine.filter({ status: 'activo' }),
      api.entities.Branch.filter({ status: 'activo' })
    ]);
    setCompanies(companiesData);
    setAllLines(linesData);
    const sortedBranches = branchesData.sort((a, b) => a.name.localeCompare(b.name));
    setBranches(sortedBranches);
    if (sortedBranches.length > 0 && !selectedBranch) {
      setSelectedBranch(sortedBranches[0].id);
    }
    
    // Calcular persistencia para cada compañía
    await calculateAllPersistence(companiesData);
    
    setLoading(false);
  };

  const calculateAllPersistence = async (companiesData) => {
    const now = new Date();
    const currentPeriodStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Obtener todas las pólizas de una vez
    const allPolicies = await api.entities.Policy.list();
    
    const persistenceData = {};
    
    for (const company of companiesData) {
      // Filtrar pólizas de renovación del periodo actual de esta compañía
      const renewalPolicies = allPolicies.filter(p => 
        p.company_id === company.id &&
        p.policy_type === 'renovacion' &&
        p.start_date >= currentPeriodStart.toISOString().split('T')[0]
      );

      if (renewalPolicies.length === 0) {
        persistenceData[company.id] = 0;
        continue;
      }

      // Obtener los IDs de las pólizas originales
      const originalPolicyIds = renewalPolicies
        .map(p => p.renewed_from_policy_id)
        .filter(id => id);

      if (originalPolicyIds.length === 0) {
        persistenceData[company.id] = 0;
        continue;
      }

      // Filtrar las pólizas originales
      const originalPolicies = allPolicies.filter(p => originalPolicyIds.includes(p.id));

      // Calcular suma de primas
      const totalRenewedPremium = renewalPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
      const totalOriginalPremium = originalPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);

      // Calcular porcentaje de persistencia
      persistenceData[company.id] = totalOriginalPremium > 0 
        ? (totalRenewedPremium / totalOriginalPremium) * 100 
        : 0;
    }
    
    setCompaniesPersistence(persistenceData);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const branch = branches.find(b => b.id === formData.branch_id);
    const dataToSave = {
      ...formData,
      branch_name: branch?.name || ''
    };
    if (editingItem) {
      await api.entities.InsuranceCompany.update(editingItem.id, dataToSave);
    } else {
      await api.entities.InsuranceCompany.create(dataToSave);
    }
    setSaving(false);
    setFormOpen(false);
    setEditingItem(null);
    resetForm();
    loadData();
  };

  const handleEdit = (item) => {
    const canEdit = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canEdit) return;
    
    setEditingItem(item);
    setFormData({
      name: item.name || '',
      country: item.country || '',
      branch_id: item.branch_id || '',
      contact_email: item.contact_email || '',
      contact_phone: item.contact_phone || '',
      lines: item.lines || [],
      new_business_payment_type: item.new_business_payment_type || 'anualizada',
      renewal_payment_type: item.renewal_payment_type || 'segun_cliente',
      direct_payment_to_agents: item.direct_payment_to_agents || false,
      status: item.status || 'activa',
      notes: item.notes || ''
    });
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (itemToDelete) {
      await api.entities.InsuranceCompany.delete(itemToDelete.id);
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      loadData();
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      country: '',
      branch_id: '',
      contact_email: '',
      contact_phone: '',
      lines: [],
      new_business_payment_type: 'anualizada',
      renewal_payment_type: 'segun_cliente',
      direct_payment_to_agents: false,
      status: 'activa',
      notes: ''
    });
  };

  const openNewForm = () => {
    const canCreate = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canCreate) return;
    
    setEditingItem(null);
    resetForm();
    setFormOpen(true);
  };

  const toggleCard = (companyId) => {
    setExpandedCards(prev => ({
      ...prev,
      [companyId]: !prev[companyId]
    }));
  };

  // Filtrar compañías por búsqueda y branch seleccionado
  const companiesInBranch = companies
    .filter(company => {
      const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            company.country?.toLowerCase().includes(searchTerm.toLowerCase());
      return company.branch_id === selectedBranch && matchesSearch;
    })
    .sort((a, b) => a.name.localeCompare(b.name));

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <BackButton />
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-muted">
                <Building2 className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">Compañías Aseguradoras</h1>
                <p className="text-sm text-muted-foreground">{companies.length} compañías</p>
              </div>
            </div>
          </div>
          {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
            <Button onClick={openNewForm} className="gap-2 w-full sm:w-auto">
              <Plus className="h-4 w-4" /> Nueva Compañía
            </Button>
          )}
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
          <Input
            placeholder="Buscar por nombre o país..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <Tabs value={selectedBranch} onValueChange={setSelectedBranch} className="w-full">
          <TabsList className="grid w-full mb-6" style={{ gridTemplateColumns: `repeat(${branches.length}, minmax(0, 1fr))` }}>
            {branches.map(b => (
              <TabsTrigger key={b.id} value={b.id} className="text-xs lg:text-sm">
                {b.name.length > 12 ? `${b.name.substring(0, 10)}...` : b.name}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={selectedBranch} className="space-y-4">
            {companiesInBranch.length === 0 ? (
              <Card className="border-0 shadow-sm p-12">
                <div className="text-center text-muted-foreground/70">
                  <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>{searchTerm ? 'No se encontraron compañías con ese criterio' : 'No hay compañías en este branch'}</p>
                  {!searchTerm && (
                    <Button onClick={openNewForm} variant="outline" className="mt-4">
                      Agregar primera compañía
                    </Button>
                  )}
                </div>
              </Card>
            ) : (
              companiesInBranch.map((company) => (
                <Collapsible
                  key={company.id}
                  open={expandedCards[company.id]}
                  onOpenChange={() => toggleCard(company.id)}
                >
                  <Card className="border-0 shadow-sm overflow-hidden">
                    <CollapsibleTrigger className="w-full p-4 hover:bg-muted/40 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {expandedCards[company.id] ? (
                            <ChevronDown className="h-5 w-5 text-muted-foreground/70" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-muted-foreground/70" />
                          )}
                          <Building2 className="h-5 w-5 text-foreground" />
                          <div className="text-left">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold text-foreground">{company.name}</h3>
                              <StatusBadge status={company.status} />
                            </div>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {company.country} · Persistencia: <span className="font-semibold text-amber-600 dark:text-amber-400">
                                {companiesPersistence[company.id] !== undefined
                                  ? `${companiesPersistence[company.id].toFixed(1)}%`
                                  : '...'}
                              </span>
                            </p>
                          </div>
                        </div>
                        <span className="text-sm text-muted-foreground bg-muted px-2 py-1 rounded-full">
                          {(company.lines || []).length} {(company.lines || []).length === 1 ? 'ramo' : 'ramos'}
                        </span>
                      </div>
                    </CollapsibleTrigger>

                    <CollapsibleContent>
                      <div className="border-t border-border p-6 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {company.contact_email && (
                            <div>
                              <p className="text-xs text-muted-foreground font-medium mb-1">Email</p>
                              <p className="text-sm text-foreground">{company.contact_email}</p>
                            </div>
                          )}
                          {company.contact_phone && (
                            <div>
                              <p className="text-xs text-muted-foreground font-medium mb-1">Teléfono</p>
                              <p className="text-sm text-foreground">{company.contact_phone}</p>
                            </div>
                          )}
                        </div>

                        {company.lines && company.lines.length > 0 && (
                          <div>
                            <p className="text-xs text-muted-foreground font-medium mb-2">Ramos</p>
                            <div className="flex flex-wrap gap-2">
                              {company.lines.map((line, idx) => (
                                <span key={idx} className="px-2 py-1 bg-muted text-foreground rounded text-xs font-medium">
                                  {line}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="p-3 bg-muted rounded-lg">
                          <p className="text-xs font-medium text-foreground/80 mb-2">Pago de Comisiones</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                            <div>
                              <span className="text-muted-foreground">Nuevos negocios:</span>
                              <span className="ml-2 font-medium text-foreground">
                                {company.new_business_payment_type === 'anualizada' ? 'Anualizada' : 'Según cliente'}
                              </span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Renovaciones:</span>
                              <span className="ml-2 font-medium text-foreground">
                                {company.renewal_payment_type === 'anualizada' ? 'Anualizada' : 'Según cliente'}
                              </span>
                            </div>
                          </div>
                          {company.direct_payment_to_agents && (
                            <div className="mt-2 pt-2 border-t border-input">
                              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                                Pago directo a agentes (sin liquidación)
                              </span>
                            </div>
                          )}
                        </div>

                        {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
                          <div className="flex items-center justify-end gap-2 pt-4 border-t border-border">
                            <Button variant="outline" size="sm" onClick={() => handleEdit(company)} className="gap-2">
                              <Pencil className="h-4 w-4" /> Editar
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => { setItemToDelete(company); setDeleteDialogOpen(true); }}
                              className="gap-2 text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400"
                            >
                              <Trash2 className="h-4 w-4" /> Eliminar
                            </Button>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              ))
            )}
          </TabsContent>
        </Tabs>

        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar Compañía' : 'Nueva Compañía'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre *</Label>
                  <Input 
                    value={formData.name} 
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>País *</Label>
                  <Input 
                    value={formData.country} 
                    onChange={(e) => setFormData({...formData, country: e.target.value})}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Branch *</Label>
                  <Select 
                    value={formData.branch_id} 
                    onValueChange={(v) => setFormData({...formData, branch_id: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar branch" />
                    </SelectTrigger>
                    <SelectContent>
                      {branches.map(b => (
                        <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Email de Contacto</Label>
                  <Input 
                    type="email"
                    value={formData.contact_email} 
                    onChange={(e) => setFormData({...formData, contact_email: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Teléfono de Contacto</Label>
                  <Input 
                    value={formData.contact_phone} 
                    onChange={(e) => setFormData({...formData, contact_phone: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Estado</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(v) => setFormData({...formData, status: v})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activa">Activa</SelectItem>
                      <SelectItem value="inactiva">Inactiva</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Ramos que Maneja</Label>
                <div className="border rounded-lg p-3 grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                  {allLines.length === 0 ? (
                    <p className="text-sm text-muted-foreground/70 col-span-2">No hay ramos configurados</p>
                  ) : (
                    allLines.sort((a, b) => a.name.localeCompare(b.name)).map(line => (
                      <label key={line.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={formData.lines.includes(line.name)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setFormData({...formData, lines: [...formData.lines, line.name]});
                            } else {
                              setFormData({...formData, lines: formData.lines.filter(l => l !== line.name)});
                            }
                          }}
                          className="rounded"
                        />
                        <span className="text-sm">{line.name}</span>
                      </label>
                    ))
                  )}
                </div>
              </div>

              <div className="space-y-4 p-4 bg-muted/40 rounded-lg border">
                <h4 className="font-medium text-sm text-foreground/80">Configuración de Pago de Comisiones</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nuevos Negocios</Label>
                    <Select 
                      value={formData.new_business_payment_type} 
                      onValueChange={(v) => setFormData({...formData, new_business_payment_type: v})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="anualizada">Anualizada</SelectItem>
                        <SelectItem value="segun_cliente">Según pague el cliente</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {formData.new_business_payment_type === 'anualizada' 
                        ? 'Se comisiona sobre la prima anual completa' 
                        : 'Se comisiona según la frecuencia de pago del cliente'}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Renovaciones</Label>
                    <Select 
                      value={formData.renewal_payment_type} 
                      onValueChange={(v) => setFormData({...formData, renewal_payment_type: v})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="anualizada">Anualizada</SelectItem>
                        <SelectItem value="segun_cliente">Según pague el cliente</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {formData.renewal_payment_type === 'anualizada' 
                        ? 'Se comisiona sobre la prima anual completa' 
                        : 'Se comisiona según la frecuencia de pago del cliente'}
                    </p>
                  </div>
                </div>
                
                <div className="pt-3 border-t border-input">
                  <label className="flex items-center justify-center gap-3">
                    <input
                      type="checkbox"
                      checked={formData.direct_payment_to_agents}
                      onChange={(e) => setFormData({...formData, direct_payment_to_agents: e.target.checked})}
                      className="rounded"
                    />
                    <span className="text-sm font-medium text-foreground">Pago directo a agentes</span>
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notas</Label>
                <Textarea 
                  value={formData.notes} 
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingItem ? 'Guardar' : 'Crear'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar compañía?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará permanentemente la compañía 
                {itemToDelete && ` "${itemToDelete.name}"`}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}