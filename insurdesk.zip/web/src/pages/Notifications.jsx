import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import PageHeader from '@/components/ui/PageHeader';
import { Bell, CheckCircle, Loader2, Mail } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const currentUser = await api.auth.me();
    setUser(currentUser);

    // Resolve agent_id from UserRole (commissions/payments use agent_id as recipient_id)
    let agentId = null;
    try {
      const roles = await api.entities.UserRole.filter({ email: currentUser.email });
      if (roles && roles.length > 0) agentId = roles[0].agent_id;
    } catch {}

    // Load notifications for current user only:
    // - recipient_id === user.id (task assignments)
    // - recipient_id === agent_id (commissions, payments, etc.)
    // - recipient_email === user.email (fallback match by email)
    const data = await api.entities.Notification.list('-created_date');
    const userNotifications = data.filter(n =>
      n.recipient_id === currentUser.id ||
      (agentId && n.recipient_id === agentId) ||
      n.recipient_email === currentUser.email
    );
    setNotifications(userNotifications);
    setLoading(false);
  };

  const markAsRead = async (notification) => {
    await api.entities.Notification.update(notification.id, { read: true });
    loadData();
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.read);
    await Promise.all(unread.map(n => 
      api.entities.Notification.update(n.id, { read: true })
    ));
    loadData();
  };

  const getNotificationIcon = (type) => {
    const icons = {
      vencimiento_poliza: '📅',
      pago_proximo: '💰',
      pago_vencido: '⚠️',
      renovacion_disponible: '🔄',
      siniestro_actualizado: '🛡️',
      endoso_aplicado: '📝',
      comision_generada: '💵',
      otro: '📬'
    };
    return icons[type] || '📬';
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <PageHeader
            title="Notificaciones"
            subtitle={`${unreadCount} no leídas`}
            icon={Bell}
          />
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllAsRead}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Marcar todas como leídas
            </Button>
          )}
        </div>

        <div className="space-y-3">
          {notifications.length === 0 ? (
            <Card className="border-0 shadow-sm p-12 text-center">
              <Bell className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p className="text-muted-foreground">No hay notificaciones</p>
            </Card>
          ) : (
            notifications.map((notification) => (
              <Card 
                key={notification.id} 
                className={`border-0 shadow-sm p-4 transition-all ${
                  notification.read ? 'bg-card' : 'bg-muted border-l-4 border-primary'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className="text-3xl">{getNotificationIcon(notification.notification_type)}</div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className={`font-semibold ${!notification.read && 'text-foreground'}`}>
                          {notification.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                        <p className="text-xs text-muted-foreground/70 mt-2">
                          {format(new Date(notification.notification_date), 'dd MMM yyyy', { locale: es })}
                        </p>
                      </div>
                      {!notification.read && (
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => markAsRead(notification)}
                        >
                          Marcar leída
                        </Button>
                      )}
                    </div>
                    {notification.sent && (
                      <div className="flex items-center gap-1 mt-2 text-xs text-green-600 dark:text-green-400">
                        <Mail className="h-3 w-3" />
                        Enviado por correo
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}