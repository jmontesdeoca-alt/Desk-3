import { useFeatures } from '@/lib/FeatureContext';
import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import AgentForm from '@/components/forms/AgentForm';
import { useSearchCache } from '@/components/SearchCache';
import { Users, Plus, Pencil, Trash2, Loader2, ChevronRight, Building2, User, Filter, X, Download, ChevronDown } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { exportToCSV, exportToExcel } from '@/components/ui/exportUtils';
import { Badge } from "@/components/ui/badge";
import DeleteSafetyDialog from '@/components/ui/DeleteSafetyDialog';
import { useLocation } from 'react-router-dom';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function Agents() {
  const { limit: featureLimit } = useFeatures();
  const hasStructure = featureLimit('structure') > 1;
  const { t } = useTranslation();
  const { searchQuery, updateSearch, clearSearch } = useSearchCache('agents');
  const location = useLocation();
  const [agents, setAgents] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [lines, setLines] = useState([]);
  const [commissionTables, setCommissionTables] = useState([]);
  const [commissionAssignments, setCommissionAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [agentToDelete, setAgentToDelete] = useState(null);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [activityFilter, setActivityFilter] = useState('todos');
  const [countryFilter, setCountryFilter] = useState('todos');
  const [tagFilter, setTagFilter] = useState('todos');
  const [assignmentFormOpen, setAssignmentFormOpen] = useState(false);
  const [newAssignment, setNewAssignment] = useState({ company_id: '', line_id: '', commission_table_id: '' });
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const user = await api.auth.me();
      const userRoleResp = await api.functions.invoke('getUserRoleInfo', {});
      const enrichedUser = { ...user, app_role: userRoleResp?.data?.app_role, agent_id: userRoleResp?.data?.agent_id };
      setCurrentUser(enrichedUser);
    };
    loadUser();
  }, []);

  useEffect(() => {
    loadData();
  }, []);

  // Handle agent selection from GlobalSearch
  useEffect(() => {
    if (location.state?.selectedAgentId && agents.length > 0) {
      const agent = agents.find(a => a.id === location.state.selectedAgentId);
      if (agent) {
        setSelectedAgent(agent);
        // Clear the state to prevent re-selecting on refresh
        window.history.replaceState({}, document.title);
      }
    }
  }, [location.state, agents]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load data sequentially with small delays to avoid rate limiting
      const agentsData = await api.entities.Agent.list('-created_date');
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const policiesData = await api.entities.Policy.list();
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const companiesData = await api.entities.InsuranceCompany.list();
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const linesData = await api.entities.InsuranceLine.list();
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const tablesData = await api.entities.CommissionTable.list();
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const assignmentsData = await api.entities.AgentCommissionAssignment.list();
    
    // Calculate agent activity status
    const today = new Date();
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
    
    const agentsWithActivity = agentsData.map(agent => {
      const agentNewPolicies = policiesData.filter(p => 
        p.agent_id === agent.id && 
        p.policy_type === 'nuevo_negocio' &&
        new Date(p.created_date) >= oneYearAgo
      );
      
      return {
        ...agent,
        activity_status: agentNewPolicies.length > 0 ? 'activo' : 'inactivo'
      };
    });
    
      setAgents(agentsWithActivity);
      setPolicies(policiesData);
      setCompanies(companiesData);
      setLines(linesData);
      setCommissionTables(tablesData);
      setCommissionAssignments(assignmentsData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Error al cargar los datos. Por favor, recarga la página.');
    }
    setLoading(false);
  };

  const handleSubmit = async (data) => {
    setSaving(true);
    try {
      // Remove fields that shouldn't be saved to the entity
      const { skip_user_creation, ...agentData } = data;
      
      if (editingAgent) {
        // If upline_agent_id changed, update upline_agent_name
        if (agentData.upline_agent_id) {
          const uplineAgent = agents.find(a => a.id === agentData.upline_agent_id);
          agentData.upline_agent_name = uplineAgent?.name || '';
        } else {
          agentData.upline_agent_name = '';
        }
        await api.entities.Agent.update(editingAgent.id, agentData);
      } else {
        // Create agent
        const newAgent = await api.entities.Agent.create(agentData);
        
        // TEMPORALMENTE DESACTIVADO - Auto-create user if not skipped
        // if (!data.skip_user_creation) {
        //   try {
        //     // Invite user
        //     await api.users.inviteUser(data.email, "user");
        //     
        //     // Wait a bit for user creation to complete
        //     await new Promise(resolve => setTimeout(resolve, 1000));
        //     
        //     // Find the user by email and update with agent role and link
        //     const users = await api.entities.User.filter({ email: data.email });
        //     if (users.length > 0) {
        //       await api.entities.User.update(users[0].id, {
        //         app_role: 'agente',
        //         agent_id: newAgent.id
        //       });
        //     }
        //   } catch (error) {
        //     console.error('Error creating user:', error);
        //     alert('Agente creado, pero hubo un error al crear el usuario automáticamente. Puedes crearlo manualmente desde Gestión de Usuarios.');
        //   }
        // }
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al guardar el agente');
    }
    setSaving(false);
    setFormOpen(false);
    setEditingAgent(null);
    loadData();
  };

  const handleEdit = (agent) => {
    setEditingAgent(agent);
    setFormOpen(true);
  };

  const checkAgentUsage = async () => {
    const [agentPolicies, commissions, downlineAgents] = await Promise.all([
      api.entities.Policy.filter({ agent_id: agentToDelete.id }),
      api.entities.Commission.filter({ agent_id: agentToDelete.id }),
      api.entities.Agent.filter({ upline_agent_id: agentToDelete.id }),
    ]);

    const usageItems = [];

    const activePolicies = agentPolicies.filter(p => p.status === 'activa');
    if (activePolicies.length > 0) {
      usageItems.push({ label: 'Pólizas activas vendidas', count: activePolicies.length, detail: 'El agente tiene ventas de pólizas actualmente vigentes.' });
    } else if (agentPolicies.length > 0) {
      usageItems.push({ label: 'Historial de pólizas', count: agentPolicies.length, detail: 'El agente tiene historial de ventas en el sistema.' });
    }

    const paidCommissions = commissions.filter(c => c.status === 'pagada');
    if (paidCommissions.length > 0) {
      usageItems.push({ label: 'Comisiones pagadas', count: paidCommissions.length, detail: 'El agente tiene comisiones que ya fueron liquidadas.' });
    }

    const pendingCommissions = commissions.filter(c => c.status !== 'pagada');
    if (pendingCommissions.length > 0) {
      usageItems.push({ label: 'Comisiones pendientes', count: pendingCommissions.length, detail: 'Comisiones generadas que aún no han sido pagadas.' });
    }

    if (downlineAgents.length > 0) {
      usageItems.push({ label: 'Agentes en su red (downline)', count: downlineAgents.length, detail: 'Otros agentes que tienen a este como su agente superior.' });
    }

    return { usageItems };
  };

  const handleDeleteAgent = async () => {
    await api.entities.Agent.delete(agentToDelete.id);
    setAgentToDelete(null);
    loadData();
  };

  const handleAddAssignment = async () => {
    if (!newAssignment.company_id || !newAssignment.line_id || !newAssignment.commission_table_id) return;
    
    const company = companies.find(c => c.id === newAssignment.company_id);
    const line = lines.find(l => l.id === newAssignment.line_id);
    const table = commissionTables.find(t => t.id === newAssignment.commission_table_id);
    
    await api.entities.AgentCommissionAssignment.create({
      agent_id: selectedAgent.id,
      agent_name: selectedAgent.name,
      company_id: newAssignment.company_id,
      company_name: company.name,
      line_id: newAssignment.line_id,
      line_name: line.name,
      commission_table_id: newAssignment.commission_table_id,
      commission_table_name: table.name
    });
    
    setNewAssignment({ company_id: '', line_id: '', commission_table_id: '' });
    setAssignmentFormOpen(false);
    loadData();
  };

  const handleRemoveAssignment = async (assignmentId) => {
    await api.entities.AgentCommissionAssignment.delete(assignmentId);
    loadData();
  };

  const getExportData = () => ({
    headers: ['Nombre', 'Tipo', 'Nivel', 'Alias', 'Superior', 'Email', 'Email Operativo', 'Teléfono', 'País', 'Estado', 'Actividad', 'Partner', 'GAPartner+'],
    rows: filteredAgents.map(agent => [
      agent.name, agent.agent_type, agent.level || 1, agent.alias || '',
      agent.upline_agent_name || '', agent.email, agent.operational_email || '', agent.phone || '', agent.country,
      agent.status, agent.activity_status === 'activo' ? 'Activo' : 'Inactivo',
      agent.is_nivel_2 ? 'Sí' : 'No', agent.is_gapartner ? 'Sí' : 'No'
    ]),
    filename: `agentes_${new Date().toISOString().split('T')[0]}`
  });

  const handleExportCSV = () => exportToCSV(getExportData());
  const handleExportExcel = () => exportToExcel({ ...getExportData(), sheetName: 'Agentes' });

  // Build hierarchy tree
  const buildTree = () => {
    const tree = [];
    const lookup = {};
    
    agents.forEach(agent => {
      lookup[agent.id] = { ...agent, children: [] };
    });
    
    agents.forEach(agent => {
      if (agent.upline_agent_id && lookup[agent.upline_agent_id]) {
        lookup[agent.upline_agent_id].children.push(lookup[agent.id]);
      } else {
        tree.push(lookup[agent.id]);
      }
    });
    
    return tree;
  };

  const getAgentStats = (agentId) => {
    const agentPolicies = policies.filter(p => p.agent_id === agentId);
    const activePolicies = agentPolicies.filter(p => p.status === 'activa');
    const totalPremium = activePolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
    return { count: agentPolicies.length, premium: totalPremium };
  };

  const getDownlineIds = (agentId) => {
    const ids = [agentId];
    const findChildren = (id) => {
      agents.filter(a => a.upline_agent_id === id).forEach(child => {
        ids.push(child.id);
        findChildren(child.id);
      });
    };
    findChildren(agentId);
    return ids;
  };

  const TreeNode = ({ node, depth = 0 }) => {
    const stats = getAgentStats(node.id);
    const isSelected = selectedAgent?.id === node.id;
    
    return (
      <div>
        <div 
          className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
            isSelected ? 'bg-muted border border-border' : 'hover:bg-muted/40'
          }`}
          style={{ marginLeft: depth * 24 }}
          onClick={() => setSelectedAgent(node)}
        >
          <div className={`p-2 rounded-lg ${node.agent_type === 'agencia' ? 'bg-purple-500/10' : 'bg-muted'}`}>
            {node.agent_type === 'agencia' ? (
              <Building2 className="h-4 w-4 text-purple-600 dark:text-purple-400" />
            ) : (
              <User className="h-4 w-4 text-foreground" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <p className="font-medium text-foreground">{node.name}</p>
              <span className="text-xs text-muted-foreground/70">Nivel {node.level || 1}</span>
              <Badge variant={node.activity_status === 'activo' ? 'default' : 'outline'} className={node.activity_status === 'activo' ? 'bg-emerald-500' : 'bg-muted-foreground/50'}>
                {node.activity_status === 'activo' ? 'Activo' : 'Inactivo'}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">{stats.count} pólizas · ${stats.premium.toLocaleString()}</p>
          </div>
          <StatusBadge status={node.status} />
          {node.children.length > 0 && (
            <ChevronRight className="h-4 w-4 text-muted-foreground/70" />
          )}
        </div>
        {node.children.map(child => (
          <TreeNode key={child.id} node={child} depth={depth + 1} />
        ))}
      </div>
    );
  };

  const columns = [
    {
      header: 'Agente',
      cell: (row) => (
        <div className="flex items-center gap-3 cursor-pointer hover:opacity-75 transition-opacity" onClick={() => setSelectedAgent(row)}>
          <div className={`p-2 rounded-lg ${row.agent_type === 'agencia' ? 'bg-purple-500/10' : 'bg-muted'}`}>
            {row.agent_type === 'agencia' ? (
              <Building2 className="h-4 w-4 text-purple-600 dark:text-purple-400" />
            ) : (
              <User className="h-4 w-4 text-foreground" />
            )}
          </div>
          <div>
            <p className="font-medium text-foreground">{row.name}</p>
            <p className="text-sm text-muted-foreground capitalize">{row.agent_type}</p>
          </div>
        </div>
      )
    },
    {
      header: 'Contacto',
      cell: (row) => (
        <div>
          <p className="text-sm">{row.email}</p>
          <p className="text-sm text-muted-foreground">{row.phone}</p>
        </div>
      )
    },
    { header: 'País', accessorKey: 'country' },
    ...(hasStructure ? [
      { header: 'Nivel', cell: (row) => `Nivel ${row.level || 1}` },
      { header: 'Superior', accessorKey: 'upline_agent_name' },
    ] : []),
    { 
      header: 'Actividad', 
      cell: (row) => (
        <Badge variant={row.activity_status === 'activo' ? 'default' : 'outline'} className={row.activity_status === 'activo' ? 'bg-emerald-500' : 'bg-muted-foreground/50'}>
          {row.activity_status === 'activo' ? 'Activo' : 'Inactivo'}
        </Badge>
      )
    },
    { header: 'Estado', cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: 'Acciones',
      cell: (row) => {
        const canEdit = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin' || currentUser.app_role === 'jefatura' || currentUser.app_role === 'financiero');
        const canDelete = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
        
        return (
          <div className="flex items-center gap-2">
            {canEdit && (
              <Button variant="ghost" size="icon" onClick={() => handleEdit(row)}>
                <Pencil className="h-4 w-4" />
              </Button>
            )}
            {canDelete && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => { setAgentToDelete(row); setDeleteDialogOpen(true); }}
              >
                <Trash2 className="h-4 w-4 text-red-500" />
              </Button>
            )}
          </div>
        );
      }
    }
  ];

  // Get unique countries for filter
  const countries = [...new Set(agents.map(a => a.country))].sort();

  // Get structure IDs for gerencial with agent
  const getStructureIds = (rootId) => {
    const ids = [rootId];
    const findChildren = (id) => {
      agents.filter(a => a.upline_agent_id === id).forEach(child => {
        ids.push(child.id);
        findChildren(child.id);
      });
    };
    findChildren(rootId);
    return ids;
  };

  const isGerencialWithAgent = currentUser?.app_role === 'gerencial' && !!currentUser?.agent_id;
  const allowedAgentIds = isGerencialWithAgent ? getStructureIds(currentUser.agent_id) : null;

  // Apply filters
  const filteredAgents = agents.filter(agent => {
    if (allowedAgentIds !== null && !allowedAgentIds.includes(agent.id)) return false;
    const activityMatch = activityFilter === 'todos' || agent.activity_status === activityFilter;
    const countryMatch = countryFilter === 'todos' || agent.country === countryFilter;
    const tagMatch = tagFilter === 'todos' || 
      (tagFilter === 'nivel_2' && agent.is_nivel_2) || 
      (tagFilter === 'gapartner' && agent.is_gapartner);
    return activityMatch && countryMatch && tagMatch;
  });

  const tree = buildTree();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <BackButton className="mt-1" />
          <div className="flex-1">
            <PageHeader
              title={t('agents.title')}
              subtitle={`${agents.length} ${t('common.active').toLowerCase()}`}
              icon={Users}
              actions={
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="gap-2">
                        <Download className="h-4 w-4" /> Exportar
                        <ChevronDown className="h-3 w-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={handleExportCSV} className="gap-2">
                        <Download className="h-4 w-4" /> Descargar CSV
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={handleExportExcel} className="gap-2">
                        <Download className="h-4 w-4" /> Descargar Excel
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button 
                    onClick={async () => { 
                      const user = await api.auth.me();
                      const canCreate = user?.role === 'admin' || user?.app_role === 'admin' || user?.app_role === 'jefatura' || user?.app_role === 'financiero';
                      if (!canCreate) {
                        toast.error('No tienes permisos para crear agentes');
                        return;
                      }
                      setEditingAgent(null); 
                      setFormOpen(true); 
                    }} 
                    className="gap-2"
                  >
                    <Plus className="h-4 w-4" /> {t('agents.new')}
                  </Button>
                </div>
              }
            />
          </div>
        </div>

        {/* Filters and Table */}
        <Card className="border-0 shadow-sm p-6 mb-6">
          <div className="flex gap-4 mb-4 flex-wrap items-center">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={activityFilter} onValueChange={setActivityFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">{t('common.all')}</SelectItem>
                  <SelectItem value="activo">{t('common.active')}</SelectItem>
                  <SelectItem value="inactivo">{t('common.inactive')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={countryFilter} onValueChange={setCountryFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los países</SelectItem>
                  {countries.filter(c => c && c.trim()).map(country => (
                    <SelectItem key={country} value={country}>{country}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={tagFilter} onValueChange={setTagFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los tags</SelectItem>
                  <SelectItem value="nivel_2">Partner</SelectItem>
                  <SelectItem value="gapartner">GAPartner+</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DataTable
            columns={columns}
            data={filteredAgents}
            searchPlaceholder="Buscar por nombre, alias, email, teléfono o país..."
            searchKeys={['name', 'alias', 'email', 'phone', 'country']}
            initialSearch={searchQuery}
            onSearchChange={updateSearch}
            emptyMessage={t('common.noData')}
            actions={
              searchQuery && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={clearSearch}
                  className="text-muted-foreground hover:text-foreground/80 gap-1"
                >
                  <X className="h-4 w-4" /> Limpiar búsqueda
                </Button>
              )
            }
          />
        </Card>

        {/* Agent Detail */}
        {selectedAgent ? (
          <Card className="border-0 shadow-sm p-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl ${selectedAgent.agent_type === 'agencia' ? 'bg-purple-500/10' : 'bg-muted'}`}>
                      {selectedAgent.agent_type === 'agencia' ? (
                        <Building2 className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                      ) : (
                        <User className="h-6 w-6 text-foreground" />
                      )}
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-foreground">
                        {selectedAgent.name}
                        {selectedAgent.alias && (
                          <span className="text-muted-foreground/70 font-normal ml-1">({selectedAgent.alias})</span>
                        )}
                      </h2>
                      <p className="text-muted-foreground capitalize">{selectedAgent.agent_type}{hasStructure ? ` · Nivel ${selectedAgent.level || 1}` : ''}</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setSelectedAgent(null)}>
                    Cerrar
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 bg-muted/40 rounded-lg">
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-medium">{selectedAgent.email}</p>
                  </div>
                  <div className="p-4 bg-muted/40 rounded-lg">
                    <p className="text-sm text-muted-foreground">Teléfono</p>
                    <p className="font-medium">{selectedAgent.phone || '-'}</p>
                  </div>
                  <div className="p-4 bg-muted/40 rounded-lg">
                    <p className="text-sm text-muted-foreground">País</p>
                    <p className="font-medium">{selectedAgent.country}</p>
                  </div>
                  {hasStructure && (
                  <div className="p-4 bg-muted/40 rounded-lg">
                    <p className="text-sm text-muted-foreground">Superior</p>
                    <p className="font-medium">{selectedAgent.upline_agent_name || 'Sin superior'}</p>
                  </div>
                  )}
                </div>

                {/* Individual stats */}
                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-3">Métricas Individuales</h3>
                  {(() => {
                    const individualPolicies = policies.filter(p => p.agent_id === selectedAgent.id);
                    const activePolicies = individualPolicies.filter(p => p.status === 'activa');
                    const individualPremium = activePolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
                    
                    // Calculate persistence
                    const oneYearAgo = new Date();
                    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
                    const twoYearsAgo = new Date();
                    twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
                    
                    const currentPeriodRenewals = individualPolicies.filter(p => 
                      p.policy_type === 'renovacion' &&
                      new Date(p.created_date) >= oneYearAgo
                    );
                    const renewalPremium = currentPeriodRenewals.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
                    
                    const previousPeriodPolicies = individualPolicies.filter(p => 
                      new Date(p.created_date) >= twoYearsAgo && 
                      new Date(p.created_date) < oneYearAgo &&
                      p.policy_type !== 'nuevo_negocio'
                    );
                    const previousPremium = previousPeriodPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
                    
                    const persistence = previousPremium > 0 ? ((renewalPremium / previousPremium) * 100).toFixed(1) : 0;
                    
                    return (
                      <div className="grid grid-cols-3 gap-4">
                        <div className="p-4 bg-muted rounded-lg text-center">
                          <p className="text-2xl font-bold text-foreground">{individualPolicies.length}</p>
                          <p className="text-sm text-muted-foreground">Pólizas Propias</p>
                        </div>
                        <div className="p-4 bg-emerald-500/10 rounded-lg text-center">
                          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">${individualPremium.toLocaleString()}</p>
                          <p className="text-sm text-muted-foreground">Prima Individual</p>
                        </div>
                        <div className="p-4 bg-amber-500/10 rounded-lg text-center">
                          <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{persistence}%</p>
                          <p className="text-sm text-muted-foreground">Persistencia</p>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Downline stats */}
                <div className="border-t pt-4 mt-4">
                  <h3 className="font-semibold mb-3">Producción de la Red</h3>
                  {(() => {
                    const downlineIds = getDownlineIds(selectedAgent.id);
                    const networkPolicies = policies.filter(p => downlineIds.includes(p.agent_id));
                    const activePolicies = networkPolicies.filter(p => p.status === 'activa');
                    const totalPremium = activePolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
                    
                    return (
                      <div className="grid grid-cols-3 gap-4">
                        <div className="p-4 bg-muted rounded-lg text-center">
                          <p className="text-2xl font-bold text-foreground">{downlineIds.length - 1}</p>
                          <p className="text-sm text-muted-foreground">En su red</p>
                        </div>
                        <div className="p-4 bg-emerald-500/10 rounded-lg text-center">
                          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{networkPolicies.length}</p>
                          <p className="text-sm text-muted-foreground">Pólizas de Red</p>
                        </div>
                        <div className="p-4 bg-purple-500/10 rounded-lg text-center">
                          <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">${totalPremium.toLocaleString()}</p>
                          <p className="text-sm text-muted-foreground">Prima Total Red</p>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Commission Tables Assignment */}
                <div className="border-t pt-4 mt-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">Tablas de Comisiones</h3>
                    <Button 
                      size="sm" 
                      onClick={async () => {
                        const user = await api.auth.me();
                        const canAssign = user?.role === 'admin' || user?.app_role === 'admin' || user?.app_role === 'jefatura' || user?.app_role === 'financiero';
                        if (!canAssign) {
                          toast.error('No tienes permisos para asignar tablas de comisiones');
                          return;
                        }
                        setAssignmentFormOpen(true);
                      }}
                    >
                      <Plus className="h-3 w-3 mr-1" /> Asignar
                    </Button>
                  </div>

                  {assignmentFormOpen && (
                    <Card className="p-4 mb-4 bg-muted/40 border border-border">
                      <div className="space-y-3">
                        <div>
                          <label className="text-sm font-medium mb-1 block">Compañía *</label>
                          <Select value={newAssignment.company_id} onValueChange={(v) => setNewAssignment({...newAssignment, company_id: v, line_id: '', commission_table_id: ''})}>
                            <SelectTrigger className="h-8">
                              <SelectValue placeholder="Seleccionar compañía" />
                            </SelectTrigger>
                            <SelectContent>
                              {companies.sort((a, b) => a.name.localeCompare(b.name)).map(c => (
                                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {newAssignment.company_id && (
                          <div>
                            <label className="text-sm font-medium mb-1 block">Ramo *</label>
                            <Select value={newAssignment.line_id} onValueChange={(v) => setNewAssignment({...newAssignment, line_id: v, commission_table_id: ''})}>
                              <SelectTrigger className="h-8">
                                <SelectValue placeholder="Seleccionar ramo" />
                              </SelectTrigger>
                              <SelectContent>
                                {lines
                                  .filter(l => {
                                    const company = companies.find(c => c.id === newAssignment.company_id);
                                    return company?.lines?.includes(l.name);
                                  })
                                  .sort((a, b) => a.name.localeCompare(b.name))
                                  .map(l => (
                                    <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                          </div>
                        )}

                        {newAssignment.company_id && newAssignment.line_id && (
                          <div>
                            <label className="text-sm font-medium mb-1 block">Tabla de Comisión *</label>
                            <Select value={newAssignment.commission_table_id} onValueChange={(v) => setNewAssignment({...newAssignment, commission_table_id: v})}>
                              <SelectTrigger className="h-8">
                                <SelectValue placeholder="Seleccionar tabla" />
                              </SelectTrigger>
                              <SelectContent>
                                {commissionTables
                                  .filter(t => t.company_id === newAssignment.company_id && t.line_id === newAssignment.line_id)
                                  .map(t => (
                                    <SelectItem key={t.id} value={t.id}>{t.name} (Nivel {t.level})</SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                          </div>
                        )}

                        <div className="flex gap-2">
                          <Button size="sm" onClick={handleAddAssignment} className="flex-1">Guardar</Button>
                          <Button size="sm" variant="outline" onClick={() => setAssignmentFormOpen(false)} className="flex-1">Cancelar</Button>
                        </div>
                      </div>
                    </Card>
                  )}

                  <div className="space-y-2">
                    {commissionAssignments
                      .filter(a => a.agent_id === selectedAgent.id)
                      .map(assignment => (
                        <div key={assignment.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-lg border border-border">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-foreground">{assignment.company_name} - {assignment.line_name}</p>
                            <p className="text-xs text-muted-foreground">{assignment.commission_table_name}</p>
                          </div>
                          <Button size="icon" variant="ghost" onClick={() => handleRemoveAssignment(assignment.id)}>
                            <X className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    {commissionAssignments.filter(a => a.agent_id === selectedAgent.id).length === 0 && !assignmentFormOpen && (
                      <p className="text-sm text-muted-foreground/70 text-center py-2">Sin asignaciones</p>
                    )}
                  </div>
                </div>
              </Card>
            ) : null}

        <AgentForm
          open={formOpen}
          onOpenChange={setFormOpen}
          onSubmit={handleSubmit}
          initialData={editingAgent}
          isLoading={saving}
        />

        <DeleteSafetyDialog
          open={deleteDialogOpen}
          onOpenChange={(open) => { setDeleteDialogOpen(open); if (!open) setAgentToDelete(null); }}
          title="Eliminar agente"
          entityDescription={agentToDelete ? `el agente "${agentToDelete.name}"` : 'este agente'}
          checkUsage={agentToDelete ? checkAgentUsage : null}
          onConfirm={handleDeleteAgent}
        />
      </div>
    </div>
  );
}