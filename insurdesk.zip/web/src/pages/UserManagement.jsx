import { useFeatures } from '@/lib/FeatureContext';
import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import { Users, Plus, Loader2, Trash2, Mail, Pencil, Key, UserX, RefreshCw, Check, ChevronsUpDown, ShieldCheck, ShieldOff, ShieldX, CalendarClock } from 'lucide-react';
import { toast } from 'sonner';
import UserConnectionStatus from '@/components/users/UserConnectionStatus';

export default function UserManagement() {
  const { has } = useFeatures();
  const crmEnabled = has('crm');
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [editingUser, setEditingUser] = useState(null);
  const [deactivateDialogOpen, setDeactivateDialogOpen] = useState(false);
  const [userToDeactivate, setUserToDeactivate] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [resetMfaDialogOpen, setResetMfaDialogOpen] = useState(false);
  const [userToResetMfa, setUserToResetMfa] = useState(null);
  const [resettingMfa, setResettingMfa] = useState(false);
  const [migratingGrace, setMigratingGrace] = useState(false);
  const [togglingCrmId, setTogglingCrmId] = useState(null);
  
  // Form fields
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [appRole, setAppRole] = useState('agente');
  const [agentId, setAgentId] = useState('');
  const [systemRole, setSystemRole] = useState('user');
  const [crmAccess, setCrmAccess] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      const user = await api.auth.me();
      setCurrentUser(user);
    };
    loadUser();
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [usersData, userRolesData, agentsData] = await Promise.all([
        api.entities.User.list().catch(() => []),
        api.entities.UserRole.list().catch(() => []),
        api.entities.Agent.list()
      ]);
      
      // Merge User and UserRole data
      const mergedUsers = usersData.map(user => {
        const userRole = userRolesData.find(ur => ur.email.toLowerCase() === user.email.toLowerCase());
        return {
          ...user,
          app_role: userRole?.app_role,
          agent_id: userRole?.agent_id,
          user_role_id: userRole?.id,
          status: userRole?.status || 'pending_activation',
          mfa_enabled: userRole?.mfa_enabled || false,
          mfa_method: userRole?.mfa_method || null,
          mfa_grace_deadline: userRole?.mfa_grace_deadline || null,
          crm_access_enabled: userRole?.crm_access_enabled || false
        };
      });
      
      setUsers(mergedUsers);
      setAgents(agentsData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Error al cargar datos');
      setUsers([]);
      setAgents([]);
    }
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingUser) {
        // Update existing UserRole
        if (editingUser.user_role_id) {
          await api.entities.UserRole.update(editingUser.user_role_id, {
            app_role: appRole,
            agent_id: agentId || null,
            crm_access_enabled: crmAccess
          });
        } else {
          // Create UserRole if it doesn't exist
          await api.entities.UserRole.create({
            email: editingUser.email,
            app_role: appRole,
            agent_id: agentId || null,
            status: 'active',
            crm_access_enabled: crmAccess
          });
        }
        toast.success('Usuario actualizado correctamente');
      } else {
        // Send invitation (function creates both User and UserRole)
        try {
          const inviteRes = await api.functions.invoke('sendUserInvitation', {
            email,
            fullName,
            appRole,
            agentId,
            crmAccess
          });

          if (!inviteRes.data?.success) {
            throw new Error('Error sending invitation email');
          }

          toast.success(`Usuario invitado: ${email}. Se ha enviado un correo con los detalles de acceso.`);
        } catch (error) {
          console.error('Invitation error:', error);
          toast.error('Error al enviar invitación: ' + (error.message || 'Error desconocido'));
        }
      }
      
      setFormOpen(false);
      resetForm();
      await loadData();
    } catch (error) {
      console.error('Error saving user:', error);
      toast.error('Error al guardar usuario: ' + (error.message || 'Error desconocido'));
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setEmail('');
    setFullName('');
    setAppRole('operativo');
    setAgentId('');
    setSystemRole('user');
    setCrmAccess(false);
    setEditingUser(null);
  };

  const handleEdit = (user) => {
    const canEdit = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canEdit) return;
    
    setEditingUser(user);
    setEmail(user.email || '');
    setFullName(user.full_name || '');
    setAppRole(user.app_role || 'agente');
    setAgentId(user.agent_id || '');
    setSystemRole(user.role || 'user');
    setCrmAccess(user.crm_access_enabled || false);
    setFormOpen(true);
  };

  // Cualquier usuario autenticado puede ver el estado de conexión
  const canViewConnectionStatus = !!currentUser;

  const handleResetPassword = async (user) => {
    try {
      await api.users.inviteUser(user.email, user.role);
      alert(`Se ha enviado un enlace para restablecer contraseña a ${user.email}`);
    } catch (error) {
      alert('Error al enviar enlace de restablecimiento: ' + error.message);
    }
  };

  const handleDeactivate = async () => {
    if (userToDeactivate && userToDeactivate.user_role_id) {
      await api.entities.UserRole.update(userToDeactivate.user_role_id, {
        status: 'inactive'
      });
      setDeactivateDialogOpen(false);
      setUserToDeactivate(null);
      loadData();
    }
  };

  const handleResetMFA = async () => {
    if (!userToResetMfa) return;
    setResettingMfa(true);
    try {
      await api.functions.invoke('resetUserMFA', { email: userToResetMfa.email });
      toast.success('MFA reseteado correctamente');
      setResetMfaDialogOpen(false);
      setUserToResetMfa(null);
      loadData();
    } catch (err) {
      toast.error('Error al resetear MFA: ' + (err.message || 'Error'));
    } finally {
      setResettingMfa(false);
    }
  };

  const handleToggleCrm = async (userRow, newValue) => {
    if (!userRow.user_role_id) {
      toast.error('Este usuario no tiene rol configurado. Edítalo primero.');
      return;
    }
    setTogglingCrmId(userRow.id);
    const prevValue = userRow.crm_access_enabled;
    // Optimistic update
    setUsers(prev => prev.map(u => u.id === userRow.id ? { ...u, crm_access_enabled: newValue } : u));
    try {
      await api.entities.UserRole.update(userRow.user_role_id, { crm_access_enabled: newValue });
      toast.success(newValue ? 'Acceso CRM concedido' : 'Acceso CRM revocado');
    } catch (err) {
      // Revert on error
      setUsers(prev => prev.map(u => u.id === userRow.id ? { ...u, crm_access_enabled: prevValue } : u));
      toast.error('Error al actualizar acceso CRM: ' + (err.message || 'Error'));
    } finally {
      setTogglingCrmId(null);
    }
  };

  const handleMigrateGrace = async () => {
    setMigratingGrace(true);
    try {
      const res = await api.functions.invoke('migrateMFAGracePeriod', {});
      const data = res.data || res;
      toast.success(`Período de gracia configurado: ${data.updated} usuarios actualizados (fecha límite: ${data.graceDeadline})`);
      loadData();
    } catch (err) {
      toast.error('Error al migrar: ' + (err.message || 'Error'));
    } finally {
      setMigratingGrace(false);
    }
  };

  const handleDelete = async () => {
    if (userToDelete) {
      await api.entities.User.delete(userToDelete.id);
      setDeleteDialogOpen(false);
      setUserToDelete(null);
      loadData();
    }
  };

  const columns = [
    {
      header: 'Usuario',
      cell: (row) => (
        <div>
          <p className="font-medium text-foreground">{row.full_name || 'Sin nombre'}</p>
          <p className="text-sm text-muted-foreground">{row.email}</p>
        </div>
      )
    },
    {
      header: 'Estado',
      cell: (row) => {
        const statusMap = {
          'active': { label: '✓ Activo', color: 'bg-green-500/10 text-green-600 dark:text-green-400' },
          'pending_activation': { label: '⏳ Pendiente Activación', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400' },
          'inactive': { label: '✗ Inactivo', color: 'bg-muted text-foreground' }
        };
        // Usar el status real del UserRole; si no tiene UserRole aún, está pendiente
        const effectiveStatus = row.status || 'pending_activation';
        const status = statusMap[effectiveStatus] || statusMap['pending_activation'];
        return (
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${status.color}`}>
            {status.label}
          </span>
        );
      }
    },
    {
      header: 'Rol Sistema',
      cell: (row) => (
        <span className="text-sm capitalize">{row.role === 'admin' ? 'Admin' : 'Usuario'}</span>
      )
    },
    {
      header: 'Rol App',
      cell: (row) => (
        <span className="text-sm font-medium capitalize">
          {row.app_role || 'No asignado'}
        </span>
      )
    },
    {
      header: 'Agente Vinculado',
      cell: (row) => {
        if (!row.agent_id) return <span className="text-sm text-muted-foreground/70">-</span>;
        const agent = agents.find(a => a.id === row.agent_id);
        return <span className="text-sm">{agent?.name || 'Agente eliminado'}</span>;
      }
    },
    ...(crmEnabled ? [{
      header: 'CRM',
      cell: (row) => {
        const isAdminUser = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
        return (
          <Switch
            checked={row.crm_access_enabled || false}
            disabled={!isAdminUser || !row.user_role_id || togglingCrmId === row.id}
            onCheckedChange={(checked) => handleToggleCrm(row, checked)}
          />
        );
      }
    }] : []),
    {
      header: 'Fecha Registro',
      cell: (row) => (
        <span className="text-sm text-muted-foreground">
          {row.created_date ? new Date(row.created_date).toLocaleDateString() : '-'}
        </span>
      )
    },
    {
      header: 'MFA',
      cell: (row) => {
        if (!row.mfa_enabled) {
          const deadline = row.mfa_grace_deadline;
          const daysLeft = deadline ? Math.ceil((new Date(deadline) - new Date()) / (1000 * 60 * 60 * 24)) : null;
          return (
            <div className="flex items-center gap-1.5">
              <ShieldOff className="h-4 w-4 text-muted-foreground/70" />
              <span className="text-xs text-muted-foreground">
                {daysLeft !== null && daysLeft >= 0 ? `${daysLeft}d gracia` : 'No configurado'}
              </span>
            </div>
          );
        }
        return (
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-green-600 dark:text-green-400" />
            <span className="text-xs font-medium text-green-600 dark:text-green-400">
              {row.mfa_method === 'totp' ? 'TOTP' : 'Email'}
            </span>
          </div>
        );
      }
    },
    {
      header: 'Acciones',
      cell: (row) => {
        const isAdmin = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
        if (!isAdmin) return null;
        
        return (
          <div className="flex items-center gap-1">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => handleEdit(row)}
              title="Editar"
            >
              <Pencil className="h-4 w-4 text-foreground" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => handleResetPassword(row)}
              title="Restablecer contraseña"
            >
              <Key className="h-4 w-4 text-amber-500" />
            </Button>
            {row.app_role && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => { setUserToDeactivate(row); setDeactivateDialogOpen(true); }}
                title="Desactivar usuario"
              >
                <UserX className="h-4 w-4 text-orange-500" />
              </Button>
            )}
            {row.mfa_enabled && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => { setUserToResetMfa(row); setResetMfaDialogOpen(true); }}
                title="Resetear MFA"
              >
                <ShieldX className="h-4 w-4 text-purple-500" />
              </Button>
            )}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => { setUserToDelete(row); setDeleteDialogOpen(true); }}
              disabled={row.role === 'admin'}
              title="Eliminar"
            >
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        );
      }
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Gestión de Usuarios"
          subtitle={`${users.length} usuarios registrados`}
          icon={Users}
          backTo="AdminPanel"
          actions={
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={loadData} 
                size="sm"
                className="gap-2"
              >
                <RefreshCw className="h-4 w-4" /> <span className="hidden sm:inline">Recargar</span>
              </Button>
              {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
                <>
                  <Button
                    variant="outline"
                    onClick={handleMigrateGrace}
                    disabled={migratingGrace}
                    size="sm"
                    className="gap-2"
                  >
                    {migratingGrace ? <Loader2 className="h-4 w-4 animate-spin" /> : <CalendarClock className="h-4 w-4" />}
                    <span className="hidden sm:inline">Migrar Gracia MFA</span>
                  </Button>
                  <Button onClick={() => { resetForm(); setFormOpen(true); }} size="sm" className="gap-2">
                    <Plus className="h-4 w-4" /> <span className="hidden sm:inline">Invitar Usuario</span>
                  </Button>
                </>
              )}
            </div>
          }
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="border-0 shadow-sm bg-muted border-border">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-foreground font-medium">Total Invitaciones</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {users.length}
                  </p>
                  <p className="text-xs text-foreground mt-1">
                    Usuarios invitados al sistema
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-green-500/10 border-green-500/30">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <Users className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
                <div>
                  <p className="text-sm text-green-600 dark:text-green-400 font-medium">Usuarios Activos</p>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-1">
                    {users.filter(u => u.status === 'active').length}
                  </p>
                  <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                    Con acceso habilitado
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-amber-500/10 border-amber-500/30">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <Key className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5" />
                <div>
                  <p className="text-sm text-amber-600 dark:text-amber-400 font-medium">Invitaciones Pendientes</p>
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
                    {users.filter(u => !u.status || u.status === 'pending_activation').length}
                  </p>
                  <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                    Esperando primer login
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {canViewConnectionStatus && <UserConnectionStatus users={users} />}

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            columns={columns}
            data={users}
            searchPlaceholder="Buscar por nombre o email..."
            emptyMessage="No hay usuarios registrados"
          />
        </Card>

        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingUser ? 'Editar Usuario' : 'Invitar Nuevo Usuario'}</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email *</Label>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="usuario@ejemplo.com"
                    disabled={!!editingUser}
                    required
                  />
                  {editingUser && (
                    <p className="text-xs text-muted-foreground">El email no se puede modificar</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label>Nombre Completo *</Label>
                  <Input
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value.toUpperCase())}
                    placeholder="JUAN PÉREZ"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Rol en el Sistema</Label>
                  <Select value={systemRole} onValueChange={setSystemRole} disabled={!!editingUser}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">Usuario Regular</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {editingUser ? 'El rol del sistema no se puede modificar' : 'Admin tiene acceso completo al sistema'}
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Perfil de Aplicación *</Label>
                  <Select value={appRole} onValueChange={setAppRole}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="gerencial">Gerencial</SelectItem>
                      <SelectItem value="jefatura">Jefatura</SelectItem>
                      <SelectItem value="operativo">Operativo</SelectItem>
                      <SelectItem value="financiero">Financiero</SelectItem>
                      <SelectItem value="agente">Agente</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Define permisos específicos de la app
                  </p>
                </div>
              </div>

              {(appRole === 'agente' || appRole === 'gerencial') && (
                <div className="space-y-2">
                  <Label>Vincular con Agente (Opcional)</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded="false"
                        className="w-full justify-between"
                      >
                        <span className="truncate">
                          {agentId
                            ? agents.find((a) => a.id === agentId)?.name || 'Seleccionar agente...'
                            : 'Seleccionar agente...'}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Buscar agente..." />
                        <CommandList>
                          <CommandEmpty>No se encontraron agentes.</CommandEmpty>
                          <CommandGroup>
                            <CommandItem
                              value="none"
                              onSelect={() => setAgentId('')}
                            >
                              Ninguno
                              <Check
                                className={`ml-auto h-4 w-4 ${!agentId ? 'opacity-100' : 'opacity-0'}`}
                              />
                            </CommandItem>
                            {agents.map((agent) => (
                              <CommandItem
                                key={agent.id}
                                value={agent.name}
                                onSelect={() => setAgentId(agent.id)}
                              >
                                {agent.name}
                                <Check
                                  className={`ml-auto h-4 w-4 ${agentId === agent.id ? 'opacity-100' : 'opacity-0'}`}
                                />
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <p className="text-xs text-muted-foreground">
                    {appRole === 'gerencial' 
                      ? 'El usuario gerencial verá solo los datos de la estructura de este agente'
                      : 'Si se vincula, el usuario verá datos relacionados con este agente'
                    }
                  </p>
                </div>
              )}

              {crmEnabled && (
              <div className="flex items-center justify-between rounded-lg border border-border p-4">
                <div>
                  <Label className="text-base">Acceso al módulo CRM</Label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Autoriza a este usuario a acceder a Pipeline, Prospectos, Calendario y Radar IA
                  </p>
                </div>
                <Switch
                  checked={crmAccess}
                  onCheckedChange={setCrmAccess}
                />
              </div>
              )}

              <div className="bg-muted/40 rounded-lg p-4">
                <h4 className="font-medium text-foreground mb-2">Roles y Permisos:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• <strong>Admin:</strong> Acceso total sin restricciones</li>
                  <li>• <strong>Gerencial:</strong> Acceso a todo pero sin editar (solo lectura)</li>
                  <li>• <strong>Jefatura:</strong> Ver pólizas/endosos/pagos, crear agentes, asignar tablas y ver estructura</li>
                  <li>• <strong>Operativo:</strong> Crear/editar pólizas, pagos, siniestros y tareas</li>
                  <li>• <strong>Financiero:</strong> Ver pólizas y aplicar pagos (sin editar pólizas ni ver siniestros)</li>
                  <li>• <strong>Agente:</strong> Portal individual con sus pólizas y comisiones</li>
                </ul>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => { setFormOpen(false); resetForm(); }}
                  disabled={saving}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingUser ? 'Actualizar Usuario' : 'Invitar Usuario'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deactivateDialogOpen} onOpenChange={setDeactivateDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Desactivar usuario?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción desactivará el acceso del usuario al sistema, pero conservará su cuenta.
                El usuario {userToDeactivate && `"${userToDeactivate.email}"`} no podrá acceder hasta que se reactive.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeactivate} className="bg-orange-600 hover:bg-orange-700">
                Desactivar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <AlertDialog open={resetMfaDialogOpen} onOpenChange={setResetMfaDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Resetear MFA de este usuario?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción desactivará el MFA del usuario {userToResetMfa && `"${userToResetMfa.email}"`}.
                El usuario deberá configurar MFA nuevamente en su próximo inicio de sesión.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleResetMFA}
                disabled={resettingMfa}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {resettingMfa && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Resetear MFA
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar usuario?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará permanentemente el usuario
                {userToDelete && ` "${userToDelete.email}"`}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}