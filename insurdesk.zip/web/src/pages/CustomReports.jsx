import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import PageHeader from '@/components/ui/PageHeader';
import * as XLSX from 'xlsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Download, Save, Trash2, Play, X, 
  ChevronDown, ChevronUp, Filter, Loader2 
} from 'lucide-react';
import AgentSelect from '@/components/forms/AgentSelect';
import PolicyTagFilter from '@/components/policy/PolicyTagFilter';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatMoney, round2 } from '@/lib/formatMoney';

export default function CustomReports() {
  const [loading, setLoading] = useState(false);
  const [executing, setExecuting] = useState(false);
  
  // Data sources
  const [policies, setPolicies] = useState([]);
  const [clients, setClients] = useState([]);
  const [payments, setPayments] = useState([]);
  const [commissions, setCommissions] = useState([]);
  const [agents, setAgents] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [allowedAgentIds, setAllowedAgentIds] = useState(null);
  const [lines, setLines] = useState([]);
  const [products, setProducts] = useState([]);
  const [branches, setBranches] = useState([]);
  
  // Report results
  const [reportData, setReportData] = useState([]);
  const [sortField, setSortField] = useState(null);
  const [sortOrder, setSortOrder] = useState('asc');
  const [showResults, setShowResults] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  
  // Templates
  const [templates, setTemplates] = useState([]);
  const [showSaveTemplate, setShowSaveTemplate] = useState(false);
  const [templateName, setTemplateName] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  
  // Selected columns (checkboxes)
  const [selectedColumns, setSelectedColumns] = useState({
    // Cliente
    client_name: true,
    client_document: false,
    client_country: false,
    client_city: false,
    client_email: false,
    client_phone: false,
    client_type: false,
    
    // Póliza
    policy_number: true,
    policy_status: true,
    policy_type: true,
    issue_date: false,
    start_date: false,
    end_date: false,
    currency: false,
    annual_premium: true,
    commissionable_premium: false,
    sum_insured: false,
    deductible_1: false,
    payment_frequency: false,
    line_name: true,
    product_name: true,
    company_name: true,
    
    // Agente
    agent_name: true,
    agent_type: false,
    agent_upline: false,
    agent_structure_head: false,
    agent_level: false,
    agent_country: false,
    is_nivel_2: false,
    is_gapartner: false,
    
    // Pagos
    payment_status: false,
    payment_date: false,
    payment_amount: false,
    payment_period: false,
    
    // Comisiones
    commission_pct: false,
    commission_amount: false,
    commission_status: false,
    commission_generation_date: false
  });
  
  // Filters
  const [filters, setFilters] = useState({
    date_field: 'created_date',
    date_from: '',
    date_to: '',
    policy_status: 'all',
    policy_type: 'all',
    line_id: 'all',
    product_id: 'all',
    company_id: 'all',
    branch_id: 'all',
    client_country: [],
    policy_country: [],
    currency: 'all',
    payment_frequency: 'all',
    agent_id: 'all',
    agent_type: 'all',
    include_structure: false,
    is_nivel_2: 'all',
    is_gapartner: 'all',
    commission_status: 'all',
    payment_status: 'all',
    tag_include: [],
    tag_exclude: []
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const currentUser = await api.auth.me();
      const [
        policiesData, clientsData, paymentsData, commissionsData,
        agentsData, companiesData, linesData, productsData, branchesData, templatesData
      ] = await Promise.all([
        api.entities.Policy.list(),
        api.entities.Client.list(),
        api.entities.Payment.list(),
        api.entities.Commission.list(),
        api.entities.Agent.list(),
        api.entities.InsuranceCompany.list(),
        api.entities.InsuranceLine.list(),
        api.entities.Product.list(),
        api.entities.Branch.list().then(data => data.sort((a, b) => a.name.localeCompare(b.name))),
        api.entities.ReportTemplate?.list().catch(() => [])
      ]);

      // Si es agente o gerencial, filtrar por su estructura
      let filteredPolicies = policiesData;
      const isAgentOrGerencial = (currentUser.app_role === 'agente' || currentUser.app_role === 'gerencial') && currentUser.agent_id;
      if (isAgentOrGerencial) {
        const agentStructure = getAgentStructureSync(currentUser.agent_id, agentsData);
        filteredPolicies = policiesData.filter(p => agentStructure.includes(p.agent_id));
        setAllowedAgentIds(agentStructure);
      } else {
        setAllowedAgentIds(null);
      }

      const filteredClientIds = new Set(filteredPolicies.map(p => p.client_id));
      const filteredClients = clientsData.filter(c => filteredClientIds.has(c.id));

      setPolicies(filteredPolicies);
      setClients(filteredClients);
      setPayments(paymentsData);
      setCommissions(commissionsData);
      setAgents(agentsData);
      setCompanies(companiesData);
      setLines(linesData);
      setProducts(productsData);
      setBranches(branchesData);
      setTemplates(templatesData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getAgentStructureSync = (agentId, allAgents) => {
    const structure = [agentId];
    const findDownline = (id) => {
      const downline = allAgents.filter(a => a.upline_agent_id === id);
      downline.forEach(agent => {
        structure.push(agent.id);
        findDownline(agent.id);
      });
    };
    findDownline(agentId);
    return structure;
  };

  const getAgentStructure = (agentId) => {
    const structure = [agentId];
    const findDownline = (id) => {
      const downline = agents.filter(a => a.upline_agent_id === id);
      downline.forEach(agent => {
        structure.push(agent.id);
        findDownline(agent.id);
      });
    };
    findDownline(agentId);
    return structure;
  };

  const uniqueClientCountries = [...new Set(clients.map(c => c.country).filter(Boolean))].sort();
  const uniquePolicyCountries = [...new Set(policies.map(p => p.country).filter(Boolean))].sort();

  const executeReport = () => {
    setExecuting(true);
    
    try {
      let filteredPolicies = [...policies];
      
      // Apply filters
      if (filters.date_from || filters.date_to) {
        filteredPolicies = filteredPolicies.filter(p => {
          let dateToCheck;
          switch (filters.date_field) {
            case 'created_date': dateToCheck = p.created_date; break;
            case 'start_date': dateToCheck = p.start_date; break;
            case 'end_date': dateToCheck = p.end_date; break;
            default: dateToCheck = p.created_date;
          }
          
          if (!dateToCheck) return false;
          const policyDate = new Date(dateToCheck);
          
          if (filters.date_from && policyDate < new Date(filters.date_from)) return false;
          if (filters.date_to && policyDate > new Date(filters.date_to)) return false;
          return true;
        });
      }
      
      if (filters.policy_status !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.status === filters.policy_status);
      }
      
      if (filters.policy_type !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.policy_type === filters.policy_type);
      }
      
      if (filters.line_id !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.line_id === filters.line_id);
      }
      
      if (filters.product_id !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.product_id === filters.product_id);
      }
      
      if (filters.company_id !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.company_id === filters.company_id);
      }
      
      if (filters.branch_id !== 'all') {
        // Branch groups companies: filter policies whose company belongs to the selected branch
        const companyIdsInBranch = new Set(
          companies.filter(c => c.branch_id === filters.branch_id).map(c => c.id)
        );
        filteredPolicies = filteredPolicies.filter(p => companyIdsInBranch.has(p.company_id));
      }
      
      if (filters.client_country.length > 0) {
        filteredPolicies = filteredPolicies.filter(p => {
          const client = clients.find(c => c.id === p.client_id);
          return filters.client_country.includes(client?.country);
        });
      }
      
      if (filters.policy_country.length > 0) {
        filteredPolicies = filteredPolicies.filter(p => {
          return filters.policy_country.includes(p.country);
        });
      }
      
      if (filters.currency !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.currency === filters.currency);
      }
      
      if (filters.payment_frequency !== 'all') {
        filteredPolicies = filteredPolicies.filter(p => p.payment_frequency === filters.payment_frequency);
      }
      
      if (filters.agent_id !== 'all') {
        if (filters.include_structure) {
          const structure = getAgentStructure(filters.agent_id);
          filteredPolicies = filteredPolicies.filter(p => structure.includes(p.agent_id));
        } else {
          filteredPolicies = filteredPolicies.filter(p => p.agent_id === filters.agent_id);
        }
      }
      
      if (filters.agent_type !== 'all') {
        const agentIds = agents.filter(a => a.agent_type === filters.agent_type).map(a => a.id);
        filteredPolicies = filteredPolicies.filter(p => agentIds.includes(p.agent_id));
      }
      
      if (filters.is_nivel_2 !== 'all') {
        const agentIds = agents.filter(a => a.is_nivel_2 === (filters.is_nivel_2 === 'true')).map(a => a.id);
        filteredPolicies = filteredPolicies.filter(p => agentIds.includes(p.agent_id));
      }
      
      if (filters.is_gapartner !== 'all') {
        const agentIds = agents.filter(a => a.is_gapartner === (filters.is_gapartner === 'true')).map(a => a.id);
        filteredPolicies = filteredPolicies.filter(p => agentIds.includes(p.agent_id));
      }
      
      // Tag filters
      if (filters.tag_include.length > 0) {
        filteredPolicies = filteredPolicies.filter(p => {
          const policyTagIds = (p.tags || []).map(t => t.id);
          return filters.tag_include.some(id => policyTagIds.includes(id));
        });
      }
      if (filters.tag_exclude.length > 0) {
        filteredPolicies = filteredPolicies.filter(p => {
          const policyTagIds = (p.tags || []).map(t => t.id);
          return !filters.tag_exclude.some(id => policyTagIds.includes(id));
        });
      }
      
      // Build report data
      const data = filteredPolicies.map(policy => {
        const client = clients.find(c => c.id === policy.client_id);
        const agent = agents.find(a => a.id === policy.agent_id);
        const uplineAgent = agent?.upline_agent_id ? agents.find(a => a.id === agent.upline_agent_id) : null;
        
        const policyPayments = payments.filter(p => p.policy_id === policy.id);
        const policyCommissions = commissions.filter(c => c.policy_id === policy.id);
        
        const row = { _policy: policy };
        
        // Cliente
        if (selectedColumns.client_name) {
          row.client_name = client?.client_type === 'persona' 
            ? `${client.first_name || ''} ${client.last_name || ''}`.trim()
            : client?.company_name || '';
        }
        if (selectedColumns.client_document) row.client_document = client?.document_id || '';
        if (selectedColumns.client_country) row.client_country = client?.country || '';
        if (selectedColumns.client_city) row.client_city = client?.city || '';
        if (selectedColumns.client_email) row.client_email = client?.email || '';
        if (selectedColumns.client_phone) row.client_phone = client?.phone || '';
        if (selectedColumns.client_type) row.client_type = client?.client_type || '';
        
        // Póliza
        if (selectedColumns.policy_number) row.policy_number = policy.policy_number;
        if (selectedColumns.policy_status) row.policy_status = policy.status;
        if (selectedColumns.policy_type) row.policy_type = policy.policy_type;
        if (selectedColumns.issue_date) row.issue_date = policy.issue_date;
        if (selectedColumns.start_date) row.start_date = policy.start_date;
        if (selectedColumns.end_date) row.end_date = policy.end_date;
        if (selectedColumns.country) row.country = policy.country;
        if (selectedColumns.currency) row.currency = policy.currency;
        if (selectedColumns.annual_premium) row.annual_premium = policy.annual_premium;
        if (selectedColumns.commissionable_premium) row.commissionable_premium = policy.commissionable_premium;
        if (selectedColumns.sum_insured) row.sum_insured = policy.sum_insured;
        if (selectedColumns.deductible_1) row.deductible_1 = policy.deductible_1;
        if (selectedColumns.payment_frequency) row.payment_frequency = policy.payment_frequency;
        if (selectedColumns.line_name) row.line_name = policy.line_name;
        if (selectedColumns.product_name) row.product_name = policy.product_name;
        if (selectedColumns.company_name) row.company_name = policy.company_name;
        
        // Agente
        if (selectedColumns.agent_name) row.agent_name = agent?.name || '';
        if (selectedColumns.agent_type) row.agent_type = agent?.agent_type || '';
        if (selectedColumns.agent_upline) row.agent_upline = uplineAgent?.name || '';
        if (selectedColumns.agent_structure_head) {
          // Walk up hierarchy to find the first upline with is_nivel_2 = true (Partner)
          let current = agent;
          let head = null;
          const visited = new Set();
          while (current?.upline_agent_id && !visited.has(current.id)) {
            visited.add(current.id);
            const upline = agents.find(a => a.id === current.upline_agent_id);
            if (!upline) break;
            if (upline.is_nivel_2) { head = upline; break; }
            current = upline;
          }
          row.agent_structure_head = head?.name || '';
        }
        if (selectedColumns.agent_level) row.agent_level = agent?.level || '';
        if (selectedColumns.agent_country) row.agent_country = agent?.country || '';
        if (selectedColumns.is_nivel_2) row.is_nivel_2 = agent?.is_nivel_2 ? 'Sí' : 'No';
        if (selectedColumns.is_gapartner) row.is_gapartner = agent?.is_gapartner ? 'Sí' : 'No';
        
        // Pagos (agregados)
        if (selectedColumns.payment_status || selectedColumns.payment_date || 
            selectedColumns.payment_amount || selectedColumns.payment_period) {
          const lastPayment = policyPayments.length > 0 ? policyPayments[policyPayments.length - 1] : null;
          if (selectedColumns.payment_status) row.payment_status = lastPayment?.status || 'N/A';
          if (selectedColumns.payment_date) row.payment_date = lastPayment?.payment_date || '';
          if (selectedColumns.payment_amount) row.payment_amount = lastPayment?.amount || 0;
          if (selectedColumns.payment_period) row.payment_period = lastPayment?.period || '';
        }
        
        // Comisiones (agregadas)
        if (selectedColumns.commission_pct || selectedColumns.commission_amount || 
            selectedColumns.commission_status || selectedColumns.commission_generation_date) {
          const totalCommission = policyCommissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);
          const avgPct = policyCommissions.length > 0 
            ? policyCommissions.reduce((sum, c) => sum + (c.commission_pct || 0), 0) / policyCommissions.length 
            : 0;
          const lastCommission = policyCommissions.length > 0 ? policyCommissions[policyCommissions.length - 1] : null;
          
          if (selectedColumns.commission_pct) row.commission_pct = avgPct.toFixed(2);
          if (selectedColumns.commission_amount) row.commission_amount = totalCommission;
          if (selectedColumns.commission_status) row.commission_status = lastCommission?.status || 'N/A';
          if (selectedColumns.commission_generation_date) row.commission_generation_date = lastCommission?.generation_date || '';
        }
        
        return row;
      });
      
      // Apply payment/commission filters if needed
      let finalData = data;
      
      if (filters.payment_status !== 'all') {
        finalData = finalData.filter(row => row.payment_status === filters.payment_status);
      }
      
      if (filters.commission_status !== 'all') {
        finalData = finalData.filter(row => row.commission_status === filters.commission_status);
      }
      
      setReportData(finalData);
      setShowResults(true);
      setCurrentPage(0);
    } catch (error) {
      console.error('Error executing report:', error);
      alert('Error al ejecutar el reporte');
    } finally {
      setExecuting(false);
    }
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const sortedData = [...reportData].sort((a, b) => {
    if (!sortField) return 0;
    
    let aVal = a[sortField];
    let bVal = b[sortField];
    
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
    }
    
    aVal = String(aVal || '');
    bVal = String(bVal || '');
    
    return sortOrder === 'asc' 
      ? aVal.localeCompare(bVal)
      : bVal.localeCompare(aVal);
  });

  const getExportRows = () => {
    const keys = Object.keys(selectedColumns).filter(key => selectedColumns[key]);
    const headerLabels = keys.map(h => getColumnLabel(h));
    const totals = getTotals();

    const numericKeys = ['annual_premium', 'commissionable_premium', 'sum_insured', 'deductible_1', 'payment_amount', 'commission_amount'];
    const dataRows = sortedData.map(row =>
      keys.map(key => {
        const val = row[key];
        if (val === undefined || val === null) return '';
        if (numericKeys.includes(key) && typeof val === 'number') return round2(val);
        return val;
      })
    );

    // Add totals row
    const totalsRow = keys.map((key, idx) => {
      if (idx === 0) return 'TOTALES';
      return totals[key] !== undefined ? totals[key] : '';
    });
    dataRows.push(totalsRow);

    return { headerLabels, keys, dataRows };
  };

  const handleExportCSV = () => {
    const { headerLabels, dataRows } = getExportRows();
    // BOM for proper tilde/ñ support
    const csvRows = dataRows.map(row =>
      row.map(cell => `"${String(cell === null || cell === undefined ? '' : cell).replace(/"/g, '""')}"`).join(',')
    );
    const BOM = '\uFEFF';
    const csv = BOM + [headerLabels.join(','), ...csvRows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_personalizado_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportExcel = () => {
    const { headerLabels, dataRows } = getExportRows();
    const wsData = [headerLabels, ...dataRows];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const colWidths = headerLabels.map(h => ({ wch: Math.max(h.length + 2, 12) }));
    ws['!cols'] = colWidths;
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Reporte');
    XLSX.writeFile(wb, `reporte_personalizado_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const saveTemplate = async () => {
    if (!templateName.trim()) {
      alert('Ingresa un nombre para la plantilla');
      return;
    }
    
    try {
      const templateData = {
        name: templateName,
        selected_columns: selectedColumns,
        filters: filters
      };
      
      await api.entities.ReportTemplate.create(templateData);
      loadData();
      setShowSaveTemplate(false);
      setTemplateName('');
      toast.success('Plantilla guardada correctamente');
    } catch (error) {
      console.error('Error saving template:', error);
      alert('Error al guardar la plantilla');
    }
  };

  const loadTemplate = (template) => {
    setSelectedColumns(template.selected_columns || {});
    setFilters(template.filters || {});
    setSelectedTemplate(template);
  };

  const deleteTemplate = async (templateId) => {
    if (!confirm('¿Eliminar esta plantilla?')) return;
    
    try {
      await api.entities.ReportTemplate.delete(templateId);
      loadData();
      if (selectedTemplate?.id === templateId) setSelectedTemplate(null);
    } catch (error) {
      console.error('Error deleting template:', error);
      alert('Error al eliminar la plantilla');
    }
  };

  const getColumnLabel = (key) => {
    const labels = {
      client_name: 'Cliente',
      client_document: 'Documento',
      client_country: 'País Cliente',
      client_city: 'Ciudad Cliente',
      client_email: 'Email',
      client_phone: 'Teléfono',
      client_type: 'Tipo Cliente',
      policy_number: 'Nº Póliza',
      policy_status: 'Estado Póliza',
      policy_type: 'Tipo Póliza',
      issue_date: 'Fecha Emisión',
      start_date: 'Vigencia Desde',
      end_date: 'Vigencia Hasta',
      country: 'País Póliza',
      currency: 'Moneda',
      annual_premium: 'Prima Anual',
      commissionable_premium: 'Prima Comisionable',
      sum_insured: 'Suma Asegurada',
      deductible_1: 'Deducible',
      payment_frequency: 'Frecuencia Pago',
      line_name: 'Ramo',
      product_name: 'Producto',
      company_name: 'Compañía',
      agent_name: 'Agente',
      agent_type: 'Tipo Agente',
      agent_upline: 'Upline',
      agent_structure_head: 'Cabeza de Estructura',
      agent_level: 'Nivel',
      agent_country: 'País Agente',
      is_nivel_2: 'Partner',
      is_gapartner: 'GAPartner+',
      payment_status: 'Estado Pago',
      payment_date: 'Fecha Pago',
      payment_amount: 'Monto Pago',
      payment_period: 'Período Pago',
      commission_pct: '% Comisión',
      commission_amount: 'Monto Comisión',
      commission_status: 'Estado Comisión',
      commission_generation_date: 'Fecha Comisión'
    };
    return labels[key] || key;
  };

  const getTotals = () => {
    const totals = {};
    
    if (selectedColumns.annual_premium) {
      totals.annual_premium = sortedData.reduce((sum, row) => sum + (row.annual_premium || 0), 0);
    }
    if (selectedColumns.commissionable_premium) {
      totals.commissionable_premium = sortedData.reduce((sum, row) => sum + (row.commissionable_premium || 0), 0);
    }
    if (selectedColumns.commission_amount) {
      totals.commission_amount = sortedData.reduce((sum, row) => sum + (row.commission_amount || 0), 0);
    }
    if (selectedColumns.payment_amount) {
      totals.payment_amount = sortedData.reduce((sum, row) => sum + (row.payment_amount || 0), 0);
    }
    
    return totals;
  };

  const activeFilters = Object.entries(filters).filter(([key, value]) => {
    if (key === 'date_field') return false;
    if (value === 'all' || value === '' || value === false) return false;
    if (Array.isArray(value) && value.length === 0) return false;
    return true;
  });

  const columnSections = {
    cliente: ['client_name', 'client_document', 'client_country', 'client_city', 'client_email', 'client_phone', 'client_type'],
    poliza: ['policy_number', 'policy_status', 'policy_type', 'issue_date', 'start_date', 'end_date', 'country', 'currency', 'annual_premium', 'commissionable_premium', 'sum_insured', 'deductible_1', 'payment_frequency', 'line_name', 'product_name', 'company_name', 'agent_name', 'agent_type', 'agent_upline'],
    agente: ['agent_structure_head', 'agent_level', 'agent_country', 'is_nivel_2', 'is_gapartner'],
    pagos: ['payment_status', 'payment_date', 'payment_amount', 'payment_period'],
    comisiones: ['commission_pct', 'commission_amount', 'commission_status', 'commission_generation_date']
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <PageHeader
          title="Reportes Personalizados"
          subtitle="Crea reportes a medida con filtros y columnas personalizables"
          backTo="Reports"
        />

        {/* Saved Templates Selector */}
        {templates.length > 0 && (
          <Card className="border-border bg-muted">
            <CardContent className="py-3 px-4">
              <div className="flex items-center gap-3 flex-wrap">
                <span className="text-sm font-semibold text-foreground whitespace-nowrap">📋 Cargar reporte guardado:</span>
                <div className="flex-1 min-w-[200px]">
                  <Select
                    value={selectedTemplate?.id || 'none'}
                    onValueChange={(val) => {
                      if (val === 'none') {
                        setSelectedTemplate(null);
                      } else {
                        const t = templates.find(t => t.id === val);
                        if (t) loadTemplate(t);
                      }
                    }}
                  >
                    <SelectTrigger className="bg-card">
                      <SelectValue placeholder="Seleccionar plantilla..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— Seleccionar plantilla —</SelectItem>
                      {templates.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedTemplate && (
                  <>
                    <Button size="sm" onClick={executeReport} disabled={executing} className="gap-1">
                      {executing ? <Loader2 className="h-3 w-3 animate-spin" /> : <Play className="h-3 w-3" />}
                      Ejecutar
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => deleteTemplate(selectedTemplate.id)} className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400">
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel: Configuration */}
          <div className="lg:col-span-1 space-y-4">

            {/* Column Selector */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-semibold">Columnas a Mostrar</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                  <Tabs defaultValue="cliente" className="w-full">
                    <TabsList className="grid grid-cols-2 mb-4">
                      <TabsTrigger value="cliente">Cliente</TabsTrigger>
                      <TabsTrigger value="poliza">Póliza</TabsTrigger>
                    </TabsList>
                    <TabsList className="grid grid-cols-3 mb-4">
                      <TabsTrigger value="agente">Agente</TabsTrigger>
                      <TabsTrigger value="pagos">Pagos</TabsTrigger>
                      <TabsTrigger value="comisiones">Comis.</TabsTrigger>
                    </TabsList>

                    {Object.entries(columnSections).map(([section, cols]) => (
                      <TabsContent key={section} value={section} className="space-y-2">
                        {cols.map(col => (
                          <div key={col} className="flex items-center gap-2">
                            <Checkbox
                              checked={selectedColumns[col]}
                              onCheckedChange={(checked) => 
                                setSelectedColumns({...selectedColumns, [col]: checked})
                              }
                            />
                            <label className="text-sm">{getColumnLabel(col)}</label>
                          </div>
                        ))}
                      </TabsContent>
                    ))}
                  </Tabs>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex gap-2">
              <Button onClick={executeReport} disabled={executing} className="flex-1 gap-2">
                {executing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                Ejecutar
              </Button>
              <Button variant="outline" onClick={() => setShowSaveTemplate(true)} className="gap-2">
                <Save className="h-4 w-4" />
              </Button>
            </div>
            
            <Button 
              variant="ghost" 
              onClick={() => {
                setReportData([]);
                setFilters({
                  date_field: 'created_date',
                  date_from: '',
                  date_to: '',
                  policy_status: 'all',
                  policy_type: 'all',
                  line_id: 'all',
                  product_id: 'all',
                  company_id: 'all',
                  branch_id: 'all',
                  client_country: [],
                  policy_country: [],
                  currency: 'all',
                  payment_frequency: 'all',
                  agent_id: 'all',
                  agent_type: 'all',
                  include_structure: false,
                  is_nivel_2: 'all',
                  is_gapartner: 'all',
                  commission_status: 'all',
                  payment_status: 'all',
                  tag_include: [],
                  tag_exclude: []
                });
                setSortField(null);
                setSortOrder('asc');
              }}
              className="w-full gap-2"
            >
              <X className="h-4 w-4" />
              Limpiar Todo
            </Button>
          </div>

          {/* Right Panel: Filters & Results */}
          <div className="lg:col-span-2 space-y-4">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  Filtros Avanzados
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4">
                {/* Date Range */}
                <div className="col-span-2">
                  <Label className="text-xs">Campo de Fecha</Label>
                  <Select value={filters.date_field} onValueChange={(val) => setFilters({...filters, date_field: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="created_date">Fecha Creación</SelectItem>
                      <SelectItem value="start_date">Vigencia Desde</SelectItem>
                      <SelectItem value="end_date">Vigencia Hasta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs">Desde</Label>
                  <Input 
                    type="date" 
                    value={filters.date_from} 
                    onChange={(e) => setFilters({...filters, date_from: e.target.value})}
                  />
                </div>

                <div>
                  <Label className="text-xs">Hasta</Label>
                  <Input 
                    type="date" 
                    value={filters.date_to} 
                    onChange={(e) => setFilters({...filters, date_to: e.target.value})}
                  />
                </div>

                {/* Policy Filters */}
                <div>
                  <Label className="text-xs">Estado Póliza</Label>
                  <Select value={filters.policy_status} onValueChange={(val) => setFilters({...filters, policy_status: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="activa">Activa</SelectItem>
                      <SelectItem value="vencida">Vencida</SelectItem>
                      <SelectItem value="cancelada">Cancelada</SelectItem>
                      <SelectItem value="renovada">Renovada</SelectItem>
                      <SelectItem value="en_riesgo">En Riesgo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs">Tipo Póliza</Label>
                  <Select value={filters.policy_type} onValueChange={(val) => setFilters({...filters, policy_type: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="nuevo_negocio">Nuevo Negocio</SelectItem>
                      <SelectItem value="renovacion">Renovación</SelectItem>
                      <SelectItem value="cambio_broker">Cambio Broker</SelectItem>
                      <SelectItem value="cesion_cartera">Cesión Cartera</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="col-span-2">
                  <Label className="text-xs">Branch</Label>
                  <Select value={filters.branch_id} onValueChange={(val) => setFilters({...filters, branch_id: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      {branches.map(b => (
                        <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs">Ramo</Label>
                  <Select value={filters.line_id} onValueChange={(val) => setFilters({...filters, line_id: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      {lines.map(l => (
                        <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs">Compañía</Label>
                  <Select value={filters.company_id} onValueChange={(val) => setFilters({...filters, company_id: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      {companies.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs">País Cliente</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-between">
                        {filters.client_country.length > 0 
                          ? `${filters.client_country.length} seleccionado(s)` 
                          : "Seleccionar países"}
                        <ChevronDown className="h-4 w-4 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <div className="max-h-64 overflow-y-auto p-2 space-y-1">
                        {uniqueClientCountries.map(country => (
                          <div key={country} className="flex items-center gap-2 p-2 hover:bg-muted/40 rounded cursor-pointer"
                            onClick={() => {
                              if (filters.client_country.includes(country)) {
                                setFilters({...filters, client_country: filters.client_country.filter(c => c !== country)});
                              } else {
                                setFilters({...filters, client_country: [...filters.client_country, country]});
                              }
                            }}>
                            <Checkbox checked={filters.client_country.includes(country)} />
                            <label className="text-sm flex-1 cursor-pointer">{country}</label>
                          </div>
                        ))}
                        {uniqueClientCountries.length === 0 && (
                          <p className="text-xs text-muted-foreground/70 p-2">No hay países</p>
                        )}
                      </div>
                    </PopoverContent>
                  </Popover>
                  {filters.client_country.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {filters.client_country.map(c => (
                        <Badge key={c} variant="secondary" className="text-xs">
                          {c}
                          <button onClick={() => setFilters({...filters, client_country: filters.client_country.filter(x => x !== c)})} className="ml-1">
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-xs">País Póliza</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-between">
                        {filters.policy_country.length > 0 
                          ? `${filters.policy_country.length} seleccionado(s)` 
                          : "Seleccionar países"}
                        <ChevronDown className="h-4 w-4 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <div className="max-h-64 overflow-y-auto p-2 space-y-1">
                        {uniquePolicyCountries.map(country => (
                          <div key={country} className="flex items-center gap-2 p-2 hover:bg-muted/40 rounded cursor-pointer"
                            onClick={() => {
                              if (filters.policy_country.includes(country)) {
                                setFilters({...filters, policy_country: filters.policy_country.filter(c => c !== country)});
                              } else {
                                setFilters({...filters, policy_country: [...filters.policy_country, country]});
                              }
                            }}>
                            <Checkbox checked={filters.policy_country.includes(country)} />
                            <label className="text-sm flex-1 cursor-pointer">{country}</label>
                          </div>
                        ))}
                        {uniquePolicyCountries.length === 0 && (
                          <p className="text-xs text-muted-foreground/70 p-2">No hay países</p>
                        )}
                      </div>
                    </PopoverContent>
                  </Popover>
                  {filters.policy_country.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {filters.policy_country.map(c => (
                        <Badge key={c} variant="secondary" className="text-xs">
                          {c}
                          <button onClick={() => setFilters({...filters, policy_country: filters.policy_country.filter(x => x !== c)})} className="ml-1">
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                {/* Agent Filters */}
                <div className="col-span-2">
                  <Label className="text-xs">Agente</Label>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <div className="flex-1">
                        <AgentSelect
                          agents={[{ id: 'all', name: 'Todos los agentes' }, ...agents.filter(a => allowedAgentIds === null || allowedAgentIds.includes(a.id))]}
                          value={filters.agent_id}
                          onValueChange={(val) => setFilters({...filters, agent_id: val || 'all'})}
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={filters.include_structure}
                        onCheckedChange={(checked) => setFilters({...filters, include_structure: checked})}
                      />
                      <label className="text-xs whitespace-nowrap">Incluir Estructura Completa</label>
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-xs">Partner</Label>
                  <Select value={filters.is_nivel_2} onValueChange={(val) => setFilters({...filters, is_nivel_2: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="true">Sí</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs">GAPartner+</Label>
                  <Select value={filters.is_gapartner} onValueChange={(val) => setFilters({...filters, is_gapartner: val})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="true">Sí</SelectItem>
                      <SelectItem value="false">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="col-span-2">
                  <Label className="text-xs">Etiquetas de Póliza</Label>
                  <PolicyTagFilter
                    includeTagIds={filters.tag_include}
                    excludeTagIds={filters.tag_exclude}
                    onIncludeChange={(ids) => setFilters({...filters, tag_include: ids})}
                    onExcludeChange={(ids) => setFilters({...filters, tag_exclude: ids})}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Active Filters Summary */}
            {activeFilters.length > 0 && (
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-xs font-medium text-muted-foreground">Filtros activos:</span>
                {activeFilters.map(([key, value]) => (
                  <span key={key} className="inline-flex items-center gap-1 px-2 py-1 bg-muted text-foreground text-xs rounded-md">
                    {key}: {Array.isArray(value) ? value.join(', ') : String(value)}
                    <button onClick={() => setFilters({...filters, [key]: Array.isArray(value) ? [] : 'all'})}>
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}


          </div>
        </div>

        {/* Results Dialog */}
        <Dialog open={showResults} onOpenChange={setShowResults}>
          <DialogContent className="max-w-[95vw] w-[95vw] h-[90vh] p-0 flex flex-col">
            {/* Header fijo */}
            <DialogHeader className="flex-shrink-0 px-6 pt-6 pb-4 border-b">
              <div className="flex items-center justify-between">
                <DialogTitle>Resultados del Reporte ({sortedData.length} registros)</DialogTitle>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button size="sm" variant="outline" className="gap-2">
                      <Download className="h-4 w-4" />
                      Exportar
                      <ChevronDown className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={handleExportCSV} className="gap-2">
                      <Download className="h-4 w-4" /> Descargar CSV
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleExportExcel} className="gap-2">
                      <Download className="h-4 w-4" /> Descargar Excel
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </DialogHeader>

            {/* Contenido que se expande */}
            <div className="flex flex-col flex-1 overflow-hidden px-6 pb-4 pt-4 gap-3">
              {/* Pagination Controls */}
              <div className="flex-shrink-0 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Label className="text-sm">Registros por página:</Label>
                  <Select value={String(pageSize)} onValueChange={(val) => { setPageSize(Number(val)); setCurrentPage(0); }}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="25">25</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                      <SelectItem value="100">100</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => setCurrentPage(p => Math.max(0, p - 1))} disabled={currentPage === 0}>
                    Anterior
                  </Button>
                  <span className="text-sm text-muted-foreground px-2">
                    Página {currentPage + 1} de {Math.max(1, Math.ceil(sortedData.length / pageSize))}
                  </span>
                  <Button size="sm" variant="outline" onClick={() => setCurrentPage(p => Math.min(Math.ceil(sortedData.length / pageSize) - 1, p + 1))} disabled={currentPage >= Math.ceil(sortedData.length / pageSize) - 1}>
                    Siguiente
                  </Button>
                </div>
              </div>

              {/* Tabla - ocupa todo el espacio restante */}
              <div className="flex-1 overflow-hidden border rounded-lg">
                <div className="h-full overflow-auto">
                  <Table>
                    <TableHeader className="sticky top-0 bg-muted/40 z-10">
                      <TableRow>
                        {Object.entries(selectedColumns)
                          .filter(([_, selected]) => selected)
                          .map(([key]) => (
                            <TableHead
                              key={key}
                              className="cursor-pointer hover:bg-muted whitespace-nowrap"
                              onClick={() => handleSort(key)}
                            >
                              <div className="flex items-center gap-1">
                                {getColumnLabel(key)}
                                {sortField === key && (
                                  sortOrder === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
                                )}
                              </div>
                            </TableHead>
                          ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedData
                        .slice(currentPage * pageSize, (currentPage + 1) * pageSize)
                        .map((row, idx) => (
                          <TableRow key={idx}>
                            {Object.entries(selectedColumns)
                              .filter(([_, selected]) => selected)
                              .map(([key]) => (
                                <TableCell key={key} className="text-sm whitespace-nowrap">
                                  {typeof row[key] === 'number' && key.includes('amount')
                                    ? `$${formatMoney(row[key])}`
                                    : row[key] || '-'}
                                </TableCell>
                              ))}
                          </TableRow>
                        ))}
                      {/* Totals Row */}
                      <TableRow className="bg-muted/40 font-semibold">
                        {Object.entries(selectedColumns)
                          .filter(([_, selected]) => selected)
                          .map(([key], idx) => {
                            const totals = getTotals();
                            return (
                              <TableCell key={key} className="text-sm whitespace-nowrap">
                                {idx === 0 ? 'TOTALES' : totals[key] ? `$${formatMoney(totals[key])}` : ''}
                              </TableCell>
                            );
                          })}
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* Info inferior */}
              <div className="flex-shrink-0 text-sm text-muted-foreground text-center">
                Mostrando {Math.min(currentPage * pageSize + 1, sortedData.length)} - {Math.min((currentPage + 1) * pageSize, sortedData.length)} de {sortedData.length} registros
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Save Template Dialog */}
        <Dialog open={showSaveTemplate} onOpenChange={setShowSaveTemplate}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Guardar Plantilla</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Nombre de la Plantilla</Label>
                <Input
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder="Ej: Reporte Mensual de Producción"
                />
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowSaveTemplate(false)}>
                  Cancelar
                </Button>
                <Button onClick={saveTemplate}>
                  Guardar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}