import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import BackButton from '@/components/ui/BackButton';
import StatusBadge from '@/components/ui/StatusBadge';
import { Globe, Plus, Pencil, Trash2, Loader2 } from 'lucide-react';

export default function SettingsBranches() {
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    country: '',
    status: 'activo'
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const branchesData = await api.entities.Branch.list('-created_date');
    setBranches(branchesData);
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    if (editingItem) {
      await api.entities.Branch.update(editingItem.id, formData);
    } else {
      await api.entities.Branch.create(formData);
    }
    setSaving(false);
    setFormOpen(false);
    setEditingItem(null);
    resetForm();
    loadData();
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      name: item.name || '',
      code: item.code || '',
      country: item.country || '',
      status: item.status || 'activo'
    });
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (itemToDelete) {
      await api.entities.Branch.delete(itemToDelete.id);
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      loadData();
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      country: '',
      status: 'activo'
    });
  };

  const openNewForm = () => {
    setEditingItem(null);
    resetForm();
    setFormOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <BackButton />
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-muted">
                <Globe className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Branches</h1>
                <p className="text-sm text-muted-foreground">{branches.length} branches</p>
              </div>
            </div>
          </div>
          <Button onClick={openNewForm} className="gap-2">
            <Plus className="h-4 w-4" /> Nuevo Branch
          </Button>
        </div>

        <div className="grid gap-4">
          {branches.length === 0 ? (
            <Card className="border-0 shadow-sm p-12">
              <div className="text-center text-muted-foreground/70">
                <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No hay branches registrados</p>
                <Button onClick={openNewForm} variant="outline" className="mt-4">
                  Agregar primer branch
                </Button>
              </div>
            </Card>
          ) : (
            branches.map((branch) => (
              <Card key={branch.id} className="border-0 shadow-sm p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-foreground">{branch.name}</h3>
                      <StatusBadge status={branch.status} />
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Código: {branch.code}</span>
                      {branch.country && (
                        <>
                          <span>•</span>
                          <span>País: {branch.country}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(branch)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => { setItemToDelete(branch); setDeleteDialogOpen(true); }}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar Branch' : 'Nuevo Branch'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre *</Label>
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ej: GA ECUADOR"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Código *</Label>
                <Input 
                  value={formData.code} 
                  onChange={(e) => setFormData({...formData, code: e.target.value})}
                  placeholder="Ej: GAECUADOR"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>País</Label>
                <Input 
                  value={formData.country} 
                  onChange={(e) => setFormData({...formData, country: e.target.value})}
                  placeholder="Ej: Ecuador"
                />
              </div>
              <div className="space-y-2">
                <Label>Estado</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(v) => setFormData({...formData, status: v})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activo">Activo</SelectItem>
                    <SelectItem value="inactivo">Inactivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingItem ? 'Guardar' : 'Crear'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar branch?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará permanentemente el branch 
                {itemToDelete && ` "${itemToDelete.name}"`}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}