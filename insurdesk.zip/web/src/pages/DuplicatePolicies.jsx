import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';
import { Loader2, Copy, Trash2, ChevronDown, ChevronRight, RefreshCw, AlertTriangle, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';

export default function DuplicatePolicies() {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState({});
  // keepId per group: which copy to keep (default: oldest = first in sorted array)
  const [keepIds, setKeepIds] = useState({});
  const [confirmGroup, setConfirmGroup] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const loadDuplicates = async () => {
    setLoading(true);
    try {
      const resp = await api.functions.invoke('getDuplicatePolicies', {});
      if (resp?.data?.success) {
        setGroups(resp.data.groups || []);
        // Default: keep the oldest copy (first in each sorted group)
        const initialKeep = {};
        (resp.data.groups || []).forEach(g => {
          if (g.copies.length > 0) initialKeep[g.policy_number + '|' + g.company_id] = g.copies[0].id;
        });
        setKeepIds(initialKeep);
      } else {
        toast.error(resp?.data?.error || 'Error al cargar duplicados');
      }
    } catch (e) {
      toast.error('Error al cargar duplicados: ' + (e.message || ''));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadDuplicates(); }, []);

  const toggleGroup = (key) => setExpanded(prev => ({ ...prev, [key]: !prev[key] }));

  const handleKeepChange = (groupKey, copyId) => setKeepIds(prev => ({ ...prev, [groupKey]: copyId }));

  const handleDeleteCopies = async () => {
    if (!confirmGroup) return;
    const group = confirmGroup;
    const keepId = keepIds[group.policy_number + '|' + group.company_id];
    const copiesToDelete = group.copies.filter(c => c.id !== keepId);
    setDeleting(true);
    let ok = 0;
    let fail = 0;
    for (const copy of copiesToDelete) {
      try {
        const resp = await api.functions.invoke('deletePolicyCascade', { policyId: copy.id });
        if (resp?.data?.success) ok++;
        else { fail++; toast.error(`Error al eliminar póliza ${copy.policy_number}: ${resp?.data?.error || ''}`); }
      } catch (e) {
        fail++;
        toast.error(`Error al eliminar póliza ${copy.policy_number}: ${e.message || ''}`);
      }
    }
    setDeleting(false);
    setConfirmGroup(null);
    if (ok > 0) toast.success(`${ok} copia(s) eliminada(s) con sus registros vinculados.`);
    if (fail === 0 && ok > 0) {
      // collapse removed group
      setExpanded(prev => ({ ...prev, [group.policy_number + '|' + group.company_id]: false }));
    }
    loadDuplicates();
  };

  const totalLinks = (counts) => counts.payments + counts.commissions + counts.claims + counts.endorsements;

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-5xl mx-auto">
        <PageHeader
          title="Pólizas Duplicadas"
          subtitle="Revisa y elimina pólizas duplicadas (misma compañía + número)"
          backTo="AdminPanel"
          icon={Copy}
        />

        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-muted-foreground">
            {groups.length === 0
              ? 'No se encontraron pólizas duplicadas.'
              : `${groups.length} grupo(s) con duplicados detectados.`}
          </p>
          <Button variant="outline" size="sm" onClick={loadDuplicates} className="gap-2">
            <RefreshCw className="h-4 w-4" /> Actualizar
          </Button>
        </div>

        <div className="space-y-4">
          {groups.map((group) => {
            const groupKey = group.policy_number + '|' + group.company_id;
            const isExpanded = expanded[groupKey];
            const keepId = keepIds[groupKey];
            const copiesToDelete = group.copies.filter(c => c.id !== keepId);
            const totalLinkedToDelete = copiesToDelete.reduce((s, c) => s + totalLinks(c.counts), 0);

            return (
              <Card key={groupKey} className="border-0 shadow-sm overflow-hidden">
                <CardContent className="p-0">
                  <button
                    onClick={() => toggleGroup(groupKey)}
                    className="w-full flex items-center justify-between p-4 hover:bg-muted/40 transition-colors text-left"
                  >
                    <div className="flex items-center gap-3">
                      {isExpanded ? <ChevronDown className="h-4 w-4 text-muted-foreground/70" /> : <ChevronRight className="h-4 w-4 text-muted-foreground/70" />}
                      <div>
                        <p className="font-semibold text-foreground">{group.policy_number}</p>
                        <p className="text-xs text-muted-foreground">{group.company_name || 'Sin compañía'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-red-500/10 text-red-600 dark:text-red-400">
                        <AlertTriangle className="h-3 w-3" /> {group.copies.length} copias
                      </span>
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="border-t border-border p-4 space-y-3 bg-muted/50">
                      <p className="text-xs text-muted-foreground mb-2">
                        Selecciona la póliza que deseas <strong>conservar</strong>. Las demás se eliminarán junto con sus pagos, comisiones, siniestros y endosos vinculados.
                      </p>
                      {group.copies.map((copy) => {
                        const isKeep = keepId === copy.id;
                        return (
                          <div
                            key={copy.id}
                            className={`rounded-lg border p-3 transition-colors ${isKeep ? 'border-green-500/30 bg-green-500/10' : 'border-border bg-card'}`}
                          >
                            <div className="flex items-start gap-3">
                              <input
                                type="radio"
                                checked={isKeep}
                                onChange={() => handleKeepChange(groupKey, copy.id)}
                                className="mt-1 h-4 w-4 accent-green-600"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-medium text-foreground text-sm">
                                    {copy.client_name || copy.contractor_name || 'Sin nombre'}
                                  </span>
                                  {isKeep && (
                                    <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full bg-green-500/10 text-green-600 dark:text-green-400">
                                      <ShieldCheck className="h-3 w-3" /> Conservar
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground mt-0.5 space-y-0.5">
                                  <p>Agente: {copy.agent_name || 'N/A'} · Creada: {(copy.created_date || '').split('T')[0]}</p>
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <StatusBadge status={copy.status} />
                                    <span className="text-muted-foreground/70">·</span>
                                    <span className={totalLinks(copy.counts) > 0 ? 'text-amber-600 dark:text-amber-400 font-medium' : 'text-muted-foreground/70'}>
                                      Vínculos: {copy.counts.payments} pagos, {copy.counts.commissions} comisiones, {copy.counts.claims} siniestros, {copy.counts.endorsements} endosos
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      <div className="flex items-center justify-between pt-2">
                        <p className="text-xs text-amber-600 dark:text-amber-400">
                          Se eliminarán <strong>{copiesToDelete.length}</strong> copia(s) · {totalLinkedToDelete} registro(s) vinculados en total.
                        </p>
                        <Button
                          variant="destructive"
                          size="sm"
                          className="gap-2"
                          disabled={copiesToDelete.length === 0}
                          onClick={() => setConfirmGroup(group)}
                        >
                          <Trash2 className="h-4 w-4" /> Eliminar duplicadas
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={!!confirmGroup} onOpenChange={(o) => !o && setConfirmGroup(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" /> Confirmar eliminación
            </DialogTitle>
          </DialogHeader>
          {confirmGroup && (() => {
            const keepId = keepIds[confirmGroup.policy_number + '|' + confirmGroup.company_id];
            const copiesToDelete = confirmGroup.copies.filter(c => c.id !== keepId);
            return (
              <div className="space-y-3">
                <p className="text-sm text-foreground/80">
                  Vas a eliminar <strong>{copiesToDelete.length}</strong> póliza(s) duplicada(s) de <strong>{confirmGroup.policy_number}</strong> ({confirmGroup.company_name}) y todos sus registros vinculados:
                </p>
                <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 space-y-1.5">
                  {copiesToDelete.map((c) => (
                    <div key={c.id} className="text-xs text-red-600 dark:text-red-400">
                      • {c.client_name || c.contractor_name || 'Sin nombre'} — {c.counts.payments} pagos, {c.counts.commissions} comisiones, {c.counts.claims} siniestros, {c.counts.endorsements} endosos
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">Esta acción no se puede deshacer.</p>
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmGroup(null)} disabled={deleting}>Cancelar</Button>
            <Button variant="destructive" onClick={handleDeleteCopies} disabled={deleting} className="gap-2">
              {deleting && <Loader2 className="h-4 w-4 animate-spin" />}
              Eliminar definitivamente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}