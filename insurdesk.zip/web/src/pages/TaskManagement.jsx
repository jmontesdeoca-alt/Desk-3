import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import TaskForm from '@/components/forms/TaskForm';
import TaskKanbanBoard from '@/components/tasks/TaskKanbanBoard';
import TaskEfficiencyDashboard from '@/components/tasks/TaskEfficiencyDashboard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, CheckCircle2, Clock, AlertTriangle, FileText, Users, Loader2, LayoutGrid, List, BarChart3 } from 'lucide-react';
import { format, isPast, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import TaskDetailModal from '@/components/tasks/TaskDetailModal';

export default function TaskManagement() {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  // Filters
  const [filterUser, setFilterUser] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [filterOverdue, setFilterOverdue] = useState('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const userData = await api.auth.me();
      setCurrentUser(userData);

      const isAdmin = userData.role === 'admin' || userData.app_role === 'admin';

      const [tasksData, usersResponse] = await Promise.all([
        isAdmin
          ? api.entities.Task.list('-created_date', 500)
          : api.entities.Task.filter({ created_by_user_id: userData.id }, '-created_date', 500),
        api.functions.invoke('listAllUsers', {})
      ]);

      setTasks(tasksData);
      setUsers(usersResponse.data?.users || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (taskId, newStatus) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    setUpdatingId(taskId);
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
    try {
      const updateData = { status: newStatus };
      if (newStatus === 'finalizado') {
        updateData.completed_at = new Date().toISOString();
      }
      if (newStatus === 'en_proceso' && !task.started_at) {
        updateData.started_at = new Date().toISOString();
      }
      await api.entities.Task.update(taskId, updateData);
    } catch (error) {
      console.error('Error updating task status:', error);
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: task.status } : t));
      alert('Error al actualizar el estado de la tarea');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleComplete = async (task) => {
    await handleStatusChange(task.id, 'finalizado');
  };

  const handleDelete = async (task) => {
    if (!confirm('¿Eliminar esta tarea? Esta acción no se puede deshacer.')) return;

    try {
      await api.entities.Task.delete(task.id);
      loadData();
    } catch (error) {
      console.error('Error deleting task:', error);
      alert('Error al eliminar la tarea');
    }
  };

  const getPriorityBadge = (priority) => {
    const styles = {
      alta: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30',
      media: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
      baja: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
    };
    const labels = { alta: '🔴 Alta', media: '🟡 Media', baja: '🟢 Baja' };
    
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium border ${styles[priority]}`}>
        {labels[priority]}
      </span>
    );
  };

  const getRelatedLink = (task) => {
    if (task.related_type === 'cliente' && task.related_client_id) {
      return (
        <Link to={createPageUrl(`ClientDetail?id=${task.related_client_id}`)} className="text-foreground hover:underline flex items-center gap-1">
          <Users className="h-3 w-3" />
          {task.related_client_name}
        </Link>
      );
    }
    if (task.related_type === 'poliza' && task.related_policy_id) {
      return (
        <Link to={createPageUrl(`PolicyDetail?id=${task.related_policy_id}`)} className="text-foreground hover:underline flex items-center gap-1">
          <FileText className="h-3 w-3" />
          {task.related_policy_number}
        </Link>
      );
    }
    return <span className="text-muted-foreground/70 text-xs">Sin relación</span>;
  };

  const getTimeRemaining = (dueDate) => {
    if (!dueDate) return '';
    const due = parseISO(dueDate);
    return isPast(due) ? '⚠️ Vencida' : '';
  };

  // Apply filters
  let filteredTasks = [...tasks];

  if (filterUser !== 'all') {
    filteredTasks = filteredTasks.filter(t => t.assigned_to_user_id === filterUser);
  }

  if (filterStatus !== 'all') {
    filteredTasks = filteredTasks.filter(t => t.status === filterStatus);
  }

  if (filterPriority !== 'all') {
    filteredTasks = filteredTasks.filter(t => t.priority === filterPriority);
  }

  if (filterOverdue === 'overdue') {
    filteredTasks = filteredTasks.filter(t => (t.status === 'pendiente' || t.status === 'en_proceso') && isPast(parseISO(t.due_date)));
  } else if (filterOverdue === 'upcoming') {
    filteredTasks = filteredTasks.filter(t => (t.status === 'pendiente' || t.status === 'en_proceso') && !isPast(parseISO(t.due_date)));
  }

  const columns = [
    {
      header: 'Tarea',
      accessorKey: 'title',
      cell: (task) => (
        <div>
          <div className={`font-medium ${task.status === 'completada' || task.status === 'finalizado' ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
            {task.title}
          </div>
          {task.description && (
            <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{task.description}</div>
          )}
        </div>
      )
    },
    {
      header: 'Asignado a',
      accessorKey: 'assigned_to_user_name',
      cell: (task) => <span className="text-sm">{task.assigned_to_user_name}</span>
    },
    {
      header: 'Prioridad',
      accessorKey: 'priority',
      cell: (task) => getPriorityBadge(task.priority)
    },
    {
      header: 'Estado',
      accessorKey: 'status',
      cell: (task) => (
        <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium border ${
          task.status === 'completada' || task.status === 'finalizado'
            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
            : task.status === 'en_proceso'
            ? 'bg-muted text-foreground border-border'
            : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
        }`}>
          {task.status === 'completada' || task.status === 'finalizado' ? 'Finalizada' : task.status === 'en_proceso' ? 'En Proceso' : 'Pendiente'}
        </span>
      )
    },
    {
      header: 'Fecha límite',
      accessorKey: 'due_date',
      cell: (task) => (
        <div>
          <div className="text-sm text-foreground/80">
            {format(parseISO(task.due_date), 'dd/MM/yyyy', { locale: es })}
          </div>
          {(task.status === 'pendiente' || task.status === 'en_proceso') && (
            <div className="text-xs text-red-600 dark:text-red-400 font-semibold mt-1">
              {getTimeRemaining(task.due_date)}
            </div>
          )}
        </div>
      )
    },
    {
      header: 'Relacionado',
      cell: (task) => getRelatedLink(task)
    },
    {
      header: 'Acciones',
      cell: (task) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setEditingTask(task);
              setShowForm(true);
            }}
          >
            Editar
          </Button>
          {(task.status === 'pendiente' || task.status === 'en_proceso') && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleComplete(task)}
              className="gap-1"
            >
              <CheckCircle2 className="h-3 w-3" />
              Finalizar
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleDelete(task)}
            className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400"
          >
            Eliminar
          </Button>
        </div>
      )
    }
  ];

  const handleExport = () => {
    const csvData = filteredTasks.map(t => ({
      Tarea: t.title,
      Descripción: t.description || '',
      'Asignado a': t.assigned_to_user_name,
      Prioridad: t.priority,
      Estado: t.status,
      'Fecha límite': t.due_date,
      'Creado por': t.created_by_user_name,
      Relacionado: t.related_type === 'cliente' ? t.related_client_name : t.related_type === 'poliza' ? t.related_policy_number : 'Ninguno'
    }));

    const headers = Object.keys(csvData[0] || {});
    const csv = [
      headers.join(','),
      ...csvData.map(row => headers.map(h => `"${row[h] || ''}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tareas_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const pendingCount = tasks.filter(t => t.status === 'pendiente').length;
  const overdueCount = tasks.filter(t => (t.status === 'pendiente' || t.status === 'en_proceso') && isPast(parseISO(t.due_date))).length;
  const completedCount = tasks.filter(t => t.status === 'completada' || t.status === 'finalizado').length;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Gestión de Tareas"
          subtitle="Control total de tareas del sistema"
          backTo="MyTasks"
          actions={
            <Button onClick={() => { setEditingTask(null); setShowForm(true); }} className="gap-2">
              <Plus className="h-4 w-4" />
              Nueva Tarea
            </Button>
          }
        />

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pendientes</p>
                <p className="text-2xl font-bold text-foreground">{pendingCount}</p>
              </div>
              <Clock className="h-8 w-8 text-foreground" />
            </div>
          </div>

          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Vencidas</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">{overdueCount}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-400" />
            </div>
          </div>

          <div className="bg-card rounded-xl border border-border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Finalizadas</p>
                <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{completedCount}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-card rounded-xl border border-border p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Usuario</label>
              <Select value={filterUser} onValueChange={setFilterUser}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {users.map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Estado</label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="pendiente">Pendiente</SelectItem>
                  <SelectItem value="en_proceso">En Proceso</SelectItem>
                  <SelectItem value="finalizado">Finalizado</SelectItem>
                  <SelectItem value="completada">Completada (histórico)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Prioridad</label>
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="alta">🔴 Alta</SelectItem>
                  <SelectItem value="media">🟡 Media</SelectItem>
                  <SelectItem value="baja">🟢 Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Vencimiento</label>
              <Select value={filterOverdue} onValueChange={setFilterOverdue}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="overdue">Vencidas</SelectItem>
                  <SelectItem value="upcoming">Por vencer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {updatingId && (
          <div className="flex items-center gap-2 text-sm text-foreground mb-3">
            <Loader2 className="h-4 w-4 animate-spin" />
            Actualizando estado...
          </div>
        )}

        <Tabs defaultValue="board" className="space-y-4">
          <TabsList>
            <TabsTrigger value="board">
              <LayoutGrid className="h-4 w-4 mr-2" />
              Tablero
            </TabsTrigger>
            <TabsTrigger value="list">
              <List className="h-4 w-4 mr-2" />
              Lista
            </TabsTrigger>
            <TabsTrigger value="efficiency">
              <BarChart3 className="h-4 w-4 mr-2" />
              Cumplimiento
            </TabsTrigger>
          </TabsList>

          <TabsContent value="board">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground/70" />
              </div>
            ) : filteredTasks.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground/70">
                No hay tareas que mostrar con los filtros actuales
              </div>
            ) : (
              <TaskKanbanBoard
                tasks={filteredTasks}
                onTaskClick={setSelectedTask}
                onStatusChange={handleStatusChange}
              />
            )}
          </TabsContent>

          <TabsContent value="list">
            <DataTable
              columns={columns}
              data={filteredTasks}
              searchable={true}
              searchPlaceholder="Buscar tareas..."
              exportable={true}
              onExport={handleExport}
              emptyMessage="No hay tareas que mostrar"
            />
          </TabsContent>

          <TabsContent value="efficiency">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground/70" />
              </div>
            ) : (
              <TaskEfficiencyDashboard tasks={tasks} users={users} />
            )}
          </TabsContent>
        </Tabs>

        <TaskForm
          open={showForm}
          onClose={() => {
            setShowForm(false);
            setEditingTask(null);
          }}
          onSuccess={loadData}
          task={editingTask}
        />

        <TaskDetailModal
          task={selectedTask}
          open={!!selectedTask}
          onClose={() => setSelectedTask(null)}
          onComplete={handleComplete}
          onTaskUpdated={(updated) => setTasks(prev => prev.map(t => t.id === updated.id ? { ...t, ...updated } : t))}
        />
      </div>
    </div>
  );
}