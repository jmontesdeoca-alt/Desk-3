import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { api } from '@/api/client';
import { useFeatures } from '@/lib/FeatureContext';
import { Card, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import PageHeader from '@/components/ui/PageHeader';
import { 
  BarChart3, Download, TrendingUp, DollarSign, FileText, 
  Loader2, Filter, Settings, ChevronDown, ChevronUp, GripVertical, Minimize2, Maximize2, Check
} from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import SalesByCountryList from '@/components/reports/SalesByCountryList';
import YearToDateWidget from '@/components/reports/YearToDateWidget';
import AgentDetailRow from '@/components/reports/AgentDetailRow';
import AgencyDetailRow from '@/components/reports/AgencyDetailRow';
import PolicyTagFilter from '@/components/policy/PolicyTagFilter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTranslation } from 'react-i18next';
import '@/components/i18n';
import { loadTRMsForPolicies, convertToUSD } from '@/lib/currencyConversion';
import { formatMoney, round2 } from '@/lib/formatMoney';

// Resizable widget wrapper (horizontal - changes column span)
function ResizableWidget({ widget, children, onSpanChange }) {
  const spans = [1, 2, 3];
  const currentSpan = widget.span || 1;

  return (
    <div className="flex flex-col relative h-full">
      <div className="flex-1">
        {children}
      </div>
      <div className="flex items-center justify-center gap-2 py-2 bg-muted/40 border-t">
        <span className="text-xs text-muted-foreground/70">Ancho:</span>
        {spans.map(s => (
          <button
            key={s}
            onClick={() => onSpanChange(widget.id, s)}
            className={`px-2 py-0.5 rounded text-xs font-medium transition-colors ${
              currentSpan === s
                ? 'bg-primary text-white'
                : 'bg-secondary text-muted-foreground hover:bg-muted-foreground/30'
            }`}
          >
            {s === 1 ? '1/3' : s === 2 ? '2/3' : 'Completo'}
          </button>
        ))}
      </div>
    </div>
  );
}

// Generic multi-select filter component - Excel style (all checked by default)
// selected=[] means ALL selected; selected=[...ids] means only those are EXCLUDED (inverted: we store exclusions)
// Actually we store EXCLUDED ids: if excluded is empty => show all; toggle adds/removes from excluded list
function MultiSelectFilter({ options, selected, onChange, allLabel = 'Todos', labelKey = 'name', valueKey = 'id', searchable = false, searchPlaceholder = 'Buscar...', secondaryLabelKey = null }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef(null);

  useEffect(() => {
    const handleClick = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const allChecked = selected.length === 0;
  const isChecked = (val) => allChecked || selected.includes(val);

  const toggleItem = (val) => {
    if (allChecked) {
      onChange(options.map(o => o[valueKey]).filter(v => v !== val));
    } else {
      const updated = selected.includes(val)
        ? selected.filter(v => v !== val)
        : [...selected, val];
      onChange(updated.length === options.length ? [] : updated);
    }
  };

  const toggleAll = () => {
    if (allChecked) {
      onChange(['__none__']);
    } else {
      onChange([]);
    }
  };

  const noneSelected = selected.length === 1 && selected[0] === '__none__';

  const filteredOptions = searchable && search
    ? options.filter(o => {
        const q = search.toLowerCase();
        return (o[labelKey] || '').toLowerCase().includes(q) || (secondaryLabelKey && (o[secondaryLabelKey] || '').toLowerCase().includes(q));
      })
    : options;

  const label = noneSelected
    ? 'Ninguno'
    : allChecked
      ? allLabel
      : selected.length === options.length
        ? allLabel
        : selected.length === 1
          ? options.find(o => o[valueKey] === selected[0])?.[labelKey] || '1 seleccionado'
          : `${selected.length} de ${options.length}`;

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => { setOpen(!open); setSearch(''); }}
        className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
      >
        <span className="truncate">{label}</span>
        <ChevronDown className="h-4 w-4 opacity-50 shrink-0 ml-2" />
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-card shadow-lg max-h-64 overflow-auto">
          <div className="sticky top-0 bg-card border-b px-3 py-2 z-10">
            <button
              type="button"
              onClick={toggleAll}
              className="text-xs font-semibold text-foreground hover:text-foreground transition-colors"
            >
              {allChecked || (!noneSelected && selected.length === options.length) ? 'Desmarcar todos' : 'Marcar todos'}
            </button>
          </div>
          {searchable && (
            <div className="sticky top-[37px] bg-card border-b px-2 py-2 z-10">
              <input
                className="w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-1 focus:ring-ring"
                placeholder={searchPlaceholder}
                value={search}
                onChange={e => setSearch(e.target.value)}
                onClick={e => e.stopPropagation()}
              />
            </div>
          )}
          {filteredOptions.map(o => {
            const val = o[valueKey];
            const checked = !noneSelected && isChecked(val);
            return (
              <div
                key={val}
                className="flex items-center gap-2 px-3 py-2 hover:bg-muted/40 cursor-pointer text-sm"
                onClick={() => {
                  if (noneSelected) {
                    onChange([val]);
                  } else {
                    toggleItem(val);
                  }
                }}
              >
                <div className={`h-4 w-4 rounded border flex items-center justify-center transition-colors ${checked ? 'bg-primary border-primary' : 'border-input bg-card'}`}>
                  {checked && <Check className="h-3 w-3 text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <span>{o[labelKey]}</span>
                  {secondaryLabelKey && o[secondaryLabelKey] && (
                    <span className="text-muted-foreground/70 ml-1 text-xs">({o[secondaryLabelKey]})</span>
                  )}
                </div>
              </div>
            );
          })}
          {filteredOptions.length === 0 && (
            <div className="px-3 py-2 text-sm text-muted-foreground/70 text-center">Sin resultados</div>
          )}
        </div>
      )}
    </div>
  );
}

// Keep backward-compatible alias
function MultiSelectCompany({ companies, selectedCompanies, onChange }) {
  return (
    <MultiSelectFilter
      options={companies}
      selected={selectedCompanies}
      onChange={onChange}
      allLabel="Todas"
    />
  );
}

const STATUS_OPTIONS = [
  { id: 'activa', name: 'Activas' },
  { id: 'vencida', name: 'Vencidas' },
  { id: 'cancelada', name: 'Canceladas' },
  { id: 'renovada', name: 'Renovadas' },
  { id: 'en_riesgo', name: 'En Riesgo' },
];

const POLICY_TYPE_OPTIONS = [
  { id: 'nuevo_negocio', name: 'Nuevo Negocio' },
  { id: 'renovacion', name: 'Renovación' },
  { id: 'cambio_broker', name: 'Cambio de Broker' },
  { id: 'cesion_cartera', name: 'Cesión de Cartera' },
  { id: 'otro', name: 'Otro' },
];

const AGENT_LEVEL_OPTIONS = [
  { id: 'nivel2', name: 'Partner' },
  { id: 'gapartner', name: 'GAPartner+' },
];

export default function Reports() {
  const { has } = useFeatures();
  const { t } = useTranslation();
  const [policies, setPolicies] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [agents, setAgents] = useState([]);
  const [clients, setClients] = useState([]);
  const [dependents, setDependents] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);

  const [dateFrom, setDateFrom] = useState(format(startOfYear(new Date()), 'yyyy-MM-dd'));
  const [dateTo, setDateTo] = useState(format(endOfMonth(new Date()), 'yyyy-MM-dd'));
  const [selectedCompanies, setSelectedCompanies] = useState([]); // [] = all, array of ids = multi
  const [selectedAgents, setSelectedAgents] = useState([]);
  const [includeStructure, setIncludeStructure] = useState(false);
  const [productionMode, setProductionMode] = useState(false);
  const [selectedStatuses, setSelectedStatuses] = useState([]);
  const [selectedPolicyTypes, setSelectedPolicyTypes] = useState([]);
  const [selectedBranches, setSelectedBranches] = useState([]);
  const [selectedAgentLevels, setSelectedAgentLevels] = useState([]);
  const [selectedCountries, setSelectedCountries] = useState([]);
  const [lines, setLines] = useState([]);
  const [selectedLines, setSelectedLines] = useState([]);
  const [tagFilterInclude, setTagFilterInclude] = useState([]);
  const [tagFilterExclude, setTagFilterExclude] = useState([]);
  const [paidPolicyIds, setPaidPolicyIds] = useState(new Set());
  const [filtersOpen, setFiltersOpen] = useState(true);
  const [allowedAgentIds, setAllowedAgentIds] = useState(null); // null = all agents visible (admin/gerencial)
  const [trmMap, setTrmMap] = useState(new Map());

  const defaultWidgets = [
    { id: 'map', title: 'Distribución Mundial de Ventas', component: 'map', collapsed: false, span: 3 },
    { id: 'ytd', title: 'Year to Date (YTD)', component: 'ytd', collapsed: false, span: 1 },
    { id: 'yearProduction', title: 'Producción por Año', component: 'yearProduction', collapsed: false, span: 1 },
    { id: 'monthlyTrend', title: 'Tendencia Mensual', component: 'monthlyTrend', collapsed: false, span: 1 },
    { id: 'company', title: 'Ventas por Compañía', component: 'company', collapsed: false, span: 1 },
    { id: 'agent', title: 'Ventas por Agente', component: 'agent', collapsed: false, span: 1 },
    { id: 'line', title: 'Distribución por Ramo', component: 'line', collapsed: false, span: 1 },
  ];

  const [widgets, setWidgets] = useState(() => {
    try {
      const saved = localStorage.getItem('reportWidgets_v4');
      if (!saved) return defaultWidgets;
      const savedWidgets = JSON.parse(saved);
      // Merge: keep user's order/span/collapsed, but use current default title/component
      const byId = {};
      defaultWidgets.forEach(w => { byId[w.id] = w; });
      const merged = savedWidgets
        .map(w => byId[w.id] ? { ...byId[w.id], span: w.span, collapsed: w.collapsed } : w)
        .filter(w => byId[w.id]);
      // Append any new default widgets not present in saved layout
      defaultWidgets.forEach(w => { if (!merged.find(m => m.id === w.id)) merged.push(w); });
      return merged;
    } catch {
      return defaultWidgets;
    }
  });

  useEffect(() => {
    localStorage.setItem('reportWidgets_v4', JSON.stringify(widgets));
  }, [widgets]);

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(widgets);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    setWidgets(items);
  };

  const toggleCollapse = (widgetId) => {
    setWidgets(widgets.map(w => w.id === widgetId ? { ...w, collapsed: !w.collapsed } : w));
  };

  const updateWidgetSpan = (widgetId, span) => {
    setWidgets(prev => prev.map(w => w.id === widgetId ? { ...w, span } : w));
  };

  const resetLayout = () => {
    setWidgets(defaultWidgets);
    localStorage.removeItem('reportWidgets_v4');
  };

  // Build agent structure IDs for filtering
  const getAgentIds = (agentIdList) => {
    if (!agentIdList || agentIdList.length === 0) return null;
    if (!includeStructure) return agentIdList;
    const ids = [...agentIdList];
    const findDownline = (id) => {
      agents.filter(a => a.upline_agent_id === id).forEach(a => {
        if (!ids.includes(a.id)) {
          ids.push(a.id);
          findDownline(a.id);
        }
      });
    };
    agentIdList.forEach(id => findDownline(id));
    return ids;
  };

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const currentUser = await api.auth.me();
    const userRole = currentUser?.data?.app_role || currentUser?.app_role;
    const userAgentId = currentUser?.data?.agent_id || currentUser?.agent_id;

    const isAgente = (userRole === 'agente' || userRole === 'gerencial') && userAgentId;

    // Policies via paginated backend; paid policy IDs via lightweight backend;
    // other entities via SDK (under 5000 for now)
    const policiesPromise = isAgente
      ? api.functions.invoke('getAgentHierarchy', { agentId: userAgentId, includePolicies: true })
      : api.functions.invoke('getAllPolicies');
    const paidPolicyIdsPromise = api.functions.invoke('getPaidPolicyIds');

    const [policiesResponse, paidPolicyIdsResponse, companiesData, agentsData, clientsData, dependentsData, branchesData, linesData] = await Promise.all([
      policiesPromise,
      paidPolicyIdsPromise,
      api.entities.InsuranceCompany.list(),
      api.entities.Agent.list(),
      api.entities.Client.list(),
      api.entities.Dependent.list(),
      api.entities.Branch.list(),
      api.entities.InsuranceLine.list()
    ]);

    let policiesData;
    let structureIds = null;

    if (isAgente) {
      structureIds = policiesResponse?.data?.agentIds || [userAgentId];
      policiesData = policiesResponse?.data?.policies || [];
      setAllowedAgentIds(structureIds);
    } else {
      policiesData = policiesResponse?.data?.policies || [];
      setAllowedAgentIds(null);
    }

    setPolicies(policiesData);
    setCompanies(companiesData.sort((a, b) => a.name.localeCompare(b.name)));
    setAgents(agentsData.sort((a, b) => a.name.localeCompare(b.name)));
    setClients(clientsData);
    setDependents(dependentsData);
    setPaidPolicyIds(new Set(paidPolicyIdsResponse?.data?.paidPolicyIds || []));
    setLines(linesData.sort((a, b) => a.name.localeCompare(b.name)));
    setBranches(branchesData.sort((a, b) => a.name.localeCompare(b.name)));
    setLoading(false);

    // Cargar TRMs para conversión COP → USD (en paralelo, no bloquea render)
    loadTRMsForPolicies(policiesData).then(setTrmMap).catch(err => console.error('Error loading TRMs:', err));
  };

  const isPolicyPaid = (policyId) => {
    return paidPolicyIds.has(policyId);
  };

  // Build lookup Maps for O(1) access inside filter loops
  const companyMap = useMemo(() => new Map(companies.map(c => [c.id, c])), [companies]);
  const agentMap = useMemo(() => new Map(agents.map(a => [a.id, a])), [agents]);

  // MAIN filter - applied to ALL widgets
  const agentIds = useMemo(() => getAgentIds(selectedAgents), [selectedAgents, agents, includeStructure]);
  const fromParsed = useMemo(() => parseISO(dateFrom), [dateFrom]);
  const toParsed = useMemo(() => parseISO(dateTo), [dateTo]);
  const paidPolicyIdSet = paidPolicyIds;

  // Shared filter predicate — used by all three filtered policy lists
  const matchesFilters = useCallback((p, { includeDate = true, excludeCountry = false } = {}) => {
    if (includeDate) {
      const policyDate = parseISO(p.start_date);
      if (policyDate < fromParsed || policyDate > toParsed) return false;
    }
    if (selectedCompanies.length !== 0 && !selectedCompanies.includes(p.company_id)) return false;
    if (agentIds !== null && !agentIds.includes(p.agent_id)) return false;
    if (selectedBranches.length !== 0) {
      const company = companyMap.get(p.company_id);
      if (!selectedBranches.includes(company?.branch_id)) return false;
    }
    if (selectedAgentLevels.length !== 0) {
      const agent = agentMap.get(p.agent_id);
      if (agent) {
        const matchesNivel2 = selectedAgentLevels.includes('nivel2') && agent.is_nivel_2 === true;
        const matchesGapartner = selectedAgentLevels.includes('gapartner') && agent.is_gapartner === true;
        if (!matchesNivel2 && !matchesGapartner) return false;
      } else return false;
    }
    if (productionMode) {
      if (!(p.policy_type === 'nuevo_negocio' && p.status === 'activa' && paidPolicyIdSet.has(p.id))) return false;
    } else if (selectedStatuses.length !== 0) {
      if (!selectedStatuses.includes(p.status)) return false;
    }
    if (selectedPolicyTypes.length !== 0 && !selectedPolicyTypes.includes(p.policy_type)) return false;
    if (!excludeCountry && selectedCountries.length !== 0 && selectedCountries[0] !== '__none__' && !selectedCountries.includes(p.country || '')) return false;
    if (selectedLines.length !== 0 && !selectedLines.includes(p.line_id)) return false;
    const policyTagIds = p.tags || [];
    if (tagFilterInclude.length > 0 && !tagFilterInclude.some(id => policyTagIds.some(t => t.id === id))) return false;
    if (tagFilterExclude.length > 0 && tagFilterExclude.some(id => policyTagIds.some(t => t.id === id))) return false;
    return true;
  }, [fromParsed, toParsed, selectedCompanies, agentIds, selectedBranches, companyMap, selectedAgentLevels, agentMap, productionMode, selectedStatuses, paidPolicyIdSet, selectedPolicyTypes, selectedCountries, selectedLines, tagFilterInclude, tagFilterExclude]);

  const filteredPolicies = useMemo(() => policies.filter(p => matchesFilters(p, { includeDate: true })), [policies, matchesFilters]);

  // For yearProduction and monthlyTrend: use ALL policies (no date range) but respect all other filters
  const noDateFilteredPolicies = useMemo(() => policies.filter(p => matchesFilters(p, { includeDate: false })), [policies, matchesFilters]);

  // Dynamic countries: derived from policies that match all OTHER filters (excluding country filter itself)
  const policiesForCountryOptions = useMemo(() => policies.filter(p => matchesFilters(p, { includeDate: true, excludeCountry: true })), [policies, matchesFilters]);

  const availableCountries = useMemo(() =>
    [...new Set(policiesForCountryOptions.map(p => p.country).filter(Boolean))].sort().map(c => ({ id: c, name: c })),
    [policiesForCountryOptions]);

  const totalPremiums = useMemo(() => filteredPolicies.reduce((sum, p) =>
    sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0), [filteredPolicies, trmMap]);
  const totalPolicies = filteredPolicies.length;
  const avgPremium = totalPolicies > 0 ? totalPremiums / totalPolicies : 0;

  const companyChartData = useMemo(() => {
    const salesByCompany = filteredPolicies.reduce((acc, p) => {
      const company = p.company_name || 'Sin compañía';
      if (!acc[company]) acc[company] = 0;
      acc[company] += convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap);
      return acc;
    }, {});
    return Object.entries(salesByCompany).map(([name, value]) => ({ name, value: Math.round(value) })).sort((a, b) => b.value - a.value);
  }, [filteredPolicies, trmMap]);

  const agentChartData = useMemo(() => {
    const salesByAgent = filteredPolicies.reduce((acc, p) => {
      const agentId = p.agent_id || 'sin_agente';
      const agentName = p.agent_name || 'Sin agente';
      const company = p.company_name || 'Sin compañía';
      const usdAmount = convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap);
      if (!acc[agentId]) acc[agentId] = { name: agentName, total: 0, count: 0, companies: {} };
      acc[agentId].total += usdAmount;
      acc[agentId].count += 1;
      if (!acc[agentId].companies[company]) acc[agentId].companies[company] = { value: 0, count: 0 };
      acc[agentId].companies[company].value += usdAmount;
      acc[agentId].companies[company].count += 1;
      return acc;
    }, {});
    return Object.entries(salesByAgent).map(([agentId, data]) => ({
      name: data.name,
      agentId,
      total: Math.round(data.total),
      count: data.count,
      byCompany: Object.entries(data.companies)
        .map(([cname, cd]) => ({ name: cname, value: Math.round(cd.value), count: cd.count }))
        .sort((a, b) => b.value - a.value)
    })).sort((a, b) => b.total - a.total);
  }, [filteredPolicies, trmMap]);

  const lineChartData = useMemo(() => {
    const salesByLine = filteredPolicies.reduce((acc, p) => {
      const line = p.line_name || 'Sin ramo';
      if (!acc[line]) acc[line] = 0;
      acc[line] += convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap);
      return acc;
    }, {});
    return Object.entries(salesByLine).map(([name, value]) => ({ name, value: Math.round(value) }));
  }, [filteredPolicies, trmMap]);

  // Year production - respects all filters EXCEPT date range
  const yearChartData = useMemo(() => {
    const productionByYear = noDateFilteredPolicies.reduce((acc, p) => {
      const issueYear = p.issue_date ? new Date(p.issue_date).getFullYear() : new Date(p.start_date).getFullYear();
      if (!acc[issueYear]) acc[issueYear] = { year: issueYear, premium: 0 };
      acc[issueYear].premium += convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap);
      return acc;
    }, {});
    return Object.values(productionByYear).map(y => ({ year: String(y.year), prima: Math.round(y.premium) })).sort((a, b) => parseInt(a.year) - parseInt(b.year));
  }, [noDateFilteredPolicies, trmMap]);

  // Monthly trend - current year, respects all filters EXCEPT date range
  const currentYear = new Date().getFullYear();
  const monthChartData = useMemo(() => {
    const monthlyTrendData = {};
    for (let i = 0; i < 12; i++) {
      monthlyTrendData[format(new Date(currentYear, i, 1), 'MMM', { locale: es })] = 0;
    }
    const monthlyBase = noDateFilteredPolicies.filter(p => {
      const issueYear = p.issue_date ? new Date(p.issue_date).getFullYear() : new Date(p.start_date).getFullYear();
      const isNewBusiness = selectedPolicyTypes.length === 0 ? p.policy_type === 'nuevo_negocio' : true;
      return issueYear === currentYear && isNewBusiness;
    });
    monthlyBase.forEach(p => {
      const issueDate = p.issue_date ? parseISO(p.issue_date) : parseISO(p.start_date);
      const monthName = format(issueDate, 'MMM', { locale: es });
      monthlyTrendData[monthName] += convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap);
    });
    return Object.entries(monthlyTrendData).map(([month, value]) => ({ month, value: Math.round(value) }));
  }, [noDateFilteredPolicies, selectedPolicyTypes, currentYear, trmMap]);

  const setThisMonth = () => {
    setDateFrom(format(startOfMonth(new Date()), 'yyyy-MM-dd'));
    setDateTo(format(endOfMonth(new Date()), 'yyyy-MM-dd'));
  };
  const setThisYear = () => {
    setDateFrom(format(startOfYear(new Date()), 'yyyy-MM-dd'));
    setDateTo(format(endOfYear(new Date()), 'yyyy-MM-dd'));
  };

  const exportToCSV = () => {
    const headers = ['Número Póliza', 'Cliente', 'Producto', 'Compañía', 'Agente', 'Prima Anual', 'Moneda', 'TRM Usada', 'Prima USD', 'Fecha Inicio', 'Estado', 'Tipo', 'Pagada'];
    const rows = filteredPolicies.map(p => {
      const trm = p.currency === 'COP' ? (trmMap.get(p.issue_date) || '') : '';
      const usd = p.currency === 'COP' && trmMap.has(p.issue_date)
        ? convertToUSD(p.annual_premium, p.currency, p.issue_date, trmMap)
        : (p.currency === 'USD' ? p.annual_premium : '');
      return [
        p.policy_number, p.client_name, p.product_name, p.company_name, p.agent_name,
        round2(p.annual_premium), p.currency,
        trm !== '' ? formatMoney(trm) : '',
        usd !== '' ? (typeof usd === 'number' ? formatMoney(usd) : usd) : '',
        p.start_date, p.status, p.policy_type, isPolicyPaid(p.id) ? 'Sí' : 'No'
      ];
    });
    const csvContent = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `reporte_ventas_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();
  };

  const COLORS = ['#4f7ee0', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316', '#84cc16', '#6366f1', '#14b8a6', '#e11d48', '#a855f7', '#0ea5e9', '#d97706', '#16a34a', '#dc2626', '#7c3aed', '#db2777', '#0891b2'];

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      {loading && (
        <div className="fixed inset-0 bg-white/70 z-50 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-foreground" />
        </div>
      )}
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title={t('reports.title')}
          subtitle={t('reports.generate')}
          icon={BarChart3}
          backTo="Dashboard"
          actions={
            has('custom_reports') ? (
              <Link to={createPageUrl('CustomReports')}>
                <Button variant="outline" className="gap-2">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline">Reportes Personalizados</span>
                </Button>
              </Link>
            ) : null
          }
        />

        <div className="mt-6 space-y-6">
          {/* Filters */}
          <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen}>
            <Card className="border-0 shadow-sm p-6">
              <CollapsibleTrigger className="w-full">
                <h3 className="font-semibold mb-4 flex items-center justify-between gap-2 cursor-pointer hover:text-foreground transition-colors">
                  <span className="flex items-center gap-2">
                    <Filter className="h-5 w-5" />
                    {t('reports.filters')}
                  </span>
                  {filtersOpen ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                </h3>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>{t('common.from')}</Label>
                    <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('common.to')}</Label>
                    <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Branch</Label>
                    <MultiSelectFilter
                      options={branches}
                      selected={selectedBranches}
                      onChange={setSelectedBranches}
                      allLabel="Todos"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('policies.company')}</Label>
                    <MultiSelectCompany
                      companies={companies}
                      selectedCompanies={selectedCompanies}
                      onChange={setSelectedCompanies}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('policies.agent')}</Label>
                    <MultiSelectFilter
                      options={agents.filter(a => allowedAgentIds === null || allowedAgentIds.includes(a.id))}
                      selected={selectedAgents}
                      onChange={setSelectedAgents}
                      allLabel="Todos"
                      searchable
                      searchPlaceholder="Buscar por nombre o alias..."
                      secondaryLabelKey="alias"
                    />
                    {selectedAgents.length > 0 && (
                      <div className="flex items-center gap-2 mt-1">
                        <Checkbox
                          id="include-structure"
                          checked={includeStructure}
                          onCheckedChange={setIncludeStructure}
                        />
                        <label htmlFor="include-structure" className="text-xs text-muted-foreground cursor-pointer">
                          Incluir estructura (agentes debajo)
                        </label>
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label>{t('policies.status')}</Label>
                    <MultiSelectFilter
                      options={STATUS_OPTIONS}
                      selected={selectedStatuses}
                      onChange={setSelectedStatuses}
                      allLabel="Todas"
                    />
                    <div className="flex items-center gap-2 mt-1">
                      <Checkbox
                        id="production-mode"
                        checked={productionMode}
                        onCheckedChange={setProductionMode}
                      />
                      <label htmlFor="production-mode" className="text-xs text-muted-foreground cursor-pointer">
                        🎯 Solo Producción (Nuevo Negocio + Activa + Pagada)
                      </label>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>{t('policies.policyType')}</Label>
                    <MultiSelectFilter
                      options={POLICY_TYPE_OPTIONS}
                      selected={selectedPolicyTypes}
                      onChange={setSelectedPolicyTypes}
                      allLabel="Todos los tipos"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Nivel de Agente</Label>
                    <MultiSelectFilter
                      options={AGENT_LEVEL_OPTIONS}
                      selected={selectedAgentLevels}
                      onChange={setSelectedAgentLevels}
                      allLabel="Todos los agentes"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>País de la Póliza</Label>
                    <MultiSelectFilter
                      options={availableCountries}
                      selected={selectedCountries}
                      onChange={setSelectedCountries}
                      allLabel="Todos los países"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Ramo</Label>
                    <MultiSelectFilter
                      options={lines}
                      selected={selectedLines}
                      onChange={setSelectedLines}
                      allLabel="Todos los ramos"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Etiquetas</Label>
                    <PolicyTagFilter
                      includeTagIds={tagFilterInclude}
                      excludeTagIds={tagFilterExclude}
                      onIncludeChange={setTagFilterInclude}
                      onExcludeChange={setTagFilterExclude}
                    />
                  </div>
                </div>

                <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-4">
                  <div className="flex gap-2 ml-auto">
                    <Button variant="outline" size="sm" onClick={setThisMonth}>Este Mes</Button>
                    <Button variant="outline" size="sm" onClick={setThisYear}>Este Año</Button>
                    <Button onClick={exportToCSV} className="gap-2">
                      <Download className="h-4 w-4" /> Exportar
                    </Button>
                  </div>
                </div>

                {productionMode && (
                  <div className="mt-4 p-3 bg-muted border border-border rounded-lg">
                    <p className="text-sm text-foreground">
                      <strong>Modo Producción:</strong> Solo pólizas de Nuevo Negocio, Activas y con al menos una cuota pagada.
                    </p>
                  </div>
                )}
              </CollapsibleContent>
            </Card>
          </Collapsible>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-0 shadow-sm p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-muted"><FileText className="h-6 w-6 text-foreground" /></div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('policies.title')}</p>
                  <p className="text-2xl font-bold text-foreground">{totalPolicies}</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">{filteredPolicies.filter(p => isPolicyPaid(p.id)).length} con cuotas pagadas</p>
                </div>
              </div>
            </Card>
            <Card className="border-0 shadow-sm p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-emerald-500/10"><DollarSign className="h-6 w-6 text-emerald-600 dark:text-emerald-400" /></div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('policies.annualPremium')}</p>
                  <p className="text-2xl font-bold text-foreground">USD {formatMoney(totalPremiums)}</p>
                  {productionMode && <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 font-medium">Producción calificada</p>}
                </div>
              </div>
            </Card>
            <Card className="border-0 shadow-sm p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-purple-500/10"><TrendingUp className="h-6 w-6 text-purple-600 dark:text-purple-400" /></div>
                <div>
                  <p className="text-sm text-muted-foreground">{t('policies.premium')}</p>
                  <p className="text-2xl font-bold text-foreground">USD {formatMoney(avgPremium)}</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    {filteredPolicies.filter(p => p.policy_type === 'nuevo_negocio').length} nuevo negocio |{' '}
                    {filteredPolicies.filter(p => p.policy_type === 'renovacion').length} renovaciones
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Widget Controls */}
          <div className="flex justify-end">
            <Button variant="outline" size="sm" onClick={resetLayout} className="gap-2">
              <Settings className="h-4 w-4" /> Resetear Layout
            </Button>
          </div>

          {/* Draggable + Resizable Widgets */}
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="widgets">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {widgets.map((widget, index) => (
                    <Draggable key={widget.id} draggableId={widget.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={`${widget.span === 3 ? 'lg:col-span-3' : widget.span === 2 ? 'lg:col-span-2' : 'lg:col-span-1'} ${snapshot.isDragging ? 'opacity-50' : ''}`}
                        >
                          <Card className="border-0 shadow-sm overflow-hidden">
                            <div className="px-4 py-3 flex items-center justify-between bg-muted/40 border-b">
                              <div className="flex items-center gap-2">
                                <div {...provided.dragHandleProps} className="cursor-move">
                                  <GripVertical className="h-5 w-5 text-muted-foreground/70" />
                                </div>
                                <h3 className="font-semibold text-sm">{widget.title}</h3>
                              </div>
                              <Button variant="ghost" size="icon" onClick={() => toggleCollapse(widget.id)} className="h-8 w-8">
                                {widget.collapsed ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                              </Button>
                            </div>

                            {!widget.collapsed && (
                              <ResizableWidget widget={widget} onSpanChange={updateWidgetSpan}>
                                <CardContent className="p-4">
                                  <div className="h-[340px] overflow-auto flex flex-col justify-center">
                                    {widget.component === 'ytd' && (
                                      <YearToDateWidget
                                        policies={policies}
                                        filters={{
                                          date_to: dateTo,
                                          policy_status: productionMode ? 'all' : (selectedStatuses.length === 1 ? selectedStatuses[0] : 'all'),
                                          policy_type: selectedPolicyTypes.length === 1 ? selectedPolicyTypes[0] : 'all',
                                          line_id: selectedLines.length === 1 ? selectedLines[0] : 'all',
                                          product_id: 'all',
                                          company_id: selectedCompanies.length === 1 ? selectedCompanies[0] : 'all',
                                          branch_id: selectedBranches.length === 1 ? selectedBranches[0] : 'all',
                                          currency: 'all',
                                          payment_frequency: 'all',
                                          agent_id: selectedAgents.length === 1 ? selectedAgents[0] : 'all',
                                          agent_type: 'all',
                                          include_structure: selectedAgents.length > 0 && includeStructure,
                                          is_nivel_2: selectedAgentLevels.length === 1 && selectedAgentLevels[0] === 'nivel2' ? 'true' : 'all',
                                          is_gapartner: selectedAgentLevels.length === 1 && selectedAgentLevels[0] === 'gapartner' ? 'true' : 'all',
                                        }}
                                        agents={agents}
                                        companies={companies}
                                        trmMap={trmMap}
                                      />
                                    )}
                                    {widget.component === 'map' && (
                                      <SalesByCountryList filteredPolicies={filteredPolicies} trmMap={trmMap} />
                                    )}
                                    {widget.component === 'yearProduction' && yearChartData.length > 0 && (
                                      <div>
                                        <p className="text-xs text-muted-foreground mb-2">Por año de emisión original — respeta todos los filtros activos</p>
                                        <ResponsiveContainer width="100%" height={280}>
                                          <BarChart data={yearChartData}>
                                            <CartesianGrid strokeDasharray="3 3" />
                                            <XAxis dataKey="year" />
                                            <YAxis />
                                            <Tooltip formatter={(value) => [`USD ${formatMoney(value)}`, 'Prima Total']} />
                                            <Legend />
                                            <Bar dataKey="prima" fill="#10b981" name="Prima Total" />
                                          </BarChart>
                                        </ResponsiveContainer>
                                      </div>
                                    )}
                                    {widget.component === 'monthlyTrend' && (
                                      <div>
                                        <p className="text-xs text-muted-foreground mb-2">Nuevos negocios del año en curso — respeta todos los filtros activos</p>
                                        <ResponsiveContainer width="100%" height={280}>
                                          <LineChart data={monthChartData}>
                                            <CartesianGrid strokeDasharray="3 3" />
                                            <XAxis dataKey="month" />
                                            <YAxis />
                                            <Tooltip formatter={(value) => `USD ${formatMoney(value)}`} />
                                            <Line type="monotone" dataKey="value" stroke="#f59e0b" strokeWidth={2} />
                                          </LineChart>
                                        </ResponsiveContainer>
                                      </div>
                                    )}
                                    {widget.component === 'company' && (
                                      <ResponsiveContainer width="100%" height={280}>
                                        <BarChart data={companyChartData}>
                                          <CartesianGrid strokeDasharray="3 3" />
                                          <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fontSize: 11 }} />
                                          <YAxis />
                                          <Tooltip formatter={(value) => `USD ${formatMoney(value)}`} />
                                          <Bar dataKey="value" fill="hsl(var(--chart-1))" />
                                        </BarChart>
                                      </ResponsiveContainer>
                                    )}
                                    {widget.component === 'agent' && (
                                      <ResponsiveContainer width="100%" height={280}>
                                        <BarChart data={agentChartData}>
                                          <CartesianGrid strokeDasharray="3 3" />
                                          <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fontSize: 11 }} />
                                          <YAxis />
                                          <Tooltip formatter={(value) => `USD ${formatMoney(value)}`} />
                                          <Bar dataKey="total" fill="#10b981" />
                                        </BarChart>
                                      </ResponsiveContainer>
                                    )}
                                    {widget.component === 'line' && (
                                     <ResponsiveContainer width="100%" height={280}>
                                       <PieChart>
                                         <Pie data={lineChartData} cx="50%" cy="50%" outerRadius={90} fill="#8884d8" dataKey="value">
                                           {lineChartData.map((entry, index) => (
                                             <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                           ))}
                                         </Pie>
                                         <Tooltip formatter={(value) => `USD ${formatMoney(value)}`} />
                                         <Legend layout="vertical" align="right" verticalAlign="middle" wrapperStyle={{ fontSize: '11px', maxWidth: '120px' }} />
                                       </PieChart>
                                     </ResponsiveContainer>
                                    )}
                                  </div>
                                </CardContent>
                              </ResizableWidget>
                            )}
                          </Card>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>

          {/* Top Agentes / Agencias */}
          <Card className="border-0 shadow-sm p-6">
            <Tabs defaultValue="agentes">
              <div className="flex items-center justify-between mb-4">
                <CardTitle className="text-lg">Rankings</CardTitle>
                <TabsList>
                  <TabsTrigger value="agentes">Top Agentes</TabsTrigger>
                  <TabsTrigger value="agencias">Top Agencias</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="agentes">
                <div className="space-y-2">
                  {agentChartData.slice(0, 10).map((agent, idx) => (
                    <AgentDetailRow key={idx} agent={agent} idx={idx} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="agencias">
                {(() => {
                  // Find agents that have at least one downline agent
                  const agentMap = {};
                  agents.forEach(a => { agentMap[a.id] = a; });

                  // Get all downline IDs recursively
                  const getDownlineIds = (agentId) => {
                    const ids = [];
                    const findDownline = (id) => {
                      agents.filter(a => a.upline_agent_id === id).forEach(a => {
                        ids.push(a.id);
                        findDownline(a.id);
                      });
                    };
                    findDownline(agentId);
                    return ids;
                  };

                  // Find heads of structure (agents with at least 1 downline)
                  // Exclude specific agent from appearing as agency head
                  const HIDDEN_AGENCY_HEADS = ['jose antonio riera vera'];
                  const structureHeads = agents.filter(a => 
                    agents.some(b => b.upline_agent_id === a.id) &&
                    !HIDDEN_AGENCY_HEADS.includes((a.name || '').toLowerCase().trim())
                  );

                  // Build agency data: head + their full structure
                  const agencyData = structureHeads.map(head => {
                    const downlineIds = getDownlineIds(head.id);
                    const allIds = [head.id, ...downlineIds];

                    // Aggregate policies for all agents in structure
                    const agentTotals = {};
                    allIds.forEach(id => {
                      const agentInfo = agentMap[id];
                      if (!agentInfo) return;
                      const agentPolicies = filteredPolicies.filter(p => p.agent_id === id);
                      if (agentPolicies.length > 0 || id === head.id) {
                        agentTotals[id] = {
                          name: agentInfo.name,
                          isHead: id === head.id,
                          total: Math.round(agentPolicies.reduce((s, p) => s + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0)),
                          count: agentPolicies.length,
                        };
                      }
                    });

                    const totalPremium = Object.values(agentTotals).reduce((s, a) => s + a.total, 0);
                    const totalPolicies = Object.values(agentTotals).reduce((s, a) => s + a.count, 0);

                    return {
                      name: head.name,
                      headId: head.id,
                      totalPremium,
                      totalPolicies,
                      structureCount: allIds.length,
                      agents: Object.values(agentTotals)
                        .sort((a, b) => b.total - a.total),
                    };
                  })
                  .filter(a => a.totalPremium > 0)
                  .sort((a, b) => b.totalPremium - a.totalPremium)
                  .slice(0, 10);

                  if (agencyData.length === 0) {
                    return <p className="text-muted-foreground/70 text-sm text-center py-8">No hay agencias con producción en el período seleccionado.</p>;
                  }

                  return (
                    <div className="space-y-2">
                      {agencyData.map((agency, idx) => (
                        <AgencyDetailRow key={idx} agency={agency} idx={idx} />
                      ))}
                    </div>
                  );
                })()}
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>
    </div>
  );
}