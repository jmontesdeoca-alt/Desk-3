import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import BackButton from '@/components/ui/BackButton';
import StatusBadge from '@/components/ui/StatusBadge';
import { Layers, Plus, Pencil, Trash2, Loader2 } from 'lucide-react';

export default function SettingsLines() {
  const [lines, setLines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    status: 'activo'
  });

  useEffect(() => {
    const loadUser = async () => {
      const user = await api.auth.me();
      setCurrentUser(user);
    };
    loadUser();
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const data = await api.entities.InsuranceLine.list('-created_date');
    setLines(data);
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    if (editingItem) {
      await api.entities.InsuranceLine.update(editingItem.id, formData);
    } else {
      await api.entities.InsuranceLine.create(formData);
    }
    setSaving(false);
    setFormOpen(false);
    setEditingItem(null);
    resetForm();
    loadData();
  };

  const handleEdit = (item) => {
    const canEdit = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canEdit) return;
    
    setEditingItem(item);
    setFormData({
      name: item.name || '',
      description: item.description || '',
      status: item.status || 'activo'
    });
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (itemToDelete) {
      await api.entities.InsuranceLine.delete(itemToDelete.id);
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      loadData();
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      status: 'activo'
    });
  };

  const openNewForm = () => {
    const canCreate = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canCreate) return;
    
    setEditingItem(null);
    resetForm();
    setFormOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <BackButton />
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-purple-500/10">
                <Layers className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Ramos de Seguros</h1>
                <p className="text-sm text-muted-foreground">{lines.length} ramos</p>
              </div>
            </div>
          </div>
          {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
            <Button onClick={openNewForm} className="gap-2">
              <Plus className="h-4 w-4" /> Nuevo Ramo
            </Button>
          )}
        </div>

        <div className="grid gap-4">
          {lines.map((line) => (
            <Card key={line.id} className="border-0 shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-foreground">{line.name}</h3>
                    <StatusBadge status={line.status} />
                  </div>
                  {line.description && (
                    <p className="text-sm text-muted-foreground">{line.description}</p>
                  )}
                </div>
                {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(line)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => { setItemToDelete(line); setDeleteDialogOpen(true); }}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
          {lines.length === 0 && (
            <Card className="border-0 shadow-sm p-12">
              <div className="text-center text-muted-foreground/70">
                <Layers className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No hay ramos registrados</p>
                <Button onClick={openNewForm} variant="outline" className="mt-4">
                  Agregar primer ramo
                </Button>
              </div>
            </Card>
          )}
        </div>

        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar Ramo' : 'Nuevo Ramo'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre *</Label>
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ej: Vida, Salud, Auto..."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Descripción</Label>
                <Textarea 
                  value={formData.description} 
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Descripción del ramo..."
                />
              </div>
              <div className="space-y-2">
                <Label>Estado</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(v) => setFormData({...formData, status: v})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activo">Activo</SelectItem>
                    <SelectItem value="inactivo">Inactivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingItem ? 'Guardar' : 'Crear'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar ramo?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará permanentemente el ramo 
                {itemToDelete && ` "${itemToDelete.name}"`}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}