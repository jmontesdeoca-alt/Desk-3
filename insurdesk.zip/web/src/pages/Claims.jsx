import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import { useSearchCache } from '@/components/SearchCache';
import { Shield, Loader2, Eye, X, Trash2, BarChart2 } from 'lucide-react';
import { formatDate } from '@/lib/dateUtils';
import { toast } from 'sonner';

import ClaimStats from '@/components/claims/ClaimStats';
import ClaimFilters from '@/components/claims/ClaimFilters';
import ClaimDetailDialog from '@/components/claims/ClaimDetailDialog';
import ClaimStalenessAlert from '@/components/claims/ClaimStalenessAlert';

export default function Claims() {
  const { searchQuery, updateSearch, clearSearch } = useSearchCache('claims');
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => { loadClaims(); }, []);

  const loadClaims = async () => {
    setLoading(true);
    const currentUser = await api.auth.me();
    setCurrentUser(currentUser);
    const allClaims = await api.entities.Claim.list('-created_date');

    let filtered = allClaims;
    if ((currentUser.app_role === 'agente' || currentUser.app_role === 'gerencial') && currentUser.agent_id) {
      const agentStructure = await getAgentStructure(currentUser.agent_id);
      const policies = await api.entities.Policy.list();
      const policyIds = new Set(policies.filter(p => agentStructure.includes(p.agent_id)).map(p => p.id));
      filtered = allClaims.filter(c => policyIds.has(c.policy_id));
    }

    setClaims(filtered);
    setLoading(false);
  };

  const getAgentStructure = async (agentId) => {
    const agents = await api.entities.Agent.list();
    const structure = [agentId];
    const findDownline = (id) => {
      agents.filter(a => a.upline_agent_id === id).forEach(a => {
        structure.push(a.id);
        findDownline(a.id);
      });
    };
    findDownline(agentId);
    return structure;
  };

  const openDetail = (claim) => {
    setSelectedClaim(claim);
    setDetailOpen(true);
  };

  const handleSaved = () => {
    loadClaims();
    // Keep dialog open after saving addendums/edits — dialog controls its own close
  };

  const filteredClaims = claims.filter(c =>
    statusFilter === 'all' || c.status === statusFilter
  );

  const exportToCSV = () => {
    const headers = ['Número', 'Póliza', 'Cliente', 'Fecha Evento', 'Tipo', 'Reclamado', 'Pagado', 'Estado'];
    const rows = filteredClaims.map(c => [
      c.claim_number, c.policy_number, c.client_name, c.event_date,
      c.claim_type, c.claimed_amount, c.paid_amount || 0, c.status
    ]);
    const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v || ''}"`).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'siniestros.csv';
    link.click();
  };

  const columns = [
    { header: 'Número', accessorKey: 'claim_number' },
    {
      header: 'Póliza',
      cell: (row) => (
        <Link to={createPageUrl(`PolicyDetail?id=${row.policy_id}`)} className="text-foreground hover:underline">
          {row.policy_number}
        </Link>
      )
    },
    { header: 'Cliente', accessorKey: 'client_name' },
    {
      header: 'Fecha Evento',
      cell: (row) => row.event_date ? formatDate(row.event_date, 'dd/MM/yyyy') : '-'
    },
    { header: 'Tipo', accessorKey: 'claim_type' },
    {
      header: 'Reclamado',
      cell: (row) => <span className="font-medium">{row.currency} {row.claimed_amount?.toLocaleString()}</span>
    },
    {
      header: 'Pagado',
      cell: (row) => (
        <span className={row.paid_amount ? 'font-medium text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground/70'}>
          {row.currency} {(row.paid_amount || 0).toLocaleString()}
        </span>
      )
    },
    { header: 'Estado', cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: 'Acciones',
      cell: (row) => (
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => openDetail(row)}>
            <Eye className="h-4 w-4" />
          </Button>
          {(currentUser?.role === 'admin' || currentUser?.app_role === 'admin') && (
            <Button
              variant="ghost"
              size="icon"
              className="text-red-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-500/10"
              onClick={(e) => {
                e.stopPropagation();
                toast(`¿Eliminar el siniestro ${row.claim_number}?`, {
                  description: 'Esta acción no se puede deshacer.',
                  action: {
                    label: 'Eliminar',
                    onClick: async () => {
                      await api.entities.Claim.delete(row.id);
                      toast.success('Siniestro eliminado');
                      loadClaims();
                    }
                  },
                  cancel: { label: 'Cancelar', onClick: () => {} },
                });
              }}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Siniestros"
          subtitle="Gestión de siniestros"
          icon={Shield}
          backTo="Dashboard"
          actions={
            <Link to={createPageUrl('ClaimReport')}>
              <Button variant="outline" size="sm" className="gap-2">
                <BarChart2 className="h-4 w-4" /> Reporte Detallado
              </Button>
            </Link>
          }
        />

        <ClaimStats claims={claims} />

        <ClaimStalenessAlert claims={claims} onOpenDetail={openDetail} />

        <ClaimFilters statusFilter={statusFilter} onStatusChange={setStatusFilter} />

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            columns={columns}
            data={filteredClaims}
            searchPlaceholder="Buscar por número, póliza o cliente..."
            initialSearch={searchQuery}
            onSearchChange={updateSearch}
            exportable
            onExport={exportToCSV}
            emptyMessage="Sin siniestros registrados"
            actions={
              searchQuery && (
                <Button variant="ghost" size="sm" onClick={clearSearch} className="text-muted-foreground hover:text-foreground/80 gap-1">
                  <X className="h-4 w-4" /> Limpiar búsqueda
                </Button>
              )
            }
          />
        </Card>

        <ClaimDetailDialog
          claim={selectedClaim}
          open={detailOpen}
          onOpenChange={setDetailOpen}
          onSaved={handleSaved}
        />
      </div>
    </div>
  );
}