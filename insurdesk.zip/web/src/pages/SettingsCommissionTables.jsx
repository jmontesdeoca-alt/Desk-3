import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import BackButton from '@/components/ui/BackButton';
import StatusBadge from '@/components/ui/StatusBadge';
import { Table2, Plus, Pencil, Trash2, Loader2, Building2, ChevronDown, Copy, RefreshCw, Download } from 'lucide-react';
import * as XLSX from 'xlsx';

export default function SettingsCommissionTables() {
  const [tables, setTables] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [lines, setLines] = useState([]);
  const [products, setProducts] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [filterCompany, setFilterCompany] = useState('all');
  const [openTables, setOpenTables] = useState({});
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    line_id: '',
    company_id: '',
    is_master: false,
    level: 1,
    level_name: '',
    status: 'activa',
    productCommissions: [] // [{product_id, product_name, new_business_percentage, renewal_percentage}]
  });

  useEffect(() => {
    const loadUser = async () => {
      const user = await api.auth.me();
      setCurrentUser(user);
    };
    loadUser();
  }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [tablesData, companiesData, linesData, productsData, branchesData] = await Promise.all([
      api.entities.CommissionTable.list('-created_date'),
      api.entities.InsuranceCompany.filter({ status: 'activa' }),
      api.entities.InsuranceLine.filter({ status: 'activo' }),
      api.entities.Product.filter({ status: 'activo' }),
      api.entities.Branch.filter({ status: 'activo' })
    ]);
    setTables(tablesData);
    setCompanies(companiesData);
    setLines(linesData);
    setProducts(productsData);
    const sortedBranches = branchesData.sort((a, b) => a.name.localeCompare(b.name));
    setBranches(sortedBranches);
    if (sortedBranches.length > 0 && !selectedBranch) {
      setSelectedBranch(sortedBranches[0].id);
    }
    setLoading(false);
  };

  const availableCompanies = formData.line_id 
    ? companies.filter(c => (c.line_ids?.includes(formData.line_id) || c.lines?.includes(lines.find(l => l.id === formData.line_id)?.name))).sort((a, b) => a.name.localeCompare(b.name))
    : [];

  const availableLines = formData.company_id
    ? lines.filter(l => {
        const company = companies.find(c => c.id === formData.company_id);
        return company?.lines?.includes(l.name);
      }).sort((a, b) => a.name.localeCompare(b.name))
    : lines.sort((a, b) => a.name.localeCompare(b.name));

  const availableProducts = (formData.line_id && formData.company_id)
    ? products.filter(p => p.line_id === formData.line_id && p.company_id === formData.company_id)
    : [];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    const company = companies.find(c => c.id === formData.company_id);
    const line = lines.find(l => l.id === formData.line_id);
    
    // Create ONE table with all products
    const dataToSave = {
      name: formData.name,
      company_id: formData.company_id,
      company_name: company?.name || '',
      line_id: formData.line_id,
      line_name: line?.name || '',
      is_master: formData.is_master,
      level: parseInt(formData.level) || 1,
      level_name: formData.level_name,
      product_commissions: formData.productCommissions.map(pc => ({
        product_id: pc.product_id,
        product_name: pc.product_name,
        new_business_percentage: parseFloat(pc.new_business_percentage) || 0,
        renewal_percentage: parseFloat(pc.renewal_percentage) || 0
      })),
      status: formData.status
    };
    
    if (editingItem) {
      await api.entities.CommissionTable.update(editingItem.id, dataToSave);
    } else {
      await api.entities.CommissionTable.create(dataToSave);
    }
    
    setSaving(false);
    setFormOpen(false);
    setEditingItem(null);
    resetForm();
    loadData();
  };

  const handleEdit = (item) => {
    const canEdit = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canEdit) {
      alert('No tienes permisos para editar tablas de comisiones');
      return;
    }
    
    setEditingItem(item);
    setFormData({
      name: item.name || '',
      line_id: item.line_id || '',
      company_id: item.company_id || '',
      is_master: item.is_master || false,
      level: item.level || 1,
      level_name: item.level_name || '',
      status: item.status || 'activa',
      productCommissions: item.product_commissions || []
    });
    setFormOpen(true);
  };

  const handleDelete = async () => {
    if (itemToDelete) {
      const canDelete = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
      if (!canDelete) {
        alert('No tienes permisos para eliminar tablas de comisiones');
        setDeleteDialogOpen(false);
        setItemToDelete(null);
        return;
      }
      
      await api.entities.CommissionTable.delete(itemToDelete.id);
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      loadData();
    }
  };

  const handleDuplicate = async (table) => {
    setSaving(true);
    
    // Generate new name with suffix
    let newName = `${table.name} - Copia`;
    let counter = 1;
    
    // Check if name exists and increment counter
    while (tables.some(t => t.name === newName)) {
      counter++;
      newName = `${table.name} - Copia ${counter}`;
    }
    
    const duplicatedData = {
      name: newName,
      company_id: table.company_id,
      company_name: table.company_name,
      line_id: table.line_id,
      line_name: table.line_name,
      is_master: false, // Copies are never master
      level: table.level,
      level_name: table.level_name,
      product_commissions: table.product_commissions || [],
      status: table.status
    };
    
    await api.entities.CommissionTable.create(duplicatedData);
    setSaving(false);
    loadData();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      line_id: '',
      company_id: '',
      is_master: false,
      level: 1,
      level_name: '',
      status: 'activa',
      productCommissions: []
    });
  };

  // Initialize product commissions when company and line are selected
  useEffect(() => {
    if (formData.line_id && formData.company_id && !editingItem) {
      const prods = products.filter(p => p.line_id === formData.line_id && p.company_id === formData.company_id);
      setFormData(prev => ({
        ...prev,
        productCommissions: prods.map(p => ({
          product_id: p.id,
          product_name: p.product_name,
          new_business_percentage: 0,
          renewal_percentage: 0
        }))
      }));
    }
  }, [formData.line_id, formData.company_id, editingItem, products]);

  const updateProductCommission = (productId, field, value) => {
    setFormData(prev => ({
      ...prev,
      productCommissions: prev.productCommissions.map(pc =>
        pc.product_id === productId ? { ...pc, [field]: value } : pc
      )
    }));
  };

  const openNewForm = () => {
    const canCreate = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin');
    if (!canCreate) {
      alert('No tienes permisos para crear tablas de comisiones');
      return;
    }
    
    setEditingItem(null);
    resetForm();
    setFormOpen(true);
  };



  const filteredTables = filterCompany === 'all' 
    ? tables 
    : tables.filter(t => t.company_id === filterCompany);

  // Filter by branch
  const tablesInBranch = filteredTables.filter(t => {
    const company = companies.find(c => c.id === t.company_id);
    return company?.branch_id === selectedBranch;
  });

  // Group by company - ordenado alfabéticamente
  const tablesByCompany = tablesInBranch.reduce((acc, table) => {
    const companyName = table.company_name || 'Sin compañía';
    if (!acc[companyName]) acc[companyName] = [];
    acc[companyName].push(table);
    return acc;
  }, {});

  // Ordenar las tablas dentro de cada compañía alfabéticamente
  Object.keys(tablesByCompany).forEach(companyName => {
    tablesByCompany[companyName].sort((a, b) => a.name.localeCompare(b.name));
  });

  const toggleTable = (tableId) => {
    setOpenTables(prev => ({ ...prev, [tableId]: !prev[tableId] }));
  };

  const exportToExcel = () => {
    const rows = [];
    tables.forEach(table => {
      const commissions = table.product_commissions || [];
      if (commissions.length === 0) {
        rows.push({
          'Tabla': table.name,
          'Compañía': table.company_name || '',
          'Ramo': table.line_name || '',
          'Nivel': `Nivel ${table.level}: ${table.level_name || ''}`,
          'Producto': '(sin productos)',
          'Nuevo Negocio (%)': '',
          'Renovación (%)': ''
        });
      } else {
        commissions.forEach(pc => {
          rows.push({
            'Tabla': table.name,
            'Compañía': table.company_name || '',
            'Ramo': table.line_name || '',
            'Nivel': `Nivel ${table.level}: ${table.level_name || ''}`,
            'Producto': pc.product_name || '',
            'Nuevo Negocio (%)': pc.new_business_percentage ?? 0,
            'Renovación (%)': pc.renewal_percentage ?? 0
          });
        });
      }
    });

    const ws = XLSX.utils.json_to_sheet(rows);

    // Column widths
    ws['!cols'] = [
      { wch: 35 }, { wch: 25 }, { wch: 20 }, { wch: 25 }, { wch: 30 }, { wch: 18 }, { wch: 16 }
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Tablas de Comisiones');
    XLSX.writeFile(wb, 'tablas_comisiones.xlsx');
  };

  const syncTableProducts = async () => {
    if (!confirm('¿Sincronizar todas las tablas con los productos actuales? Esto agregará productos nuevos y actualizará nombres de productos modificados.')) {
      return;
    }

    setSaving(true);
    try {
      const allTables = await api.entities.CommissionTable.list();
      const allProducts = await api.entities.Product.list();

      for (const table of allTables) {
        // Get products for this table's company and line
        const relevantProducts = allProducts.filter(
          p => p.company_id === table.company_id && p.line_id === table.line_id
        );

        const existingCommissions = table.product_commissions || [];
        const existingProductIds = new Set(existingCommissions.map(pc => pc.product_id));

        // Update existing product names
        const updatedCommissions = existingCommissions.map(pc => {
          const currentProduct = relevantProducts.find(p => p.id === pc.product_id);
          if (currentProduct && currentProduct.product_name !== pc.product_name) {
            return { ...pc, product_name: currentProduct.product_name };
          }
          return pc;
        });

        // Add new products that don't exist yet
        relevantProducts.forEach(product => {
          if (!existingProductIds.has(product.id)) {
            updatedCommissions.push({
              product_id: product.id,
              product_name: product.product_name,
              new_business_percentage: 0,
              renewal_percentage: 0
            });
          }
        });

        // Update the table if there were changes
        if (JSON.stringify(updatedCommissions) !== JSON.stringify(existingCommissions)) {
          await api.entities.CommissionTable.update(table.id, {
            product_commissions: updatedCommissions
          });
        }
      }

      await loadData();
      alert('¡Sincronización completada! Todas las tablas han sido actualizadas.');
    } catch (error) {
      console.error('Error syncing tables:', error);
      alert('Error al sincronizar las tablas. Por favor intenta nuevamente.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <BackButton />
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/10">
                <Table2 className="h-6 w-6 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Tablas de Comisiones</h1>
                <p className="text-sm text-muted-foreground">{tables.length} tablas</p>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={exportToExcel} variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Exportar Excel
            </Button>
            {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
              <>
                <Button onClick={syncTableProducts} variant="outline" className="gap-2" disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                  Sincronizar
                </Button>
                <Button onClick={openNewForm} className="gap-2">
                  <Plus className="h-4 w-4" /> Nueva Tabla
                </Button>
              </>
            )}
          </div>
        </div>

        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="flex items-center gap-4">
            <Label className="text-muted-foreground">Filtrar por compañía:</Label>
            <Select value={filterCompany} onValueChange={setFilterCompany}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las compañías</SelectItem>
                {companies.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </Card>

        <Tabs value={selectedBranch} onValueChange={setSelectedBranch} className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 mb-6">
            {branches.map(b => (
              <TabsTrigger key={b.id} value={b.id} className="text-xs lg:text-sm">
                {b.name.length > 12 ? `${b.name.substring(0, 10)}...` : b.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {branches.map(branch => (
            <TabsContent key={branch.id} value={branch.id} className="space-y-6">
              {Object.entries(tablesByCompany).sort(([a], [b]) => a.localeCompare(b)).map(([companyName, companyTables]) => (
                <div key={companyName}>
                  <div className="flex items-center gap-2 mb-3">
                    <Building2 className="h-4 w-4 text-muted-foreground/70" />
                    <h2 className="font-semibold text-foreground/80">{companyName}</h2>
                    <span className="text-sm text-muted-foreground/70">({companyTables.length})</span>
                  </div>
                  <div className="grid gap-4">
                    {companyTables.map((table) => (
                      <Collapsible 
                        key={table.id} 
                        open={openTables[table.id]} 
                        onOpenChange={() => toggleTable(table.id)}
                      >
                        <Card className="border-0 shadow-sm overflow-hidden">
                          <CollapsibleTrigger className="w-full">
                            <div className="p-4 hover:bg-muted/40 transition-colors">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <ChevronDown className={`h-4 w-4 text-muted-foreground/70 transition-transform ${openTables[table.id] ? 'rotate-180' : ''}`} />
                                  <div className="text-left">
                                    <div className="flex items-center gap-3 mb-1">
                                      <h3 className="font-semibold text-foreground">{table.name}</h3>
                                      {table.is_master && (
                                        <span className="px-2 py-0.5 rounded text-xs font-medium bg-purple-500/10 text-purple-600 dark:text-purple-400">
                                          MASTER
                                        </span>
                                      )}
                                      <StatusBadge status={table.status} />
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                      <span>Ramo: {table.line_name}</span>
                                      <span>•</span>
                                      <span>Productos: {table.product_commissions?.length || 0}</span>
                                      <span>•</span>
                                      <span>Nivel {table.level}: {table.level_name}</span>
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                                 {currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin') && (
                                   <>
                                     <Button 
                                       variant="ghost" 
                                       size="icon" 
                                       onClick={() => handleDuplicate(table)}
                                       disabled={saving}
                                       title="Duplicar tabla"
                                     >
                                       <Copy className="h-4 w-4 text-foreground" />
                                     </Button>
                                     <Button variant="ghost" size="icon" onClick={() => handleEdit(table)}>
                                       <Pencil className="h-4 w-4" />
                                     </Button>
                                     <Button 
                                       variant="ghost" 
                                       size="icon" 
                                       onClick={() => { setItemToDelete(table); setDeleteDialogOpen(true); }}
                                     >
                                       <Trash2 className="h-4 w-4 text-red-500" />
                                     </Button>
                                   </>
                                 )}
                                </div>
                              </div>
                            </div>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <div className="px-4 pb-4">
                              <div className="bg-muted/40 rounded-lg p-4 overflow-x-auto">
                                <table className="w-full text-sm">
                                  <thead>
                                    <tr className="border-b border-input">
                                      <th className="text-left py-2 px-2 font-semibold">Producto</th>
                                      <th className="text-center py-2 px-2 font-semibold text-emerald-600 dark:text-emerald-400">Nuevo Negocio</th>
                                      <th className="text-center py-2 px-2 font-semibold text-foreground">Renovación</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {table.product_commissions?.map((pc, idx) => (
                                      <tr key={idx} className="border-b border-border">
                                        <td className="py-2 px-2">{pc.product_name}</td>
                                        <td className="text-center py-2 px-2 font-medium text-emerald-600 dark:text-emerald-400">{pc.new_business_percentage}%</td>
                                        <td className="text-center py-2 px-2 font-medium text-foreground">{pc.renewal_percentage}%</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </CollapsibleContent>
                        </Card>
                      </Collapsible>
                    ))}
                  </div>
                </div>
              ))}
              {tablesInBranch.length === 0 && (
                <Card className="border-0 shadow-sm p-12">
                  <div className="text-center text-muted-foreground/70">
                    <Table2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No hay tablas en este branch</p>
                  </div>
                </Card>
              )}
            </TabsContent>
          ))}
        </Tabs>

        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Editar Tabla' : 'Nueva Tabla de Comisiones'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre de la Tabla *</Label>
                  <Input 
                    value={formData.name} 
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Ej: Comisión Vida Nivel 1"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Compañía *</Label>
                  <Select 
                    value={formData.company_id} 
                    onValueChange={(v) => setFormData({...formData, company_id: v, line_id: '', product_id: ''})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar compañía" />
                    </SelectTrigger>
                    <SelectContent>
                      {companies.sort((a, b) => a.name.localeCompare(b.name)).map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Ramo *</Label>
                  <Select 
                    value={formData.line_id} 
                    onValueChange={(v) => setFormData({...formData, line_id: v, product_id: ''})}
                    disabled={!formData.company_id}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={formData.company_id ? "Seleccionar ramo" : "Primero seleccione compañía"} />
                    </SelectTrigger>
                    <SelectContent>
                      {availableLines.map(l => (
                        <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Estado</Label>
                  <Select 
                    value={formData.status} 
                    onValueChange={(v) => setFormData({...formData, status: v})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activa">Activa</SelectItem>
                      <SelectItem value="inactiva">Inactiva</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Nivel *</Label>
                  <Input 
                    type="number"
                    min="1"
                    value={formData.level} 
                    onChange={(e) => setFormData({...formData, level: e.target.value})}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Nombre del Nivel *</Label>
                  <Input 
                    value={formData.level_name} 
                    onChange={(e) => setFormData({...formData, level_name: e.target.value})}
                    placeholder="Ej: Vendedor, Supervisor"
                    required
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="is_master"
                  checked={formData.is_master}
                  onChange={(e) => setFormData({...formData, is_master: e.target.checked})}
                  className="rounded"
                />
                <Label htmlFor="is_master" className="cursor-pointer">Tabla MASTER (Agencia Principal)</Label>
              </div>

              {/* Products Table */}
              {formData.company_id && formData.productCommissions.length > 0 && (
                <div className="space-y-3 p-4 bg-muted/40 rounded-lg border-2 border-border">
                  <h4 className="font-medium text-sm text-foreground/80">Comisiones por Producto</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-input">
                          <th className="text-left py-2 px-3 font-semibold text-foreground/80">Producto</th>
                          <th className="text-center py-2 px-3 font-semibold text-foreground/80">Nuevo Negocio (%)</th>
                          <th className="text-center py-2 px-3 font-semibold text-foreground/80">Renovación (%)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formData.productCommissions.map((pc, idx) => (
                          <tr key={pc.product_id} className={idx % 2 === 0 ? 'bg-card' : 'bg-muted'}>
                            <td className="py-2 px-3 font-medium">{pc.product_name}</td>
                            <td className="py-2 px-3">
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                value={pc.new_business_percentage}
                                onChange={(e) => updateProductCommission(pc.product_id, 'new_business_percentage', e.target.value)}
                                className="text-center h-9"
                              />
                            </td>
                            <td className="py-2 px-3">
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                value={pc.renewal_percentage}
                                onChange={(e) => updateProductCommission(pc.product_id, 'renewal_percentage', e.target.value)}
                                className="text-center h-9"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setFormOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingItem ? 'Guardar' : 'Crear'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar tabla?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. Se eliminará permanentemente la tabla 
                {itemToDelete && ` "${itemToDelete.name}"`}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}