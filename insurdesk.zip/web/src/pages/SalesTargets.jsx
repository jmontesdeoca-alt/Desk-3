import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import PageHeader from '@/components/ui/PageHeader';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from 'react-hook-form';
import { Plus, Target, Users, Briefcase } from 'lucide-react';
import AgentSelect from '@/components/forms/AgentSelect';
import FlippableBudgetCard from '../components/budget/FlippableBudgetCard';
import AgentTargetGroup from '../components/targets/AgentTargetGroup';
import SalesAnalyticsDashboard from '../components/targets/SalesAnalyticsDashboard';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function SalesTargets() {
  const [deleteTargetId, setDeleteTargetId] = useState(null);
  const [deleteBudgetId, setDeleteBudgetId] = useState(null);
  // Raw targets (no current_value computed) – used to build agent groups
  const [rawTargets, setRawTargets] = useState([]);
  const [agents, setAgents] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [lines, setLines] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [payments, setPayments] = useState([]);
  const [open, setOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedCompanies, setSelectedCompanies] = useState([]);
  const [selectedLines, setSelectedLines] = useState([]);
  const [allLines, setAllLines] = useState(true);
  const [budgets, setBudgets] = useState([]);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [products, setProducts] = useState([]);
  const [selectedBudgetProducts, setSelectedBudgetProducts] = useState([]);
  const [budgetOnlyNewBusiness, setBudgetOnlyNewBusiness] = useState(false);
  const [agentFilter, setAgentFilter] = useState('');
  const [analyticsBranch, setAnalyticsBranch] = useState('__all__');
  // Cache: agentId → computed targets array
  const targetCacheRef = React.useRef({});

  const { register, handleSubmit, reset, setValue, watch } = useForm();
  const { register: registerBudget, handleSubmit: handleSubmitBudget, reset: resetBudget, setValue: setValueBudget, watch: watchBudget } = useForm();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [targetsData, agentsData, companiesData, linesData, policiesData, paymentsData, budgetsData, productsData, userRoleResp] = await Promise.all([
        api.entities.SalesTarget.list(),
        api.entities.Agent.list(),
        api.entities.InsuranceCompany.list(),
        api.entities.InsuranceLine.list(),
        api.entities.Policy.list(),
        api.entities.Payment.list(),
        api.entities.CompanyBudget.list(),
        api.entities.Product.list(),
        api.functions.invoke('getUserRoleInfo', {})
      ]);

      const appRole = userRoleResp?.data?.app_role;
      const linkedAgentId = userRoleResp?.data?.agent_id;

      // For gerencial with agent: restrict to structure
      let filteredAgentsData = agentsData;
      let filteredTargetsData = targetsData;
      let filteredPoliciesData = policiesData;

      if (appRole === 'gerencial' && linkedAgentId) {
        const structureIds = [];
        const findStructure = (id) => {
          structureIds.push(id);
          agentsData.filter(a => a.upline_agent_id === id).forEach(child => findStructure(child.id));
        };
        findStructure(linkedAgentId);
        filteredAgentsData = agentsData.filter(a => structureIds.includes(a.id));
        filteredTargetsData = targetsData.filter(t => structureIds.includes(t.agent_id));
        filteredPoliciesData = policiesData.filter(p => structureIds.includes(p.agent_id));
      }

      // Invalidate cache on full reload so groups re-compute on next expand
      targetCacheRef.current = {};

      // Calculate stats for each budget
      const budgetsWithStats = budgetsData.map(budget => {
        const stats = calculateBudgetStats(budget, filteredPoliciesData, paymentsData);
        return { ...budget, ...stats };
      });
      
      // Store raw targets – NO current_value computation here
      setRawTargets(filteredTargetsData);
      setAgents(filteredAgentsData);
      setCompanies(companiesData);
      setLines(linesData);
      setPolicies(filteredPoliciesData);
      setPayments(paymentsData);
      setBudgets(budgetsWithStats);
      setProducts(productsData);
    } finally {
      setLoading(false);
    }
  };

  const calculateBudgetStats = (budget, allPolicies, allPayments) => {
    const startDate = new Date(budget.start_date + 'T12:00:00');
    const endDate = new Date(budget.end_date + 'T12:00:00');

    let policiesInPeriod = allPolicies.filter(p => {
      if (!p.start_date) return false;
      if (p.status === 'cancelada') return false;
      const policyDate = new Date(p.start_date + 'T12:00:00');
      return policyDate >= startDate && policyDate <= endDate;
    });

    // Filter by company if specified
    if (budget.company_id) {
      policiesInPeriod = policiesInPeriod.filter(p => p.company_id === budget.company_id);
    }

    // Filter by line if specified
    if (budget.line_id) {
      policiesInPeriod = policiesInPeriod.filter(p => p.line_id === budget.line_id);
    }

    // Filter only new business if specified
    if (budget.only_new_business) {
      policiesInPeriod = policiesInPeriod.filter(p => p.policy_type === 'nuevo_negocio');
    }

    // Filter by specific products if specified
    if (budget.products && budget.products.length > 0) {
      const productIds = budget.products.map(pr => pr.product_id);
      policiesInPeriod = policiesInPeriod.filter(p => productIds.includes(p.product_id));
    }

    const total = policiesInPeriod.reduce((sum, p) => sum + (p.annual_premium || 0), 0);

    // Calculate paid based on payments
    const paidPolicyIds = new Set(
      allPayments
        .filter(pay => pay.status === 'pagado' && 
          policiesInPeriod.some(p => p.id === pay.policy_id))
        .map(pay => pay.policy_id)
    );

    const paid = policiesInPeriod
      .filter(p => paidPolicyIds.has(p.id))
      .reduce((sum, p) => sum + (p.annual_premium || 0), 0);

    const unpaid = total - paid;

    // Calculate per-product breakdown
    const productMap = {};
    policiesInPeriod.forEach(p => {
      if (!p.product_id) return;
      if (!productMap[p.product_id]) {
        productMap[p.product_id] = { product_id: p.product_id, product_name: p.product_name || 'Sin nombre', total: 0 };
      }
      productMap[p.product_id].total += (p.annual_premium || 0);
    });
    const productBreakdown = Object.values(productMap).sort((a, b) => b.total - a.total);

    return { total, paid, unpaid, productBreakdown };
  };

  const calculateCurrentValue = async (target, allPolicies, allAgents) => {
    const policiesInPeriod = allPolicies.filter(p => {
      if (!p.start_date) return false;
      if (p.status === 'cancelada') return false;
      const policyDate = new Date(p.start_date + 'T00:00:00');
      const startDate = new Date(target.start_date + 'T00:00:00');
      const endDate = new Date(target.end_date + 'T00:00:00');
      return policyDate >= startDate && policyDate <= endDate;
    });

    let relevantPolicies = policiesInPeriod;

    if (target.target_type === 'individual') {
      relevantPolicies = relevantPolicies.filter(p => p.agent_id === target.agent_id);
    } else if (target.target_type === 'structure') {
      const structureAgents = getAgentStructure(target.agent_id, allAgents);
      const agentIds = structureAgents.map(a => a.id);
      relevantPolicies = relevantPolicies.filter(p => agentIds.includes(p.agent_id));
    }

    if (target.companies && target.companies.length > 0) {
      const companyIds = target.companies.map(c => c.company_id);
      relevantPolicies = relevantPolicies.filter(p => companyIds.includes(p.company_id));
    }

    if (!target.all_lines && target.lines && target.lines.length > 0) {
      const lineIds = target.lines.map(l => l.line_id);
      relevantPolicies = relevantPolicies.filter(p => lineIds.includes(p.line_id));
    }

    const getValue = (p) => {
      switch (target.metric) {
        case 'new_policies': return 1;
        case 'premium_volume': return p.annual_premium || 0;
        case 'commission_value': return p.commissionable_premium || 0;
        default: return 0;
      }
    };

    const total = relevantPolicies.reduce((sum, p) => sum + getValue(p), 0);

    // Always build company breakdown from relevant policies
    const companyMap = {};
    relevantPolicies.forEach(p => {
      if (!p.company_id) return;
      if (!companyMap[p.company_id]) {
        companyMap[p.company_id] = { company_id: p.company_id, company_name: p.company_name || 'Sin nombre', value: 0 };
      }
      companyMap[p.company_id].value += getValue(p);
    });
    const companyBreakdown = Object.values(companyMap).sort((a, b) => b.value - a.value);

    return { total, companyBreakdown };
  };

  const getAgentStructure = (agentId, allAgents) => {
    const result = [allAgents.find(a => a.id === agentId)].filter(Boolean);
    const children = allAgents.filter(a => a.upline_agent_id === agentId);
    
    children.forEach(child => {
      result.push(...getAgentStructure(child.id, allAgents));
    });
    
    return result;
  };

  const getStructureContributions = async (target) => {
    if (target.target_type !== 'structure') return [];
    
    const structureAgents = getAgentStructure(target.agent_id, agents);
    const contributions = [];

    for (const agent of structureAgents) {
      const individualTarget = { ...target, target_type: 'individual', agent_id: agent.id };
      const { total } = await calculateCurrentValue(individualTarget, policies, agents);
      if (total > 0) {
        contributions.push({
          agent_id: agent.id,
          agent_name: agent.name,
          contribution_value: total
        });
      }
    }

    return contributions;
  };

  const handleOpenForm = (target = null) => {
    if (target) {
      setEditingTarget(target);
      Object.keys(target).forEach(key => setValue(key, target[key]));
      setSelectedCompanies(target.companies || []);
      setSelectedLines(target.lines || []);
      setAllLines(target.all_lines !== false);
    } else {
      setEditingTarget(null);
      setSelectedCompanies([]);
      setSelectedLines([]);
      setAllLines(true);
      reset({
        target_type: 'individual',
        metric: 'new_policies',
        status: 'activo',
        all_lines: true
      });
    }
    setOpen(true);
  };

  const onSubmit = async (data) => {
    try {
      // Get agent name
      const selectedAgent = agents.find(a => a.id === data.agent_id);
      
      const submitData = {
        ...data,
        agent_name: selectedAgent?.name || '',
        target_value: parseFloat(data.target_value),
        bonus_amount: data.bonus_amount ? parseFloat(data.bonus_amount) : null,
        companies: selectedCompanies.length > 0 ? selectedCompanies : null,
        all_lines: allLines,
        lines: allLines ? null : selectedLines,
        structure_contributions: []
      };

      if (editingTarget) {
        await api.entities.SalesTarget.update(editingTarget.id, submitData);
      } else {
        await api.entities.SalesTarget.create(submitData);
      }
      setOpen(false);
      loadData();
    } catch (error) {
      console.error('Error saving target:', error);
    }
  };

  const toggleCompanySelection = (company) => {
    setSelectedCompanies(prev => {
      const isSelected = prev.some(c => c.company_id === company.id);
      if (isSelected) {
        return prev.filter(c => c.company_id !== company.id);
      } else {
        return [...prev, { company_id: company.id, company_name: company.name }];
      }
    });
  };

  const toggleLineSelection = (line) => {
    setSelectedLines(prev => {
      const isSelected = prev.some(l => l.line_id === line.id);
      if (isSelected) {
        return prev.filter(l => l.line_id !== line.id);
      } else {
        return [...prev, { line_id: line.id, line_name: line.name }];
      }
    });
  };

  const handleDelete = (id) => {
    setDeleteTargetId(id);
  };

  const confirmDeleteTarget = async () => {
    await api.entities.SalesTarget.delete(deleteTargetId);
    setDeleteTargetId(null);
    loadData();
  };

  const handleOpenBudgetForm = (budget = null) => {
    if (budget) {
      setEditingBudget(budget);
      Object.keys(budget).forEach(key => setValueBudget(key, budget[key]));
      setSelectedBudgetProducts(budget.products || []);
      setBudgetOnlyNewBusiness(budget.only_new_business === true);
    } else {
      setEditingBudget(null);
      resetBudget({
        currency: 'USD',
        status: 'activo'
      });
      setSelectedBudgetProducts([]);
      setBudgetOnlyNewBusiness(false);
    }
    setBudgetOpen(true);
  };

  const toggleBudgetProduct = (product) => {
    setSelectedBudgetProducts(prev => {
      const isSelected = prev.some(p => p.product_id === product.id);
      if (isSelected) {
        return prev.filter(p => p.product_id !== product.id);
      } else {
        return [...prev, { product_id: product.id, product_name: product.product_name }];
      }
    });
  };

  const onSubmitBudget = async (data) => {
    try {
      const selectedCompany = data.company_id ? companies.find(c => c.id === data.company_id) : null;
      const selectedLine = data.line_id ? lines.find(l => l.id === data.line_id) : null;

      const submitData = {
        ...data,
        target_amount: parseFloat(data.target_amount),
        company_name: selectedCompany?.name || null,
        line_name: selectedLine?.name || null,
        products: selectedBudgetProducts.length > 0 ? selectedBudgetProducts : null,
        only_new_business: budgetOnlyNewBusiness
      };

      if (editingBudget) {
        await api.entities.CompanyBudget.update(editingBudget.id, submitData);
      } else {
        await api.entities.CompanyBudget.create(submitData);
      }
      setBudgetOpen(false);
      loadData();
    } catch (error) {
      console.error('Error saving budget:', error);
    }
  };

  const handleDeleteBudget = (id) => {
    setDeleteBudgetId(id);
  };

  const confirmDeleteBudget = async () => {
    await api.entities.CompanyBudget.delete(deleteBudgetId);
    setDeleteBudgetId(null);
    loadData();
  };

  const getMetricLabel = (metric) => {
    const labels = {
      new_policies: 'Pólizas Nuevas',
      premium_volume: 'Volumen de Prima',
      commission_value: 'Valor en Comisiones'
    };
    return labels[metric] || metric;
  };

  const getProgressPercentage = (current, target) => {
    return Math.min((current / target) * 100, 100);
  };

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-6xl mx-auto">
        <PageHeader 
          title="Objetivos de Ventas" 
          subtitle="Gestiona objetivos personalizados por agente o equipo"
          icon={Target}
          backTo="AdminPanel"
        />

        <Tabs defaultValue="objectives" className="space-y-4">
          <TabsList>
            <TabsTrigger value="objectives">Objetivos Individuales</TabsTrigger>
            <TabsTrigger value="budget">Presupuesto de Compañía</TabsTrigger>
            <TabsTrigger value="analytics">Dashboard Analítico</TabsTrigger>
          </TabsList>

          <TabsContent value="objectives" className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-64">
                <AgentSelect
                  agents={[
                    { id: '', name: 'Todos los agentes' },
                    ...[...new Map(rawTargets.map(t => [t.agent_id, { id: t.agent_id, name: t.agent_name, alias: agents.find(a => a.id === t.agent_id)?.alias }])).values()]
                      .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
                  ]}
                  value={agentFilter}
                  onValueChange={(val) => setAgentFilter(val || '')}
                />
              </div>
              {agentFilter && (
                <Button variant="ghost" size="sm" onClick={() => setAgentFilter('')} className="text-muted-foreground">
                  Limpiar
                </Button>
              )}
              <div className="ml-auto flex items-center gap-3">
                {/* Leyenda de métricas */}
                <div className="hidden sm:flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-primary inline-block" />Prima</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />Pólizas</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />Comisiones</span>
                </div>
                <Button onClick={() => handleOpenForm()} className="bg-primary hover:bg-primary/90">
                  <Plus className="h-4 w-4 mr-2" />
                  Nuevo Objetivo
                </Button>
              </div>
            </div>

            {(() => {
              const filtered = rawTargets.filter(t => !agentFilter || t.agent_id === agentFilter);
              const grouped = filtered.reduce((acc, t) => {
                if (!acc[t.agent_id]) acc[t.agent_id] = { agent_id: t.agent_id, agent_name: t.agent_name, targets: [] };
                acc[t.agent_id].targets.push(t);
                return acc;
              }, {});
              const groups = Object.values(grouped).sort((a, b) => (a.agent_name || '').localeCompare(b.agent_name || ''));

              if (groups.length === 0) {
                return (
                  <Card className="p-8">
                    <div className="text-center text-muted-foreground">
                      <Target className="h-12 w-12 mx-auto mb-3 text-muted-foreground/70" />
                      <p className="text-lg font-medium mb-1">No hay objetivos creados</p>
                      <p className="text-sm">Crea objetivos para medir el rendimiento de tus agentes.</p>
                    </div>
                  </Card>
                );
              }

              // Build branch tabs from all targets
              // A target belongs to a branch if ALL its companies share the same branch_id
              // If a target has no companies, or companies from multiple branches → "Mixta"
              const companyBranchMap = {};
              companies.forEach(c => { companyBranchMap[c.id] = { branch_id: c.branch_id, branch_name: c.branch_name }; });

              const getTargetBranch = (t) => {
                if (!t.companies || t.companies.length === 0) return null; // no filter → all branches
                const branchIds = [...new Set(t.companies.map(c => companyBranchMap[c.company_id]?.branch_id).filter(Boolean))];
                if (branchIds.length === 1) {
                  const info = Object.values(companyBranchMap).find(b => b.branch_id === branchIds[0]);
                  return { branch_id: branchIds[0], branch_name: info?.branch_name || branchIds[0] };
                }
                return { branch_id: '__mixta__', branch_name: 'Mixta' };
              };

              // Collect distinct branches across all filtered targets
              const branchOrder = [];
              const branchSet = new Set();
              filtered.forEach(t => {
                const b = getTargetBranch(t);
                const key = b ? b.branch_id : '__sin_filtro__';
                if (!branchSet.has(key)) {
                  branchSet.add(key);
                  branchOrder.push(b ? b : { branch_id: '__sin_filtro__', branch_name: 'Sin filtro' });
                }
              });

              // Sort: put Mixta and Sin filtro last
              branchOrder.sort((a, b) => {
                const special = ['__mixta__', '__sin_filtro__'];
                const aSpec = special.includes(a.branch_id);
                const bSpec = special.includes(b.branch_id);
                if (aSpec && !bSpec) return 1;
                if (!aSpec && bSpec) return -1;
                return (a.branch_name || '').localeCompare(b.branch_name || '');
              });

              const hasBranchTabs = branchOrder.length > 1;

              const renderGroups = (targetSubset) => {
                const subGrouped = targetSubset.reduce((acc, t) => {
                  if (!acc[t.agent_id]) acc[t.agent_id] = { agent_id: t.agent_id, agent_name: t.agent_name, targets: [] };
                  acc[t.agent_id].targets.push(t);
                  return acc;
                }, {});
                const subGroups = Object.values(subGrouped).sort((a, b) => (a.agent_name || '').localeCompare(b.agent_name || ''));
                if (subGroups.length === 0) return <p className="text-center text-muted-foreground/70 py-8 text-sm">Sin objetivos en este branch</p>;
                return (
                  <div className="space-y-3">
                    {subGroups.map(group => (
                      <AgentTargetGroup
                        key={group.agent_id}
                        agentId={group.agent_id}
                        agentName={group.agent_name}
                        rawTargets={group.targets}
                        policies={policies}
                        agents={agents}
                        onEdit={handleOpenForm}
                        onDelete={handleDelete}
                        onRefresh={async (t) => {
                          const contributions = await getStructureContributions(t);
                          await api.entities.SalesTarget.update(t.id, { structure_contributions: contributions });
                          delete targetCacheRef.current[t.agent_id];
                          loadData();
                        }}
                        getCached={(id) => targetCacheRef.current[id] || null}
                        setCache={(id, data) => { targetCacheRef.current[id] = data; }}
                      />
                    ))}
                  </div>
                );
              };

              if (!hasBranchTabs) {
                return renderGroups(filtered);
              }

              return (
                <Tabs defaultValue={branchOrder[0]?.branch_id} className="space-y-3">
                  <TabsList>
                    {branchOrder.map(b => (
                      <TabsTrigger key={b.branch_id} value={b.branch_id}>
                        {b.branch_name}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  {branchOrder.map(b => {
                    const branchTargets = filtered.filter(t => {
                      const tb = getTargetBranch(t);
                      const key = tb ? tb.branch_id : '__sin_filtro__';
                      return key === b.branch_id;
                    });
                    return (
                      <TabsContent key={b.branch_id} value={b.branch_id}>
                        {renderGroups(branchTargets)}
                      </TabsContent>
                    );
                  })}
                </Tabs>
              );
            })()}
          </TabsContent>

          <TabsContent value="analytics">
            {(() => {
              // Build branch list from companies (same logic as objectives tab)
              const companyBranchMap = {};
              companies.forEach(c => { companyBranchMap[c.id] = { branch_id: c.branch_id, branch_name: c.branch_name }; });

              const allBranches = [...new Map(
                companies
                  .filter(c => c.branch_id)
                  .map(c => [c.branch_id, { branch_id: c.branch_id, branch_name: c.branch_name || c.branch_id }])
              ).values()].sort((a, b) => (a.branch_name || '').localeCompare(b.branch_name || ''));

              if (allBranches.length <= 1) {
                // No hay branches distintos, renderizar sin filtro
                return (
                  <SalesAnalyticsDashboard
                    targets={rawTargets}
                    budgets={budgets}
                    policies={policies}
                    agents={agents}
                  />
                );
              }

              const branchCompanyIds = analyticsBranch === '__all__'
                ? null
                : new Set(companies.filter(c => c.branch_id === analyticsBranch).map(c => c.id));

              const filteredPolicies = branchCompanyIds
                ? policies.filter(p => branchCompanyIds.has(p.company_id))
                : policies;

              const filteredTargets = branchCompanyIds
                ? rawTargets.filter(t =>
                    !t.companies || t.companies.length === 0
                      ? false // si no tiene compañías no sabemos a qué branch pertenece, excluir
                      : t.companies.some(c => branchCompanyIds.has(c.company_id))
                  )
                : rawTargets;

              const filteredBudgets = branchCompanyIds
                ? budgets.filter(b => !b.company_id || branchCompanyIds.has(b.company_id))
                : budgets;

              return (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground font-medium">Branch:</span>
                    <div className="flex gap-2 flex-wrap">
                      <button
                        onClick={() => setAnalyticsBranch('__all__')}
                        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          analyticsBranch === '__all__'
                            ? 'bg-primary text-white'
                            : 'bg-muted text-muted-foreground hover:bg-secondary'
                        }`}
                      >
                        Todos
                      </button>
                      {allBranches.map(b => (
                        <button
                          key={b.branch_id}
                          onClick={() => setAnalyticsBranch(b.branch_id)}
                          className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                            analyticsBranch === b.branch_id
                              ? 'bg-primary text-white'
                              : 'bg-muted text-muted-foreground hover:bg-secondary'
                          }`}
                        >
                          {b.branch_name}
                        </button>
                      ))}
                    </div>
                  </div>
                  <SalesAnalyticsDashboard
                    targets={filteredTargets}
                    budgets={filteredBudgets}
                    policies={filteredPolicies}
                    agents={agents}
                  />
                </div>
              );
            })()}
          </TabsContent>

          <TabsContent value="budget">
            <div className="flex justify-end mb-4">
              <Button onClick={() => handleOpenBudgetForm()} className="bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Presupuesto
              </Button>
            </div>

            <div className="space-y-4">
              {budgets.map(budget => (
                <FlippableBudgetCard
                  key={budget.id}
                  budget={budget}
                  onEdit={handleOpenBudgetForm}
                  onDelete={handleDeleteBudget}
                />
              ))}

              {budgets.length === 0 && (
                <Card className="p-8">
                  <div className="text-center text-muted-foreground">
                    <Briefcase className="h-12 w-12 mx-auto mb-3 text-muted-foreground/70" />
                    <p className="text-lg font-medium mb-1">No hay presupuestos creados</p>
                    <p className="text-sm">Crea presupuestos para medir el cumplimiento de ventas por periodo, aseguradora o ramo.</p>
                  </div>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingTarget ? 'Editar Objetivo' : 'Nuevo Objetivo de Ventas'}</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Tipo de Objetivo *</Label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        value="individual"
                        checked={watch('target_type') === 'individual'}
                        onChange={(e) => setValue('target_type', e.target.value)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm">Individual</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        value="structure"
                        checked={watch('target_type') === 'structure'}
                        onChange={(e) => setValue('target_type', e.target.value)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        Por Estructura
                      </span>
                    </label>
                  </div>
                  {watch('target_type') === 'structure' && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Se incluirá la producción del agente y toda su estructura (downline)
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Agente {watch('target_type') === 'structure' ? '(Cabeza de Estructura)' : ''} *</Label>
                  <AgentSelect
                    agents={[...agents].sort((a, b) => a.name.localeCompare(b.name))}
                    value={watch('agent_id') || ''}
                    onValueChange={(v) => setValue('agent_id', v)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Métrica *</Label>
                  <Select value={watch('metric') || ''} onValueChange={(v) => setValue('metric', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new_policies">Pólizas Nuevas</SelectItem>
                      <SelectItem value="premium_volume">Volumen de Prima</SelectItem>
                      <SelectItem value="commission_value">Valor en Comisiones</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Valor Objetivo *</Label>
                  <Input {...register('target_value', { required: true })} type="number" step="0.01" placeholder="100" />
                </div>

                <div className="space-y-2">
                  <Label>Bono (opcional)</Label>
                  <Input {...register('bonus_amount')} type="number" step="0.01" placeholder="1000" />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Fecha Inicio *</Label>
                  <Input {...register('start_date', { required: true })} type="date" />
                </div>

                <div className="space-y-2">
                  <Label>Fecha Fin *</Label>
                  <Input {...register('end_date', { required: true })} type="date" />
                </div>

                <div className="space-y-2">
                  <Label>Estado</Label>
                  <Select value={watch('status') || 'activo'} onValueChange={(v) => setValue('status', v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activo">Activo</SelectItem>
                      <SelectItem value="completado">Completado</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Ramos *</Label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox 
                        checked={allLines}
                        onCheckedChange={(checked) => {
                          setAllLines(checked);
                          if (checked) setSelectedLines([]);
                        }}
                      />
                      <span className="text-sm">Todos los ramos</span>
                    </label>
                    
                    {!allLines && (
                      <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto p-2 border rounded bg-muted/40">
                        {lines.map(line => (
                          <div key={line.id} className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              id={`line_${line.id}`}
                              checked={selectedLines.some(l => l.line_id === line.id)}
                              onChange={() => toggleLineSelection(line)}
                              className="rounded"
                            />
                            <label htmlFor={`line_${line.id}`} className="text-sm cursor-pointer text-foreground/80">
                              {line.name}
                            </label>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Compañías (opcional)</Label>
                  <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto p-2 border rounded bg-muted/40">
                    {companies.length === 0 ? (
                      <p className="text-sm text-muted-foreground col-span-2">No hay compañías disponibles</p>
                    ) : (
                      companies.map(company => (
                        <div key={company.id} className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id={`company_${company.id}`}
                            checked={selectedCompanies.some(c => c.company_id === company.id)}
                            onChange={() => toggleCompanySelection(company)}
                            className="rounded"
                          />
                          <label htmlFor={`company_${company.id}`} className="text-sm cursor-pointer text-foreground/80">
                            {company.name}
                          </label>
                        </div>
                      ))
                    )}
                  </div>
                  {selectedCompanies.length > 0 && (
                    <div className="text-xs text-muted-foreground mt-2">
                      {selectedCompanies.length} compañía(s) seleccionada(s)
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90">
                  {editingTarget ? 'Guardar Cambios' : 'Crear Objetivo'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={budgetOpen} onOpenChange={setBudgetOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingBudget ? 'Editar Presupuesto' : 'Nuevo Presupuesto de Compañía'}</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmitBudget(onSubmitBudget)} className="space-y-4">
              {/* Fila 1: Nombre */}
              <div className="space-y-1">
                <Label>Nombre del Presupuesto *</Label>
                <Input {...registerBudget('name', { required: true })} placeholder="Ej: Q1 2024, Presupuesto Salud, etc." />
              </div>

              {/* Fila 2: Fechas + Moneda + Monto */}
              <div className="grid grid-cols-4 gap-3">
                <div className="space-y-1">
                  <Label>Fecha Inicio *</Label>
                  <Input {...registerBudget('start_date', { required: true })} type="date" />
                </div>
                <div className="space-y-1">
                  <Label>Fecha Fin *</Label>
                  <Input {...registerBudget('end_date', { required: true })} type="date" />
                </div>
                <div className="space-y-1">
                  <Label>Moneda</Label>
                  <Select value={watchBudget('currency') || 'USD'} onValueChange={(v) => setValueBudget('currency', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['USD','COP','MXN','EUR','PEN','CLP','ARS'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Monto Objetivo *</Label>
                  <Input {...registerBudget('target_amount', { required: true })} type="number" step="0.01" placeholder="100000" />
                </div>
              </div>

              {/* Fila 3: Aseguradora + Ramo + Estado */}
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label>Aseguradora (opcional)</Label>
                  <Select value={watchBudget('company_id') || ''} onValueChange={(v) => { setValueBudget('company_id', v || null); setSelectedBudgetProducts([]); }}>
                    <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Todas las aseguradoras</SelectItem>
                      {companies.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Ramo (opcional)</Label>
                  <Select value={watchBudget('line_id') || ''} onValueChange={(v) => setValueBudget('line_id', v || null)}>
                    <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Todos los ramos</SelectItem>
                      {lines.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Estado</Label>
                  <Select value={watchBudget('status') || 'activo'} onValueChange={(v) => setValueBudget('status', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="activo">Activo</SelectItem>
                      <SelectItem value="completado">Completado</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Productos (solo si hay compañía seleccionada) */}
              {watchBudget('company_id') && (() => {
                const companyProducts = products.filter(p => p.company_id === watchBudget('company_id') && p.status === 'activo');
                return companyProducts.length > 0 ? (
                  <div className="space-y-1 border rounded-lg p-3 bg-muted/40">
                    <div className="flex items-center justify-between mb-1">
                      <Label>Productos a medir (opcional)</Label>
                      {selectedBudgetProducts.length > 0 && (
                        <span className="text-xs text-foreground font-medium">{selectedBudgetProducts.length} seleccionado(s)</span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">Sin selección = todos los productos de la compañía.</p>
                    <div className="grid grid-cols-3 gap-2 max-h-32 overflow-y-auto">
                      {companyProducts.map(product => (
                        <label key={product.id} htmlFor={`budprod_${product.id}`} className="flex items-start gap-2 cursor-pointer p-1.5 rounded hover:bg-card border border-transparent hover:border-border transition-colors">
                          <input
                            type="checkbox"
                            id={`budprod_${product.id}`}
                            checked={selectedBudgetProducts.some(p => p.product_id === product.id)}
                            onChange={() => toggleBudgetProduct(product)}
                            className="rounded mt-0.5 shrink-0"
                          />
                          <span className="text-sm text-foreground/80 leading-tight">
                            {product.product_name}
                            {product.line_name && <span className="text-xs text-muted-foreground/70 block">{product.line_name}</span>}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                ) : null;
              })()}

              {/* Solo Nuevo Negocio */}
              <div className="flex items-center gap-2 p-3 border rounded-lg bg-muted/40">
                <Checkbox
                  id="only_new_business"
                  checked={budgetOnlyNewBusiness}
                  onCheckedChange={(checked) => setBudgetOnlyNewBusiness(!!checked)}
                />
                <label htmlFor="only_new_business" className="text-sm font-medium text-foreground/80 cursor-pointer">
                  Solo Nuevo Negocio
                  <span className="block text-xs text-muted-foreground/70 font-normal">Excluye renovaciones, cambios de broker y cesiones de cartera</span>
                </label>
              </div>

              {/* Notas */}
              <div className="space-y-1">
                <Label>Notas (opcional)</Label>
                <Textarea {...registerBudget('notes')} placeholder="Observaciones adicionales..." rows={2} />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t">
                <Button type="button" variant="outline" onClick={() => setBudgetOpen(false)}>Cancelar</Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90">
                  {editingBudget ? 'Guardar Cambios' : 'Crear Presupuesto'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <AlertDialog open={!!deleteTargetId} onOpenChange={(o) => !o && setDeleteTargetId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar objetivo?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTarget} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deleteBudgetId} onOpenChange={(o) => !o && setDeleteBudgetId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar presupuesto?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteBudget} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}