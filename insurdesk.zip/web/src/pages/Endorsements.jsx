import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import { FileEdit, Loader2, TrendingUp, TrendingDown } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function Endorsements() {
  const [endorsements, setEndorsements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
    api.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const loadData = async () => {
    setLoading(true);
    const data = await api.entities.Endorsement.list('-created_date');
    setEndorsements(data);
    setLoading(false);
  };

  const applyEndorsement = async (endorsement) => {
    if (endorsement.status !== 'aprobado') {
      alert('El endoso debe estar aprobado para ser aplicado');
      return;
    }

    const policy = await api.entities.Policy.filter({ id: endorsement.policy_id });
    if (!policy[0]) return;

    // Handle cancellation
    if (endorsement.endorsement_type === 'cancelacion') {
      await api.entities.Policy.update(endorsement.policy_id, {
        status: 'cancelada',
        annual_premium: endorsement.new_annual_premium,
        commissionable_premium: endorsement.new_annual_premium
      });
    } else if (endorsement.premium_difference && endorsement.premium_difference !== 0) {
      // Update policy premium for other types
      await api.entities.Policy.update(endorsement.policy_id, {
        annual_premium: endorsement.new_annual_premium,
        commissionable_premium: endorsement.new_annual_premium
      });
    }

    // Generate commissions (positive or negative)
    if (endorsement.premium_difference && endorsement.premium_difference !== 0) {
      await generateEndorsementCommissions(endorsement, policy[0]);
    }

    // Update endorsement status
    await api.entities.Endorsement.update(endorsement.id, { status: 'aplicado' });

    // Create notification
    await api.entities.Notification.create({
      notification_type: 'endoso_aplicado',
      recipient_type: 'agente',
      recipient_id: policy[0]?.agent_id,
      recipient_email: policy[0]?.created_by,
      recipient_name: policy[0]?.agent_name,
      title: 'Endoso Aplicado',
      message: `El endoso ${endorsement.endorsement_number} ha sido aplicado a la póliza ${endorsement.policy_number}`,
      related_entity_type: 'Endorsement',
      related_entity_id: endorsement.id,
      notification_date: new Date().toISOString().split('T')[0]
    });

    loadData();
  };

  const generateEndorsementCommissions = async (endorsement, policy) => {
    const agents = await api.entities.Agent.list();
    const assignments = await api.entities.AgentCommissionAssignment.filter({
      company_id: policy.company_id,
      line_id: policy.line_id
    });

    const agent = agents.find(a => a.id === policy.agent_id);
    if (!agent) return;

    // Generate commissions for agent hierarchy
    const agentHierarchy = [];
    let currentAgent = agent;
    let level = 1;

    while (currentAgent) {
      agentHierarchy.push({ agent: currentAgent, level });
      if (currentAgent.upline_agent_id) {
        currentAgent = agents.find(a => a.id === currentAgent.upline_agent_id);
        level++;
      } else {
        break;
      }
    }

    for (const { agent: hierarchyAgent, level } of agentHierarchy) {
      const assignment = assignments.find(a => a.agent_id === hierarchyAgent.id);
      if (!assignment) continue;

      const commissionTable = await api.entities.CommissionTable.filter({ 
        id: assignment.commission_table_id 
      });
      if (!commissionTable[0]) continue;

      const productCommission = commissionTable[0].product_commissions?.find(
        pc => pc.product_id === policy.product_id
      );
      if (!productCommission) continue;

      const commissionPct = productCommission.new_business_percentage || 0;
      const baseAmount = endorsement.premium_difference;
      const commissionAmount = (baseAmount * commissionPct) / 100;

      const sourceType = endorsement.endorsement_type === 'cancelacion' 
        ? 'cancelacion' 
        : endorsement.endorsement_type === 'inclusion_dependiente'
          ? 'inclusion_dependiente'
          : baseAmount > 0 ? 'aumento_prima' : 'reduccion_prima';

      await api.entities.Commission.create({
        policy_id: policy.id,
        policy_number: policy.policy_number,
        product_id: policy.product_id,
        product_name: policy.product_name,
        company_id: policy.company_id,
        company_name: policy.company_name,
        agent_id: hierarchyAgent.id,
        agent_name: hierarchyAgent.name,
        client_name: policy.client_name,
        level: level,
        base_amount: baseAmount,
        commission_pct: commissionPct,
        commission_amount: commissionAmount,
        currency: policy.currency,
        generation_date: new Date().toISOString().split('T')[0],
        status: 'pendiente_liberar',
        source_type: sourceType,
        notes: `Generada por endoso ${endorsement.endorsement_number} - ${endorsement.endorsement_type.replace(/_/g, ' ')}`
      });
    }
  };

  const columns = [
    { header: 'Número', accessorKey: 'endorsement_number' },
    { header: 'Póliza', accessorKey: 'policy_number' },
    { 
      header: 'Tipo', 
      cell: (row) => (
        <span className="capitalize text-sm">
          {row.endorsement_type?.replace(/_/g, ' ')}
        </span>
      )
    },
    { 
      header: 'Fecha', 
      cell: (row) => format(new Date(row.endorsement_date), 'dd/MM/yyyy', { locale: es })
    },
    { 
      header: 'Diferencia Prima', 
      cell: (row) => row.premium_difference ? (
        <div className="flex items-center gap-1">
          {row.premium_difference > 0 ? (
            <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
          ) : row.premium_difference < 0 ? (
            <TrendingDown className="h-4 w-4 text-red-600 dark:text-red-400" />
          ) : null}
          <span className={row.premium_difference > 0 ? 'text-green-600 dark:text-green-400' : row.premium_difference < 0 ? 'text-red-600 dark:text-red-400' : ''}>
            {row.premium_difference?.toLocaleString()}
          </span>
        </div>
      ) : '-'
    },
    { header: 'Estado', cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: 'Acción',
      cell: (row) => {
        const canApply = currentUser && (currentUser.role === 'admin' || currentUser.app_role === 'admin' || currentUser.app_role === 'operativo');
        return row.status === 'aprobado' && canApply ? (
          <Button size="sm" onClick={() => applyEndorsement(row)}>
            Aplicar
          </Button>
        ) : null;
      }
    }
  ];

  const filteredEndorsements = statusFilter === 'all' 
    ? endorsements 
    : endorsements.filter(e => e.status === statusFilter);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Endosos"
          subtitle="Gestión de modificaciones a pólizas"
          icon={FileEdit}
        />

        <Card className="border-0 shadow-sm p-6">
          <DataTable
            columns={columns}
            data={filteredEndorsements}
            searchable={true}
            searchPlaceholder="Buscar por número o póliza..."
            emptyMessage="No hay endosos registrados"
          />
        </Card>
      </div>
    </div>
  );
}