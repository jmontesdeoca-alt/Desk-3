import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import BackButton from '@/components/ui/BackButton';
import { 
  User, Phone, MapPin, Briefcase, Camera, Save, 
  Loader2, Lock, Trash2, Shield, Mail, FileText
} from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';
import { Globe } from 'lucide-react';

export default function UserProfile() {
  const { t, i18n } = useTranslation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Profile fields
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [position, setPosition] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const userData = await api.auth.me();
    setUser(userData);
    setDisplayName(userData.display_name || userData.full_name || '');
    setPhone(userData.phone || '');
    setAddress(userData.address || '');
    setPosition(userData.position || '');
    setBio(userData.bio || '');
    setAvatarUrl(userData.avatar_url || '');
    setLoading(false);
  };

  const handleSaveProfile = async () => {
    setSaving(true);
    await api.auth.updateMe({
      display_name: displayName.toUpperCase(),
      phone,
      address,
      position,
      bio,
      avatar_url: avatarUrl
    });
    toast.success('Perfil actualizado correctamente');
    setSaving(false);
    setTimeout(() => window.location.reload(), 800);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingAvatar(true);
    const { file_url } = await api.integrations.Core.UploadFile({ file });
    setAvatarUrl(file_url);
    await api.auth.updateMe({ avatar_url: file_url });
    toast.success('Foto actualizada');
    setUploadingAvatar(false);
  };

  const handleDeleteAccount = async () => {
    setDeleting(true);
    await api.auth.updateMe({ status: 'inactive', app_role: null });
    toast.success('Cuenta desactivada. Cerrando sesión...');
    setTimeout(() => api.auth.logout(), 1500);
  };

  const getRoleLabel = (role) => {
    const labels = {
      admin: 'Administrador', gerencial: 'Gerencial', jefatura: 'Jefatura',
      operativo: 'Operativo', financiero: 'Financiero', agente: 'Agente'
    };
    return labels[role] || role;
  };

  const getInitials = () => {
    const name = displayName || user?.full_name || user?.email || '?';
    return name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-3xl mx-auto">

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <BackButton />
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-muted">
              <User className="h-6 w-6 text-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Mi Perfil</h1>
              <p className="text-sm text-muted-foreground">Gestiona tu información personal y configuración de cuenta</p>
            </div>
          </div>
        </div>

        {/* Avatar + Info básica */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={avatarUrl} />
                  <AvatarFallback className="bg-primary text-white text-2xl font-bold">
                    {getInitials()}
                  </AvatarFallback>
                </Avatar>
                <label className="absolute -bottom-1 -right-1 bg-card border border-border rounded-full p-1.5 cursor-pointer shadow-sm hover:bg-muted/40 transition-colors">
                  {uploadingAvatar 
                    ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                    : <Camera className="h-4 w-4 text-muted-foreground" />
                  }
                  <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
                </label>
              </div>
              <div className="text-center sm:text-left">
                <h2 className="text-xl font-bold text-foreground">
                  {displayName || user?.full_name || 'Sin nombre'}
                </h2>
                <p className="text-muted-foreground flex items-center justify-center sm:justify-start gap-1 mt-1">
                  <Mail className="h-3.5 w-3.5" /> {user?.email}
                </p>
                <div className="flex items-center justify-center sm:justify-start gap-2 mt-2">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-muted text-foreground">
                    <Shield className="h-3 w-3" /> {getRoleLabel(user?.app_role)}
                  </span>
                  {position && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-muted text-foreground/80">
                      <Briefcase className="h-3 w-3" /> {position}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Datos Personales */}
        <Card className="border-0 shadow-sm mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-5 w-5 text-muted-foreground" /> Datos Personales
            </CardTitle>
            <CardDescription>Tu información de contacto y presentación en la plataforma</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5 text-muted-foreground/70" /> Nombre para mostrar
                </Label>
                <Input
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value.toUpperCase())}
                  placeholder="TU NOMBRE COMPLETO"
                  className="uppercase"
                />
                <p className="text-xs text-muted-foreground/70">Este nombre aparecerá en toda la aplicación</p>
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <Briefcase className="h-3.5 w-3.5 text-muted-foreground/70" /> Cargo
                </Label>
                <Input
                  value={position}
                  onChange={(e) => setPosition(e.target.value)}
                  placeholder="Ej: Asesor Comercial"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <Phone className="h-3.5 w-3.5 text-muted-foreground/70" /> Teléfono
                </Label>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+593 999 999 999"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-muted-foreground/70" /> Dirección
                </Label>
                <Input
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Ciudad, País"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-1.5">
                <FileText className="h-3.5 w-3.5 text-muted-foreground/70" /> Descripción breve
              </Label>
              <Textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Cuéntanos un poco sobre ti..."
                className="resize-none"
                rows={3}
              />
            </div>

            <div className="flex justify-end pt-2">
              <Button onClick={handleSaveProfile} disabled={saving} className="gap-2">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Guardar Cambios
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Información de Cuenta (solo lectura) */}
        <Card className="border-0 shadow-sm mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="h-5 w-5 text-muted-foreground" /> Información de Cuenta
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div className="bg-muted/40 rounded-lg p-4">
                <p className="text-xs text-muted-foreground/70 uppercase font-medium mb-1">Email</p>
                <p className="font-medium text-foreground/80">{user?.email}</p>
              </div>
              <div className="bg-muted/40 rounded-lg p-4">
                <p className="text-xs text-muted-foreground/70 uppercase font-medium mb-1">Rol</p>
                <p className="font-medium text-foreground/80">{getRoleLabel(user?.app_role)}</p>
              </div>
              <div className="bg-muted/40 rounded-lg p-4">
                <p className="text-xs text-muted-foreground/70 uppercase font-medium mb-1">Miembro desde</p>
                <p className="font-medium text-foreground/80">
                  {user?.created_date ? new Date(user.created_date).toLocaleDateString('es-ES', { year: 'numeric', month: 'long' }) : '-'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Idioma */}
        <Card className="border-0 shadow-sm mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Globe className="h-5 w-5 text-muted-foreground" /> {t('settings.language')}
            </CardTitle>
            <CardDescription>Elige el idioma de la interfaz</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <button
                onClick={() => i18n.changeLanguage('es')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-all ${
                  i18n.language === 'es' || i18n.language?.startsWith('es')
                    ? 'bg-primary text-white border-primary shadow-sm'
                    : 'bg-card text-foreground/80 border-border hover:border-input hover:bg-muted/40'
                }`}
              >
                🇪🇸 Español
              </button>
              <button
                onClick={() => i18n.changeLanguage('en')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-all ${
                  i18n.language === 'en' || i18n.language?.startsWith('en')
                    ? 'bg-primary text-white border-primary shadow-sm'
                    : 'bg-card text-foreground/80 border-border hover:border-input hover:bg-muted/40'
                }`}
              >
                🇺🇸 English
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Cambiar Contraseña */}
        <Card className="border-0 shadow-sm mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Lock className="h-5 w-5 text-muted-foreground" /> Seguridad
            </CardTitle>
            <CardDescription>Restablece tu contraseña de acceso</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Se enviará un enlace de restablecimiento de contraseña a <strong>{user?.email}</strong>.
            </p>
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={async () => {
                await api.users.inviteUser(user.email, user.role);
                toast.success('Enlace de restablecimiento enviado a tu correo');
              }}
            >
              <Lock className="h-4 w-4" />
              Enviar enlace de cambio de contraseña
            </Button>
          </CardContent>
        </Card>

        {/* Zona de Peligro */}
        <Card className="border-0 shadow-sm border-red-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-red-600 dark:text-red-400">
              <Trash2 className="h-5 w-5" /> Zona de Peligro
            </CardTitle>
            <CardDescription>Acciones irreversibles sobre tu cuenta</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-red-500/10 border border-red-100 rounded-lg p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <p className="font-medium text-foreground text-sm">Eliminar mi cuenta</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Se desactivará tu acceso al sistema. Esta acción no se puede deshacer.
                </p>
              </div>
              <Button 
                variant="destructive" 
                size="sm"
                className="gap-2 shrink-0"
                onClick={() => setDeleteDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4" /> Eliminar cuenta
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar tu cuenta?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción desactivará permanentemente tu acceso al sistema. No podrás iniciar sesión nuevamente hasta que un administrador reactive tu cuenta.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleting ? 'Procesando...' : 'Sí, eliminar mi cuenta'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}