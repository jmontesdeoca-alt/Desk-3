import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/lib/AuthContext';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PageHeader from '@/components/ui/PageHeader';
import DataTable from '@/components/ui/DataTable';
import StatusBadge from '@/components/ui/StatusBadge';
import StatCard from '@/components/ui/StatCard';
import { RefreshCw, Loader2, Plus, CheckCircle, XCircle, Clock, AlertTriangle, Download, Search, Pencil } from 'lucide-react';
import { exportToExcel } from '@/components/ui/exportUtils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AgentSelect from '@/components/forms/AgentSelect';
import { differenceInDays, addYears } from 'date-fns';
import { es } from 'date-fns/locale';
import { formatDate, formatDateTime, parseLocalDate } from '@/lib/dateUtils';
import { toast } from 'sonner';

export default function Renewals() {
  const { user: contextUser, userRoleInfo } = useAuth();
  const [renewals, setRenewals] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [agents, setAgents] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedAgentFilter, setSelectedAgentFilter] = useState('all');
  const [branches, setBranches] = useState([]);
  const [selectedBranchFilter, setSelectedBranchFilter] = useState(() => localStorage.getItem('renewals-branch-filter') || 'all');
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState(null);
  const [saving, setSaving] = useState(false);
  const [confirmingId, setConfirmingId] = useState(null); // tracks which renewal is being confirmed
  const [selectedRenewalIds, setSelectedRenewalIds] = useState(new Set()); // batch selection
  const [batchProgress, setBatchProgress] = useState(null); // { current, total } during batch
  
  const [renewalForm, setRenewalForm] = useState({
    new_premium: 0,
    new_commissionable_premium: 0,
    payment_frequency: 'mensual',
    new_start_date: '',
    new_end_date: '',
    deductible_1: '',
    deductible_2: ''
  });
  const [selectedPolicyProduct, setSelectedPolicyProduct] = useState(null); // product for create form
  const [editingRenewalProduct, setEditingRenewalProduct] = useState(null); // product for edit form

  // Edit proposal state
  const [editOpen, setEditOpen] = useState(false);
  const [editingRenewal, setEditingRenewal] = useState(null);
  const [editForm, setEditForm] = useState({
    new_premium: 0,
    new_commissionable_premium: 0,
    payment_frequency: 'mensual',
    new_start_date: '',
    new_end_date: '',
    deductible_1: '',
    deductible_2: ''
  });

  useEffect(() => {
    if (contextUser && userRoleInfo) loadData();
  }, [contextUser, userRoleInfo]);

  useEffect(() => {
    localStorage.setItem('renewals-branch-filter', selectedBranchFilter);
  }, [selectedBranchFilter]);

  const [updatingStatuses, setUpdatingStatuses] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const isAgente = currentUser?.app_role === 'agente';

  const getAgentStructure = async (agentId) => {
    const allAgents = await api.entities.Agent.list();
    const structure = [agentId];
    const findDownline = (id) => {
      allAgents.filter(a => a.upline_agent_id === id).forEach(a => {
        structure.push(a.id);
        findDownline(a.id);
      });
    };
    findDownline(agentId);
    return structure;
  };

  const loadData = async () => {
    setLoading(true);
    // Use user from AuthContext (already loaded by Layout) — avoids redundant auth.me() call
    const currentUser = contextUser && userRoleInfo ? {
      ...contextUser,
      app_role: userRoleInfo.app_role,
      agent_id: userRoleInfo.agent_id
    } : null;
    setCurrentUser(currentUser);

    // Stagger API calls into smaller batches to avoid rate limit
    const [propuestasData, historialData] = await Promise.all([
      api.entities.Renewal.filter({ status: 'propuesta' }, '-created_date', 2000),
      api.entities.Renewal.filter({ status: { $in: ['confirmada', 'rechazada'] } }, '-updated_date', 1000)
    ]);
    const [policiesData, agentsData] = await Promise.all([
      api.entities.Policy.list('-end_date', 5000),
      api.entities.Agent.list('name', 500)
    ]);
    const [productsData, branchesData] = await Promise.all([
      api.entities.Product.list('product_name', 1000),
      api.entities.Branch.list('name', 500)
    ]);

    let filteredPolicies = policiesData;
    // Sort: propuestas first (by created_date desc), then historial (by updated_date desc — most recently confirmed first)
    let filteredRenewals = [
      ...propuestasData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)),
      ...historialData
    ];

    if (currentUser.app_role === 'gerencial' && currentUser.agent_id) {
      const agentStructure = await getAgentStructure(currentUser.agent_id);
      const structureSet = new Set(agentStructure);
      filteredPolicies = policiesData.filter(p => structureSet.has(p.agent_id));
      const allowedPolicyIds = new Set(filteredPolicies.map(p => p.id));
      filteredRenewals = filteredRenewals.filter(r => allowedPolicyIds.has(r.original_policy_id));
    }

    setRenewals(filteredRenewals);
    setPolicies(filteredPolicies);
    setAgents(agentsData.filter(a => a.status === 'activo'));
    setProducts(productsData);
    setBranches(branchesData.filter(b => b.status === 'activo'));
    setLoading(false);
  };

  // Lightweight refresh: reload only renewal proposals (not 5000 policies)
  const refreshRenewals = async () => {
    const [propuestasData, historialData] = await Promise.all([
      api.entities.Renewal.filter({ status: 'propuesta' }, '-created_date', 2000),
      api.entities.Renewal.filter({ status: { $in: ['confirmada', 'rechazada'] } }, '-updated_date', 1000)
    ]);
    let filteredRenewals = [
      ...propuestasData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)),
      ...historialData
    ];
    if (currentUser?.app_role === 'gerencial' && currentUser?.agent_id) {
      const agentStructure = await getAgentStructure(currentUser.agent_id);
      const structureSet = new Set(agentStructure);
      const allowedPolicyIds = new Set(policies.filter(p => structureSet.has(p.agent_id)).map(p => p.id));
      filteredRenewals = filteredRenewals.filter(r => allowedPolicyIds.has(r.original_policy_id));
    }
    setRenewals(filteredRenewals);
  };

  // Reload policies so original (renovada) leaves "Por Renovar" and new policy appears in Policies page
  const reloadPolicies = async () => {
    try {
      const policiesData = await api.entities.Policy.list('-end_date', 5000);
      let filteredPolicies = policiesData;
      if (currentUser?.app_role === 'gerencial' && currentUser?.agent_id) {
        const agentStructure = await getAgentStructure(currentUser.agent_id);
        const structureSet = new Set(agentStructure);
        filteredPolicies = policiesData.filter(p => structureSet.has(p.agent_id));
      }
      setPolicies(filteredPolicies);
    } catch (err) {
      console.error('Error reloading policies:', err);
    }
  };

  const exportPendingRenewals = () => {
    const headers = [
      'Cliente', 'Agente', 'Compañía', 'Producto', 'Fecha Vencimiento', 'Número de Póliza',
      'Prima Anterior', 'Prima Nueva (Oferta)', '% Incremento', 'Moneda', 'Frecuencia de Pago', 'Días Restantes', 'Estado Renovación'
    ];

    // Pólizas sin propuesta aún (las que están por vencer o vencidas sin renovación activa)
    const sinPropuesta = branchFilteredPolicies.filter(p => {
      if (!p.end_date) return false;
      if (['renovada', 'cancelada'].includes(p.status)) return false;
      const hasActiveRenewal = branchFilteredRenewals.some(r => r.original_policy_id === p.id && r.status !== 'rechazada');
      if (hasActiveRenewal) return false;
      const daysUntilEnd = differenceInDays(parseLocalDate(p.end_date), today);
      return daysUntilEnd <= RENEWAL_WINDOW_DAYS;
    });

    // Pólizas que ya tienen una propuesta de renovación activa
    const conPropuesta = branchFilteredPolicies.filter(p => {
      if (!p.end_date) return false;
      if (['renovada', 'cancelada'].includes(p.status)) return false;
      return branchFilteredRenewals.some(r => r.original_policy_id === p.id && r.status === 'propuesta');
    });

    const todasParaExportar = [
      ...sinPropuesta.map(p => ({ policy: p, renewal: null })),
      ...conPropuesta.map(p => ({
        policy: p,
        renewal: branchFilteredRenewals.find(r => r.original_policy_id === p.id && r.status === 'propuesta')
      }))
    ].sort((a, b) => (a.policy.agent_name || '').localeCompare(b.policy.agent_name || ''));

    const rows = todasParaExportar.map(({ policy: p, renewal: oferta }) => {
      const primaNueva = oferta ? oferta.new_premium : '';
      const primaAnterior = oferta ? oferta.current_premium : p.annual_premium;
      const pctIncremento = oferta && primaAnterior
        ? parseFloat(((oferta.new_premium - primaAnterior) / primaAnterior * 100).toFixed(2))
        : '';
      const estadoRenovacion = oferta ? 'Con propuesta' : 'Sin propuesta';
      return [
        p.client_name || '',
        p.agent_name || '',
        p.company_name || '',
        p.product_name || '',
        p.end_date ? formatDate(p.end_date, 'dd/MM/yyyy') : '',
        p.policy_number || '',
        primaAnterior || 0,
        primaNueva,
        pctIncremento,
        p.currency || 'USD',
        (oferta?.payment_frequency || p.payment_frequency || ''),
        p.end_date ? differenceInDays(parseLocalDate(p.end_date), today) : '',
        estadoRenovacion,
      ];
    });
    exportToExcel({ headers, rows, filename: 'Renovaciones_Pendientes' });
  };

  const updateExpiredPolicies = async () => {
    setUpdatingStatuses(true);
    try {
      const res = await api.functions.invoke('updateExpiredPolicies', {});
      const { updated, message } = res.data;
      if (updated > 0) await loadData();
      toast.success(message);
    } finally {
      setUpdatingStatuses(false);
    }
  };

  const [expiringTab, setExpiringTab] = useState('proximas'); // 'proximas' | 'vencidas'
  const [expiringPage, setExpiringPage] = useState(1);
  const [expiredPage, setExpiredPage] = useState(1);
  const [policySearch, setPolicySearch] = useState('');
  const EXPIRING_PAGE_SIZE = 10;

  // Get policies that need renewal: expiring within 60 days OR already expired (but not yet renewed/cancelled)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const RENEWAL_WINDOW_DAYS = 60;

  // Branch filter (applied before agent filter; both combine with AND logic)
  const branchFilteredPolicies = selectedBranchFilter === 'all'
    ? policies
    : policies.filter(p => p.branch_id === selectedBranchFilter);
  const branchFilteredRenewals = selectedBranchFilter === 'all'
    ? renewals
    : renewals.filter(r => {
        const policy = policies.find(p => p.id === r.original_policy_id);
        return policy?.branch_id === selectedBranchFilter;
      });

  // Agents that have at least one pending renewal (expiring/expired policy or active renewal proposal)
  const agentsWithPendingRenewals = (() => {
    const relevantAgentIds = new Set();
    branchFilteredPolicies.forEach(p => {
      if (!p.end_date) return;
      if (['renovada', 'cancelada'].includes(p.status)) return;
      const daysUntilEnd = differenceInDays(parseLocalDate(p.end_date), today);
      if (daysUntilEnd <= RENEWAL_WINDOW_DAYS && p.agent_id) {
        relevantAgentIds.add(p.agent_id);
      }
    });
    branchFilteredRenewals.forEach(r => {
      if (r.status === 'propuesta') {
        const policy = policies.find(p => p.id === r.original_policy_id);
        if (policy?.agent_id) relevantAgentIds.add(policy.agent_id);
      }
    });
    return agents.filter(a => relevantAgentIds.has(a.id));
  })();
  const agentFilteredPolicies = selectedAgentFilter === 'all'
    ? branchFilteredPolicies
    : branchFilteredPolicies.filter(p => p.agent_id === selectedAgentFilter);
  const agentFilteredRenewals = selectedAgentFilter === 'all'
    ? branchFilteredRenewals
    : branchFilteredRenewals.filter(r => {
        const policy = policies.find(p => p.id === r.original_policy_id);
        return policy?.agent_id === selectedAgentFilter;
      });
  const expiringPolicies = agentFilteredPolicies.filter(p => {
    if (!p.end_date) return false;
    // Exclude statuses that don't need renewal action
    if (['renovada', 'cancelada'].includes(p.status)) return false;
    // Exclude if already has an active renewal in progress
    const hasActiveRenewal = agentFilteredRenewals.some(r => r.original_policy_id === p.id && r.status !== 'rechazada');
    if (hasActiveRenewal) return false;
    const daysUntilEnd = differenceInDays(parseLocalDate(p.end_date), today);
    // Show if expiring within 60 days (including already expired: daysUntilEnd <= 0)
    return daysUntilEnd <= RENEWAL_WINDOW_DAYS;
  }).sort((a, b) => parseLocalDate(a.end_date) - parseLocalDate(b.end_date));

  const searchMatch = (p) => {
    if (!policySearch.trim()) return true;
    const q = policySearch.toLowerCase();
    return (p.policy_number || '').toLowerCase().includes(q) || (p.client_name || '').toLowerCase().includes(q);
  };

  // Proximas: expiring within 60 days but NOT yet expired (daysLeft >= 0)
  const proximas = expiringPolicies.filter(p => differenceInDays(parseLocalDate(p.end_date), today) >= 0 && searchMatch(p));
  // Vencidas: already past end_date (daysLeft < 0)
  const vencidas = expiringPolicies.filter(p => differenceInDays(parseLocalDate(p.end_date), today) < 0 && searchMatch(p))
    .sort((a, b) => parseLocalDate(b.end_date) - parseLocalDate(a.end_date));

  const expiringPaged = proximas.slice((expiringPage - 1) * EXPIRING_PAGE_SIZE, expiringPage * EXPIRING_PAGE_SIZE);
  const expiringTotalPages = Math.ceil(proximas.length / EXPIRING_PAGE_SIZE);
  const expiredPaged = vencidas.slice((expiredPage - 1) * EXPIRING_PAGE_SIZE, expiredPage * EXPIRING_PAGE_SIZE);
  const expiredTotalPages = Math.ceil(vencidas.length / EXPIRING_PAGE_SIZE);

  const checkRenewalAllowed = async (policy, newStartDate, newEndDate, excludeRenewalId) => {
    try {
      const res = await api.functions.invoke('validateRenewal', {
        original_policy_id: policy.id,
        new_start_date: newStartDate,
        new_end_date: newEndDate,
        exclude_renewal_id: excludeRenewalId
      });
      const data = res?.data;
      if (data && !data.canRenew) {
        toast.error(data.reason || 'Esta póliza ya tiene una renovación activa para este período.');
        return false;
      }
      return true;
    } catch (err) {
      console.error('Error validating renewal:', err);
      return true;
    }
  };

  const handleAutoRenew = async (policy) => {
    // Auto-renew based on product configuration
    const product = await api.entities.Product.filter({ id: policy.product_id });
    if (!product[0] || !product[0].allows_renewal) {
      toast.error('Este producto no permite renovación automática');
      return;
    }

    const endDate = parseLocalDate(policy.end_date);
    if (!endDate) { toast.error('La póliza no tiene fecha de fin'); return; }
    const newStartDate = new Date(endDate);
    newStartDate.setDate(newStartDate.getDate() + 1);
    const newEndDate = new Date(newStartDate);
    newEndDate.setFullYear(newEndDate.getFullYear() + 1);

    // Validar antes de renovar
    const allowed = await checkRenewalAllowed(
      policy,
      newStartDate.toISOString().split('T')[0],
      newEndDate.toISOString().split('T')[0]
    );
    if (!allowed) return;

    setSaving(true);

    const newPolicyNumber = `${policy.policy_number}-R${Date.now().toString().slice(-4)}`;

    // Create renewed policy
    const newPolicy = await api.entities.Policy.create({
      policy_number: newPolicyNumber,
      client_id: policy.client_id,
      client_name: policy.client_name,
      product_id: policy.product_id,
      product_name: policy.product_name,
      company_id: policy.company_id,
      company_name: policy.company_name,
      line_id: policy.line_id,
      line_name: policy.line_name,
      agent_id: policy.agent_id,
      agent_name: policy.agent_name,
      currency: policy.currency,
      annual_premium: policy.annual_premium,
      commissionable_premium: policy.commissionable_premium,
      payment_frequency: policy.payment_frequency,
      installment_amount: policy.installment_amount,
      start_date: newStartDate.toISOString().split('T')[0],
      end_date: newEndDate.toISOString().split('T')[0],
      status: 'activa',
      policy_type: 'renovacion',
      country: policy.country,
      insured_amount: policy.insured_amount,
      deductible_1: policy.deductible_1,
      deductible_2: policy.deductible_2,
      sum_insured: policy.sum_insured,
      dependents: policy.dependents,
      renewed_from_policy_id: policy.id
    });

    // Generate payment schedule
    const frequencyMap = { mensual: 12, trimestral: 4, semestral: 2, anual: 1, unico: 1 };
    const installments = frequencyMap[policy.payment_frequency] || 12;
    
    for (let i = 0; i < installments; i++) {
      const dueDate = new Date(newStartDate);
      if (policy.payment_frequency === 'mensual') dueDate.setMonth(dueDate.getMonth() + i);
      else if (policy.payment_frequency === 'trimestral') dueDate.setMonth(dueDate.getMonth() + (i * 3));
      else if (policy.payment_frequency === 'semestral') dueDate.setMonth(dueDate.getMonth() + (i * 6));
      
      await api.entities.Payment.create({
        policy_id: newPolicy.id,
        policy_number: newPolicyNumber,
        client_name: policy.client_name,
        due_date: dueDate.toISOString().split('T')[0],
        period: `${dueDate.toLocaleString('es', { month: 'long', year: 'numeric' })}`,
        amount: policy.installment_amount,
        currency: policy.currency,
        status: 'pendiente',
        installment_number: i + 1
      });
    }

    // Update original policy
    await api.entities.Policy.update(policy.id, { status: 'renovada' });

    // Create notification
    await api.entities.Notification.create({
      notification_type: 'renovacion_disponible',
      recipient_type: 'agente',
      recipient_id: policy.agent_id,
      recipient_email: policy.created_by,
      recipient_name: policy.agent_name,
      title: 'Póliza Renovada Automáticamente',
      message: `La póliza ${policy.policy_number} ha sido renovada automáticamente con número ${newPolicyNumber}`,
      related_entity_type: 'Policy',
      related_entity_id: newPolicy.id,
      notification_date: new Date().toISOString().split('T')[0]
    });

    setSaving(false);
    toast.success('Póliza renovada automáticamente con número ' + newPolicyNumber);
    loadData();
  };

  const openRenewalForm = (policy) => {
    setSelectedPolicy(policy);
    const product = products.find(p => p.id === policy.product_id) || null;
    setSelectedPolicyProduct(product);

    const newStartDate = parseLocalDate(policy.end_date);
    if (!newStartDate) return;
    newStartDate.setDate(newStartDate.getDate() + 1);
    const newEndDate = addYears(newStartDate, 1);

    // Pre-fill deductibles from policy (which came from product originally)
    const d1Options = product?.deductible_1_options || [];
    const d2Options = product?.deductible_2_options || [];

    setRenewalForm({
      new_premium: policy.annual_premium,
      new_commissionable_premium: policy.commissionable_premium,
      payment_frequency: policy.payment_frequency,
      new_start_date: newStartDate.toISOString().split('T')[0],
      new_end_date: newEndDate.toISOString().split('T')[0],
      deductible_1: policy.deductible_1 != null ? String(policy.deductible_1) : (d1Options.length > 0 ? String(d1Options[0]) : ''),
      deductible_2: policy.deductible_2 != null ? String(policy.deductible_2) : (d2Options.length > 0 ? String(d2Options[0]) : ''),
    });
    setFormOpen(true);
  };

  const handleCreateRenewal = async () => {
    if (!selectedPolicy) return;

    // Validar antes de crear propuesta
    const allowed = await checkRenewalAllowed(
      selectedPolicy,
      renewalForm.new_start_date,
      renewalForm.new_end_date
    );
    if (!allowed) return;

    setSaving(true);
    await api.entities.Renewal.create({
      original_policy_id: selectedPolicy.id,
      original_policy_number: selectedPolicy.policy_number,
      client_name: selectedPolicy.client_name,
      product_name: selectedPolicy.product_name,
      renewal_date: new Date().toISOString().split('T')[0],
      new_start_date: renewalForm.new_start_date,
      new_end_date: renewalForm.new_end_date,
      current_premium: selectedPolicy.annual_premium,
      new_premium: parseFloat(renewalForm.new_premium),
      new_commissionable_premium: parseFloat(renewalForm.new_commissionable_premium),
      payment_frequency: renewalForm.payment_frequency,
      currency: selectedPolicy.currency,
      status: 'propuesta',
      deductible_1: renewalForm.deductible_1 !== '' ? parseFloat(renewalForm.deductible_1) : null,
      deductible_2: renewalForm.deductible_2 !== '' ? parseFloat(renewalForm.deductible_2) : null,
    });
    
    // Update policy status
    await api.entities.Policy.update(selectedPolicy.id, { status: 'en_renovacion' });
    
    setSaving(false);
    setFormOpen(false);
    setSelectedPolicy(null);
    loadData();
  };

  const confirmRenewal = async (renewal) => {
    setConfirmingId(renewal.id);
    setSaving(true);

    try {
      const res = await api.functions.invoke('confirmRenewal', { renewal_id: renewal.id });
      const result = res?.data;

      if (!result || !result.success) {
        throw new Error(result?.error || 'Error al confirmar renovación');
      }

      // Optimistic update: mark renewal as confirmada + original policy as renovada in local state immediately
      setRenewals(prev => prev.map(r => r.id === renewal.id ? { ...r, status: 'confirmada', new_policy_id: result.new_policy_id } : r));
      setPolicies(prev => prev.map(p => p.id === renewal.original_policy_id ? { ...p, status: 'renovada' } : p));

      toast.success(`Renovación confirmada. Nueva póliza: ${result.new_policy_number}`);
      refreshRenewals();
      // Reload policies so the original leaves "Por Renovar" and the new one appears in Policies
      reloadPolicies();
    } catch (err) {
      toast.error(err.message || 'Error al confirmar renovación');
    } finally {
      setSaving(false);
      setConfirmingId(null);
    }
  };

  const confirmRenewalBatch = async () => {
    const ids = Array.from(selectedRenewalIds);
    if (ids.length === 0) return;

    setSaving(true);
    setBatchProgress({ current: 0, total: ids.length });

    try {
      const res = await api.functions.invoke('confirmRenewalBatch', { renewal_ids: ids });
      const result = res?.data;

      if (!result) throw new Error('Sin respuesta del servidor');

      // Update local state: move confirmed ones, keep failed ones as propuesta
      const confirmedIds = new Set((result.confirmed || []).map(c => c.renewal_id));
      const confirmedOriginalPolicyIds = new Set(
        renewals.filter(r => confirmedIds.has(r.id)).map(r => r.original_policy_id)
      );
      setRenewals(prev => prev.map(r => {
        if (confirmedIds.has(r.id)) {
          const c = result.confirmed.find(x => x.renewal_id === r.id);
          return { ...r, status: 'confirmada', new_policy_id: c?.new_policy_id };
        }
        return r;
      }));
      // Mark original policies as renovada in local state so they leave "Por Renovar"
      setPolicies(prev => prev.map(p => confirmedOriginalPolicyIds.has(p.id) ? { ...p, status: 'renovada' } : p));

      const failedCount = result.failed_count || 0;
      const confirmedCount = result.confirmed_count || 0;

      if (failedCount > 0) {
        toast.warning(`Lote completado: ${confirmedCount} confirmadas, ${failedCount} fallidas`, {
          description: result.failed.map(f => `${f.renewal_id.slice(-6)}: ${f.error}`).join('\n')
        });
      } else {
        toast.success(`Lote completado: ${confirmedCount} renovaciones confirmadas`);
      }

      setSelectedRenewalIds(new Set());
      refreshRenewals();
      reloadPolicies();
    } catch (err) {
      toast.error(err.message || 'Error al procesar lote');
    } finally {
      setSaving(false);
      setBatchProgress(null);
    }
  };

  const openEditForm = (renewal) => {
    setEditingRenewal(renewal);
    // Find the policy to get its product_id
    const policy = policies.find(p => p.id === renewal.original_policy_id);
    const product = policy ? products.find(pr => pr.id === policy.product_id) || null : null;
    setEditingRenewalProduct(product);

    setEditForm({
      new_premium: renewal.new_premium,
      new_commissionable_premium: renewal.new_commissionable_premium || renewal.new_premium,
      payment_frequency: renewal.payment_frequency || 'mensual',
      new_start_date: renewal.new_start_date,
      new_end_date: renewal.new_end_date,
      deductible_1: renewal.deductible_1 != null ? String(renewal.deductible_1) : '',
      deductible_2: renewal.deductible_2 != null ? String(renewal.deductible_2) : '',
    });
    setEditOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!editingRenewal) return;
    setSaving(true);
    await api.entities.Renewal.update(editingRenewal.id, {
      new_premium: parseFloat(editForm.new_premium),
      new_commissionable_premium: parseFloat(editForm.new_commissionable_premium),
      payment_frequency: editForm.payment_frequency,
      new_start_date: editForm.new_start_date,
      new_end_date: editForm.new_end_date,
      deductible_1: editForm.deductible_1 !== '' ? parseFloat(editForm.deductible_1) : null,
      deductible_2: editForm.deductible_2 !== '' ? parseFloat(editForm.deductible_2) : null,
    });
    setSaving(false);
    setEditOpen(false);
    setEditingRenewal(null);
    toast.success('Propuesta actualizada correctamente');
    loadData();
  };

  const rejectRenewal = async (renewal) => {
    await api.entities.Renewal.update(renewal.id, { status: 'rechazada' });
    
    // Reset policy status
    const originalPolicy = await api.entities.Policy.filter({ id: renewal.original_policy_id });
    if (originalPolicy.length > 0) {
      await api.entities.Policy.update(renewal.original_policy_id, { status: 'activa' });
    }
    
    loadData();
  };

  // Stats
  const proposed = agentFilteredRenewals.filter(r => r.status === 'propuesta').length;
  const confirmed = agentFilteredRenewals.filter(r => r.status === 'confirmada').length;
  const rejected = agentFilteredRenewals.filter(r => r.status === 'rechazada').length;
  const expiring15 = expiringPolicies.filter(p => differenceInDays(parseLocalDate(p.end_date), today) <= 15).length;
  const alreadyExpired = expiringPolicies.filter(p => differenceInDays(parseLocalDate(p.end_date), today) < 0).length;

  const renewalColumns = [
    {
      header: '',
      cell: (row) => row.status === 'propuesta' && !isAgente && (
        <input
          type="checkbox"
          checked={selectedRenewalIds.has(row.id)}
          onChange={(e) => {
            e.stopPropagation();
            setSelectedRenewalIds(prev => {
              const next = new Set(prev);
              if (e.target.checked) next.add(row.id);
              else next.delete(row.id);
              return next;
            });
          }}
          className="h-4 w-4 rounded border-input cursor-pointer"
        />
      )
    },
    {
      header: 'Póliza Original',
      cell: (row) => (
        <Link to={createPageUrl(`PolicyDetail?id=${row.original_policy_id}`)} className="text-foreground hover:underline">
          {row.original_policy_number}
        </Link>
      )
    },
    { header: 'Cliente', accessorKey: 'client_name' },
    { header: 'Producto', accessorKey: 'product_name' },
    {
      header: 'Prima Actual',
      cell: (row) => `${row.currency} ${row.current_premium?.toLocaleString()}`
    },
    {
      header: 'Prima Nueva',
      cell: (row) => `${row.currency} ${row.new_premium?.toLocaleString()}`
    },
    {
      header: 'Nueva Vigencia',
      cell: (row) => (
        <span className="text-sm">
          {row.new_start_date ? formatDate(row.new_start_date, 'dd/MM/yy') : ''} - {' '}
          {row.new_end_date ? formatDate(row.new_end_date, 'dd/MM/yy') : ''}
        </span>
      )
    },
    {
      header: 'Nueva Póliza',
      cell: (row) => row.new_policy_id ? (
        <Link to={createPageUrl(`PolicyDetail?id=${row.new_policy_id}`)} className="text-foreground hover:underline font-medium">
          {row.original_policy_number}-R{row.new_start_date ? parseLocalDate(row.new_start_date)?.getFullYear() : new Date().getFullYear()}
        </Link>
      ) : <span className="text-slate-300">—</span>
    },
    {
      header: 'Fecha',
      cell: (row) => (
        <span className="text-xs text-muted-foreground">
          {row.status === 'confirmada' && row.updated_date
            ? formatDateTime(row.updated_date, 'dd/MM/yy HH:mm')
            : row.created_date
              ? formatDateTime(row.created_date, 'dd/MM/yy')
              : ''}
        </span>
      )
    },
    { header: 'Estado', cell: (row) => <StatusBadge status={row.status} /> },
    {
      header: 'Acciones',
      cell: (row) => row.status === 'propuesta' && !isAgente && (
        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={() => confirmRenewal(row)}
            disabled={saving}
            className="gap-1 min-w-[110px]"
          >
            {confirmingId === row.id ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Procesando...
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4" />
                Confirmar
              </>
            )}
          </Button>
          <Button size="sm" variant="outline" onClick={() => openEditForm(row)} disabled={saving} title="Editar propuesta">
            <Pencil className="h-4 w-4" />
          </Button>
          <Button size="sm" variant="outline" onClick={() => rejectRenewal(row)} disabled={saving} title="Rechazar propuesta">
            <XCircle className="h-4 w-4" />
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start justify-between mb-6">
          <PageHeader
            title="Renovaciones"
            subtitle="Gestión de renovaciones de pólizas"
            icon={RefreshCw}
            backTo="Dashboard"
          />
          {!isAgente && (
            <div className="flex gap-2 mt-1">
              <Button
                variant="outline"
                size="sm"
                onClick={exportPendingRenewals}
                disabled={expiringPolicies.length === 0 && agentFilteredRenewals.filter(r => r.status === 'propuesta').length === 0}
                className="gap-2"
              >
                <Download className="h-4 w-4" />
                Exportar pendientes
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={updateExpiredPolicies}
                disabled={updatingStatuses}
                className="gap-2"
              >
                {updatingStatuses ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                Actualizar estados
              </Button>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title="Propuestas"
            value={proposed}
            icon={Clock}
            iconBg="bg-muted"
            iconColor="text-foreground"
          />
          <StatCard
            title="Confirmadas"
            value={confirmed}
            icon={CheckCircle}
            iconBg="bg-emerald-500/10"
            iconColor="text-emerald-600 dark:text-emerald-400"
          />
          <StatCard
            title="Rechazadas"
            value={rejected}
            icon={XCircle}
            iconBg="bg-red-500/10"
            iconColor="text-red-600 dark:text-red-400"
          />
          <StatCard
            title="Urgentes (≤15 días / vencidas)"
            value={expiring15}
            icon={AlertTriangle}
            iconBg="bg-amber-500/10"
            iconColor="text-amber-600 dark:text-amber-400"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-4 p-3 bg-card rounded-lg border border-border shadow-sm">
          <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">Sede:</span>
          <div className="w-56">
            <Select
              value={selectedBranchFilter}
              onValueChange={(v) => { setSelectedBranchFilter(v); setExpiringPage(1); setExpiredPage(1); }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todas las sedes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las sedes</SelectItem>
                {branches.map(b => (
                  <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">Agente:</span>
          <div className="w-72">
            <AgentSelect
              agents={agentsWithPendingRenewals}
              value={selectedAgentFilter === 'all' ? '' : selectedAgentFilter}
              onValueChange={(v) => { setSelectedAgentFilter(v || 'all'); setExpiringPage(1); setExpiredPage(1); }}
            />
          </div>
          {(selectedBranchFilter !== 'all' || selectedAgentFilter !== 'all') && (
            <Button variant="ghost" size="sm" onClick={() => { setSelectedBranchFilter('all'); setSelectedAgentFilter('all'); setExpiringPage(1); setExpiredPage(1); }} className="text-muted-foreground/70 hover:text-muted-foreground">
              × Limpiar
            </Button>
          )}
        </div>

        <Tabs defaultValue="por_renovar" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="por_renovar" className="gap-2">
              <AlertTriangle className="h-4 w-4" />
              Por Renovar
              <span className="ml-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs px-1.5 py-0.5 rounded-full font-semibold">
                {expiringPolicies.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="propuestas" className="gap-2">
              <Clock className="h-4 w-4" />
              Con Propuesta
              <span className="ml-1 bg-muted text-foreground text-xs px-1.5 py-0.5 rounded-full font-semibold">
                {agentFilteredRenewals.filter(r => r.status === 'propuesta').length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="historial" className="gap-2">
              <CheckCircle className="h-4 w-4" />
              Renovadas / Rechazadas
              <span className="ml-1 bg-muted text-muted-foreground text-xs px-1.5 py-0.5 rounded-full font-semibold">
                {agentFilteredRenewals.filter(r => r.status === 'confirmada' || r.status === 'rechazada').length}
              </span>
            </TabsTrigger>
          </TabsList>

          {/* TAB 1: Por Renovar */}
          <TabsContent value="por_renovar">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  Pólizas por Renovar
                </CardTitle>
                {/* Search */}
                <div className="relative mt-2">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground/70" />
                  <Input
                    className="pl-8 h-9 text-sm"
                    placeholder="Buscar por nro. póliza o cliente..."
                    value={policySearch}
                    onChange={e => { setPolicySearch(e.target.value); setExpiringPage(1); setExpiredPage(1); }}
                  />
                </div>
                {/* Sub-tabs */}
                <div className="flex gap-1 mt-2 bg-muted rounded-lg p-1">
                  <button
                    onClick={() => { setExpiringTab('proximas'); setExpiringPage(1); }}
                    className={`flex-1 text-sm py-1.5 px-2 rounded-md font-medium transition-colors ${
                      expiringTab === 'proximas' ? 'bg-card shadow text-amber-600 dark:text-amber-400' : 'text-muted-foreground hover:text-foreground/80'
                    }`}
                  >
                    Por Vencer <span className="ml-1 text-xs">({proximas.length})</span>
                  </button>
                  <button
                    onClick={() => { setExpiringTab('vencidas'); setExpiredPage(1); }}
                    className={`flex-1 text-sm py-1.5 px-2 rounded-md font-medium transition-colors ${
                      expiringTab === 'vencidas' ? 'bg-card shadow text-red-600 dark:text-red-400' : 'text-muted-foreground hover:text-foreground/80'
                    }`}
                  >
                    Vencidas <span className="ml-1 text-xs">({vencidas.length})</span>
                  </button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 max-h-[600px] overflow-y-auto">
                {expiringTab === 'proximas' && (
                  <>
                    {proximas.length === 0 ? (
                      <p className="text-center text-muted-foreground/70 py-8">No hay pólizas próximas a vencer</p>
                    ) : (
                      expiringPaged.map(policy => {
                        const daysLeft = differenceInDays(parseLocalDate(policy.end_date), today);
                        const hasRenewal = renewals.some(r => r.original_policy_id === policy.id && r.status !== 'rechazada');
                        return (
                          <div key={policy.id} className="p-3 bg-muted/40 rounded-lg">
                            <div className="flex items-start justify-between">
                              <div>
                                <Link to={createPageUrl(`PolicyDetail?id=${policy.id}`)} className="font-medium text-foreground hover:text-foreground">
                                  {policy.policy_number}
                                </Link>
                                <p className="text-sm text-muted-foreground">{policy.client_name}</p>
                                <p className="text-xs text-muted-foreground/70">{policy.product_name}</p>
                                <div className="flex gap-3 mt-1">
                                  {policy.agent_name && <p className="text-xs text-foreground">👤 {policy.agent_name}</p>}
                                  {policy.company_name && <p className="text-xs text-muted-foreground">🏢 {policy.company_name}</p>}
                                </div>
                              </div>
                              <div className="text-right">
                                <span className={`text-sm font-medium ${daysLeft <= 15 ? 'text-red-600 dark:text-red-400' : daysLeft <= 30 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground'}`}>
                                  {daysLeft} días
                                </span>
                                <p className="text-xs text-muted-foreground/70">{formatDate(policy.end_date, 'dd MMM', { locale: es })}</p>
                              </div>
                            </div>
                            {!hasRenewal && !isAgente && (
                              <div className="grid grid-cols-2 gap-2 mt-2">
                                <Button size="sm" variant="outline" className="gap-1" onClick={() => handleAutoRenew(policy)}>
                                  <RefreshCw className="h-3 w-3" /> Auto
                                </Button>
                                <Button size="sm" className="gap-1" onClick={() => openRenewalForm(policy)}>
                                  <Plus className="h-3 w-3" /> Manual
                                </Button>
                              </div>
                            )}
                            {hasRenewal && <p className="text-center text-sm text-foreground mt-2">Renovación en proceso</p>}
                          </div>
                        );
                      })
                    )}
                    {expiringTotalPages > 1 && (
                      <div className="flex items-center justify-between pt-2 border-t">
                        <span className="text-xs text-muted-foreground">{proximas.length} pólizas · Pág {expiringPage}/{expiringTotalPages}</span>
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" disabled={expiringPage === 1} onClick={() => setExpiringPage(p => p - 1)}>‹</Button>
                          <Button size="sm" variant="outline" disabled={expiringPage === expiringTotalPages} onClick={() => setExpiringPage(p => p + 1)}>›</Button>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {expiringTab === 'vencidas' && (
                  <>
                    {vencidas.length === 0 ? (
                      <p className="text-center text-muted-foreground/70 py-8">No hay pólizas vencidas sin renovar</p>
                    ) : (
                      expiredPaged.map(policy => {
                        const daysExpired = Math.abs(differenceInDays(parseLocalDate(policy.end_date), today));
                        const hasRenewal = renewals.some(r => r.original_policy_id === policy.id && r.status !== 'rechazada');
                        return (
                          <div key={policy.id} className="p-3 bg-red-500/10 border border-red-100 rounded-lg">
                            <div className="flex items-start justify-between">
                              <div>
                                <Link to={createPageUrl(`PolicyDetail?id=${policy.id}`)} className="font-medium text-foreground hover:text-foreground">
                                  {policy.policy_number}
                                </Link>
                                <p className="text-sm text-muted-foreground">{policy.client_name}</p>
                                <p className="text-xs text-muted-foreground/70">{policy.product_name}</p>
                                <div className="flex gap-3 mt-1">
                                  {policy.agent_name && <p className="text-xs text-foreground">👤 {policy.agent_name}</p>}
                                  {policy.company_name && <p className="text-xs text-muted-foreground">🏢 {policy.company_name}</p>}
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="text-sm font-bold text-red-600 dark:text-red-400">
                                  Hace {daysExpired}d
                                </span>
                                <p className="text-xs text-muted-foreground/70">{formatDate(policy.end_date, 'dd MMM yyyy', { locale: es })}</p>
                              </div>
                            </div>
                            {!hasRenewal && !isAgente && (
                              <div className="grid grid-cols-2 gap-2 mt-2">
                                <Button size="sm" variant="outline" className="gap-1" onClick={() => handleAutoRenew(policy)}>
                                  <RefreshCw className="h-3 w-3" /> Auto
                                </Button>
                                <Button size="sm" className="gap-1 bg-red-600 hover:bg-red-700" onClick={() => openRenewalForm(policy)}>
                                  <Plus className="h-3 w-3" /> Manual
                                </Button>
                              </div>
                            )}
                            {hasRenewal && <p className="text-center text-sm text-foreground mt-2">Renovación en proceso</p>}
                          </div>
                        );
                      })
                    )}
                    {expiredTotalPages > 1 && (
                      <div className="flex items-center justify-between pt-2 border-t">
                        <span className="text-xs text-muted-foreground">{vencidas.length} pólizas · Pág {expiredPage}/{expiredTotalPages}</span>
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" disabled={expiredPage === 1} onClick={() => setExpiredPage(p => p - 1)}>‹</Button>
                          <Button size="sm" variant="outline" disabled={expiredPage === expiredTotalPages} onClick={() => setExpiredPage(p => p + 1)}>›</Button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* TAB 2: Con Propuesta */}
          <TabsContent value="propuestas">
            <Card className="border-0 shadow-sm p-6">
              <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <Clock className="h-5 w-5 text-foreground" />
                  Propuestas de Renovación Pendientes
                </h3>
                {!isAgente && selectedRenewalIds.size > 0 && (
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{selectedRenewalIds.size} seleccionada(s)</span>
                    <Button
                      size="sm"
                      onClick={confirmRenewalBatch}
                      disabled={saving}
                      className="gap-2"
                    >
                      {batchProgress ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Procesando {batchProgress.current}/{batchProgress.total}...
                        </>
                      ) : (
                        <>
                          <CheckCircle className="h-4 w-4" />
                          Confirmar seleccionadas ({selectedRenewalIds.size})
                        </>
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedRenewalIds(new Set())}
                      disabled={saving}
                    >
                      Limpiar
                    </Button>
                  </div>
                )}
              </div>
              <DataTable
                columns={renewalColumns}
                data={agentFilteredRenewals.filter(r => r.status === 'propuesta')}
                searchPlaceholder="Buscar por póliza o cliente..."
                searchKeys={['original_policy_number', 'client_name', 'product_name']}
                emptyMessage="No hay propuestas de renovación activas"
                pageSize={50}
              />
            </Card>
          </TabsContent>

          {/* TAB 3: Renovadas / Rechazadas */}
          <TabsContent value="historial">
            <Card className="border-0 shadow-sm p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-emerald-500" />
                Historial de Renovaciones
              </h3>
              <DataTable
                columns={renewalColumns}
                data={agentFilteredRenewals.filter(r => r.status === 'confirmada' || r.status === 'rechazada')}
                searchPlaceholder="Buscar por póliza o cliente..."
                emptyMessage="No hay renovaciones confirmadas o rechazadas"
              />
            </Card>
          </TabsContent>
        </Tabs>

        {/* Edit Proposal Dialog */}
        <Dialog open={editOpen} onOpenChange={setEditOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Propuesta de Renovación</DialogTitle>
            </DialogHeader>
            {editingRenewal && (
              <div className="space-y-6">
                <div className="p-4 bg-muted/40 rounded-lg">
                  <p className="text-sm text-muted-foreground">Póliza</p>
                  <p className="font-semibold">{editingRenewal.original_policy_number}</p>
                  <p className="text-sm">{editingRenewal.client_name}</p>
                  <p className="text-sm text-muted-foreground">{editingRenewal.product_name}</p>
                  <p className="text-sm font-medium mt-2">
                    Prima actual: {editingRenewal.currency} {editingRenewal.current_premium?.toLocaleString()}
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nueva Prima Anual</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={editForm.new_premium}
                        onChange={(e) => setEditForm({...editForm, new_premium: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Prima Comisionable</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={editForm.new_commissionable_premium}
                        onChange={(e) => setEditForm({...editForm, new_commissionable_premium: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Frecuencia de Pago</Label>
                    <Select
                      value={editForm.payment_frequency}
                      onValueChange={(value) => setEditForm({...editForm, payment_frequency: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mensual">Mensual</SelectItem>
                        <SelectItem value="trimestral">Trimestral</SelectItem>
                        <SelectItem value="semestral">Semestral</SelectItem>
                        <SelectItem value="anual">Anual</SelectItem>
                        <SelectItem value="unico">Único</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Vigencia Desde</Label>
                      <Input
                        type="date"
                        value={editForm.new_start_date}
                        onChange={(e) => setEditForm({...editForm, new_start_date: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Vigencia Hasta</Label>
                      <Input
                        type="date"
                        value={editForm.new_end_date}
                        onChange={(e) => setEditForm({...editForm, new_end_date: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Deducible 1 (País)</Label>
                      {editingRenewalProduct?.deductible_1_options?.length > 0 ? (
                        <Select
                          value={editForm.deductible_1}
                          onValueChange={(v) => setEditForm({...editForm, deductible_1: v})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione deducible" />
                          </SelectTrigger>
                          <SelectContent>
                            {editingRenewalProduct.deductible_1_options.map(opt => (
                              <SelectItem key={opt} value={String(opt)}>{opt.toLocaleString()}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Ingrese deducible"
                          value={editForm.deductible_1}
                          onChange={(e) => setEditForm({...editForm, deductible_1: e.target.value})}
                        />
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label>Deducible 2 (Internacional)</Label>
                      {editingRenewalProduct?.deductible_2_options?.length > 0 ? (
                        <Select
                          value={editForm.deductible_2}
                          onValueChange={(v) => setEditForm({...editForm, deductible_2: v})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione deducible" />
                          </SelectTrigger>
                          <SelectContent>
                            {editingRenewalProduct.deductible_2_options.map(opt => (
                              <SelectItem key={opt} value={String(opt)}>{opt.toLocaleString()}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Ingrese deducible"
                          value={editForm.deductible_2}
                          onChange={(e) => setEditForm({...editForm, deductible_2: e.target.value})}
                        />
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setEditOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleSaveEdit} disabled={saving}>
                    {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Guardar Cambios
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Renewal Form Dialog */}
        <Dialog open={formOpen} onOpenChange={setFormOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crear Propuesta de Renovación</DialogTitle>
            </DialogHeader>
            
            {selectedPolicy && (
              <div className="space-y-6">
                <div className="p-4 bg-muted/40 rounded-lg">
                  <p className="text-sm text-muted-foreground">Póliza a renovar</p>
                  <p className="font-semibold">{selectedPolicy.policy_number}</p>
                  <p className="text-sm">{selectedPolicy.client_name}</p>
                  <p className="text-sm text-muted-foreground">{selectedPolicy.product_name}</p>
                  <p className="text-sm font-medium mt-2">
                    Prima actual: {selectedPolicy.currency} {selectedPolicy.annual_premium?.toLocaleString()}
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nueva Prima Anual</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={renewalForm.new_premium}
                        onChange={(e) => setRenewalForm({...renewalForm, new_premium: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Prima Comisionable</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={renewalForm.new_commissionable_premium}
                        onChange={(e) => setRenewalForm({...renewalForm, new_commissionable_premium: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Frecuencia de Pago</Label>
                    <Select 
                      value={renewalForm.payment_frequency}
                      onValueChange={(value) => setRenewalForm({...renewalForm, payment_frequency: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mensual">Mensual</SelectItem>
                        <SelectItem value="trimestral">Trimestral</SelectItem>
                        <SelectItem value="semestral">Semestral</SelectItem>
                        <SelectItem value="anual">Anual</SelectItem>
                        <SelectItem value="unico">Único</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nueva Vigencia Desde</Label>
                      <Input
                        type="date"
                        value={renewalForm.new_start_date}
                        onChange={(e) => setRenewalForm({...renewalForm, new_start_date: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nueva Vigencia Hasta</Label>
                      <Input
                        type="date"
                        value={renewalForm.new_end_date}
                        onChange={(e) => setRenewalForm({...renewalForm, new_end_date: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Deducible 1 (País)</Label>
                      {selectedPolicyProduct?.deductible_1_options?.length > 0 ? (
                        <Select
                          value={renewalForm.deductible_1}
                          onValueChange={(v) => setRenewalForm({...renewalForm, deductible_1: v})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione deducible" />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedPolicyProduct.deductible_1_options.map(opt => (
                              <SelectItem key={opt} value={String(opt)}>{opt.toLocaleString()}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Ingrese deducible"
                          value={renewalForm.deductible_1}
                          onChange={(e) => setRenewalForm({...renewalForm, deductible_1: e.target.value})}
                        />
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label>Deducible 2 (Internacional)</Label>
                      {selectedPolicyProduct?.deductible_2_options?.length > 0 ? (
                        <Select
                          value={renewalForm.deductible_2}
                          onValueChange={(v) => setRenewalForm({...renewalForm, deductible_2: v})}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione deducible" />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedPolicyProduct.deductible_2_options.map(opt => (
                              <SelectItem key={opt} value={String(opt)}>{opt.toLocaleString()}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Ingrese deducible"
                          value={renewalForm.deductible_2}
                          onChange={(e) => setRenewalForm({...renewalForm, deductible_2: e.target.value})}
                        />
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setFormOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleCreateRenewal} disabled={saving}>
                    {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Crear Propuesta
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}