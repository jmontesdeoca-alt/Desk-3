import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import DataTable from '@/components/ui/DataTable';
import { TrendingUp, TrendingDown, DollarSign, Loader2, Download, Eye } from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';

export default function AgentProfitability() {
  const [agents, setAgents] = useState([]);
  const [profitabilityData, setProfitabilityData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [calculating, setCalculating] = useState(false);
  
  // Filters
  const [dateFrom, setDateFrom] = useState(format(startOfMonth(subMonths(new Date(), 2)), 'yyyy-MM-dd'));
  const [dateTo, setDateTo] = useState(format(endOfMonth(new Date()), 'yyyy-MM-dd'));
  const [countryFilter, setCountryFilter] = useState('all');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [lineFilter, setLineFilter] = useState('all');
  const [usePaidOnly, setUsePaidOnly] = useState(false);
  
  const [companies, setCompanies] = useState([]);
  const [lines, setLines] = useState([]);
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [agentsData, companiesData, linesData, userRoleResp] = await Promise.all([
      api.entities.Agent.list(),
      api.entities.InsuranceCompany.list(),
      api.entities.InsuranceLine.list(),
      api.functions.invoke('getUserRoleInfo', {})
    ]);

    const appRole = userRoleResp?.data?.app_role;
    const linkedAgentId = userRoleResp?.data?.agent_id;

    let filteredAgents = agentsData;
    if (appRole === 'gerencial' && linkedAgentId) {
      const structureIds = [];
      const findStructure = (id) => {
        structureIds.push(id);
        agentsData.filter(a => a.upline_agent_id === id).forEach(child => findStructure(child.id));
      };
      findStructure(linkedAgentId);
      filteredAgents = agentsData.filter(a => structureIds.includes(a.id));
    }
    
    setAgents(filteredAgents);
    setCompanies(companiesData);
    setLines(linesData);
    
    // Extract unique countries
    const uniqueCountries = [...new Set(filteredAgents.map(a => a.country).filter(Boolean))];
    setCountries(uniqueCountries);
    
    setLoading(false);
  };

  const calculateProfitability = async () => {
    setCalculating(true);
    
    // Get all commissions in date range
    const allCommissions = await api.entities.Commission.list();
    const filteredCommissions = allCommissions.filter(c => {
      const commDate = c.generation_date;
      if (commDate < dateFrom || commDate > dateTo) return false;
      if (usePaidOnly && c.status !== 'pagada') return false;
      if (companyFilter !== 'all' && c.company_id !== companyFilter) return false;
      if (lineFilter !== 'all' && c.product_id) {
        // Would need to check product's line - simplified here
        return true;
      }
      return true;
    });
    
    // Get all costs in date range
    const allCosts = await api.entities.AgentCost.list();
    const filteredCosts = allCosts.filter(c => {
      const costDate = c.date;
      if (costDate < dateFrom || costDate > dateTo) return false;
      if (c.status === 'anulado' || c.status === 'reversado') return false;
      return true;
    });
    
    // Get all policies to calculate margins
    const allPolicies = await api.entities.Policy.list();
    
    // Calculate per agent
    const agentProfitability = agents
      .filter(agent => {
        if (countryFilter !== 'all' && agent.country !== countryFilter) return false;
        return agent.status === 'activo';
      })
      .map(agent => {
        // Commissions paid to this agent
        const agentCommissions = filteredCommissions.filter(c => c.agent_id === agent.id);
        const totalCommissionPaid = agentCommissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);
        const totalBaseAmount = agentCommissions.reduce((sum, c) => sum + (c.base_amount || 0), 0);
        
        // Calculate margin (this is simplified - in reality we'd need company tope)
        // For now: margin = base * estimated company % (assume 5% margin on average)
        const estimatedMargin = totalBaseAmount * 0.05;
        
        // Costs
        const agentCosts = filteredCosts.filter(c => c.agent_id === agent.id);
        const totalCosts = agentCosts.reduce((sum, c) => sum + (c.amount || 0), 0);
        
        // Profitability
        const profitability = estimatedMargin - totalCosts;
        const profitabilityPct = totalBaseAmount > 0 ? (profitability / totalBaseAmount * 100) : 0;
        
        return {
          agent_id: agent.id,
          agent_name: agent.name,
          country: agent.country,
          total_base: totalBaseAmount,
          total_commission_paid: totalCommissionPaid,
          margin_empresa: estimatedMargin,
          total_costs: totalCosts,
          profitability: profitability,
          profitability_pct: profitabilityPct,
          num_policies: agentCommissions.length
        };
      })
      .filter(p => p.total_base > 0); // Only show agents with activity
    
    setProfitabilityData(agentProfitability);
    setCalculating(false);
  };

  useEffect(() => {
    if (!loading) {
      calculateProfitability();
    }
  }, [dateFrom, dateTo, countryFilter, companyFilter, lineFilter, usePaidOnly, loading]);

  const exportToCSV = () => {
    const headers = ['Agente', 'País', 'Base Comisionable', 'Comisión Pagada', 'Margen Empresa', 'Costos', 'Rentabilidad', '% Rentabilidad'];
    const rows = profitabilityData.map(p => [
      p.agent_name,
      p.country,
      p.total_base.toFixed(2),
      p.total_commission_paid.toFixed(2),
      p.margin_empresa.toFixed(2),
      p.total_costs.toFixed(2),
      p.profitability.toFixed(2),
      p.profitability_pct.toFixed(2) + '%'
    ]);
    
    const csvContent = [headers.join(','), ...rows.map(r => r.map(cell => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `rentabilidad_agentes_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();
  };

  const topProfitable = [...profitabilityData].sort((a, b) => b.profitability - a.profitability).slice(0, 5);
  const leastProfitable = [...profitabilityData].sort((a, b) => a.profitability - b.profitability).slice(0, 5);

  const columns = [
    {
      header: 'Agente',
      cell: (row) => (
        <div>
          <p className="font-medium text-foreground">{row.agent_name}</p>
          <p className="text-xs text-muted-foreground">{row.country}</p>
        </div>
      )
    },
    {
      header: 'Base Comisionable',
      cell: (row) => <span className="font-medium">USD {row.total_base.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
    },
    {
      header: 'Comisión Pagada',
      cell: (row) => <span className="text-foreground/80">USD {row.total_commission_paid.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
    },
    {
      header: 'Margen Empresa',
      cell: (row) => <span className="font-medium text-foreground">USD {row.margin_empresa.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
    },
    {
      header: 'Costos',
      cell: (row) => <span className="text-red-600 dark:text-red-400">USD {row.total_costs.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
    },
    {
      header: 'Rentabilidad',
      cell: (row) => (
        <div>
           <p className={`font-bold ${row.profitability >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
             USD {row.profitability.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
           </p>
          <p className="text-xs text-muted-foreground">{row.profitability_pct.toFixed(2)}%</p>
        </div>
      )
    },
    {
      header: 'Acciones',
      cell: (row) => (
        <Link to={createPageUrl(`AgentProfitabilityDetail?agentId=${row.agent_id}&from=${dateFrom}&to=${dateTo}`)}>
          <Button variant="ghost" size="sm" className="gap-2">
            <Eye className="h-4 w-4" /> Ver Detalle
          </Button>
        </Link>
      )
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <BackButton className="mt-1" />
          <div className="flex-1">
            <PageHeader
              title="Rentabilidad por Agente"
              subtitle={`${profitabilityData.length} agentes con actividad`}
              icon={TrendingUp}
              actions={
                <Button onClick={exportToCSV} variant="outline" className="gap-2">
                  <Download className="h-4 w-4" /> Exportar
                </Button>
              }
            />
          </div>
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Desde</Label>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-full px-3 py-2 border rounded-md text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Hasta</Label>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-full px-3 py-2 border rounded-md text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">País</Label>
              <Select value={countryFilter} onValueChange={setCountryFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">Compañía</Label>
              <Select value={companyFilter} onValueChange={setCompanyFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {companies.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 pt-6">
              <Switch checked={usePaidOnly} onCheckedChange={setUsePaidOnly} />
              <Label className="text-xs">Solo comisiones pagadas</Label>
            </div>
          </div>
        </Card>

        {/* Top Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="border-0 shadow-sm bg-green-500/10">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <TrendingUp className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
                <div>
                  <p className="text-sm text-green-600 dark:text-green-400 font-medium">Top Rentables</p>
                  {topProfitable.slice(0, 3).map((p, i) => (
                    <p key={i} className="text-xs text-green-600 dark:text-green-400 mt-1">
                      {i + 1}. {p.agent_name}: USD {p.profitability.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                    </p>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-muted">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <DollarSign className="h-5 w-5 text-foreground mt-0.5" />
                <div>
                  <p className="text-sm text-foreground font-medium">Margen Total Empresa</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    USD {profitabilityData.reduce((sum, p) => sum + p.margin_empresa, 0).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-amber-500/10">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <TrendingDown className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5" />
                <div>
                  <p className="text-sm text-amber-600 dark:text-amber-400 font-medium">Costos Totales</p>
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
                    USD {profitabilityData.reduce((sum, p) => sum + p.total_costs, 0).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Table */}
        <Card className="border-0 shadow-sm p-6">
          {calculating ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-foreground" />
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={profitabilityData}
              searchPlaceholder="Buscar agente..."
              searchKeys={['agent_name', 'country']}
              emptyMessage="No hay datos de rentabilidad en el período seleccionado"
              sortable={true}
              defaultSortField="profitability"
              defaultSortOrder="desc"
            />
          )}
        </Card>
      </div>
    </div>
  );
}