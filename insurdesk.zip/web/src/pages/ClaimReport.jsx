import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';
import ClaimStalenessAlert from '@/components/claims/ClaimStalenessAlert';
import ClaimDetailDialog from '@/components/claims/ClaimDetailDialog';
import DataTable from '@/components/ui/DataTable';
import { exportToCSV, exportToExcel } from '@/components/ui/exportUtils';
import { format, differenceInDays } from 'date-fns';
import { Loader2, Shield, Filter, AlertTriangle, TrendingDown } from 'lucide-react';

const STATUS_OPTIONS = [
  { value: 'all', label: 'Todos los estados' },
  { value: 'en_proceso', label: 'En Proceso' },
  { value: 'aprobado', label: 'Aprobado' },
  { value: 'pagado_parcial', label: 'Pagado Parcial' },
  { value: 'pagado', label: 'Pagado' },
  { value: 'rechazado', label: 'Rechazado' },
];

const SORT_OPTIONS = [
  { value: 'created_date_desc', label: 'Fecha Ingreso (más reciente)' },
  { value: 'created_date_asc', label: 'Fecha Ingreso (más antigua)' },
  { value: 'event_date_desc', label: 'Fecha Evento (más reciente)' },
  { value: 'event_date_asc', label: 'Fecha Evento (más antigua)' },
  { value: 'claimed_desc', label: 'Mayor monto reclamado' },
  { value: 'claimed_asc', label: 'Menor monto reclamado' },
];

function fmt(n, currency = '') {
  return `${currency} ${(n || 0).toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`.trim();
}

function getLastActivityDays(claim) {
  let latest = claim.created_date ? new Date(claim.created_date) : new Date(0);
  if (claim.history?.length > 0) {
    claim.history.forEach(h => { if (h.date) { const d = new Date(h.date); if (d > latest) latest = d; } });
  }
  if (claim.addendums?.length > 0) {
    claim.addendums.forEach(a => { if (a.date) { const d = new Date(a.date); if (d > latest) latest = d; } });
  }
  return differenceInDays(new Date(), latest);
}

export default function ClaimReport() {
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [sortBy, setSortBy] = useState('created_date_desc');
  const [search, setSearch] = useState('');
  const [staleOnly, setStaleOnly] = useState(false);
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const allClaims = await api.entities.Claim.list('-created_date', 2000);

    // Enrich with company_name from Policy when missing on claim
    const claimsWithMissingCompany = allClaims.filter(c => !c.company_name && c.policy_id);
    if (claimsWithMissingCompany.length > 0) {
      const policyIds = [...new Set(claimsWithMissingCompany.map(c => c.policy_id))];
      const policies = await Promise.all(
        policyIds.map(pid => api.entities.Policy.filter({ id: pid }).then(r => r[0]).catch(() => null))
      );
      const policyMap = {};
      policies.forEach(p => { if (p) policyMap[p.id] = p; });

      const enriched = allClaims.map(c => {
        if (!c.company_name && c.policy_id && policyMap[c.policy_id]) {
          return { ...c, company_name: policyMap[c.policy_id].company_name };
        }
        return c;
      });
      setClaims(enriched);
    } else {
      setClaims(allClaims);
    }
    setLoading(false);
  };

  // Extract unique companies from policies linked to claims
  const companies = useMemo(() => {
    const names = [...new Set(claims.map(c => c.company_name).filter(Boolean))].sort();
    return names;
  }, [claims]);

  const filtered = useMemo(() => {
    let result = [...claims];

    if (statusFilter !== 'all') result = result.filter(c => c.status === statusFilter);
    if (companyFilter !== 'all') result = result.filter(c => c.company_name === companyFilter);
    if (staleOnly) result = result.filter(c => {
      const active = ['en_proceso', 'aprobado', 'pagado_parcial'].includes(c.status);
      return active && getLastActivityDays(c) >= 15;
    });
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(c =>
        (c.claim_number || '').toLowerCase().includes(q) ||
        (c.client_name || '').toLowerCase().includes(q) ||
        (c.policy_number || '').toLowerCase().includes(q) ||
        (c.claim_type || '').toLowerCase().includes(q)
      );
    }

    // Sort
    result.sort((a, b) => {
      switch (sortBy) {
        case 'created_date_asc': return new Date(a.created_date) - new Date(b.created_date);
        case 'created_date_desc': return new Date(b.created_date) - new Date(a.created_date);
        case 'event_date_asc': return new Date(a.event_date || 0) - new Date(b.event_date || 0);
        case 'event_date_desc': return new Date(b.event_date || 0) - new Date(a.event_date || 0);
        case 'claimed_asc': return (a.claimed_amount || 0) - (b.claimed_amount || 0);
        case 'claimed_desc': return (b.claimed_amount || 0) - (a.claimed_amount || 0);
        default: return 0;
      }
    });

    return result;
  }, [claims, statusFilter, companyFilter, sortBy, search, staleOnly]);

  // Summary stats for filtered set
  const stats = useMemo(() => {
    const total = filtered.length;
    const totalClaimed = filtered.reduce((s, c) => s + (c.claimed_amount || 0), 0);
    const totalPaid = filtered.reduce((s, c) => s + (c.paid_amount || 0), 0);
    const difference = totalClaimed - totalPaid;
    const staleCount = filtered.filter(c => {
      const active = ['en_proceso', 'aprobado', 'pagado_parcial'].includes(c.status);
      return active && getLastActivityDays(c) >= 15;
    }).length;
    const byStatus = {};
    filtered.forEach(c => { byStatus[c.status] = (byStatus[c.status] || 0) + 1; });
    return { total, totalClaimed, totalPaid, difference, staleCount, byStatus };
  }, [filtered]);

  const getExportData = () => ({
    headers: ['N° Siniestro', 'Póliza', 'Compañía', 'Cliente', 'Fecha Ingreso', 'Fecha Evento', 'Tipo', 'Moneda', 'Reclamado', 'Pagado', 'Diferencia', 'Estado', 'Días sin actividad'],
    rows: filtered.map(c => [
      c.claim_number, c.policy_number, c.company_name || '', c.client_name,
      c.created_date ? format(new Date(c.created_date), 'dd/MM/yyyy') : '',
      c.event_date ? format(new Date(c.event_date), 'dd/MM/yyyy') : '',
      c.claim_type, c.currency,
      c.claimed_amount || 0, c.paid_amount || 0,
      (c.claimed_amount || 0) - (c.paid_amount || 0),
      c.status, getLastActivityDays(c)
    ]),
    filename: `reporte_siniestros_${format(new Date(), 'yyyy-MM-dd')}`
  });

  const handleExportCSV = () => exportToCSV(getExportData());
  const handleExportExcel = () => exportToExcel({ ...getExportData(), sheetName: 'Siniestros' });

  const openDetail = (claim) => { setSelectedClaim(claim); setDetailOpen(true); };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Reporte de Siniestros"
          subtitle={`${filtered.length} siniestros`}
          icon={Shield}
          backTo="Claims"
        />

        {/* Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm p-4">
            <div className="text-xs text-muted-foreground mb-1">Siniestros</div>
            <div className="text-2xl font-bold text-foreground">{stats.total}</div>
          </Card>
          <Card className="border-0 shadow-sm p-4">
            <div className="text-xs text-muted-foreground mb-1">Total Reclamado</div>
            <div className="text-lg font-bold text-foreground">{fmt(stats.totalClaimed, '$')}</div>
          </Card>
          <Card className="border-0 shadow-sm p-4">
            <div className="text-xs text-muted-foreground mb-1">Total Pagado</div>
            <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{fmt(stats.totalPaid, '$')}</div>
          </Card>
          <Card className={`border-0 shadow-sm p-4 ${stats.staleCount > 0 ? 'border-l-4 border-l-amber-400' : ''}`}>
            <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              {stats.staleCount > 0 && <AlertTriangle className="h-3 w-3 text-amber-500" />}
              Sin actividad +15d
            </div>
            <div className={`text-2xl font-bold ${stats.staleCount > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground/70'}`}>{stats.staleCount}</div>
          </Card>
        </div>

        {/* Stale Alert */}
        <ClaimStalenessAlert claims={claims} onOpenDetail={openDetail} />

        {/* Filters */}
        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="h-4 w-4 text-muted-foreground/70" />
            <span className="text-sm font-medium text-foreground/80">Filtros y ordenamiento</span>
          </div>
          <div className="flex flex-wrap gap-3">
            <Input
              placeholder="Buscar por N°, cliente, póliza, tipo..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-64"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger className="w-52">
                <SelectValue placeholder="Compañía" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las compañías</SelectItem>
                {companies.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-60">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                {SORT_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button
              variant={staleOnly ? 'default' : 'outline'}
              size="sm"
              className={`gap-2 ${staleOnly ? 'bg-amber-500 hover:bg-amber-600 border-amber-500' : 'border-amber-500/30 text-amber-600 dark:text-amber-400 hover:bg-amber-500/10'}`}
              onClick={() => setStaleOnly(v => !v)}
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              Solo sin actividad
            </Button>
            {(statusFilter !== 'all' || companyFilter !== 'all' || search || staleOnly) && (
              <Button variant="ghost" size="sm" onClick={() => { setStatusFilter('all'); setCompanyFilter('all'); setSearch(''); setStaleOnly(false); }}>
                Limpiar filtros
              </Button>
            )}
          </div>
        </Card>

        {/* Distribution by status */}
        {!staleOnly && statusFilter === 'all' && (
          <div className="flex flex-wrap gap-2 mb-4">
            {Object.entries(stats.byStatus).map(([status, count]) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className="flex items-center gap-2 text-xs bg-card border border-border rounded-full px-3 py-1.5 hover:bg-muted/40 transition-colors shadow-sm"
              >
                <StatusBadge status={status} />
                <span className="font-semibold text-foreground/80">{count}</span>
              </button>
            ))}
          </div>
        )}

        {/* Table */}
        <Card className="border-0 shadow-sm p-4">
          <DataTable
            columns={[
              {
                header: 'N° Siniestro',
                cell: (c) => {
                  const daysSince = getLastActivityDays(c);
                  const isStale = ['en_proceso', 'aprobado', 'pagado_parcial'].includes(c.status) && daysSince >= 15;
                  return (
                    <div className="flex items-center gap-1.5">
                      {isStale && <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0" />}
                      <span className="font-mono text-xs font-semibold">{c.claim_number || '—'}</span>
                    </div>
                  );
                }
              },
              {
                header: 'Cliente / Asegurado',
                cell: (c) => (
                  <div>
                    <div className="font-medium text-foreground text-sm">{c.client_name}</div>
                    <div className="text-xs text-muted-foreground/70">{c.policy_number}</div>
                  </div>
                )
              },
              { header: 'Compañía', cell: (c) => <span className="text-xs">{c.company_name || '—'}</span> },
              { header: 'Tipo', cell: (c) => <span className="text-xs">{c.claim_type}</span> },
              { header: 'F. Ingreso', cell: (c) => <span className="text-xs text-muted-foreground">{c.created_date ? format(new Date(c.created_date), 'dd/MM/yyyy') : '—'}</span> },
              { header: 'F. Evento', cell: (c) => <span className="text-xs text-muted-foreground">{c.event_date ? format(new Date(c.event_date), 'dd/MM/yyyy') : '—'}</span> },
              {
                header: 'Reclamado',
                cell: (c) => <span className="text-xs font-medium text-foreground/80">{fmt(c.claimed_amount, c.currency)}</span>
              },
              {
                header: 'Pagado',
                cell: (c) => {
                  const diff = (c.claimed_amount || 0) - (c.paid_amount || 0);
                  return (
                    <div>
                      <span className={`text-xs font-medium ${c.paid_amount ? 'text-emerald-600 dark:text-emerald-400' : 'text-muted-foreground/70'}`}>
                        {fmt(c.paid_amount, c.currency)}
                      </span>
                      {diff > 0 && c.paid_amount > 0 && (
                        <div className="text-xs text-red-400 flex items-center gap-0.5">
                          <TrendingDown className="h-3 w-3" />{fmt(diff)}
                        </div>
                      )}
                    </div>
                  );
                }
              },
              { header: 'Estado', cell: (c) => <StatusBadge status={c.status} /> },
              {
                header: 'Sin Act.',
                cell: (c) => {
                  const d = getLastActivityDays(c);
                  const isStale = ['en_proceso', 'aprobado', 'pagado_parcial'].includes(c.status) && d >= 15;
                  return isStale
                    ? <span className={`text-xs font-bold ${d >= 30 ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>{d}d</span>
                    : <span className="text-xs text-slate-300">{d}d</span>;
                }
              },
            ]}
            data={filtered}
            searchPlaceholder="Buscar por número, cliente, póliza..."
            exportable
            onExport={handleExportCSV}
            onExportExcel={handleExportExcel}
            onRowClick={openDetail}
            emptyMessage="No se encontraron siniestros con los filtros aplicados."
          />
        </Card>

        <ClaimDetailDialog
          claim={selectedClaim}
          open={detailOpen}
          onOpenChange={setDetailOpen}
          onSaved={loadData}
        />
      </div>
    </div>
  );
}