import MFASetupPage from '@/components/mfa/MFASetupPage';

export default function MFASetup() {
  return <MFASetupPage />;
}