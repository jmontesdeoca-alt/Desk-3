import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import PageHeader from '@/components/ui/PageHeader';
import { FileText, Loader2, Save, Eye } from 'lucide-react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import jsPDF from 'jspdf';
import { format } from 'date-fns';

export default function CommissionPDFSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [settings, setSettings] = useState({
    header_notes: '',
    footer_notes: '',
    company_name: '',
    company_address: '',
    company_phone: '',
    company_email: ''
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const data = await api.entities.AppSettings.filter({ 
      setting_key: { $regex: 'commission_pdf_' } 
    });
    
    if (data.length === 0) {
      await createDefaultSettings();
      const newData = await api.entities.AppSettings.filter({ 
        setting_key: { $regex: 'commission_pdf_' } 
      });
      setSettings(parseSettings(newData));
    } else {
      setSettings(parseSettings(data));
    }
    setLoading(false);
  };

  const parseSettings = (data) => {
    const parsed = {};
    data.forEach(setting => {
      const key = setting.setting_key.replace('commission_pdf_', '');
      parsed[key] = setting.setting_value;
      parsed[`${key}_id`] = setting.id;
    });
    return parsed;
  };

  const createDefaultSettings = async () => {
    const defaults = [
      {
        setting_key: 'commission_pdf_header_notes',
        setting_value: 'Liquidación de Comisiones\n\nEstimado agente, a continuación se detalla su liquidación de comisiones correspondiente al período indicado.',
        setting_type: 'string',
        description: 'Notas del encabezado del PDF'
      },
      {
        setting_key: 'commission_pdf_footer_notes',
        setting_value: 'Los montos indicados están sujetos a las deducciones correspondientes según contrato.\nPara cualquier consulta, contacte al departamento de finanzas.',
        setting_type: 'string',
        description: 'Notas del pie de página del PDF'
      },
      {
        setting_key: 'commission_pdf_company_name',
        setting_value: 'InsurDesk',
        setting_type: 'string',
        description: 'Nombre de la compañía'
      },
      {
        setting_key: 'commission_pdf_company_address',
        setting_value: 'Ciudad de Panamá, Panamá',
        setting_type: 'string',
        description: 'Dirección de la compañía'
      },
      {
        setting_key: 'commission_pdf_company_phone',
        setting_value: '+507 1234-5678',
        setting_type: 'string',
        description: 'Teléfono de la compañía'
      },
      {
        setting_key: 'commission_pdf_company_email',
        setting_value: '',
        setting_type: 'string',
        description: 'Email de contacto'
      }
    ];
    
    await api.entities.AppSettings.bulkCreate(defaults);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    const formData = new FormData(e.target);
    
    try {
      const updates = [
        { id: settings.header_notes_id, value: formData.get('header_notes') },
        { id: settings.footer_notes_id, value: formData.get('footer_notes') },
        { id: settings.company_name_id, value: formData.get('company_name') },
        { id: settings.company_address_id, value: formData.get('company_address') },
        { id: settings.company_phone_id, value: formData.get('company_phone') },
        { id: settings.company_email_id, value: formData.get('company_email') }
      ];
      
      for (const update of updates) {
        await api.entities.AppSettings.update(update.id, {
          setting_value: update.value
        });
      }
      
      alert('Configuración guardada exitosamente');
      loadSettings();
    } catch (error) {
      alert('Error al guardar: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const generatePreviewPDF = async () => {
    setGenerating(true);
    try {
      // Sample data
      const sampleAgent = { name: 'Juan Pérez - Agente Demo' };
      const sampleCommissions = [
        {
          policy_number: 'POL-001',
          client_name: 'María González',
          agent_name: 'Juan Pérez',
          installment_number: 1,
          base_amount: 1500,
          commission_pct: 10,
          commission_amount: 150,
          currency: 'USD'
        },
        {
          policy_number: 'POL-002',
          client_name: 'Carlos Rodríguez',
          agent_name: 'Juan Pérez',
          installment_number: 2,
          base_amount: 2000,
          commission_pct: 12,
          commission_amount: 240,
          currency: 'USD'
        },
        {
          policy_number: 'POL-003',
          client_name: 'Ana Martínez',
          agent_name: 'Juan Pérez',
          installment_number: 1,
          base_amount: 1800,
          commission_pct: 10,
          commission_amount: 180,
          currency: 'USD'
        }
      ];

      const settlementData = {
        total_commissionable: 570,
        administrative_expenses_pct: 5,
        administrative_expenses_amount: 28.5,
        discounts: 0,
        total_to_collect: 541.5,
        notes: 'Liquidación de ejemplo generada para preview'
      };

      const doc = new jsPDF({ orientation: 'landscape', format: 'a4' });
      
      // Logo
      const logoImg = new Image();
      logoImg.src = '/logo-icon.png';
      await new Promise((resolve) => { logoImg.onload = resolve; });
      doc.addImage(logoImg, 'PNG', 15, 10, 20, 20);

      // Header
      const formData = new FormData(document.querySelector('form'));
      const currentSettings = {
        company_name: formData.get('company_name'),
        company_address: formData.get('company_address'),
        company_phone: formData.get('company_phone'),
        company_email: formData.get('company_email'),
        header_notes: formData.get('header_notes'),
        footer_notes: formData.get('footer_notes')
      };

      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('LIQUIDACIÓN DE COMISIONES - PREVIEW', 45, 20);
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(currentSettings.company_name || 'InsurDesk', 45, 26);
      doc.text(currentSettings.company_address || '', 45, 30);
      
      doc.setFontSize(10);
      doc.text(`Agente: ${sampleAgent.name}`, 15, 38);
      doc.text(`Liquidación N°: LIQ-PREVIEW`, 200, 20);
      doc.text(`Fecha: ${format(new Date(), 'dd/MM/yyyy')}`, 200, 26);
      
      if (currentSettings.company_phone) doc.text(`Tel: ${currentSettings.company_phone}`, 200, 32);
      if (currentSettings.company_email) doc.text(`Email: ${currentSettings.company_email}`, 200, 38);

      // Header notes
      let yPos = 45;
      if (currentSettings.header_notes) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        const headerLines = doc.splitTextToSize(currentSettings.header_notes, 260);
        doc.text(headerLines, 15, yPos);
        yPos += (headerLines.length * 4) + 5;
      }

      // Table
      const pageWidth = 297;
      const margins = { left: 15, right: 15 };
      const tableWidth = pageWidth - margins.left - margins.right;
      
      const headers = ['Póliza', 'Asegurado', 'Vendedor', 'Cuota', 'Prima Total', 'Prima Com.', '% Com.', 'Valor Com.'];
      const colWidths = [30, 45, 45, 18, 30, 30, 20, 37];
      
      doc.setFillColor(30, 58, 138);
      doc.rect(margins.left, yPos, tableWidth, 8, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      
      let xPos = margins.left + 2;
      headers.forEach((header, i) => {
        doc.text(header, xPos, yPos + 5.5);
        xPos += colWidths[i];
      });
      
      yPos += 8;
      doc.setTextColor(0, 0, 0);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      
      // Table rows
      sampleCommissions.forEach((c, idx) => {
        if (idx % 2 === 0) {
          doc.setFillColor(245, 245, 245);
          doc.rect(margins.left, yPos, tableWidth, 7, 'F');
        }
        
        xPos = margins.left + 2;
        const rowData = [
          c.policy_number,
          c.client_name,
          c.agent_name,
          c.installment_number,
          `${c.currency} ${c.base_amount.toLocaleString()}`,
          `${c.currency} ${c.base_amount.toLocaleString()}`,
          `${c.commission_pct}%`,
          `${c.currency} ${c.commission_amount.toLocaleString()}`
        ];
        
        rowData.forEach((cell, i) => {
          doc.text(String(cell), xPos, yPos + 5);
          xPos += colWidths[i];
        });
        
        yPos += 7;
      });

      const finalY = yPos + 10;

      // Totals
      doc.setFontSize(10);
      const rightX = 240;
      doc.text('Total a comisionar:', rightX, finalY, { align: 'right' });
      doc.text(`$${settlementData.total_commissionable.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, finalY, { align: 'right' });
      
      doc.text('Gastos administrativos:', rightX, finalY + 6, { align: 'right' });
      doc.text(`-$${settlementData.administrative_expenses_amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, finalY + 6, { align: 'right' });
      
      doc.text('Descuentos:', rightX, finalY + 12, { align: 'right' });
      doc.text(`-$${settlementData.discounts.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, finalY + 12, { align: 'right' });
      
      doc.setDrawColor(0);
      doc.setLineWidth(0.5);
      doc.line(200, finalY + 16, 280, finalY + 16);
      
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text('TOTAL A COBRAR:', rightX, finalY + 22, { align: 'right' });
      doc.text(`$${settlementData.total_to_collect.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, finalY + 22, { align: 'right' });

      // Notes
      let notesY = finalY + 35;
      if (settlementData.notes) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text('NOTAS DE LIQUIDACIÓN:', 15, notesY);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        const splitNotes = doc.splitTextToSize(settlementData.notes, 260);
        doc.text(splitNotes, 15, notesY + 7);
        notesY += (splitNotes.length * 4) + 15;
      }

      // Footer notes
      if (currentSettings.footer_notes) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.text('TÉRMINOS Y CONDICIONES:', 15, notesY);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(60, 60, 60);
        const footerLines = doc.splitTextToSize(currentSettings.footer_notes, 260);
        doc.text(footerLines, 15, notesY + 5);
        doc.setTextColor(0, 0, 0);
      }

      // Watermark
      doc.setFontSize(40);
      doc.setTextColor(200, 200, 200);
      doc.text('PREVIEW', 148, 110, { align: 'center', angle: 45 });

      doc.save('preview_liquidacion.pdf');
    } catch (error) {
      alert('Error generando preview: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto">
        <PageHeader
          title="Configuración de PDFs de Comisiones"
          subtitle="Personaliza las notas y datos de los PDFs de liquidación"
          backTo="AdminPanel"
          icon={FileText}
        />

        <Alert className="mb-6">
          <AlertDescription>
            Estas configuraciones se aplicarán a todas las liquidaciones de comisiones generadas en formato PDF
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle>Información de la Compañía</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre de la Compañía</Label>
                  <Input
                    name="company_name"
                    defaultValue={settings.company_name}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Dirección</Label>
                  <Input
                    name="company_address"
                    defaultValue={settings.company_address}
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Teléfono</Label>
                  <Input
                    name="company_phone"
                    defaultValue={settings.company_phone}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email de Contacto</Label>
                  <Input
                    name="company_email"
                    type="email"
                    defaultValue={settings.company_email}
                    required
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle>Notas del PDF</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Notas del Encabezado</Label>
                <Textarea
                  name="header_notes"
                  defaultValue={settings.header_notes}
                  rows={4}
                  placeholder="Texto que aparecerá al inicio del PDF..."
                />
                <p className="text-xs text-muted-foreground">
                  Aparecerá al inicio de cada liquidación, después de los datos del agente
                </p>
              </div>

              <div className="space-y-2">
                <Label>Notas del Pie de Página</Label>
                <Textarea
                  name="footer_notes"
                  defaultValue={settings.footer_notes}
                  rows={4}
                  placeholder="Texto que aparecerá al final del PDF..."
                />
                <p className="text-xs text-muted-foreground">
                  Aparecerá al final de cada liquidación, después de la tabla de comisiones
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-muted">
            <CardContent className="pt-6">
              <h4 className="font-medium text-foreground mb-2">Vista Previa del PDF</h4>
              <p className="text-sm text-foreground mb-4">
                El PDF incluirá los siguientes elementos en este orden:
              </p>
              <ol className="text-sm text-foreground space-y-2 list-decimal list-inside">
                <li>Encabezado con logo y datos de la compañía</li>
                <li>Datos del agente y número de liquidación</li>
                <li>Notas del encabezado (configuradas arriba)</li>
                <li>Tabla de comisiones detalladas</li>
                <li>Resumen de totales y deducciones</li>
                <li>Notas del pie de página (configuradas arriba)</li>
                <li>Información de contacto</li>
              </ol>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3">
            <Button 
              type="button" 
              variant="outline" 
              onClick={generatePreviewPDF}
              disabled={generating}
              className="gap-2"
            >
              {generating && <Loader2 className="h-4 w-4 animate-spin" />}
              <Eye className="h-4 w-4" />
              Preview PDF
            </Button>
            <Button type="submit" disabled={saving} className="gap-2">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              <Save className="h-4 w-4" />
              Guardar Configuración
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}