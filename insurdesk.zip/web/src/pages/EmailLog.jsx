import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import DataTable from '@/components/ui/DataTable';
import PageHeader from '@/components/ui/PageHeader';
import EmailPreviewModal from '@/components/EmailPreviewModal';
import { Mail, Loader2, AlertCircle, Eye } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function EmailLogPage() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [filters, setFilters] = useState({
    email_type: 'all',
    status: 'all'
  });

  useEffect(() => {
    loadLogs();
  }, [filters]);

  const loadLogs = async () => {
    setLoading(true);
    try {
      // Obtener todos los logs sin filtros primero
      const data = await api.entities.EmailLog.list('-created_date', 100);

      if (!data || data.length === 0) {
        setLogs([]);
        setLoading(false);
        return;
      }

      // Aplicar filtros localmente
      let filtered = data;
      if (filters.email_type !== 'all') {
        filtered = filtered.filter(log => log.email_type === filters.email_type);
      }
      if (filters.status !== 'all') {
        filtered = filtered.filter(log => log.status === filters.status);
      }

      // Agregar campo body para preview si no existe
      const logsWithBody = filtered.map(log => ({
        ...log,
        body: log.body || '<div style="padding: 20px; color: #666;"><p>Contenido del correo no disponible</p></div>'
      }));

      setLogs(logsWithBody);
    } catch (error) {
      console.error('Error loading email logs:', error);
      setLogs([]);
    } finally {
      setLoading(false);
    }
  };

  const statusStyles = {
    enviado: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
    error: 'bg-red-500/10 text-red-600 dark:text-red-400',
    no_enviado: 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
  };

  const emailTypeLabels = {
    nueva_poliza: 'Nueva Póliza',
    renovacion_recordatorio: 'Recordatorio Renovación',
    pago_recordatorio: 'Recordatorio Pago',
    otro: 'Otro'
  };

  const handlePreview = (log) => {
    setSelectedEmail(log);
    setPreviewOpen(true);
  };

  const columns = [
    {
      header: 'Fecha',
      accessorKey: 'created_date',
      cell: (row) => format(new Date(row.created_date), 'dd/MM/yyyy HH:mm', { locale: es })
    },
    {
      header: 'Tipo',
      accessorKey: 'email_type',
      cell: (row) => emailTypeLabels[row.email_type] || row.email_type
    },
    {
      header: 'Destinatario',
      accessorKey: 'recipient_name'
    },
    {
      header: 'Email',
      accessorKey: 'recipient_email'
    },
    {
      header: 'Referencia',
      accessorKey: 'related_entity_reference'
    },
    {
      header: 'Estado',
      accessorKey: 'status',
      cell: (row) => (
        <div className={`px-2 py-1 rounded-full text-xs font-medium text-center ${statusStyles[row.status] || ''}`}>
          {row.status === 'enviado' && '✓ Enviado'}
          {row.status === 'error' && '✗ Error'}
          {row.status === 'no_enviado' && '⊘ No Enviado'}
        </div>
      )
    },
    {
      header: 'Acciones',
      cell: (row) => (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handlePreview(row)}
          className="gap-2"
        >
          <Eye className="h-4 w-4" />
          Ver
        </Button>
      )
    }
  ];

  const expandedRowContent = (item) => (
    <div className="bg-muted/40 p-4 space-y-3">
      {item.error_message && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
          <p className="text-sm font-medium text-red-600 dark:text-red-400 mb-1 flex items-center gap-2">
            <AlertCircle className="h-4 w-4" />
            Mensaje de Error
          </p>
          <p className="text-sm text-red-600 dark:text-red-400">{item.error_message}</p>
        </div>
      )}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="font-medium text-muted-foreground">ID de Registro</p>
          <p className="text-foreground">{item.related_entity_id || 'N/A'}</p>
        </div>
        <div>
          <p className="font-medium text-muted-foreground">Tipo de Entidad</p>
          <p className="text-foreground">{item.related_entity_type || 'N/A'}</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader 
          title="Registro de Correos"
          subtitle="Monitoreo de envíos de correos automáticos"
          icon={Mail}
          backTo="AdminPanel"
        />

        <Card className="border-0 shadow-sm mb-6">
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Tipo de Correo</label>
                <select
                  value={filters.email_type}
                  onChange={(e) => setFilters({ ...filters, email_type: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="all">Todos</option>
                  <option value="nueva_poliza">Nueva Póliza</option>
                  <option value="renovacion_recordatorio">Recordatorio Renovación</option>
                  <option value="pago_recordatorio">Recordatorio Pago</option>
                  <option value="otro">Otro</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Estado</label>
                <select
                  value={filters.status}
                  onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="all">Todos</option>
                  <option value="enviado">Enviado</option>
                  <option value="error">Error</option>
                  <option value="no_enviado">No Enviado</option>
                </select>
              </div>

              <Button 
                onClick={loadLogs}
                className="mt-6"
                variant="outline"
              >
                Actualizar
              </Button>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-foreground" />
          </div>
        ) : (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-0">
              {logs.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground/70">
                  <Mail className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No hay registros de correos que coincidan con los filtros seleccionados</p>
                </div>
              ) : (
                <DataTable
                   data={logs}
                   columns={columns}
                   searchable={true}
                   searchPlaceholder="Buscar por email, asunto..."
                   searchKeys={['recipient_email', 'subject', 'recipient_name']}
                   pageSize={15}
                   emptyMessage="No hay registros de correos"
                 />
              )}
            </CardContent>
          </Card>
        )}

        <EmailPreviewModal 
          open={previewOpen}
          onOpenChange={setPreviewOpen}
          email={selectedEmail}
        />
      </div>
    </div>
  );
}