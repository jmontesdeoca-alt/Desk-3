import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import BackButton from '@/components/ui/BackButton';
import { Users, ChevronDown, ChevronRight, Loader2, Search, X } from 'lucide-react';

export default function AgentStructure() {
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [filter, setFilter] = useState('all'); // all, nivel_2, gapartner
  const [expandedNodes, setExpandedNodes] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [hideIsolated, setHideIsolated] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const user = await api.auth.me();
    const userRoleResp = await api.functions.invoke('getUserRoleInfo', {});
    const appRole = userRoleResp?.data?.app_role;
    const agentId = userRoleResp?.data?.agent_id;

    const data = await api.entities.Agent.filter({ status: 'activo' });

    // For gerencial with agent: limit to their structure
    if (appRole === 'gerencial' && agentId) {
      const structureIds = [];
      const findStructure = (id) => {
        structureIds.push(id);
        data.filter(a => a.upline_agent_id === id).forEach(child => findStructure(child.id));
      };
      findStructure(agentId);
      setAgents(data.filter(a => structureIds.includes(a.id)));
    } else {
      setAgents(data);
    }
    setLoading(false);
  };

  const getDownlineAgents = (agentId) => {
    return agents.filter(a => a.upline_agent_id === agentId);
  };

  const getUplineChain = (agent) => {
    const chain = [];
    let current = agent;
    while (current && current.upline_agent_id) {
      const upline = agents.find(a => a.id === current.upline_agent_id);
      if (upline) {
        chain.push(upline);
        current = upline;
      } else {
        break;
      }
    }
    return chain;
  };

  const toggleNode = (agentId) => {
    setExpandedNodes(prev => ({
      ...prev,
      [agentId]: !prev[agentId]
    }));
  };

  const renderAgentNode = (agent, depth = 0) => {
    const downline = getDownlineAgents(agent.id);
    const isExpanded = expandedNodes[agent.id];
    const hasChildren = downline.length > 0;

    return (
      <div key={agent.id} style={{ marginLeft: `${depth * 24}px` }} className="mb-2">
        <Card className="border-0 shadow-sm p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {hasChildren ? (
                <button onClick={() => toggleNode(agent.id)} className="text-muted-foreground/70 hover:text-muted-foreground">
                  {isExpanded ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                </button>
              ) : (
                <div className="w-5" />
              )}
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-foreground">{agent.name}</p>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                    agent.agent_type === 'agencia' ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400' : 'bg-muted text-foreground'
                  }`}>
                    {agent.agent_type === 'agencia' ? 'Agencia' : 'Agente'}
                  </span>
                  {agent.is_nivel_2 && (
                    <span className="px-2 py-0.5 rounded text-xs font-medium bg-orange-500/10 text-orange-600 dark:text-orange-400">
                      PARTNER
                    </span>
                  )}
                  {agent.is_gapartner && (
                    <span className="px-2 py-0.5 rounded text-xs font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      GAPARTNER+
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {agent.email} • Nivel: {agent.level || 1}
                  {hasChildren && ` • ${downline.length} subordinado${downline.length !== 1 ? 's' : ''}`}
                </p>
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setSelectedAgent(agent)}
            >
              Ver Detalles
            </Button>
          </div>
        </Card>
        {isExpanded && hasChildren && (
          <div className="mt-2">
            {downline.map(d => renderAgentNode(d, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const filteredAgents = agents.filter(agent => {
    // Apply filter
    if (filter === 'nivel_2' && !agent.is_nivel_2) return false;
    if (filter === 'gapartner' && !agent.is_gapartner) return false;
    
    // Hide isolated agents (no upline and no downline)
    if (hideIsolated) {
      const hasUpline = agent.upline_agent_id && agents.find(a => a.id === agent.upline_agent_id);
      const hasDownline = agents.some(a => a.upline_agent_id === agent.id);
      if (!hasUpline && !hasDownline) return false;
    }
    
    // Apply search
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      return agent.name?.toLowerCase().includes(search) ||
             agent.email?.toLowerCase().includes(search) ||
             agent.country?.toLowerCase().includes(search);
    }
    
    return true;
  });

  const topLevelAgents = filteredAgents.filter(a => !a.upline_agent_id || !filteredAgents.find(x => x.id === a.upline_agent_id));

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <BackButton />
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-muted">
              <Users className="h-6 w-6 text-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Estructura de Agencias</h1>
              <p className="text-sm text-muted-foreground">Visualiza la jerarquía organizacional</p>
            </div>
          </div>
        </div>

        <Card className="border-0 shadow-sm p-4 mb-6">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="relative flex-1 min-w-[250px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
              <Input
                placeholder="Buscar por nombre, email o país..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
              {searchTerm && (
                <button
                  onClick={() => { setSearchTerm(''); setSelectedAgent(null); }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/70 hover:text-muted-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-muted-foreground">Filtrar:</label>
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="nivel_2">Solo Partners</SelectItem>
                  <SelectItem value="gapartner">Solo GAPartners+</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              variant={hideIsolated ? "default" : "outline"}
              onClick={() => setHideIsolated(!hideIsolated)}
              size="sm"
            >
              {hideIsolated ? 'Mostrar Aislados' : 'Ocultar Aislados'}
            </Button>
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Hierarchy Tree */}
          <div className="lg:col-span-2">
            <h2 className="text-lg font-semibold mb-4">Jerarquía</h2>
            {topLevelAgents.length === 0 ? (
              <Card className="border-0 shadow-sm p-12">
                <div className="text-center text-muted-foreground/70">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No hay agentes que coincidan con el filtro</p>
                </div>
              </Card>
            ) : (
              <div className="space-y-2">
                {topLevelAgents.map(agent => renderAgentNode(agent))}
              </div>
            )}
          </div>

          {/* Details Panel */}
          <div>
            <h2 className="text-lg font-semibold mb-4">Detalles</h2>
            {selectedAgent ? (
              <Card className="border-0 shadow-sm p-6 sticky top-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Nombre</p>
                    <p className="font-semibold text-foreground">{selectedAgent.name}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Email</p>
                    <p className="text-sm">{selectedAgent.email}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">País</p>
                    <p className="text-sm">{selectedAgent.country}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Nivel</p>
                    <p className="text-sm">{selectedAgent.level || 1}</p>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <p className="text-xs text-muted-foreground mb-2">Superior Inmediato</p>
                    {selectedAgent.upline_agent_name ? (
                      <p className="text-sm font-medium text-foreground">{selectedAgent.upline_agent_name}</p>
                    ) : (
                      <p className="text-sm text-muted-foreground/70">No tiene superior</p>
                    )}
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-xs text-muted-foreground mb-2">Cadena de Superiores</p>
                    {getUplineChain(selectedAgent).length > 0 ? (
                      <div className="space-y-1">
                        {getUplineChain(selectedAgent).map((upline, idx) => (
                          <p key={upline.id} className="text-sm" style={{ paddingLeft: `${idx * 12}px` }}>
                            → {upline.name}
                          </p>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground/70">Es nivel superior</p>
                    )}
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-xs text-muted-foreground mb-2">Subordinados Directos</p>
                    {getDownlineAgents(selectedAgent.id).length > 0 ? (
                      <div className="space-y-1">
                        {getDownlineAgents(selectedAgent.id).map(downline => (
                          <p key={downline.id} className="text-sm">• {downline.name}</p>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground/70">Sin subordinados</p>
                    )}
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="border-0 shadow-sm p-12">
                <div className="text-center text-muted-foreground/70">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-sm">Selecciona un agente para ver sus detalles</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}