import React, { useState } from 'react';
import { MessageSquare, Plus } from 'lucide-react';
import MessageList from '@/components/messaging/MessageList';
import MessageThread from '@/components/messaging/MessageThread';
import NewConversationDialog from '@/components/messaging/NewConversationDialog';
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import { Button } from '@/components/ui/button';

export default function Messaging() {
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [newConvDialogOpen, setNewConvDialogOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start justify-between gap-4 mb-6">
          <div className="flex items-start gap-4 flex-1">
            <BackButton className="mt-1" />
            <div className="flex-1">
              <PageHeader
                title="Mensajería Interna"
                subtitle="Comunícate sobre pólizas y tareas"
                icon={MessageSquare}
              />
            </div>
          </div>
          <Button onClick={() => setNewConvDialogOpen(true)} className="gap-2 mt-1">
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Nuevo Chat</span>
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lista de conversaciones */}
          <div className="lg:col-span-1">
            <MessageList onSelectConversation={setSelectedConversation} />
          </div>

          {/* Thread de mensajes */}
          <div className="lg:col-span-2">
            {selectedConversation ? (
              <MessageThread
                conversationType={selectedConversation.conversationType}
                conversationId={selectedConversation.conversationId}
                conversationTitle={selectedConversation.conversationTitle}
                onClose={() => setSelectedConversation(null)}
              />
            ) : (
              <div className="flex items-center justify-center h-[600px] bg-card rounded-xl border border-border">
                <div className="text-center">
                  <MessageSquare className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-muted-foreground">Selecciona una conversación para empezar</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <NewConversationDialog 
          open={newConvDialogOpen} 
          onOpenChange={setNewConvDialogOpen}
          onConversationCreated={setSelectedConversation}
        />
      </div>
    </div>
  );
}