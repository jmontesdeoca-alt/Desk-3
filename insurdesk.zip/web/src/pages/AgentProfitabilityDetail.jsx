import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import PageHeader from '@/components/ui/PageHeader';
import BackButton from '@/components/ui/BackButton';
import DataTable from '@/components/ui/DataTable';
import { TrendingUp, Plus, Loader2, Pencil, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function AgentProfitabilityDetail() {
  const [agent, setAgent] = useState(null);
  const [commissions, setCommissions] = useState([]);
  const [costs, setCosts] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [costFormOpen, setCostFormOpen] = useState(false);
  const [editingCost, setEditingCost] = useState(null);
  const [saving, setSaving] = useState(false);
  
  // URL params
  const urlParams = new URLSearchParams(window.location.search);
  const agentId = urlParams.get('agentId');
  const dateFrom = urlParams.get('from');
  const dateTo = urlParams.get('to');
  
  // Form fields
  const [costType, setCostType] = useState('bono');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [costDate, setCostDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (agentId) {
      loadData();
    }
  }, [agentId]);

  const loadData = async () => {
    setLoading(true);
    
    const agentData = await api.entities.Agent.filter({ id: agentId });
    if (agentData.length === 0) {
      toast.error('Agente no encontrado');
      return;
    }
    setAgent(agentData[0]);
    
    // Get commissions in range
    const allCommissions = await api.entities.Commission.list();
    const agentCommissions = allCommissions.filter(c => {
      if (c.agent_id !== agentId) return false;
      if (dateFrom && c.generation_date < dateFrom) return false;
      if (dateTo && c.generation_date > dateTo) return false;
      return true;
    });
    setCommissions(agentCommissions);
    
    // Get costs in range
    const allCosts = await api.entities.AgentCost.list();
    const agentCosts = allCosts.filter(c => {
      if (c.agent_id !== agentId) return false;
      if (c.status === 'anulado' || c.status === 'reversado') return false;
      if (dateFrom && c.date < dateFrom) return false;
      if (dateTo && c.date > dateTo) return false;
      return true;
    });
    setCosts(agentCosts);
    
    // Get related policies
    const policyIds = [...new Set(agentCommissions.map(c => c.policy_id))];
    const allPolicies = await api.entities.Policy.list();
    const relatedPolicies = allPolicies.filter(p => policyIds.includes(p.id));
    setPolicies(relatedPolicies);
    
    setLoading(false);
  };

  const resetForm = () => {
    setCostType('bono');
    setDescription('');
    setAmount('');
    setCurrency('USD');
    setCostDate(format(new Date(), 'yyyy-MM-dd'));
    setNotes('');
    setEditingCost(null);
  };

  const handleSubmitCost = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    const costData = {
      agent_id: agentId,
      agent_name: agent.name,
      cost_type: costType,
      description: description,
      amount: parseFloat(amount),
      currency: currency,
      date: costDate,
      period: format(new Date(costDate), 'yyyy-MM'),
      status: 'activo',
      notes: notes
    };
    
    try {
      if (editingCost) {
        await api.entities.AgentCost.update(editingCost.id, costData);
        toast.success('Costo actualizado');
      } else {
        await api.entities.AgentCost.create(costData);
        toast.success('Costo registrado');
      }
      
      setCostFormOpen(false);
      resetForm();
      loadData();
    } catch (error) {
      toast.error('Error al guardar: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleEditCost = (cost) => {
    setEditingCost(cost);
    setCostType(cost.cost_type);
    setDescription(cost.description);
    setAmount(cost.amount.toString());
    setCurrency(cost.currency);
    setCostDate(cost.date);
    setNotes(cost.notes || '');
    setCostFormOpen(true);
  };

  const handleDeleteCost = async (cost) => {
    if (!confirm('¿Anular este costo?')) return;
    
    await api.entities.AgentCost.update(cost.id, {
      status: 'anulado',
      notes: (cost.notes || '') + ` [ANULADO: ${format(new Date(), 'yyyy-MM-dd')}]`
    });
    toast.success('Costo anulado');
    loadData();
  };

  // Calculate KPIs
  const totalBase = commissions.reduce((sum, c) => sum + (c.base_amount || 0), 0);
  const totalCommissionPaid = commissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);
  const estimatedMargin = totalBase * 0.05; // Simplified
  const totalCosts = costs.reduce((sum, c) => sum + (c.amount || 0), 0);
  const profitability = estimatedMargin - totalCosts;
  const profitabilityPct = totalBase > 0 ? (profitability / totalBase * 100) : 0;

  const costColumns = [
    {
      header: 'Fecha',
      accessorKey: 'date',
      cell: (row) => format(new Date(row.date), 'dd/MM/yyyy')
    },
    {
      header: 'Tipo',
      cell: (row) => <span className="capitalize">{row.cost_type.replace('_', ' ')}</span>
    },
    {
      header: 'Descripción',
      accessorKey: 'description'
    },
    {
      header: 'Monto',
      cell: (row) => <span className="font-medium text-red-600 dark:text-red-400">{row.currency} {row.amount.toLocaleString('en-US', {minimumFractionDigits: 2})}</span>
    },
    {
      header: 'Acciones',
      cell: (row) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => handleEditCost(row)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => handleDeleteCost(row)}>
            <Trash2 className="h-4 w-4 text-red-500" />
          </Button>
        </div>
      )
    }
  ];

  const commissionColumns = [
    {
      header: 'Fecha',
      accessorKey: 'generation_date',
      cell: (row) => format(new Date(row.generation_date), 'dd/MM/yyyy')
    },
    {
      header: 'Póliza',
      accessorKey: 'policy_number'
    },
    {
      header: 'Cliente',
      accessorKey: 'client_name'
    },
    {
      header: 'Base',
      cell: (row) => `${row.currency} ${row.base_amount.toLocaleString('en-US', {minimumFractionDigits: 2})}`
    },
    {
      header: 'Comisión',
      cell: (row) => `${row.currency} ${row.commission_amount.toLocaleString('en-US', {minimumFractionDigits: 2})}`
    },
    {
      header: 'Estado',
      cell: (row) => <span className="text-xs capitalize">{row.status.replace('_', ' ')}</span>
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  if (!agent) {
    return <div className="p-6">Agente no encontrado</div>;
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-start gap-4 mb-6">
          <BackButton className="mt-1" />
          <div className="flex-1">
            <PageHeader
              title={`Rentabilidad: ${agent.name}`}
              subtitle={`Período: ${dateFrom} a ${dateTo}`}
              icon={TrendingUp}
            />
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">Base Comisionable</p>
              <p className="text-2xl font-bold text-foreground mt-1">
                USD {totalBase.toLocaleString('en-US', {minimumFractionDigits: 2})}
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">Comisión Pagada</p>
              <p className="text-2xl font-bold text-foreground mt-1">
                USD {totalCommissionPaid.toLocaleString('en-US', {minimumFractionDigits: 2})}
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-muted">
            <CardContent className="pt-6">
              <p className="text-sm text-foreground">Margen Empresa</p>
              <p className="text-2xl font-bold text-foreground mt-1">
                USD {estimatedMargin.toLocaleString('en-US', {minimumFractionDigits: 2})}
              </p>
            </CardContent>
          </Card>

          <Card className={`border-0 shadow-sm ${profitability >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
            <CardContent className="pt-6">
              <p className={`text-sm ${profitability >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>Rentabilidad Final</p>
              <p className={`text-2xl font-bold ${profitability >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'} mt-1`}>
                USD {profitability.toLocaleString('en-US', {minimumFractionDigits: 2})}
              </p>
              <p className="text-xs text-muted-foreground mt-1">{profitabilityPct.toFixed(2)}%</p>
            </CardContent>
          </Card>
        </div>

        {/* Costs */}
        <Card className="border-0 shadow-sm p-6 mb-6">
          <CardHeader className="px-0 pt-0">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Costos Asociados</CardTitle>
              <Button onClick={() => { resetForm(); setCostFormOpen(true); }} className="gap-2">
                <Plus className="h-4 w-4" /> Agregar Costo
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-0">
            <DataTable
              columns={costColumns}
              data={costs}
              searchable={false}
              emptyMessage="No hay costos registrados"
            />
          </CardContent>
        </Card>

        {/* Commissions */}
        <Card className="border-0 shadow-sm p-6">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="text-lg">Comisiones del Período</CardTitle>
          </CardHeader>
          <CardContent className="px-0">
            <DataTable
              columns={commissionColumns}
              data={commissions}
              searchPlaceholder="Buscar póliza o cliente..."
              searchKeys={['policy_number', 'client_name']}
              emptyMessage="No hay comisiones en el período"
            />
          </CardContent>
        </Card>

        {/* Cost Form Dialog */}
        <Dialog open={costFormOpen} onOpenChange={setCostFormOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingCost ? 'Editar Costo' : 'Nuevo Costo'}</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmitCost} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tipo de Costo *</Label>
                  <Select value={costType} onValueChange={setCostType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bono">Bono</SelectItem>
                      <SelectItem value="incentivo">Incentivo</SelectItem>
                      <SelectItem value="premio">Premio</SelectItem>
                      <SelectItem value="gasto_admin">Gasto Administrativo</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Fecha *</Label>
                  <Input
                    type="date"
                    value={costDate}
                    onChange={(e) => setCostDate(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Descripción *</Label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ej: Bono por cumplimiento de metas"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Monto *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Moneda</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="COP">COP</SelectItem>
                      <SelectItem value="MXN">MXN</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notas</Label>
                <Input
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notas adicionales"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => { setCostFormOpen(false); resetForm(); }}
                  disabled={saving}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingCost ? 'Actualizar' : 'Guardar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}