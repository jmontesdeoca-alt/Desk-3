import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';
import ClientInfoCard from '@/components/client/ClientInfoCard';
import ClientPoliciesTab from '@/components/client/ClientPoliciesTab';
import ClientActivityTimeline from '@/components/client/ClientActivityTimeline';
import ClientFinancialSummary from '@/components/client/ClientFinancialSummary';
import ClientForm from '@/components/forms/ClientForm';
import {
  User, FileText, Users as UsersIcon, Plus, Pencil, Trash2,
  Loader2, Building2, Activity, DollarSign
} from 'lucide-react';
import { format } from 'date-fns';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import DataTable from '@/components/ui/DataTable';

export default function ClientDetail() {
  const [client, setClient] = useState(null);
  const [dependents, setDependents] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [payments, setPayments] = useState([]);
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  const [editFormOpen, setEditFormOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [depFormOpen, setDepFormOpen] = useState(false);
  const [editingDep, setEditingDep] = useState(null);
  const [depToDelete, setDepToDelete] = useState(null);
  const [depSaving, setDepSaving] = useState(false);
  const [depForm, setDepForm] = useState({
    full_name: '', relationship: 'conyuge', birth_date: '',
    document_type: 'cedula', document_id: '', status: 'activo'
  });

  const urlParams = new URLSearchParams(window.location.search);
  const clientId = urlParams.get('id');

  useEffect(() => {
    api.auth.me().then(u => setCurrentUser(u)).catch(() => {});
    if (clientId) loadData();
  }, [clientId]);

  const loadData = async () => {
    setLoading(true);
    const [clientData, depsData, policiesData] = await Promise.all([
      api.entities.Client.filter({ id: clientId }),
      api.entities.Dependent.filter({ client_id: clientId }),
      api.entities.Policy.filter({ client_id: clientId }),
    ]);
    const cl = clientData[0] || null;
    setClient(cl);
    setDependents(depsData);
    setPolicies(policiesData);

    // Load payments & claims based on policies
    if (policiesData.length > 0) {
      const policyIds = policiesData.map(p => p.id);
      const [paymentsAll, claimsAll] = await Promise.all([
        api.entities.Payment.list(),
        api.entities.Claim.list(),
      ]);
      setPayments(paymentsAll.filter(p => policyIds.includes(p.policy_id)));
      setClaims(claimsAll.filter(c => policyIds.includes(c.policy_id)));
    }

    setLoading(false);
  };

  const getClientName = (c = client) => {
    if (!c) return '';
    return c.client_type === 'persona'
      ? `${c.first_name || ''} ${c.last_name || ''}`.trim()
      : c.company_name || '';
  };

  const handleClientSave = async (data) => {
    setSaving(true);
    await api.entities.Client.update(client.id, data);
    setSaving(false);
    setEditFormOpen(false);
    loadData();
  };

  // ── Dependents ──────────────────────────────────────────────────────────────
  const handleDepSubmit = async (e) => {
    e.preventDefault();
    setDepSaving(true);
    if (editingDep) {
      await api.entities.Dependent.update(editingDep.id, depForm);
    } else {
      await api.entities.Dependent.create({ ...depForm, client_id: clientId });
    }
    setDepSaving(false);
    setDepFormOpen(false);
    setEditingDep(null);
    setDepForm({ full_name: '', relationship: 'conyuge', birth_date: '', document_type: 'cedula', document_id: '', status: 'activo' });
    loadData();
  };

  const handleEditDep = (dep) => {
    setEditingDep(dep);
    setDepForm({
      full_name: dep.full_name || '', relationship: dep.relationship || 'conyuge',
      birth_date: dep.birth_date || '', document_type: dep.document_type || 'cedula',
      document_id: dep.document_id || '', status: dep.status || 'activo'
    });
    setDepFormOpen(true);
  };

  const handleDeleteDep = async () => {
    if (depToDelete) {
      await api.entities.Dependent.delete(depToDelete.id);
      setDepToDelete(null);
      loadData();
    }
  };

  const dependentColumns = [
    { key: 'full_name', label: 'Nombre' },
    { key: 'relationship', label: 'Parentesco', render: (v) => <span className="capitalize">{v}</span> },
    { key: 'document_id', label: 'Documento' },
    {
      key: 'birth_date', label: 'Fecha Nac.',
      render: (v) => {
        if (!v) return '—';
        const d = new Date(v + 'T00:00:00');
        return isNaN(d.getTime()) ? '—' : format(d, 'dd/MM/yyyy');
      }
    },
    { key: 'status', label: 'Estado', render: (v) => <StatusBadge status={v} /> },
    {
      key: 'id', label: '',
      render: (v, row) => (
        currentUser?.app_role !== 'agente' ? (
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => handleEditDep(row)}>
              <Pencil className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setDepToDelete(row)}>
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        ) : null
      )
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-foreground" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Cliente no encontrado</p>
      </div>
    );
  }

  const pendingCount = payments.filter(p => p.status === 'pendiente' || p.status === 'atrasado').length;

  return (
    <div className="min-h-screen bg-background p-4 lg:p-6">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title={getClientName()}
          subtitle={`${client.client_type === 'persona' ? 'Persona Natural' : 'Empresa'} · ${client.document_id}`}
          icon={client.client_type === 'persona' ? User : Building2}
          backTo="Clients"
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-2">
          {/* Left Column: Info */}
          <div className="lg:col-span-1">
            <ClientInfoCard
              client={client}
              policies={policies}
              onEdit={currentUser?.app_role !== 'agente' ? () => setEditFormOpen(true) : undefined}
            />
          </div>

          {/* Right Column: Tabs */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="policies">
              <TabsList className="mb-4 w-full sm:w-auto flex overflow-x-auto">
                <TabsTrigger value="policies" className="gap-1.5 whitespace-nowrap">
                  <FileText className="h-4 w-4" />
                  Pólizas
                  <span className="ml-1 bg-muted text-foreground text-xs px-1.5 py-0.5 rounded-full">
                    {policies.length}
                  </span>
                </TabsTrigger>
                <TabsTrigger value="financial" className="gap-1.5 whitespace-nowrap">
                  <DollarSign className="h-4 w-4" />
                  Finanzas
                  {pendingCount > 0 && (
                    <span className="ml-1 bg-red-500/10 text-red-600 dark:text-red-400 text-xs px-1.5 py-0.5 rounded-full">
                      {pendingCount}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="timeline" className="gap-1.5 whitespace-nowrap">
                  <Activity className="h-4 w-4" />
                  Actividad
                </TabsTrigger>
                <TabsTrigger value="dependents" className="gap-1.5 whitespace-nowrap">
                  <UsersIcon className="h-4 w-4" />
                  Dependientes
                  {dependents.length > 0 && (
                    <span className="ml-1 bg-muted text-muted-foreground text-xs px-1.5 py-0.5 rounded-full">
                      {dependents.length}
                    </span>
                  )}
                </TabsTrigger>
              </TabsList>

              {/* Pólizas */}
              <TabsContent value="policies">
                <Card className="border-0 shadow-sm p-5">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-foreground">Historial de Pólizas</h3>
                    {currentUser?.app_role !== 'agente' && (
                      <Link to={createPageUrl('Policies')}>
                        <Button size="sm" className="gap-2">
                          <Plus className="h-4 w-4" /> Nueva Póliza
                        </Button>
                      </Link>
                    )}
                  </div>
                  <ClientPoliciesTab policies={policies} />
                </Card>
              </TabsContent>

              {/* Finanzas */}
              <TabsContent value="financial">
                <Card className="border-0 shadow-sm p-5">
                  <h3 className="font-semibold text-foreground mb-4">Resumen Financiero</h3>
                  <ClientFinancialSummary payments={payments} policies={policies} />
                </Card>
              </TabsContent>

              {/* Timeline */}
              <TabsContent value="timeline">
                <Card className="border-0 shadow-sm p-5">
                  <h3 className="font-semibold text-foreground mb-5">Historial de Actividad</h3>
                  <ClientActivityTimeline
                    policies={policies}
                    payments={payments}
                    claims={claims}
                    clientCreatedDate={client.created_date}
                  />
                </Card>
              </TabsContent>

              {/* Dependientes */}
              <TabsContent value="dependents">
                <Card className="border-0 shadow-sm p-5">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-foreground">Dependientes</h3>
                    {currentUser?.app_role !== 'agente' && (
                      <Button size="sm" className="gap-2" onClick={() => {
                        setEditingDep(null);
                        setDepForm({ full_name: '', relationship: 'conyuge', birth_date: '', document_type: 'cedula', document_id: '', status: 'activo' });
                        setDepFormOpen(true);
                      }}>
                        <Plus className="h-4 w-4" /> Agregar
                      </Button>
                    )}
                  </div>
                  <DataTable
                    columns={dependentColumns}
                    data={dependents}
                    searchable={false}
                    pageSize={5}
                    emptyMessage="No hay dependientes registrados"
                  />
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Edit Client */}
        <ClientForm
          open={editFormOpen}
          onOpenChange={setEditFormOpen}
          onSubmit={handleClientSave}
          initialData={client}
          isLoading={saving}
        />

        {/* Dependent Form */}
        <Dialog open={depFormOpen} onOpenChange={setDepFormOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingDep ? 'Editar Dependiente' : 'Agregar Dependiente'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleDepSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre Completo *</Label>
                <Input value={depForm.full_name} onChange={(e) => setDepForm({ ...depForm, full_name: e.target.value })} required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Parentesco *</Label>
                  <Select value={depForm.relationship} onValueChange={(v) => setDepForm({ ...depForm, relationship: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="conyuge">Cónyuge</SelectItem>
                      <SelectItem value="hijo">Hijo/a</SelectItem>
                      <SelectItem value="padre">Padre</SelectItem>
                      <SelectItem value="madre">Madre</SelectItem>
                      <SelectItem value="hermano">Hermano/a</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Fecha de Nacimiento</Label>
                  <Input type="date" value={depForm.birth_date} onChange={(e) => setDepForm({ ...depForm, birth_date: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tipo de Documento</Label>
                  <Select value={depForm.document_type} onValueChange={(v) => setDepForm({ ...depForm, document_type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cedula">Cédula</SelectItem>
                      <SelectItem value="pasaporte">Pasaporte</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Número de Documento</Label>
                  <Input value={depForm.document_id} onChange={(e) => setDepForm({ ...depForm, document_id: e.target.value })} />
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <Button type="button" variant="outline" onClick={() => setDepFormOpen(false)}>Cancelar</Button>
                <Button type="submit" disabled={depSaving}>
                  {depSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingDep ? 'Guardar' : 'Agregar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Dependent */}
        <AlertDialog open={!!depToDelete} onOpenChange={() => setDepToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar dependiente?</AlertDialogTitle>
              <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteDep} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}