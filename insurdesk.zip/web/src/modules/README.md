# Módulos del frontend

Los módulos del CRM (`crm`, `automatizaciones`, `citas`, `ia`, `integraciones`) viven aquí y se registran en `registry.js`.
Cada módulo declara en su `manifest.js`: `pages`, `publicPages`, `nav` y `settingsTabs`.

- `MODULE_FEATURE` (en `registry.js`) liga cada módulo con la función del plan que lo habilita (`server/plans.json`).
- El menú del CRM se arma solo con los módulos incluidos en el plan y para usuarios con acceso al CRM.
- Un módulo nuevo: carpeta con `manifest.js`, una línea en `registry.js` y, en el servidor, `server/modules/<id>/module.json`.
