// Registro de módulos del frontend. Cada módulo declara en su manifest.js:
//   pages        → páginas con sesión (/<Nombre>)
//   publicPages  → rutas públicas (sin sesión)
//   nav          → entradas del menú (section: main | admin | user)
//   settingsTabs → pestañas que aporta a la Configuración del CRM
// Un módulo se muestra solo si el plan incluye su función (MODULE_FEATURE) y el usuario tiene acceso al CRM.
import { LayoutDashboard } from 'lucide-react';
import crm from './crm/manifest';
import automatizaciones from './automatizaciones/manifest';
import citas from './citas/manifest';
import ia from './ia/manifest';
import integraciones from './integraciones/manifest';

export const MODULES = [crm, automatizaciones, citas, ia, integraciones];
export const MODULE_FEATURE = { crm: 'crm', automatizaciones: 'crm', citas: 'crm', ia: 'ai', integraciones: 'crm_integrations' };

const byOrder = (a, b) => (a.order ?? 100) - (b.order ?? 100);

/** Página → { Component, module } */
export const PAGES = Object.fromEntries(
  MODULES.flatMap((m) => Object.entries(m.pages || {}).map(([name, Component]) => [name, { Component, module: m.id }])),
);
export const PUBLIC_PAGES = MODULES.flatMap((m) => Object.entries(m.publicPages || {}).map(([path, Component]) => ({ path, Component, module: m.id })));
/** Función del plan que habilita una página de módulo (undefined si es del núcleo) */
export const pageFeature = (name) => (PAGES[name] ? MODULE_FEATURE[PAGES[name].module] : undefined);

// Etiquetas del menú que evitan repetir nombres con el portal (Reportes, Tareas)
const LABELS = { CrmReports: 'Reportes CRM', Tasks: 'Seguimientos' };

const items = (section, isEnabled) => MODULES.filter((m) => isEnabled(m.id))
  .flatMap((m) => (m.nav || []).filter((n) => n.section === section)).sort(byOrder)
  .map((n) => ({ name: LABELS[n.page] || n.name, icon: n.icon, path: n.page }));

/** Menú del CRM dentro del portal: [{ heading }, ...enlaces]. `crmRole` decide qué ve cada perfil. */
export function crmNavItems(isEnabled, crmRole) {
  if (!isEnabled('crm')) return [];
  const manager = crmRole === 'admin_crm' || crmRole === 'jefatura_crm';
  return [
    { heading: 'CRM' },
    { name: 'Resumen', icon: LayoutDashboard, path: 'CrmDashboard' },
    ...items('main', isEnabled),
    ...(manager ? items('admin', isEnabled) : []),
    ...items('user', isEnabled),
  ];
}

/** Pestañas de Configuración del CRM aportadas por los módulos activos */
export const settingsTabs = (isEnabled) => MODULES.filter((m) => isEnabled(m.id))
  .flatMap((m) => (m.settingsTabs || [])).sort(byOrder);
