// Integraciones: Meta (leads, Pixel y API de conversiones), WhatsApp y formularios web.
import { Link2 } from 'lucide-react';
import MetaIntegration from './pages/MetaIntegration';
import WebForms from './pages/WebForms';
import WhatsAppSettings from './pages/WhatsAppSettings';
import IntegrationsTab from './components/settings/IntegrationsTab';

export default {
  id: 'integraciones',
  name: 'Integraciones',
  pages: { MetaIntegration, WebForms, WhatsAppSettings },
  settingsTabs: [{ id: 'vinculaciones', order: 80, label: 'Vinculaciones', icon: Link2, Component: IntegrationsTab }],
};
