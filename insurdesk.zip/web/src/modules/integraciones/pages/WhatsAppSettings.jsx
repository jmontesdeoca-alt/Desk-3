import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Save, CheckCircle, XCircle, AlertCircle,
  Loader2, Copy, Check, Webhook, Shield, Eye, EyeOff, ArrowLeft, MessageCircle
} from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function WhatsAppSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const [config, setConfig] = useState(null);
  const [showToken, setShowToken] = useState(false);
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [formData, setFormData] = useState({
    phone_number_id: '',
    business_account_id: '',
    access_token: '',
    verify_token: '',
    webhook_phone_number: ''
  });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const user = await api.auth.me();
      const isAdmin = user.crm_role === 'admin_crm' || user.role === 'admin';
      setHasAccess(isAdmin);
      if (!isAdmin) return;

      const configs = await api.entities.WhatsAppConfig.list();
      if (configs.length > 0) {
        setConfig(configs[0]);
        setFormData({
          phone_number_id: configs[0].phone_number_id || '',
          business_account_id: configs[0].business_account_id || '',
          access_token: configs[0].access_token || '',
          verify_token: configs[0].verify_token || '',
          webhook_phone_number: configs[0].webhook_phone_number || ''
        });
      }
    } catch (error) {
      toast.error('Error cargando configuración');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.phone_number_id || !formData.access_token || !formData.verify_token) {
      toast.error('Phone Number ID, Access Token y Verify Token son requeridos');
      return;
    }
    setSaving(true);
    try {
      if (config) {
        await api.entities.WhatsAppConfig.update(config.id, {
          ...formData,
          connection_status: 'not_configured',
          error_message: ''
        });
        toast.success('Configuración actualizada');
      } else {
        await api.entities.WhatsAppConfig.create({
          ...formData,
          connection_status: 'not_configured',
          is_active: true
        });
        toast.success('Configuración guardada');
      }
      loadData();
    } catch (error) {
      toast.error('Error guardando configuración');
    } finally {
      setSaving(false);
    }
  };

  const testConnection = async () => {
    if (!formData.phone_number_id || !formData.access_token) {
      toast.error('Completa Phone Number ID y Access Token primero');
      return;
    }
    setTesting(true);
    try {
      const response = await fetch(
        `https://graph.facebook.com/v21.0/${formData.phone_number_id}?fields=display_phone_number,verified_name&access_token=${formData.access_token}`
      );
      const data = await response.json();
      if (response.ok && data.display_phone_number) {
        if (config) {
          await api.entities.WhatsAppConfig.update(config.id, {
            connection_status: 'ok',
            error_message: '',
            last_validated_at: new Date().toISOString(),
            webhook_phone_number: data.display_phone_number
          });
        }
        toast.success(`Conexión exitosa: ${data.verified_name} (${data.display_phone_number})`);
        loadData();
      } else {
        const msg = data.error?.message || 'Credenciales inválidas';
        if (config) {
          await api.entities.WhatsAppConfig.update(config.id, { connection_status: 'error', error_message: msg });
        }
        toast.error(`Error: ${msg}`);
        loadData();
      }
    } catch (error) {
      toast.error('Error probando conexión');
    } finally {
      setTesting(false);
    }
  };

  const webhookUrl = `${window.location.origin}/api/functions/whatsappWebhook`;

  const copyWebhook = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    toast.success('URL copiada');
    setTimeout(() => setCopiedWebhook(false), 2000);
  };

  const getStatusBadge = () => {
    if (!config) return null;
    switch (config.connection_status) {
      case 'ok':
        return <Badge className="bg-green-100 text-green-800 gap-2"><CheckCircle className="h-3 w-3" />Conectado</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800 gap-2"><XCircle className="h-3 w-3" />Error</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-800 gap-2"><AlertCircle className="h-3 w-3" />Sin configurar</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="max-w-5xl mx-auto">
          <Link to={createPageUrl('Settings')}>
            <Button variant="ghost" className="gap-2 mb-4"><ArrowLeft className="h-4 w-4" />Volver a Configuración</Button>
          </Link>
          <Alert className="max-w-2xl mx-auto">
            <Shield className="h-4 w-4" />
            <AlertDescription>Solo los administradores pueden acceder a esta configuración.</AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <Link to={createPageUrl('Settings')}>
          <Button variant="ghost" className="gap-2"><ArrowLeft className="h-4 w-4" />Volver a Configuración</Button>
        </Link>

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-[#25D366] flex items-center justify-center">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">WhatsApp Business</h1>
              <p className="text-slate-600 dark:text-zinc-400">Integración con WhatsApp Business API (Meta)</p>
            </div>
          </div>
          {getStatusBadge()}
        </div>

        {config?.connection_status === 'error' && config?.error_message && (
          <Alert className="bg-red-50 border-red-200">
            <XCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>Error de conexión:</strong> {config.error_message}
            </AlertDescription>
          </Alert>
        )}

        {config?.connection_status === 'ok' && (
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              WhatsApp Business conectado correctamente.
              {config.webhook_phone_number && <> Número activo: <strong>{config.webhook_phone_number}</strong></>}
              {config.last_validated_at && <> · Validado: {new Date(config.last_validated_at).toLocaleString()}</>}
            </AlertDescription>
          </Alert>
        )}

        {/* Webhook URL */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Webhook className="h-5 w-5 text-[#25D366]" /> URL del Webhook
            </CardTitle>
            <CardDescription>
              Configura esta URL en Meta for Developers → tu App → WhatsApp → Configuración
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-2">
              <Input value={webhookUrl} readOnly className="font-mono text-sm" />
              <Button variant="outline" onClick={copyWebhook} className="shrink-0">
                {copiedWebhook ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <p className="text-xs text-slate-500">
              En Meta for Developers, suscríbete al evento <code className="bg-slate-100 px-1 rounded">messages</code> de WhatsApp.
            </p>
          </CardContent>
        </Card>

        {/* Credentials */}
        <Card>
          <CardHeader>
            <CardTitle>Credenciales de WhatsApp Business</CardTitle>
            <CardDescription>
              Obtén estas credenciales en <a href="https://developers.facebook.com" target="_blank" className="text-blue-600 underline">developers.facebook.com</a> → Tu App → WhatsApp
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Phone Number ID *</Label>
                <Input
                  value={formData.phone_number_id}
                  onChange={e => setFormData({ ...formData, phone_number_id: e.target.value })}
                  placeholder="123456789012345"
                  className="mt-1 font-mono"
                />
                <p className="text-xs text-slate-500 mt-1">WhatsApp → Primeros pasos → Phone Number ID</p>
              </div>
              <div>
                <Label>Business Account ID</Label>
                <Input
                  value={formData.business_account_id}
                  onChange={e => setFormData({ ...formData, business_account_id: e.target.value })}
                  placeholder="123456789012345"
                  className="mt-1 font-mono"
                />
                <p className="text-xs text-slate-500 mt-1">WhatsApp Business Account ID (WABA ID)</p>
              </div>
            </div>

            <div>
              <Label>Access Token (System User) *</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  type={showToken ? 'text' : 'password'}
                  value={formData.access_token}
                  onChange={e => setFormData({ ...formData, access_token: e.target.value })}
                  placeholder="EAAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  className="font-mono"
                />
                <Button variant="outline" size="icon" onClick={() => setShowToken(!showToken)}>
                  {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-slate-500 mt-1">Token de System User con permisos: whatsapp_business_messaging, whatsapp_business_management</p>
            </div>

            <div>
              <Label>Verify Token *</Label>
              <Input
                value={formData.verify_token}
                onChange={e => setFormData({ ...formData, verify_token: e.target.value })}
                placeholder="mi_token_secreto_wsp_123"
                className="mt-1"
              />
              <p className="text-xs text-slate-500 mt-1">Token personalizado que debes usar también en la configuración del webhook de Meta</p>
            </div>

            <div className="pt-4 border-t flex gap-3">
              <Button onClick={handleSave} disabled={saving} className="bg-[#25D366] hover:bg-[#128C7E]">
                {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                Guardar Configuración
              </Button>
              <Button variant="outline" onClick={testConnection} disabled={testing || !formData.phone_number_id || !formData.access_token}>
                {testing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <CheckCircle className="h-4 w-4 mr-2" />}
                Probar Conexión
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Instrucciones de Configuración</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm text-slate-600">
            <div>
              <h4 className="font-semibold mb-1">1. Crear / Configurar App en Meta for Developers</h4>
              <p>Ve a <a href="https://developers.facebook.com/apps" target="_blank" className="text-blue-600 underline">developers.facebook.com/apps</a>, crea una app de tipo <strong>Business</strong> y agrega el producto <strong>WhatsApp</strong>.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-1">2. Obtener Phone Number ID y Access Token</h4>
              <ul className="list-disc ml-5 space-y-1">
                <li>En tu app, ve a <strong>WhatsApp → Primeros pasos</strong></li>
                <li>Copia el <strong>Phone Number ID</strong> y el <strong>WhatsApp Business Account ID</strong></li>
                <li>Genera un <strong>Access Token de System User</strong> permanente en Business Settings → Usuarios del sistema</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-1">3. Configurar Webhook</h4>
              <ul className="list-disc ml-5 space-y-1">
                <li>En tu app, ve a <strong>WhatsApp → Configuración</strong></li>
                <li>Agrega la URL del webhook mostrada arriba</li>
                <li>Usa el mismo <strong>Verify Token</strong> que configuraste aquí</li>
                <li>Suscríbete al evento <code className="bg-slate-100 px-1 rounded">messages</code></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-1">4. Verificar y usar</h4>
              <p>Guarda la configuración y usa <strong>Probar Conexión</strong> para validar las credenciales. Una vez conectado, podrás enviar y recibir mensajes de WhatsApp desde los leads del CRM.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}