import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Code2, Check, Trash2, ToggleLeft, ToggleRight, Edit, Globe, FileCode } from "lucide-react";
import { toast } from 'sonner';
import WebFormEditor from '@/modules/integraciones/components/webforms/WebFormEditor';
import WebFormEmbedCode from '@/modules/integraciones/components/webforms/WebFormEmbedCode';

export default function WebForms() {
  const [forms, setForms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showEditor, setShowEditor] = useState(false);
  const [showEmbed, setShowEmbed] = useState(false);
  const [selectedForm, setSelectedForm] = useState(null);

  useEffect(() => { loadForms(); }, []);

  const loadForms = async () => {
    setLoading(true);
    const data = await api.entities.WebForm.list('-created_date');
    setForms(data);
    setLoading(false);
  };

  const handleToggle = async (form) => {
    await api.entities.WebForm.update(form.id, { is_active: !form.is_active });
    setForms(forms.map(f => f.id === form.id ? { ...f, is_active: !f.is_active } : f));
    toast.success(form.is_active ? 'Formulario desactivado' : 'Formulario activado');
  };

  const handleDelete = async (form) => {
    if (!confirm(`¿Eliminar el formulario "${form.name}"?`)) return;
    await api.entities.WebForm.delete(form.id);
    setForms(forms.filter(f => f.id !== form.id));
    toast.success('Formulario eliminado');
  };

  const handleEdit = (form) => {
    setSelectedForm(form);
    setShowEditor(true);
  };

  const handleNew = () => {
    setSelectedForm(null);
    setShowEditor(true);
  };

  const handleSaved = () => {
    setShowEditor(false);
    loadForms();
  };

  const handleShowEmbed = (form) => {
    setSelectedForm(form);
    setShowEmbed(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-4 md:p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Formularios Web</h1>
            <p className="text-slate-500 dark:text-zinc-400 text-sm mt-1">Crea formularios embebibles para capturar prospectos desde cualquier web</p>
          </div>
          <Button onClick={handleNew} className="bg-brand hover:bg-brand-dark gap-2 w-full sm:w-auto">
            <Plus className="h-4 w-4" /> Nuevo Formulario
          </Button>
        </div>

        {/* Empty state */}
        {!loading && forms.length === 0 && (
          <Card className="py-16">
            <CardContent className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center">
                <FileCode className="h-8 w-8 text-brand" />
              </div>
              <div>
                <p className="font-semibold text-slate-700">No hay formularios creados</p>
                <p className="text-sm text-slate-500 mt-1">Crea tu primer formulario y pégalo en cualquier landing page</p>
              </div>
              <Button onClick={handleNew} className="bg-brand hover:bg-brand-dark gap-2">
                <Plus className="h-4 w-4" /> Crear primer formulario
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Forms list */}
        <div className="grid gap-4">
          {forms.map(form => (
            <Card key={form.id} className="overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-slate-800 dark:text-white">{form.name}</h3>
                    <Badge className={form.is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}>
                      {form.is_active ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </div>
                  {form.description && <p className="text-sm text-slate-500 dark:text-zinc-400 mt-0.5 truncate">{form.description}</p>}
                  <div className="flex items-center gap-4 mt-2 text-xs text-slate-400 dark:text-zinc-500">
                    <span className="flex items-center gap-1">
                      <Globe className="h-3 w-3" />
                      {(form.fields || []).length} campo(s)
                    </span>
                    <span className="flex items-center gap-1">
                      <Check className="h-3 w-3 text-emerald-500" />
                      {form.submissions_count || 0} envíos
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <Button variant="outline" size="sm" onClick={() => handleShowEmbed(form)} className="gap-1.5">
                    <Code2 className="h-3.5 w-3.5" /> Código
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleEdit(form)} className="gap-1.5">
                    <Edit className="h-3.5 w-3.5" /> Editar
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleToggle(form)} className="gap-1.5">
                    {form.is_active
                      ? <ToggleRight className="h-4 w-4 text-emerald-600" />
                      : <ToggleLeft className="h-4 w-4 text-slate-400" />}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(form)} className="text-red-500 hover:text-red-700">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {showEditor && (
        <WebFormEditor
          open={showEditor}
          form={selectedForm}
          onClose={() => setShowEditor(false)}
          onSaved={handleSaved}
        />
      )}

      {showEmbed && selectedForm && (
        <WebFormEmbedCode
          open={showEmbed}
          form={selectedForm}
          onClose={() => setShowEmbed(false)}
        />
      )}
    </div>
  );
}