import React, { useState, useEffect, useCallback, useRef } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/lib/AuthContext';
import { useBranches } from '@/lib/useBranches';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';
import {
  Facebook, Instagram, Loader2, CheckCircle2, AlertTriangle, XCircle, Circle, Copy, Check, RefreshCw, Eye, EyeOff,
  Plug, Route as RouteIcon, Send, Activity, FlaskConical, RotateCcw, Radio, ExternalLink, Info, KeyRound, Webhook, Zap,
} from 'lucide-react';

const META_EVENTS = ['Lead', 'Contact', 'Schedule', 'SubmitApplication', 'CompleteRegistration', 'InitiateCheckout', 'Purchase'];
const COUNTRIES = [['EC', 'Ecuador'], ['CO', 'Colombia'], ['MX', 'México'], ['PE', 'Perú'], ['CL', 'Chile'], ['AR', 'Argentina'], ['US', 'Estados Unidos'], ['ES', 'España'], ['PA', 'Panamá'], ['CR', 'Costa Rica'], ['GT', 'Guatemala'], ['DO', 'Rep. Dominicana']];

const STATUS_STYLE = {
  ok: { icon: CheckCircle2, cls: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800' },
  warn: { icon: AlertTriangle, cls: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800' },
  error: { icon: XCircle, cls: 'text-red-600', bg: 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' },
  todo: { icon: Circle, cls: 'text-slate-400', bg: 'bg-white dark:bg-zinc-900 border-slate-200 dark:border-zinc-800' },
  optional: { icon: Circle, cls: 'text-slate-300', bg: 'bg-white dark:bg-zinc-900 border-slate-200 dark:border-zinc-800' },
};

const timeAgo = (iso) => {
  if (!iso) return '';
  const s = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `hace ${s}s`;
  if (s < 3600) return `hace ${Math.round(s / 60)} min`;
  if (s < 86400) return `hace ${Math.round(s / 3600)} h`;
  return new Date(iso).toLocaleDateString('es-EC', { day: 'numeric', month: 'short' });
};

function CopyField({ label, value, mono = true, hint }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(value); setCopied(true); toast.success('Copiado'); setTimeout(() => setCopied(false), 1500); } catch { toast.error('No se pudo copiar'); }
  };
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold text-slate-600 dark:text-zinc-400">{label}</Label>
      <div className="flex gap-2">
        <Input readOnly value={value || ''} className={`${mono ? 'font-mono text-xs' : ''} bg-slate-50 dark:bg-zinc-800`} onFocus={(e) => e.target.select()} />
        <Button type="button" variant="outline" size="icon" onClick={copy} aria-label={`Copiar ${label}`}>{copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}</Button>
      </div>
      {hint && <p className="text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

function SecretField({ id, label, isSet, value, onChange, placeholder, hint }) {
  const [show, setShow] = useState(false);
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-xs font-semibold text-slate-600 dark:text-zinc-400">{label}</Label>
      <div className="flex gap-2">
        <Input id={id} type={show ? 'text' : 'password'} autoComplete="off" value={value} onChange={(e) => onChange(e.target.value)}
          placeholder={isSet ? '•••••••• (guardado; escribe solo si quieres cambiarlo)' : placeholder} className="font-mono text-xs" />
        <Button type="button" variant="outline" size="icon" onClick={() => setShow((s) => !s)} aria-label={show ? 'Ocultar' : 'Mostrar'}>{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</Button>
      </div>
      {hint && <p className="text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

function StatusPill({ status }) {
  const map = {
    ok: ['Conectado', 'bg-emerald-100 text-emerald-700 border-emerald-200'],
    error: ['Con errores', 'bg-red-100 text-red-700 border-red-200'],
    not_configured: ['Falta configurar', 'bg-amber-100 text-amber-700 border-amber-200'],
  };
  const [text, cls] = map[status] || map.not_configured;
  return <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${cls}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{text}</span>;
}

function EventSelect({ value, onChange, autoLabel, allowAuto = false }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full sm:w-52 h-9"><SelectValue /></SelectTrigger>
      <SelectContent>
        {allowAuto && <SelectItem value="__auto">{autoLabel || 'Según el tipo de etapa'}</SelectItem>}
        <SelectItem value="__none">No enviar nada</SelectItem>
        {META_EVENTS.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}

export default function MetaIntegration() {
  const { user } = useAuth();
  const isAdmin = user && (user.crm_role === 'admin_crm' || user.role === 'admin');
  const { branches } = useBranches();

  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState('');
  const [tab, setTab] = useState('conexion');
  const [form, setForm] = useState({});
  const [secrets, setSecrets] = useState({ app_secret: '', access_token: '', capi_access_token: '' });
  const [pipelines, setPipelines] = useState([]);
  const [agents, setAgents] = useState([]);
  const [logs, setLogs] = useState([]);
  const [metaLeads, setMetaLeads] = useState([]);
  const [forms, setForms] = useState([]);
  const [editForm, setEditForm] = useState(null);
  const [notes, setNotes] = useState([]);
  const initialised = useRef(false);

  const applyStatus = useCallback((s) => {
    setStatus(s);
    const c = s.config || {};
    const first = !initialised.current; // se decide aquí: el actualizador de setForm corre después
    initialised.current = true;
    setForm((prev) => (!first ? prev : {
      app_id: c.app_id || '', page_id: c.page_id || '', pixel_id: c.pixel_id || '', capi_test_event_code: c.capi_test_event_code || '',
      auto_create_lead: c.auto_create_lead !== false, auto_send_events: c.auto_send_events !== false,
      default_pipeline_id: c.default_pipeline_id || '', default_branch: c.default_branch || 'General', default_premium_estimated: c.default_premium_estimated ?? 0,
      agent_mode: c.agent_mode || 'fixed', default_agent_id: c.default_agent_id || '', round_robin_agent_ids: c.round_robin_agent_ids || [],
      default_country: c.default_country || 'EC', event_map: c.event_map || {},
    }));
  }, []);

  const loadStatus = useCallback(async () => {
    try {
      const { data } = await api.functions.invoke('metaStatus');
      applyStatus(data);
      return data;
    } catch (e) {
      toast.error(e.message || 'No se pudo cargar el estado de Meta');
    }
  }, [applyStatus]);

  // Refresco barato (sin llamar a Meta): contadores y los puntos que dependen de avisos recibidos
  const refreshLight = useCallback(async () => {
    try {
      const { data } = await api.functions.invoke('metaStatus', { light: true });
      setStatus((prev) => {
        if (!prev) return prev;
        const c = data.config || {};
        const when = (iso) => new Date(iso).toLocaleString('es-EC');
        const checks = (prev.checks || []).map((k) => {
          if (k.id === 'events') return { ...k, status: c.last_webhook_at ? 'ok' : 'todo', detail: c.last_webhook_at ? `Último aviso de Meta: ${when(c.last_webhook_at)}` : k.detail };
          if (k.id === 'webhook') return { ...k, status: c.webhook_verified_at ? 'ok' : 'todo', detail: c.webhook_verified_at ? `Meta confirmó la URL el ${when(c.webhook_verified_at)}` : k.detail };
          return k;
        });
        return { ...prev, config: { ...prev.config, ...c }, stats: data.stats, checks };
      });
    } catch { /* ignorar */ }
  }, []);

  const loadActivity = useCallback(async () => {
    try {
      const [l, m, f] = await Promise.all([
        api.entities.MetaEventLog.list('-created_date', 60),
        api.entities.MetaLead.list('-created_date', 30),
        api.entities.MetaLeadAdConfig.list('-created_date'),
      ]);
      setLogs(l); setMetaLeads(m); setForms(f);
    } catch { /* sin permisos o sin datos */ }
  }, []);

  useEffect(() => {
    if (!isAdmin) { setLoading(false); return; }
    (async () => {
      const [s] = await Promise.all([
        loadStatus(),
        loadActivity(),
        api.entities.Pipeline.filter({ is_active: true }, 'sort_order', 50).then(setPipelines).catch(() => {}),
        api.functions.invoke('listAgents', {}).then((r) => setAgents(r.data?.agents || [])).catch(() => {}),
      ]);
      if (s?.status === 'ok') setTab('actividad');
      setLoading(false);
    })();
  }, [isAdmin, loadStatus, loadActivity]);

  // Tiempo real: cada evento nuevo refresca la actividad (y, tras un lead o evento, el estado)
  useEffect(() => {
    if (!isAdmin) return undefined;
    let t;
    const refresh = () => { clearTimeout(t); t = setTimeout(() => { loadActivity(); refreshLight(); }, 400); };
    const u1 = api.entities.MetaEventLog.subscribe(refresh);
    const u2 = api.entities.MetaLead.subscribe(refresh);
    return () => { clearTimeout(t); u1(); u2(); };
  }, [isAdmin, loadActivity, refreshLight]);

  const call = async (name, payload, label) => {
    setBusy(label);
    try {
      const { data } = await api.functions.invoke(name, payload);
      return data;
    } catch (e) {
      toast.error(e.message || 'Error');
      return null;
    } finally { setBusy(''); }
  };

  const save = async (fields, { verify = false, successMsg = 'Guardado' } = {}) => {
    const body = { ...fields, verify };
    const data = await call('metaConnect', body, verify ? 'connect' : 'save');
    if (!data) return null;
    applyStatus(data);
    setNotes(data.notes || []);
    toast.success(successMsg);
    return data;
  };

  const handleConnect = async () => {
    if (!form.app_id?.trim()) return toast.error('Falta el App ID');
    if (!status?.config?.app_secret_set && !secrets.app_secret.trim()) return toast.error('Falta el App Secret');
    if (!status?.config?.access_token_set && !secrets.access_token.trim()) return toast.error('Falta el token de acceso');
    const data = await save({ app_id: form.app_id, page_id: form.page_id, pixel_id: form.pixel_id, capi_test_event_code: form.capi_test_event_code, ...secrets }, { verify: true, successMsg: 'Conexión verificada' });
    if (data) {
      setSecrets({ app_secret: '', access_token: '', capi_access_token: '' });
      loadActivity();
      if (data.status === 'ok') toast.success('¡Todo listo! Falta solo que Meta verifique el webhook si aún no lo hizo.');
    }
  };

  const doAction = async (action, extra = {}, label = action) => {
    const data = await call('metaAction', { action, ...extra }, label);
    if (data) { await loadStatus(); await loadActivity(); }
    return data;
  };

  const handleSimulate = async () => {
    const r = await doAction('simulate_lead', {}, 'simulate');
    if (r?.success) toast.success('Lead de prueba creado: míralo en el Pipeline');
    else if (r) toast.error(r.result?.error || 'No se pudo simular el lead');
  };
  const handleTestEvent = async () => {
    const r = await doAction('test_event', {}, 'test_event');
    if (r?.success) toast.success(r.test_mode ? 'Evento enviado en modo prueba: míralo en Events Manager → Probar eventos' : 'Evento de prueba enviado a Meta');
    else if (r) toast.error(r.error || 'Meta rechazó el evento');
  };
  const handleRetryAll = async () => {
    const r = await doAction('retry_all', {}, 'retry_all');
    if (r) toast.success(`Reintentados: ${r.leads} lead(s) y ${r.events} evento(s)`);
  };
  const handleRegenerate = async () => {
    if (!window.confirm('Se generará un token nuevo y el actual dejará de funcionar. Tendrás que pegar el nuevo en tu app de Meta. ¿Continuar?')) return;
    const r = await doAction('regenerate_token', {}, 'regen');
    if (r) toast.success('Token regenerado: pégalo en Meta');
  };

  // ───────── Mapa de eventos
  const evMap = form.event_map || {};
  const evValue = (key, def) => (Object.prototype.hasOwnProperty.call(evMap, key) ? (evMap[key] === '' ? '__none' : evMap[key]) : def);
  const setEv = (key, v, { auto = false } = {}) => setForm((f) => {
    const m = { ...(f.event_map || {}) };
    if (auto && v === '__auto') delete m[key]; else m[key] = v === '__none' ? '' : v;
    return { ...f, event_map: m };
  });

  const activePipeline = pipelines.find((p) => p.id === form.default_pipeline_id) || pipelines[0];
  const webhookUrl = status?.webhook_url || '';
  const isLocal = /^https?:\/\/(localhost|127\.|0\.0\.0\.0|\[::1\])/.test(webhookUrl);
  const notHttps = webhookUrl && !webhookUrl.startsWith('https://');

  if (!isAdmin) {
    return <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center p-6"><Alert className="max-w-md"><AlertTriangle className="h-4 w-4" /><AlertDescription>Solo los administradores pueden configurar Meta.</AlertDescription></Alert></div>;
  }
  if (loading) {
    return <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-brand" /></div>;
  }

  const pixelSnippet = form.pixel_id || status?.config?.pixel_id
    ? `<!-- Meta Pixel -->\n<script>\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');\nfbq('init','${status?.config?.pixel_id || form.pixel_id}');\nfbq('track','PageView');\n</script>`
    : '';

  const leadsPending = status?.stats?.leads_error || 0;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-4 md:p-6">
      <div className="max-w-5xl mx-auto space-y-5">
        {/* Encabezado */}
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-xl bg-[#1877F2] flex items-center justify-center text-white"><Facebook className="h-6 w-6" /></div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">Meta <Instagram className="h-5 w-5 text-pink-500" /></h1>
              <p className="text-sm text-slate-500 dark:text-zinc-400">Recibe leads de Facebook e Instagram y devuelve a Meta cuáles se convierten</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <StatusPill status={status?.status} />
            <Button variant="outline" size="sm" onClick={async () => { setBusy('refresh'); await loadStatus(); await loadActivity(); setBusy(''); }} disabled={!!busy}>
              <RefreshCw className={`h-4 w-4 mr-2 ${busy === 'refresh' ? 'animate-spin' : ''}`} />Revisar ahora
            </Button>
          </div>
        </div>

        {isLocal && (
          <Alert className="border-amber-300 bg-amber-50 dark:bg-amber-900/20">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800 dark:text-amber-300 text-sm">
              Esta instalación usa <b>{webhookUrl.split('/api')[0]}</b>. Meta solo puede llamar a una dirección pública con HTTPS. Para probar desde tu computador usa un túnel (Cloudflare Tunnel, ngrok) y define <code>APP_URL</code> con esa dirección; en producción, tu dominio.
            </AlertDescription>
          </Alert>
        )}
        {!isLocal && notHttps && (
          <Alert className="border-amber-300 bg-amber-50"><AlertTriangle className="h-4 w-4 text-amber-600" /><AlertDescription className="text-amber-800 text-sm">Meta exige HTTPS para el webhook.</AlertDescription></Alert>
        )}

        {/* Checklist de estado */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Radio className="h-4 w-4 text-brand" />Estado de la conexión</CardTitle>
            <CardDescription>Cada punto se comprueba contra Meta en tiempo real. Si algo falla, aquí dice qué hacer.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {(status?.checks || []).map((c) => {
              const st = STATUS_STYLE[c.status] || STATUS_STYLE.todo;
              const Icon = st.icon;
              return (
                <div key={c.id} className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 ${st.bg}`}>
                  <Icon className={`h-5 w-5 mt-0.5 shrink-0 ${st.cls}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-800 dark:text-zinc-100">{c.label}{c.status === 'optional' && <span className="ml-2 text-xs font-normal text-slate-400">opcional</span>}</p>
                    <p className="text-xs text-slate-600 dark:text-zinc-400 break-words">{c.detail}</p>
                  </div>
                  {c.action?.id === 'subscribe' && (
                    <Button size="sm" onClick={() => doAction('subscribe', {}, 'subscribe').then((r) => r?.success && toast.success('Página suscrita'))} disabled={!!busy}>
                      {busy === 'subscribe' ? <Loader2 className="h-4 w-4 animate-spin" /> : c.action.label}
                    </Button>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 p-1 h-auto flex-wrap gap-1">
            <TabsTrigger value="conexion" className="gap-2 data-[state=active]:bg-brand data-[state=active]:text-white"><Plug className="h-4 w-4" />Conexión</TabsTrigger>
            <TabsTrigger value="ruteo" className="gap-2 data-[state=active]:bg-brand data-[state=active]:text-white"><RouteIcon className="h-4 w-4" />Qué hacer con los leads</TabsTrigger>
            <TabsTrigger value="eventos" className="gap-2 data-[state=active]:bg-brand data-[state=active]:text-white"><Send className="h-4 w-4" />Eventos a Meta</TabsTrigger>
            <TabsTrigger value="actividad" className="gap-2 data-[state=active]:bg-brand data-[state=active]:text-white"><Activity className="h-4 w-4" />Actividad{leadsPending > 0 && <Badge className="ml-1 bg-red-500 h-5 px-1.5">{leadsPending}</Badge>}</TabsTrigger>
          </TabsList>

          {/* ───────────── CONEXIÓN ───────────── */}
          <TabsContent value="conexion" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2"><Webhook className="h-4 w-4 text-brand" />Paso 1 · Pega estos dos datos en tu app de Meta</CardTitle>
                <CardDescription>Meta los pide una sola vez, en <b>developers.facebook.com → tu app → Webhooks → Page</b>.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <CopyField label="URL de devolución de llamada" value={webhookUrl} />
                  <div>
                    <CopyField label="Token de verificación" value={status?.config?.verify_token} hint="Se generó solo; no tienes que inventarlo." />
                    <button type="button" onClick={handleRegenerate} className="text-xs text-slate-500 hover:text-red-600 underline mt-1">Generar uno nuevo</button>
                  </div>
                </div>
                <ol className="text-sm text-slate-600 dark:text-zinc-400 space-y-1 list-decimal pl-5">
                  <li>En <b>Webhooks</b> elige el objeto <b>Page</b> y pulsa <b>Suscribirse</b> / <b>Editar suscripción</b>.</li>
                  <li>Pega la <b>URL</b> y el <b>token</b> de arriba y pulsa <b>Verificar y guardar</b>. El punto <i>“Webhook verificado”</i> se pondrá verde.</li>
                  <li>Marca el campo <b>leadgen</b> y pulsa Suscribir.</li>
                </ol>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2"><KeyRound className="h-4 w-4 text-brand" />Paso 2 · Credenciales de tu app</CardTitle>
                <CardDescription>Se guardan cifradas en tu servidor y nunca se vuelven a mostrar.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="app_id" className="text-xs font-semibold text-slate-600 dark:text-zinc-400">App ID</Label>
                    <Input id="app_id" value={form.app_id || ''} onChange={(e) => setForm({ ...form, app_id: e.target.value })} placeholder="1234567890123456" className="font-mono text-xs" />
                    <p className="text-xs text-slate-500">Configuración de la app → Básica</p>
                  </div>
                  <SecretField id="app_secret" label="App Secret" isSet={status?.config?.app_secret_set} value={secrets.app_secret} onChange={(v) => setSecrets({ ...secrets, app_secret: v })} placeholder="Clave secreta de la app" hint="Sirve para comprobar que los avisos vienen de Meta." />
                </div>
                <SecretField id="access_token" label="Token de acceso (usuario del sistema)" isSet={status?.config?.access_token_set} value={secrets.access_token} onChange={(v) => setSecrets({ ...secrets, access_token: v })} placeholder="EAAG…"
                  hint="Business Settings → Usuarios del sistema → Generar token. Permisos: leads_retrieval, pages_manage_metadata, pages_show_list, pages_read_engagement (+ ads_management para el Pixel). Elige “Sin vencimiento”." />
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="page_id" className="text-xs font-semibold text-slate-600 dark:text-zinc-400">ID de la página de Facebook</Label>
                    <Input id="page_id" value={form.page_id || ''} onChange={(e) => setForm({ ...form, page_id: e.target.value })} placeholder="1111111111" className="font-mono text-xs" />
                    <p className="text-xs text-slate-500">El CRM suscribe la página a los leads por ti.</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="pixel_id" className="text-xs font-semibold text-slate-600 dark:text-zinc-400">Pixel ID <span className="font-normal text-slate-400">(opcional)</span></Label>
                    <Input id="pixel_id" value={form.pixel_id || ''} onChange={(e) => setForm({ ...form, pixel_id: e.target.value })} placeholder="9999999999" className="font-mono text-xs" />
                    <p className="text-xs text-slate-500">Para devolver a Meta qué leads se convierten.</p>
                  </div>
                </div>
                <details className="rounded-lg border border-slate-200 dark:border-zinc-700 px-3 py-2 text-sm">
                  <summary className="cursor-pointer font-medium text-slate-700 dark:text-zinc-300">Opciones avanzadas</summary>
                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <SecretField id="capi_token" label="Token distinto para el Pixel" isSet={status?.config?.capi_access_token_set} value={secrets.capi_access_token} onChange={(v) => setSecrets({ ...secrets, capi_access_token: v })} placeholder="Solo si el Pixel usa otro token" hint="Si lo dejas vacío se usa el token de acceso." />
                    <div className="space-y-1.5">
                      <Label htmlFor="test_code" className="text-xs font-semibold text-slate-600 dark:text-zinc-400">Código de “Probar eventos”</Label>
                      <Input id="test_code" value={form.capi_test_event_code || ''} onChange={(e) => setForm({ ...form, capi_test_event_code: e.target.value })} placeholder="TEST12345" className="font-mono text-xs" />
                      <p className="text-xs text-slate-500">Mientras esté puesto, los eventos van a la pestaña de pruebas de Meta y no afectan tus campañas. <b>Bórralo en producción.</b></p>
                    </div>
                  </div>
                </details>
                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <Button onClick={handleConnect} disabled={!!busy} className="bg-brand hover:bg-brand-dark">
                    {busy === 'connect' ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Plug className="h-4 w-4 mr-2" />}Guardar y verificar conexión
                  </Button>
                  <span className="text-xs text-slate-500">Comprueba el token, suscribe la página y revisa el Pixel.</span>
                </div>
                {notes.map((n, i) => <Alert key={i}><Info className="h-4 w-4" /><AlertDescription className="text-sm">{n}</AlertDescription></Alert>)}
              </CardContent>
            </Card>

            <Card className="border-blue-200 dark:border-blue-900">
              <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Info className="h-4 w-4 text-blue-600" />Si el token es válido pero no llegan leads, revisa esto</CardTitle></CardHeader>
              <CardContent className="text-sm text-slate-600 dark:text-zinc-400 space-y-1.5">
                <p>• <b>La app debe estar en modo “Activo” (Live).</b> En modo desarrollo, Meta solo envía leads creados por personas con rol en la app.</p>
                <p>• En <b>Business Settings → Integraciones → Acceso a clientes potenciales</b>, asigna este CRM/app a tu página.</p>
                <p>• La página debe estar <b>asignada al usuario del sistema</b> con control total.</p>
                <p>• Prueba rápido con la <a className="text-brand underline inline-flex items-center gap-1" href="https://developers.facebook.com/tools/lead-ads-testing" target="_blank" rel="noopener noreferrer">herramienta de prueba de Lead Ads <ExternalLink className="h-3 w-3" /></a>: crea un lead de prueba y debe aparecer en <i>Actividad</i>.</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ───────────── QUÉ HACER CON LOS LEADS ───────────── */}
          <TabsContent value="ruteo" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Cuando llega un lead de Meta…</CardTitle>
                <CardDescription>Se crea el prospecto (sin duplicar por correo o teléfono) y, si quieres, el lead en el pipeline.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="flex items-center justify-between rounded-lg border px-4 py-3">
                  <div><p className="text-sm font-semibold">Crear un lead en el pipeline</p><p className="text-xs text-slate-500">Si lo apagas, solo se crea el prospecto.</p></div>
                  <Switch checked={form.auto_create_lead !== false} onCheckedChange={(v) => setForm({ ...form, auto_create_lead: v })} />
                </div>
                {form.auto_create_lead !== false && (
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-semibold">Pipeline</Label>
                      <Select value={form.default_pipeline_id || activePipeline?.id || ''} onValueChange={(v) => setForm({ ...form, default_pipeline_id: v })}>
                        <SelectTrigger><SelectValue placeholder="Elige un pipeline" /></SelectTrigger>
                        <SelectContent>{pipelines.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                      </Select>
                      <p className="text-xs text-slate-500">Entra en la primera etapa{activePipeline?.stages?.[0] ? ` (“${activePipeline.stages[0].label}”)` : ''}.</p>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-semibold">Ramo</Label>
                      <Select value={form.default_branch || 'General'} onValueChange={(v) => setForm({ ...form, default_branch: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{branches.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-semibold">Prima estimada</Label>
                      <Input type="number" min="0" value={form.default_premium_estimated ?? 0} onChange={(e) => setForm({ ...form, default_premium_estimated: e.target.value })} />
                      <p className="text-xs text-slate-500">Es el valor que se informa a Meta si el lead se gana.</p>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="text-xs font-semibold">¿A quién se asigna?</Label>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {[['fixed', 'A un agente fijo', 'Todos los leads van a la misma persona.'], ['round_robin', 'Rotar entre agentes', 'Se reparten por turnos, uno a uno.']].map(([val, t, d]) => (
                      <button key={val} type="button" onClick={() => setForm({ ...form, agent_mode: val })}
                        className={`text-left rounded-lg border px-4 py-3 transition ${form.agent_mode === val ? 'border-brand bg-brand/5 ring-1 ring-brand' : 'hover:border-slate-300'}`}>
                        <p className="text-sm font-semibold">{t}</p><p className="text-xs text-slate-500">{d}</p>
                      </button>
                    ))}
                  </div>
                  {form.agent_mode === 'round_robin' ? (
                    <div className="rounded-lg border p-3 grid sm:grid-cols-2 gap-2">
                      {agents.map((a) => {
                        const on = (form.round_robin_agent_ids || []).includes(a.id);
                        return (
                          <label key={a.id} className="flex items-center gap-2 text-sm cursor-pointer">
                            <input type="checkbox" checked={on} onChange={() => setForm({ ...form, round_robin_agent_ids: on ? form.round_robin_agent_ids.filter((x) => x !== a.id) : [...(form.round_robin_agent_ids || []), a.id] })} />
                            {a.full_name || a.email}
                          </label>
                        );
                      })}
                    </div>
                  ) : (
                    <Select value={form.default_agent_id || '__admin'} onValueChange={(v) => setForm({ ...form, default_agent_id: v === '__admin' ? '' : v })}>
                      <SelectTrigger className="sm:w-80"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__admin">Un administrador (por defecto)</SelectItem>
                        {agents.map((a) => <SelectItem key={a.id} value={a.id}>{a.full_name || a.email}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  )}
                  <p className="text-xs text-slate-500">Un lead nunca queda sin dueño: los agentes solo ven los suyos.</p>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">País de tus clientes</Label>
                  <Select value={form.default_country || 'EC'} onValueChange={(v) => setForm({ ...form, default_country: v })}>
                    <SelectTrigger className="sm:w-60"><SelectValue /></SelectTrigger>
                    <SelectContent>{COUNTRIES.map(([c, n]) => <SelectItem key={c} value={c}>{n}</SelectItem>)}</SelectContent>
                  </Select>
                  <p className="text-xs text-slate-500">Para convertir teléfonos como 0991234567 al formato internacional.</p>
                </div>

                <Button onClick={() => save({
                  auto_create_lead: form.auto_create_lead, default_pipeline_id: form.default_pipeline_id || activePipeline?.id || '', default_branch: form.default_branch,
                  default_premium_estimated: form.default_premium_estimated, agent_mode: form.agent_mode, default_agent_id: form.default_agent_id,
                  round_robin_agent_ids: form.round_robin_agent_ids, default_country: form.default_country,
                })} disabled={!!busy} className="bg-brand hover:bg-brand-dark">
                  {busy === 'save' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Guardar
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Formularios detectados</CardTitle>
                <CardDescription>No hay que registrarlos: aparecen solos con el primer lead. Úsalo solo si un formulario necesita un trato distinto.</CardDescription>
              </CardHeader>
              <CardContent>
                {forms.length === 0 ? <p className="text-sm text-slate-500">Todavía no ha llegado ningún formulario.</p> : (
                  <div className="divide-y">
                    {forms.map((f) => (
                      <div key={f.id} className="flex items-center gap-3 py-2.5">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold truncate">{f.form_name}</p>
                          <p className="text-xs text-slate-500">{f.leads_received || 0} leads{f.last_lead_received_at ? ` · último ${timeAgo(f.last_lead_received_at)}` : ''}{(f.default_pipeline_id || f.default_assigned_agent_id || f.default_branch) ? ' · con ajustes propios' : ''}</p>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setEditForm({ ...f })}>Ajustar</Button>
                        <Switch checked={f.is_active !== false} onCheckedChange={async (v) => { await api.entities.MetaLeadAdConfig.update(f.id, { is_active: v }); loadActivity(); }} aria-label="Activo" />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ───────────── EVENTOS A META ───────────── */}
          <TabsContent value="eventos" className="space-y-4 mt-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2"><Zap className="h-4 w-4 text-brand" />Devolver resultados a Meta (API de conversiones)</CardTitle>
                <CardDescription>Meta aprende de qué anuncios traen clientes reales y no solo formularios llenos. Los datos personales viajan cifrados (hash SHA-256).</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {!status?.config?.pixel_id && <Alert><Info className="h-4 w-4" /><AlertDescription className="text-sm">Añade tu <b>Pixel ID</b> en la pestaña Conexión para activar esto.</AlertDescription></Alert>}
                <div className="flex items-center justify-between rounded-lg border px-4 py-3">
                  <div><p className="text-sm font-semibold">Enviar eventos automáticamente</p><p className="text-xs text-slate-500">Solo para leads que vienen de Meta. Cada evento se envía una vez.</p></div>
                  <Switch checked={form.auto_send_events !== false} onCheckedChange={(v) => setForm({ ...form, auto_send_events: v })} />
                </div>

                <div className="space-y-3">
                  {[['__created', 'Se crea el lead', 'Lead', false], ['__won', 'El lead pasa a una etapa de “ganado”', 'Purchase', false], ['__lost', 'El lead pasa a una etapa de “perdido”', '__none', false]].map(([key, label, def]) => (
                    <div key={key} className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-sm text-slate-700 dark:text-zinc-300">{label}</span>
                      <EventSelect value={evValue(key, def)} onChange={(v) => setEv(key, v)} />
                    </div>
                  ))}
                </div>

                {activePipeline?.stages?.length > 0 && (
                  <details className="rounded-lg border px-3 py-2">
                    <summary className="cursor-pointer text-sm font-medium">Ajustar por etapa del pipeline “{activePipeline.name}”</summary>
                    <div className="space-y-2 mt-3">
                      {activePipeline.stages.map((s) => (
                        <div key={s.key} className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-sm flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />{s.label}</span>
                          <EventSelect value={evValue(s.key, '__auto')} onChange={(v) => setEv(s.key, v, { auto: true })} allowAuto />
                        </div>
                      ))}
                    </div>
                  </details>
                )}

                <div className="flex flex-wrap gap-3">
                  <Button onClick={() => save({ auto_send_events: form.auto_send_events, event_map: form.event_map })} disabled={!!busy} className="bg-brand hover:bg-brand-dark">
                    {busy === 'save' && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Guardar
                  </Button>
                  <Button variant="outline" onClick={handleTestEvent} disabled={!!busy || !status?.config?.pixel_id}>
                    {busy === 'test_event' ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FlaskConical className="h-4 w-4 mr-2" />}Enviar evento de prueba
                  </Button>
                </div>
              </CardContent>
            </Card>

            {pixelSnippet && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Pixel para tu sitio web</CardTitle>
                  <CardDescription>Los formularios web de este CRM ya lo incluyen solos. Pega este código solo en páginas tuyas que no usen esos formularios.</CardDescription>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-slate-900 text-slate-100 rounded-lg p-3 overflow-x-auto max-h-48">{pixelSnippet}</pre>
                  <Button variant="outline" size="sm" className="mt-2" onClick={() => { navigator.clipboard.writeText(pixelSnippet); toast.success('Código copiado'); }}><Copy className="h-4 w-4 mr-2" />Copiar</Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ───────────── ACTIVIDAD ───────────── */}
          <TabsContent value="actividad" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[['Leads recibidos', status?.stats?.leads ?? 0, 'text-slate-900'], ['Leads con error', status?.stats?.leads_error ?? 0, status?.stats?.leads_error ? 'text-red-600' : 'text-slate-900'],
                ['Eventos enviados a Meta', status?.stats?.events_sent ?? 0, 'text-slate-900'], ['Eventos con error', status?.stats?.events_error ?? 0, status?.stats?.events_error ? 'text-red-600' : 'text-slate-900']].map(([l, v, c]) => (
                <Card key={l}><CardContent className="p-4"><p className="text-xs text-slate-500">{l}</p><p className={`text-2xl font-bold ${c} dark:text-white`}>{v}</p></CardContent></Card>
              ))}
            </div>

            <div className="flex flex-wrap gap-3">
              <Button onClick={handleSimulate} disabled={!!busy} className="bg-brand hover:bg-brand-dark">
                {busy === 'simulate' ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FlaskConical className="h-4 w-4 mr-2" />}Simular un lead de Meta
              </Button>
              <Button variant="outline" onClick={handleRetryAll} disabled={!!busy || (!leadsPending && !status?.stats?.events_error)}>
                {busy === 'retry_all' ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RotateCcw className="h-4 w-4 mr-2" />}Reintentar fallidos
              </Button>
              <p className="text-xs text-slate-500 self-center">“Simular” recorre el mismo camino que un lead real (sin llamar a Meta ni enviarle datos).</p>
            </div>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Leads de Meta</CardTitle></CardHeader>
              <CardContent>
                {metaLeads.length === 0 ? <p className="text-sm text-slate-500 py-4 text-center">Aún no hay leads. Usa “Simular un lead” o la herramienta de prueba de Meta.</p> : (
                  <div className="divide-y">
                    {metaLeads.map((m) => (
                      <div key={m.id} className="flex items-center gap-3 py-2.5">
                        {m.source_channel === 'instagram' ? <Instagram className="h-4 w-4 text-pink-500 shrink-0" /> : <Facebook className="h-4 w-4 text-[#1877F2] shrink-0" />}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold truncate">{m.prospect_name || `Lead ${m.leadgen_id}`}{m.is_test && <Badge variant="outline" className="ml-2 text-[10px]">prueba</Badge>}</p>
                          <p className="text-xs text-slate-500 truncate">{[m.campaign_name, m.form_name].filter(Boolean).join(' · ') || m.leadgen_id} · {timeAgo(m.created_date)}</p>
                          {m.processing_status === 'error' && <p className="text-xs text-red-600 break-words">{m.error_message}</p>}
                        </div>
                        <Badge className={m.processing_status === 'processed' ? 'bg-emerald-100 text-emerald-700' : m.processing_status === 'duplicate' ? 'bg-blue-100 text-blue-700' : m.processing_status === 'error' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}>
                          {{ processed: 'Procesado', duplicate: 'Ya existía', error: 'Error', pending: 'En proceso' }[m.processing_status] || m.processing_status}
                        </Badge>
                        {m.processing_status === 'error' && (
                          <Button size="sm" variant="outline" onClick={() => doAction('retry_lead', { meta_lead_id: m.id }, `retry_${m.id}`).then((r) => r && (r.success ? toast.success('Lead procesado') : toast.error(r.result?.error || 'Sigue fallando')))} disabled={!!busy}>
                            {busy === `retry_${m.id}` ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Reintentar'}
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Bitácora en vivo</CardTitle><CardDescription>Todo lo que entra y sale hacia Meta, con el motivo si algo falla.</CardDescription></CardHeader>
              <CardContent>
                {logs.length === 0 ? <p className="text-sm text-slate-500 py-4 text-center">Sin movimiento todavía.</p> : (
                  <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1">
                    {logs.map((l) => {
                      const st = STATUS_STYLE[l.status === 'skipped' ? 'todo' : l.status] || STATUS_STYLE.ok;
                      const Icon = st.icon;
                      return (
                        <div key={l.id} className="flex items-start gap-2.5 text-sm">
                          <Icon className={`h-4 w-4 mt-0.5 shrink-0 ${st.cls}`} />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-slate-800 dark:text-zinc-100">{l.title}{l.test && <Badge variant="outline" className="ml-2 text-[10px]">prueba</Badge>}</p>
                            {l.message && <p className="text-xs text-slate-500 break-words">{l.message}</p>}
                          </div>
                          <span className="text-xs text-slate-400 whitespace-nowrap">{timeAgo(l.created_date)}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Ajustes propios de un formulario */}
      <Dialog open={!!editForm} onOpenChange={(o) => !o && setEditForm(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editForm?.form_name}</DialogTitle></DialogHeader>
          {editForm && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500">Lo que dejes en “Como el resto” usa la configuración general.</p>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Pipeline</Label>
                <Select value={editForm.default_pipeline_id || '__g'} onValueChange={(v) => setEditForm({ ...editForm, default_pipeline_id: v === '__g' ? '' : v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="__g">Como el resto</SelectItem>{pipelines.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Ramo</Label>
                <Select value={editForm.default_branch || '__g'} onValueChange={(v) => setEditForm({ ...editForm, default_branch: v === '__g' ? '' : v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="__g">Como el resto</SelectItem>{branches.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Agente</Label>
                <Select value={editForm.default_assigned_agent_id || '__g'} onValueChange={(v) => setEditForm({ ...editForm, default_assigned_agent_id: v === '__g' ? '' : v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="__g">Como el resto</SelectItem>{agents.map((a) => <SelectItem key={a.id} value={a.id}>{a.full_name || a.email}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditForm(null)}>Cancelar</Button>
            <Button className="bg-brand hover:bg-brand-dark" onClick={async () => {
              const agent = agents.find((a) => a.id === editForm.default_assigned_agent_id);
              const pl = pipelines.find((p) => p.id === editForm.default_pipeline_id);
              await api.entities.MetaLeadAdConfig.update(editForm.id, {
                default_pipeline_id: editForm.default_pipeline_id || '', default_pipeline_name: pl?.name || '', default_branch: editForm.default_branch || '',
                default_assigned_agent_id: editForm.default_assigned_agent_id || '', default_assigned_agent_name: agent?.full_name || '',
              });
              setEditForm(null); loadActivity(); toast.success('Formulario actualizado');
            }}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
