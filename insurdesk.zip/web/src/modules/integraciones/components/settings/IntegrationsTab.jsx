import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Facebook, FileCode, MessageCircle } from 'lucide-react';

export default function IntegrationsTab() {
  return (
    <div className="space-y-4">
    {/* Meta (Facebook / Instagram) */}
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Facebook className="h-5 w-5 text-blue-600" /> Meta · Facebook e Instagram
        </CardTitle>
        <CardDescription>Recibe leads de tus anuncios y devuelve a Meta qué leads se convierten (Pixel y API de conversiones)</CardDescription>
      </CardHeader>
      <CardContent className="flex items-center justify-between">
        <p className="text-sm text-slate-500 max-w-md">
          Una sola pantalla: conexión paso a paso con diagnóstico, qué hacer con cada lead, eventos hacia Meta y bitácora en vivo.
        </p>
        <Link to={createPageUrl('MetaIntegration')}>
          <Button className="gap-2 bg-blue-600 hover:bg-blue-700 whitespace-nowrap">
            <Facebook className="h-4 w-4" /> Configurar Meta
          </Button>
        </Link>
      </CardContent>
    </Card>

    {/* Web Forms */}
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileCode className="h-5 w-5 text-brand" /> Formularios Web Embebibles
        </CardTitle>
        <CardDescription>Genera formularios HTML/JS para capturar prospectos desde cualquier landing page o sitio web</CardDescription>
      </CardHeader>
      <CardContent className="flex items-center justify-between">
        <p className="text-sm text-slate-500 max-w-md">
          Crea formularios personalizados y pega el código en tu web. Los envíos llegan directamente como prospectos al CRM.
        </p>
        <Link to={createPageUrl('WebForms')}>
          <Button className="gap-2 bg-brand hover:bg-brand-dark whitespace-nowrap">
            <FileCode className="h-4 w-4" /> Gestionar Formularios
          </Button>
        </Link>
      </CardContent>
    </Card>

    {/* WhatsApp Business */}
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <MessageCircle className="h-5 w-5 text-[#25D366]" /> WhatsApp Business API
        </CardTitle>
        <CardDescription>Integración con WhatsApp Business para enviar y recibir mensajes desde los leads</CardDescription>
      </CardHeader>
      <CardContent className="flex items-center justify-between">
        <p className="text-sm text-slate-500 max-w-md">
          Conecta tu número de WhatsApp Business para comunicarte con prospectos directamente desde el CRM y registrar el historial de conversaciones.
        </p>
        <Link to={createPageUrl('WhatsAppSettings')}>
          <Button className="gap-2 whitespace-nowrap" style={{ backgroundColor: '#25D366' }} onMouseEnter={e => e.currentTarget.style.backgroundColor = '#128C7E'} onMouseLeave={e => e.currentTarget.style.backgroundColor = '#25D366'}>
            <MessageCircle className="h-4 w-4" /> Configurar WhatsApp
          </Button>
        </Link>
      </CardContent>
    </Card>
    </div>
  );
}
