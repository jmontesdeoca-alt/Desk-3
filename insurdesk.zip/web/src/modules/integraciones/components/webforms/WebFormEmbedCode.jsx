import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { toast } from 'sonner';

export default function WebFormEmbedCode({ open, form, onClose }) {
  const [copied, setCopied] = useState(false);
  const [pixelId, setPixelId] = useState('');

  // Pixel ID de Meta (dato público, no secreto): si existe, el código incluye el Pixel y el evento Lead
  useEffect(() => {
    api.functions.invoke('getMetaPublicConfig').then((r) => setPixelId(/^\d{5,20}$/.test(r.data?.pixel_id || '') ? r.data.pixel_id : '')).catch(() => {});
  }, []);

  // URL pública del CRM: el formulario embebido en sitios externos envía los datos aquí
  const baseUrl = window.location.origin;
  const submitUrl = `${baseUrl}/api/functions/webFormSubmit`;

  const generateEmbedHtml = () => {
    const fields = form.fields || [];
    const color = form.primary_color || '#2F4F9D';
    const token = form.form_token;

    const PHONE_COUNTRIES = [
      {code:'+593',name:'Ecuador 🇪🇨',country:'Ecuador'},{code:'+57',name:'Colombia 🇨🇴',country:'Colombia'},
      {code:'+52',name:'México 🇲🇽',country:'México'},{code:'+51',name:'Perú 🇵🇪',country:'Perú'},
      {code:'+56',name:'Chile 🇨🇱',country:'Chile'},{code:'+54',name:'Argentina 🇦🇷',country:'Argentina'},
      {code:'+58',name:'Venezuela 🇻🇪',country:'Venezuela'},{code:'+591',name:'Bolivia 🇧🇴',country:'Bolivia'},
      {code:'+595',name:'Paraguay 🇵🇾',country:'Paraguay'},{code:'+598',name:'Uruguay 🇺🇾',country:'Uruguay'},
      {code:'+55',name:'Brasil 🇧🇷',country:'Brasil'},{code:'+1',name:'EEUU/Canadá 🇺🇸',country:'Estados Unidos'},
      {code:'+34',name:'España 🇪🇸',country:'España'},{code:'+502',name:'Guatemala 🇬🇹',country:'Guatemala'},
      {code:'+504',name:'Honduras 🇭🇳',country:'Honduras'},{code:'+503',name:'El Salvador 🇸🇻',country:'El Salvador'},
      {code:'+505',name:'Nicaragua 🇳🇮',country:'Nicaragua'},{code:'+506',name:'Costa Rica 🇨🇷',country:'Costa Rica'},
      {code:'+507',name:'Panamá 🇵🇦',country:'Panamá'},{code:'+53',name:'Cuba 🇨🇺',country:'Cuba'},
      {code:'+351',name:'Portugal 🇵🇹',country:'Portugal'},{code:'+44',name:'Reino Unido 🇬🇧',country:'Reino Unido'},
      {code:'+33',name:'Francia 🇫🇷',country:'Francia'},{code:'+49',name:'Alemania 🇩🇪',country:'Alemania'},
      {code:'+39',name:'Italia 🇮🇹',country:'Italia'},{code:'+61',name:'Australia 🇦🇺',country:'Australia'},
    ];

    const COUNTRY_LIST = [
      'Ecuador','Colombia','México','Perú','Chile','Argentina','Venezuela','Bolivia',
      'Paraguay','Uruguay','Brasil','Estados Unidos','Canadá','España','Guatemala',
      'Honduras','El Salvador','Nicaragua','Costa Rica','Panamá','Cuba','República Dominicana',
      'Portugal','Reino Unido','Francia','Alemania','Italia','Australia','Otro',
    ];

    const phoneCountriesOpts = PHONE_COUNTRIES.map(c =>
      `<option value="${c.code}" data-country="${c.country}">${c.name} (${c.code})</option>`
    ).join('');

    const countryOpts = COUNTRY_LIST.map(c =>
      `<option value="${c}">${c}</option>`
    ).join('');

    const inputStyle = 'width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;box-sizing:border-box';

    const telFields = fields.filter(f => f.type === 'tel');

    const fieldsHtml = fields.map(f => {
      const labelHtml = `<label style="display:block;margin-bottom:4px;font-size:14px;font-weight:500;color:#374151">${f.label}${f.required ? ' *' : ''}</label>`;

      if (f.type === 'textarea') {
        return `
    <div style="margin-bottom:16px">
      ${labelHtml}
      <textarea name="${f.key}" placeholder="${f.placeholder || ''}" ${f.required ? 'required' : ''} style="${inputStyle};resize:vertical;min-height:80px;font-family:inherit"></textarea>
    </div>`;
      }
      if (f.type === 'select') {
        const opts = (f.options || []).map(o => `<option value="${o}">${o}</option>`).join('');
        return `
    <div style="margin-bottom:16px">
      ${labelHtml}
      <select name="${f.key}" ${f.required ? 'required' : ''} style="${inputStyle};background:white">
        <option value="">-- Selecciona una opción --</option>
        ${opts}
      </select>
    </div>`;
      }
      if (f.type === 'country') {
        return `
    <div style="margin-bottom:16px">
      ${labelHtml}
      <select name="${f.key}" ${f.required ? 'required' : ''} style="${inputStyle};background:white">
        <option value="">-- Selecciona tu país --</option>
        ${countryOpts}
      </select>
    </div>`;
      }
      if (f.type === 'tel') {
        return `
    <div style="margin-bottom:16px">
      ${labelHtml}
      <div style="display:flex;gap:6px">
        <select id="crm-cc-${token}-${f.key}" style="padding:10px 8px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;background:white;min-width:185px">
          ${phoneCountriesOpts}
        </select>
        <input type="tel" id="crm-num-${token}-${f.key}" placeholder="${f.placeholder || 'Número'}" style="flex:1;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;box-sizing:border-box" />
      </div>
      <input type="hidden" name="${f.key}" id="crm-phone-${token}-${f.key}" />
      <input type="hidden" name="country" id="crm-country-${token}" />
    </div>`;
      }
      return `
    <div style="margin-bottom:16px">
      ${labelHtml}
      <input type="${f.type}" name="${f.key}" placeholder="${f.placeholder || ''}" ${f.required ? 'required' : ''} style="${inputStyle}" />
    </div>`;
    }).join('');

    // JS to combine phone fields before submit
    const phoneCombineJs = telFields.map(f => `
    var _cc${f.key}=document.getElementById('crm-cc-${token}-${f.key}');
    var _num${f.key}=document.getElementById('crm-num-${token}-${f.key}');
    var _ph${f.key}=document.getElementById('crm-phone-${token}-${f.key}');
    var _ctry=document.getElementById('crm-country-${token}');
    if(_cc${f.key}&&_num${f.key}&&_ph${f.key}){
      if(${f.required ? 'true' : 'false'}&&!_num${f.key}.value){ _num${f.key}.style.borderColor='#ef4444'; _num${f.key}.focus(); btn.disabled=false; btn.style.opacity='1'; return; }
      if(_num${f.key}.value) _ph${f.key}.value=_cc${f.key}.value+_num${f.key}.value;
      if(_ctry){ var _selOpt=_cc${f.key}.options[_cc${f.key}.selectedIndex]; _ctry.value=_selOpt?(_selOpt.getAttribute('data-country')||''):''; }
    }`).join('');

    // Auto-detect country code from browser locale
    const autoDetectJs = telFields.length > 0 ? `
  (function(){
    var m={'EC':'+593','CO':'+57','MX':'+52','PE':'+51','CL':'+56','AR':'+54','VE':'+58','BO':'+591','PY':'+595','UY':'+598','BR':'+55','US':'+1','CA':'+1','ES':'+34','GT':'+502','HN':'+504','SV':'+503','NI':'+505','CR':'+506','PA':'+507','CU':'+53','DO':'+1','PT':'+351','GB':'+44','FR':'+33','DE':'+49','IT':'+39','AU':'+61'};
    var r=(navigator.language||'').split('-')[1]||'';
    var c=m[r]||'+593';
    ${telFields.map(f => `var s${f.key}=document.getElementById('crm-cc-${token}-${f.key}'); if(s${f.key}) s${f.key}.value=c;`).join(' ')}
  })();` : '';

    const pixelHtml = pixelId ? `<!-- Meta Pixel (si tu sitio ya lo tiene, no se duplica) -->
<script>
if(!window.fbq){!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${pixelId}');fbq('track','PageView');}
</script>
` : '';

    return `${pixelHtml}<!-- Formulario CRM: ${form.name} -->
<div id="crm-form-${token}" style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:480px;margin:0 auto">
  <form id="crm-form-el-${token}">
    ${fieldsHtml}
    <button type="submit" id="crm-btn-${token}" style="width:100%;padding:12px;background:${color};color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;transition:opacity 0.2s">
      ${form.submit_button_text || 'Enviar'}
    </button>
    <div id="crm-msg-${token}" style="display:none;margin-top:16px;padding:16px;background:#ecfdf5;border:1px solid #6ee7b7;border-radius:8px;color:#065f46;text-align:center;font-size:14px">
      ${form.success_message || '¡Gracias! Nos pondremos en contacto pronto.'}
    </div>
    <button type="button" id="crm-reset-${token}" style="display:none;width:100%;margin-top:12px;padding:10px;background:transparent;color:${color};border:1px solid ${color};border-radius:8px;font-size:14px;cursor:pointer">
      Enviar otra respuesta
    </button>
    <div id="crm-err-${token}" style="display:none;margin-top:16px;padding:12px;background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;color:#991b1b;text-align:center;font-size:14px"></div>
  </form>
</div>
<script>
(function(){
  ${autoDetectJs}
  var form=document.getElementById('crm-form-el-${token}');
  var btn=document.getElementById('crm-btn-${token}');
  var msgOk=document.getElementById('crm-msg-${token}');
  var msgErr=document.getElementById('crm-err-${token}');
  var resetBtn=document.getElementById('crm-reset-${token}');
  if(resetBtn){ resetBtn.addEventListener('click', function(){
    form.reset(); msgOk.style.display='none'; msgErr.style.display='none';
    btn.style.display=''; btn.disabled=false; btn.style.opacity='1';
    resetBtn.style.display='none';
  }); }
  form.addEventListener('submit', function(e){
    e.preventDefault();
    btn.disabled=true; btn.style.opacity='0.7';
    msgOk.style.display='none'; msgErr.style.display='none';
    ${phoneCombineJs}
    function crmCookie(n){var m=document.cookie.match(new RegExp('(?:^|; )'+n+'=([^;]*)'));return m?decodeURIComponent(m[1]):'';}
    var fbc=crmCookie('_fbc');
    if(!fbc){var fb=new URLSearchParams(location.search).get('fbclid'); if(fb) fbc='fb.1.'+Date.now()+'.'+fb;}
    var meta={event_id:'wf_'+Date.now().toString(36)+Math.random().toString(36).slice(2,8),fbp:crmCookie('_fbp'),fbc:fbc,source_url:location.href};
    var data={};
    var els=form.elements;
    for(var i=0;i<els.length;i++){ if(els[i].name) data[els[i].name]=els[i].value; }
    fetch('${submitUrl}',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({form_token:'${token}',data:data,meta:meta})
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
      if(res.success){
        try{ if(window.fbq) fbq('track','Lead',{content_name:${JSON.stringify(form.name || 'Formulario')}},{eventID:meta.event_id}); }catch(e){}
        form.reset(); btn.style.display='none'; msgOk.style.display='block';
        var rb=document.getElementById('crm-reset-${token}'); if(rb) rb.style.display='block';
      }
      else{ msgErr.textContent=res.error||'Error al enviar'; msgErr.style.display='block'; btn.disabled=false; btn.style.opacity='1'; }
    })
    .catch(function(){ msgErr.textContent='Error de conexión'; msgErr.style.display='block'; btn.disabled=false; btn.style.opacity='1'; });
  });
})();
</script>`;
  };

  const code = generateEmbedHtml();

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast.success('Código copiado al portapapeles');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-[calc(100vw-2rem)] max-w-2xl max-h-[90vh] overflow-hidden flex flex-col rounded-xl p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <DialogTitle className="flex items-center gap-2">
            Código de integración — <span className="text-brand">{form.name}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="px-6 py-4 flex-1 overflow-y-auto space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
            <strong>¿Cómo usar?</strong> Copia el código HTML/JS y pégalo en cualquier sección de tu landing page o sitio web. Los envíos llegarán directamente como prospectos al CRM.
          </div>

          <div className="relative">
            <pre className="bg-slate-900 text-slate-100 rounded-xl p-4 text-xs overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-72 overflow-y-auto">
              <code>{code}</code>
            </pre>
            <Button
              onClick={handleCopy}
              size="sm"
              className="absolute top-3 right-3 gap-1.5 bg-slate-700 hover:bg-slate-600 text-white"
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Copiado' : 'Copiar'}
            </Button>
          </div>

          <div className="bg-slate-50 dark:bg-zinc-800 rounded-lg p-4 space-y-2 text-sm border dark:border-zinc-700">
            <p className="font-semibold text-slate-700 dark:text-zinc-200">Detalles del formulario</p>
            <div className="grid grid-cols-2 gap-2 text-slate-600 dark:text-zinc-300">
              <span className="text-slate-400 dark:text-zinc-500">Token:</span>
              <code className="font-mono text-xs bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-600 px-2 py-0.5 rounded dark:text-zinc-300">{form.form_token}</code>
              <span className="text-slate-400 dark:text-zinc-500">Campos:</span>
              <span>{(form.fields || []).map(f => f.label).join(', ')}</span>
              <span className="text-slate-400 dark:text-zinc-500">Agente:</span>
              <span>{form.default_assigned_agent_name || 'Sin asignar'}</span>
            </div>
          </div>
        </div>

        <div className="px-6 pb-6 border-t pt-4">
          <Button onClick={handleCopy} className="w-full bg-brand hover:bg-brand-dark gap-2">
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? 'Copiado' : 'Copiar código HTML/JS'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}