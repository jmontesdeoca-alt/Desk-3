import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Trash2, GripVertical } from "lucide-react";
import { toast } from 'sonner';

const FIELD_TYPES = [
  { value: 'text', label: 'Texto' },
  { value: 'email', label: 'Email' },
  { value: 'tel', label: 'Teléfono (con código de país)' },
  { value: 'textarea', label: 'Texto largo' },
  { value: 'select', label: 'Desplegable' },
];

const DEFAULT_FIELDS = [
  { key: 'full_name', label: 'Nombre completo', type: 'text', required: true, placeholder: 'Tu nombre' },
  { key: 'email', label: 'Email', type: 'email', required: true, placeholder: 'tu@email.com' },
  { key: 'phone', label: 'Teléfono', type: 'tel', required: false, placeholder: '+593...' },
];

function generateToken() {
  return Math.random().toString(36).substring(2, 12) + Date.now().toString(36);
}

export default function WebFormEditor({ open, form, onClose, onSaved }) {
  const [loading, setLoading] = useState(false);
  const [agents, setAgents] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    fields: DEFAULT_FIELDS,
    default_assigned_agent_id: '',
    default_assigned_agent_name: '',
    submit_button_text: 'Enviar',
    success_message: '¡Gracias! Nos pondremos en contacto pronto.',
    primary_color: '#2F4F9D',
    is_active: true,
  });

  useEffect(() => {
    loadAgents();
    if (form) {
      setFormData({
        name: form.name || '',
        description: form.description || '',
        fields: form.fields || DEFAULT_FIELDS,
        default_assigned_agent_id: form.default_assigned_agent_id || '',
        default_assigned_agent_name: form.default_assigned_agent_name || '',
        submit_button_text: form.submit_button_text || 'Enviar',
        success_message: form.success_message || '¡Gracias! Nos pondremos en contacto pronto.',
        primary_color: form.primary_color || '#2F4F9D',
        is_active: form.is_active !== false,
      });
    } else {
      setFormData({
        name: '',
        description: '',
        fields: [...DEFAULT_FIELDS],
        default_assigned_agent_id: '',
        default_assigned_agent_name: '',
        submit_button_text: 'Enviar',
        success_message: '¡Gracias! Nos pondremos en contacto pronto.',
        primary_color: '#2F4F9D',
        is_active: true,
      });
    }
  }, [form, open]);

  const loadAgents = async () => {
    const users = await api.entities.User.list();
    setAgents(users);
  };

  const addField = () => {
    const newField = {
      key: `campo_${Date.now()}`,
      label: 'Nuevo campo',
      type: 'text',
      required: false,
      placeholder: '',
    };
    setFormData(prev => ({ ...prev, fields: [...prev.fields, newField] }));
  };

  const updateField = (idx, updates) => {
    const fields = [...formData.fields];
    fields[idx] = { ...fields[idx], ...updates };
    setFormData(prev => ({ ...prev, fields }));
  };

  const removeField = (idx) => {
    setFormData(prev => ({ ...prev, fields: prev.fields.filter((_, i) => i !== idx) }));
  };

  const handleAgentChange = (agentId) => {
    const agent = agents.find(a => a.id === agentId);
    setFormData(prev => ({
      ...prev,
      default_assigned_agent_id: agentId,
      default_assigned_agent_name: agent?.full_name || '',
    }));
  };

  const handleSave = async () => {
    if (!formData.name.trim()) { toast.error('El nombre es obligatorio'); return; }
    setLoading(true);
    const payload = {
      ...formData,
      form_token: form?.form_token || generateToken(),
    };
    if (form) {
      await api.entities.WebForm.update(form.id, payload);
      toast.success('Formulario actualizado');
    } else {
      await api.entities.WebForm.create(payload);
      toast.success('Formulario creado');
    }
    setLoading(false);
    onSaved();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-[calc(100vw-2rem)] max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl p-0">
        <DialogHeader className="px-6 pt-6 pb-0">
          <DialogTitle>{form ? 'Editar Formulario' : 'Nuevo Formulario'}</DialogTitle>
        </DialogHeader>

        <div className="px-6 py-4 space-y-5">
          {/* Básicos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs font-medium text-slate-600 dark:text-zinc-300 mb-1 block">Nombre del formulario *</Label>
              <Input value={formData.name} onChange={e => setFormData(p => ({ ...p, name: e.target.value }))} placeholder="Ej: Cotización de Vida" />
            </div>
            <div>
              <Label className="text-xs font-medium text-slate-600 dark:text-zinc-300 mb-1 block">Descripción</Label>
              <Input value={formData.description} onChange={e => setFormData(p => ({ ...p, description: e.target.value }))} placeholder="Opcional" />
            </div>
          </div>

          {/* Agente por defecto */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs font-medium text-slate-600 dark:text-zinc-300 mb-1 block">Agente asignado por defecto</Label>
              <Select value={formData.default_assigned_agent_id} onValueChange={handleAgentChange}>
                <SelectTrigger><SelectValue placeholder="Sin asignar" /></SelectTrigger>
                <SelectContent>
                  {agents.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.full_name || a.email}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs font-medium text-slate-600 dark:text-zinc-300 mb-1 block">Color principal</Label>
              <div className="flex items-center gap-2">
                <input type="color" value={formData.primary_color} onChange={e => setFormData(p => ({ ...p, primary_color: e.target.value }))} className="h-10 w-12 rounded cursor-pointer border border-slate-200" />
                <Input value={formData.primary_color} onChange={e => setFormData(p => ({ ...p, primary_color: e.target.value }))} className="font-mono text-sm" />
              </div>
            </div>
          </div>

          {/* Campos */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Campos del formulario</Label>
              <Button variant="outline" size="sm" onClick={addField} className="gap-1">
                <Plus className="h-3.5 w-3.5" /> Agregar campo
              </Button>
            </div>
            <div className="space-y-2">
              {formData.fields.map((field, idx) => (
                <div key={idx} className="flex items-start gap-2 p-3 bg-slate-50 dark:bg-zinc-800 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <GripVertical className="h-4 w-4 text-slate-300 mt-2.5 shrink-0" />
                  <div className="flex-1 flex flex-col gap-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <Input
                        value={field.label}
                        onChange={e => updateField(idx, { label: e.target.value })}
                        placeholder="Etiqueta"
                        className="h-8 text-sm col-span-2 sm:col-span-1"
                      />
                      <Input
                        value={field.key}
                        onChange={e => updateField(idx, { key: e.target.value })}
                        placeholder="clave_campo"
                        className="h-8 text-sm text-slate-500 font-mono col-span-2 sm:col-span-1"
                      />
                      <Select value={field.type} onValueChange={v => updateField(idx, { type: v })}>
                        <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {FIELD_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <div className="flex items-center gap-2 h-8">
                        <Switch checked={field.required} onCheckedChange={v => updateField(idx, { required: v })} className="scale-75" />
                        <span className="text-xs text-slate-500 dark:text-zinc-400">Requerido</span>
                      </div>
                    </div>
                    {field.type === 'select' && (
                      <div>
                        <label className="text-xs text-slate-500 dark:text-zinc-400 mb-1.5 block">Opciones del desplegable</label>
                        <div className="space-y-1.5">
                          {(field.options || []).map((opt, optIdx) => (
                            <div key={optIdx} className="flex items-center gap-1">
                              <Input
                                value={opt}
                                onChange={e => {
                                  const opts = [...(field.options || [])];
                                  opts[optIdx] = e.target.value;
                                  updateField(idx, { options: opts.filter(Boolean) });
                                }}
                                placeholder={`Opción ${optIdx + 1}`}
                                className="h-8 text-sm"
                              />
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  const opts = [...(field.options || [])];
                                  opts.splice(optIdx, 1);
                                  updateField(idx, { options: opts });
                                }}
                                className="text-red-400 hover:text-red-600 h-8 w-8 p-0 shrink-0"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          ))}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateField(idx, { options: [...(field.options || []), ''] })}
                            className="gap-1 text-xs h-7"
                          >
                            <Plus className="h-3 w-3" /> Agregar opción
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => removeField(idx)} className="text-red-400 hover:text-red-600 h-8 w-8 p-0 shrink-0">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Textos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs font-medium text-slate-600 dark:text-zinc-300 mb-1 block">Texto del botón</Label>
              <Input value={formData.submit_button_text} onChange={e => setFormData(p => ({ ...p, submit_button_text: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs font-medium text-slate-600 dark:text-zinc-300 mb-1 block">Mensaje de éxito</Label>
              <Input value={formData.success_message} onChange={e => setFormData(p => ({ ...p, success_message: e.target.value }))} />
            </div>
          </div>
        </div>

        <DialogFooter className="px-6 pb-6 gap-2">
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave} disabled={loading} className="bg-brand hover:bg-brand-dark">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {form ? 'Guardar cambios' : 'Crear formulario'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}