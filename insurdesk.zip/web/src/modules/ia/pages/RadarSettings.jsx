import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from '@/components/ui/use-toast';
import { Settings, Zap, RotateCw } from "lucide-react";

export default function RadarSettings() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const res = await api.entities.RadarConfig.list();
      if (res.length > 0) setConfig(res[0]);
      else setConfig({ max_days_no_followup: 3, days_after_quote: 2, min_score_high_priority: 70, max_daily_actions_per_agent: 10 });
    } catch (err) {
      toast({ title: "Error", description: "No se pudo cargar la configuración", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    try {
      if (config.id) {
        await api.entities.RadarConfig.update(config.id, config);
      } else {
        const newConf = await api.entities.RadarConfig.create(config);
        setConfig(newConf);
      }
      toast({ title: "Guardado", description: "Configuración guardada exitosamente." });
      
      // Recalcular manualmente las reglas
      toast({ title: "Radar en proceso", description: "Evaluando base de datos con las nuevas reglas..." });
      const response = await api.functions.invoke('generateRadarRecommendations', {});
      
      toast({ 
        title: "Radar actualizado", 
        description: `Se han generado ${response.data?.generated || 0} recomendaciones nuevas.`,
        className: "bg-emerald-50 border-emerald-200 text-emerald-800"
      });
      
    } catch (err) {
      toast({ title: "Error al actualizar", description: err.message, variant: "destructive" });
    } finally {
      setIsProcessing(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin h-8 w-8 border-4 border-violet-500 border-t-transparent rounded-full" />
    </div>
  );

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2 text-slate-900 dark:text-white">
          <Zap className="h-8 w-8 text-violet-500" />
          Configuración Radar IA
        </h1>
        <p className="text-slate-500 dark:text-zinc-400 mt-1">
          Ajusta los parámetros con los que la IA detecta oportunidades y genera acciones para los asesores.
        </p>
      </div>

      <Card className="border-slate-200 dark:border-zinc-800">
        <CardHeader className="bg-slate-50/50 dark:bg-zinc-900/50 border-b border-slate-100 dark:border-zinc-800">
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-slate-500"/> Reglas de Negocio
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSave} className="space-y-5">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Días sin seguimiento</Label>
                <div className="relative">
                  <Input type="number" min="1" className="pl-3" value={config.max_days_no_followup} onChange={e => setConfig({...config, max_days_no_followup: parseInt(e.target.value)})} />
                  <span className="absolute right-3 top-2.5 text-sm text-slate-400">días</span>
                </div>
                <p className="text-[11px] text-slate-500">Máximo de días inactivo antes de sugerir seguimiento.</p>
              </div>
              
              <div className="space-y-2">
                <Label>Gracia tras Cotización</Label>
                <div className="relative">
                  <Input type="number" min="1" className="pl-3" value={config.days_after_quote} onChange={e => setConfig({...config, days_after_quote: parseInt(e.target.value)})} />
                  <span className="absolute right-3 top-2.5 text-sm text-slate-400">días</span>
                </div>
                <p className="text-[11px] text-slate-500">Días tras cotizar antes de pedir llamar al cliente.</p>
              </div>

              <div className="space-y-2">
                <Label>Score prioridad Alta</Label>
                <div className="relative">
                  <Input type="number" min="1" max="100" className="pl-3" value={config.min_score_high_priority} onChange={e => setConfig({...config, min_score_high_priority: parseInt(e.target.value)})} />
                  <span className="absolute right-3 top-2.5 text-sm text-slate-400">pts</span>
                </div>
                <p className="text-[11px] text-slate-500">Puntaje mínimo (0-100) para catalogar acción como URGENTE.</p>
              </div>

              <div className="space-y-2">
                <Label>Max acciones x Asesor</Label>
                <div className="relative">
                  <Input type="number" min="1" className="pl-3" value={config.max_daily_actions_per_agent} onChange={e => setConfig({...config, max_daily_actions_per_agent: parseInt(e.target.value)})} />
                  <span className="absolute right-3 top-2.5 text-sm text-slate-400">ítems</span>
                </div>
                <p className="text-[11px] text-slate-500">Límite de tarjetas que verá un asesor en su dashboard al día.</p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-zinc-800">
              <Button type="submit" disabled={isProcessing} className="w-full bg-violet-600 hover:bg-violet-700 text-white h-12 text-sm shadow-md">
                {isProcessing ? <RotateCw className="h-5 w-5 animate-spin mr-2" /> : <Zap className="h-5 w-5 mr-2" />}
                {isProcessing ? "Recalculando base de datos..." : "Guardar Reglas y Recalcular Radar"}
              </Button>
            </div>

          </form>
        </CardContent>
      </Card>
    </div>
  );
}