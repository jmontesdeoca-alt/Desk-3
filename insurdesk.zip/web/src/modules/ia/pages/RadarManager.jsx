import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import StatsCard from '@/components/ui/StatsCard';
import { Target, TrendingUp, TrendingDown, CheckCircle2, Clock, Zap, Users } from "lucide-react";

export default function RadarManager() {
  const [recs, setRecs] = useState([]);
  const [agentMap, setAgentMap] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [data, agentsRes] = await Promise.all([
        api.entities.RadarRecommendation.list('-created_date', 2000),
        api.functions.invoke('listAgents', {})
      ]);
      setRecs(data);
      const map = {};
      (agentsRes?.data?.agents || []).forEach(a => { map[a.id] = a.full_name; });
      setAgentMap(map);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin h-8 w-8 border-4 border-violet-500 border-t-transparent rounded-full" />
    </div>
  );

  const total = recs.length;
  const completed = recs.filter(r => r.status === 'completed').length;
  const postponed = recs.filter(r => r.status === 'postponed').length;
  const pending = recs.filter(r => r.status === 'pending');

  const hotLeads = pending.filter(r => r.score >= 70).sort((a,b) => b.score - a.score).slice(0, 15);
  const coolingLeads = pending.filter(r => r.score < 40).sort((a,b) => a.score - b.score).slice(0, 15);

  // Agrupar por agente con nombre
  const agentPending = {};
  pending.forEach(r => {
    if (!agentPending[r.agent_id]) agentPending[r.agent_id] = 0;
    agentPending[r.agent_id]++;
  });
  const topAgents = Object.entries(agentPending).sort((a,b) => b[1] - a[1]).slice(0, 10);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2 text-slate-900 dark:text-white">
          <Zap className="h-8 w-8 text-violet-500" />
          Radar IA: Gerencial
        </h1>
        <p className="text-slate-500 dark:text-zinc-400 mt-1">
          Métricas de desempeño y rendimiento del motor de recomendaciones.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatsCard title="Total Recomendadas" value={total} icon={Target} variant="purple" />
        <StatsCard title="Acciones Completadas" value={completed} icon={CheckCircle2} variant="success" />
        <StatsCard title="Pospuestas/Pendientes" value={postponed + pending.length} icon={Clock} variant="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-emerald-200 dark:border-emerald-900/50">
          <CardHeader className="bg-emerald-50/50 dark:bg-emerald-900/10 rounded-t-lg">
            <CardTitle className="text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
              <TrendingUp className="h-5 w-5"/> Leads Calientes (Alta Prioridad)
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-3">
              {hotLeads.map(l => (
                <div key={l.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-zinc-800/50 rounded-lg">
                  <div>
                    <p className="font-semibold text-slate-800 dark:text-zinc-100">{l.lead_name}</p>
                    <p className="text-xs text-slate-500 dark:text-zinc-400">{l.action_recommended}</p>
                  </div>
                  <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-0">
                    Score {l.score}
                  </Badge>
                </div>
              ))}
              {hotLeads.length === 0 && <p className="text-slate-400 text-sm text-center py-6">No hay leads calientes pendientes.</p>}
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 dark:border-blue-900/50">
          <CardHeader className="bg-blue-50/50 dark:bg-blue-900/10 rounded-t-lg">
            <CardTitle className="text-blue-700 dark:text-blue-400 flex items-center gap-2">
              <TrendingDown className="h-5 w-5"/> Leads Enfriándose (Baja Prioridad)
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-3">
              {coolingLeads.map(l => (
                <div key={l.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-zinc-800/50 rounded-lg">
                  <div>
                    <p className="font-semibold text-slate-800 dark:text-zinc-100">{l.lead_name}</p>
                    <p className="text-xs text-slate-500 dark:text-zinc-400">{l.action_recommended}</p>
                  </div>
                  <Badge variant="outline" className="dark:border-zinc-700">Score {l.score}</Badge>
                </div>
              ))}
              {coolingLeads.length === 0 && <p className="text-slate-400 text-sm text-center py-6">No hay leads fríos pendientes.</p>}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-violet-500"/> Asesores con más acciones pendientes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {topAgents.map(([agentId, count]) => (
              <div key={agentId} className="flex justify-between items-center border-b border-slate-100 dark:border-zinc-800 pb-3 pt-2 last:border-0">
                <span className="font-medium text-slate-700 dark:text-zinc-300">{agentMap[agentId] || agentId}</span>
                <Badge variant="secondary" className="bg-slate-100 dark:bg-zinc-800">{count} recomendaciones pendientes</Badge>
              </div>
            ))}
            {topAgents.length === 0 && <p className="text-slate-400 text-sm py-4">Todos los asesores están al día.</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}