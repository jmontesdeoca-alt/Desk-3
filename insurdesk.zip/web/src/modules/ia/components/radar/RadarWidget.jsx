import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Clock, XCircle, ArrowRight, Zap, ExternalLink, Loader2, ChevronDown, ChevronRight, CalendarCheck } from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from '@/components/ui/use-toast';

export default function RadarWidget({ currentUser }) {
  const [recommendations, setRecommendations] = useState([]);
  const [todayEvents, setTodayEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (currentUser?.id) loadAll();
  }, [currentUser]);

  const loadAll = async () => {
    try {
      const [recs, events] = await Promise.all([
        api.entities.RadarRecommendation.filter(
          { agent_id: currentUser.id, status: "pending" },
          '-score',
          20
        ),
        api.entities.CalendarEvent.filter(
          {
            assigned_to_id: currentUser.id,
            start_datetime: { $gte: new Date(new Date().toLocaleDateString('en-CA', { timeZone: 'America/Guayaquil' }) + 'T00:00:00-05:00').toISOString(), $lte: new Date(new Date().toLocaleDateString('en-CA', { timeZone: 'America/Guayaquil' }) + 'T23:59:59-05:00').toISOString() }
          },
          'start_datetime',
          20
        )
      ]);

      // Filtrar recomendaciones (sin etapas cerradas, sin duplicados)
      const closedKeywords = ['ganad', 'cierr', 'perdid'];
      const seenLeads = new Set();
      const filteredRecs = recs.filter(r => {
        const stage = (r.pipeline_stage || '').toLowerCase();
        if (closedKeywords.some(k => stage.includes(k))) return false;
        if (seenLeads.has(r.lead_id)) return false;
        seenLeads.add(r.lead_id);
        return true;
      });

      setRecommendations(filteredRecs);
      setTodayEvents(events);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (id, newStatus) => {
    await api.entities.RadarRecommendation.update(id, { status: newStatus });
    setRecommendations(prev => prev.filter(r => r.id !== id));
    toast({
      title: newStatus === 'completed' ? "¡Acción completada!" : newStatus === 'postponed' ? "Acción pospuesta" : "Acción descartada",
      duration: 4000
    });
  };

  const formatEventTime = (datetime) => {
    if (!datetime) return '';
    return new Date(datetime).toLocaleTimeString('es-EC', {
      timeZone: 'America/Guayaquil',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalPending = recommendations.length + todayEvents.length;

  return (
    <Card className="border-0 shadow-sm bg-white dark:bg-zinc-900">
      <CardHeader className="py-3 cursor-pointer select-none" onClick={() => setOpen(o => !o)}>
        <CardTitle className="flex items-center gap-2 text-base">
          <div className="p-1.5 bg-brand rounded-lg">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <span className="bg-clip-text text-transparent bg-brand font-bold">
            Qué hacer hoy
          </span>
          {!loading && totalPending > 0 && (
            <Badge className="bg-violet-100 text-violet-700 border-violet-200">
              {totalPending} pendiente{totalPending !== 1 ? 's' : ''}
            </Badge>
          )}
          <div className="ml-auto text-slate-400">
            {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </div>
        </CardTitle>
      </CardHeader>

      {open && (
        <CardContent className="space-y-3 pt-0">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-violet-400" />
            </div>
          ) : totalPending === 0 ? (
            <div className="text-center py-8">
              <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="h-6 w-6 text-emerald-500" />
              </div>
              <p className="text-sm font-medium text-slate-600 dark:text-zinc-300">¡Todo al día!</p>
              <p className="text-xs text-slate-400 dark:text-zinc-500 mt-1">No tienes acciones pendientes para hoy.</p>
            </div>
          ) : (
            <>
              {/* Citas de hoy */}
              {todayEvents.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-400 dark:text-zinc-500 uppercase tracking-wide">📅 Citas de hoy</p>
                  {todayEvents.map(ev => (
                    <div
                      key={ev.id}
                      className="rounded-lg border bg-slate-50 dark:bg-zinc-800 overflow-hidden"
                      style={{ borderLeftWidth: 3, borderLeftColor: '#2F4F9D' }}
                    >
                      <div className="p-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="font-semibold text-sm text-slate-800 dark:text-zinc-100 truncate">{ev.title}</p>
                            {ev.attendees && <p className="text-xs text-slate-500 dark:text-zinc-400 truncate">{ev.attendees}</p>}
                          </div>
                          <Badge className="bg-blue-50 text-blue-700 border-blue-200 text-xs flex-shrink-0">
                            {formatEventTime(ev.start_datetime)}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1.5 mt-2">
                          <CalendarCheck className="h-3.5 w-3.5 text-brand flex-shrink-0" />
                          <span className="text-xs text-slate-500 dark:text-zinc-400">
                            {ev.event_type || 'reunión'} · {formatEventTime(ev.start_datetime)} – {formatEventTime(ev.end_datetime)}
                          </span>
                        </div>
                        <div className="mt-2">
                          <Link to={createPageUrl('Calendar')}>
                            <Button size="sm" variant="outline" className="h-7 text-xs px-3 dark:bg-zinc-700 dark:border-zinc-600">
                              <ExternalLink className="h-3 w-3 mr-1" /> Ver en calendario
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Recomendaciones IA */}
              {recommendations.length > 0 && (
                <div className="space-y-2">
                  {todayEvents.length > 0 && <p className="text-xs font-semibold text-slate-400 dark:text-zinc-500 uppercase tracking-wide">🤖 Recomendaciones IA</p>}
                  {recommendations.map(rec => (
                    <div
                      key={rec.id}
                      className="rounded-lg border bg-slate-50 dark:bg-zinc-800 overflow-hidden"
                      style={{ borderLeftWidth: 3, borderLeftColor: rec.priority === 'Alta' ? '#ef4444' : rec.priority === 'Media' ? '#f59e0b' : '#2F4F9D' }}
                    >
                      <div className="p-3">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="min-w-0">
                            <p className="font-semibold text-sm text-slate-800 dark:text-zinc-100 truncate">{rec.lead_name}</p>
                            <p className="text-xs text-slate-500 dark:text-zinc-400">{rec.pipeline_stage} · {rec.product}</p>
                          </div>
                          <Badge variant="outline" className={`text-xs flex-shrink-0 ${
                            rec.priority === 'Alta' ? 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-400' :
                            rec.priority === 'Media' ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400' :
                            'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400'
                          }`}>
                            {rec.priority}
                          </Badge>
                        </div>
                        <div className="flex items-start gap-1.5 mb-3">
                          <ArrowRight className="h-3.5 w-3.5 text-violet-500 mt-0.5 flex-shrink-0" />
                          <div>
                            <span className="text-xs font-semibold text-violet-700 dark:text-violet-400">{rec.action_recommended}: </span>
                            <span className="text-xs text-slate-600 dark:text-zinc-400">{rec.reason}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white h-7 text-xs flex-1 px-2" onClick={() => handleAction(rec.id, 'completed')}>
                            <CheckCircle2 className="h-3 w-3 mr-1" /> Hecho
                          </Button>
                          <Button size="sm" variant="outline" className="h-7 text-xs flex-1 px-2 dark:bg-zinc-700 dark:border-zinc-600" onClick={() => handleAction(rec.id, 'postponed')}>
                            <Clock className="h-3 w-3 mr-1" /> Posponer
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 text-xs px-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20" onClick={() => handleAction(rec.id, 'discarded')}>
                            <XCircle className="h-3.5 w-3.5" />
                          </Button>
                          <Link to={createPageUrl('Pipeline')}>
                            <Button size="sm" variant="ghost" className="h-7 text-xs px-2 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20">
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </CardContent>
      )}
    </Card>
  );
}