import React, { useState, useEffect, useRef } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageCircle, X, Send, Loader2, Bot } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function ChatbotWidget({ leadContext = null }) {
  const { user: currentUser } = useAuth();
  const userRole = currentUser?.crm_role || 'agente_crm';
  const [isOpen, setIsOpen] = useState(false);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const scrollRef = useRef(null);

  // Construye el contexto del usuario para inyectarlo en cada mensaje
  const buildUserContext = () => {
    if (!currentUser) return '';
    return `[Contexto del Usuario: user_id=${currentUser.id}, user_email=${currentUser.email}, user_role=${userRole}, user_name=${currentUser.full_name || ''}]`;
  };

  useEffect(() => {
    if (isOpen && !conversation) {
      initConversation();
    }
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const initConversation = async () => {
    try {
      const conv = await api.agents.createConversation({
        agent_name: 'crm_assistant',
        metadata: {
          name: 'Asistencia CRM',
          description: 'Conversación con asistente inteligente',
          user_id: currentUser?.id,
          user_email: currentUser?.email,
          user_role: userRole,
          user_name: currentUser?.full_name || ''
        }
      });
      setConversation(conv);
      setMessages(conv.messages || []);
    } catch (error) {
      console.error('Error creating conversation:', error);
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !conversation || isSending) return;

    const userMessage = inputMessage.trim();
    setInputMessage('');
    setIsSending(true);

    try {
      // Siempre incluir el contexto del usuario + contexto de lead si existe
      const userCtx = buildUserContext();
      const leadCtx = leadContext
        ? `\n[Contexto del Lead: ID=${leadContext.id}, Nombre=${leadContext.prospect_name}, Etapa=${leadContext.pipeline_stage}, Última actividad=${leadContext.last_activity_at || 'Ninguna'}]`
        : '';
      const messageContent = `${userCtx}${leadCtx}\n\n${userMessage}`;

      await api.agents.addMessage(conversation, {
        role: 'user',
        content: messageContent
      });
    } catch (error) {
      console.error('Error sending message:', error);
      setIsSending(false);
    }
  };

  useEffect(() => {
    if (!conversation) return;

    const unsubscribe = api.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages || []);
      
      // Detectar cuando la IA termina de responder
      const lastMessage = data.messages[data.messages.length - 1];
      if (lastMessage && lastMessage.role === 'assistant' && !lastMessage.streaming) {
        setIsSending(false);
      }
    });

    return () => unsubscribe();
  }, [conversation]);

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg bg-brand hover:bg-brand-dark z-50"
        size="icon"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[600px] shadow-2xl z-50 flex flex-col">
      {/* Header */}
      <div className="bg-ink text-white p-4 rounded-t-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <Bot className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold">Asistente CRM</h3>
            <p className="text-xs text-white/80">
              {leadContext ? `Lead: ${leadContext.prospect_name}` : 'Ayuda General'}
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsOpen(false)}
          className="text-white hover:bg-white/10"
        >
          <X className="h-5 w-5" />
        </Button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-slate-500 py-8">
              <Bot className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p className="text-sm">¡Hola! Soy tu asistente del CRM.</p>
              <p className="text-xs mt-1">Pregúntame sobre leads, procesos o pide sugerencias.</p>
            </div>
          )}
          
          {messages.map((msg, idx) => {
            if (msg.role === 'user') {
              return (
                <div key={idx} className="flex justify-end">
                  <div className="bg-brand text-white rounded-lg px-4 py-2 max-w-[80%]">
                    <p className="text-sm">{msg.content}</p>
                  </div>
                </div>
              );
            }
            
            if (msg.role === 'assistant') {
              return (
                <div key={idx} className="flex justify-start">
                  <div className="bg-slate-100 rounded-lg px-4 py-2 max-w-[80%]">
                    <ReactMarkdown 
                      className="text-sm prose prose-sm prose-slate max-w-none"
                      components={{
                        p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                        ul: ({ children }) => <ul className="ml-4 list-disc mb-2">{children}</ul>,
                        ol: ({ children }) => <ol className="ml-4 list-decimal mb-2">{children}</ol>,
                        li: ({ children }) => <li className="mb-1">{children}</li>,
                        strong: ({ children }) => <strong className="font-semibold text-slate-900">{children}</strong>,
                      }}
                    >
                      {msg.content}
                    </ReactMarkdown>
                  </div>
                </div>
              );
            }
            
            return null;
          })}
          
          {isSending && (
            <div className="flex justify-start">
              <div className="bg-slate-100 rounded-lg px-4 py-3">
                <Loader2 className="h-4 w-4 animate-spin text-slate-500" />
              </div>
            </div>
          )}
          
          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage();
          }}
          className="flex gap-2"
        >
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Escribe tu mensaje..."
            disabled={isSending}
            className="flex-1"
          />
          <Button
            type="submit"
            size="icon"
            disabled={!inputMessage.trim() || isSending}
            className="bg-brand hover:bg-brand-dark"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </Card>
  );
}