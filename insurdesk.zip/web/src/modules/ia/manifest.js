// Inteligencia artificial: Radar de recomendaciones y asistente conversacional.
import { Zap, Target } from 'lucide-react';
import RadarManager from './pages/RadarManager';
import RadarSettings from './pages/RadarSettings';

export default {
  id: 'ia',
  name: 'Inteligencia artificial',
  pages: {},
  settingsTabs: [
    { id: 'radar_reglas', order: 60, label: 'Reglas Radar', icon: Zap, Component: RadarSettings, bare: true },
    { id: 'radar_gerencial', order: 70, label: 'Radar Gerencial', icon: Target, Component: RadarManager, bare: true },
  ],
};
