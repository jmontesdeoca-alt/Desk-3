import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Copy, Check, Calendar, Clock, User, Mail, Loader2, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import AppointmentProposalForm from './AppointmentProposalForm';

const STATUS_STYLES = {
  pending:   { label: 'Pendiente',  className: 'bg-amber-100 text-amber-700' },
  confirmed: { label: 'Confirmada', className: 'bg-green-100 text-green-700' },
  expired:   { label: 'Expirada',   className: 'bg-slate-100 text-slate-500' },
  cancelled: { label: 'Cancelada',  className: 'bg-red-100 text-red-600' },
};

export default function AppointmentProposalsManager({ currentUser }) {
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    if (currentUser?.id) loadProposals();
  }, [currentUser]);

  const loadProposals = async () => {
    setLoading(true);
    try {
      const data = await api.entities.AppointmentRequest.filter(
        { agent_id: currentUser.id },
        '-created_date',
        100
      );
      setProposals(data);
    } catch (err) {
      console.error('Error loading proposals:', err);
    } finally {
      setLoading(false);
    }
  };

  const copyLink = (proposal) => {
    const url = `${window.location.origin}/PublicBooking?t=${proposal.token}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedId(proposal.id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const handleFormClose = () => {
    setShowForm(false);
    loadProposals();
  };

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-7 w-7 animate-spin text-brand" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Propuestas de Cita</h2>
          <p className="text-sm text-slate-500 dark:text-zinc-400 mt-0.5">
            Crea propuestas con múltiples horarios y comparte el enlace con tu cliente
          </p>
        </div>
        <Button onClick={() => setShowForm(true)} className="gap-2 bg-brand hover:bg-brand-dark">
          <Plus className="h-4 w-4" />
          Nueva propuesta
        </Button>
      </div>

      {/* List */}
      {proposals.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-zinc-900 rounded-xl border border-slate-200 dark:border-zinc-700">
          <Calendar className="h-12 w-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">Aún no tienes propuestas creadas</p>
          <p className="text-slate-400 text-sm mt-1">Crea una y comparte el enlace con tu cliente para que elija su horario</p>
          <Button onClick={() => setShowForm(true)} className="mt-4 gap-2 bg-brand hover:bg-brand-dark">
            <Plus className="h-4 w-4" />
            Crear primera propuesta
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {proposals.map(p => {
            const status = STATUS_STYLES[p.status] || STATUS_STYLES.pending;
            const bookingUrl = `${window.location.origin}/PublicBooking?t=${p.token}`;
            return (
              <div key={p.id} className="bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 rounded-xl p-4 space-y-3">
                {/* Top row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-slate-900 dark:text-white text-sm">{p.title}</h3>
                      <Badge className={`text-xs ${status.className}`}>{status.label}</Badge>
                    </div>
                    <div className="flex items-center gap-4 mt-1 flex-wrap">
                      {p.client_name && (
                        <span className="flex items-center gap-1 text-xs text-slate-500 dark:text-zinc-400">
                          <User className="h-3 w-3" />
                          {p.client_name}
                        </span>
                      )}
                      <span className="flex items-center gap-1 text-xs text-slate-500 dark:text-zinc-400">
                        <Mail className="h-3 w-3" />
                        {p.client_email}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs text-slate-400 dark:text-zinc-500 whitespace-nowrap flex-shrink-0">
                    {format(new Date(p.created_date), "d MMM yyyy", { locale: es })}
                  </span>
                </div>

                {/* Slots */}
                {p.proposed_slots?.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {p.proposed_slots.map((slot, i) => {
                      const dt = new Date(slot.datetime);
                      const isConfirmed = p.confirmed_datetime && new Date(p.confirmed_datetime).toISOString() === new Date(slot.datetime).toISOString();
                      return (
                        <span key={i} className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium border ${isConfirmed ? 'bg-green-100 text-green-700 border-green-300' : 'bg-slate-50 text-slate-600 border-slate-200 dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-600'}`}>
                          <Clock className="h-3 w-3" />
                          {format(dt, "EEE d MMM, HH:mm", { locale: es })}
                          {p.duration_minutes && <span className="text-slate-400">· {p.duration_minutes}min</span>}
                        </span>
                      );
                    })}
                  </div>
                )}

                {/* Confirmed */}
                {p.status === 'confirmed' && p.confirmed_datetime && (
                  <p className="text-xs text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-1.5 font-medium">
                    ✓ Confirmada el {format(new Date(p.confirmed_at || p.confirmed_datetime), "d 'de' MMMM 'a las' HH:mm", { locale: es })}
                  </p>
                )}

                {/* Link row — only for pending */}
                {p.status === 'pending' && p.token && (
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-zinc-800 rounded-lg px-3 py-2">
                    <a
                      href={bookingUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 text-xs text-brand truncate font-mono hover:underline"
                    >
                      {bookingUrl}
                    </a>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyLink(p)}
                      className="flex-shrink-0 h-7 px-2 gap-1 text-xs"
                    >
                      {copiedId === p.id
                        ? <><Check className="h-3.5 w-3.5 text-green-500" /> Copiado</>
                        : <><Copy className="h-3.5 w-3.5" /> Copiar</>
                      }
                    </Button>
                    <a href={bookingUrl} target="_blank" rel="noreferrer">
                      <Button size="sm" variant="ghost" className="h-7 px-2">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Button>
                    </a>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Form modal — standalone (no lead/prospect) */}
      <AppointmentProposalForm
        open={showForm}
        onClose={handleFormClose}
        lead={null}
        prospect={null}
        currentUser={currentUser}
      />
    </div>
  );
}