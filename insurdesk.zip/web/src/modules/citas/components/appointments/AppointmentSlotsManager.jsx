import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Plus, Calendar, Trash2, Copy, User, XCircle, Link, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const DURATIONS = [15, 30, 45, 60, 90];

function generateToken() {
  return Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
}

export default function AppointmentSlotsManager({ currentUser }) {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ date: '', time: '', duration_minutes: 30, title: 'Consulta de Seguros', description: '' });
  const [formErrors, setFormErrors] = useState({});
  const { toast } = useToast();

  useEffect(() => {
    if (currentUser) loadSlots();
  }, [currentUser]);

  const loadSlots = async () => {
    try {
      setLoading(true);
      const data = await api.entities.AppointmentSlot.filter(
        { agent_id: currentUser.id },
        'datetime',
        100
      );
      setSlots(data);
    } catch (err) {
      toast({ title: 'Error', description: 'No se pudieron cargar los slots', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    const errs = {};
    if (!form.date) errs.date = 'La fecha es requerida';
    if (!form.time) errs.time = 'La hora es requerida';
    if (!form.title.trim()) errs.title = 'El título es requerido';
    else {
      const dt = new Date(`${form.date}T${form.time}`);
      if (dt <= new Date()) errs.date = 'La fecha debe ser futura';
    }
    return errs;
  };

  const handleSave = async () => {
    const errs = validateForm();
    if (Object.keys(errs).length > 0) { setFormErrors(errs); return; }
    setSaving(true);
    try {
      const datetime = new Date(`${form.date}T${form.time}`).toISOString();
      await api.entities.AppointmentSlot.create({
        agent_id: currentUser.id,
        agent_name: currentUser.full_name,
        agent_email: currentUser.email,
        datetime,
        duration_minutes: Number(form.duration_minutes),
        title: form.title.trim(),
        description: form.description.trim(),
        status: 'available',
        public_token: generateToken()
      });
      toast({ title: 'Slot creado', description: 'El horario está disponible para reservas' });
      setShowForm(false);
      setForm({ date: '', time: '', duration_minutes: 30, title: 'Consulta de Seguros', description: '' });
      setFormErrors({});
      loadSlots();
    } catch (err) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (slot) => {
    if (!window.confirm('¿Eliminar este horario?')) return;
    await api.entities.AppointmentSlot.delete(slot.id);
    loadSlots();
    toast({ title: 'Eliminado', description: 'Horario eliminado correctamente' });
  };

  const handleCancel = async (slot) => {
    await api.entities.AppointmentSlot.update(slot.id, { status: 'cancelled' });
    loadSlots();
    toast({ title: 'Cancelado', description: 'El horario fue cancelado' });
  };

  const copyBookingLink = (slot) => {
    const baseUrl = window.location.origin;
    const link = `${baseUrl}/PublicBooking?agent=${currentUser.id}&token=${slot.public_token}`;
    navigator.clipboard.writeText(link);
    toast({ title: '¡Enlace copiado!', description: 'Compártelo con tu cliente' });
  };

  const copyAgentLink = () => {
    const baseUrl = window.location.origin;
    const link = `${baseUrl}/PublicBooking?agent=${currentUser.id}`;
    navigator.clipboard.writeText(link);
    toast({ title: '¡Enlace copiado!', description: 'Comparte tu página de reservas' });
  };

  const futureSlots = slots.filter(s => new Date(s.datetime) > new Date() && s.status !== 'cancelled');
  const pastOrBooked = slots.filter(s => new Date(s.datetime) <= new Date() || s.status === 'booked' || s.status === 'cancelled');

  const statusBadge = (status) => {
    if (status === 'available') return <Badge className="bg-green-100 text-green-700">Disponible</Badge>;
    if (status === 'booked') return <Badge className="bg-blue-100 text-blue-700">Reservado</Badge>;
    return <Badge className="bg-slate-100 text-slate-500">Cancelado</Badge>;
  };

  return (
    <div className="space-y-4">
      {/* Header actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-semibold text-slate-800 dark:text-white">Mis Slots de Cita</h3>
          <p className="text-sm text-slate-500 dark:text-zinc-400">Horarios que ofreces a tus clientes para agendar</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={copyAgentLink} className="gap-2">
            <Link className="h-4 w-4" />
            Mi Enlace
          </Button>
          <Button size="sm" onClick={() => setShowForm(true)} className="gap-2 bg-brand hover:bg-brand-dark">
            <Plus className="h-4 w-4" />
            Nuevo Horario
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : (
        <>
          {/* Upcoming slots */}
          {futureSlots.length === 0 ? (
            <div className="text-center py-10 bg-slate-50 dark:bg-zinc-900 rounded-xl border-2 border-dashed border-slate-200 dark:border-zinc-700">
              <Calendar className="h-10 w-10 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 font-medium">No tienes horarios disponibles</p>
              <p className="text-slate-400 text-sm mt-1">Crea tu primer horario para que los clientes puedan reservar</p>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Próximos ({futureSlots.length})</p>
              {futureSlots.map(slot => {
                const dt = new Date(slot.datetime);
                return (
                  <div key={slot.id} className="bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 rounded-xl p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className="w-12 h-12 bg-brand/10 rounded-xl flex flex-col items-center justify-center flex-shrink-0">
                          <span className="text-xs font-bold text-brand">{format(dt, 'MMM', { locale: es }).toUpperCase()}</span>
                          <span className="text-lg font-black text-brand leading-none">{format(dt, 'd')}</span>
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-slate-800 dark:text-white text-sm truncate">{slot.title}</p>
                          <p className="text-brand font-bold text-sm">{format(dt, 'HH:mm')} · {slot.duration_minutes} min</p>
                          <p className="text-xs text-slate-400 capitalize">{format(dt, "EEEE d 'de' MMMM", { locale: es })}</p>
                          {slot.status === 'booked' && slot.booked_by_name && (
                            <div className="flex items-center gap-1 mt-1">
                              <User className="h-3 w-3 text-blue-500" />
                              <span className="text-xs text-blue-600 font-medium">{slot.booked_by_name}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {statusBadge(slot.status)}
                        {slot.status === 'available' && (
                          <>
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => copyBookingLink(slot)} title="Copiar enlace">
                              <Copy className="h-3.5 w-3.5 text-slate-400" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleCancel(slot)} title="Cancelar">
                              <XCircle className="h-3.5 w-3.5 text-red-400" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Past/booked slots */}
          {pastOrBooked.length > 0 && (
            <details className="mt-4">
              <summary className="text-xs font-semibold text-slate-400 uppercase tracking-wider cursor-pointer hover:text-slate-600 transition-colors">
                Histórico ({pastOrBooked.length})
              </summary>
              <div className="mt-3 space-y-2">
                {pastOrBooked.map(slot => {
                  const dt = new Date(slot.datetime);
                  return (
                    <div key={slot.id} className="bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-700 rounded-xl p-3 flex items-center justify-between gap-3 opacity-70">
                      <div>
                        <p className="text-sm font-medium text-slate-600 dark:text-zinc-400">{slot.title}</p>
                        <p className="text-xs text-slate-400">{format(dt, "d MMM yyyy, HH:mm", { locale: es })}</p>
                        {slot.booked_by_name && <p className="text-xs text-blue-500">{slot.booked_by_name}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        {statusBadge(slot.status)}
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDelete(slot)}>
                          <Trash2 className="h-3.5 w-3.5 text-red-400" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </details>
          )}
        </>
      )}

      {/* Create slot dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nuevo Horario Disponible</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Título de la cita *</label>
              <input
                type="text"
                value={form.title}
                onChange={e => setForm({...form, title: e.target.value})}
                placeholder="Consulta de Seguros de Vida"
                className={`w-full px-3 py-2.5 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand ${formErrors.title ? 'border-red-400' : 'border-slate-300'}`}
              />
              {formErrors.title && <p className="text-xs text-red-500 mt-1">{formErrors.title}</p>}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Fecha *</label>
                <input
                  type="date"
                  value={form.date}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={e => setForm({...form, date: e.target.value})}
                  className={`w-full px-3 py-2.5 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand ${formErrors.date ? 'border-red-400' : 'border-slate-300'}`}
                />
                {formErrors.date && <p className="text-xs text-red-500 mt-1">{formErrors.date}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Hora *</label>
                <input
                  type="time"
                  value={form.time}
                  onChange={e => setForm({...form, time: e.target.value})}
                  className={`w-full px-3 py-2.5 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand ${formErrors.time ? 'border-red-400' : 'border-slate-300'}`}
                />
                {formErrors.time && <p className="text-xs text-red-500 mt-1">{formErrors.time}</p>}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Duración</label>
              <div className="flex gap-2 flex-wrap">
                {DURATIONS.map(d => (
                  <button
                    key={d}
                    onClick={() => setForm({...form, duration_minutes: d})}
                    className={`px-3 py-1.5 text-sm rounded-lg border transition-all ${form.duration_minutes === d ? 'bg-brand text-white border-brand' : 'border-slate-300 text-slate-600 hover:border-brand'}`}
                  >
                    {d} min
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Descripción para el cliente <span className="text-slate-400">(opcional)</span></label>
              <textarea
                value={form.description}
                onChange={e => setForm({...form, description: e.target.value})}
                placeholder="Conversaremos sobre tu situación y las mejores opciones de cobertura..."
                rows={2}
                className="w-full px-3 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand resize-none"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" onClick={() => setShowForm(false)} className="flex-1">Cancelar</Button>
              <Button onClick={handleSave} disabled={saving} className="flex-1 bg-brand hover:bg-brand-dark gap-2">
                {saving ? <><Loader2 className="h-4 w-4 animate-spin" /> Guardando...</> : 'Crear Horario'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}