import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Trash2, Loader2, Calendar as CalendarIcon, Send, AlertCircle, CheckCircle, Copy, Check, Clock, Info } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const MAX_SLOTS = 4;

const emptyForm = (prospect, lead) => ({
  client_name: prospect?.full_name || lead?.prospect_name || '',
  client_email: prospect?.email || '',
  client_phone: prospect?.phone || '',
  title: 'Consulta de Seguros',
  description: '',
  duration_minutes: 30,
});

export default function AppointmentProposalForm({ open, onClose, lead, prospect, currentUser }) {
  const [form, setForm] = useState(emptyForm(prospect, lead));
  const [availableDays, setAvailableDays] = useState([]);
  const [hasConfig, setHasConfig] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedSlots, setSelectedSlots] = useState([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [bookingUrl, setBookingUrl] = useState('');
  const [copied, setCopied] = useState(false);

  const isStandalone = !lead && !prospect;

  useEffect(() => {
    if (open) {
      setForm(emptyForm(prospect, lead));
      setSelectedDate(null);
      setSelectedSlots([]);
      setError(null);
      setSuccess(false);
      setBookingUrl('');
      setCopied(false);
      fetchAvailableSlots();
    }
  }, [open]);

  const fetchAvailableSlots = async () => {
    setLoadingSlots(true);
    setError(null);
    try {
      const { data } = await api.functions.invoke('getMyAvailableSlots', {});
      setHasConfig(data.has_availability_config !== false);
      if (data.duration_minutes) {
        setForm(f => ({ ...f, duration_minutes: data.duration_minutes }));
      }
      setAvailableDays(data.days || []);
    } catch (err) {
      setError('Error al cargar disponibilidad: ' + (err.message || 'desconocido'));
    } finally {
      setLoadingSlots(false);
    }
  };

  const availableDates = new Set(availableDays.map(d => d.date));

  const currentDaySlots = React.useMemo(() => {
    if (!selectedDate) return [];
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    const dayData = availableDays.find(d => d.date === dateStr);
    return dayData?.slots || [];
  }, [selectedDate, availableDays]);

  const isSlotSelected = (datetime) => selectedSlots.some(s => s.datetime === datetime);

  const toggleSlot = (slot) => {
    if (isSlotSelected(slot.datetime)) {
      setSelectedSlots(prev => prev.filter(s => s.datetime !== slot.datetime));
    } else if (selectedSlots.length < MAX_SLOTS) {
      setSelectedSlots(prev => [...prev, slot]);
    }
  };

  const formatSlotTime = (datetime) =>
    new Date(datetime).toLocaleTimeString('es-EC', {
      hour: '2-digit', minute: '2-digit', timeZone: 'America/Guayaquil'
    });

  const formatSlotFull = (datetime) =>
    new Date(datetime).toLocaleDateString('es-EC', {
      weekday: 'short', day: 'numeric', month: 'short', timeZone: 'America/Guayaquil'
    });

  const handleCopy = () => {
    navigator.clipboard.writeText(bookingUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleSend = async () => {
    setError(null);
    if (!form.client_email.trim()) { setError('El email del cliente es requerido'); return; }
    if (isStandalone && !form.client_name.trim()) { setError('El nombre del cliente es requerido'); return; }
    if (!form.title.trim()) { setError('El motivo de la cita es requerido'); return; }
    if (selectedSlots.length === 0) { setError('Selecciona al menos un horario disponible'); return; }

    setSending(true);
    try {
      const { data } = await api.functions.invoke('sendAppointmentProposal', {
        client_name: form.client_name.trim() || null,
        client_email: form.client_email.trim(),
        client_phone: form.client_phone.trim() || null,
        proposed_slots: selectedSlots.map(s => ({ datetime: s.datetime, duration_minutes: s.duration_minutes })),
        title: form.title.trim(),
        description: form.description.trim() || null,
        duration_minutes: form.duration_minutes,
        lead_id: lead?.id || null,
        prospect_id: prospect?.id || null,
        app_url: window.location.origin
      });

      if (data.error) {
        if (data.conflicting_slots) {
          setSelectedSlots(prev => prev.filter(s => !data.conflicting_slots.includes(s.datetime)));
          setError('Algunos horarios ya no están disponibles. Se eliminaron de tu selección.');
        } else {
          setError(data.error);
        }
        return;
      }

      setSuccess(true);
      setBookingUrl(data.booking_url);
    } catch (err) {
      setError(err.message || 'Error al enviar la propuesta');
    } finally {
      setSending(false);
    }
  };

  const sortedSelectedSlots = [...selectedSlots].sort((a, b) => new Date(a.datetime) - new Date(b.datetime));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5 text-brand" />
            Proponer Cita
          </DialogTitle>
        </DialogHeader>

        {success ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-lg">¡Propuesta enviada!</h3>
              <p className="text-slate-500 text-sm mt-1">
                {form.client_name || 'El cliente'} recibirá un correo con los horarios para elegir uno.
              </p>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-left">
              <p className="text-xs text-slate-400 mb-2">Enlace de reserva:</p>
              <p className="text-xs text-brand break-all font-mono mb-2">{bookingUrl}</p>
              <Button size="sm" variant="outline" onClick={handleCopy} className="gap-2 w-full">
                {copied ? <><Check className="h-3.5 w-3.5 text-green-500" /> Copiado</> : <><Copy className="h-3.5 w-3.5" /> Copiar enlace</>}
              </Button>
            </div>
            <Button onClick={onClose} className="w-full bg-brand hover:bg-brand-dark">Cerrar</Button>
          </div>
        ) : (
          <div className="space-y-4 pt-1">
            {/* Client info */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Email del cliente *</label>
                <input
                  type="email"
                  value={form.client_email}
                  onChange={e => setForm({ ...form, client_email: e.target.value })}
                  placeholder="cliente@ejemplo.com"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Nombre {isStandalone && '*'}</label>
                  <input
                    type="text"
                    value={form.client_name}
                    onChange={e => setForm({ ...form, client_name: e.target.value })}
                    placeholder="Juan Pérez"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Teléfono</label>
                  <input
                    type="tel"
                    value={form.client_phone}
                    onChange={e => setForm({ ...form, client_phone: e.target.value })}
                    placeholder="+593 99..."
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                  />
                </div>
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Motivo de la cita *</label>
              <input
                type="text"
                value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
                placeholder="Consulta de Seguros de Vida"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
              />
            </div>

            {/* Availability-based slot picker */}
            {loadingSlots ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-brand" />
                <span className="ml-2 text-sm text-slate-500">Cargando tu disponibilidad...</span>
              </div>
            ) : !hasConfig ? (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-center">
                <AlertCircle className="h-6 w-6 text-amber-500 mx-auto mb-2" />
                <p className="text-sm text-amber-700">No tienes una configuración de disponibilidad activa.</p>
                <p className="text-xs text-amber-600 mt-1">Configura tus horarios en "Mi Disponibilidad" para proponer citas.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Calendar */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-2">Selecciona un día</label>
                    <div className="flex justify-center">
                      <CalendarComponent
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        locale={es}
                        fromDate={new Date()}
                        toDate={new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)}
                        disabled={(date) => {
                          const dateStr = format(date, 'yyyy-MM-dd');
                          return !availableDates.has(dateStr);
                        }}
                        className="rounded-lg border"
                      />
                    </div>
                    {form.duration_minutes && (
                      <p className="text-xs text-slate-400 mt-2 text-center">Duración: {form.duration_minutes} min</p>
                    )}
                  </div>

                  {/* Available slots */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-2">
                      Horarios disponibles
                      {selectedDate && (
                        <span className="font-normal text-slate-400 capitalize ml-1">
                          · {format(selectedDate, 'EEEE d MMM', { locale: es })}
                        </span>
                      )}
                    </label>
                    {!selectedDate ? (
                      <div className="flex items-center justify-center h-32 text-sm text-slate-400 border border-dashed border-slate-200 rounded-lg">
                        Selecciona un día
                      </div>
                    ) : currentDaySlots.length === 0 ? (
                      <div className="flex items-center justify-center h-32 text-sm text-slate-400 border border-dashed border-slate-200 rounded-lg">
                        Sin horarios para este día
                      </div>
                    ) : (
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {currentDaySlots.map((slot) => {
                          const selected = isSlotSelected(slot.datetime);
                          return (
                            <button
                              key={slot.datetime}
                              type="button"
                              onClick={() => toggleSlot(slot)}
                              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-sm transition-all ${
                                selected
                                  ? 'bg-brand text-white border-brand'
                                  : 'bg-white text-slate-600 border-slate-200 hover:border-brand hover:bg-slate-50'
                              }`}
                            >
                              <span className="flex items-center gap-2">
                                <Clock className="h-3.5 w-3.5" />
                                {formatSlotTime(slot.datetime)}
                              </span>
                              {selected && <Check className="h-3.5 w-3.5" />}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                {/* Selected slots */}
                {selectedSlots.length > 0 && (
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-slate-600">
                        Seleccionados ({selectedSlots.length}/{MAX_SLOTS})
                      </span>
                      <button
                        type="button"
                        onClick={() => setSelectedSlots([])}
                        className="text-xs text-slate-400 hover:text-red-500"
                      >
                        Limpiar
                      </button>
                    </div>
                    <div className="space-y-1">
                      {sortedSelectedSlots.map((slot) => (
                        <div
                          key={slot.datetime}
                          className="flex items-center justify-between bg-white rounded-md px-3 py-1.5 border border-slate-200"
                        >
                          <span className="text-xs text-slate-600">
                            <span className="font-medium capitalize">{formatSlotFull(slot.datetime)}</span>
                            <span className="text-slate-400"> · {formatSlotTime(slot.datetime)}</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setSelectedSlots(prev => prev.filter(s => s.datetime !== slot.datetime))}
                            className="text-slate-400 hover:text-red-500"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Info note */}
                <div className="flex items-start gap-2 bg-blue-50 border border-blue-100 rounded-lg p-2.5">
                  <Info className="h-3.5 w-3.5 text-blue-500 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-600">
                    Los horarios seleccionados se bloquean temporalmente hasta que el cliente confirme uno o la propuesta expire (7 días).
                  </p>
                </div>
              </>
            )}

            {/* Message */}
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Mensaje adicional</label>
              <textarea
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                placeholder="Prepara tu documentación de ingresos, DNI..."
                rows={2}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand resize-none"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg p-3">
                <AlertCircle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <div className="flex gap-3 pt-1">
              <Button variant="outline" onClick={onClose} className="flex-1">Cancelar</Button>
              <Button
                onClick={handleSend}
                disabled={sending || !hasConfig}
                className="flex-1 bg-brand hover:bg-brand-dark gap-2"
              >
                {sending ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Enviando...</>
                ) : (
                  <><Send className="h-4 w-4" /> Enviar propuesta</>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}