import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { format } from 'date-fns';

const EVENT_TYPES = [
  { value: 'llamada', label: 'Llamada' },
  { value: 'reunión', label: 'Reunión' },
  { value: 'seguimiento', label: 'Seguimiento' },
  { value: 'otro', label: 'Otro' }
];

export default function CalendarEventForm({ open, onClose, onSaved, initialDate }) {
  const [loading, setLoading] = useState(false);
  const [leads, setLeads] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    event_type: 'llamada',
    start_datetime: '',
    end_datetime: '',
    lead_id: '',
    location: '',
    attendees: ''
  });

  useEffect(() => {
    if (open) {
      loadLeads();
      if (initialDate) {
        const dateStr = format(initialDate, "yyyy-MM-dd'T'HH:mm");
        const endDateStr = format(new Date(initialDate.getTime() + 60 * 60 * 1000), "yyyy-MM-dd'T'HH:mm");
        setFormData(prev => ({
          ...prev,
          start_datetime: dateStr,
          end_datetime: endDateStr
        }));
      }
    }
  }, [open, initialDate]);

  const loadLeads = async () => {
    try {
      const user = await api.auth.me();
      const leadsData = await api.entities.Lead.filter({
        assigned_agent_id: user.id,
        lead_status: 'ACTIVO'
      }, '-last_activity_at', 100);
      setLeads(leadsData);
    } catch (error) {
      console.error('Error loading leads:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title || !formData.start_datetime || !formData.end_datetime) {
      alert('Por favor completa los campos requeridos');
      return;
    }

    try {
      setLoading(true);

      // Get lead name if lead selected
      let eventData = { ...formData };
      if (formData.lead_id) {
        const selectedLead = leads.find(l => l.id === formData.lead_id);
        if (selectedLead) {
          eventData.lead_name = selectedLead.prospect_name;
          eventData.prospect_id = selectedLead.prospect_id;
        }
      }

      // Create event with Google Calendar sync
      const response = await api.functions.invoke('createUserGoogleCalendarEvent', {
        eventData
      });
      
      if (response.data.message) {
        alert(response.data.message);
      }

      onSaved();
      resetForm();
    } catch (error) {
      console.error('Error creating event:', error);
      alert('Error al crear el evento');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      event_type: 'llamada',
      start_datetime: '',
      end_datetime: '',
      lead_id: '',
      location: '',
      attendees: ''
    });
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-zinc-950 dark:border-zinc-800">
        <DialogHeader>
          <DialogTitle>Nueva Actividad</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label>Título *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Ej: Reunión con cliente"
                required
              />
            </div>

            <div>
              <Label>Tipo de Evento *</Label>
              <Select value={formData.event_type} onValueChange={(v) => setFormData({ ...formData, event_type: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EVENT_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Lead Relacionado</Label>
              <Select value={formData.lead_id} onValueChange={(v) => setFormData({ ...formData, lead_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar lead" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Ninguno</SelectItem>
                  {leads.map(lead => (
                    <SelectItem key={lead.id} value={lead.id}>
                      {lead.prospect_name} - {lead.branch}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Fecha y Hora de Inicio *</Label>
              <Input
                type="datetime-local"
                value={formData.start_datetime}
                onChange={(e) => setFormData({ ...formData, start_datetime: e.target.value })}
                required
              />
            </div>

            <div>
              <Label>Fecha y Hora de Fin *</Label>
              <Input
                type="datetime-local"
                value={formData.end_datetime}
                onChange={(e) => setFormData({ ...formData, end_datetime: e.target.value })}
                required
              />
            </div>

            <div className="md:col-span-2">
              <Label>Ubicación</Label>
              <Input
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="Ej: Oficina, Zoom, etc."
              />
            </div>

            <div className="md:col-span-2">
              <Label>Participantes (emails separados por coma)</Label>
              <Input
                value={formData.attendees}
                onChange={(e) => setFormData({ ...formData, attendees: e.target.value })}
                placeholder="email1@ejemplo.com, email2@ejemplo.com"
              />
            </div>

            <div className="md:col-span-2">
              <Label>Descripción</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Detalles adicionales sobre el evento"
                rows={4}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Crear y Sincronizar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}