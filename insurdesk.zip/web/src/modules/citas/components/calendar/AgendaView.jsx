import React, { useMemo } from 'react';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, isToday, addWeeks, subWeeks } from 'date-fns';
import { es } from 'date-fns/locale';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, MapPin, Users, ChevronLeft, ChevronRight, CalendarIcon } from 'lucide-react';
import { cn } from "@/lib/utils";

const eventTypeColors = {
  'llamada':     'bg-blue-50 text-blue-700 border-blue-200 border-l-blue-500 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800 dark:border-l-blue-500',
  'reunión':     'bg-purple-50 text-purple-700 border-purple-200 border-l-purple-500 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800 dark:border-l-purple-500',
  'seguimiento': 'bg-amber-50 text-amber-700 border-amber-200 border-l-amber-500 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800 dark:border-l-amber-500',
  'otro':        'bg-slate-50 text-slate-700 border-slate-200 border-l-slate-400 dark:bg-zinc-800/50 dark:text-zinc-300 dark:border-zinc-700 dark:border-l-zinc-500',
};

const statusColors = {
  'programado': 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-700',
  'completado': 'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700',
  'cancelado':  'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-700',
};

export default function AgendaView({ events, weekDate, onWeekChange, onEventClick }) {
  const weekStart = startOfWeek(weekDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(weekDate, { weekStartsOn: 1 });
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const eventsByDay = useMemo(() => {
    const map = {};
    weekDays.forEach(day => {
      const key = format(day, 'yyyy-MM-dd');
      map[key] = events
        .filter(e => isSameDay(new Date(e.start_datetime), day))
        .sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime));
    });
    return map;
  }, [events, weekDate]);

  const totalWeekEvents = weekDays.reduce((acc, day) => {
    return acc + (eventsByDay[format(day, 'yyyy-MM-dd')]?.length || 0);
  }, 0);

  return (
    <div className="space-y-4">
      {/* Week navigation */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => onWeekChange(subWeeks(weekDate, 1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => onWeekChange(new Date())}>
            Esta semana
          </Button>
          <Button variant="outline" size="icon" onClick={() => onWeekChange(addWeeks(weekDate, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="text-sm text-slate-500 dark:text-zinc-400">
          {format(weekStart, "d MMM", { locale: es })} – {format(weekEnd, "d MMM yyyy", { locale: es })}
          <span className="ml-2 font-medium text-slate-700 dark:text-zinc-200">({totalWeekEvents} actividades)</span>
        </div>
      </div>

      {/* Days */}
      <div className="space-y-3">
        {weekDays.map(day => {
          const key = format(day, 'yyyy-MM-dd');
          const dayEvents = eventsByDay[key] || [];
          const today = isToday(day);

          return (
            <div
              key={key}
              className={cn(
                "rounded-xl overflow-hidden border",
                today
                  ? "border-2 border-blue-500 dark:border-blue-700"
                  : "border-slate-200 dark:border-zinc-700"
              )}
            >
              {/* Day header */}
              <div
                className={cn(
                  "px-4 py-2 flex items-center gap-3",
                  today
                    ? "bg-blue-600 dark:bg-blue-800 text-white"
                    : "bg-slate-100 dark:bg-zinc-700 text-slate-700 dark:text-white"
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold">
                    {format(day, 'd')}
                  </span>
                  <span className="text-sm font-medium capitalize">
                    {format(day, 'EEEE', { locale: es })}
                  </span>
                  {today && (
                    <Badge className="bg-white text-blue-600 dark:text-blue-700 text-xs px-2">Hoy</Badge>
                  )}
                </div>
                <span className={cn("ml-auto text-xs", today ? "text-blue-100" : "text-slate-500 dark:text-zinc-400")}>
                  {dayEvents.length} {dayEvents.length === 1 ? 'actividad' : 'actividades'}
                </span>
              </div>

              {/* Events */}
              <div className="divide-y divide-slate-100 dark:divide-zinc-700 bg-white dark:bg-zinc-800">
                {dayEvents.length === 0 ? (
                  <div className="px-4 py-3 text-sm text-slate-400 dark:text-zinc-500 italic">Sin actividades</div>
                ) : (
                  dayEvents.map(event => (
                    <div
                      key={event.id}
                      onClick={() => onEventClick(event)}
                      className={cn(
                        "px-4 py-3 cursor-pointer transition-colors border-l-4",
                        "hover:bg-slate-50 dark:hover:bg-zinc-700/60",
                        eventTypeColors[event.event_type] || eventTypeColors['otro']
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-semibold text-slate-800 dark:text-zinc-100 text-sm">{event.title}</p>
                            <Badge variant="outline" className={cn("text-xs", statusColors[event.status])}>
                              {event.status}
                            </Badge>
                          </div>

                          <div className="flex items-center gap-4 mt-1.5 flex-wrap">
                            <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-zinc-400">
                              <Clock className="h-3 w-3" />
                              <span>
                                {format(new Date(event.start_datetime), 'HH:mm')} – {format(new Date(event.end_datetime), 'HH:mm')}
                              </span>
                            </div>
                            {event.location && (
                              <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-zinc-400">
                                <MapPin className="h-3 w-3" />
                                <span className="truncate max-w-[150px]">{event.location}</span>
                              </div>
                            )}
                            {event.attendees && (
                              <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-zinc-400">
                                <Users className="h-3 w-3" />
                                <span className="truncate max-w-[150px]">{event.attendees}</span>
                              </div>
                            )}
                          </div>

                          {event.description && (
                            <p className="text-xs text-slate-500 dark:text-zinc-400 mt-1 line-clamp-2">{event.description}</p>
                          )}
                          {event.lead_name && (
                            <p className="text-xs text-slate-600 dark:text-zinc-300 mt-1 font-medium">🔗 Lead: {event.lead_name}</p>
                          )}
                        </div>
                        <Badge className={cn("text-xs shrink-0", eventTypeColors[event.event_type] || eventTypeColors['otro'])}>
                          {event.event_type}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {totalWeekEvents === 0 && (
        <div className="text-center py-12 text-slate-400 dark:text-zinc-500">
          <CalendarIcon className="h-12 w-12 mx-auto mb-3 text-slate-300 dark:text-zinc-600" />
          <p>No hay actividades esta semana</p>
        </div>
      )}
    </div>
  );
}