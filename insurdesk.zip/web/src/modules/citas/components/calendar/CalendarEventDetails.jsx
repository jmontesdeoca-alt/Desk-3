import React from 'react';
import { api } from '@/api/client';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, MapPin, Users, FileText, CheckCircle, XCircle } from "lucide-react";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from "@/lib/utils";

const eventTypeColors = {
  'llamada': 'bg-blue-100 text-blue-700 border-blue-200',
  'reunión': 'bg-purple-100 text-purple-700 border-purple-200',
  'seguimiento': 'bg-amber-100 text-amber-700 border-amber-200',
  'otro': 'bg-slate-100 text-slate-700 border-slate-200'
};

const statusColors = {
  'programado': 'bg-blue-100 text-blue-700',
  'completado': 'bg-green-100 text-green-700',
  'cancelado': 'bg-red-100 text-red-700'
};

export default function CalendarEventDetails({ open, onClose, event, onEventUpdated }) {
  if (!event) return null;

  const handleMarkCompleted = async () => {
    try {
      await api.entities.CalendarEvent.update(event.id, {
        status: 'completado'
      });
      onEventUpdated();
      onClose();
    } catch (error) {
      console.error('Error updating event:', error);
      alert('Error al actualizar el evento');
    }
  };

  const handleMarkCancelled = async () => {
    try {
      await api.entities.CalendarEvent.update(event.id, {
        status: 'cancelado'
      });
      onEventUpdated();
      onClose();
    } catch (error) {
      console.error('Error updating event:', error);
      alert('Error al actualizar el evento');
    }
  };

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto dark:bg-zinc-800 dark:border-zinc-700">
        <SheetHeader>
          <SheetTitle className="text-2xl">{event.title}</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={cn("text-sm px-3 py-1", eventTypeColors[event.event_type])}>
              {event.event_type}
            </Badge>
            <Badge className={cn("text-sm px-3 py-1", statusColors[event.status])}>
              {event.status}
            </Badge>
          </div>

          <Card>
            <CardContent className="pt-4 space-y-3">
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-slate-400 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-slate-900">
                    {format(new Date(event.start_datetime), "EEEE, d 'de' MMMM", { locale: es })}
                  </p>
                  <p className="text-sm text-slate-600">
                    {format(new Date(event.start_datetime), 'HH:mm')} - {format(new Date(event.end_datetime), 'HH:mm')}
                  </p>
                </div>
              </div>

              {event.location && (
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-slate-400 mt-0.5" />
                  <p className="text-sm text-slate-600">{event.location}</p>
                </div>
              )}

              {event.attendees && (
                <div className="flex items-start gap-3">
                  <Users className="h-5 w-5 text-slate-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-slate-900 mb-1">Participantes:</p>
                    <p className="text-sm text-slate-600">{event.attendees}</p>
                  </div>
                </div>
              )}

              {event.description && (
                <div className="flex items-start gap-3">
                  <FileText className="h-5 w-5 text-slate-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-slate-900 mb-1">Descripción:</p>
                    <p className="text-sm text-slate-600 whitespace-pre-wrap">{event.description}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {event.lead_name && (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-4">
                <p className="text-sm font-medium text-blue-900 mb-1">Lead Relacionado:</p>
                <p className="text-sm text-blue-700">{event.lead_name}</p>
              </CardContent>
            </Card>
          )}

          {event.status === 'programado' && (
            <div className="flex gap-3 pt-4">
              <Button
                onClick={handleMarkCompleted}
                className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
              >
                <CheckCircle className="h-4 w-4" />
                Marcar Completado
              </Button>
              <Button
                onClick={handleMarkCancelled}
                variant="outline"
                className="flex-1 text-red-600 hover:text-red-700 gap-2"
              >
                <XCircle className="h-4 w-4" />
                Cancelar
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}