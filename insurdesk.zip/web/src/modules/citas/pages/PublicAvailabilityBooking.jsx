import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Loader2, Clock, Calendar as CalendarIcon, ChevronLeft, ChevronRight, Megaphone, CheckCircle, AlertCircle, User } from 'lucide-react';
import { format, addMonths, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameDay, isSameMonth, isToday, isBefore, startOfDay } from 'date-fns';
import { es } from 'date-fns/locale';

const DAY_LABELS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const MONTH_NAMES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

export default function PublicAvailabilityBooking() {
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('t');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [agentInfo, setAgentInfo] = useState(null);

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState(null);

  const [step, setStep] = useState('calendar'); // 'calendar' | 'form' | 'success'
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);
  const [result, setResult] = useState(null);
  const [form, setForm] = useState({ name: '', email: '', phone: '', notes: '' });

  useEffect(() => {
    if (!token) {
      setError('Enlace inválido. Falta el parámetro de configuración.');
      setLoading(false);
      return;
    }
    loadAgentInfo();
  }, []);

  const loadAgentInfo = async () => {
    try {
      const { data } = await api.functions.invoke('getAgentBookableInfo', { token });
      if (data.error) throw new Error(data.error);
      setAgentInfo(data);
    } catch (err) {
      setError('No se pudo cargar la disponibilidad. El enlace puede ser inválido.');
    } finally {
      setLoading(false);
    }
  };

  const availableDays = agentInfo?.available_days || [];

  const isDateAvailable = (date) => {
    if (isBefore(startOfDay(date), startOfDay(new Date()))) return false;
    return availableDays.includes(getDay(date));
  };

  const handleDateClick = async (date) => {
    if (!isDateAvailable(date)) return;
    setSelectedDate(date);
    setSelectedSlot(null);
    setSlots([]);
    setLoadingSlots(true);
    setStep('calendar');

    try {
      const dateStr = format(date, 'yyyy-MM-dd');
      const { data } = await api.functions.invoke('getAgentSlotsForDate', { token, date: dateStr });
      if (data.error) throw new Error(data.error);
      setSlots(data.slots || []);
    } catch (err) {
      setSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleConfirm = async () => {
    setFormError(null);
    setSubmitting(true);
    try {
      const { data } = await api.functions.invoke('bookAgentSlot', {
        token,
        datetime: selectedSlot.datetime,
        client_name: form.name.trim(),
        client_email: form.email.trim(),
        client_phone: form.phone.trim() || null,
        notes: form.notes.trim() || null,
      });
      if (data.error) throw new Error(data.error);
      setResult(data);
      setStep('success');
    } catch (err) {
      setFormError(err.message || 'Error al reservar. Intenta de nuevo.');
    } finally {
      setSubmitting(false);
    }
  };

  // --- LOADING ---
  if (loading) return (
    <div className="min-h-screen bg-ink flex items-center justify-center">
      <Loader2 className="h-10 w-10 animate-spin text-white" />
    </div>
  );

  // --- ERROR ---
  if (error || !agentInfo) return (
    <div className="min-h-screen bg-ink flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-2xl">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">Enlace inválido</h2>
        <p className="text-slate-500 text-sm">{error || 'No se encontró la configuración.'}</p>
      </div>
    </div>
  );

  // --- SUCCESS ---
  if (step === 'success' && result) {
    const dt = new Date(result.confirmed_datetime);
    return (
      <div className="min-h-screen bg-ink flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
          <div className="bg-ink p-5 text-center">
            <span className="text-xl font-black"><span style={{ color: '#9DB1E3' }}>GA</span><span className="text-white">CRM</span></span>
          </div>
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-9 w-9 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">¡Cita confirmada!</h2>
            <p className="text-slate-500 text-sm mb-6">Te enviamos un correo con los detalles.</p>
            <div className="bg-slate-50 rounded-xl p-4 text-left space-y-3">
              <Row icon={<CalendarIcon className="h-4 w-4 text-brand" />} label="Motivo" value={result.title} />
              <Row icon={<CalendarIcon className="h-4 w-4 text-brand" />} label="Fecha" value={<span className="capitalize">{format(dt, "EEEE d 'de' MMMM, yyyy", { locale: es })}</span>} />
              <Row icon={<Clock className="h-4 w-4 text-brand" />} label="Hora" value={`${format(dt, 'HH:mm')} (Ecuador)`} />
              <Row icon={<User className="h-4 w-4 text-brand" />} label="Agente" value={result.agent_name} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --- CALENDAR / FORM ---
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = new Date(monthStart);
  calendarStart.setDate(calendarStart.getDate() - getDay(monthStart));
  const calendarEnd = new Date(monthEnd);
  calendarEnd.setDate(calendarEnd.getDate() + (6 - getDay(monthEnd)));
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Prevent navigating to past months
  const canGoPrev = !isBefore(monthStart, startOfMonth(new Date()));

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center p-4 py-8">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col md:flex-row">
        {/* Left Panel */}
        <div className="md:w-64 p-6 border-b md:border-b-0 md:border-r border-slate-200 flex flex-col">
          <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center mb-4">
            <Megaphone className="h-6 w-6 text-white" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-4 leading-tight">
            {agentInfo.agent_name} Calendar
          </h2>
          <div className="space-y-3 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 flex-shrink-0" />
              <span>{agentInfo.duration_minutes} min</span>
            </div>
            {selectedDate && (
              <div className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 flex-shrink-0" />
                <span className="capitalize">{format(selectedDate, "EEE, d 'de' MMM 'de' yyyy", { locale: es })}</span>
              </div>
            )}
          </div>
          {agentInfo.booking_description && (
            <p className="text-xs text-slate-400 mt-auto pt-4">{agentInfo.booking_description}</p>
          )}
        </div>

        {/* Right Panel */}
        <div className="flex-1 p-6">
          {step === 'form' && selectedSlot ? (
            // --- FORM STEP ---
            <div>
              <button onClick={() => setStep('calendar')} className="flex items-center gap-1 text-sm text-brand hover:underline mb-4">
                <ChevronLeft className="h-4 w-4" /> Volver
              </button>
              <h3 className="text-base font-bold text-slate-900 mb-1">Confirma tus datos</h3>
              <p className="text-sm text-slate-500 mb-4 capitalize">
                {format(selectedDate, "EEEE d 'de' MMMM", { locale: es })} a las {format(new Date(selectedSlot.datetime), 'HH:mm')}
              </p>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Nombre completo *</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                    placeholder="Juan Pérez"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Correo electrónico *</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={e => setForm({ ...form, email: e.target.value })}
                    placeholder="juan@email.com"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Teléfono <span className="text-slate-400 font-normal">(opcional)</span></label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={e => setForm({ ...form, phone: e.target.value })}
                    placeholder="+593 99 999 9999"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Notas <span className="text-slate-400 font-normal">(opcional)</span></label>
                  <textarea
                    value={form.notes}
                    onChange={e => setForm({ ...form, notes: e.target.value })}
                    placeholder="¿Algo que debamos saber antes de la cita?"
                    rows={2}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                  />
                </div>
              </div>

              {formError && (
                <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg p-3 mt-3">
                  <AlertCircle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-600">{formError}</p>
                </div>
              )}

              <button
                onClick={handleConfirm}
                disabled={!form.name.trim() || !form.email.trim() || submitting}
                className="w-full mt-4 py-3 rounded-xl font-semibold text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                style={{ background: 'linear-gradient(135deg, #0A8FBE, #004B6F)' }}
              >
                {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Confirmando...</> : 'Confirmar cita →'}
              </button>
            </div>
          ) : (
            // --- CALENDAR STEP ---
            <>
              <h3 className="text-base font-bold text-slate-900 mb-4">Seleccione la Fecha & Hora</h3>

              {/* Month Navigation */}
              <div className="flex items-center justify-between mb-4">
                <button
                  onClick={() => canGoPrev && setCurrentMonth(addMonths(currentMonth, -1))}
                  disabled={!canGoPrev}
                  className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="h-5 w-5 text-brand" />
                </button>
                <span className="text-base font-semibold text-slate-900">
                  {MONTH_NAMES[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </span>
                <button
                  onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                  className="p-1.5 rounded-lg hover:bg-slate-100"
                >
                  <ChevronRight className="h-5 w-5 text-brand" />
                </button>
              </div>

              {/* Day Headers */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {DAY_LABELS.map(d => (
                  <div key={d} className="text-center text-xs text-slate-400 font-medium py-1">{d}</div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-1 mb-4">
                {calendarDays.map((date, idx) => {
                  const available = isDateAvailable(date);
                  const isSelected = selectedDate && isSameDay(date, selectedDate);
                  const inMonth = isSameMonth(date, currentMonth);
                  const today = isToday(date);

                  return (
                    <button
                      key={idx}
                      onClick={() => available && handleDateClick(date)}
                      disabled={!available || !inMonth}
                      className={`
                        aspect-square flex items-center justify-center text-sm rounded-full transition-all relative
                        ${!inMonth ? 'text-slate-300 cursor-default' : ''}
                        ${available && !isSelected ? 'text-slate-700 hover:bg-blue-50 cursor-pointer font-medium' : ''}
                        ${available ? 'font-semibold' : ''}
                        ${isSelected ? 'bg-brand text-white font-bold' : ''}
                        ${!available && inMonth && !isSelected ? 'text-slate-400 cursor-not-allowed' : ''}
                      `}
                    >
                      {format(date, 'd')}
                      {available && !isSelected && inMonth && (
                        <span className="absolute bottom-1 w-1.5 h-1.5 rounded-full bg-brand opacity-40"></span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Time Slots */}
              {selectedDate && (
                <div className="border-t border-slate-200 pt-4">
                  <p className="text-sm font-semibold text-slate-700 mb-3 capitalize">
                    {format(selectedDate, "EEEE d 'de' MMMM", { locale: es })}
                  </p>
                  {loadingSlots ? (
                    <div className="flex items-center gap-2 text-sm text-slate-500 py-4">
                      <Loader2 className="h-4 w-4 animate-spin" /> Buscando horarios disponibles...
                    </div>
                  ) : slots.length === 0 ? (
                    <p className="text-sm text-slate-400 py-4">No hay horarios disponibles este día. Tu agenda está completa.</p>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {slots.map((slot, idx) => {
                        const isSelected = selectedSlot?.datetime === slot.datetime;
                        return (
                          <button
                            key={idx}
                            onClick={() => { setSelectedSlot(slot); setStep('form'); }}
                            className={`py-2.5 rounded-lg border-2 text-sm font-medium transition-all ${
                              isSelected
                                ? 'border-brand bg-brand text-white'
                                : 'border-brand text-brand hover:bg-blue-50'
                            }`}
                          >
                            {format(new Date(slot.datetime), 'HH:mm')}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Timezone Footer */}
              <div className="border-t border-slate-200 mt-4 pt-3 flex items-center justify-between">
                <span className="text-sm text-slate-500">Zona horaria</span>
                <div className="flex items-center gap-1.5 text-sm text-slate-700">
                  <span>{agentInfo.timezone}</span>
                  <ChevronRight className="h-3 w-3 text-brand rotate-90" />
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ icon, label, value }) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 flex-shrink-0">{icon}</div>
      <div>
        <p className="text-xs text-slate-400 uppercase font-semibold">{label}</p>
        <p className="text-sm font-semibold text-slate-700">{value}</p>
      </div>
    </div>
  );
}