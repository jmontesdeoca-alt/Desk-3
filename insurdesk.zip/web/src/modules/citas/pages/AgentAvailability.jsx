import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Plus, Trash2, Copy, Check, CalendarClock, ExternalLink, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const DAYS = [
  { value: 1, label: 'Lunes', short: 'Lun' },
  { value: 2, label: 'Martes', short: 'Mar' },
  { value: 3, label: 'Miércoles', short: 'Mié' },
  { value: 4, label: 'Jueves', short: 'Jue' },
  { value: 5, label: 'Viernes', short: 'Vie' },
  { value: 6, label: 'Sábado', short: 'Sáb' },
  { value: 0, label: 'Domingo', short: 'Dom' },
];

const DURATIONS = [15, 30, 45, 60, 90];

function generateToken() {
  return Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
}

export default function AgentAvailability() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [configId, setConfigId] = useState(null);
  const [config, setConfig] = useState(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);

      const existing = await api.entities.AgentAvailability.filter({ agent_id: user.id });
      if (existing.length > 0) {
        const c = existing[0];
        setConfigId(c.id);
        setConfig({
          schedule: c.schedule || [],
          duration_minutes: c.duration_minutes || 30,
          buffer_minutes: c.buffer_minutes || 0,
          booking_title: c.booking_title || 'Consulta',
          booking_description: c.booking_description || '',
          public_token: c.public_token || generateToken(),
          is_active: c.is_active !== false,
        });
      } else {
        setConfig({
          schedule: [],
          duration_minutes: 30,
          buffer_minutes: 0,
          booking_title: 'Consulta',
          booking_description: '',
          public_token: generateToken(),
          is_active: true,
        });
      }
    } catch (err) {
      toast({ title: 'Error', description: 'No se pudo cargar la configuración', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const toggleDay = (dayValue) => {
    const exists = config.schedule.find(s => s.day_of_week === dayValue);
    if (exists) {
      setConfig({ ...config, schedule: config.schedule.filter(s => s.day_of_week !== dayValue) });
    } else {
      setConfig({
        ...config,
        schedule: [...config.schedule, { day_of_week: dayValue, time_slots: [{ start_time: '09:00', end_time: '12:00' }] }]
      });
    }
  };

  const updateTimeSlot = (dayValue, slotIndex, field, value) => {
    setConfig({
      ...config,
      schedule: config.schedule.map(s => {
        if (s.day_of_week !== dayValue) return s;
        const newSlots = [...s.time_slots];
        newSlots[slotIndex] = { ...newSlots[slotIndex], [field]: value };
        return { ...s, time_slots: newSlots };
      })
    });
  };

  const addTimeSlot = (dayValue) => {
    setConfig({
      ...config,
      schedule: config.schedule.map(s => {
        if (s.day_of_week !== dayValue) return s;
        return { ...s, time_slots: [...s.time_slots, { start_time: '14:00', end_time: '17:00' }] };
      })
    });
  };

  const removeTimeSlot = (dayValue, slotIndex) => {
    setConfig({
      ...config,
      schedule: config.schedule.map(s => {
        if (s.day_of_week !== dayValue) return s;
        return { ...s, time_slots: s.time_slots.filter((_, i) => i !== slotIndex) };
      })
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        ...config,
        agent_id: currentUser.id,
        agent_name: currentUser.full_name,
        agent_email: currentUser.email,
      };

      if (configId) {
        await api.entities.AgentAvailability.update(configId, payload);
      } else {
        const created = await api.entities.AgentAvailability.create(payload);
        setConfigId(created.id);
      }

      toast({ title: '✅ Guardado', description: 'Tu disponibilidad se actualizó correctamente' });
    } catch (err) {
      toast({ title: 'Error', description: 'No se pudo guardar', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const copyLink = () => {
    const link = `${window.location.origin}/Booking?t=${config.public_token}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading || !config) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  const bookingLink = `${window.location.origin}/Booking?t=${config.public_token}`;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CalendarClock className="h-6 w-6 text-brand" />
              Mi Disponibilidad
            </h1>
            <p className="text-slate-500 dark:text-zinc-400 mt-1 text-sm">
              Configura los horarios en que aceptas citas. El sistema revisará tu calendario de Google y mostrará solo los espacios libres.
            </p>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to={createPageUrl('Calendar')}>← Volver</Link>
          </Button>
        </div>

        {/* Booking Link */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Enlace público de reservas</CardTitle>
            <CardDescription>Comparte este enlace con tus clientes para que agenden solos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Input value={bookingLink} readOnly className="font-mono text-sm" />
              <Button onClick={copyLink} variant="outline" size="icon" className="flex-shrink-0">
                {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
              </Button>
              <Button asChild size="icon" className="flex-shrink-0 bg-brand hover:bg-brand-dark">
                <a href={bookingLink} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
            </div>
            <div className="flex items-center gap-2 mt-4">
              <Switch
                checked={config.is_active}
                onCheckedChange={(v) => setConfig({ ...config, is_active: v })}
              />
              <Label className="text-sm cursor-pointer">Disponibilidad activa</Label>
            </div>
          </CardContent>
        </Card>

        {/* Weekly Schedule */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Horarios semanales</CardTitle>
            <CardDescription>Marca los días y rangos horarios en que aceptas citas</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {DAYS.map(day => {
              const daySchedule = config.schedule.find(s => s.day_of_week === day.value);
              const isEnabled = !!daySchedule;
              return (
                <div key={day.value} className={`rounded-lg border p-3 transition-colors ${isEnabled ? 'border-brand/30 bg-brand/5 dark:bg-brand/10' : 'border-slate-200 dark:border-zinc-700'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <Switch checked={isEnabled} onCheckedChange={() => toggleDay(day.value)} />
                      <span className="font-medium text-sm text-slate-800 dark:text-zinc-200">{day.label}</span>
                    </div>
                    {isEnabled && daySchedule.time_slots.length < 3 && (
                      <Button onClick={() => addTimeSlot(day.value)} variant="ghost" size="sm" className="text-brand gap-1">
                        <Plus className="h-3 w-3" /> Añadir rango
                      </Button>
                    )}
                  </div>
                  {isEnabled && (
                    <div className="space-y-2 ml-11">
                      {daySchedule.time_slots.map((slot, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <Clock className="h-3.5 w-3.5 text-slate-400 flex-shrink-0" />
                          <Input
                            type="time"
                            value={slot.start_time}
                            onChange={(e) => updateTimeSlot(day.value, idx, 'start_time', e.target.value)}
                            className="w-32 text-sm"
                          />
                          <span className="text-slate-400 text-sm">—</span>
                          <Input
                            type="time"
                            value={slot.end_time}
                            onChange={(e) => updateTimeSlot(day.value, idx, 'end_time', e.target.value)}
                            className="w-32 text-sm"
                          />
                          {daySchedule.time_slots.length > 1 && (
                            <Button onClick={() => removeTimeSlot(day.value, idx)} variant="ghost" size="icon" className="h-7 w-7 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20">
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Appointment Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Configuración de la cita</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm">Duración de la cita</Label>
                <Select value={String(config.duration_minutes)} onValueChange={(v) => setConfig({ ...config, duration_minutes: Number(v) })}>
                  <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DURATIONS.map(d => <SelectItem key={d} value={String(d)}>{d} minutos</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm">Separación entre citas (min)</Label>
                <Input
                  type="number"
                  min="0"
                  step="5"
                  value={config.buffer_minutes}
                  onChange={(e) => setConfig({ ...config, buffer_minutes: Number(e.target.value) })}
                  className="mt-1.5"
                />
              </div>
            </div>
            <div>
              <Label className="text-sm">Título de la cita</Label>
              <Input
                value={config.booking_title}
                onChange={(e) => setConfig({ ...config, booking_title: e.target.value })}
                placeholder="Ej: Consulta de Seguros"
                className="mt-1.5"
              />
            </div>
            <div>
              <Label className="text-sm">Descripción (opcional)</Label>
              <Textarea
                value={config.booking_description}
                onChange={(e) => setConfig({ ...config, booking_description: e.target.value })}
                placeholder="Información adicional que verá el cliente al reservar"
                className="mt-1.5"
                rows={2}
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3 pb-6">
          <Button asChild variant="outline">
            <Link to={createPageUrl('Calendar')}>Cancelar</Link>
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-brand hover:bg-brand-dark gap-2">
            {saving ? <><Loader2 className="h-4 w-4 animate-spin" /> Guardando...</> : 'Guardar disponibilidad'}
          </Button>
        </div>
      </div>
    </div>
  );
}