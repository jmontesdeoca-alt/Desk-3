import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar as CalendarIcon, Plus, RefreshCw, ChevronLeft, 
  ChevronRight, Clock, Users, Loader2, LayoutList, Grid3X3
} from "lucide-react";

import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, startOfWeek, endOfWeek } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from "@/lib/utils";
import CalendarEventForm from '@/modules/citas/components/calendar/CalendarEventForm';
import CalendarEventDetails from '@/modules/citas/components/calendar/CalendarEventDetails';
import AgendaView from '@/modules/citas/components/calendar/AgendaView';
import AppointmentProposalsManager from '@/modules/citas/components/appointments/AppointmentProposalsManager';
import { useToast } from "@/components/ui/use-toast";

const eventTypeColors = {
  'llamada': 'bg-blue-100 text-blue-700 border-blue-200',
  'reunión': 'bg-purple-100 text-purple-700 border-purple-200',
  'seguimiento': 'bg-amber-100 text-amber-700 border-amber-200',
  'otro': 'bg-slate-100 text-slate-700 border-slate-200'
};

export default function Calendar() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [showEventForm, setShowEventForm] = useState(false);
  const [showEventDetails, setShowEventDetails] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [calendarConnection, setCalendarConnection] = useState(null);
  const [checkingConnection, setCheckingConnection] = useState(true);
  const [viewMode, setViewMode] = useState('month'); // 'month' | 'agenda' | 'slots'
  const [agendaWeekDate, setAgendaWeekDate] = useState(new Date());
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      setCheckingConnection(true);
      const user = await api.auth.me();
      setCurrentUser(user);

      // Check calendar connection
      const connections = await api.entities.UserCalendarConnection.filter({
        user_id: user.id,
        provider: 'google',
        is_active: true
      });
      setCalendarConnection(connections.length > 0 ? connections[0] : null);

      // Strict filter: only load events belonging to the authenticated user
      const eventsData = await api.entities.CalendarEvent.filter({
        assigned_to_id: user.id
      }, '-start_datetime', 500);
      
      setEvents(eventsData);
    } catch (error) {
      console.error('Error loading calendar:', error);
    } finally {
      setLoading(false);
      setCheckingConnection(false);
    }
  };

  const handleConnectCalendar = async () => {
    try {
      const { data } = await api.functions.invoke('initiateCalendarAuth', {});
      if (data.error) {
        toast({ title: 'Error', description: data.message || data.error, variant: 'destructive' });
        return;
      }

      if (data.auth_url) {
        const popup = window.open(data.auth_url, 'google_calendar_auth', 'width=500,height=600,scrollbars=yes');

        const messageHandler = async (event) => {
          if (event.data?.type === 'calendar_connected') {
            window.removeEventListener('message', messageHandler);
            clearInterval(pollClosed);
            await loadData();
            toast({ title: '¡Conectado!', description: 'Google Calendar vinculado correctamente.' });
          }
        };
        window.addEventListener('message', messageHandler);

        const pollClosed = setInterval(async () => {
          if (popup?.closed) {
            clearInterval(pollClosed);
            window.removeEventListener('message', messageHandler);
            await loadData();
          }
        }, 1000);
      }
    } catch (error) {
      console.error('Error connecting calendar:', error);
      toast({ title: 'Error', description: 'Error al conectar el calendario', variant: 'destructive' });
    }
  };

  const handleDisconnectCalendar = async () => {
    if (!window.confirm('¿Deseas desconectar tu Google Calendar?')) return;
    
    try {
      setSyncing(true);
      await api.functions.invoke('disconnectCalendar', {});
      await loadData();
      toast({ title: 'Desconectado', description: 'Google Calendar desconectado correctamente.' });
    } catch (error) {
      console.error('Error disconnecting calendar:', error);
      toast({ title: 'Error', description: 'Error al desconectar el calendario', variant: 'destructive' });
    } finally {
      setSyncing(false);
    }
  };

  const handleSyncCalendar = async () => {
    if (!calendarConnection) {
      toast({ title: 'Sin conexión', description: 'Primero debes conectar tu Google Calendar', variant: 'destructive' });
      return;
    }
    
    try {
      setSyncing(true);
      const { data } = await api.functions.invoke('syncUserGoogleCalendar', {});
      await loadData();
      toast({ title: 'Sincronizado', description: data.message || 'Calendario sincronizado correctamente.' });
    } catch (error) {
      console.error('Error syncing calendar:', error);
      toast({ title: 'Error', description: 'Error al sincronizar el calendario', variant: 'destructive' });
    } finally {
      setSyncing(false);
    }
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const eventsByDate = useMemo(() => {
    const map = {};
    events.forEach(event => {
      const dateKey = format(new Date(event.start_datetime), 'yyyy-MM-dd');
      if (!map[dateKey]) map[dateKey] = [];
      map[dateKey].push(event);
    });
    return map;
  }, [events]);

  const upcomingEvents = useMemo(() => {
    const now = new Date();
    return events
      .filter(e => new Date(e.start_datetime) >= now && e.status === 'programado')
      .slice(0, 5);
  }, [events]);

  const handleEventClick = (event) => {
    setSelectedEvent(event);
    setShowEventDetails(true);
  };

  const handleDateClick = (date) => {
    setSelectedDate(date);
    setShowEventForm(true);
  };

  const handleEventSaved = () => {
    loadData();
    setShowEventForm(false);
    setSelectedDate(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Calendario</h1>
            <p className="text-slate-500 dark:text-zinc-400 mt-1">Gestiona tus actividades y citas</p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {!checkingConnection && (
              <>
                {calendarConnection ? (
                  <>
                    <Button 
                      variant="outline"
                      onClick={handleSyncCalendar}
                      disabled={syncing}
                      className="gap-2"
                    >
                      <RefreshCw className={cn("h-4 w-4", syncing && "animate-spin")} />
                      Sincronizar
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={handleDisconnectCalendar}
                      disabled={syncing}
                      className="gap-2 text-red-600 hover:text-red-700"
                    >
                      Desconectar Google
                    </Button>
                  </>
                ) : (
                  <Button 
                    variant="outline"
                    onClick={handleConnectCalendar}
                    className="gap-2 text-blue-600 hover:text-blue-700"
                  >
                    <CalendarIcon className="h-4 w-4" />
                    Conectar Google Calendar
                  </Button>
                )}
              </>
            )}
            {/* View toggle */}
            <div className="flex items-center border rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('month')}
                className={cn("flex items-center gap-1.5 px-3 py-2 text-sm transition-colors", viewMode === 'month' ? "bg-blue-600 text-white" : "text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800")}
              >
                <Grid3X3 className="h-4 w-4" />
                <span className="hidden sm:inline">Mes</span>
              </button>
              <button
                onClick={() => setViewMode('agenda')}
                className={cn("flex items-center gap-1.5 px-3 py-2 text-sm transition-colors", viewMode === 'agenda' ? "bg-blue-600 text-white" : "text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800")}
              >
                <LayoutList className="h-4 w-4" />
                <span className="hidden sm:inline">Agenda</span>
              </button>
              <button
                onClick={() => setViewMode('slots')}
                className={cn("flex items-center gap-1.5 px-3 py-2 text-sm transition-colors", viewMode === 'slots' ? "bg-blue-600 text-white" : "text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800")}
              >
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">Citas</span>
              </button>
            </div>

            <Button 
              onClick={() => { setSelectedDate(new Date()); setShowEventForm(true); }}
              className="gap-2 bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              Nueva Actividad
            </Button>
          </div>
        </div>

        {/* Agenda View */}
        {viewMode === 'agenda' && (
          <AgendaView
            events={events}
            weekDate={agendaWeekDate}
            onWeekChange={setAgendaWeekDate}
            onEventClick={handleEventClick}
          />
        )}

        {viewMode === 'month' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar View */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">
                    {format(currentDate, 'MMMM yyyy', { locale: es })}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setCurrentDate(new Date())}
                    >
                      Hoy
                    </Button>
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Weekday Headers */}
                <div className="grid grid-cols-7 gap-2 mb-2">
                  {['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map(day => (
                    <div key={day} className="text-center text-sm font-semibold text-slate-600 dark:text-zinc-400 py-2">
                      {day}
                    </div>
                  ))}
                </div>

                {/* Calendar Days */}
                <div className="grid grid-cols-7 gap-2">
                  {calendarDays.map(day => {
                    const dateKey = format(day, 'yyyy-MM-dd');
                    const dayEvents = eventsByDate[dateKey] || [];
                    const isToday = isSameDay(day, new Date());
                    const isCurrentMonth = isSameMonth(day, currentDate);

                    return (
                      <div
                        key={day.toISOString()}
                        onClick={() => handleDateClick(day)}
                        className={cn(
                          "min-h-[100px] p-2 border dark:border-zinc-700 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-zinc-800/60 transition-colors",
                          !isCurrentMonth && "bg-slate-50/50 dark:bg-zinc-900/30 text-slate-400 dark:text-zinc-600",
                          isToday && "border-blue-500 bg-blue-50 dark:bg-blue-900/20"
                        )}
                      >
                        <div className={cn(
                          "text-sm font-medium mb-1",
                          isToday && "text-blue-600"
                        )}>
                          {format(day, 'd')}
                        </div>
                        <div className="space-y-1">
                          {dayEvents.slice(0, 3).map(event => (
                            <div
                              key={event.id}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEventClick(event);
                              }}
                              className={cn(
                                "text-xs p-1 rounded border truncate",
                                eventTypeColors[event.event_type]
                              )}
                            >
                              {format(new Date(event.start_datetime), 'HH:mm')} {event.title}
                            </div>
                          ))}
                          {dayEvents.length > 3 && (
                            <div className="text-xs text-slate-500 pl-1">
                              +{dayEvents.length - 3} más
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Events */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Próximas Actividades</CardTitle>
              </CardHeader>
              <CardContent>
                {upcomingEvents.length > 0 ? (
                  <div className="space-y-3">
                    {upcomingEvents.map(event => (
                      <div
                        key={event.id}
                        onClick={() => handleEventClick(event)}
                        className="p-3 bg-slate-50 dark:bg-zinc-800 rounded-lg border border-transparent dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-700 cursor-pointer transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <p className="font-medium text-slate-900 dark:text-white text-sm">{event.title}</p>
                          <Badge className={cn("text-xs", eventTypeColors[event.event_type])}>
                            {event.event_type}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-zinc-400">
                          <Clock className="h-3 w-3" />
                          <span>
                            {format(new Date(event.start_datetime), "d MMM, HH:mm", { locale: es })}
                          </span>
                        </div>
                        {event.lead_name && (
                          <p className="text-xs text-slate-600 dark:text-zinc-400 mt-1">Lead: {event.lead_name}</p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-400">
                    <CalendarIcon className="h-12 w-12 mx-auto mb-3 text-slate-300" />
                    <p className="text-sm">No hay actividades programadas</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Este Mes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600 dark:text-zinc-400">Total eventos</span>
                    <span className="font-semibold">{events.filter(e => isSameMonth(new Date(e.start_datetime), currentDate)).length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600 dark:text-zinc-400">Programados</span>
                    <span className="font-semibold text-blue-600">
                      {events.filter(e => e.status === 'programado' && isSameMonth(new Date(e.start_datetime), currentDate)).length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600 dark:text-zinc-400">Completados</span>
                    <span className="font-semibold text-green-600">
                      {events.filter(e => e.status === 'completado' && isSameMonth(new Date(e.start_datetime), currentDate)).length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        )}

        {/* Slots Manager View */}
        {viewMode === 'slots' && (
          <div className="max-w-3xl mx-auto">
            <AppointmentProposalsManager currentUser={currentUser} />
          </div>
        )}

        {/* Event Form Modal */}
        <CalendarEventForm
          open={showEventForm}
          onClose={() => { setShowEventForm(false); setSelectedDate(null); }}
          onSaved={handleEventSaved}
          initialDate={selectedDate}
        />

        {/* Event Details Modal */}
        <CalendarEventDetails
          open={showEventDetails}
          onClose={() => { setShowEventDetails(false); setSelectedEvent(null); }}
          event={selectedEvent}
          onEventUpdated={loadData}
        />
      </div>
    </div>
  );
}