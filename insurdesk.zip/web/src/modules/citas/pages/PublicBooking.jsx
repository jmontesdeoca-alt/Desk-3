import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Loader2, Calendar, Clock, User, CheckCircle, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function PublicBooking() {
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('t');

  const [proposal, setProposal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedDatetime, setSelectedDatetime] = useState(null);
  const [step, setStep] = useState('select'); // 'select' | 'confirm' | 'success'
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [form, setForm] = useState({ name: '', phone: '' });
  const [formError, setFormError] = useState(null);

  useEffect(() => {
    if (!token) {
      setError('Enlace inválido. Por favor contacta a tu agente.');
      setLoading(false);
      return;
    }
    loadProposal();
  }, []);

  const loadProposal = async () => {
    try {
      setLoading(true);
      // Use service role via backend to fetch proposal by token (no auth needed)
      const { data } = await api.functions.invoke('getProposalByToken', { token });
      if (data.error) throw new Error(data.error);
      setProposal(data.proposal);
      // Pre-fill name from proposal if exists
      if (data.proposal.client_name) setForm(f => ({ ...f, name: data.proposal.client_name }));
    } catch (err) {
      setError('No se pudo cargar la propuesta. El enlace puede ser inválido o haber expirado.');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async () => {
    setFormError(null);
    setSubmitting(true);
    try {
      const { data } = await api.functions.invoke('confirmAppointment', {
        token,
        selected_datetime: selectedDatetime,
        client_name: form.name.trim() || proposal.client_name || null,
        client_phone: form.phone.trim() || null
      });
      if (data.error) throw new Error(data.error);
      setResult(data);
      setStep('success');
    } catch (err) {
      setFormError(err.message || 'Error al confirmar. Intenta de nuevo.');
    } finally {
      setSubmitting(false);
    }
  };

  // --- LOADING ---
  if (loading) return (
    <div className="min-h-screen bg-ink flex items-center justify-center">
      <div className="text-center text-white">
        <Loader2 className="h-10 w-10 animate-spin mx-auto mb-4" />
        <p className="text-white/70 text-sm">Cargando propuesta...</p>
      </div>
    </div>
  );

  // --- ERROR ---
  if (error || !proposal) return (
    <div className="min-h-screen bg-ink flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-2xl">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">Enlace inválido</h2>
        <p className="text-slate-500 text-sm">{error || 'Propuesta no encontrada.'}</p>
      </div>
    </div>
  );

  // --- ALREADY USED ---
  if (proposal.status === 'confirmed') return (
    <div className="min-h-screen bg-ink flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-2xl">
        <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">Esta cita ya fue confirmada</h2>
        <p className="text-slate-500 text-sm">Este enlace ya fue utilizado. Si necesitas cambios, contacta directamente a <strong>{proposal.agent_name}</strong>.</p>
      </div>
    </div>
  );

  if (proposal.status === 'expired' || (proposal.expires_at && new Date(proposal.expires_at) < new Date())) return (
    <div className="min-h-screen bg-ink flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-2xl">
        <AlertCircle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">Este enlace expiró</h2>
        <p className="text-slate-500 text-sm">Contacta a <strong>{proposal.agent_name}</strong> para recibir una nueva propuesta.</p>
      </div>
    </div>
  );

  // --- SUCCESS ---
  if (step === 'success' && result) {
    const dt = new Date(result.confirmed_datetime);
    const dateStr = format(dt, "EEEE d 'de' MMMM, yyyy", { locale: es });
    const timeStr = format(dt, 'HH:mm');
    return (
      <div className="min-h-screen bg-ink flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
          <div className="bg-ink p-5 text-center">
            <span className="text-xl font-black"><span style={{ color: '#9DB1E3' }}>GA</span><span className="text-white">CRM</span></span>
          </div>
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-9 w-9 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">¡Cita confirmada!</h2>
            <p className="text-slate-500 text-sm mb-6">Revisa tu correo, te enviamos la confirmación.</p>
            <div className="bg-slate-50 rounded-xl p-4 text-left space-y-3">
              <Row icon={<Calendar className="h-4 w-4 text-brand" />} label="Motivo" value={result.title} />
              <Row icon={<Clock className="h-4 w-4 text-brand" />} label="Fecha" value={<span className="capitalize">{dateStr}</span>} />
              <Row icon={<Clock className="h-4 w-4 text-brand" />} label="Hora" value={`${timeStr} (Ecuador)`} />
              <Row icon={<User className="h-4 w-4 text-brand" />} label="Agente" value={result.agent_name} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  const slots = proposal.proposed_slots || [];

  // --- SELECT SLOT ---
  return (
    <div className="min-h-screen bg-ink flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-ink p-5">
          <div className="text-center mb-3">
            <span className="text-xl font-black"><span style={{ color: '#9DB1E3' }}>GA</span><span className="text-white">CRM</span></span>
          </div>
          <p className="text-white/70 text-xs text-center">Propuesta de cita de <strong className="text-white">{proposal.agent_name}</strong></p>
        </div>

        <div className="p-6">
          <div className="text-center mb-5">
            <h1 className="text-lg font-bold text-slate-800">{proposal.title}</h1>
            {proposal.client_name && <p className="text-slate-500 text-sm mt-0.5">Hola, <strong>{proposal.client_name}</strong></p>}
            <p className="text-slate-400 text-sm mt-1">Elige el horario que mejor te convenga:</p>
          </div>

          {/* Slot picker */}
          <div className="space-y-2 mb-5">
            {slots.map((slot, idx) => {
              const dt = new Date(slot.datetime);
              const isPast = dt <= new Date();
              const isSelected = selectedDatetime === slot.datetime;
              return (
                <button
                  key={idx}
                  disabled={isPast}
                  onClick={() => { setSelectedDatetime(slot.datetime); setStep('select'); }}
                  className={`w-full text-left p-3.5 rounded-xl border-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed ${isSelected ? 'border-brand bg-brand/5' : 'border-slate-200 hover:border-brand/50 hover:bg-slate-50'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${isSelected ? 'bg-brand text-white' : 'bg-slate-100 text-slate-500'}`}>
                      {idx + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-800 text-sm capitalize">
                        {format(dt, "EEEE d 'de' MMMM", { locale: es })}
                      </p>
                      <p className="text-brand font-bold text-sm">{format(dt, 'HH:mm')} — {slot.duration_minutes || proposal.duration_minutes || 30} min</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {proposal.description && (
            <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg p-3 mb-4">{proposal.description}</p>
          )}

          {/* Name/phone fields */}
          {!proposal.client_name && (
            <div className="space-y-2 mb-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Tu nombre</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder="Juan Pérez"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Teléfono <span className="text-slate-400 font-normal">(opcional)</span></label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })}
                  placeholder="+593 99 999 9999"
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                />
              </div>
            </div>
          )}

          {formError && (
            <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg p-3 mb-3">
              <AlertCircle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">{formError}</p>
            </div>
          )}

          <button
            onClick={handleConfirm}
            disabled={!selectedDatetime || submitting}
            className="w-full py-3 rounded-xl font-semibold text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            style={{ background: selectedDatetime ? 'linear-gradient(135deg, #0A8FBE, #004B6F)' : undefined, backgroundColor: !selectedDatetime ? '#94a3b8' : undefined }}
          >
            {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Confirmando...</> : 'Confirmar este horario →'}
          </button>
        </div>
      </div>
    </div>
  );
}

function Row({ icon, label, value }) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 flex-shrink-0">{icon}</div>
      <div>
        <p className="text-xs text-slate-400 uppercase font-semibold">{label}</p>
        <p className="text-sm font-semibold text-slate-700">{value}</p>
      </div>
    </div>
  );
}