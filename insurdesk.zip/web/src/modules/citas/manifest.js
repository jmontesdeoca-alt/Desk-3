// Citas y calendario: disponibilidad, reservas públicas, propuestas de cita y Google Calendar.
import { Calendar as CalendarIcon, CalendarClock } from 'lucide-react';
import Calendar from './pages/Calendar';
import AgentAvailability from './pages/AgentAvailability';
import PublicBooking from './pages/PublicBooking';
import PublicAvailabilityBooking from './pages/PublicAvailabilityBooking';

export default {
  id: 'citas',
  name: 'Citas y calendario',
  pages: { Calendar, AgentAvailability },
  // Páginas públicas (sin sesión): ruta → componente
  publicPages: { '/PublicBooking': PublicBooking, '/Booking': PublicAvailabilityBooking },
  nav: [
    { section: 'main', order: 30, name: 'Calendario', icon: CalendarIcon, page: 'Calendar' },
    { section: 'user', order: 10, name: 'Mi Disponibilidad', icon: CalendarClock, page: 'AgentAvailability' },
  ],
};
