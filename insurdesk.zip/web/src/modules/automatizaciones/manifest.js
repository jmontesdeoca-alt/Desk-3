// Automatizaciones: flujos de trabajo y reglas. Parte de lo básico (no se desactiva).
import { Zap } from 'lucide-react';
import Automations from './pages/Automations';
import WorkflowAutomations from './pages/WorkflowAutomations';

export default {
  id: 'automatizaciones',
  name: 'Automatizaciones',
  pages: { Automations, WorkflowAutomations },
  nav: [{ section: 'admin', order: 20, name: 'Automatizaciones', icon: Zap, page: 'WorkflowAutomations' }],
};
