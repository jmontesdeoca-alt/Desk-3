import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit, Mail } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function EmailTemplates() {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    body: '',
    category: 'otro'
  });

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      const data = await api.entities.EmailTemplate.list('-created_date');
      setTemplates(data);
    } catch (error) {
      toast.error('Error al cargar plantillas');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.name || !formData.subject || !formData.body) {
      toast.error('Completa todos los campos requeridos');
      return;
    }

    try {
      if (editingTemplate) {
        await api.entities.EmailTemplate.update(editingTemplate.id, formData);
        toast.success('Plantilla actualizada');
      } else {
        await api.entities.EmailTemplate.create(formData);
        toast.success('Plantilla creada');
      }
      
      setShowDialog(false);
      setEditingTemplate(null);
      setFormData({ name: '', subject: '', body: '', category: 'otro' });
      loadTemplates();
    } catch (error) {
      toast.error('Error al guardar plantilla');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Eliminar esta plantilla?')) return;

    try {
      await api.entities.EmailTemplate.delete(id);
      toast.success('Plantilla eliminada');
      loadTemplates();
    } catch (error) {
      toast.error('Error al eliminar plantilla');
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando plantillas...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Plantillas de Email</h2>
          <p className="text-sm text-slate-600">
            Usa variables: {`{{prospect_name}}, {{company_name}}, {{branch}}, {{agent_name}}`}
          </p>
        </div>
        <Button 
          onClick={() => {
            setEditingTemplate(null);
            setFormData({ name: '', subject: '', body: '', category: 'otro' });
            setShowDialog(true);
          }}
          className="bg-brand hover:bg-brand-dark"
        >
          <Plus className="h-5 w-5 mr-2" />
          Nueva Plantilla
        </Button>
      </div>

      {templates.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Mail className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 mb-4">No hay plantillas de email</p>
            <Button onClick={() => setShowDialog(true)}>
              <Plus className="h-5 w-5 mr-2" />
              Crear primera plantilla
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {templates.map(template => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Mail className="h-5 w-5 text-brand" />
                      {template.name}
                    </CardTitle>
                    <p className="text-sm text-slate-600 mt-1">
                      Asunto: {template.subject}
                    </p>
                  </div>
                  <Badge>{template.category}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm text-slate-700 bg-slate-50 p-3 rounded border max-h-32 overflow-y-auto">
                    {template.body}
                  </div>
                  
                  {template.usage_count > 0 && (
                    <p className="text-xs text-slate-500">
                      Usado {template.usage_count} veces
                    </p>
                  )}

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingTemplate(template);
                        setFormData(template);
                        setShowDialog(true);
                      }}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(template.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Eliminar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Dialog para crear/editar */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingTemplate ? 'Editar Plantilla' : 'Nueva Plantilla'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nombre *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Nombre de la plantilla"
              />
            </div>
            <div>
              <Label>Asunto *</Label>
              <Input
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="Asunto del email"
              />
            </div>
            <div>
              <Label>Cuerpo del Email * (HTML permitido)</Label>
              <Textarea
                value={formData.body}
                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                placeholder="Contenido del email..."
                rows={8}
              />
              <p className="text-xs text-slate-500 mt-1">
                Variables disponibles: {`{{prospect_name}}, {{company_name}}, {{branch}}, {{agent_name}}`}
              </p>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSave} className="bg-brand hover:bg-brand-dark">
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}