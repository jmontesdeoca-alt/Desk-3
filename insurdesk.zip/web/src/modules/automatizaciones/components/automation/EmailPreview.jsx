import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Mail } from "lucide-react";

export default function EmailPreview({ templateId, open, onClose }) {
  const [template, setTemplate] = useState(null);
  const [previewHtml, setPreviewHtml] = useState('');

  useEffect(() => {
    if (open && templateId) {
      loadTemplate();
    }
  }, [open, templateId]);

  const loadTemplate = async () => {
    try {
      const tmpl = await api.entities.EmailTemplate.get(templateId);
      setTemplate(tmpl);

      // Reemplazar variables con ejemplos
      let html = tmpl.body;
      const examples = {
        prospect_name: 'Juan Pérez',
        company_name: 'Seguros ABC',
        branch: 'Vida',
        agent_name: 'María González'
      };

      for (const [key, value] of Object.entries(examples)) {
        html = html.replace(new RegExp(`{{${key}}}`, 'g'), `<span class="bg-yellow-100 px-1 rounded">${value}</span>`);
      }

      setPreviewHtml(html);
    } catch (error) {
      console.error('Error loading template:', error);
    }
  };

  if (!template) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Vista Previa: {template.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Email Header */}
          <div className="bg-slate-50 p-4 rounded-lg border">
            <div className="space-y-2 text-sm">
              <div className="flex gap-2">
                <span className="font-semibold text-slate-600">De:</span>
                <span>noreply@deskcrm.com</span>
              </div>
              <div className="flex gap-2">
                <span className="font-semibold text-slate-600">Para:</span>
                <span>cliente@ejemplo.com</span>
              </div>
              <div className="flex gap-2">
                <span className="font-semibold text-slate-600">Asunto:</span>
                <span>{template.subject.replace(/{{(\w+)}}/g, (_, key) => {
                  const examples = {
                    prospect_name: 'Juan Pérez',
                    company_name: 'Seguros ABC',
                    branch: 'Vida',
                    agent_name: 'María González'
                  };
                  return examples[key] || key;
                })}</span>
              </div>
            </div>
          </div>

          {/* Email Body */}
          <div className="bg-white border rounded-lg p-6">
            <div 
              dangerouslySetInnerHTML={{ __html: previewHtml }}
              className="prose prose-sm max-w-none"
            />
          </div>

          {/* Legend */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <p className="text-xs text-yellow-800">
              💡 Las palabras con <span className="bg-yellow-100 px-1 rounded font-mono">fondo amarillo</span> son variables que se reemplazarán con datos reales del lead
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}