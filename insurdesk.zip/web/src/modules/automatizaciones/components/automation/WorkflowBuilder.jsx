import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, Trash2, Save, Zap, Filter, GitBranch, Mail, Target, UserCheck, Clock, FileText, Webhook, GripVertical, Eye, ZoomIn, ZoomOut, GitMerge, Shuffle, Tag, ChevronDown, ChevronRight, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import EmailPreview from './EmailPreview';
import RoundRobinConfig from './RoundRobinConfig';

const ACTION_ICONS = {
  send_email: Mail,
  change_stage: Target,
  assign_agent: UserCheck,
  assign_agent_roundrobin: Shuffle,
  create_task: Clock,
  create_note: FileText,
  create_lead: Plus,
  clone_to_pipeline: GitMerge,
  add_tag: Tag,
  webhook: Webhook,
  wait: Clock,
  send_meta_conversion: TrendingUp
};

const ACTION_LABELS = {
  send_email: 'Enviar email',
  change_stage: 'Cambiar etapa',
  assign_agent: 'Asignar agente (fijo)',
  assign_agent_roundrobin: 'Asignación secuencial',
  create_task: 'Crear tarea',
  create_note: 'Crear nota',
  create_lead: 'Crear lead desde prospecto',
  clone_to_pipeline: 'Clonar a pipeline',
  add_tag: 'Asignar etiqueta',
  webhook: 'Webhook',
  wait: 'Esperar tiempo',
  send_meta_conversion: 'Enviar conversión a Meta'
};

export default function WorkflowBuilder({ workflow, onClose }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    triggers: [{ trigger_type: 'lead_created', trigger_config: {} }],
    trigger_type: 'lead_created',
    trigger_config: {},
    conditions: [],
    actions_if_true: [],
    actions_if_false: [],
    is_active: true
  });

  const [selectedElement, setSelectedElement] = useState(null);
  const [showPanel, setShowPanel] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [showEmailPreview, setShowEmailPreview] = useState(false);
  const [previewTemplateId, setPreviewTemplateId] = useState(null);
  const [agents, setAgents] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [webForms, setWebForms] = useState([]);

  useEffect(() => {
    if (workflow) {
      setFormData({
        ...workflow,
        triggers: workflow.triggers?.length ? workflow.triggers : [{ trigger_type: workflow.trigger_type || 'lead_created', trigger_config: workflow.trigger_config || {} }],
        actions_if_true: workflow.actions || [],
        actions_if_false: workflow.actions_if_false || []
      });
    }
    loadData();
  }, [workflow]);

  const loadData = async () => {
    try {
      const [agentsRes, pipelinesData, formsData] = await Promise.all([
        api.functions.invoke('listAgents'),
        api.entities.Pipeline.list(),
        api.entities.WebForm.list().catch(() => [])
      ]);
      setAgents(agentsRes.data?.agents || []);
      setPipelines(pipelinesData.filter(p => p.is_active !== false));
      setWebForms(formsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleSave = async () => {
    if (!formData.name) {
      toast.error('El nombre es requerido');
      return;
    }
    try {
      const user = await api.auth.me();
      const saveData = {
        ...formData,
        triggers: formData.triggers,
        trigger_type: formData.triggers?.[0]?.trigger_type || formData.trigger_type,
        trigger_config: formData.triggers?.[0]?.trigger_config || formData.trigger_config,
        actions: formData.actions_if_true
      };
      if (workflow) {
        await api.entities.WorkflowAutomation.update(workflow.id, { ...saveData, version: (workflow.version || 1) + 1 });
        toast.success('Workflow actualizado');
      } else {
        await api.entities.WorkflowAutomation.create({ ...saveData, created_by_name: user.full_name });
        toast.success('Workflow creado');
      }
      onClose();
    } catch (error) {
      toast.error('Error al guardar workflow');
      console.error(error);
    }
  };

  const openPanel = (type, data, index) => {
    setSelectedElement({ type, data, index });
    setShowPanel(true);
  };

  const addAction = (branch) => {
    const newAction = { type: 'send_email', config: {}, sub_conditions: [], sub_actions_if_true: [], sub_actions_if_false: [] };
    if (branch === 'true') {
      setFormData({ ...formData, actions_if_true: [...formData.actions_if_true, newAction] });
    } else {
      setFormData({ ...formData, actions_if_false: [...formData.actions_if_false, newAction] });
    }
  };

  const removeAction = (branch, index) => {
    if (branch === 'true') {
      setFormData({ ...formData, actions_if_true: formData.actions_if_true.filter((_, i) => i !== index) });
    } else {
      setFormData({ ...formData, actions_if_false: formData.actions_if_false.filter((_, i) => i !== index) });
    }
  };

  const handleDragEnd = (result, branch) => {
    if (!result.destination) return;
    const actions = branch === 'true' ? [...formData.actions_if_true] : [...formData.actions_if_false];
    const [removed] = actions.splice(result.source.index, 1);
    actions.splice(result.destination.index, 0, removed);
    if (branch === 'true') {
      setFormData({ ...formData, actions_if_true: actions });
    } else {
      setFormData({ ...formData, actions_if_false: actions });
    }
  };

  const getTriggerLabel = (type) => {
    const labels = {
      prospect_created: 'Prospecto creado',
      lead_created: 'Lead creado',
      lead_stage_changed: 'Cambio de etapa',
      lead_inactive: 'Lead inactivo',
      email_clicked: 'Clic en email',
      tag_added: 'Tag agregado',
      tag_removed: 'Tag eliminado',
      form_submitted: 'Formulario enviado',
      manual: 'Manual'
    };
    return labels[type] || type;
  };

  const renderActionCard = (action, index, branch, provided, snapshot) => {
    const Icon = ACTION_ICONS[action.type] || Zap;
    const hasSubConditions = action.sub_conditions?.length > 0;

    return (
      <Card
        ref={provided.innerRef}
        {...provided.draggableProps}
        className={cn("cursor-pointer hover:shadow-lg transition-all bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700", snapshot.isDragging && "shadow-2xl rotate-2")}
        onClick={() => openPanel('action', action, { branch, index })}
      >
        <CardContent className="pt-4">
          <div className="flex items-center gap-3">
            <div {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing">
              <GripVertical className="h-5 w-5 text-slate-400 dark:text-zinc-500" />
            </div>
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${branch === 'true' ? 'bg-brand/10' : 'bg-slate-100 dark:bg-zinc-700'}`}>
              <Icon className={`h-5 w-5 ${branch === 'true' ? 'text-brand' : 'text-slate-500 dark:text-zinc-300'}`} />
            </div>
            <div className="flex-1">
              <span className="font-semibold capitalize text-slate-800 dark:text-white text-sm">
                {ACTION_LABELS[action.type] || action.type.replace(/_/g, ' ')}
              </span>
              {action.type === 'wait' && action.config.wait_amount && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">⏱️ {action.config.wait_amount} {action.config.wait_type}</p>
              )}
              {action.type === 'add_tag' && action.config.tag_name && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">🏷️ {action.config.tag_name}</p>
              )}
              {action.type === 'change_stage' && action.config.new_stage && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">→ Etapa: {action.config.new_stage}</p>
              )}
              {action.type === 'assign_agent' && action.config.agent_name && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">👤 {action.config.agent_name}</p>
              )}
              {action.type === 'assign_agent_roundrobin' && action.config.agents?.length > 0 && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">🔁 {action.config.agents.length} agente(s) en rotación</p>
              )}
              {action.type === 'send_email' && action.config.template_id && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">📧 Plantilla: {action.config.template_id.substring(0, 12)}...</p>
              )}
              {action.type === 'create_lead' && (action.config.pipeline_name || action.config.branch) && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  {action.config.branch && `${action.config.branch}`}{action.config.pipeline_name && ` → ${action.config.pipeline_name}`}
                  {action.config.assigned_agent_name && ` · ${action.config.assigned_agent_name}`}
                </p>
              )}
              {action.type === 'clone_to_pipeline' && action.config.target_pipeline_name && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">🔀 → {action.config.target_pipeline_name}</p>
              )}
              {action.type === 'create_task' && action.config.task_type && (
                <p className="text-xs text-slate-500 dark:text-zinc-400">📋 {action.config.task_type}</p>
              )}
              {action.type === 'webhook' && action.config.url && (
                <p className="text-xs text-slate-500 dark:text-zinc-400 truncate max-w-[160px]">🔗 {action.config.url}</p>
              )}
              {hasSubConditions && (
                <Badge className="mt-1 text-xs bg-purple-100 text-purple-700 border-purple-200">
                  + {action.sub_conditions.length} sub-condición(es)
                </Badge>
              )}
            </div>
            {action.type === 'send_email' && action.config.template_id && (
              <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); setPreviewTemplateId(action.config.template_id); setShowEmailPreview(true); }}>
                <Eye className="h-4 w-4" />
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); removeAction(branch, index); }}>
              <Trash2 className="h-4 w-4 text-red-600" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderBranch = (branch, branchLabel, color) => {
    const actions = branch === 'true' ? formData.actions_if_true : formData.actions_if_false;
    const borderColor = branch === 'true' ? 'border-green-300' : 'border-red-300';
    const hoverColor = branch === 'true' ? 'hover:border-green-500 hover:bg-green-50' : 'hover:border-red-500 hover:bg-red-50';
    const dragOverBg = branch === 'true' ? 'bg-green-50 dark:bg-green-900/20 border-green-300' : 'bg-red-50 dark:bg-red-900/20 border-red-300';

    return (
      <div className="space-y-4">
        <div className="text-center">
          <div className={`inline-flex items-center gap-2 ${color} text-white px-6 py-3 rounded-xl font-bold shadow-lg`}>
            <span className="text-xl">{branch === 'true' ? '✓' : '✗'}</span>
            {branchLabel}
          </div>
        </div>
        <DragDropContext onDragEnd={(result) => handleDragEnd(result, branch)}>
          <Droppable droppableId={`actions-${branch}`}>
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={cn("space-y-3 min-h-[200px] p-4 rounded-xl border-2 border-dashed transition-colors", snapshot.isDraggingOver ? dragOverBg : "bg-slate-50 dark:bg-zinc-900 border-slate-200 dark:border-zinc-700")}
              >
                {actions.map((action, index) => (
                  <Draggable key={`${branch}-${index}`} draggableId={`${branch}-${index}`} index={index}>
                    {(provided, snapshot) => renderActionCard(action, index, branch, provided, snapshot)}
                  </Draggable>
                ))}
                {provided.placeholder}
                {actions.length === 0 && (
                  <div className="text-center py-12 text-slate-400">
                    <Mail className="h-12 w-12 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">Arrastra acciones aquí o haz clic abajo</p>
                  </div>
                )}
              </div>
            )}
          </Droppable>
        </DragDropContext>
        <Button variant="outline" className={`w-full border-dashed border-2 ${hoverColor}`} onClick={() => addAction(branch)}>
          <Plus className="h-4 w-4 mr-2" />
          Agregar acción
        </Button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white dark:bg-zinc-900 border-b dark:border-zinc-700 shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onClose} size="sm"><ArrowLeft className="h-4 w-4" /></Button>
            <div className="flex-1">
              <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Nombre del workflow..." className="text-xl font-bold border-none shadow-none p-0 h-auto" />
              <Input value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="Descripción..." className="text-sm text-slate-600 border-none shadow-none p-0 h-auto mt-1" />
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-100 dark:bg-zinc-800 rounded-lg">
              <Button variant="ghost" size="sm" onClick={() => setZoom(Math.max(50, zoom - 10))} disabled={zoom <= 50}><ZoomOut className="h-4 w-4" /></Button>
              <span className="text-sm font-medium w-12 text-center">{zoom}%</span>
              <Button variant="ghost" size="sm" onClick={() => setZoom(Math.min(150, zoom + 10))} disabled={zoom >= 150}><ZoomIn className="h-4 w-4" /></Button>
            </div>
            <Button onClick={handleSave} className="bg-brand hover:bg-brand-dark">
              <Save className="h-5 w-5 mr-2" />Guardar
            </Button>
          </div>
        </div>
      </div>

      {/* Canvas */}
      <div className="container mx-auto px-6 py-8">
        <div style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top center', transition: 'transform 0.2s ease' }} className="space-y-6">
          {/* Triggers */}
          <div className="space-y-2">
            <p className="text-xs text-slate-500 dark:text-zinc-400 uppercase font-semibold tracking-wide text-center">Disparadores</p>
            <div className="flex flex-wrap gap-3 justify-center items-start">
              {formData.triggers.map((trigger, idx) => (
                <Card key={idx} className="cursor-pointer hover:shadow-lg transition-all border-2 border-brand bg-brand-soft w-56" onClick={() => openPanel('trigger', trigger, idx)}>
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-lg bg-brand flex items-center justify-center shadow flex-shrink-0">
                        <Zap className="h-4 w-4 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-slate-500 dark:text-zinc-400 font-semibold uppercase">Disparador</p>
                        <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5 leading-tight">{getTriggerLabel(trigger.trigger_type)}</p>
                        {trigger.trigger_config?.days && <p className="text-xs text-slate-500 mt-0.5">{trigger.trigger_config.days} días inactivo</p>}
                        {trigger.trigger_type === 'form_submitted' && trigger.trigger_config?.form_name && (
                          <p className="text-xs text-slate-500 mt-0.5">📋 {trigger.trigger_config.form_name}</p>
                        )}
                      </div>
                      {formData.triggers.length > 1 && (
                        <button onClick={(e) => { e.stopPropagation(); setFormData({ ...formData, triggers: formData.triggers.filter((_, i) => i !== idx) }); }} className="text-slate-400 hover:text-red-500 transition-colors">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
              <button onClick={() => setFormData({ ...formData, triggers: [...formData.triggers, { trigger_type: 'lead_created', trigger_config: {} }] })} className="w-56 h-[88px] border-2 border-dashed border-brand/40 rounded-lg flex items-center justify-center gap-2 text-brand hover:border-brand hover:bg-brand/5 transition-all text-sm font-medium">
                <Plus className="h-4 w-4" />Añadir disparador
              </button>
            </div>
          </div>

          <div className="flex justify-center">
            <div className="w-1 h-16 bg-slate-300 rounded-full"></div>
          </div>

          {/* Conditions */}
          <Card className="cursor-pointer hover:shadow-lg transition-all border-2 border-amber-500 bg-amber-50 dark:bg-amber-500/5" onClick={() => openPanel('conditions', formData.conditions, null)}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-amber-500 flex items-center justify-center shadow-lg">
                  <Filter className="h-7 w-7 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-slate-500 dark:text-zinc-400 uppercase font-semibold tracking-wide">Condiciones</p>
                  <p className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                    {formData.conditions.length === 0 ? 'Sin condiciones (siempre ejecuta)' : `${formData.conditions.length} condición(es) configuradas`}
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); setFormData({ ...formData, conditions: [...formData.conditions, { field: 'pipeline_stage', operator: 'equals', value: '', logic: 'AND' }] }); }}>
                  <Plus className="h-4 w-4 mr-1" />Agregar
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center items-center py-4">
            <div className="relative">
              <GitBranch className="h-16 w-16 text-slate-400" />
              {formData.conditions.length > 0 && (
                <div className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full font-semibold">SI/NO</div>
              )}
            </div>
          </div>

          {/* Branches */}
          <div className="grid md:grid-cols-2 gap-8">
            {renderBranch('true', 'SI - Condiciones cumplidas', 'bg-green-500')}
            {renderBranch('false', 'NO - Condiciones no cumplidas', 'bg-red-500')}
          </div>
        </div>
      </div>

      {/* Side Panel */}
      <Sheet open={showPanel} onOpenChange={setShowPanel}>
        <SheetContent className="w-[420px] sm:w-[560px] overflow-y-auto">
          {selectedElement && (
            <ConfigPanel
              element={selectedElement}
              formData={formData}
              setFormData={setFormData}
              agents={agents}
              pipelines={pipelines}
              webForms={webForms}
              onClose={() => setShowPanel(false)}
            />
          )}
        </SheetContent>
      </Sheet>

      <EmailPreview templateId={previewTemplateId} open={showEmailPreview} onClose={() => setShowEmailPreview(false)} />
    </div>
  );
}

// ─── Condition Editor (reutilizable para condiciones principales y sub-condiciones) ───
function ConditionEditor({ conditions, onChange, pipelines, webForms, context = 'lead' }) {
  const FIELD_OPTIONS = [
    { value: 'pipeline_stage', label: '📊 Etapa del pipeline', contexts: ['lead'] },
    { value: 'branch', label: '🏢 Ramo de seguro', contexts: ['lead', 'prospect'] },
    { value: 'premium_estimated', label: '💰 Prima estimada', contexts: ['lead'] },
    { value: 'lead_status', label: '📌 Estado del lead', contexts: ['lead'] },
    { value: 'tags', label: '🏷️ Tags', contexts: ['lead', 'prospect'] },
    { value: 'source', label: '📡 Fuente de origen', contexts: ['prospect'] },
    { value: 'source_form_id', label: '📋 Formulario de origen', contexts: ['lead', 'prospect'] },
    { value: 'assigned_agent_id', label: '👤 Agente asignado', contexts: ['lead', 'prospect'] },
    { value: 'pipeline_id', label: '🗂️ Pipeline', contexts: ['lead'] },
  ];

  const updateCondition = (idx, field, value) => {
    const updated = [...conditions];
    updated[idx] = { ...updated[idx], [field]: value };
    onChange(updated);
  };

  const removeCondition = (idx) => onChange(conditions.filter((_, i) => i !== idx));

  const addCondition = () => onChange([...conditions, { field: 'tags', operator: 'has_tag', value: '', logic: 'AND' }]);

  return (
    <div className="space-y-3">
      {conditions.map((condition, idx) => (
        <Card key={idx} className="border-2">
          <CardContent className="pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-bold">Condición {idx + 1}</Label>
              <Button variant="ghost" size="sm" onClick={() => removeCondition(idx)}>
                <Trash2 className="h-4 w-4 text-red-600" />
              </Button>
            </div>

            <div>
              <Label className="text-xs">Campo a evaluar</Label>
              <Select value={condition.field} onValueChange={(v) => updateCondition(idx, 'field', v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FIELD_OPTIONS.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs">Operador</Label>
              <Select value={condition.operator} onValueChange={(v) => updateCondition(idx, 'operator', v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="equals">= Igual a</SelectItem>
                  <SelectItem value="not_equals">≠ Diferente de</SelectItem>
                  <SelectItem value="greater_than">&gt; Mayor que</SelectItem>
                  <SelectItem value="less_than">&lt; Menor que</SelectItem>
                  <SelectItem value="contains">📝 Contiene</SelectItem>
                  <SelectItem value="has_tag">🏷️ Tiene el tag</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs">Valor</Label>
              {condition.field === 'source_form_id' && webForms.length > 0 ? (
                <Select value={condition.value} onValueChange={(v) => updateCondition(idx, 'value', v)}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Seleccionar formulario" /></SelectTrigger>
                  <SelectContent>
                    {webForms.map(f => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : condition.field === 'source' ? (
                <Select value={condition.value} onValueChange={(v) => updateCondition(idx, 'value', v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="meta">Meta (Facebook/Instagram)</SelectItem>
                    <SelectItem value="manual">Manual</SelectItem>
                    <SelectItem value="web">Formulario Web</SelectItem>
                    <SelectItem value="referido">Referido</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  value={condition.value}
                  onChange={(e) => updateCondition(idx, 'value', e.target.value)}
                  placeholder={condition.operator === 'has_tag' ? 'Ej: META, VIP' : 'Valor a comparar'}
                  className="mt-1"
                />
              )}
            </div>

            {idx < conditions.length - 1 && (
              <div>
                <Label className="text-xs">Lógica con siguiente condición</Label>
                <Select value={condition.logic} onValueChange={(v) => updateCondition(idx, 'logic', v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AND">Y (AND) - Ambas deben cumplirse</SelectItem>
                    <SelectItem value="OR">O (OR) - Cualquiera puede cumplirse</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
      <Button variant="outline" className="w-full border-dashed border-2" onClick={addCondition}>
        <Plus className="h-4 w-4 mr-2" />Agregar condición
      </Button>
    </div>
  );
}

// ─── Panel de configuración lateral ───
function ConfigPanel({ element, formData, setFormData, agents, pipelines, webForms, onClose }) {
  const { type, data, index } = element;
  const [localAction, setLocalAction] = useState(data);
  const [showSubConditions, setShowSubConditions] = useState(false);

  useEffect(() => {
    setLocalAction(data);
  }, [data]);

  const updateAction = (branch, actionIndex, field, value) => {
    const actions = branch === 'true' ? [...formData.actions_if_true] : [...formData.actions_if_false];
    actions[actionIndex].config = { ...actions[actionIndex].config, [field]: value };
    if (branch === 'true') {
      setFormData({ ...formData, actions_if_true: actions });
    } else {
      setFormData({ ...formData, actions_if_false: actions });
    }
  };

  const updateActionType = (branch, actionIndex, newType) => {
    const actions = branch === 'true' ? [...formData.actions_if_true] : [...formData.actions_if_false];
    const newAction = { type: newType, config: {}, sub_conditions: actions[actionIndex].sub_conditions || [], sub_actions_if_true: actions[actionIndex].sub_actions_if_true || [], sub_actions_if_false: actions[actionIndex].sub_actions_if_false || [] };
    actions[actionIndex] = newAction;
    if (branch === 'true') {
      setFormData({ ...formData, actions_if_true: actions });
    } else {
      setFormData({ ...formData, actions_if_false: actions });
    }
    setLocalAction(newAction);
  };

  const updateActionField = (branch, actionIndex, field, value) => {
    const actions = branch === 'true' ? [...formData.actions_if_true] : [...formData.actions_if_false];
    actions[actionIndex][field] = value;
    if (branch === 'true') {
      setFormData({ ...formData, actions_if_true: actions });
    } else {
      setFormData({ ...formData, actions_if_false: actions });
    }
    setLocalAction({ ...localAction, [field]: value });
  };

  // ── TRIGGER ──
  if (type === 'trigger') {
    const triggerIdx = index;
    const trigger = formData.triggers?.[triggerIdx] || {};

    const updateTrigger = (field, value) => {
      const newTriggers = [...(formData.triggers || [])];
      newTriggers[triggerIdx] = { ...newTriggers[triggerIdx], [field]: value };
      setFormData({ ...formData, triggers: newTriggers });
    };

    const updateTriggerConfig = (field, value) => {
      const newTriggers = [...(formData.triggers || [])];
      newTriggers[triggerIdx] = { ...newTriggers[triggerIdx], trigger_config: { ...(newTriggers[triggerIdx].trigger_config || {}), [field]: value } };
      setFormData({ ...formData, triggers: newTriggers });
    };

    return (
      <>
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2"><Zap className="h-5 w-5 text-brand" />Configurar Disparador {formData.triggers?.length > 1 ? `#${triggerIdx + 1}` : ''}</SheetTitle>
        </SheetHeader>
        <div className="space-y-6 mt-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">💡 El disparador define <strong>cuándo</strong> se ejecutará este workflow automáticamente</p>
          </div>
          <div>
            <Label className="text-base font-semibold">¿Cuándo se ejecuta?</Label>
            <Select value={trigger.trigger_type || 'lead_created'} onValueChange={(value) => updateTrigger('trigger_type', value)}>
              <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="prospect_created">👤 Cuando se crea un prospecto</SelectItem>
                <SelectItem value="lead_created">🆕 Cuando se crea un lead</SelectItem>
                <SelectItem value="lead_stage_changed">🔄 Cuando cambia la etapa</SelectItem>
                <SelectItem value="lead_inactive">💤 Lead inactivo por X días</SelectItem>
                <SelectItem value="email_clicked">📧 Clic en enlace de email</SelectItem>
                <SelectItem value="tag_added">🏷️ Tag agregado al lead</SelectItem>
                <SelectItem value="form_submitted">📋 Formulario web enviado</SelectItem>
                <SelectItem value="manual">👤 Ejecución manual</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {trigger.trigger_type === 'lead_inactive' && (
            <div>
              <Label>Días de inactividad</Label>
              <Input type="number" value={trigger.trigger_config?.days || 7} onChange={(e) => updateTriggerConfig('days', parseInt(e.target.value))} min="1" />
            </div>
          )}

          {trigger.trigger_type === 'lead_stage_changed' && (
            <div className="space-y-4">
              <div>
                <Label>Pipeline específico (opcional)</Label>
                <Select value={trigger.trigger_config?.pipeline_id || 'any'} onValueChange={(value) => updateTriggerConfig('pipeline_id', value === 'any' ? '' : value)}>
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Cualquier pipeline</SelectItem>
                    {pipelines.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Etapa específica (opcional)</Label>
                <Select value={trigger.trigger_config?.stage || 'any'} onValueChange={(value) => updateTriggerConfig('stage', value)}>
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Cualquier etapa</SelectItem>
                    {(trigger.trigger_config?.pipeline_id
                      ? (pipelines.find(p => p.id === trigger.trigger_config.pipeline_id)?.stages || [])
                      : pipelines.flatMap(p => p.stages || []).filter((s, i, arr) => arr.findIndex(x => x.key === s.key) === i)
                    ).map(s => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {trigger.trigger_type === 'form_submitted' && (
            <div>
              <Label>Formulario específico (opcional)</Label>
              <Select value={trigger.trigger_config?.form_id || 'any'} onValueChange={(value) => {
                const form = webForms.find(f => f.id === value);
                updateTriggerConfig('form_id', value === 'any' ? '' : value);
                updateTriggerConfig('form_name', form?.name || '');
              }}>
                <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Cualquier formulario</SelectItem>
                  {webForms.map(f => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 mt-1">Si se deja en "cualquier", se ejecutará con todos los formularios</p>
            </div>
          )}

          {trigger.trigger_type === 'tag_added' && (
            <div>
              <Label>Tag específico (opcional)</Label>
              <Input value={trigger.trigger_config?.tag || ''} onChange={(e) => updateTriggerConfig('tag', e.target.value.toUpperCase())} placeholder="Ej: META, GOOGLE, VIP" />
            </div>
          )}
        </div>
      </>
    );
  }

  // ── CONDITIONS ──
  if (type === 'conditions') {
    return (
      <>
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2"><Filter className="h-5 w-5 text-amber-500" />Configurar Condiciones</SheetTitle>
        </SheetHeader>
        <div className="space-y-4 mt-6">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-sm text-amber-800">🎯 Las condiciones determinan qué acciones ejecutar (branch SI o NO)</p>
          </div>
          <ConditionEditor
            conditions={formData.conditions}
            onChange={(newConditions) => setFormData({ ...formData, conditions: newConditions })}
            pipelines={pipelines}
            webForms={webForms}
          />
        </div>
      </>
    );
  }

  // ── ACTION ──
  if (type === 'action') {
    const { branch, index: actionIndex } = index;

    return (
      <>
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            {ACTION_ICONS[localAction.type] && React.createElement(ACTION_ICONS[localAction.type], { className: "h-5 w-5 text-brand" })}
            Configurar Acción
          </SheetTitle>
        </SheetHeader>
        <div className="space-y-4 mt-6">
          <div>
            <Label>Tipo de acción</Label>
            <Select value={localAction.type} onValueChange={(value) => updateActionType(branch, actionIndex, value)}>
              <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="send_email">📧 Enviar email</SelectItem>
                <SelectItem value="change_stage">🔄 Cambiar etapa</SelectItem>
                <SelectItem value="clone_to_pipeline">🔀 Clonar lead a otro Pipeline</SelectItem>
                <SelectItem value="assign_agent">👤 Asignar agente (fijo)</SelectItem>
                <SelectItem value="assign_agent_roundrobin">🔁 Asignación secuencial (Round-Robin)</SelectItem>
                <SelectItem value="create_task">📋 Crear tarea</SelectItem>
                <SelectItem value="create_note">📝 Crear nota</SelectItem>
                <SelectItem value="create_lead">➕ Crear lead desde prospecto</SelectItem>
                <SelectItem value="add_tag">🏷️ Asignar etiqueta</SelectItem>
                <SelectItem value="wait">⏱️ Esperar tiempo</SelectItem>
                <SelectItem value="webhook">🔗 Webhook</SelectItem>
                <SelectItem value="send_meta_conversion">📈 Enviar conversión a Meta (CAPI)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* ── Configuraciones por tipo ── */}
          {localAction.type === 'send_email' && (
            <>
              <div>
                <Label>ID de plantilla de email</Label>
                <Input value={localAction.config.template_id || ''} onChange={(e) => updateAction(branch, actionIndex, 'template_id', e.target.value)} placeholder="ID de la plantilla" className="mt-2" />
                <p className="text-xs text-slate-500 mt-1">Ve a "Plantillas Email" para crear plantillas</p>
              </div>
              <div>
                <Label>Email destino (opcional)</Label>
                <Input value={localAction.config.to_email || ''} onChange={(e) => updateAction(branch, actionIndex, 'to_email', e.target.value)} placeholder="Deja vacío para usar email del prospecto" className="mt-2" />
              </div>
            </>
          )}

          {localAction.type === 'change_stage' && (
            <div>
              <Label>Nueva etapa</Label>
              <Select value={localAction.config.new_stage || ''} onValueChange={(v) => updateAction(branch, actionIndex, 'new_stage', v)}>
                <SelectTrigger className="mt-2"><SelectValue placeholder="Seleccionar etapa" /></SelectTrigger>
                <SelectContent>
                  {pipelines.flatMap(p => p.stages || []).filter((s, i, arr) => arr.findIndex(x => x.key === s.key) === i).map(s => (
                    <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {localAction.type === 'assign_agent' && (
            <div>
              <Label>Agente a asignar</Label>
              <Select value={localAction.config.agent_id || ''} onValueChange={(v) => {
                const agent = agents.find(a => a.id === v);
                updateAction(branch, actionIndex, 'agent_id', v);
                updateAction(branch, actionIndex, 'agent_name', agent?.full_name || '');
              }}>
                <SelectTrigger className="mt-2"><SelectValue placeholder="Seleccionar agente" /></SelectTrigger>
                <SelectContent>
                  {agents.map(agent => <SelectItem key={agent.id} value={agent.id}>{agent.full_name} ({agent.email})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}

          {localAction.type === 'assign_agent_roundrobin' && (
            <RoundRobinConfig agents={agents} selectedAgents={localAction.config.agents || []} onChange={(newAgents) => updateAction(branch, actionIndex, 'agents', newAgents)} />
          )}

          {localAction.type === 'create_task' && (
            <>
              <div>
                <Label>Descripción de la tarea</Label>
                <Textarea value={localAction.config.description || ''} onChange={(e) => updateAction(branch, actionIndex, 'description', e.target.value)} placeholder="¿Qué debe hacer el agente?" rows={4} className="mt-2" />
              </div>
              <div>
                <Label>Tipo de tarea</Label>
                <Select value={localAction.config.task_type || 'seguimiento'} onValueChange={(v) => updateAction(branch, actionIndex, 'task_type', v)}>
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="seguimiento">Seguimiento</SelectItem>
                    <SelectItem value="llamada">Llamada</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="reunion">Reunión</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {localAction.type === 'create_note' && (
            <div>
              <Label>Texto de la nota</Label>
              <Textarea value={localAction.config.note_text || ''} onChange={(e) => updateAction(branch, actionIndex, 'note_text', e.target.value)} placeholder="Nota interna que se agregará al lead/prospecto" rows={4} className="mt-2" />
            </div>
          )}

          {localAction.type === 'add_tag' && (
            <>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-sm text-purple-800">🏷️ Se asignará esta etiqueta al lead o prospecto cuando se ejecute la acción.</p>
              </div>
              <div>
                <Label>Nombre de la etiqueta</Label>
                <Input value={localAction.config.tag_name || ''} onChange={(e) => updateAction(branch, actionIndex, 'tag_name', e.target.value)} placeholder="Ej: META, VIP, CALIFICADO" className="mt-2" />
                <p className="text-xs text-slate-500 mt-1">Si la etiqueta no existe, se creará automáticamente</p>
              </div>
              <div>
                <Label>Color de la etiqueta (hex)</Label>
                <Input value={localAction.config.tag_color || '#2F4F9D'} onChange={(e) => updateAction(branch, actionIndex, 'tag_color', e.target.value)} placeholder="#2F4F9D" className="mt-2" />
              </div>
            </>
          )}

          {localAction.type === 'create_lead' && (
            <>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">💡 Esta acción crea un Lead automáticamente desde el Prospecto. Útil con el trigger "Prospecto creado" o "Formulario enviado".</p>
              </div>
              <div>
                <Label>Pipeline destino</Label>
                <Select value={localAction.config.pipeline_id || ''} onValueChange={(v) => {
                  const pipeline = pipelines.find(p => p.id === v);
                  updateAction(branch, actionIndex, 'pipeline_id', v);
                  updateAction(branch, actionIndex, 'pipeline_name', pipeline?.name || '');
                  const firstStage = pipeline?.stages?.[0];
                  if (firstStage) updateAction(branch, actionIndex, 'pipeline_stage', firstStage.key);
                }}>
                  <SelectTrigger className="mt-2"><SelectValue placeholder="Seleccionar pipeline" /></SelectTrigger>
                  <SelectContent>
                    {pipelines.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Ramo de seguro</Label>
                <Select value={localAction.config.branch || ''} onValueChange={(v) => updateAction(branch, actionIndex, 'branch', v)}>
                  <SelectTrigger className="mt-2"><SelectValue placeholder="Seleccionar ramo" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Vida">Vida</SelectItem>
                    <SelectItem value="Salud">Salud</SelectItem>
                    <SelectItem value="Viaje">Viaje</SelectItem>
                    <SelectItem value="Inversiones">Inversiones</SelectItem>
                    <SelectItem value="General">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Asignar a agente</Label>
                <Select value={localAction.config.assigned_agent_id || ''} onValueChange={(v) => {
                  const agent = agents.find(a => a.id === v);
                  updateAction(branch, actionIndex, 'assigned_agent_id', v);
                  updateAction(branch, actionIndex, 'assigned_agent_name', agent?.full_name || '');
                }}>
                  <SelectTrigger className="mt-2"><SelectValue placeholder="Seleccionar agente" /></SelectTrigger>
                  <SelectContent>
                    {agents.map(agent => <SelectItem key={agent.id} value={agent.id}>{agent.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Prima estimada (USD)</Label>
                <Input type="number" value={localAction.config.premium_estimated || 0} onChange={(e) => updateAction(branch, actionIndex, 'premium_estimated', parseFloat(e.target.value))} min="0" className="mt-2" />
              </div>
            </>
          )}

          {localAction.type === 'clone_to_pipeline' && (
            <>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-sm text-purple-800">🔀 Clona el lead actual a otro pipeline. El lead original no se modifica.</p>
              </div>
              <div>
                <Label>Pipeline destino</Label>
                <Select value={localAction.config.target_pipeline_id || ''} onValueChange={(v) => {
                  const pipeline = pipelines.find(p => p.id === v);
                  updateAction(branch, actionIndex, 'target_pipeline_id', v);
                  updateAction(branch, actionIndex, 'target_pipeline_name', pipeline?.name || '');
                  const firstStage = pipeline?.stages?.[0];
                  if (firstStage) updateAction(branch, actionIndex, 'target_stage', firstStage.key);
                }}>
                  <SelectTrigger className="mt-2"><SelectValue placeholder="Seleccionar pipeline destino" /></SelectTrigger>
                  <SelectContent>
                    {pipelines.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {localAction.config.target_pipeline_id && (() => {
                const stages = pipelines.find(p => p.id === localAction.config.target_pipeline_id)?.stages || [];
                return stages.length > 0 ? (
                  <div>
                    <Label>Etapa inicial</Label>
                    <Select value={localAction.config.target_stage || stages[0]?.key || ''} onValueChange={(v) => updateAction(branch, actionIndex, 'target_stage', v)}>
                      <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                      <SelectContent>{stages.map(s => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                ) : null;
              })()}
              <div>
                <Label>Agente (opcional)</Label>
                <Select value={localAction.config.assigned_agent_id || 'same'} onValueChange={(v) => {
                  if (v === 'same') { updateAction(branch, actionIndex, 'assigned_agent_id', ''); updateAction(branch, actionIndex, 'assigned_agent_name', ''); }
                  else { const agent = agents.find(a => a.id === v); updateAction(branch, actionIndex, 'assigned_agent_id', v); updateAction(branch, actionIndex, 'assigned_agent_name', agent?.full_name || ''); }
                }}>
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="same">Mismo agente que el lead original</SelectItem>
                    {agents.map(agent => <SelectItem key={agent.id} value={agent.id}>{agent.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {localAction.type === 'wait' && (
            <>
              <div>
                <Label>Unidad de tiempo</Label>
                <Select value={localAction.config.wait_type || 'minutes'} onValueChange={(v) => updateAction(branch, actionIndex, 'wait_type', v)}>
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minutes">Minutos</SelectItem>
                    <SelectItem value="hours">Horas</SelectItem>
                    <SelectItem value="days">Días</SelectItem>
                    <SelectItem value="weeks">Semanas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Cantidad</Label>
                <Input type="number" value={localAction.config.wait_amount || 1} onChange={(e) => updateAction(branch, actionIndex, 'wait_amount', parseInt(e.target.value))} min="1" className="mt-2" />
              </div>
            </>
          )}

          {localAction.type === 'webhook' && (
            <div>
              <Label>URL del webhook</Label>
              <Input value={localAction.config.url || ''} onChange={(e) => updateAction(branch, actionIndex, 'url', e.target.value)} placeholder="https://..." className="mt-2" />
            </div>
          )}

          {localAction.type === 'send_meta_conversion' && (
            <>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">📈 Envía un evento de conversión a Meta (Conversions API) para que el algoritmo optimice campañas en base a leads ganados. Requiere Pixel ID y CAPI Token configurados en la integración de Meta.</p>
              </div>
              <div>
                <Label>Tipo de evento</Label>
                <Select value={localAction.config.event_name || 'Purchase'} onValueChange={(v) => updateAction(branch, actionIndex, 'event_name', v)}>
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Purchase">Purchase (Compra — recomendado)</SelectItem>
                    <SelectItem value="Lead">Lead (Lead calificado)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500 mt-1">"Purchase" permite optimizar por valor si configuras uno</p>
              </div>
              <div>
                <Label>Valor de la conversión (opcional)</Label>
                <Input type="number" value={localAction.config.value || 0} onChange={(e) => updateAction(branch, actionIndex, 'value', parseFloat(e.target.value))} min="0" step="0.01" className="mt-2" />
                <p className="text-xs text-slate-500 mt-1">Deja en 0 para usar la prima estimada del lead automáticamente</p>
              </div>
            </>
          )}

          {/* ── Sub-condiciones ── */}
          <div className="border-t pt-4 mt-4">
            <button
              className="flex items-center gap-2 w-full text-left text-sm font-semibold text-purple-700 hover:text-purple-800 transition-colors"
              onClick={() => setShowSubConditions(!showSubConditions)}
            >
              {showSubConditions ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              <GitBranch className="h-4 w-4" />
              Sub-condiciones después de esta acción
              {(localAction.sub_conditions?.length > 0) && (
                <Badge className="ml-auto bg-purple-100 text-purple-700 text-xs">{localAction.sub_conditions.length}</Badge>
              )}
            </button>

            {showSubConditions && (
              <div className="mt-4 space-y-4">
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                  <p className="text-xs text-purple-800">
                    🔀 Después de ejecutar esta acción, puedes evaluar nuevas condiciones y ejecutar más acciones según el resultado.
                  </p>
                </div>

                <div>
                  <Label className="text-xs font-bold text-purple-700 uppercase">Condiciones adicionales</Label>
                  <div className="mt-2">
                    <ConditionEditor
                      conditions={localAction.sub_conditions || []}
                      onChange={(newConds) => updateActionField(branch, actionIndex, 'sub_conditions', newConds)}
                      pipelines={pipelines}
                      webForms={webForms}
                    />
                  </div>
                </div>

                {(localAction.sub_conditions?.length > 0) && (
                  <>
                    <div>
                      <Label className="text-xs font-bold text-green-700 uppercase">SI se cumplen → acciones adicionales</Label>
                      <SubActionList
                        actions={localAction.sub_actions_if_true || []}
                        onChange={(actions) => updateActionField(branch, actionIndex, 'sub_actions_if_true', actions)}
                        agents={agents}
                        pipelines={pipelines}
                      />
                    </div>
                    <div>
                      <Label className="text-xs font-bold text-red-700 uppercase">NO se cumplen → acciones adicionales</Label>
                      <SubActionList
                        actions={localAction.sub_actions_if_false || []}
                        onChange={(actions) => updateActionField(branch, actionIndex, 'sub_actions_if_false', actions)}
                        agents={agents}
                        pipelines={pipelines}
                      />
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </>
    );
  }

  return null;
}

// ─── Sub-acciones simples (sin anidación adicional) ───
function SubActionList({ actions, onChange, agents, pipelines }) {
  const addSubAction = () => onChange([...actions, { type: 'create_note', config: {} }]);
  const removeSubAction = (idx) => onChange(actions.filter((_, i) => i !== idx));

  const updateSubAction = (idx, field, value) => {
    const updated = [...actions];
    updated[idx] = { ...updated[idx], [field]: value };
    onChange(updated);
  };

  const updateSubActionConfig = (idx, configField, value) => {
    const updated = [...actions];
    updated[idx] = { ...updated[idx], config: { ...updated[idx].config, [configField]: value } };
    onChange(updated);
  };

  return (
    <div className="space-y-2 mt-2">
      {actions.map((action, idx) => (
        <Card key={idx} className="border border-slate-200">
          <CardContent className="pt-3 pb-3 space-y-2">
            <div className="flex items-center justify-between">
              <Select value={action.type} onValueChange={(v) => updateSubAction(idx, 'type', v)}>
                <SelectTrigger className="h-8 text-xs flex-1 mr-2"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="create_note">📝 Crear nota</SelectItem>
                  <SelectItem value="create_task">📋 Crear tarea</SelectItem>
                  <SelectItem value="add_tag">🏷️ Asignar etiqueta</SelectItem>
                  <SelectItem value="change_stage">🔄 Cambiar etapa</SelectItem>
                  <SelectItem value="assign_agent">👤 Asignar agente</SelectItem>
                  <SelectItem value="send_email">📧 Enviar email</SelectItem>
                  <SelectItem value="create_lead">➕ Crear lead</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="ghost" size="sm" onClick={() => removeSubAction(idx)} className="h-8 w-8 p-0">
                <Trash2 className="h-3.5 w-3.5 text-red-500" />
              </Button>
            </div>

            {action.type === 'create_note' && (
              <Textarea value={action.config.note_text || ''} onChange={(e) => updateSubActionConfig(idx, 'note_text', e.target.value)} placeholder="Texto de la nota" rows={2} className="text-xs" />
            )}
            {action.type === 'add_tag' && (
              <Input value={action.config.tag_name || ''} onChange={(e) => updateSubActionConfig(idx, 'tag_name', e.target.value)} placeholder="Nombre del tag (ej: VIP)" className="text-xs h-8" />
            )}
            {action.type === 'change_stage' && (
              <Select value={action.config.new_stage || ''} onValueChange={(v) => updateSubActionConfig(idx, 'new_stage', v)}>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Seleccionar etapa" /></SelectTrigger>
                <SelectContent>
                  {pipelines.flatMap(p => p.stages || []).filter((s, i, arr) => arr.findIndex(x => x.key === s.key) === i).map(s => (
                    <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            {action.type === 'assign_agent' && (
              <Select value={action.config.agent_id || ''} onValueChange={(v) => {
                const agent = agents.find(a => a.id === v);
                updateSubActionConfig(idx, 'agent_id', v);
                updateSubActionConfig(idx, 'agent_name', agent?.full_name || '');
              }}>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Seleccionar agente" /></SelectTrigger>
                <SelectContent>
                  {agents.map(a => <SelectItem key={a.id} value={a.id}>{a.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            {action.type === 'send_email' && (
              <Input value={action.config.template_id || ''} onChange={(e) => updateSubActionConfig(idx, 'template_id', e.target.value)} placeholder="ID de plantilla de email" className="text-xs h-8" />
            )}
            {action.type === 'create_lead' && (
              <Select value={action.config.pipeline_id || ''} onValueChange={(v) => {
                const pipeline = pipelines.find(p => p.id === v);
                updateSubActionConfig(idx, 'pipeline_id', v);
                updateSubActionConfig(idx, 'pipeline_name', pipeline?.name || '');
                const firstStage = pipeline?.stages?.[0];
                if (firstStage) updateSubActionConfig(idx, 'pipeline_stage', firstStage.key);
              }}>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Pipeline destino" /></SelectTrigger>
                <SelectContent>
                  {pipelines.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          </CardContent>
        </Card>
      ))}
      <Button variant="outline" size="sm" className="w-full border-dashed text-xs h-8" onClick={addSubAction}>
        <Plus className="h-3 w-3 mr-1" />Agregar sub-acción
      </Button>
    </div>
  );
}