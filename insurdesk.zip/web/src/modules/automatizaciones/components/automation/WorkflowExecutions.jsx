import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Clock, AlertCircle } from "lucide-react";
import moment from 'moment';

export default function WorkflowExecutions() {
  const [executions, setExecutions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadExecutions();
  }, []);

  const loadExecutions = async () => {
    try {
      const data = await api.entities.WorkflowExecution.list('-created_date', 50);
      setExecutions(data);
    } catch (error) {
      console.error('Error al cargar ejecuciones:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-12">Cargando ejecuciones...</div>;
  }

  const STATUS_CONFIG = {
    completed: { icon: CheckCircle2, color: 'text-green-600', label: 'Completado', bg: 'bg-green-100' },
    failed: { icon: XCircle, color: 'text-red-600', label: 'Fallido', bg: 'bg-red-100' },
    waiting: { icon: Clock, color: 'text-blue-600', label: 'Esperando', bg: 'bg-blue-100' },
    cancelled: { icon: AlertCircle, color: 'text-slate-600', label: 'Cancelado', bg: 'bg-slate-100' }
  };

  return (
    <div className="space-y-4">
      {executions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <AlertCircle className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600">No hay ejecuciones registradas</p>
          </CardContent>
        </Card>
      ) : (
        executions.map(execution => {
          const status = STATUS_CONFIG[execution.status] || STATUS_CONFIG.completed;
          const Icon = status.icon;

          return (
            <Card key={execution.id}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-slate-900">{execution.workflow_name}</h3>
                    <p className="text-sm text-slate-600">
                      Lead: {execution.lead_external_id} • {execution.trigger_event}
                    </p>
                  </div>
                  <Badge className={`${status.bg} ${status.color} gap-1`}>
                    <Icon className="h-3 w-3" />
                    {status.label}
                  </Badge>
                </div>

                <div className="text-xs text-slate-500 mb-3">
                  {moment(execution.created_date).format('DD/MM/YYYY HH:mm')}
                  {execution.execution_time_ms && (
                    <span className="ml-2">• {execution.execution_time_ms}ms</span>
                  )}
                </div>

                {execution.conditions_met !== undefined && (
                  <div className="mb-2">
                    <Badge variant={execution.conditions_met ? 'default' : 'secondary'}>
                      {execution.conditions_met ? 'Condiciones cumplidas' : 'Condiciones no cumplidas'}
                    </Badge>
                  </div>
                )}

                {execution.actions_executed && execution.actions_executed.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-slate-700">Acciones ejecutadas:</p>
                    {execution.actions_executed.map((action, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs">
                        {action.status === 'success' ? (
                          <CheckCircle2 className="h-3 w-3 text-green-600" />
                        ) : (
                          <XCircle className="h-3 w-3 text-red-600" />
                        )}
                        <span className="text-slate-600">{action.action_type}</span>
                        {action.error && (
                          <span className="text-red-600">- {action.error}</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {execution.error_message && (
                  <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
                    {execution.error_message}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
}