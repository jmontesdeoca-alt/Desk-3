import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shuffle, Plus, Trash2, ArrowUp, ArrowDown } from "lucide-react";

export default function RoundRobinConfig({ agents, selectedAgents, onChange }) {
  const [addingAgent, setAddingAgent] = useState('');

  const handleAdd = (agentId) => {
    if (!agentId) return;
    const agent = agents.find(a => a.id === agentId);
    if (!agent) return;
    if (selectedAgents.find(a => a.id === agentId)) return; // no duplicados
    onChange([...selectedAgents, { id: agent.id, full_name: agent.full_name, email: agent.email }]);
    setAddingAgent('');
  };

  const handleRemove = (agentId) => {
    onChange(selectedAgents.filter(a => a.id !== agentId));
  };

  const moveUp = (index) => {
    if (index === 0) return;
    const updated = [...selectedAgents];
    [updated[index - 1], updated[index]] = [updated[index], updated[index - 1]];
    onChange(updated);
  };

  const moveDown = (index) => {
    if (index === selectedAgents.length - 1) return;
    const updated = [...selectedAgents];
    [updated[index], updated[index + 1]] = [updated[index + 1], updated[index]];
    onChange(updated);
  };

  const availableAgents = agents.filter(a => !selectedAgents.find(s => s.id === a.id));

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <Shuffle className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-blue-800">Asignación Round-Robin</p>
            <p className="text-xs text-blue-700 mt-0.5">
              Los leads se asignan de forma secuencial: primero al agente 1, luego al 2, luego al 3, y así sucesivamente, rotando en orden.
            </p>
          </div>
        </div>
      </div>

      {/* Lista de agentes seleccionados */}
      <div>
        <p className="text-sm font-semibold text-slate-700 mb-2">
          Agentes en rotación ({selectedAgents.length})
        </p>

        {selectedAgents.length === 0 ? (
          <div className="border-2 border-dashed border-slate-200 rounded-lg py-6 text-center">
            <Shuffle className="h-8 w-8 text-slate-300 mx-auto mb-2" />
            <p className="text-xs text-slate-400">Agrega al menos 2 agentes para la rotación</p>
          </div>
        ) : (
          <div className="space-y-2">
            {selectedAgents.map((agent, idx) => (
              <div
                key={agent.id}
                className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg px-3 py-2"
              >
                <Badge variant="outline" className="text-xs w-6 h-6 rounded-full flex items-center justify-center p-0 font-bold border-brand text-brand">
                  {idx + 1}
                </Badge>
                <span className="flex-1 text-sm font-medium text-slate-800">{agent.full_name}</span>
                <span className="text-xs text-slate-400 hidden sm:block">{agent.email}</span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => moveUp(idx)}
                    disabled={idx === 0}
                  >
                    <ArrowUp className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => moveDown(idx)}
                    disabled={idx === selectedAgents.length - 1}
                  >
                    <ArrowDown className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => handleRemove(agent.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Selector para agregar */}
      {availableAgents.length > 0 && (
        <div className="flex gap-2">
          <Select value={addingAgent} onValueChange={setAddingAgent}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Seleccionar agente..." />
            </SelectTrigger>
            <SelectContent>
              {availableAgents.map(agent => (
                <SelectItem key={agent.id} value={agent.id}>
                  {agent.full_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            onClick={() => handleAdd(addingAgent)}
            disabled={!addingAgent}
            className="bg-brand hover:bg-brand-dark"
            size="sm"
          >
            <Plus className="h-4 w-4 mr-1" />
            Agregar
          </Button>
        </div>
      )}

      {selectedAgents.length > 0 && (
        <div className="bg-slate-50 rounded-lg p-3">
          <p className="text-xs text-slate-500">
            💡 El orden define la rotación. Usa las flechas para reordenar. El estado del turno se guarda automáticamente en el sistema.
          </p>
        </div>
      )}
    </div>
  );
}