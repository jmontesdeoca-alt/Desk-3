import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Zap, Plus, Trash2, Clock, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function AutomationsPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [showNewRule, setShowNewRule] = useState(false);
  const [deleteRuleId, setDeleteRuleId] = useState(null);
  const [formData, setFormData] = useState({
    rule_name: '',
    inactivity_days: 30,
    exclude_stages: 'GANADO,PERDIDO'
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const { data: rules = [], isLoading } = useQuery({
    queryKey: ['automation-rules'],
    queryFn: () => api.entities.AutomationRule.list('-created_date')
  });

  const createRuleMutation = useMutation({
    mutationFn: async (data) => {
      await api.entities.AutomationRule.create({
        ...data,
        created_by_name: currentUser?.full_name
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automation-rules'] });
      setShowNewRule(false);
      setFormData({
        rule_name: '',
        inactivity_days: 30,
        exclude_stages: 'GANADO,PERDIDO'
      });
      toast.success('Regla de automatización creada');
    }
  });

  const toggleRuleMutation = useMutation({
    mutationFn: async ({ id, isActive }) => {
      await api.entities.AutomationRule.update(id, { is_active: !isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automation-rules'] });
      toast.success('Estado de la regla actualizado');
    }
  });

  const deleteRuleMutation = useMutation({
    mutationFn: async (id) => {
      await api.entities.AutomationRule.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automation-rules'] });
      setDeleteRuleId(null);
      toast.success('Regla eliminada');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.rule_name || !formData.inactivity_days) {
      toast.error('Por favor completa todos los campos requeridos');
      return;
    }
    createRuleMutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand mx-auto"></div>
          <p className="mt-4 text-slate-600">Cargando automatizaciones...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Automatizaciones
          </h1>
          <p className="text-slate-600">
            Configura reglas automáticas para gestionar tu pipeline
          </p>
        </div>

        <Dialog open={showNewRule} onOpenChange={setShowNewRule}>
          <DialogTrigger asChild>
            <Button className="bg-brand">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Regla
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crear Regla de Automatización</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="rule_name">Nombre de la Regla</Label>
                <Input
                  id="rule_name"
                  value={formData.rule_name}
                  onChange={(e) => setFormData({ ...formData, rule_name: e.target.value })}
                  placeholder="Ej: Abandonar leads inactivos 30 días"
                  required
                />
              </div>

              <div>
                <Label htmlFor="inactivity_days">Días de Inactividad</Label>
                <Input
                  id="inactivity_days"
                  type="number"
                  min="1"
                  value={formData.inactivity_days}
                  onChange={(e) => setFormData({ ...formData, inactivity_days: parseInt(e.target.value) })}
                  required
                />
                <p className="text-sm text-slate-500 mt-1">
                  Los leads sin actividad durante este período serán marcados como abandonados
                </p>
              </div>

              <div>
                <Label htmlFor="exclude_stages">Etapas a Excluir (separadas por coma)</Label>
                <Input
                  id="exclude_stages"
                  value={formData.exclude_stages}
                  onChange={(e) => setFormData({ ...formData, exclude_stages: e.target.value })}
                  placeholder="GANADO,PERDIDO"
                />
                <p className="text-sm text-slate-500 mt-1">
                  Los leads en estas etapas no serán afectados por la automatización
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setShowNewRule(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={createRuleMutation.isPending} className="bg-brand">
                  Crear Regla
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Información */}
      <Card className="mb-6 bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex gap-3">
            <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-1">
                ¿Cómo funcionan las automatizaciones?
              </h3>
              <p className="text-sm text-blue-800">
                Las reglas de automatización se ejecutan periódicamente (cada hora) y marcan leads como abandonados
                cuando no han tenido actividad durante el período especificado. Los leads abandonados se mueven
                a una vista separada para mantener limpio tu pipeline activo.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de reglas */}
      {rules.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Zap className="h-16 w-16 text-slate-300 mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">
              No hay reglas configuradas
            </h3>
            <p className="text-slate-600 text-center mb-4">
              Crea tu primera regla de automatización para mantener limpio tu pipeline
            </p>
            <Button onClick={() => setShowNewRule(true)} className="bg-brand">
              <Plus className="h-4 w-4 mr-2" />
              Crear Primera Regla
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {rules.map((rule) => (
            <Card key={rule.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <CardTitle>{rule.rule_name}</CardTitle>
                      {rule.is_active ? (
                        <Badge className="bg-green-600">Activa</Badge>
                      ) : (
                        <Badge variant="outline">Inactiva</Badge>
                      )}
                    </div>
                    <CardDescription>
                      Creada por {rule.created_by_name} el {new Date(rule.created_date).toLocaleDateString('es-ES')}
                    </CardDescription>
                  </div>

                  <div className="flex items-center gap-2">
                    <Switch
                      checked={rule.is_active}
                      onCheckedChange={() => toggleRuleMutation.mutate({ id: rule.id, isActive: rule.is_active })}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteRuleId(rule.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-6 text-sm">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Clock className="h-4 w-4" />
                    <span>
                      <strong>{rule.inactivity_days}</strong> días de inactividad
                    </span>
                  </div>
                  {rule.exclude_stages && (
                    <div className="text-slate-600">
                      Excluye: <strong>{rule.exclude_stages}</strong>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Diálogo de confirmación de eliminación */}
      <AlertDialog open={!!deleteRuleId} onOpenChange={() => setDeleteRuleId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar regla?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. La regla será eliminada permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteRuleMutation.mutate(deleteRuleId)}
              className="bg-red-600 hover:bg-red-700"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}