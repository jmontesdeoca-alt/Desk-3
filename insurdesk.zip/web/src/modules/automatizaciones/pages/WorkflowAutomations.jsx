import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Zap, Plus, Play, Pause, Trash2, Edit, Activity,
  Mail, UserCheck, Target, Clock, Tag, FileText, Webhook,
  TrendingUp, AlertCircle, Settings, Shuffle, CalendarCheck, Bell
} from "lucide-react";
import { toast } from "sonner";
import WorkflowBuilder from "@/modules/automatizaciones/components/automation/WorkflowBuilder";
import WorkflowExecutions from "@/modules/automatizaciones/components/automation/WorkflowExecutions";
import EmailTemplates from "@/modules/automatizaciones/components/automation/EmailTemplates";

const ACTION_ICONS = {
  send_email: Mail,
  change_stage: Target,
  assign_agent: UserCheck,
  assign_agent_roundrobin: Shuffle,
  create_task: Clock,
  add_tag: Tag,
  create_note: FileText,
  webhook: Webhook
};

export default function WorkflowAutomations() {
  const [loading, setLoading] = useState(true);
  const [workflows, setWorkflows] = useState([]);
  const [rules, setRules] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [showBuilder, setShowBuilder] = useState(false);
  const [activeTab, setActiveTab] = useState('workflows');
  const [showNewRule, setShowNewRule] = useState(false);
  const [deleteRuleId, setDeleteRuleId] = useState(null);
  const [ruleForm, setRuleForm] = useState({ rule_name: '', inactivity_days: 30, exclude_stages: 'GANADO,PERDIDO' });
  const [savingRule, setSavingRule] = useState(false);
  const [remindersEnabled, setRemindersEnabled] = useState(true);
  const [remindersLoading, setRemindersLoading] = useState(false);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
      const [wfData, rulesData, configData] = await Promise.all([
        api.entities.WorkflowAutomation.list('-created_date'),
        api.entities.AutomationRule.list('-created_date'),
        api.entities.AppConfig.filter({ key: 'appointment_reminders_enabled' }),
      ]);
      setWorkflows(wfData);
      setRules(rulesData);
      if (configData.length > 0) {
        setRemindersEnabled(configData[0].value?.[0] !== 'false');
      }
    } catch (error) {
      toast.error('Error al cargar automatizaciones');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const loadWorkflows = loadAll;

  const toggleReminders = async () => {
    setRemindersLoading(true);
    try {
      // Store preference in AppConfig entity
      const configs = await api.entities.AppConfig.filter({ key: 'appointment_reminders_enabled' });
      const newVal = !remindersEnabled;
      if (configs.length > 0) {
        await api.entities.AppConfig.update(configs[0].id, { value: [newVal ? 'true' : 'false'] });
      } else {
        await api.entities.AppConfig.create({ key: 'appointment_reminders_enabled', value: [newVal ? 'true' : 'false'] });
      }
      setRemindersEnabled(newVal);
      toast.success(newVal ? 'Recordatorios activados' : 'Recordatorios desactivados');
    } finally {
      setRemindersLoading(false);
    }
  };

  const toggleWorkflow = async (workflow) => {
    try {
      await api.entities.WorkflowAutomation.update(workflow.id, {
        is_active: !workflow.is_active
      });
      toast.success(workflow.is_active ? 'Workflow desactivado' : 'Workflow activado');
      loadWorkflows();
    } catch (error) {
      toast.error('Error al cambiar estado');
    }
  };

  const deleteWorkflow = async (workflowId) => {
    if (!confirm('¿Eliminar este workflow? Esta acción no se puede deshacer.')) return;

    try {
      await api.entities.WorkflowAutomation.delete(workflowId);
      toast.success('Workflow eliminado');
      loadWorkflows();
    } catch (error) {
      toast.error('Error al eliminar workflow');
    }
  };

  const getTriggerLabel = (type) => {
    const labels = {
      prospect_created: 'Prospecto creado',
      lead_created: 'Lead creado',
      lead_stage_changed: 'Cambio de etapa',
      lead_inactive: 'Lead inactivo',
      email_clicked: 'Clic en email',
      tag_added: 'Tag agregado',
      tag_removed: 'Tag eliminado',
      manual: 'Manual'
    };
    return labels[type] || type;
  };

  const createRule = async (e) => {
    e.preventDefault();
    if (!ruleForm.rule_name || !ruleForm.inactivity_days) {
      toast.error('Completa todos los campos');
      return;
    }
    setSavingRule(true);
    try {
      await api.entities.AutomationRule.create({ ...ruleForm, created_by_name: currentUser?.full_name });
      toast.success('Regla creada');
      setShowNewRule(false);
      setRuleForm({ rule_name: '', inactivity_days: 30, exclude_stages: 'GANADO,PERDIDO' });
      loadAll();
    } finally {
      setSavingRule(false);
    }
  };

  const toggleRule = async (rule) => {
    await api.entities.AutomationRule.update(rule.id, { is_active: !rule.is_active });
    toast.success(rule.is_active ? 'Regla desactivada' : 'Regla activada');
    loadAll();
  };

  const deleteRule = async () => {
    await api.entities.AutomationRule.delete(deleteRuleId);
    toast.success('Regla eliminada');
    setDeleteRuleId(null);
    loadAll();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Zap className="h-12 w-12 text-brand animate-pulse mx-auto mb-4" />
          <p className="text-slate-600">Cargando automatizaciones...</p>
        </div>
      </div>
    );
  }

  if (showBuilder) {
    return (
      <WorkflowBuilder
        workflow={selectedWorkflow}
        onClose={() => {
          setShowBuilder(false);
          setSelectedWorkflow(null);
          loadWorkflows();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
              <Zap className="h-8 w-8 text-brand" />
              Automatizaciones
            </h1>
            <p className="text-slate-600 dark:text-zinc-400 mt-1">
              Sistema de workflows inteligentes para gestión comercial
            </p>
          </div>
          <Button 
            onClick={() => {
              setSelectedWorkflow(null);
              setShowBuilder(true);
            }}
            className="bg-brand hover:bg-brand-dark"
          >
            <Plus className="h-5 w-5 mr-2" />
            Nuevo Workflow
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-zinc-400">Total Workflows</p>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white">{workflows.length}</p>
                </div>
                <Zap className="h-8 w-8 text-brand" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-zinc-400">Activos</p>
                  <p className="text-2xl font-bold text-green-600">
                    {workflows.filter(w => w.is_active).length}
                  </p>
                </div>
                <Play className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-zinc-400">Inactivos</p>
                  <p className="text-2xl font-bold text-slate-400">
                    {workflows.filter(w => !w.is_active).length}
                  </p>
                </div>
                <Pause className="h-8 w-8 text-slate-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600 dark:text-zinc-400">Ejecuciones</p>
                  <p className="text-2xl font-bold text-brand">
                    {workflows.reduce((sum, w) => sum + (w.execution_count || 0), 0)}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-brand" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="workflows">
              <Zap className="h-4 w-4 mr-2" />
              Workflows
            </TabsTrigger>
            <TabsTrigger value="rules">
              <Settings className="h-4 w-4 mr-2" />
              Reglas ({rules.length})
            </TabsTrigger>
            <TabsTrigger value="citas">
              <CalendarCheck className="h-4 w-4 mr-2" />
              Citas
            </TabsTrigger>
            <TabsTrigger value="executions">
              <Activity className="h-4 w-4 mr-2" />
              Ejecuciones
            </TabsTrigger>
            <TabsTrigger value="templates">
              <Mail className="h-4 w-4 mr-2" />
              Plantillas Email
            </TabsTrigger>
          </TabsList>

          <TabsContent value="workflows" className="space-y-4">
            {workflows.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <AlertCircle className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">
                    No hay workflows configurados
                  </h3>
                  <p className="text-slate-600 mb-4">
                    Crea tu primer workflow automatizado
                  </p>
                  <Button 
                    onClick={() => setShowBuilder(true)}
                    className="bg-brand hover:bg-brand-dark"
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Crear Workflow
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {workflows.map(workflow => {
                  const actionCount = workflow.actions?.length || 0;
                  const conditionCount = workflow.conditions?.length || 0;

                  return (
                    <Card key={workflow.id} className={!workflow.is_active ? 'opacity-60' : ''}>
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center flex-wrap gap-2 mb-2">
                              <CardTitle className="text-xl">{workflow.name}</CardTitle>
                              <Badge variant={workflow.is_active ? 'default' : 'secondary'}>
                                {workflow.is_active ? 'Activo' : 'Inactivo'}
                              </Badge>
                              {(workflow.triggers?.length ? workflow.triggers : [{ trigger_type: workflow.trigger_type }]).map((t, i) => (
                                <Badge key={i} variant="outline">
                                  {getTriggerLabel(t.trigger_type)}
                                </Badge>
                              ))}
                            </div>
                            {workflow.description && (
                              <CardDescription>{workflow.description}</CardDescription>
                            )}
                          </div>
                          <Switch
                            checked={workflow.is_active}
                            onCheckedChange={() => toggleWorkflow(workflow)}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {/* Métricas */}
                          <div className="flex items-center gap-6 text-sm text-slate-600 dark:text-zinc-400">
                            <div className="flex items-center gap-2">
                              <Target className="h-4 w-4" />
                              <span>{conditionCount} condiciones</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Zap className="h-4 w-4" />
                              <span>{actionCount} acciones</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <TrendingUp className="h-4 w-4" />
                              <span>{workflow.execution_count || 0} ejecuciones</span>
                            </div>
                          </div>

                          {/* Acciones */}
                          {actionCount > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {workflow.actions.map((action, idx) => {
                                const Icon = ACTION_ICONS[action.type] || Zap;
                                return (
                                  <Badge key={idx} variant="outline" className="gap-1">
                                    <Icon className="h-3 w-3" />
                                    {action.type}
                                  </Badge>
                                );
                              })}
                            </div>
                          )}

                          {/* Botones */}
                          <div className="flex gap-2 pt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedWorkflow(workflow);
                                setShowBuilder(true);
                              }}
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Editar
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => deleteWorkflow(workflow.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Eliminar
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="rules" className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-sm text-slate-600 dark:text-zinc-400">Reglas automáticas para abandono de leads inactivos</p>
              <Button onClick={() => setShowNewRule(true)} className="bg-brand hover:bg-brand-dark" size="sm">
                <Plus className="h-4 w-4 mr-1" /> Nueva Regla
              </Button>
            </div>

            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-4 pb-4">
                <div className="flex gap-2 items-start">
                  <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                  <p className="text-sm text-blue-800">
                    Las reglas se ejecutan cada hora y marcan como <strong>ABANDONADO</strong> a los leads sin actividad durante el período configurado. Los leads en las etapas excluidas no son afectados.
                  </p>
                </div>
              </CardContent>
            </Card>

            {rules.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <Settings className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500">No hay reglas configuradas</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {rules.map(rule => (
                  <Card key={rule.id} className={!rule.is_active ? 'opacity-60' : ''}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CardTitle className="text-base">{rule.rule_name}</CardTitle>
                          <Badge variant={rule.is_active ? 'default' : 'secondary'}>
                            {rule.is_active ? 'Activa' : 'Inactiva'}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch checked={rule.is_active} onCheckedChange={() => toggleRule(rule)} />
                          <Button variant="ghost" size="icon" onClick={() => setDeleteRuleId(rule.id)} className="text-red-600 hover:bg-red-50 h-8 w-8">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-6 text-sm text-slate-600 dark:text-zinc-400">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          <span><strong>{rule.inactivity_days}</strong> días de inactividad</span>
                        </div>
                        {rule.exclude_stages && (
                          <div>Excluye: <strong>{rule.exclude_stages}</strong></div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="citas" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Bell className="h-5 w-5 text-brand" />
                  Recordatorios Automáticos de Citas
                </CardTitle>
                <CardDescription>
                  Cuando un cliente confirma una cita, el sistema envía automáticamente emails de recordatorio.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-zinc-800 rounded-xl border border-slate-200 dark:border-zinc-700">
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white">Recordatorios habilitados</p>
                    <p className="text-sm text-slate-500 dark:text-zinc-400 mt-0.5">
                      Activa o desactiva el envío de recordatorios para todas las citas
                    </p>
                  </div>
                  <Switch checked={remindersEnabled} onCheckedChange={toggleReminders} disabled={remindersLoading} />
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div className={`p-4 rounded-xl border ${remindersEnabled ? 'bg-green-50 border-green-200' : 'bg-slate-50 border-slate-200 opacity-60'}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${remindersEnabled ? 'bg-green-100' : 'bg-slate-100'}`}>
                        <Clock className={`h-4 w-4 ${remindersEnabled ? 'text-green-600' : 'text-slate-400'}`} />
                      </div>
                      <span className="font-semibold text-slate-800 dark:text-white text-sm">24 horas antes</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-zinc-400">
                      Se envía un email recordatorio al cliente el día previo a su cita.
                    </p>
                  </div>
                  <div className={`p-4 rounded-xl border ${remindersEnabled ? 'bg-blue-50 border-blue-200' : 'bg-slate-50 border-slate-200 opacity-60'}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${remindersEnabled ? 'bg-blue-100' : 'bg-slate-100'}`}>
                        <Bell className={`h-4 w-4 ${remindersEnabled ? 'text-blue-600' : 'text-slate-400'}`} />
                      </div>
                      <span className="font-semibold text-slate-800 dark:text-white text-sm">1 hora antes</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-zinc-400">
                      Se envía un email de último aviso 1 hora antes del inicio de la cita.
                    </p>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <div className="flex gap-2 items-start">
                    <AlertCircle className="h-4 w-4 text-amber-600 mt-0.5 shrink-0" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-0.5">¿Cómo funciona?</p>
                      <p>El sistema verifica cada 30 minutos las citas confirmadas. Si una cita cae dentro de la ventana de 24h o 1h, envía el recordatorio al email del cliente y marca que ya fue enviado para no duplicar.</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="executions">
            <WorkflowExecutions />
          </TabsContent>

          <TabsContent value="templates">
            <EmailTemplates />
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialog nueva regla */}
      <Dialog open={showNewRule} onOpenChange={setShowNewRule}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nueva Regla de Automatización</DialogTitle>
          </DialogHeader>
          <form onSubmit={createRule} className="space-y-4">
            <div>
              <Label>Nombre de la regla</Label>
              <Input value={ruleForm.rule_name} onChange={e => setRuleForm({...ruleForm, rule_name: e.target.value})} placeholder="Ej: Abandonar leads inactivos 30 días" className="mt-1" required />
            </div>
            <div>
              <Label>Días de inactividad</Label>
              <Input type="number" min="1" value={ruleForm.inactivity_days} onChange={e => setRuleForm({...ruleForm, inactivity_days: parseInt(e.target.value)})} className="mt-1" required />
              <p className="text-xs text-slate-500 mt-1">Leads sin actividad durante este período serán marcados como abandonados</p>
            </div>
            <div>
              <Label>Etapas a excluir (separadas por coma)</Label>
              <Input value={ruleForm.exclude_stages} onChange={e => setRuleForm({...ruleForm, exclude_stages: e.target.value})} placeholder="GANADO,PERDIDO" className="mt-1" />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setShowNewRule(false)}>Cancelar</Button>
              <Button type="submit" disabled={savingRule} className="bg-brand">Crear Regla</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Confirm delete rule */}
      <AlertDialog open={!!deleteRuleId} onOpenChange={() => setDeleteRuleId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar regla?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={deleteRule} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}