// CRM base: pipelines, prospectos, leads, tareas, reportes, etiquetas y metas.
import { Target, Users, Clock, BarChart2, Layers, Tag, FileSpreadsheet } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Pipeline from './pages/Pipeline';
import Prospects from './pages/Prospects';
import Tasks from './pages/Tasks';
import Reports from './pages/Reports';
import AgentGoals from './pages/AgentGoals';
import TagsReport from './pages/TagsReport';
import AbandonedLeads from './pages/AbandonedLeads';
import PipelinesSettings from './pages/PipelinesSettings';
import PipelinesTab from './components/settings/PipelinesTab';
import TagsTab from './components/settings/TagsTab';
import ImportsTab from './components/settings/ImportsTab';
import GoalsTab from './components/settings/GoalsTab';

export default {
  id: 'crm',
  name: 'CRM base',
  mainPage: 'CrmDashboard',
  pages: { CrmDashboard: Dashboard, Pipeline, Prospects, Tasks, CrmReports: Reports, AgentGoals, TagsReport, AbandonedLeads, PipelinesSettings },
  nav: [
    { section: 'main', order: 10, name: 'Pipeline', icon: Target, page: 'Pipeline' },
    { section: 'main', order: 20, name: 'Prospectos', icon: Users, page: 'Prospects' },
    { section: 'main', order: 40, name: 'Tareas', icon: Clock, page: 'Tasks' },
    { section: 'admin', order: 10, name: 'Reportes', icon: BarChart2, page: 'CrmReports' },
  ],
  settingsTabs: [
    { id: 'pipelines', order: 10, label: 'Pipelines', icon: Layers, Component: PipelinesTab },
    { id: 'etiquetas', order: 20, label: 'Etiquetas', icon: Tag, Component: TagsTab },
    { id: 'importaciones', order: 30, label: 'Importaciones', icon: FileSpreadsheet, Component: ImportsTab },
    { id: 'metas', order: 40, label: 'Metas', icon: Target, Component: GoalsTab },
  ],
};
