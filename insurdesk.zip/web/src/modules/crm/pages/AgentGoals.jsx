import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { format, addMonths, subMonths } from 'date-fns';
import { es } from 'date-fns/locale';
import { Target, Plus, Pencil, Trash2, ChevronLeft, ChevronRight, Loader2, Trophy, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const ProgressBar = ({ value, max }) => {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const color = pct >= 100 ? 'bg-green-500' : pct >= 60 ? 'bg-blue-500' : pct >= 30 ? 'bg-amber-500' : 'bg-red-400';
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-slate-100 rounded-full h-2">
        <div className={cn("h-2 rounded-full transition-all", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-semibold text-slate-600 w-10 text-right">{pct}%</span>
    </div>
  );
};

const emptyForm = { agent_id: '', agent_name: '', agent_email: '', target_leads: '', target_amount: '', pipeline_id: '', pipeline_name: '' };

export default function AgentGoals() {
  const [goals, setGoals] = useState([]);
  const [agents, setAgents] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [allLeads, setAllLeads] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [periodDate, setPeriodDate] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const periodLabel = format(periodDate, 'yyyy-MM');
  const periodDisplay = format(periodDate, 'MMMM yyyy', { locale: es });

  useEffect(() => {
    loadData();
  }, [periodDate]);

  const loadData = async () => {
    try {
      setLoading(true);
      const user = await api.auth.me();
      setCurrentUser(user);
      const admin = user.crm_role === 'admin_crm' || user.role === 'admin';
      setIsAdmin(admin);

      const [goalsData, pipelinesData, leadsData] = await Promise.all([
        api.entities.AgentGoal.filter({ period_label: periodLabel }),
        api.entities.Pipeline.list(),
        admin
          ? api.entities.Lead.filter({ lead_status: 'ACTIVO' })
          : api.entities.Lead.filter({ assigned_agent_id: user.id, lead_status: 'ACTIVO' }),
      ]);
      setPipelines(pipelinesData);
      setAllLeads(leadsData);

      if (admin) {
        // Load agents via function
        try {
          const { data } = await api.functions.invoke('listAgents', {});
          setAgents(data.agents || []);
        } catch { setAgents([]); }
        setGoals(goalsData);
      } else {
        setGoals(goalsData.filter(g => g.agent_id === user.id));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const getActuals = (agentId, pipelineId) => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const leads = allLeads.filter(l => {
      if (l.assigned_agent_id !== agentId) return false;
      if (pipelineId && l.pipeline_id !== pipelineId) return false;
      if (!(l.pipeline_stage?.toLowerCase().includes('ganado') || l.pipeline_stage?.toLowerCase() === 'won')) return false;
      return new Date(l.updated_date) >= monthStart;
    });
    return {
      wonLeads: leads.length,
      wonAmount: leads.reduce((s, l) => s + (l.premium_estimated || 0), 0),
    };
  };

  const openNew = () => {
    setEditingGoal(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (goal) => {
    setEditingGoal(goal);
    setForm({
      agent_id: goal.agent_id,
      agent_name: goal.agent_name,
      agent_email: goal.agent_email || '',
      target_leads: goal.target_leads || '',
      target_amount: goal.target_amount || '',
      pipeline_id: goal.pipeline_id || '',
      pipeline_name: goal.pipeline_name || '',
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.agent_id) return toast({ title: 'Selecciona un agente', variant: 'destructive' });
    setSaving(true);
    const payload = {
      agent_id: form.agent_id,
      agent_name: form.agent_name,
      agent_email: form.agent_email,
      period_label: periodLabel,
      period_type: 'monthly',
      target_leads: Number(form.target_leads) || 0,
      target_amount: Number(form.target_amount) || 0,
      pipeline_id: form.pipeline_id || null,
      pipeline_name: form.pipeline_name || null,
      created_by_name: currentUser?.full_name,
    };
    try {
      if (editingGoal) {
        await api.entities.AgentGoal.update(editingGoal.id, payload);
      } else {
        await api.entities.AgentGoal.create(payload);
      }
      toast({ title: 'Meta guardada correctamente' });
      setShowForm(false);
      loadData();
    } catch (e) {
      toast({ title: 'Error al guardar', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Eliminar esta meta?')) return;
    await api.entities.AgentGoal.delete(id);
    setGoals(prev => prev.filter(g => g.id !== id));
  };

  const handleAgentSelect = (agentId) => {
    const agent = agents.find(a => a.id === agentId);
    setForm(f => ({ ...f, agent_id: agentId, agent_name: agent?.full_name || '', agent_email: agent?.email || '' }));
  };

  const handlePipelineSelect = (pid) => {
    const p = pipelines.find(p => p.id === pid);
    setForm(f => ({ ...f, pipeline_id: pid === '__all__' ? '' : pid, pipeline_name: pid === '__all__' ? '' : (p?.name || '') }));
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Target className="h-6 w-6 text-brand" />
              Metas de Agentes
            </h1>
            <p className="text-slate-500 text-sm mt-1">Seguimiento de objetivos por período</p>
          </div>
          <div className="flex items-center gap-3">
            {/* Period navigator */}
            <div className="flex items-center gap-1 border rounded-lg bg-white px-1 py-1">
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setPeriodDate(d => subMonths(d, 1))}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm font-medium text-slate-700 px-2 capitalize">{periodDisplay}</span>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setPeriodDate(d => addMonths(d, 1))}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            {isAdmin && (
              <Button onClick={openNew} className="bg-brand hover:bg-brand-dark gap-2">
                <Plus className="h-4 w-4" /> Nueva Meta
              </Button>
            )}
          </div>
        </div>

        {/* Goals Grid */}
        {goals.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Target className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p className="text-slate-500 font-medium">No hay metas para {periodDisplay}</p>
              {isAdmin && <p className="text-slate-400 text-sm mt-1">Haz clic en "Nueva Meta" para agregar una</p>}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {goals.map(goal => {
              const { wonLeads, wonAmount } = getActuals(goal.agent_id, goal.pipeline_id);
              const allDone = goal.target_leads > 0 && wonLeads >= goal.target_leads && goal.target_amount > 0 && wonAmount >= goal.target_amount;
              return (
                <Card key={goal.id} className={cn("shadow-sm", allDone && "border-green-300 bg-green-50/40")}>
                  <CardHeader className="pb-3 pt-4 px-5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <CardTitle className="text-base text-slate-800">{goal.agent_name}</CardTitle>
                        <p className="text-xs text-slate-500 mt-0.5">{goal.pipeline_name || 'Todos los pipelines'}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        {allDone && <Badge className="bg-green-100 text-green-700 border-0 text-xs">🎉 Cumplido</Badge>}
                        {isAdmin && (
                          <>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-blue-600" onClick={() => openEdit(goal)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-600" onClick={() => handleDelete(goal.id)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="px-5 pb-5 space-y-3">
                    {goal.target_leads > 0 && (
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs text-slate-600">
                          <span className="flex items-center gap-1"><Trophy className="h-3 w-3 text-amber-500" /> Leads ganados</span>
                          <span className="font-semibold">{wonLeads} / {goal.target_leads}</span>
                        </div>
                        <ProgressBar value={wonLeads} max={goal.target_leads} />
                      </div>
                    )}
                    {goal.target_amount > 0 && (
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs text-slate-600">
                          <span className="flex items-center gap-1"><TrendingUp className="h-3 w-3 text-blue-500" /> Prima total</span>
                          <span className="font-semibold">${wonAmount.toLocaleString()} / ${goal.target_amount.toLocaleString()}</span>
                        </div>
                        <ProgressBar value={wonAmount} max={goal.target_amount} />
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Form Modal */}
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingGoal ? 'Editar Meta' : 'Nueva Meta'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <Label>Agente</Label>
                <Select value={form.agent_id} onValueChange={handleAgentSelect}>
                  <SelectTrigger><SelectValue placeholder="Seleccionar agente" /></SelectTrigger>
                  <SelectContent>
                    {agents.map(a => (
                      <SelectItem key={a.id} value={a.id}>{a.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Pipeline (opcional)</Label>
                <Select value={form.pipeline_id || '__all__'} onValueChange={handlePipelineSelect}>
                  <SelectTrigger><SelectValue placeholder="Todos los pipelines" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__all__">Todos los pipelines</SelectItem>
                    {pipelines.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Meta de leads ganados</Label>
                  <Input type="number" min="0" placeholder="0" value={form.target_leads}
                    onChange={e => setForm(f => ({ ...f, target_leads: e.target.value }))} />
                </div>
                <div className="space-y-1.5">
                  <Label>Meta de prima ($)</Label>
                  <Input type="number" min="0" placeholder="0" value={form.target_amount}
                    onChange={e => setForm(f => ({ ...f, target_amount: e.target.value }))} />
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setShowForm(false)}>Cancelar</Button>
                <Button className="flex-1 bg-brand hover:bg-brand-dark" onClick={handleSave} disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Guardar'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}