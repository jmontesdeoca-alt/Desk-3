import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Download, Search, RotateCcw, Trash2, Archive } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const BRANCH_COLORS = {
  'Vida': 'bg-blue-100 text-blue-800',
  'Salud': 'bg-green-100 text-green-800',
  'Viaje': 'bg-purple-100 text-purple-800',
  'Inversiones': 'bg-yellow-100 text-yellow-800',
  'General': 'bg-slate-100 text-slate-800'
};

export default function AbandonedLeadsPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [leadToRestore, setLeadToRestore] = useState(null);
  const [leadToDelete, setLeadToDelete] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const { data: leads = [], isLoading } = useQuery({
    queryKey: ['abandoned-leads'],
    queryFn: () => api.entities.Lead.filter({ lead_status: 'ABANDONADO' }, '-last_activity_at')
  });

  const restoreLead = useMutation({
    mutationFn: async (leadId) => {
      await api.entities.Lead.update(leadId, {
        lead_status: 'ACTIVO'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['abandoned-leads'] });
      setLeadToRestore(null);
      toast.success('Lead restaurado correctamente');
    }
  });

  const deleteLead = useMutation({
    mutationFn: async (leadId) => {
      await api.entities.Lead.delete(leadId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['abandoned-leads'] });
      setLeadToDelete(null);
      toast.success('Lead eliminado');
    }
  });

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const response = await api.functions.invoke('exportAbandonedLeads');
      const blob = new Blob([response.data], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `leads_abandonados_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success('Archivo exportado correctamente');
    } catch (error) {
      console.error('Error exporting:', error);
      toast.error('Error al exportar el archivo');
    } finally {
      setIsExporting(false);
    }
  };

  const filteredLeads = leads.filter(lead => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      lead.prospect_name?.toLowerCase().includes(search) ||
      lead.external_id?.toLowerCase().includes(search) ||
      lead.assigned_agent_name?.toLowerCase().includes(search) ||
      lead.branch?.toLowerCase().includes(search)
    );
  });

  const formatCurrency = (amount, currency) => {
    if (!amount) return '-';
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency || 'USD'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand mx-auto"></div>
          <p className="mt-4 text-slate-600">Cargando leads abandonados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">
              Leads Abandonados
            </h1>
            <p className="text-slate-600">
              {leads.length} {leads.length === 1 ? 'lead abandonado' : 'leads abandonados'}
            </p>
          </div>

          <Button
            onClick={handleExport}
            disabled={isExporting || leads.length === 0}
            className="bg-green-600 hover:bg-green-700"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar a Excel
          </Button>
        </div>

        {/* Búsqueda */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar por prospecto, ID, agente o ramo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {filteredLeads.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Archive className="h-16 w-16 text-slate-300 mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">
              {searchTerm ? 'No se encontraron resultados' : 'No hay leads abandonados'}
            </h3>
            <p className="text-slate-600 text-center">
              {searchTerm
                ? 'Intenta con otro término de búsqueda'
                : 'Los leads marcados como abandonados aparecerán aquí'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Prospecto</TableHead>
                <TableHead>Ramo</TableHead>
                <TableHead>Agente</TableHead>
                <TableHead>Prima</TableHead>
                <TableHead>Última Actividad</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLeads.map((lead) => {
                const daysSinceActivity = lead.last_activity_at
                  ? Math.floor((new Date() - new Date(lead.last_activity_at)) / (1000 * 60 * 60 * 24))
                  : null;

                return (
                  <TableRow key={lead.id}>
                    <TableCell className="font-mono text-sm">
                      {lead.external_id}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{lead.prospect_name}</div>
                      {lead.company_name && (
                        <div className="text-sm text-slate-500">{lead.company_name}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={BRANCH_COLORS[lead.branch] || BRANCH_COLORS['General']}>
                        {lead.branch}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {lead.assigned_agent_name}
                    </TableCell>
                    <TableCell>
                      {formatCurrency(lead.premium_estimated, lead.currency)}
                    </TableCell>
                    <TableCell>
                      {lead.last_activity_at ? (
                        <div>
                          <div className="text-sm">
                            {new Date(lead.last_activity_at).toLocaleDateString('es-ES')}
                          </div>
                          <div className="text-xs text-slate-500">
                            Hace {daysSinceActivity} días
                          </div>
                        </div>
                      ) : (
                        <span className="text-slate-400">Sin actividad</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setLeadToRestore(lead)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <RotateCcw className="h-4 w-4 mr-1" />
                          Restaurar
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setLeadToDelete(lead)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Diálogo de confirmación de restauración */}
      <AlertDialog open={!!leadToRestore} onOpenChange={() => setLeadToRestore(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Restaurar lead?</AlertDialogTitle>
            <AlertDialogDescription>
              El lead "{leadToRestore?.prospect_name}" volverá a aparecer en tu pipeline activo.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => restoreLead.mutate(leadToRestore.id)}
              className="bg-brand hover:bg-brand-dark"
            >
              Restaurar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Diálogo de confirmación de eliminación */}
      <AlertDialog open={!!leadToDelete} onOpenChange={() => setLeadToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar lead permanentemente?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El lead "{leadToDelete?.prospect_name}" será eliminado de forma permanente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteLead.mutate(leadToDelete.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}