import React, { useState, useEffect, useMemo, useRef } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import {
  Plus, Search, User, Mail, Phone, Globe, Edit, Trash2,
  Target, Loader2, MoreVertical, CreditCard, Upload,
  Merge, Users, ArrowUpDown, ArrowUp, ArrowDown,
  Filter, X, CheckSquare, Square, ChevronLeft, ChevronRight
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import ProspectForm from '@/modules/crm/components/prospects/ProspectForm';
import LeadForm from '@/modules/crm/components/leads/LeadForm';
import ProspectImporter from '@/modules/crm/components/prospects/ProspectImporter';
import MergeProspectsDialog from '@/modules/crm/components/prospects/MergeProspectsDialog';
import ReassignAgentDialog from '@/modules/crm/components/prospects/ReassignAgentDialog';
import { cn } from '@/lib/utils';

const SORT_OPTIONS = [
  { value: 'created_date_desc', label: 'Fecha creación (más nuevo)', field: 'created_date', dir: 'desc' },
  { value: 'created_date_asc', label: 'Fecha creación (más antiguo)', field: 'created_date', dir: 'asc' },
  { value: 'last_activity_desc', label: 'Última actividad (reciente)', field: 'last_activity_at', dir: 'desc' },
  { value: 'last_activity_asc', label: 'Última actividad (antigua)', field: 'last_activity_at', dir: 'asc' },
  { value: 'name_asc', label: 'Nombre (A-Z)', field: 'full_name', dir: 'asc' },
  { value: 'name_desc', label: 'Nombre (Z-A)', field: 'full_name', dir: 'desc' },
  { value: 'agent_asc', label: 'Agente (A-Z)', field: 'assigned_agent_name', dir: 'asc' },
];

function SortIcon({ field, currentField, currentDir }) {
  if (field !== currentField) return <ArrowUpDown className="h-3.5 w-3.5 text-slate-400" />;
  return currentDir === 'asc'
    ? <ArrowUp className="h-3.5 w-3.5 text-blue-600" />
    : <ArrowDown className="h-3.5 w-3.5 text-blue-600" />;
}

export default function Prospects() {
  const [prospects, setProspects] = useState([]);
  const [leads, setLeads] = useState([]);
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);

  // Filters & sort
  const [search, setSearch] = useState('');
  const [filterAgent, setFilterAgent] = useState('all');
  const [filterSource, setFilterSource] = useState('all');
  const [sortField, setSortField] = useState('created_date');
  const [sortDir, setSortDir] = useState('desc');

  // Pagination
  const [pageSize, setPageSize] = useState(50);
  const [currentPage, setCurrentPage] = useState(1);

  // Selection
  const [selected, setSelected] = useState(new Set());

  // Modals
  const [showProspectForm, setShowProspectForm] = useState(false);
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [selectedProspect, setSelectedProspect] = useState(null);
  const [leadProspectId, setLeadProspectId] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [showImporter, setShowImporter] = useState(false);
  const [mergeProspect, setMergeProspect] = useState(null);
  const [showReassign, setShowReassign] = useState(false);
  const [reassignSingle, setReassignSingle] = useState(null); // single from row menu

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
      setUserRole(user.crm_role || 'agente_crm');

      const canSeeAll = user.crm_role === 'admin_crm' || user.crm_role === 'jefatura_crm' || user.role === 'admin';

      const [prospectsData, leadsData] = await Promise.all([
        canSeeAll
          ? api.entities.Prospect.list('-created_date', 20000)
          : api.entities.Prospect.filter({ assigned_agent_id: user.id }, '-created_date', 20000),
        api.entities.Lead.list('-created_date', 20000),
      ]);

      setProspects(prospectsData);
      setLeads(leadsData);

      // Build unique agent list from prospects
      const agentMap = {};
      prospectsData.forEach(p => {
        if (p.assigned_agent_id && p.assigned_agent_name) {
          agentMap[p.assigned_agent_id] = p.assigned_agent_name;
        }
      });
      setAgents(Object.entries(agentMap).map(([id, name]) => ({ id, name })));
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const filteredAndSorted = useMemo(() => {
    let list = [...prospects];

    // Search
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(p =>
        p.full_name?.toLowerCase().includes(q) ||
        p.email?.toLowerCase().includes(q) ||
        p.phone?.includes(search) ||
        p.id_number?.includes(search)
      );
    }

    // Agent filter
    if (filterAgent !== 'all') {
      list = list.filter(p => p.assigned_agent_id === filterAgent);
    }

    // Source filter
    if (filterSource !== 'all') {
      list = list.filter(p => p.source === filterSource);
    }

    // Sort
    list.sort((a, b) => {
      let valA = a[sortField] ?? '';
      let valB = b[sortField] ?? '';
      if (valA < valB) return sortDir === 'asc' ? -1 : 1;
      if (valA > valB) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });

    return list;
  }, [prospects, search, filterAgent, filterSource, sortField, sortDir]);

  // Reset to page 1 when filters/sort change
  const prevFilterRef = useRef('');
  const filterKey = `${search}|${filterAgent}|${filterSource}|${sortField}|${sortDir}`;
  if (prevFilterRef.current !== filterKey) {
    prevFilterRef.current = filterKey;
    if (currentPage !== 1) setCurrentPage(1);
  }

  const totalPages = Math.max(1, Math.ceil(filteredAndSorted.length / pageSize));
  const paginatedProspects = filteredAndSorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const getLeadCount = (prospectId) => leads.filter(l => l.prospect_id === prospectId).length;

  const toggleSelect = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    const pageIds = paginatedProspects.map(p => p.id);
    const allSelected = pageIds.every(id => selected.has(id));
    setSelected(prev => {
      const next = new Set(prev);
      if (allSelected) pageIds.forEach(id => next.delete(id));
      else pageIds.forEach(id => next.add(id));
      return next;
    });
  };

  const selectedProspects = filteredAndSorted.filter(p => selected.has(p.id));

  const handleDelete = async () => {
    if (!deleteConfirm) return;
    try {
      await api.entities.Prospect.delete(deleteConfirm.id);
      setProspects(prospects.filter(p => p.id !== deleteConfirm.id));
    } catch (error) {
      console.error('Error deleting prospect:', error);
    }
    setDeleteConfirm(null);
  };

  const clearFilters = () => {
    setSearch('');
    setFilterAgent('all');
    setFilterSource('all');
  };

  const hasFilters = search || filterAgent !== 'all' || filterSource !== 'all';
  const isAdmin = userRole === 'admin_crm' || userRole === 'jefatura_crm' || currentUser?.role === 'admin';
  const isAgente = !isAdmin;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-4">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Prospectos</h1>
            <p className="text-slate-500 dark:text-zinc-400 mt-1">
              {filteredAndSorted.length} de {prospects.length} prospectos
              {isAgente ? ' asignados a ti' : ' en total'}
              {totalPages > 1 && ` · Página ${currentPage} de ${totalPages}`}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowImporter(true)} className="gap-2">
              <Upload className="h-4 w-4" />
              Importar Excel
            </Button>
            <Button
              onClick={() => { setSelectedProspect(null); setShowProspectForm(true); }}
              className="gap-2 bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              Nuevo Prospecto
            </Button>
          </div>
        </div>

        {/* Filters Bar */}
        <Card className="p-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Buscar por nombre, email, teléfono, cédula..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>

            {isAdmin && (
              <Select value={filterAgent} onValueChange={setFilterAgent}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Agente" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los agentes</SelectItem>
                  {agents.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Select value={filterSource} onValueChange={setFilterSource}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Origen" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los orígenes</SelectItem>
                <SelectItem value="meta">Meta Ads</SelectItem>
                <SelectItem value="manual">Manual</SelectItem>
                <SelectItem value="web">Web</SelectItem>
                <SelectItem value="referido">Referido</SelectItem>
                <SelectItem value="otro">Otro</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={`${sortField}_${sortDir}`}
              onValueChange={val => {
                const opt = SORT_OPTIONS.find(o => o.value === val);
                if (opt) { setSortField(opt.field); setSortDir(opt.dir); }
              }}
            >
              <SelectTrigger className="w-52">
                <ArrowUpDown className="h-3.5 w-3.5 mr-1.5 text-slate-400" />
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                {SORT_OPTIONS.map(opt => (
                  <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {hasFilters && (
              <Button variant="ghost" onClick={clearFilters} className="gap-1.5 text-slate-500 shrink-0">
                <X className="h-4 w-4" />
                Limpiar
              </Button>
            )}
          </div>
        </Card>

        {/* Bulk Actions Bar */}
        {selected.size > 0 && (
          <div className="flex items-center gap-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg px-4 py-2.5">
            <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
              {selected.size} seleccionado{selected.size > 1 ? 's' : ''}
            </span>
            <div className="flex gap-2 ml-auto">
              {isAdmin && (
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 text-blue-700 border-blue-300"
                  onClick={() => { setReassignSingle(null); setShowReassign(true); }}
                >
                  <Users className="h-3.5 w-3.5" />
                  Reasignar agente
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                className="text-slate-500"
                onClick={() => setSelected(new Set())}
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}

        {/* Table */}
        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50 dark:bg-zinc-800">
                <TableHead className="w-10">
                  <button onClick={toggleSelectAll} className="flex items-center justify-center">
                    {paginatedProspects.length > 0 && paginatedProspects.every(p => selected.has(p.id))
                      ? <CheckSquare className="h-4 w-4 text-blue-600" />
                      : <Square className="h-4 w-4 text-slate-400" />
                    }
                  </button>
                </TableHead>
                <TableHead
                  className="font-semibold dark:text-zinc-300 cursor-pointer select-none"
                  onClick={() => handleSort('full_name')}
                >
                  <span className="flex items-center gap-1.5">
                    Prospecto <SortIcon field="full_name" currentField={sortField} currentDir={sortDir} />
                  </span>
                </TableHead>
                <TableHead className="font-semibold dark:text-zinc-300">Identificación</TableHead>
                <TableHead className="font-semibold dark:text-zinc-300">Contacto</TableHead>
                <TableHead className="font-semibold dark:text-zinc-300">País</TableHead>
                <TableHead
                  className="font-semibold dark:text-zinc-300 cursor-pointer select-none"
                  onClick={() => handleSort('assigned_agent_name')}
                >
                  <span className="flex items-center gap-1.5">
                    Agente <SortIcon field="assigned_agent_name" currentField={sortField} currentDir={sortDir} />
                  </span>
                </TableHead>
                <TableHead className="font-semibold dark:text-zinc-300">Leads</TableHead>
                <TableHead
                  className="font-semibold dark:text-zinc-300 cursor-pointer select-none"
                  onClick={() => handleSort('created_date')}
                >
                  <span className="flex items-center gap-1.5">
                    Creado <SortIcon field="created_date" currentField={sortField} currentDir={sortDir} />
                  </span>
                </TableHead>
                <TableHead className="font-semibold dark:text-zinc-300 text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedProspects.map(prospect => (
                <TableRow
                  key={prospect.id}
                  className={cn(
                    "hover:bg-slate-50/50 dark:hover:bg-zinc-800/60 dark:border-zinc-700",
                    selected.has(prospect.id) && "bg-blue-50/50 dark:bg-blue-950/20"
                  )}
                >
                  <TableCell>
                    <button onClick={() => toggleSelect(prospect.id)}>
                      {selected.has(prospect.id)
                        ? <CheckSquare className="h-4 w-4 text-blue-600" />
                        : <Square className="h-4 w-4 text-slate-300 dark:text-zinc-600" />
                      }
                    </button>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center shrink-0">
                        <User className="h-4 w-4 text-blue-600 dark:text-blue-300" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900 dark:text-white text-sm">{prospect.full_name}</p>
                        {prospect.source && prospect.source !== 'manual' && (
                          <Badge variant="outline" className="text-xs mt-0.5">{prospect.source}</Badge>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    {prospect.id_type && prospect.id_number ? (
                      <div className="flex items-center gap-1.5 text-slate-600 dark:text-zinc-300">
                        <CreditCard className="h-3.5 w-3.5 shrink-0" />
                        <span className="text-sm">{prospect.id_type}: {prospect.id_number}</span>
                      </div>
                    ) : (
                      <span className="text-slate-400 dark:text-zinc-600 text-sm">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      {prospect.email && (
                        <div className="flex items-center gap-1.5 text-slate-600 dark:text-zinc-300">
                          <Mail className="h-3.5 w-3.5 shrink-0" />
                          <span className="text-sm truncate max-w-[160px]">{prospect.email}</span>
                        </div>
                      )}
                      {prospect.phone && (
                        <div className="flex items-center gap-1.5 text-slate-500 dark:text-zinc-400">
                          <Phone className="h-3.5 w-3.5 shrink-0" />
                          <span className="text-sm">{prospect.phone}</span>
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    {prospect.country ? (
                      <div className="flex items-center gap-1.5 text-slate-600 dark:text-zinc-300">
                        <Globe className="h-3.5 w-3.5" />
                        <span className="text-sm">{prospect.country}</span>
                      </div>
                    ) : (
                      <span className="text-slate-400 dark:text-zinc-600 text-sm">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-slate-600 dark:text-zinc-300 text-sm">
                    {prospect.assigned_agent_name || '—'}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300">
                      {getLeadCount(prospect.id)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-slate-500 dark:text-zinc-400 text-sm">
                    {prospect.created_date && !isNaN(new Date(prospect.created_date))
                      ? format(new Date(prospect.created_date), 'dd MMM yyyy', { locale: es })
                      : '—'}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu onOpenChange={(open) => open && setSelectedProspect(prospect)}>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setSelectedProspect(prospect);
                          setLeadProspectId(prospect.id);
                          setShowLeadForm(true);
                        }}>
                          <Target className="mr-2 h-4 w-4" />
                          Crear Lead
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setSelectedProspect(prospect);
                          setShowProspectForm(true);
                        }}>
                          <Edit className="mr-2 h-4 w-4" />
                          Editar
                        </DropdownMenuItem>
                        {isAdmin && (
                          <DropdownMenuItem onClick={() => {
                            setReassignSingle(prospect);
                            setShowReassign(true);
                          }}>
                            <Users className="mr-2 h-4 w-4" />
                            Cambiar agente
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => setMergeProspect(prospect)}>
                          <Merge className="mr-2 h-4 w-4" />
                          Fusionar duplicado
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => setDeleteConfirm(prospect)}
                          className="text-red-600"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Eliminar
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}

              {filteredAndSorted.length === 0 && (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12 text-slate-500 dark:text-zinc-400">
                    {hasFilters ? (
                      <div className="flex flex-col items-center gap-2">
                        <Filter className="h-8 w-8 text-slate-300" />
                        <p>No se encontraron prospectos con estos filtros</p>
                        <Button variant="ghost" size="sm" onClick={clearFilters}>Limpiar filtros</Button>
                      </div>
                    ) : 'No hay prospectos registrados'}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>

        {/* Pagination footer */}
        {filteredAndSorted.length > 0 && (
          <div className="flex items-center justify-between gap-4 px-1">
            <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-zinc-400">
              <span>Filas por página:</span>
              <Select value={String(pageSize)} onValueChange={v => { setPageSize(Number(v)); setCurrentPage(1); }}>
                <SelectTrigger className="w-20 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                </SelectContent>
              </Select>
              <span className="hidden sm:inline">
                {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, filteredAndSorted.length)} de {filteredAndSorted.length}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="outline" size="icon"
                className="h-8 w-8"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(1)}
              >
                <ChevronLeft className="h-3.5 w-3.5" /><ChevronLeft className="h-3.5 w-3.5 -ml-2" />
              </Button>
              <Button
                variant="outline" size="icon"
                className="h-8 w-8"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => p - 1)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm text-slate-600 dark:text-zinc-300 px-2 font-medium">
                {currentPage} / {totalPages}
              </span>
              <Button
                variant="outline" size="icon"
                className="h-8 w-8"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(p => p + 1)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                variant="outline" size="icon"
                className="h-8 w-8"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(totalPages)}
              >
                <ChevronRight className="h-3.5 w-3.5" /><ChevronRight className="h-3.5 w-3.5 -ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* Modals */}
        <ProspectForm
          open={showProspectForm}
          onClose={() => { setShowProspectForm(false); setSelectedProspect(null); }}
          prospect={selectedProspect}
          onSaved={() => { loadData(); setSelectedProspect(null); }}
        />

        <ProspectImporter
          open={showImporter}
          onClose={() => setShowImporter(false)}
          onImported={() => { loadData(); setShowImporter(false); }}
        />

        <LeadForm
          open={showLeadForm}
          onClose={() => { setShowLeadForm(false); setSelectedProspect(null); setLeadProspectId(null); }}
          prospectId={leadProspectId}
          onSaved={() => { loadData(); setSelectedProspect(null); }}
        />

        <MergeProspectsDialog
          open={!!mergeProspect}
          onClose={() => setMergeProspect(null)}
          sourceProspect={mergeProspect}
          allProspects={prospects}
          onMerged={() => { loadData(); setMergeProspect(null); }}
        />

        <ReassignAgentDialog
          open={showReassign}
          onClose={() => { setShowReassign(false); setReassignSingle(null); }}
          prospects={reassignSingle ? [reassignSingle] : selectedProspects}
          onReassigned={() => {
            loadData();
            setSelected(new Set());
            setReassignSingle(null);
          }}
        />

        <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar este prospecto?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. El prospecto "{deleteConfirm?.full_name}" será eliminado permanentemente.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}