import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  CheckCircle2, Clock, Calendar as CalendarIcon,
  Phone, Mail, Video, AlertCircle, X
} from "lucide-react";
import { format, isPast, isToday, isTomorrow } from "date-fns";
import { es } from "date-fns/locale";
import { cn } from "@/lib/utils";

const REMINDER_ICONS = {
  seguimiento: Clock,
  llamada: Phone,
  email: Mail,
  reunión: Video,
  otro: AlertCircle
};

export default function TasksPage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [filter, setFilter] = useState('all');
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const { data: reminders = [], isLoading } = useQuery({
    queryKey: ['reminders', currentUser?.id],
    queryFn: async () => {
      if (!currentUser) return [];
      return await api.entities.FollowUpReminder.filter({ 
        assigned_to_id: currentUser.id,
        status: 'pendiente'
      }, '-reminder_date');
    },
    enabled: !!currentUser
  });

  const completeReminderMutation = useMutation({
    mutationFn: async (reminderId) => {
      await api.entities.FollowUpReminder.update(reminderId, {
        status: 'completado',
        completed_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
    }
  });

  const cancelReminderMutation = useMutation({
    mutationFn: async (reminderId) => {
      await api.entities.FollowUpReminder.update(reminderId, {
        status: 'cancelado'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
    }
  });

  const getDateBadge = (dateStr) => {
    const date = new Date(dateStr);
    const now = new Date();

    if (isPast(date) && !isToday(date)) {
      return <Badge variant="destructive">Vencido</Badge>;
    }
    if (isToday(date)) {
      return <Badge className="bg-orange-500">Hoy</Badge>;
    }
    if (isTomorrow(date)) {
      return <Badge className="bg-blue-500">Mañana</Badge>;
    }
    return <Badge variant="outline">Próximo</Badge>;
  };

  const filteredReminders = reminders.filter(reminder => {
    const date = new Date(reminder.reminder_date);
    const now = new Date();

    if (filter === 'overdue') return isPast(date) && !isToday(date);
    if (filter === 'today') return isToday(date);
    if (filter === 'upcoming') return !isPast(date) && !isToday(date);
    return true;
  });

  const overdueCount = reminders.filter(r => isPast(new Date(r.reminder_date)) && !isToday(new Date(r.reminder_date))).length;
  const todayCount = reminders.filter(r => isToday(new Date(r.reminder_date))).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand mx-auto"></div>
          <p className="mt-4 text-slate-600">Cargando tareas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">
          Tareas Pendientes
        </h1>
        <p className="text-slate-600 dark:text-zinc-400">
          Gestiona tus recordatorios y seguimientos de leads
        </p>
      </div>

      {/* Filtros */}
      <div className="flex gap-2 mb-6 flex-wrap">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          onClick={() => setFilter('all')}
          className={filter === 'all' ? 'bg-brand' : ''}
        >
          Todas ({reminders.length})
        </Button>
        <Button
          variant={filter === 'overdue' ? 'default' : 'outline'}
          onClick={() => setFilter('overdue')}
          className={filter === 'overdue' ? 'bg-red-600' : ''}
        >
          Vencidas ({overdueCount})
        </Button>
        <Button
          variant={filter === 'today' ? 'default' : 'outline'}
          onClick={() => setFilter('today')}
          className={filter === 'today' ? 'bg-orange-500' : ''}
        >
          Hoy ({todayCount})
        </Button>
        <Button
          variant={filter === 'upcoming' ? 'default' : 'outline'}
          onClick={() => setFilter('upcoming')}
        >
          Próximas ({reminders.length - overdueCount - todayCount})
        </Button>
      </div>

      {/* Lista de recordatorios */}
      {filteredReminders.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Clock className="h-16 w-16 text-slate-300 mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">
              No hay tareas pendientes
            </h3>
            <p className="text-slate-600 text-center">
              {filter === 'all' 
                ? 'No tienes recordatorios pendientes en este momento.'
                : 'No hay recordatorios en esta categoría.'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredReminders.map((reminder) => {
            const Icon = REMINDER_ICONS[reminder.reminder_type] || Clock;
            const isPastDue = isPast(new Date(reminder.reminder_date)) && !isToday(new Date(reminder.reminder_date));

            return (
              <Card
                key={reminder.id}
                className={cn(
                  "transition-all hover:shadow-md",
                  isPastDue && "border-red-300 bg-red-50/50"
                )}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                      isPastDue ? "bg-red-100" : "bg-brand/10"
                    )}>
                      <Icon className={cn(
                        "h-5 w-5",
                        isPastDue ? "text-red-600" : "text-brand"
                      )} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div>
                          <Link
                            to={createPageUrl('Pipeline')}
                            className="font-semibold text-slate-900 hover:text-brand transition-colors"
                          >
                            {reminder.prospect_name}
                          </Link>
                          <p className="text-sm text-slate-600 mt-1">
                            {reminder.description || 'Sin descripción'}
                          </p>
                        </div>
                        {getDateBadge(reminder.reminder_date)}
                      </div>

                      <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
                        <div className="flex items-center gap-1">
                          <CalendarIcon className="h-4 w-4" />
                          {format(new Date(reminder.reminder_date), "d 'de' MMMM, yyyy 'a las' HH:mm", { locale: es })}
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {reminder.reminder_type}
                        </Badge>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => completeReminderMutation.mutate(reminder.id)}
                          disabled={completeReminderMutation.isPending}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle2 className="h-4 w-4 mr-1" />
                          Completar
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => cancelReminderMutation.mutate(reminder.id)}
                          disabled={cancelReminderMutation.isPending}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}