import React, { useState, useEffect, useMemo, useDeferredValue } from 'react';
import { safeStorage } from '@/lib/safeStorage';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, LayoutGrid, List, Loader2, Archive, Download, Layers } from "lucide-react";
import ChatbotWidget from '@/modules/ia/components/chat/ChatbotWidget';
import { useModules } from '@/lib/ModulesContext';
import { useBrand } from '@/components/ui/BrandProvider';
import { differenceInDays } from 'date-fns';
import PipelineKanban from '@/modules/crm/components/leads/PipelineKanban';
import LeadsList from '@/modules/crm/components/leads/LeadsList';
import LeadFilters from '@/modules/crm/components/leads/LeadFilters';
import LeadForm from '@/modules/crm/components/leads/LeadForm';
import ActivityForm from '@/modules/crm/components/leads/ActivityForm';
import ReminderForm from '@/modules/crm/components/leads/ReminderForm';
import LeadDetails from '@/modules/crm/components/leads/LeadDetails';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Pipeline() {
  const { isEnabled } = useModules();
  const { brand } = useBrand();
  const [leads, setLeads] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [selectedPipelineId, setSelectedPipelineId] = useState(() => {
    return safeStorage.getItem('pipeline_selected_id') || null;
  });
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [viewMode, setViewMode] = useState('kanban');
  const [statusTab, setStatusTab] = useState('activo');
  const [exporting, setExporting] = useState(false);
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [showActivityForm, setShowActivityForm] = useState(false);
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [showLeadDetails, setShowLeadDetails] = useState(false);
  const [selectedLead, setSelectedLead] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [filters, setFilters] = useState({
    search: '',
    branch: '',
    stage: '',
    agent_id: '',
    country: '',
    min_premium: '',
    max_premium: '',
    days_inactive: '',
    lead_status: 'ACTIVO',
    tag_id: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [user, leadsData, pipelinesData] = await Promise.all([
        api.auth.me(),
        api.entities.Lead.list('-last_activity_at', 20000),
        api.entities.Pipeline.filter({ is_active: true }, 'sort_order', 20)
      ]);
      const role = user.role === 'admin' ? 'admin_crm' : (user.crm_role || 'agente_crm');
      setCurrentUser(user);
      setUserRole(role);
      setLeads(leadsData);
      // Filter pipelines by visibility unless admin/jefatura
      const visiblePipelines = (role === 'admin_crm' || role === 'jefatura_crm')
        ? pipelinesData
        : pipelinesData.filter(p =>
            p.visibility_type !== 'specific_agents' ||
            (p.allowed_agent_ids || []).includes(user.id)
          );
      setPipelines(visiblePipelines);
      // Select stored pipeline or default to first one
      const storedId = safeStorage.getItem('pipeline_selected_id');
      const validStored = storedId && pipelinesData.find(p => p.id === storedId);
      if (!validStored && pipelinesData.length > 0) {
        // Default to B2C if available, otherwise first
        const b2c = pipelinesData.find(p => p.name === 'B2C');
        const defaultPipeline = b2c || pipelinesData[0];
        setSelectedPipelineId(defaultPipeline.id);
        safeStorage.setItem('pipeline_selected_id', defaultPipeline.id);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectedPipeline = useMemo(() => pipelines.find(p => p.id === selectedPipelineId), [pipelines, selectedPipelineId]);

  // El texto del buscador se aplica en segundo plano: la caja responde al instante aunque haya miles de leads
  const deferredSearch = useDeferredValue(filters.search);

  const filteredLeads = useMemo(() => {
    let result = leads;

    // Filter by selected pipeline
    if (selectedPipelineId) {
      result = result.filter(l => l.pipeline_id === selectedPipelineId);
    }

    // Filter by status tab
    if (statusTab === 'activo') {
      result = result.filter(l => l.lead_status === 'ACTIVO');
    } else if (statusTab === 'abandonado') {
      result = result.filter(l => l.lead_status === 'ABANDONADO');
    }

    // Filter by lead_status (if specified in filters)
    if (filters.lead_status && filters.lead_status !== statusTab.toUpperCase()) {
      result = result.filter(l => l.lead_status === filters.lead_status);
    }

    // Filter by agent for non-admin users
    if (userRole === 'agente_crm' || userRole === 'reclutador_crm') {
      result = result.filter(l => l.assigned_agent_id === currentUser?.id);
    } else if (filters.agent_id) {
      result = result.filter(l => l.assigned_agent_id === filters.agent_id);
    }

    // Search
    if (deferredSearch) {
      const search = deferredSearch.toLowerCase();
      result = result.filter(l => 
        l.prospect_name?.toLowerCase().includes(search) ||
        l.company_name?.toLowerCase().includes(search) ||
        l.external_id?.toLowerCase().includes(search)
      );
    }

    // Branch
    if (filters.branch) {
      result = result.filter(l => l.branch === filters.branch);
    }

    // Stage
    if (filters.stage) {
      result = result.filter(l => l.pipeline_stage === filters.stage);
    }

    // Premium range
    if (filters.min_premium) {
      result = result.filter(l => (l.premium_estimated || 0) >= parseFloat(filters.min_premium));
    }
    if (filters.max_premium) {
      result = result.filter(l => (l.premium_estimated || 0) <= parseFloat(filters.max_premium));
    }

    // Days inactive
    if (filters.days_inactive) {
      const days = parseInt(filters.days_inactive);
      result = result.filter(l => {
        if (!l.last_activity_at) return true;
        return differenceInDays(new Date(), new Date(l.last_activity_at)) > days;
      });
    }

    // Tag filter
    if (filters.tag_id) {
      result = result.filter(l => (l.tags || []).some(t => t.id === filters.tag_id));
    }

    return result;
  }, [leads, filters, deferredSearch, userRole, currentUser, statusTab, selectedPipelineId]);

  const handleEditLead = (lead) => {
    setSelectedLead(lead);
    setShowLeadForm(true);
  };

  const handleAddActivity = (lead) => {
    setSelectedLead(lead);
    setShowActivityForm(true);
  };

  const handleAddReminder = (lead) => {
    setSelectedLead(lead);
    setShowReminderForm(true);
  };

  const handleDeleteLead = async () => {
    if (!deleteConfirm) return;
    try {
      await api.entities.Lead.delete(deleteConfirm.id);
      setLeads(leads.filter(l => l.id !== deleteConfirm.id));
    } catch (error) {
      console.error('Error deleting lead:', error);
    }
    setDeleteConfirm(null);
  };

  const handleStageChange = (leadId, newStage) => {
    setLeads(leads.map(l => 
      l.id === leadId 
        ? { ...l, pipeline_stage: newStage, last_activity_at: new Date().toISOString() }
        : l
    ));
  };

  const handleLeadSaved = () => {
    loadData();
    setSelectedLead(null);
  };

  const handleActivitySaved = () => {
    loadData();
    setSelectedLead(null);
  };

  const handleArchiveLead = async (lead) => {
    try {
      const newStatus = lead.lead_status === 'ARCHIVADO' ? 'ACTIVO' : 'ARCHIVADO';
      await api.entities.Lead.update(lead.id, { lead_status: newStatus });
      loadData();
    } catch (error) {
      console.error('Error archiving lead:', error);
    }
  };

  const handleViewLead = (lead) => {
    setSelectedLead(lead);
    setShowLeadDetails(true);
  };

  const handleExportAbandoned = async () => {
    setExporting(true);
    try {
      const response = await api.functions.invoke('exportAbandonedLeads', {});
      const blob = new Blob([response.data], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `leads_abandonados_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    } catch (error) {
      console.error('Error exporting:', error);
      alert('Error al exportar leads abandonados');
    } finally {
      setExporting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-6">
      <div className="max-w-full mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-3">
          {/* Title row: title left, button right (both mobile and desktop) */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">Pipeline de Ventas</h1>
              <p className="text-slate-500 dark:text-zinc-400 text-sm mt-0.5">
                {filteredLeads.length} leads {(userRole === 'agente_crm' || userRole === 'reclutador_crm') ? 'asignados' : 'en total'}
              </p>
            </div>
            <Button 
              onClick={() => { setSelectedLead(null); setShowLeadForm(true); }}
              className="gap-2 h-10"
              style={{ backgroundColor: brand.primary_color }}
            >
              <Plus className="h-4 w-4" />
              <span>Nuevo Lead</span>
            </Button>
          </div>

          {/* Controls row: left on mobile, right on desktop */}
          <div className="flex flex-wrap items-center gap-2 md:justify-end">
            {pipelines.length > 1 && (
              <Select value={selectedPipelineId || ''} onValueChange={(v) => { setSelectedPipelineId(v); safeStorage.setItem('pipeline_selected_id', v); }}>
                <SelectTrigger className="w-[140px] bg-white dark:bg-zinc-800 border-slate-300 dark:border-zinc-600 h-9 dark:text-zinc-200">
                  <Layers className="h-4 w-4 mr-1 text-slate-400 shrink-0" />
                  <SelectValue placeholder="Pipeline" />
                </SelectTrigger>
                <SelectContent>
                  {pipelines.map(p => (
                    <SelectItem key={p.id} value={p.id}>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full inline-block shrink-0" style={{ backgroundColor: p.color || '#2F4F9D' }} />
                        {p.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Tabs value={statusTab} onValueChange={setStatusTab}>
              <TabsList className="bg-white dark:bg-zinc-800 border dark:border-zinc-600 h-9">
                <TabsTrigger value="activo" className="text-sm px-3">Activos</TabsTrigger>
                <TabsTrigger value="abandonado" className="gap-1.5 text-sm px-3">
                  <Archive className="h-3.5 w-3.5" />
                  Abandonados
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <Tabs value={viewMode} onValueChange={setViewMode}>
              <TabsList className="bg-white dark:bg-zinc-800 border dark:border-zinc-600 h-9">
                <TabsTrigger value="kanban" className="gap-1.5 text-sm px-3">
                  <LayoutGrid className="h-3.5 w-3.5" />
                  Kanban
                </TabsTrigger>
                <TabsTrigger value="list" className="gap-1.5 text-sm px-3">
                  <List className="h-3.5 w-3.5" />
                  Lista
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {statusTab === 'abandonado' && (
              <Button 
                onClick={handleExportAbandoned}
                disabled={exporting}
                variant="outline"
                className="gap-2 h-9 text-sm"
              >
                {exporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                Exportar
              </Button>
            )}
          </div>
        </div>

        {/* Filters */}
        <LeadFilters 
          filters={filters} 
          onFiltersChange={setFilters}
          userRole={userRole}
        />

        {/* Content */}
        {viewMode === 'kanban' ? (
          <PipelineKanban
            leads={filteredLeads}
            pipeline={selectedPipeline}
            onLeadEdit={handleEditLead}
            onLeadDelete={setDeleteConfirm}
            onAddActivity={handleAddActivity}
            onAddReminder={handleAddReminder}
            onStageChange={handleStageChange}
            onArchive={handleArchiveLead}
            onView={handleViewLead}
            onCloned={loadData}
          />
        ) : (
          <LeadsList
            leads={filteredLeads}
            onEdit={handleEditLead}
            onDelete={setDeleteConfirm}
            onAddActivity={handleAddActivity}
            onAddReminder={handleAddReminder}
            onArchive={handleArchiveLead}
            onView={handleViewLead}
            onCloned={loadData}
          />
        )}

        {/* Lead Form Modal */}
        <LeadForm
          open={showLeadForm}
          onClose={() => { setShowLeadForm(false); setSelectedLead(null); }}
          lead={selectedLead}
          onSaved={handleLeadSaved}
        />

        {/* Activity Form Modal */}
        <ActivityForm
          open={showActivityForm}
          onClose={() => { setShowActivityForm(false); setSelectedLead(null); }}
          lead={selectedLead}
          onSaved={handleActivitySaved}
        />

        {/* Reminder Form Modal */}
        <ReminderForm
          open={showReminderForm}
          onOpenChange={(open) => { setShowReminderForm(open); if (!open) setSelectedLead(null); }}
          lead={selectedLead}
          onSuccess={handleLeadSaved}
        />

        {/* Lead Details View */}
        <LeadDetails
          open={showLeadDetails}
          onClose={() => { setShowLeadDetails(false); setSelectedLead(null); }}
          leadId={selectedLead?.id}
          onStageChanged={handleStageChange}
        />

        {/* Delete Confirmation */}
        <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar este lead?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. El lead "{deleteConfirm?.prospect_name}" será eliminado permanentemente.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteLead} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* AI Chatbot */}
        {isEnabled('ia') && <ChatbotWidget leadContext={selectedLead} />}
      </div>
    </div>
  );
}