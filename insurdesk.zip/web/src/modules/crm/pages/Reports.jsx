import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { Button } from "@/components/ui/button";
import {
  TrendingUp, Users, Target, Award, DollarSign,
  Flame, Snowflake, CheckCircle, XCircle, Shield, Printer
} from 'lucide-react';

const BRANCHES = ['Vida', 'Salud', 'Viaje', 'Inversiones', 'General'];

const PERIOD_OPTIONS = [
  { value: '7', label: 'Últimos 7 días' },
  { value: '30', label: 'Últimos 30 días' },
  { value: '60', label: 'Últimos 60 días' },
  { value: '90', label: 'Últimos 90 días' },
  { value: '180', label: 'Últimos 6 meses' },
  { value: '365', label: 'Último año' },
  { value: 'all', label: 'Todo el tiempo' },
];

const COLORS = ['#2F4F9D', '#6F8CD0', '#8A94A6', '#2F8F83', '#C58A2E', '#C2503E', '#5B6B8C', '#A3B1D6'];

function StatCard({ title, value, subtitle, icon: Icon, color = 'text-slate-700', bg = 'bg-slate-50' }) {
  return (
    <Card className="border border-slate-200 dark:border-zinc-700">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-slate-500 dark:text-zinc-400 font-medium uppercase tracking-wide">{title}</p>
            <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
            {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
          </div>
          <div className={`p-2 rounded-lg ${bg}`}>
            <Icon className={`h-5 w-5 ${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Reports() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const [leads, setLeads] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [agents, setAgents] = useState([]);

  // Filters
  const [selectedPipeline, setSelectedPipeline] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [selectedAgent, setSelectedAgent] = useState('all');
  const [selectedBranch, setSelectedBranch] = useState('all');

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
      const admin = user?.role === 'admin' || user?.crm_role === 'admin_crm';
      setIsAdmin(admin);
      if (admin) {
        const [leadsData, pipelinesData, usersData] = await Promise.all([
          api.entities.Lead.list('-created_date', 20000),
          api.entities.Pipeline.list(),
          api.entities.User.list().catch(() => []),
        ]);
        setLeads(leadsData);
        setPipelines(pipelinesData);
        setAgents(usersData);
      }
    } catch (e) {
      console.error('Error loading reports:', e);
    } finally {
      setLoading(false);
    }
  };

  const filteredLeads = useMemo(() => {
    return leads.filter(lead => {
      // Period filter
      if (selectedPeriod !== 'all') {
        const days = parseInt(selectedPeriod);
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        const leadDate = new Date(lead.created_date);
        if (leadDate < cutoff) return false;
      }
      // Pipeline filter
      if (selectedPipeline !== 'all' && lead.pipeline_id !== selectedPipeline) return false;
      // Agent filter
      if (selectedAgent !== 'all' && lead.assigned_agent_id !== selectedAgent) return false;
      // Branch filter
      if (selectedBranch !== 'all' && lead.branch !== selectedBranch) return false;
      return true;
    });
  }, [leads, selectedPipeline, selectedPeriod, selectedAgent, selectedBranch]);

  const stats = useMemo(() => {
    const total = filteredLeads.length;

    // Find won/lost stages across pipelines
    const wonStageKeys = new Set();
    const lostStageKeys = new Set();
    pipelines.forEach(p => {
      (p.stages || []).forEach(s => {
        if (s.is_won) wonStageKeys.add(s.key);
        if (s.is_lost) lostStageKeys.add(s.key);
      });
    });

    const won = filteredLeads.filter(l => wonStageKeys.has(l.pipeline_stage)).length;
    const abandoned = filteredLeads.filter(l => l.lead_status === 'ABANDONADO').length;
    const archived = filteredLeads.filter(l => l.lead_status === 'ARCHIVADO').length;
    const active = filteredLeads.filter(l => l.lead_status === 'ACTIVO').length;

    // Hot/Cold: hot = last activity < 7 days, cold = last activity > 30 days
    const now = new Date();
    const hot = filteredLeads.filter(l => {
      if (!l.last_activity_at) return false;
      const diff = (now - new Date(l.last_activity_at)) / (1000 * 60 * 60 * 24);
      return diff <= 7;
    }).length;
    const cold = filteredLeads.filter(l => {
      const diff = l.last_activity_at
        ? (now - new Date(l.last_activity_at)) / (1000 * 60 * 60 * 24)
        : 999;
      return diff > 30;
    }).length;

    const totalPremium = filteredLeads.reduce((sum, l) => sum + (l.premium_estimated || 0), 0);
    const wonPremium = filteredLeads
      .filter(l => wonStageKeys.has(l.pipeline_stage))
      .reduce((sum, l) => sum + (l.premium_estimated || 0), 0);

    const conversionRate = total > 0 ? ((won / total) * 100).toFixed(1) : 0;

    return { total, won, abandoned, archived, active, hot, cold, totalPremium, wonPremium, conversionRate, wonStageKeys, lostStageKeys };
  }, [filteredLeads, pipelines]);

  // Leads by stage for selected pipeline
  const stageData = useMemo(() => {
    const pipeline = pipelines.find(p => p.id === selectedPipeline);
    if (!pipeline) {
      // Aggregate across all pipelines
      const stageMap = {};
      pipelines.forEach(p => {
        (p.stages || []).forEach(s => {
          if (!stageMap[s.key]) stageMap[s.key] = { name: s.label, count: 0, color: s.color };
          stageMap[s.key].count += filteredLeads.filter(l => l.pipeline_stage === s.key).length;
        });
      });
      return Object.values(stageMap).filter(s => s.count > 0);
    }
    return (pipeline.stages || []).map(s => ({
      name: s.label,
      count: filteredLeads.filter(l => l.pipeline_stage === s.key).length,
      color: s.color || '#2F4F9D',
    }));
  }, [filteredLeads, pipelines, selectedPipeline]);

  // Agent stats
  const agentStats = useMemo(() => {
    const map = {};
    filteredLeads.forEach(lead => {
      const id = lead.assigned_agent_id;
      const name = lead.assigned_agent_name || 'Sin asignar';
      if (!map[id]) map[id] = { name, total: 0, won: 0, premium: 0, wonPremium: 0 };
      map[id].total++;
      map[id].premium += lead.premium_estimated || 0;
      if (stats.wonStageKeys.has(lead.pipeline_stage)) {
        map[id].won++;
        map[id].wonPremium += lead.premium_estimated || 0;
      }
    });
    return Object.values(map)
      .map(a => ({ ...a, convRate: a.total > 0 ? ((a.won / a.total) * 100).toFixed(1) : 0 }))
      .sort((a, b) => b.won - a.won);
  }, [filteredLeads, stats.wonStageKeys]);

  // Top leads won
  const topWonLeads = useMemo(() => {
    return filteredLeads
      .filter(l => stats.wonStageKeys.has(l.pipeline_stage))
      .sort((a, b) => (b.premium_estimated || 0) - (a.premium_estimated || 0))
      .slice(0, 5);
  }, [filteredLeads, stats.wonStageKeys]);

  // Top active leads by premium
  const topActiveLeads = useMemo(() => {
    return filteredLeads
      .filter(l => l.lead_status === 'ACTIVO' && !stats.wonStageKeys.has(l.pipeline_stage))
      .sort((a, b) => (b.premium_estimated || 0) - (a.premium_estimated || 0))
      .slice(0, 5);
  }, [filteredLeads, stats.wonStageKeys]);

  // Branch distribution
  const branchData = useMemo(() => {
    const map = {};
    filteredLeads.forEach(l => {
      const b = l.branch || 'Sin ramo';
      map[b] = (map[b] || 0) + 1;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [filteredLeads]);

  const fmt = (n) => n?.toLocaleString('es-EC', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-brand rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <Shield className="h-16 w-16 text-slate-300" />
        <h2 className="text-xl font-semibold text-slate-600">Acceso restringido</h2>
        <p className="text-slate-400 text-sm">Solo los administradores pueden ver esta página.</p>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 md:p-6 max-w-screen-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-white">Reportes y Analítica</h1>
          <p className="text-sm text-slate-500 dark:text-zinc-400 mt-0.5">Panel de rendimiento del equipo comercial</p>
        </div>
        <Button onClick={handlePrint} variant="outline" className="gap-2 print:hidden shrink-0">
          <Printer className="h-4 w-4" />
          Imprimir PDF
        </Button>
      </div>

      {/* Filters */}
      <Card className="border border-slate-200 dark:border-zinc-700">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <Label className="text-xs text-slate-500 dark:text-zinc-400 mb-1 block">Período</Label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PERIOD_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-slate-500 dark:text-zinc-400 mb-1 block">Pipeline</Label>
              <Select value={selectedPipeline} onValueChange={setSelectedPipeline}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los pipelines</SelectItem>
                  {pipelines.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-slate-500 dark:text-zinc-400 mb-1 block">Agente</Label>
              <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los agentes</SelectItem>
                  {agents.map(a => <SelectItem key={a.id} value={a.id}>{a.full_name || a.email}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-slate-500 dark:text-zinc-400 mb-1 block">Ramo</Label>
              <Select value={selectedBranch} onValueChange={setSelectedBranch}>
                <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los ramos</SelectItem>
                  {BRANCHES.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3">
        <div className="col-span-1"><StatCard title="Total Leads" value={stats.total} icon={Users} color="text-slate-700 dark:text-zinc-200" bg="bg-slate-100 dark:bg-slate-700" /></div>
        <div className="col-span-1"><StatCard title="Activos" value={stats.active} icon={Target} color="text-blue-700 dark:text-blue-300" bg="bg-blue-100 dark:bg-blue-900/30" /></div>
        <div className="col-span-1"><StatCard title="Cierres" value={stats.won} icon={CheckCircle} color="text-green-700 dark:text-green-300" bg="bg-green-100 dark:bg-green-900/30" /></div>
        <div className="col-span-1"><StatCard title="Tasa Cierre" value={`${stats.conversionRate}%`} icon={TrendingUp} color="text-emerald-700 dark:text-emerald-300" bg="bg-emerald-100 dark:bg-emerald-900/30" /></div>
        <div className="col-span-1"><StatCard title="Abandonados" value={stats.abandoned} icon={XCircle} color="text-red-700 dark:text-red-300" bg="bg-red-100 dark:bg-red-900/30" /></div>
        <div className="col-span-1"><StatCard title="Calientes 🔥" value={stats.hot} subtitle="Actividad < 7 días" icon={Flame} color="text-orange-700 dark:text-orange-300" bg="bg-orange-100 dark:bg-orange-900/30" /></div>
        <div className="col-span-1"><StatCard title="Fríos ❄️" value={stats.cold} subtitle="Sin actividad > 30d" icon={Snowflake} color="text-cyan-700 dark:text-cyan-300" bg="bg-cyan-100 dark:bg-cyan-900/30" /></div>
        <div className="col-span-1"><StatCard title="Prima Cerrada" value={`$${fmt(stats.wonPremium)}`} icon={DollarSign} color="text-green-700 dark:text-green-300" bg="bg-green-100 dark:bg-green-900/30" /></div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Leads by stage */}
        <Card className="border border-slate-200 dark:border-zinc-700">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-semibold text-slate-700 dark:text-zinc-200">Leads por etapa del embudo</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            {stageData.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">Sin datos</p>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={stageData} margin={{ top: 4, right: 8, left: -20, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" interval={0} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip formatter={(v) => [v, 'Leads']} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {stageData.map((entry, i) => (
                      <Cell key={i} fill={entry.color || COLORS[i % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Branch distribution */}
        <Card className="border border-slate-200 dark:border-zinc-700">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-semibold text-slate-700 dark:text-zinc-200">Distribución por ramo</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            {branchData.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">Sin datos</p>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={branchData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                    {branchData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Agent Performance */}
      <Card className="border border-slate-200 dark:border-zinc-700">
        <CardHeader className="pb-2 pt-4 px-4">
          <CardTitle className="text-sm font-semibold text-slate-700 dark:text-zinc-200 flex items-center gap-2">
            <Award className="h-4 w-4 text-brand" /> Rendimiento por agente
          </CardTitle>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {agentStats.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-6">Sin datos</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-zinc-700">
                    <th className="text-left text-xs text-slate-400 dark:text-zinc-500 font-medium py-2 pr-4">#</th>
                    <th className="text-left text-xs text-slate-400 dark:text-zinc-500 font-medium py-2 pr-4">Agente</th>
                    <th className="text-right text-xs text-slate-400 dark:text-zinc-500 font-medium py-2 pr-4">Total</th>
                    <th className="text-right text-xs text-slate-400 dark:text-zinc-500 font-medium py-2 pr-4">Cierres</th>
                    <th className="text-right text-xs text-slate-400 dark:text-zinc-500 font-medium py-2 pr-4">Conv.%</th>
                    <th className="text-right text-xs text-slate-400 dark:text-zinc-500 font-medium py-2 pr-4">Prima propuesta</th>
                    <th className="text-right text-xs text-slate-400 dark:text-zinc-500 font-medium py-2">Prima cerrada</th>
                  </tr>
                </thead>
                <tbody>
                  {agentStats.map((a, i) => (
                    <tr key={i} className="border-b border-slate-50 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/50 transition-colors">
                      <td className="py-2 pr-4">
                        {i === 0 && <span className="text-yellow-500 font-bold">🥇</span>}
                        {i === 1 && <span className="text-slate-400 font-bold">🥈</span>}
                        {i === 2 && <span className="text-amber-600 font-bold">🥉</span>}
                        {i > 2 && <span className="text-slate-300 dark:text-zinc-600 text-xs">{i + 1}</span>}
                      </td>
                      <td className="py-2 pr-4 font-medium text-slate-700 dark:text-zinc-200">{a.name}</td>
                      <td className="py-2 pr-4 text-right text-slate-600 dark:text-zinc-300">{a.total}</td>
                      <td className="py-2 pr-4 text-right">
                        <span className="text-green-600 font-semibold">{a.won}</span>
                      </td>
                      <td className="py-2 pr-4 text-right">
                        <Badge className={`text-xs ${parseFloat(a.convRate) >= 20 ? 'bg-green-100 text-green-700' : parseFloat(a.convRate) >= 10 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-600'}`}>
                          {a.convRate}%
                        </Badge>
                      </td>
                      <td className="py-2 pr-4 text-right text-slate-600 dark:text-zinc-300">${fmt(a.premium)}</td>
                      <td className="py-2 text-right text-green-700 dark:text-green-400 font-semibold">${fmt(a.wonPremium)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Leads */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top Won */}
        <Card className="border border-slate-200 dark:border-zinc-700">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-semibold text-slate-700 dark:text-zinc-200 flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" /> Mejores cierres
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-2">
            {topWonLeads.length === 0 ? <p className="text-xs text-slate-400 py-4 text-center">Sin cierres en este período</p> : topWonLeads.map((l, i) => (
              <div key={l.id} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-slate-700 dark:text-white">{l.prospect_name}</p>
                  <p className="text-xs text-slate-400 dark:text-zinc-400">{l.branch} · {l.assigned_agent_name}</p>
                </div>
                <span className="text-sm font-bold text-green-700 dark:text-green-400">${fmt(l.premium_estimated)}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Top Active */}
        <Card className="border border-slate-200 dark:border-zinc-700">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-semibold text-slate-700 dark:text-zinc-200 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-brand" /> Mejores leads en progreso
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-2">
            {topActiveLeads.length === 0 ? <p className="text-xs text-slate-400 py-4 text-center">Sin leads activos</p> : topActiveLeads.map((l, i) => (
              <div key={l.id} className="flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-slate-700 dark:text-white">{l.prospect_name}</p>
                  <p className="text-xs text-slate-400 dark:text-zinc-400">{l.branch} · {l.assigned_agent_name}</p>
                </div>
                <span className="text-sm font-bold text-brand dark:text-brand-light">${fmt(l.premium_estimated)}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}