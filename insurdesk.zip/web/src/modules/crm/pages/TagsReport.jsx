import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Tag, Users, Target, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export default function TagsReport() {
  const [loading, setLoading] = useState(true);
  const [tags, setTags] = useState([]);
  const [leads, setLeads] = useState([]);
  const [prospects, setProspects] = useState([]);
  const [entityFilter, setEntityFilter] = useState('both');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [tagsData, leadsData, prospectsData] = await Promise.all([
      api.entities.Tag.list('name'),
      api.entities.Lead.list('-created_date', 20000),
      api.entities.Prospect.list('-created_date', 20000),
    ]);
    setTags(tagsData);
    setLeads(leadsData);
    setProspects(prospectsData);
    setLoading(false);
  };

  // Build stats per tag
  const tagStats = tags.map(tag => {
    const leadCount = leads.filter(l =>
      Array.isArray(l.tags) && l.tags.some(t => (typeof t === 'object' ? t.id : t) === tag.id)
    ).length;
    const prospectCount = prospects.filter(p =>
      Array.isArray(p.tags) && p.tags.some(t => (typeof t === 'object' ? t.id : t) === tag.id)
    ).length;
    const total = (entityFilter === 'leads' ? leadCount : entityFilter === 'prospects' ? prospectCount : leadCount + prospectCount);
    return { ...tag, leadCount, prospectCount, total };
  }).sort((a, b) => b.total - a.total);

  const chartData = tagStats.filter(t => t.total > 0);

  const totalTaggedLeads = leads.filter(l => Array.isArray(l.tags) && l.tags.length > 0).length;
  const totalTaggedProspects = prospects.filter(p => Array.isArray(p.tags) && p.tags.length > 0).length;
  const topTag = tagStats[0];

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Tag className="h-8 w-8 text-blue-600" />
              Reporte de Etiquetas
            </h1>
            <p className="text-slate-500 mt-1">Distribución de leads y prospectos por etiqueta</p>
          </div>
          <Select value={entityFilter} onValueChange={setEntityFilter}>
            <SelectTrigger className="w-[180px] bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="both">Leads + Prospectos</SelectItem>
              <SelectItem value="leads">Solo Leads</SelectItem>
              <SelectItem value="prospects">Solo Prospectos</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <Tag className="h-6 w-6 text-blue-500 mx-auto mb-1" />
              <p className="text-2xl font-bold text-slate-900">{tags.length}</p>
              <p className="text-xs text-slate-500">Etiquetas creadas</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="h-6 w-6 text-emerald-500 mx-auto mb-1" />
              <p className="text-2xl font-bold text-slate-900">{totalTaggedLeads}</p>
              <p className="text-xs text-slate-500">Leads etiquetados</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Users className="h-6 w-6 text-purple-500 mx-auto mb-1" />
              <p className="text-2xl font-bold text-slate-900">{totalTaggedProspects}</p>
              <p className="text-xs text-slate-500">Prospectos etiquetados</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-6 w-6 text-orange-500 mx-auto mb-1" />
              {topTag ? (
                <>
                  <p className="text-lg font-bold text-slate-900 truncate">{topTag.name}</p>
                  <p className="text-xs text-slate-500">Etiqueta más usada</p>
                </>
              ) : (
                <p className="text-sm text-slate-400">Sin datos</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Bar Chart */}
        {chartData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Distribución por Etiqueta</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 12 }}
                    angle={-35}
                    textAnchor="end"
                    interval={0}
                  />
                  <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                  <Tooltip
                    formatter={(value, name) => [value, name === 'leadCount' ? 'Leads' : name === 'prospectCount' ? 'Prospectos' : 'Total']}
                  />
                  {(entityFilter === 'both' || entityFilter === 'leads') && (
                    <Bar dataKey="leadCount" name="Leads" radius={[4, 4, 0, 0]}>
                      {chartData.map(tag => (
                        <Cell key={tag.id} fill={tag.color} />
                      ))}
                    </Bar>
                  )}
                  {entityFilter === 'both' && (
                    <Bar dataKey="prospectCount" name="Prospectos" radius={[4, 4, 0, 0]} fill="#94a3b8" />
                  )}
                  {entityFilter === 'prospects' && (
                    <Bar dataKey="prospectCount" name="Prospectos" radius={[4, 4, 0, 0]}>
                      {chartData.map(tag => (
                        <Cell key={tag.id} fill={tag.color} />
                      ))}
                    </Bar>
                  )}
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Detailed Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Detalle por Etiqueta</CardTitle>
          </CardHeader>
          <CardContent>
            {tagStats.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <Tag className="h-10 w-10 mx-auto mb-2 opacity-40" />
                <p>No hay etiquetas creadas aún.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {tagStats.map(tag => {
                  const max = tagStats[0]?.total || 1;
                  const pct = max > 0 ? (tag.total / max) * 100 : 0;
                  return (
                    <div key={tag.id} className="flex items-center gap-3">
                      <span className="w-3.5 h-3.5 rounded-full shrink-0" style={{ backgroundColor: tag.color }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">{tag.name}</span>
                            <Badge variant="outline" className="text-xs py-0">{tag.category}</Badge>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-slate-500 shrink-0">
                            {entityFilter !== 'prospects' && (
                              <span><Target className="h-3 w-3 inline mr-0.5" />{tag.leadCount} leads</span>
                            )}
                            {entityFilter !== 'leads' && (
                              <span><Users className="h-3 w-3 inline mr-0.5" />{tag.prospectCount} prospectos</span>
                            )}
                            <span className="font-semibold text-slate-700">{tag.total} total</span>
                          </div>
                        </div>
                        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${pct}%`, backgroundColor: tag.color }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}