import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { useAuth } from '@/lib/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Target, TrendingDown, DollarSign, 
  ThermometerSun, ThermometerSnowflake, Trophy,
  Calendar, BarChart3, ArrowRight, Layers
} from "lucide-react";
import { differenceInDays, subDays, startOfMonth, endOfMonth, startOfYear, endOfYear } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import StatsCard from '@/components/ui/StatsCard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import AgentStatsPanel from '@/modules/crm/components/dashboard/AgentStatsPanel';
import ActivityFeed from '@/modules/crm/components/dashboard/ActivityFeed';
import DashboardAlerts from '@/modules/crm/components/dashboard/DashboardAlerts';
import RadarWidget from '@/modules/ia/components/radar/RadarWidget';
import { useModules } from '@/lib/ModulesContext';
import AgentGoalsWidget from '@/modules/crm/components/dashboard/AgentGoalsWidget';

const BRANCHES = ["Vida", "Salud", "Viaje", "Inversiones", "General"];
const COLORS = ['#2F4F9D', '#6F8CD0', '#8A94A6', '#2F8F83', '#C58A2E'];

export default function Dashboard() {
  const { isEnabled } = useModules();
  const { user: currentUser } = useAuth();
  const userRole = currentUser?.crm_role || 'agente_crm';
  const [leads, setLeads] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [selectedPipelineId, setSelectedPipelineId] = useState('all');
  const [loading, setLoading] = useState(true);
  const [agents, setAgents] = useState([]);
  const [activities, setActivities] = useState([]);
  const [filters, setFilters] = useState({
    dateRange: 'month',
    agentId: '',
    branch: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    if (!currentUser) return;
    try {
      const isAgent = userRole === 'agente_crm' || userRole === 'reclutador_crm';

      // Optimización B: agentes/reclutadores solo descargan SUS leads (no los 500 del CRM)
      const leadPromise = isAgent
        ? api.entities.Lead.filter({ assigned_agent_id: currentUser.id }, '-created_date', 20000)
        : api.entities.Lead.list('-created_date', 20000);

      // Optimización C: LeadActivity solo lo consume AgentStatsPanel (admin/jefatura)
      const activityPromise = isAgent
        ? Promise.resolve([])
        : api.entities.LeadActivity.list('-created_date', 1000);

      const [leadsData, pipelinesData, activitiesData] = await Promise.all([
        leadPromise,
        api.entities.Pipeline.list('sort_order'),
        activityPromise
      ]);
      setLeads(leadsData);
      setPipelines(pipelinesData);
      setActivities(activitiesData);

      // Solo admin y jefatura pueden listar usuarios
      if (userRole === 'admin_crm' || userRole === 'jefatura_crm' || currentUser?.role === 'admin') {
        try {
          const usersData = await api.entities.User.list();
          setAgents(usersData.filter(u => ['admin_crm', 'jefatura_crm', 'agente_crm', 'reclutador_crm'].includes(u.crm_role)));
        } catch {
          // Sin permisos para listar usuarios
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredLeads = useMemo(() => {
    let result = leads;

    // Filter by pipeline
    if (selectedPipelineId && selectedPipelineId !== 'all') {
      result = result.filter(l => l.pipeline_id === selectedPipelineId);
    }
    
    // Filter by agent
    if (userRole === 'agente_crm' || userRole === 'reclutador_crm') {
      result = result.filter(l => 
        l.assigned_agent_id === currentUser?.id || 
        l.assigned_agent_id === currentUser?.email ||
        l.created_by === currentUser?.email
      );
    } else if (filters.agentId?.startsWith('me:')) {
      // Admin/jefatura viendo solo sus propios leads
      result = result.filter(l => 
        l.assigned_agent_id === currentUser?.id ||
        l.assigned_agent_id === currentUser?.email ||
        l.created_by === currentUser?.email
      );
    } else if (filters.agentId) {
      result = result.filter(l => l.assigned_agent_id === filters.agentId);
    }

    // Filter by branch
    if (filters.branch) {
      result = result.filter(l => l.branch === filters.branch);
    }

    return result;
  }, [leads, filters, userRole, currentUser, selectedPipelineId]);

  const getDateRange = () => {
    const now = new Date();
    switch (filters.dateRange) {
      case 'week':
        return { start: subDays(now, 7), end: now };
      case 'month':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case 'year':
        return { start: startOfYear(now), end: endOfYear(now) };
      default:
        return { start: startOfMonth(now), end: now };
    }
  };

  // Get won/lost stage keys for a pipeline
  const getWonLostKeys = (pipelineId) => {
    if (!pipelineId || pipelineId === 'all') {
      // Aggregate from all pipelines
      const wonKeys = new Set();
      const lostKeys = new Set();
      pipelines.forEach(p => (p.stages || []).forEach(s => {
        if (s.is_won) wonKeys.add(s.key);
        if (s.is_lost) lostKeys.add(s.key);
      }));
      // Legacy fallback
      wonKeys.add('GANADO'); lostKeys.add('PERDIDO');
      return { wonKeys, lostKeys };
    }
    const pipeline = pipelines.find(p => p.id === pipelineId);
    if (!pipeline) return { wonKeys: new Set(['GANADO']), lostKeys: new Set(['PERDIDO']) };
    const wonKeys = new Set((pipeline.stages || []).filter(s => s.is_won).map(s => s.key));
    const lostKeys = new Set((pipeline.stages || []).filter(s => s.is_lost).map(s => s.key));
    if (wonKeys.size === 0) wonKeys.add('GANADO');
    if (lostKeys.size === 0) lostKeys.add('PERDIDO');
    return { wonKeys, lostKeys };
  };

  const metrics = useMemo(() => {
    const { start, end } = getDateRange();
    const now = new Date();
    const { wonKeys, lostKeys } = getWonLostKeys(selectedPipelineId);

    const active = filteredLeads.filter(l => 
      l.lead_status !== 'ARCHIVADO' && 
      !wonKeys.has(l.pipeline_stage) &&
      !lostKeys.has(l.pipeline_stage)
    );

    const hot = active.filter(l => {
      if (!l.last_activity_at) return false;
      const days = differenceInDays(now, new Date(l.last_activity_at));
      return days <= 7;
    });

    const cold = active.filter(l => {
      if (!l.last_activity_at) return true;
      return differenceInDays(now, new Date(l.last_activity_at)) > 14;
    });

    // Won/lost: use updated_date OR created_date (whichever is available), falling back to all if date is missing
    const won = filteredLeads.filter(l => {
      if (!wonKeys.has(l.pipeline_stage)) return false;
      const d = new Date(l.updated_date || l.created_date);
      return d >= start && d <= end;
    });

    const lost = filteredLeads.filter(l => {
      if (!lostKeys.has(l.pipeline_stage)) return false;
      const d = new Date(l.updated_date || l.created_date);
      return d >= start && d <= end;
    });

    const premiumActive = active.reduce((sum, l) => sum + (l.premium_estimated || 0), 0);
    const premiumWon = won.reduce((sum, l) => sum + (l.premium_estimated || 0), 0);

    const topLeads = [...filteredLeads]
      .filter(l => !wonKeys.has(l.pipeline_stage) && !lostKeys.has(l.pipeline_stage) && l.lead_status === 'ACTIVO')
      .sort((a, b) => (b.premium_estimated || 0) - (a.premium_estimated || 0))
      .slice(0, 10);

    const byBranch = BRANCHES.map(branch => ({
      name: branch,
      value: filteredLeads.filter(l => l.branch === branch).length,
      premium: filteredLeads.filter(l => l.branch === branch).reduce((sum, l) => sum + (l.premium_estimated || 0), 0)
    })).filter(b => b.value > 0);

    const totalLeads = filteredLeads.length;
    const effectivenessRate = totalLeads > 0 
      ? ((won.length / totalLeads) * 100).toFixed(1)
      : 0;

    return {
      active: active.length,
      hot: hot.length,
      cold: cold.length,
      won: won.length,
      lost: lost.length,
      premiumActive,
      premiumWon,
      topLeads,
      byBranch,
      conversionRate: won.length + lost.length > 0 
        ? ((won.length / (won.length + lost.length)) * 100).toFixed(1)
        : 0,
      effectivenessRate
    };
  }, [filteredLeads, filters.dateRange, pipelines, selectedPipelineId]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
            <p className="text-slate-500 dark:text-zinc-400 mt-1">
              {(userRole === 'agente_crm' || userRole === 'reclutador_crm') ? 'Mis métricas de ventas' : 'Métricas globales del CRM'}
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Pipeline filter */}
            {pipelines.length > 0 && (
              <Select value={selectedPipelineId} onValueChange={setSelectedPipelineId}>
                <SelectTrigger className="w-[160px] bg-background border-border text-foreground">
                  <Layers className="h-4 w-4 mr-2 text-slate-400" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los pipelines</SelectItem>
                  {pipelines.map(p => (
                    <SelectItem key={p.id} value={p.id}>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: p.color || '#2F4F9D' }} />
                        {p.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Select value={filters.dateRange} onValueChange={(v) => setFilters(f => ({ ...f, dateRange: v }))}>
              <SelectTrigger className="w-[150px] bg-background border-border text-foreground">
                <Calendar className="h-4 w-4 mr-2 text-slate-400" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Última semana</SelectItem>
                <SelectItem value="month">Este mes</SelectItem>
                <SelectItem value="year">Este año</SelectItem>
              </SelectContent>
            </Select>


          </div>
        </div>

        {/* Alertas personalizadas */}
        <DashboardAlerts currentUser={currentUser} myLeads={filteredLeads} />

        {/* Radar IA: Qué hacer hoy */}
        {isEnabled('ia') && <RadarWidget currentUser={currentUser} />}

        {/* Main Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <StatsCard
            title="Leads Activos"
            value={metrics.active}
            icon={Target}
            variant="primary"
          />
          <StatsCard
            title="Leads Calientes"
            value={metrics.hot}
            icon={ThermometerSun}
            variant="warning"
            subtitle="Actividad < 7 días"
          />
          <StatsCard
            title="Leads Fríos"
            value={metrics.cold}
            icon={ThermometerSnowflake}
            variant="default"
            subtitle="Sin actividad > 14 días"
          />
          <StatsCard
            title="Tasa Conversión"
            value={`${metrics.conversionRate}%`}
            icon={BarChart3}
            variant="purple"
            subtitle="Ganados / Cerrados"
          />
          <StatsCard
            title="Tasa Efectividad"
            value={`${metrics.effectivenessRate}%`}
            icon={Trophy}
            variant="success"
            subtitle="Ganados / Total"
          />
        </div>

        {/* Financial Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatsCard
            title="Primas en Curso"
            value={formatCurrency(metrics.premiumActive)}
            icon={DollarSign}
            subtitle="Leads activos"
          />
          <StatsCard
            title="Primas Ganadas"
            value={formatCurrency(metrics.premiumWon)}
            icon={Trophy}
            variant="success"
            subtitle={`${metrics.won} deals cerrados`}
          />
          <StatsCard
            title="Leads Perdidos"
            value={metrics.lost}
            icon={TrendingDown}
            variant="danger"
          />
        </div>

        {/* Per-Pipeline Breakdown when viewing all */}
        {selectedPipelineId === 'all' && pipelines.length > 1 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {pipelines.map(pipeline => {
              // Use filteredLeads so agent filter applies
              const pLeads = filteredLeads.filter(l => l.pipeline_id === pipeline.id);
              const { wonKeys, lostKeys } = getWonLostKeys(pipeline.id);
              const pActive = pLeads.filter(l => l.lead_status !== 'ARCHIVADO' && !wonKeys.has(l.pipeline_stage) && !lostKeys.has(l.pipeline_stage));
              const pWon = pLeads.filter(l => wonKeys.has(l.pipeline_stage));
              const pLost = pLeads.filter(l => lostKeys.has(l.pipeline_stage));
              const pPremium = pActive.reduce((s, l) => s + (l.premium_estimated || 0), 0);
              return (
                <Card key={pipeline.id} className="border-l-4 dark:bg-zinc-900 dark:border-zinc-700" style={{ borderLeftColor: pipeline.color || '#2F4F9D' }}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-slate-800 dark:text-zinc-100">{pipeline.name}</h3>
                      <Badge style={{ backgroundColor: pipeline.color || '#2F4F9D', color: '#fff' }}>
                        {pLeads.length} leads
                      </Badge>
                    </div>
                    <div className="grid grid-cols-4 gap-2 text-center">
                      <div>
                        <p className="text-xl font-bold text-slate-900 dark:text-zinc-100">{pActive.length}</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-400">Activos</p>
                      </div>
                      <div>
                        <p className="text-xl font-bold text-emerald-600">{pWon.length}</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-400">Ganados</p>
                      </div>
                      <div>
                        <p className="text-xl font-bold text-red-500">{pLost.length}</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-400">Perdidos</p>
                      </div>
                      <div>
                        <p className="text-xl font-bold text-blue-500">${(pPremium / 1000).toFixed(0)}k</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-400">En curso</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* By Branch */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Distribución por Ramo</CardTitle>
            </CardHeader>
            <CardContent>
              {metrics.byBranch.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={metrics.byBranch}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={2}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {metrics.byBranch.map((entry, index) => (
                        <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[250px] flex items-center justify-center text-slate-400 dark:text-zinc-500">
                No hay datos
                </div>
                )}
                </CardContent>
                </Card>

                {/* Premium by Branch */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Prima por Ramo</CardTitle>
            </CardHeader>
            <CardContent>
              {metrics.byBranch.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={metrics.byBranch}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--chart-grid, #e2e8f0)" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
                    <Tooltip formatter={(v) => formatCurrency(v)} />
                    <Bar dataKey="premium" fill="#2F4F9D" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[250px] flex items-center justify-center text-slate-400 dark:text-zinc-500">
                No hay datos
                </div>
                )}
                </CardContent>
                </Card>
                </div>

                {/* Top Leads */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Mejores Prospectos</CardTitle>
            <Link to={createPageUrl('Pipeline')}>
              <Button variant="ghost" size="sm" className="gap-1">
                Ver todos <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {metrics.topLeads.length > 0 ? (
              <div className="space-y-3">
                {metrics.topLeads.slice(0, 5).map((lead, index) => (
                  <div key={lead.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-zinc-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-400 font-semibold text-sm">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900 dark:text-zinc-100">{lead.prospect_name}</p>
                        <p className="text-xs text-slate-500 dark:text-zinc-400">{lead.branch} • {lead.pipeline_stage}</p>
                      </div>
                    </div>
                    <span className="font-semibold text-emerald-600">
                      {formatCurrency(lead.premium_estimated)}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-400 dark:text-zinc-500">
                No hay leads en cotización o negociación
              </div>
            )}
          </CardContent>
        </Card>

        {/* Activity Feed + Agent Stats + Goals + Radar */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {(userRole === 'admin_crm' || userRole === 'jefatura_crm' || currentUser?.role === 'admin') && (
            <ActivityFeed />
          )}
          <div className="space-y-4">
            <AgentGoalsWidget currentUser={currentUser} allLeads={leads} pipelines={pipelines} />
            {(userRole === 'admin_crm' || userRole === 'jefatura_crm' || currentUser?.role === 'admin') && (
              <AgentStatsPanel
                leads={leads}
                activities={activities}
                agents={agents}
                dateRange={filters.dateRange}
              />
            )}
          </div>
        </div>

      </div>
    </div>
  );
}