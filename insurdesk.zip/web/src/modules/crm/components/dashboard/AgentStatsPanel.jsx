import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Target, Mail, Phone, MessageSquare, Activity } from "lucide-react";

export default function AgentStatsPanel({ leads, activities, agents, dateRange }) {

  const getDateBounds = () => {
    const now = new Date();
    if (dateRange === 'week') return new Date(now - 7 * 86400000);
    if (dateRange === 'year') return new Date(now.getFullYear(), 0, 1);
    // default: month
    return new Date(now.getFullYear(), now.getMonth(), 1);
  };

  const stats = useMemo(() => {
    const since = getDateBounds();

    // Build map: agentId -> stats
    const map = {};

    // Get unique agents from leads
    leads.forEach(lead => {
      const id = lead.assigned_agent_id;
      const name = lead.assigned_agent_name || 'Sin nombre';
      if (!id) return;
      if (!map[id]) {
        map[id] = { id, name, newLeads: 0, stageChanges: 0, emails: 0, calls: 0, whatsapps: 0, otherActivities: 0 };
      }
      const created = new Date(lead.created_date);
      if (created >= since) map[id].newLeads++;
    });

    // Count activities
    activities.forEach(act => {
      const created = new Date(act.created_date);
      if (created < since) return;

      // Try to match agent from the lead
      const lead = leads.find(l => l.id === act.lead_id);
      const agentId = lead?.assigned_agent_id;
      if (!agentId || !map[agentId]) return;

      if (act.activity_type === 'email') map[agentId].emails++;
      else if (act.activity_type === 'llamada') map[agentId].calls++;
      else if (act.activity_type === 'whatsapp') map[agentId].whatsapps++;
      else map[agentId].otherActivities++;
    });

    return Object.values(map).sort((a, b) => b.newLeads - a.newLeads);
  }, [leads, activities, dateRange]);

  if (stats.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            Estadísticas por Agente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">No hay datos disponibles</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Users className="h-5 w-5 text-blue-600" />
          Estadísticas por Agente
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 dark:border-zinc-700">
                <th className="text-left py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">Agente</th>
                <th className="text-center py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">
                  <span className="flex items-center justify-center gap-1"><Target className="h-3.5 w-3.5" />Nuevos</span>
                </th>
                <th className="text-center py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">
                  <span className="flex items-center justify-center gap-1"><Mail className="h-3.5 w-3.5" />Emails</span>
                </th>
                <th className="text-center py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">
                  <span className="flex items-center justify-center gap-1"><Phone className="h-3.5 w-3.5" />Llamadas</span>
                </th>
                <th className="text-center py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">
                  <span className="flex items-center justify-center gap-1"><MessageSquare className="h-3.5 w-3.5" />WhatsApp</span>
                </th>
                <th className="text-center py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">
                  <span className="flex items-center justify-center gap-1"><Activity className="h-3.5 w-3.5" />Otras act.</span>
                </th>
                <th className="text-center py-2 px-3 text-slate-500 dark:text-zinc-400 font-medium">Total act.</th>
              </tr>
            </thead>
            <tbody>
              {stats.map((agent, idx) => {
                const totalAct = agent.emails + agent.calls + agent.whatsapps + agent.otherActivities;
                return (
                  <tr key={agent.id} className={idx % 2 === 0 ? 'bg-slate-50/50 dark:bg-zinc-800/50' : ''}>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-blue-600 dark:text-blue-300 font-semibold text-xs">
                          {agent.name.charAt(0).toUpperCase()}
                        </div>
                        <span className="font-medium text-slate-800 dark:text-zinc-100">{agent.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <Badge className="bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 border-0">{agent.newLeads}</Badge>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="text-slate-700 dark:text-zinc-300">{agent.emails}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="text-slate-700 dark:text-zinc-300">{agent.calls}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="text-slate-700 dark:text-zinc-300">{agent.whatsapps}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="text-slate-700 dark:text-zinc-300">{agent.otherActivities}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <Badge className={`border-0 ${totalAct >= 10 ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300' : totalAct >= 5 ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300' : 'bg-slate-100 dark:bg-zinc-700 text-slate-600 dark:text-zinc-300'}`}>
                        {totalAct}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}