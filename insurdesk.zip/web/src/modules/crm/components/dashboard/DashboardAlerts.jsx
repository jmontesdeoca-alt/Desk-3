import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { differenceInDays, isToday } from 'date-fns';
import { AlertTriangle, Bell, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';

const AlertCard = ({ icon: Icon, label, count, sub, to, color }) => {
  const colors = {
    amber: 'border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-700',
    red:   'border-red-200   bg-red-50   hover:bg-red-100   text-red-700',
    blue:  'border-blue-200  bg-blue-50  hover:bg-blue-100  text-blue-700',
    slate: 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700',
  };
  const countColors = {
    amber: 'text-amber-600',
    red:   'text-red-600',
    blue:  'text-blue-600',
    slate: 'text-slate-600',
  };

  return (
    <Link to={to} className={cn(
      "flex items-start gap-3 p-4 rounded-xl border transition-colors cursor-pointer",
      colors[color]
    )}>
      <Icon className="h-5 w-5 mt-0.5 shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className="font-semibold text-sm">{label}</span>
          <span className={cn("text-2xl font-bold leading-none", countColors[color])}>{count}</span>
        </div>
        <p className="text-xs opacity-75 mt-0.5">{sub}</p>
      </div>
    </Link>
  );
};

export default function DashboardAlerts({ currentUser, myLeads }) {
  const [todayEvents, setTodayEvents] = useState(0);
  const [pendingReminders, setPendingReminders] = useState(0);
  const [overdueReminders, setOverdueReminders] = useState(0);

  useEffect(() => {
    if (!currentUser?.id) return;
    loadCounts();
  }, [currentUser]);

  const loadCounts = async () => {
    try {
      const [events, reminders] = await Promise.all([
        api.entities.CalendarEvent.filter({ assigned_to_id: currentUser.id, status: 'programado' }, 'start_datetime', 100),
        api.entities.FollowUpReminder.filter({ assigned_to_id: currentUser.id, status: 'pendiente' }, 'reminder_date', 100),
      ]);
      setTodayEvents(events.filter(e => isToday(new Date(e.start_datetime))).length);
      const now = new Date();
      setPendingReminders(reminders.filter(r => isToday(new Date(r.reminder_date))).length);
      setOverdueReminders(reminders.filter(r => new Date(r.reminder_date) < now && !isToday(new Date(r.reminder_date))).length);
    } catch (e) {
      console.error(e);
    }
  };

  const coldLeads = myLeads.filter(l => {
    if (l.lead_status !== 'ACTIVO') return false;
    if (!l.last_activity_at) return true;
    return differenceInDays(new Date(), new Date(l.last_activity_at)) > 14;
  }).length;

  const cards = [
    pendingReminders > 0 && {
      icon: Bell,
      label: pendingReminders === 1 ? 'Tarea para hoy' : 'Tareas para hoy',
      count: pendingReminders,
      sub: 'Recordatorios programados para hoy',
      to: createPageUrl('Tasks'),
      color: 'blue',
    },
    overdueReminders > 0 && {
      icon: Clock,
      label: 'Tareas vencidas',
      count: overdueReminders,
      sub: 'Recordatorios pendientes sin completar',
      to: createPageUrl('Tasks'),
      color: 'red',
    },
    coldLeads > 0 && {
      icon: AlertTriangle,
      label: 'Leads sin actividad',
      count: coldLeads,
      sub: 'Sin actividad en más de 14 días',
      to: createPageUrl('Pipeline'),
      color: 'amber',
    },
  ].filter(Boolean);

  if (cards.length === 0) return null;

  return (
    <div className={cn(
      "grid gap-3",
      cards.length === 1 ? "grid-cols-1 sm:grid-cols-2" :
      cards.length === 2 ? "grid-cols-1 sm:grid-cols-2" :
      cards.length === 3 ? "grid-cols-1 sm:grid-cols-3" :
      "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
    )}>
      {cards.map((card, i) => (
        <AlertCard key={i} {...card} />
      ))}
    </div>
  );
}