import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, Mail, Phone, Users, FileText, 
  Activity, Zap
} from "lucide-react";
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

const ACTIVITY_CONFIG = {
  llamada:   { icon: Phone,        color: 'bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400',     label: 'Llamada' },
  whatsapp:  { icon: MessageSquare,color: 'bg-green-100 dark:bg-green-900/40 text-green-600 dark:text-green-400', label: 'WhatsApp' },
  email:     { icon: Mail,         color: 'bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400', label: 'Email' },
  'reunión': { icon: Users,        color: 'bg-orange-100 dark:bg-orange-900/40 text-orange-600 dark:text-orange-400', label: 'Reunión' },
  nota:      { icon: FileText,     color: 'bg-slate-100 dark:bg-zinc-700 text-slate-600 dark:text-zinc-300',      label: 'Nota' },
  otro:      { icon: Activity,     color: 'bg-gray-100 dark:bg-zinc-700 text-gray-600 dark:text-zinc-300',        label: 'Actividad' },
};

function isStageChange(description) {
  return description?.toLowerCase().includes('etapa') || 
         description?.toLowerCase().includes('stage') ||
         description?.toLowerCase().includes('cambio') ||
         description?.toLowerCase().includes('pasó a');
}

function isAssignment(description) {
  return description?.toLowerCase().includes('asignado') || 
         description?.toLowerCase().includes('clonado');
}

function ActivityItem({ activity }) {
  const config = ACTIVITY_CONFIG[activity.activity_type] || ACTIVITY_CONFIG.otro;
  const Icon = config.icon;

  const getVariant = () => {
    if (isStageChange(activity.description)) return { bg: 'bg-amber-50 dark:bg-amber-950/30 border-l-amber-400', badge: 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300' };
    if (isAssignment(activity.description)) return { bg: 'bg-blue-50 dark:bg-blue-950/30 border-l-blue-400', badge: 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300' };
    return { bg: 'bg-white dark:bg-zinc-800 border-l-slate-200 dark:border-l-zinc-600', badge: null };
  };

  const variant = getVariant();

  return (
    <div className={`flex gap-3 p-3 rounded-lg border-l-4 ${variant.bg} transition-all`}>
      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${config.color}`}>
        <Icon className="h-3.5 w-3.5" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            {activity.lead_external_id && (
              <span className="text-xs font-mono text-slate-400 dark:text-zinc-500 block">{activity.lead_external_id}</span>
            )}
            <p className="text-sm text-slate-700 dark:text-zinc-200 leading-snug line-clamp-2">{activity.description}</p>
          </div>
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            {variant.badge && (
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${variant.badge}`}>
                {isStageChange(activity.description) ? 'Etapa' : 'Asignación'}
              </span>
            )}
            <Badge variant="outline" className="text-[10px] px-1.5 py-0.5 whitespace-nowrap dark:border-zinc-600 dark:text-zinc-300">
              {config.label}
            </Badge>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-1">
          {activity.created_by_name && (
            <span className="text-xs text-slate-500 dark:text-zinc-400 font-medium">{activity.created_by_name}</span>
          )}
          <span className="text-xs text-slate-400 dark:text-zinc-500">
            {formatDistanceToNow(new Date(activity.created_date), { addSuffix: true, locale: es })}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function ActivityFeed() {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newCount, setNewCount] = useState(0);

  useEffect(() => {
    loadActivities();

    // Real-time subscription
    const unsubscribe = api.entities.LeadActivity.subscribe((event) => {
      if (event.type === 'create' && event.data) {
        setActivities(prev => [event.data, ...prev].slice(0, 50));
        setNewCount(c => c + 1);
        // Reset count after 3s
        setTimeout(() => setNewCount(c => Math.max(0, c - 1)), 3000);
      }
    });

    return () => unsubscribe();
  }, []);

  const loadActivities = async () => {
    try {
      const data = await api.entities.LeadActivity.list('-created_date', 30);
      setActivities(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="flex flex-col h-[520px]">
      <CardHeader className="pb-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-500" />
            Feed de Actividad
          </CardTitle>
          <div className="flex items-center gap-2">
            {newCount > 0 && (
              <Badge className="bg-green-500 text-white text-xs animate-pulse">
                +{newCount} nuevo{newCount > 1 ? 's' : ''}
              </Badge>
            )}
            <span className="flex items-center gap-1 text-xs text-green-600 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse inline-block" />
              En vivo
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-3 pt-0 space-y-2">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin h-6 w-6 border-2 border-blue-500 border-t-transparent rounded-full" />
          </div>
        ) : activities.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-400 dark:text-zinc-500 gap-2">
            <Activity className="h-8 w-8" />
            <p className="text-sm">Sin actividad reciente</p>
          </div>
        ) : (
          activities.map(activity => (
            <ActivityItem key={activity.id} activity={activity} />
          ))
        )}
      </CardContent>
    </Card>
  );
}