import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { Target, TrendingUp, Trophy, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const ProgressBar = ({ value, max }) => {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const barColor = pct >= 100 ? 'bg-green-500' : pct >= 60 ? 'bg-blue-500' : pct >= 30 ? 'bg-amber-500' : 'bg-red-400';
  return (
    <div className="w-full bg-slate-100 rounded-full h-2">
      <div className={cn("h-2 rounded-full transition-all duration-700", barColor)} style={{ width: `${pct}%` }} />
    </div>
  );
};

export default function AgentGoalsWidget({ currentUser, allLeads, pipelines = [] }) {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);

  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (!currentUser?.id) return;
    loadGoals();
  }, [currentUser]);

  const loadGoals = async () => {
    try {
      const data = await api.entities.AgentGoal.filter({ agent_id: currentUser.id }, '-created_date', 20);
      // Show only active (current date within range)
      const active = data.filter(g => g.start_date && g.end_date && today >= g.start_date && today <= g.end_date);
      setGoals(active);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const wonStageKeys = useMemo(() => {
    const keys = new Set();
    pipelines.forEach(p => {
      (p.stages || []).forEach(s => { if (s.is_won) keys.add(s.key); });
    });
    return keys;
  }, [pipelines]);

  const isWonLead = (l) => {
    if (!l.pipeline_stage) return false;
    if (wonStageKeys.has(l.pipeline_stage)) return true;
    return l.pipeline_stage.toLowerCase().includes('ganado') || l.pipeline_stage.toLowerCase() === 'won';
  };

  const goalsWithActuals = useMemo(() => {
    return goals.map(goal => {
      if (!goal.start_date || !goal.end_date) return { ...goal, wonLeads: 0, wonAmount: 0 };
      const start = parseISO(goal.start_date);
      const end = new Date(parseISO(goal.end_date).setHours(23, 59, 59));
      const leads = allLeads.filter(l => {
        if (l.assigned_agent_id !== currentUser?.id) return false;
        if (goal.pipeline_id && l.pipeline_id !== goal.pipeline_id) return false;
        if (!isWonLead(l)) return false;
        const updatedAt = new Date(l.updated_date);
        return updatedAt >= start && updatedAt <= end;
      });
      return {
        ...goal,
        wonLeads: leads.length,
        wonAmount: leads.reduce((s, l) => s + (l.premium_estimated || 0), 0),
      };
    });
  }, [goals, allLeads, currentUser, wonStageKeys]);

  if (loading || goalsWithActuals.length === 0) return null;

  return (
    <Card className="border-0 shadow-sm bg-brand-soft">
      <CardHeader className="pb-3 pt-4 px-5">
        <CardTitle className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <Target className="h-4 w-4 text-brand" />
          Mis Metas Activas
        </CardTitle>
      </CardHeader>
      <CardContent className="px-5 pb-5 space-y-5">
        {goalsWithActuals.map(goal => {
          const leadPct = goal.target_leads > 0 ? Math.min(100, Math.round((goal.wonLeads / goal.target_leads) * 100)) : 0;
          const amountPct = goal.target_amount > 0 ? Math.min(100, Math.round((goal.wonAmount / goal.target_amount) * 100)) : 0;
          const allDone = (goal.target_leads > 0 ? goal.wonLeads >= goal.target_leads : true) &&
            (goal.target_amount > 0 ? goal.wonAmount >= goal.target_amount : true);

          return (
            <div key={goal.id} className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Calendar className="h-3 w-3" />
                  <span>
                    {format(parseISO(goal.start_date), 'd MMM', { locale: es })} — {format(parseISO(goal.end_date), 'd MMM yyyy', { locale: es })}
                  </span>
                  {goal.pipeline_name && <span className="text-slate-400">· {goal.pipeline_name}</span>}
                </div>
              </div>

              {goal.target_leads > 0 && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600 flex items-center gap-1.5">
                      <Trophy className="h-3.5 w-3.5 text-amber-500" />
                      Leads ganados
                    </span>
                    <span className="font-bold text-slate-800">
                      {goal.wonLeads} <span className="font-normal text-slate-400">/ {goal.target_leads}</span>
                      <span className={cn("ml-2 text-xs font-semibold", leadPct >= 100 ? 'text-green-600' : 'text-slate-500')}>
                        {leadPct}%
                      </span>
                    </span>
                  </div>
                  <ProgressBar value={goal.wonLeads} max={goal.target_leads} />
                </div>
              )}

              {goal.target_amount > 0 && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600 flex items-center gap-1.5">
                      <TrendingUp className="h-3.5 w-3.5 text-blue-500" />
                      Prima total
                    </span>
                    <span className="font-bold text-slate-800">
                      ${goal.wonAmount.toLocaleString()} <span className="font-normal text-slate-400">/ ${goal.target_amount.toLocaleString()}</span>
                      <span className={cn("ml-2 text-xs font-semibold", amountPct >= 100 ? 'text-green-600' : 'text-slate-500')}>
                        {amountPct}%
                      </span>
                    </span>
                  </div>
                  <ProgressBar value={goal.wonAmount} max={goal.target_amount} />
                </div>
              )}

              {allDone && (
                <div className="bg-green-50 border border-green-200 rounded-lg px-3 py-2 text-xs text-green-700 font-semibold text-center">
                  🎉 ¡Meta cumplida!
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}