import React from 'react';
import { useAuth } from '@/lib/AuthContext';
import AgentGoalsSettings from '@/modules/crm/components/settings/AgentGoalsSettings';

export default function GoalsTab() {
  const { user } = useAuth();
  return <AgentGoalsSettings currentUser={user} />;
}
