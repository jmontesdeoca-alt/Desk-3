import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { Target, Plus, Pencil, Trash2, Loader2, Trophy, TrendingUp, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const ProgressBar = ({ value, max }) => {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const color = pct >= 100 ? 'bg-green-500' : pct >= 60 ? 'bg-blue-500' : pct >= 30 ? 'bg-amber-500' : 'bg-red-400';
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-slate-100 dark:bg-zinc-700 rounded-full h-2">
        <div className={cn("h-2 rounded-full transition-all", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-semibold text-slate-600 dark:text-zinc-300 w-10 text-right">{pct}%</span>
    </div>
  );
};

const emptyForm = {
  agent_id: '', agent_name: '', agent_email: '',
  start_date: '', end_date: '',
  target_leads: '', target_amount: '',
  pipeline_id: '', pipeline_name: ''
};

export default function AgentGoalsSettings({ currentUser }) {
  const [goals, setGoals] = useState([]);
  const [agents, setAgents] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [allLeads, setAllLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [filterAgent, setFilterAgent] = useState('__all__');
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [goalsData, pipelinesData, leadsData] = await Promise.all([
        api.entities.AgentGoal.list('-created_date', 200),
        api.entities.Pipeline.list(),
        api.entities.Lead.list('-updated_date', 20000),
      ]);
      setPipelines(pipelinesData);
      setAllLeads(leadsData);
      setGoals(goalsData);

      try {
        const { data } = await api.functions.invoke('listAgents', {});
        setAgents(data.agents || []);
      } catch { setAgents([]); }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Build a set of won stage keys across all pipelines
  const wonStageKeys = useMemo(() => {
    const keys = new Set();
    pipelines.forEach(p => {
      (p.stages || []).forEach(s => { if (s.is_won) keys.add(s.key); });
    });
    return keys;
  }, [pipelines]);

  const isWonLead = (l) => {
    if (!l.pipeline_stage) return false;
    if (wonStageKeys.has(l.pipeline_stage)) return true;
    // fallback
    return l.pipeline_stage.toLowerCase().includes('ganado') || l.pipeline_stage.toLowerCase() === 'won';
  };

  const getActuals = (goal) => {
    if (!goal.start_date || !goal.end_date) return { wonLeads: 0, wonAmount: 0 };
    const start = parseISO(goal.start_date);
    const end = new Date(parseISO(goal.end_date).setHours(23, 59, 59));
    const leads = allLeads.filter(l => {
      if (l.assigned_agent_id !== goal.agent_id) return false;
      if (goal.pipeline_id && l.pipeline_id !== goal.pipeline_id) return false;
      if (!isWonLead(l)) return false;
      const updatedAt = new Date(l.updated_date);
      return updatedAt >= start && updatedAt <= end;
    });
    return {
      wonLeads: leads.length,
      wonAmount: leads.reduce((s, l) => s + (l.premium_estimated || 0), 0),
    };
  };

  const openNew = () => {
    setEditingGoal(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (goal) => {
    setEditingGoal(goal);
    setForm({
      agent_id: goal.agent_id,
      agent_name: goal.agent_name,
      agent_email: goal.agent_email || '',
      start_date: goal.start_date || '',
      end_date: goal.end_date || '',
      target_leads: goal.target_leads || '',
      target_amount: goal.target_amount || '',
      pipeline_id: goal.pipeline_id || '',
      pipeline_name: goal.pipeline_name || '',
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.agent_id) return toast({ title: 'Selecciona un agente', variant: 'destructive' });
    if (!form.start_date || !form.end_date) return toast({ title: 'Define el período (fecha inicio y fin)', variant: 'destructive' });
    if (form.start_date > form.end_date) return toast({ title: 'La fecha de inicio debe ser antes que la de fin', variant: 'destructive' });
    setSaving(true);
    const payload = {
      agent_id: form.agent_id,
      agent_name: form.agent_name,
      agent_email: form.agent_email,
      start_date: form.start_date,
      end_date: form.end_date,
      target_leads: Number(form.target_leads) || 0,
      target_amount: Number(form.target_amount) || 0,
      pipeline_id: form.pipeline_id || null,
      pipeline_name: form.pipeline_name || null,
      created_by_name: currentUser?.full_name,
    };
    try {
      if (editingGoal) {
        await api.entities.AgentGoal.update(editingGoal.id, payload);
      } else {
        await api.entities.AgentGoal.create(payload);
      }
      toast({ title: 'Meta guardada correctamente', duration: 3000 });
      setShowForm(false);
      loadData();
    } catch {
      toast({ title: 'Error al guardar', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Eliminar esta meta?')) return;
    await api.entities.AgentGoal.delete(id);
    setGoals(prev => prev.filter(g => g.id !== id));
  };

  const handleAgentSelect = (agentId) => {
    const agent = agents.find(a => a.id === agentId);
    setForm(f => ({ ...f, agent_id: agentId, agent_name: agent?.full_name || '', agent_email: agent?.email || '' }));
  };

  const handlePipelineSelect = (pid) => {
    const p = pipelines.find(p => p.id === pid);
    setForm(f => ({ ...f, pipeline_id: pid === '__all__' ? '' : pid, pipeline_name: pid === '__all__' ? '' : (p?.name || '') }));
  };

  const today = new Date().toISOString().split('T')[0];

  const filteredGoals = filterAgent === '__all__' ? goals : goals.filter(g => g.agent_id === filterAgent);

  const isActive = (goal) => {
    if (!goal.start_date || !goal.end_date) return false;
    return today >= goal.start_date && today <= goal.end_date;
  };

  if (loading) return (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="h-8 w-8 animate-spin text-brand" />
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-2">
          <Select value={filterAgent} onValueChange={setFilterAgent}>
            <SelectTrigger className="w-[180px] h-9">
              <SelectValue placeholder="Todos los agentes" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">Todos los agentes</SelectItem>
              {agents.map(a => (
                <SelectItem key={a.id} value={a.id}>{a.full_name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={openNew} className="bg-brand hover:bg-brand-dark gap-2">
          <Plus className="h-4 w-4" /> Nueva Meta
        </Button>
      </div>

      {/* Goals List */}
      {filteredGoals.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <Target className="h-12 w-12 mx-auto mb-3 text-slate-300" />
          <p className="font-medium">No hay metas configuradas</p>
          <p className="text-sm mt-1">Haz clic en "Nueva Meta" para agregar una</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filteredGoals.map(goal => {
            const { wonLeads, wonAmount } = getActuals(goal);
            const active = isActive(goal);
            const allDone = (goal.target_leads > 0 ? wonLeads >= goal.target_leads : true) &&
              (goal.target_amount > 0 ? wonAmount >= goal.target_amount : true) &&
              (goal.target_leads > 0 || goal.target_amount > 0);
            return (
              <Card key={goal.id} className={cn("shadow-sm dark:bg-zinc-800/80 dark:border-zinc-700", allDone && "border-green-300 bg-green-50/40 dark:bg-green-900/20")}>
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-slate-800 dark:text-white">{goal.agent_name}</p>
                        {active ? (
                          <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">Activa</Badge>
                        ) : today > (goal.end_date || '') ? (
                          <Badge className="bg-slate-100 text-slate-500 border-0 text-xs">Finalizada</Badge>
                        ) : (
                          <Badge className="bg-amber-100 text-amber-700 border-0 text-xs">Futura</Badge>
                        )}
                        {allDone && <Badge className="bg-green-100 text-green-700 border-0 text-xs">🎉 Cumplido</Badge>}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-zinc-400 mt-1">
                        <Calendar className="h-3 w-3" />
                        {goal.start_date && goal.end_date ? (
                          <span>
                            {format(parseISO(goal.start_date), 'd MMM yyyy', { locale: es })} — {format(parseISO(goal.end_date), 'd MMM yyyy', { locale: es })}
                          </span>
                        ) : 'Sin período definido'}
                      </div>
                      {goal.pipeline_name && <p className="text-xs text-slate-400 dark:text-zinc-500 mt-0.5">{goal.pipeline_name}</p>}
                    </div>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-blue-600" onClick={() => openEdit(goal)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-600" onClick={() => handleDelete(goal.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  {goal.target_leads > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs text-slate-600 dark:text-zinc-300">
                        <span className="flex items-center gap-1"><Trophy className="h-3 w-3 text-amber-500" /> Leads ganados</span>
                        <span className="font-semibold">{wonLeads} / {goal.target_leads}</span>
                      </div>
                      <ProgressBar value={wonLeads} max={goal.target_leads} />
                    </div>
                  )}
                  {goal.target_amount > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs text-slate-600 dark:text-zinc-300">
                        <span className="flex items-center gap-1"><TrendingUp className="h-3 w-3 text-blue-500" /> Prima total</span>
                        <span className="font-semibold">${wonAmount.toLocaleString()} / ${goal.target_amount.toLocaleString()}</span>
                      </div>
                      <ProgressBar value={wonAmount} max={goal.target_amount} />
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Form Modal */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingGoal ? 'Editar Meta' : 'Nueva Meta'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label>Agente</Label>
              <Select value={form.agent_id} onValueChange={handleAgentSelect}>
                <SelectTrigger><SelectValue placeholder="Seleccionar agente" /></SelectTrigger>
                <SelectContent>
                  {agents.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Fecha inicio</Label>
                <Input type="date" value={form.start_date}
                  onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Fecha fin</Label>
                <Input type="date" value={form.end_date}
                  onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Pipeline (opcional)</Label>
              <Select value={form.pipeline_id || '__all__'} onValueChange={handlePipelineSelect}>
                <SelectTrigger><SelectValue placeholder="Todos los pipelines" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todos los pipelines</SelectItem>
                  {pipelines.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Meta de leads ganados</Label>
                <Input type="number" min="0" placeholder="0" value={form.target_leads}
                  onChange={e => setForm(f => ({ ...f, target_leads: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Meta de prima ($)</Label>
                <Input type="number" min="0" placeholder="0" value={form.target_amount}
                  onChange={e => setForm(f => ({ ...f, target_amount: e.target.value }))} />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowForm(false)}>Cancelar</Button>
              <Button className="flex-1 bg-brand hover:bg-brand-dark" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Guardar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}