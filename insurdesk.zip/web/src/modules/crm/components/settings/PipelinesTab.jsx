import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Loader2, Layers } from "lucide-react";
import PipelineEditor from '@/modules/crm/components/pipelines/PipelineEditor';

export default function PipelinesTab() {
  const [pipelines, setPipelines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingPipeline, setEditingPipeline] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  useEffect(() => { loadPipelines(); }, []);

  const loadPipelines = async () => {
    setLoading(true);
    const data = await api.entities.Pipeline.list('sort_order');
    setPipelines(data);
    setLoading(false);
  };

  const handleEdit = (pipeline) => {
    setEditingPipeline(pipeline);
    setShowEditor(true);
  };

  const handleNew = () => {
    setEditingPipeline(null);
    setShowEditor(true);
  };

  const handleSave = () => {
    setShowEditor(false);
    setEditingPipeline(null);
    loadPipelines();
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Eliminar este pipeline? Los leads asociados no serán afectados.')) return;
    setDeletingId(id);
    await api.entities.Pipeline.delete(id);
    loadPipelines();
    setDeletingId(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={handleNew} className="gap-2 bg-brand hover:bg-brand-dark">
          <Plus className="h-4 w-4" />
          Nuevo Pipeline
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-brand" />
        </div>
      ) : (
        <div className="space-y-4">
          {pipelines.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center text-slate-400">
                <Layers className="h-10 w-10 mx-auto mb-3 opacity-40" />
                <p>No hay pipelines configurados. Crea el primero.</p>
              </CardContent>
            </Card>
          )}

          {pipelines.map(pipeline => (
            <Card key={pipeline.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div
                      className="w-4 h-12 rounded-full flex-shrink-0 mt-1"
                      style={{ backgroundColor: pipeline.color || '#2F4F9D' }}
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-lg font-semibold text-slate-900 dark:text-white">{pipeline.name}</h3>
                        <Badge variant={pipeline.is_active ? 'default' : 'secondary'}>
                          {pipeline.is_active ? 'Activo' : 'Inactivo'}
                        </Badge>
                      </div>
                      {pipeline.description && (
                        <p className="text-sm text-slate-500 mb-3">{pipeline.description}</p>
                      )}
                      <div className="flex flex-wrap gap-2">
                        {(pipeline.stages || []).map((stage, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium text-white"
                            style={{ backgroundColor: stage.color || '#64748b' }}
                          >
                            {stage.label}
                            {stage.is_won && ' ✓'}
                            {stage.is_lost && ' ✗'}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(pipeline)} className="gap-1">
                      <Pencil className="h-3 w-3" />
                      Editar
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-500 border-red-200 hover:bg-red-50"
                      onClick={() => handleDelete(pipeline.id)}
                      disabled={deletingId === pipeline.id}
                    >
                      {deletingId === pipeline.id
                        ? <Loader2 className="h-3 w-3 animate-spin" />
                        : <Trash2 className="h-3 w-3" />
                      }
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showEditor && (
        <PipelineEditor
          pipeline={editingPipeline}
          onSave={handleSave}
          onClose={() => { setShowEditor(false); setEditingPipeline(null); }}
        />
      )}
    </div>
  );
}