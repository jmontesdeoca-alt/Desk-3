import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { FileSpreadsheet } from 'lucide-react';
import ImportHistoryTab from '@/modules/crm/components/imports/ImportHistoryTab';

export default function ImportsTab() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileSpreadsheet className="h-5 w-5 text-brand" /> Historial de Importaciones
        </CardTitle>
        <CardDescription>Registro de todas las importaciones de prospectos desde Excel. Puedes revertir una importación para eliminar los datos creados.</CardDescription>
      </CardHeader>
      <CardContent>
        <ImportHistoryTab />
      </CardContent>
    </Card>
  );
}
