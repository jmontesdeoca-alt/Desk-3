import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Tag, BarChart2 } from 'lucide-react';
import TagManager from '@/modules/crm/components/tags/TagManager';

export default function TagsTab() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            <Tag className="h-5 w-5 text-brand" /> Etiquetas de Clasificación
          </CardTitle>
          <CardDescription>Crea y gestiona etiquetas de colores para clasificar leads y prospectos</CardDescription>
        </div>
        <Link to={createPageUrl('TagsReport')}>
          <Button variant="outline" size="sm" className="gap-2">
            <BarChart2 className="h-4 w-4" /> Reporte
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <TagManager />
      </CardContent>
    </Card>
  );
}
