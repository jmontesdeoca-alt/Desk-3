import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Check, Tag, X } from "lucide-react";

// value: array of tag objects { id, name, color }
// onChange: (newTagsArray) => void
export default function TagSelector({ value = [], onChange, placeholder = "Agregar etiquetas" }) {
  const [availableTags, setAvailableTags] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    api.entities.Tag.filter({ is_active: true }, 'name').then(setAvailableTags).catch(() => {});
  }, []);

  const selectedIds = value.map(t => t.id);

  const toggleTag = (tag) => {
    if (selectedIds.includes(tag.id)) {
      onChange(value.filter(t => t.id !== tag.id));
    } else {
      onChange([...value, { id: tag.id, name: tag.name, color: tag.color }]);
    }
  };

  const removeTag = (tagId, e) => {
    e.stopPropagation();
    onChange(value.filter(t => t.id !== tagId));
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          className="w-full justify-start font-normal h-auto min-h-[44px] flex-wrap gap-1.5 px-3 py-2"
        >
          {value.length > 0 ? (
            value.map(tag => (
              <span
                key={tag.id}
                className="tag-chip inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                style={{ '--tag': tag.color }}
                onClick={(e) => removeTag(tag.id, e)}
              >
                {tag.name}
                <X className="h-3 w-3 opacity-70 hover:opacity-100" />
              </span>
            ))
          ) : (
            <span className="flex items-center gap-2 text-slate-400">
              <Tag className="h-4 w-4" />
              {placeholder}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-2" align="start">
        {availableTags.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-4 px-2">
            No hay etiquetas creadas. Crea una en Configuración → Etiquetas.
          </p>
        ) : (
          <div
            className="space-y-0.5 max-h-60 overflow-y-auto"
            onWheel={(e) => {
              const el = e.currentTarget;
              el.scrollTop += e.deltaY;
            }}
          >
            {availableTags.map(tag => (
              <button
                key={tag.id}
                type="button"
                onClick={() => toggleTag(tag)}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-slate-50 text-left transition-colors"
              >
                <span
                  className="w-3.5 h-3.5 rounded-full shrink-0"
                  style={{ backgroundColor: tag.color }}
                />
                <span className="text-sm flex-1 font-medium">{tag.name}</span>
                {tag.category && (
                  <span className="text-xs text-slate-400">{tag.category}</span>
                )}
                {selectedIds.includes(tag.id) && (
                  <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                )}
              </button>
            ))}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}