import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Loader2, Tag } from "lucide-react";

const PRESET_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4',
  '#2F4F9D', '#8b5cf6', '#ec4899', '#14b8a6', '#64748b',
  '#a855f7', '#10b981', '#f59e0b', '#0ea5e9', '#6366f1'
];

const CATEGORIES = [
  { value: 'fuente', label: 'Fuente' },
  { value: 'referido', label: 'Referido' },
  { value: 'personalizado', label: 'Personalizado' },
];

export default function TagManager() {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTag, setEditingTag] = useState(null);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({ name: '', color: '#2F4F9D', description: '', category: 'personalizado' });

  useEffect(() => { loadTags(); }, []);

  const loadTags = async () => {
    setLoading(true);
    const data = await api.entities.Tag.list('name');
    setTags(data);
    setLoading(false);
  };

  const openCreate = () => {
    setEditingTag(null);
    setFormData({ name: '', color: '#2F4F9D', description: '', category: 'personalizado' });
    setShowForm(true);
  };

  const openEdit = (tag) => {
    setEditingTag(tag);
    setFormData({ name: tag.name, color: tag.color, description: tag.description || '', category: tag.category || 'personalizado' });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) return;
    setSaving(true);
    if (editingTag) {
      await api.entities.Tag.update(editingTag.id, formData);
    } else {
      await api.entities.Tag.create({ ...formData, is_active: true });
    }
    await loadTags();
    setShowForm(false);
    setSaving(false);
  };

  const handleDelete = async (tag) => {
    if (!confirm(`¿Eliminar la etiqueta "${tag.name}"?`)) return;
    await api.entities.Tag.delete(tag.id);
    setTags(tags.filter(t => t.id !== tag.id));
  };

  const categoryLabel = (cat) => CATEGORIES.find(c => c.value === cat)?.label || cat;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500">
          {tags.length} etiqueta{tags.length !== 1 ? 's' : ''} creada{tags.length !== 1 ? 's' : ''}
        </p>
        <Button onClick={openCreate} size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          Nueva Etiqueta
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-slate-400" />
        </div>
      ) : tags.length === 0 ? (
        <div className="text-center py-10 text-slate-400">
          <Tag className="h-10 w-10 mx-auto mb-2 opacity-40" />
          <p className="text-sm">No hay etiquetas. Crea la primera para empezar a clasificar leads y prospectos.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {tags.map(tag => (
            <div key={tag.id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-zinc-800 rounded-lg border dark:border-zinc-700">
              <span className="w-5 h-5 rounded-full shrink-0" style={{ backgroundColor: tag.color }} />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate dark:text-white">{tag.name}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <Badge variant="outline" className="text-xs py-0">{categoryLabel(tag.category)}</Badge>
                  {tag.description && (
                    <span className="text-xs text-slate-400 dark:text-zinc-500 truncate">{tag.description}</span>
                  )}
                </div>
              </div>
              <div className="flex gap-1 shrink-0">
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(tag)}>
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500 hover:text-red-600" onClick={() => handleDelete(tag)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{editingTag ? 'Editar Etiqueta' : 'Nueva Etiqueta'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nombre *</Label>
              <Input
                value={formData.name}
                onChange={e => setFormData(p => ({ ...p, name: e.target.value }))}
                placeholder="Ej: Meta, Referido, Base de datos..."
              />
            </div>
            <div>
              <Label>Categoría</Label>
              <Select value={formData.category} onValueChange={v => setFormData(p => ({ ...p, category: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Color</Label>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex flex-wrap gap-2">
                  {PRESET_COLORS.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData(p => ({ ...p, color }))}
                      className="w-7 h-7 rounded-full border-2 transition-transform hover:scale-110"
                      style={{
                        backgroundColor: color,
                        borderColor: formData.color === color ? '#1e293b' : 'transparent'
                      }}
                    />
                  ))}
                </div>
                <input
                  type="color"
                  value={formData.color}
                  onChange={e => setFormData(p => ({ ...p, color: e.target.value }))}
                  className="w-8 h-8 rounded cursor-pointer border border-slate-200"
                />
              </div>
            </div>
            <div>
              <Label>Descripción (opcional)</Label>
              <Input
                value={formData.description}
                onChange={e => setFormData(p => ({ ...p, description: e.target.value }))}
                placeholder="Ej: Leads provenientes de Facebook Ads"
              />
            </div>
            <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg">
              <span className="w-4 h-4 rounded-full" style={{ backgroundColor: formData.color }} />
              <span className="text-sm font-medium">{formData.name || 'Vista previa'}</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowForm(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saving || !formData.name.trim()}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {editingTag ? 'Guardar' : 'Crear'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}