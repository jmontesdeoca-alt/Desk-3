import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { Loader2, Copy } from "lucide-react";
import { toast } from "sonner";

export default function CloneLeadDialog({ open, onClose, lead, onCloned }) {
  const [pipelines, setPipelines] = useState([]);
  const [agents, setAgents] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedPipelineId, setSelectedPipelineId] = useState('');
  const [selectedStage, setSelectedStage] = useState('');
  const [selectedAgentId, setSelectedAgentId] = useState('');
  const [selectedAgentName, setSelectedAgentName] = useState('');
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(false);

  useEffect(() => {
    if (open) {
      setSelectedPipelineId('');
      setSelectedStage('');
      setSelectedAgentId(lead?.assigned_agent_id || '');
      setSelectedAgentName(lead?.assigned_agent_name || '');
      loadData();
    }
  }, [open, lead]);

  const loadData = async () => {
    setDataLoading(true);
    try {
      // Paralelizar ambas llamadas
      const [pipelinesData, agentsRes, user] = await Promise.all([
        api.entities.Pipeline.list('sort_order', 50),
        api.functions.invoke('listAgents', {}),
        api.auth.me()
      ]);
      setPipelines(pipelinesData.filter(p => p.is_active !== false));
      setAgents(agentsRes.data?.agents || []);
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading clone dialog data:', error);
    } finally {
      setDataLoading(false);
    }
  };

  const selectedPipeline = pipelines.find(p => p.id === selectedPipelineId);
  const stages = selectedPipeline?.stages || [];

  const handlePipelineChange = (pid) => {
    setSelectedPipelineId(pid);
    setSelectedStage('');
  };

  const handleAgentChange = (agentId) => {
    const agent = agents.find(a => a.id === agentId);
    setSelectedAgentId(agentId);
    setSelectedAgentName(agent?.full_name || '');
  };

  const handleClone = async () => {
    if (!selectedPipelineId || !selectedStage) {
      toast.error('Selecciona pipeline y etapa destino');
      return;
    }

    setLoading(true);
    try {
      await api.functions.invoke('cloneLead', {
        lead_id: lead.id,
        target_pipeline_id: selectedPipelineId,
        target_stage: selectedStage,
        assigned_agent_id: selectedAgentId || lead.assigned_agent_id,
        assigned_agent_name: selectedAgentName || lead.assigned_agent_name,
        caller_name: currentUser?.full_name || ''
      });
      toast.success(`Lead clonado exitosamente al pipeline "${selectedPipeline?.name}"`);
      onCloned?.();
      onClose();
    } catch (error) {
      toast.error('Error al clonar el lead: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-md max-h-[95dvh] overflow-y-auto p-0 gap-0 rounded-t-2xl sm:rounded-2xl">
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-slate-100 sticky top-0 bg-white z-10">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Copy className="h-5 w-5 text-blue-600" />
            Clonar Lead
          </DialogTitle>
        </DialogHeader>

        <div className="px-5 py-4 space-y-5">
            <div className="bg-slate-50 rounded-lg p-3 text-sm text-slate-600">
              <span className="font-medium">Lead:</span> {lead?.prospect_name} · {lead?.branch}
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Pipeline destino <span className="text-red-500">*</span></Label>
              <Select value={selectedPipelineId} onValueChange={handlePipelineChange}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder="Selecciona un pipeline" />
                </SelectTrigger>
                <SelectContent>
                  {pipelines.map(p => (
                    <SelectItem key={p.id} value={p.id} className="text-base py-3">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: p.color || '#2F4F9D' }} />
                        {p.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Etapa destino <span className="text-red-500">*</span></Label>
              <Select value={selectedStage} onValueChange={setSelectedStage} disabled={!selectedPipelineId}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder={selectedPipelineId ? "Selecciona una etapa" : "Primero selecciona un pipeline"} />
                </SelectTrigger>
                <SelectContent>
                  {stages.map(s => (
                    <SelectItem key={s.key} value={s.key} className="text-base py-3">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: s.color || '#64748b' }} />
                        {s.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Agente</Label>
              <Select value={selectedAgentId} onValueChange={handleAgentChange}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder="Mismo agente actual" />
                </SelectTrigger>
                <SelectContent>
                  {agents.map(a => (
                    <SelectItem key={a.id} value={a.id} className="text-base py-3">
                      {a.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!selectedAgentId && (
                <p className="text-xs text-slate-400">Se mantiene: {lead?.assigned_agent_name}</p>
              )}
            </div>

            <div className="flex gap-3 pb-2">
              <Button variant="outline" onClick={onClose} disabled={loading} className="flex-1 h-12 text-base">Cancelar</Button>
              <Button onClick={handleClone} disabled={loading || !selectedPipelineId || !selectedStage} className="flex-1 h-12 text-base font-semibold gap-2">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Copy className="h-4 w-4" />}
                Clonar
              </Button>
            </div>
          </div>
      </DialogContent>
    </Dialog>
  );
}