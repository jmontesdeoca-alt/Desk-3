import React, { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, X, ChevronDown, ChevronUp } from "lucide-react";
import { api } from '@/api/client';

const BRANCHES = ["Vida", "Salud", "Viaje", "Inversiones", "General"];
const STAGES = ["NUEVO", "CONTACTADO", "COTIZADO", "NEGOCIANDO", "GANADO", "PERDIDO"];
const COUNTRIES = [
  "Ecuador", "Colombia", "Perú", "México", "Estados Unidos", "España", 
  "Argentina", "Chile", "Venezuela", "Panamá", "Costa Rica", "Guatemala"
];

export default function LeadFilters({ filters, onFiltersChange, userRole }) {
  const [expanded, setExpanded] = useState(false);
  const [agents, setAgents] = useState([]);
  const [tags, setTags] = useState([]);

  useEffect(() => {
    if (userRole === 'admin_crm' || userRole === 'jefatura_crm' || userRole === 'admin') {
      loadAgents();
    }
    loadTags();
  }, [userRole]);

  const loadAgents = async () => {
    try {
      const res = await api.functions.invoke('listAgents', {});
      setAgents(res.data?.agents || []);
    } catch (error) {
      console.error('Error loading agents:', error);
    }
  };

  const loadTags = async () => {
    try {
      const data = await api.entities.Tag.filter({ is_active: true }, 'name', 100);
      setTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const updateFilter = (key, value) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const clearFilters = () => {
    onFiltersChange({
      search: '',
      branch: '',
      stage: '',
      agent_id: '',
      country: '',
      min_premium: '',
      max_premium: '',
      days_inactive: '',
      tag_id: '',
      lead_status: 'ACTIVO'
    });
  };

  const hasActiveFilters = Object.values(filters).some(v => v && v !== '');

  return (
    <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-sm border dark:border-zinc-700 p-4 mb-6">
      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar por prospecto, compañía..."
            value={filters.search || ''}
            onChange={(e) => updateFilter('search', e.target.value)}
            className="pl-10"
          />
        </div>

        <Select value={filters.branch || ''} onValueChange={(v) => updateFilter('branch', v)}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Ramo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={null}>Todos</SelectItem>
            {BRANCHES.map(b => (
              <SelectItem key={b} value={b}>{b}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.stage || ''} onValueChange={(v) => updateFilter('stage', v)}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Etapa" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={null}>Todas</SelectItem>
            {STAGES.map(s => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.lead_status || 'ACTIVO'} onValueChange={(v) => updateFilter('lead_status', v)}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ACTIVO">Activos</SelectItem>
            <SelectItem value="ARCHIVADO">Archivados</SelectItem>
            <SelectItem value={null}>Todos</SelectItem>
          </SelectContent>
        </Select>

        {tags.length > 0 && (
          <Select value={filters.tag_id || ''} onValueChange={(v) => updateFilter('tag_id', v)}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Etiqueta" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Todas</SelectItem>
              {tags.map(t => (
                <SelectItem key={t.id} value={t.id}>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full inline-block shrink-0" style={{ backgroundColor: t.color }} />
                    {t.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        <Button
          variant="outline"
          size="sm"
          onClick={() => setExpanded(!expanded)}
          className="gap-2"
        >
          <Filter className="h-4 w-4" />
          Más filtros
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>

        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="text-slate-500">
            <X className="h-4 w-4 mr-1" />
            Limpiar
          </Button>
        )}
      </div>

      {expanded && (
        <div className="mt-4 pt-4 border-t dark:border-zinc-700 grid grid-cols-2 md:grid-cols-4 gap-4">
          {(userRole === 'admin_crm' || userRole === 'jefatura_crm' || userRole === 'admin') && (
            <div>
              <label className="text-xs font-medium text-slate-600 dark:text-zinc-400 mb-1 block">Agente</label>
              <Select value={filters.agent_id || ''} onValueChange={(v) => updateFilter('agent_id', v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Todos</SelectItem>
                  {agents.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <label className="text-xs font-medium text-slate-600 dark:text-zinc-400 mb-1 block">País</label>
            <Select value={filters.country || ''} onValueChange={(v) => updateFilter('country', v)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Todos</SelectItem>
                {COUNTRIES.map(c => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-600 dark:text-zinc-400 mb-1 block">Prima mínima</label>
            <Input
              type="number"
              placeholder="0"
              value={filters.min_premium || ''}
              onChange={(e) => updateFilter('min_premium', e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-600 dark:text-zinc-400 mb-1 block">Prima máxima</label>
            <Input
              type="number"
              placeholder="Sin límite"
              value={filters.max_premium || ''}
              onChange={(e) => updateFilter('max_premium', e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-600 dark:text-zinc-400 mb-1 block">Sin actividad (días)</label>
            <Input
              type="number"
              placeholder="Ej: 14"
              value={filters.days_inactive || ''}
              onChange={(e) => updateFilter('days_inactive', e.target.value)}
            />
          </div>
        </div>
      )}
    </div>
  );
}