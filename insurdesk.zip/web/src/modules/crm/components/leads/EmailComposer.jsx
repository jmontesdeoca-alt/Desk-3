import React, { useState } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Mail, Paperclip, Send, X, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function EmailComposer({ open, onClose, lead, prospect, onEmailSent }) {
  const [form, setForm] = useState({
    to: prospect?.email || '',
    subject: '',
    body: ''
  });
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    try {
      const uploaded = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await api.integrations.Core.UploadFile({ file });
          return { name: file.name, url: file_url };
        })
      );
      setAttachments(prev => [...prev, ...uploaded]);
    } catch {
      toast.error('Error al subir archivos');
    } finally {
      setUploading(false);
    }
  };

  const removeAttachment = (idx) => {
    setAttachments(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSend = async () => {
    if (!form.to || !form.subject || !form.body) {
      toast.error('Completa todos los campos requeridos');
      return;
    }
    setSending(true);
    try {
      const currentUser = await api.auth.me();

      // 1. Create activity first so we have the activity_id for the tracking pixel
      const activity = await api.entities.LeadActivity.create({
        lead_id: lead.id,
        lead_external_id: lead.external_id || '',
        activity_type: 'email',
        description: `Email enviado a ${form.to} | Asunto: ${form.subject}`,
        email_to: form.to,
        email_subject: form.subject,
        email_html: null,
        created_by_name: currentUser.full_name
      });

      // 2. Send email with activity_id so tracking pixel can be injected
      const res = await api.functions.invoke('sendTrackedEmail', {
        to: form.to,
        subject: form.subject,
        body: form.body,
        from_name: currentUser.full_name,
        attachments: attachments,
        activity_id: activity.id,
        lead_id: lead.id
      });
      if (res.data?.error) throw new Error(res.data.error);

      // 3. Update activity with the final HTML (which includes the tracking pixel)
      if (res.data?.html) {
        await api.entities.LeadActivity.update(activity.id, { email_html: res.data.html });
      }

      // 4. Update last activity timestamp on lead
      await api.entities.Lead.update(lead.id, { last_activity_at: new Date().toISOString() });

      toast.success('Email enviado correctamente');
      onEmailSent?.();
      onClose();
      setForm({ to: prospect?.email || '', subject: '', body: '' });
      setAttachments([]);
    } catch (err) {
      toast.error('Error al enviar el email: ' + err.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-blue-600" />
            Enviar Email — {lead?.prospect_name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          <div>
            <Label>Para *</Label>
            <Input
              value={form.to}
              onChange={e => setForm(f => ({ ...f, to: e.target.value }))}
              placeholder="email@ejemplo.com"
              className="mt-1"
            />
          </div>

          <div>
            <Label>Asunto *</Label>
            <Input
              value={form.subject}
              onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
              placeholder="Asunto del correo"
              className="mt-1"
            />
          </div>

          <div>
            <Label>Mensaje *</Label>
            <Textarea
              value={form.body}
              onChange={e => setForm(f => ({ ...f, body: e.target.value }))}
              placeholder="Escribe tu mensaje..."
              rows={8}
              className="mt-1"
            />
          </div>

          {/* Attachments */}
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {attachments.map((att, idx) => (
                <Badge key={idx} variant="secondary" className="gap-1 pr-1">
                  <Paperclip className="h-3 w-3" />
                  {att.name}
                  <button onClick={() => removeAttachment(idx)} className="ml-1 hover:text-red-500">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <label className="cursor-pointer">
              <input type="file" multiple className="hidden" onChange={handleFileChange} disabled={uploading} />
              <Button type="button" variant="outline" size="sm" asChild className="cursor-pointer">
                <span>
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Paperclip className="h-4 w-4 mr-2" />}
                  Adjuntar archivo
                </span>
              </Button>
            </label>

            <div className="flex gap-2">
              <Button variant="outline" onClick={onClose} disabled={sending}>Cancelar</Button>
              <Button onClick={handleSend} disabled={sending} className="gap-2">
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                Enviar
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}