import React, { useState } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Clock, Plus } from "lucide-react";
import { toast } from "sonner";
import { addDays } from "date-fns";
import { localDateTimeToISO, localNowForInput } from '@/lib/dateUtils';

export default function ReminderForm({ lead, open, onOpenChange, onSuccess }) {
  const [formData, setFormData] = useState({
    reminder_type: 'seguimiento',
    description: '',
    days_ahead: 3,
    custom_date: ''
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const user = await api.auth.me();
      
      // Calcular la fecha del recordatorio
      let reminderDate;
      if (formData.custom_date) {
        // localDateTimeToISO treats the input as local time (fixes UTC offset bug)
        reminderDate = localDateTimeToISO(formData.custom_date);
      } else {
        reminderDate = addDays(new Date(), formData.days_ahead).toISOString();
      }

      await api.entities.FollowUpReminder.create({
        lead_id: lead.id,
        lead_name: lead.external_id,
        prospect_name: lead.prospect_name,
        assigned_to_id: user.id,
        assigned_to_name: user.full_name,
        reminder_date: reminderDate,
        reminder_type: formData.reminder_type,
        description: formData.description || `Seguimiento de ${lead.prospect_name}`,
        status: 'pendiente'
      });

      toast.success('Recordatorio creado correctamente');
      onSuccess?.();
      onOpenChange(false);
      
      // Reset form
      setFormData({
        reminder_type: 'seguimiento',
        description: '',
        days_ahead: 3,
        custom_date: ''
      });
    } catch (error) {
      console.error('Error creating reminder:', error);
      toast.error('Error al crear el recordatorio');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-brand" />
            Crear Recordatorio
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Tipo de Recordatorio</Label>
            <Select
              value={formData.reminder_type}
              onValueChange={(value) => setFormData({ ...formData, reminder_type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="seguimiento">Seguimiento General</SelectItem>
                <SelectItem value="llamada">Llamada Telefónica</SelectItem>
                <SelectItem value="email">Correo Electrónico</SelectItem>
                <SelectItem value="reunión">Reunión</SelectItem>
                <SelectItem value="otro">Otro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Descripción</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="¿Qué necesitas recordar?"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Días Adelante</Label>
              <Select
                value={formData.days_ahead.toString()}
                onValueChange={(value) => setFormData({ ...formData, days_ahead: parseInt(value), custom_date: '' })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">En 1 día</SelectItem>
                  <SelectItem value="2">En 2 días</SelectItem>
                  <SelectItem value="3">En 3 días</SelectItem>
                  <SelectItem value="5">En 5 días</SelectItem>
                  <SelectItem value="7">En 1 semana</SelectItem>
                  <SelectItem value="14">En 2 semanas</SelectItem>
                  <SelectItem value="30">En 1 mes</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>O Fecha Personalizada</Label>
              <Input
                type="datetime-local"
                value={formData.custom_date}
                onChange={(e) => setFormData({ ...formData, custom_date: e.target.value })}
                min={localNowForInput()}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={saving} className="bg-brand">
              <Plus className="h-4 w-4 mr-2" />
              Crear Recordatorio
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}