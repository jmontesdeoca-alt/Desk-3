import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, MessageSquare, ExternalLink, ThermometerSun, ThermometerSnowflake, Archive, Eye, Bell, Copy } from "lucide-react";
import { formatDistanceToNow, differenceInDays } from 'date-fns';
import { es } from 'date-fns/locale';
import CloneLeadDialog from './CloneLeadDialog';

const stageColors = {
  'NUEVO': 'bg-slate-100 text-slate-700',
  'CONTACTADO': 'bg-blue-100 text-blue-700',
  'COTIZADO': 'bg-amber-100 text-amber-700',
  'NEGOCIANDO': 'bg-purple-100 text-purple-700',
  'GANADO': 'bg-emerald-100 text-emerald-700',
  'PERDIDO': 'bg-red-100 text-red-700'
};

const branchColors = {
  'Vida': 'bg-purple-100 text-purple-700',
  'Salud': 'bg-rose-100 text-rose-700',
  'Viaje': 'bg-sky-100 text-sky-700',
  'Inversiones': 'bg-emerald-100 text-emerald-700',
  'General': 'bg-slate-100 text-slate-700'
};

export default function LeadsList({ leads, onEdit, onDelete, onAddActivity, onAddReminder, onArchive, onView, onCloned }) {
  // Con miles de leads se dibuja por tandas para que la pantalla no se congele
  const [shown, setShown] = useState(50);
  const [cloneLead, setCloneLead] = useState(null);
  const formatCurrency = (amount, currency = 'USD') => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="bg-white dark:bg-zinc-900 rounded-xl shadow-sm border dark:border-zinc-700 overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50 dark:bg-zinc-800">
            <TableHead className="font-semibold dark:text-zinc-300">Prospecto</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300">Ramo</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300">Compañía</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300">Prima</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300">Etapa</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300">Agente</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300">Última Actividad</TableHead>
            <TableHead className="font-semibold dark:text-zinc-300 text-right">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {leads.slice(0, shown).map(lead => {
            const lastActivityDate = lead.last_activity_at ? new Date(lead.last_activity_at) : null;
            const daysSinceActivity = lastActivityDate ? differenceInDays(new Date(), lastActivityDate) : null;
            
            const isHot = daysSinceActivity !== null && daysSinceActivity <= 7 && 
              ['CONTACTADO', 'COTIZADO', 'NEGOCIANDO'].includes(lead.pipeline_stage);
            const isCold = daysSinceActivity !== null && daysSinceActivity > 14;

            return (
              <TableRow key={lead.id} className="hover:bg-slate-50/50 dark:hover:bg-zinc-800/60 dark:border-zinc-700">
                <TableCell>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium">{lead.prospect_name}</span>
                    {isHot && <ThermometerSun className="h-4 w-4 text-orange-500" />}
                    {isCold && <ThermometerSnowflake className="h-4 w-4 text-blue-400" />}
                    {Array.isArray(lead.tags) && lead.tags.map(tag => (
                      <span
                        key={tag.id || tag}
                        className="tag-chip inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium"
                        style={{ '--tag': tag.color || '#64748b' }}
                      >
                        {tag.name || tag}
                      </span>
                    ))}
                  </div>
                  <span className="text-xs text-slate-500 dark:text-zinc-400">{lead.external_id}</span>
                </TableCell>
                <TableCell>
                  <Badge className={branchColors[lead.branch] || branchColors['General']}>
                    {lead.branch}
                  </Badge>
                </TableCell>
                <TableCell className="text-slate-600 dark:text-zinc-300">
                  {lead.company_name || '-'}
                </TableCell>
                <TableCell className="font-semibold text-emerald-700 dark:text-emerald-400">
                  {formatCurrency(lead.premium_estimated, lead.currency)}
                </TableCell>
                <TableCell>
                  <Badge className={stageColors[lead.pipeline_stage]}>
                    {lead.pipeline_stage}
                  </Badge>
                </TableCell>
                <TableCell className="text-slate-600 dark:text-zinc-300">
                  {lead.assigned_agent_name || '-'}
                </TableCell>
                <TableCell className="text-slate-500 dark:text-zinc-400 text-sm">
                  {lastActivityDate 
                    ? formatDistanceToNow(lastActivityDate, { addSuffix: true, locale: es })
                    : '-'
                  }
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onView?.(lead)}
                      title="Ver detalles"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onAddActivity?.(lead)}
                      title="Agregar actividad"
                    >
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onAddReminder?.(lead)}
                      title="Crear recordatorio"
                    >
                      <Bell className="h-4 w-4" />
                    </Button>
                    {['GANADO', 'PERDIDO'].includes(lead.pipeline_stage) && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onArchive?.(lead)}
                        title={lead.lead_status === 'ARCHIVADO' ? 'Desarchivar' : 'Archivar'}
                      >
                        <Archive className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEdit?.(lead)}
                      title="Editar"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setCloneLead(lead)}
                      title="Clonar lead"
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete?.(lead)}
                      className="text-red-600 hover:text-red-700"
                      title="Eliminar"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    {lead.gportal_link && (
                      <a
                        href={lead.gportal_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 hover:bg-slate-100 rounded"
                        title="Ver en InsurDesk"
                      >
                        <ExternalLink className="h-4 w-4 text-blue-600" />
                      </a>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
          {leads.length === 0 && (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-12 text-slate-500 dark:text-zinc-400">
                No se encontraron leads
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      {leads.length > shown && (
        <div className="flex items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm text-muted-foreground">
          <span>Mostrando {shown} de {leads.length} leads</span>
          <Button variant="outline" size="sm" onClick={() => setShown((n) => n + 50)}>Mostrar 50 más</Button>
        </div>
      )}
    <CloneLeadDialog
      open={!!cloneLead}
      onClose={() => setCloneLead(null)}
      lead={cloneLead}
      onCloned={() => { setCloneLead(null); onCloned?.(); }}
    />
    </div>
  );
}