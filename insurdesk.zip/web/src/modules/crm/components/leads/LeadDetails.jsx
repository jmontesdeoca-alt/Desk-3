import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  User, Building2, DollarSign, Calendar, TrendingUp, 
  FileText, History, Phone, Mail, MapPin, Briefcase,
  MessageSquare, Clock, MailOpen, MessageCircle,
  CreditCard, Globe, Heart, Flag, StickyNote, ChevronDown, ChevronUp,
  Plus, ArrowRightLeft, Loader2, CalendarPlus
} from "lucide-react";
import { addHours } from 'date-fns';
import { cn } from "@/lib/utils";
import { toast } from 'sonner';
import { localDateAndTimeToISO, formatLocalDateTime } from '@/lib/dateUtils';
import EmailComposer from './EmailComposer';
import EmailPreviewModal from './EmailPreviewModal';
import AppointmentProposalForm from '@/modules/citas/components/appointments/AppointmentProposalForm';
import { useModules } from '@/lib/ModulesContext';

const branchColors = {
  'Vida': 'bg-purple-100 text-purple-700 border-purple-200',
  'Salud': 'bg-rose-100 text-rose-700 border-rose-200',
  'Viaje': 'bg-sky-100 text-sky-700 border-sky-200',
  'Inversiones': 'bg-emerald-100 text-emerald-700 border-emerald-200',
  'General': 'bg-slate-100 text-slate-700 border-slate-200'
};

const stageColors = {
  'NUEVO': 'bg-slate-500',
  'CONTACTADO': 'bg-blue-500',
  'COTIZADO': 'bg-amber-500',
  'NEGOCIANDO': 'bg-purple-500',
  'GANADO': 'bg-emerald-500',
  'PERDIDO': 'bg-red-500'
};

const activityIcons = {
  'llamada': Phone,
  'whatsapp': MessageSquare,
  'email': Mail,
  'reunión': Briefcase,
  'nota': FileText,
  'otro': Clock
};

const ACTIVITY_TYPES = [
  { value: 'llamada', label: 'Llamada', icon: Phone },
  { value: 'whatsapp', label: 'WhatsApp', icon: MessageSquare },
  { value: 'reunión', label: 'Reunión', icon: Calendar },
  { value: 'nota', label: 'Nota', icon: FileText },
  { value: 'otro', label: 'Otro', icon: Clock },
];

export default function LeadDetails({ open, onClose, leadId, onStageChanged }) {
  const { isEnabled } = useModules();
  const [lead, setLead] = useState(null);
  const [prospect, setProspect] = useState(null);
  const [pipeline, setPipeline] = useState(null);
  const [activities, setActivities] = useState([]);
  const [openedEmails, setOpenedEmails] = useState({});
  const [loading, setLoading] = useState(true);
  const [showEmailComposer, setShowEmailComposer] = useState(false);
  const [showProposalForm, setShowProposalForm] = useState(false);
  const [emailPreview, setEmailPreview] = useState(null);
  const [prospectExpanded, setProspectExpanded] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  // Inline activity form state
  const [activityType, setActivityType] = useState('');
  const [activityDesc, setActivityDesc] = useState('');
  const [activityMeetingDate, setActivityMeetingDate] = useState('');
  const [activityMeetingTime, setActivityMeetingTime] = useState('09:00');
  const [savingActivity, setSavingActivity] = useState(false);

  // Stage change state
  const [changingStage, setChangingStage] = useState(false);

  useEffect(() => {
    if (open && leadId) {
      loadData();
    }
  }, [open, leadId]);

  const loadData = async () => {
    try {
      setLoading(true);
      const user = await api.auth.me();
      setCurrentUser(user);

      const [leadData, activitiesData, openTrackingData] = await Promise.all([
        api.entities.Lead.filter({ id: leadId }),
        api.entities.LeadActivity.filter({ lead_id: leadId }, '-created_date'),
        api.entities.EmailOpenTracking.filter({ lead_id: leadId })
      ]);

      if (leadData.length > 0) {
        const l = leadData[0];
        setLead(l);
        
        const promises = [];
        if (l.prospect_id) {
          promises.push(api.entities.Prospect.filter({ id: l.prospect_id }).then(d => {
            if (d.length > 0) setProspect(d[0]);
          }));
        }
        if (l.pipeline_id) {
          promises.push(api.entities.Pipeline.filter({ id: l.pipeline_id }).then(d => {
            if (d.length > 0) setPipeline(d[0]);
          }));
        }
        await Promise.all(promises);
      }

      setActivities(activitiesData);
      const openMap = {};
      openTrackingData.forEach(t => { openMap[t.activity_id] = t; });
      setOpenedEmails(openMap);
    } catch (error) {
      console.error('Error loading lead details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveActivity = async () => {
    if (!activityType || !activityDesc.trim() || !lead) return;
    setSavingActivity(true);
    try {
      const now = new Date().toISOString();
      await api.entities.LeadActivity.create({
        lead_id: lead.id,
        lead_external_id: lead.external_id,
        activity_type: activityType,
        description: activityDesc,
        created_by_name: currentUser?.full_name || '',
      });
      await api.entities.Lead.update(lead.id, { last_activity_at: now });

      if (activityType === 'reunión' && activityMeetingDate && activityMeetingTime) {
        const start = new Date(localDateAndTimeToISO(activityMeetingDate, activityMeetingTime));
        const end = addHours(start, 1);
        api.functions.invoke('createUserGoogleCalendarEvent', {
          eventData: {
            title: `Reunión: ${lead.prospect_name}`,
            description: activityDesc,
            event_type: 'reunión',
            start_datetime: start.toISOString(),
            end_datetime: end.toISOString(),
            lead_id: lead.id,
            lead_name: lead.prospect_name,
            prospect_id: lead.prospect_id,
            assigned_to_id: currentUser?.id,
            assigned_to_name: currentUser?.full_name,
          }
        }).catch(() => {});
      }

      toast.success('Actividad registrada');
      setActivityType('');
      setActivityDesc('');
      setActivityMeetingDate('');
      setActivityMeetingTime('09:00');
      // Reload activities only
      const updated = await api.entities.LeadActivity.filter({ lead_id: lead.id }, '-created_date');
      setActivities(updated);
      setLead(prev => ({ ...prev, last_activity_at: now }));
    } catch (e) {
      toast.error('Error al guardar');
    } finally {
      setSavingActivity(false);
    }
  };

  const handleStageChange = async (newStage) => {
    if (!lead || newStage === lead.pipeline_stage) return;
    setChangingStage(true);
    try {
      const now = new Date().toISOString();
      await api.entities.Lead.update(lead.id, { pipeline_stage: newStage, last_activity_at: now });
      setLead(prev => ({ ...prev, pipeline_stage: newStage, last_activity_at: now }));
      onStageChanged?.(lead.id, newStage);
      toast.success('Etapa actualizada');
    } catch (e) {
      toast.error('Error al cambiar etapa');
    } finally {
      setChangingStage(false);
    }
  };

  const formatCurrency = (amount, currency = 'USD') => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (!open) return null;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-2xl lg:max-w-4xl overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin h-8 w-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
          </div>
        ) : lead ? (
          <>
            <SheetHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <SheetTitle className="text-2xl">{lead.prospect_name}</SheetTitle>
                  <SheetDescription className="text-base mt-1">
                    Lead #{lead.external_id || lead.id}
                  </SheetDescription>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge className={cn("text-sm px-3 py-1", branchColors[lead.branch] || branchColors['General'])}>
                    {lead.branch}
                  </Badge>
                  <Badge className={cn("text-sm px-3 py-1 text-white", stageColors[lead.pipeline_stage])}>
                    {lead.pipeline_stage}
                  </Badge>
                </div>
              </div>
            </SheetHeader>

            <div className="mt-6 space-y-6">
              {/* Financial Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-emerald-600" />
                    Información Financiera
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-slate-500 mb-1">Prima Estimada</p>
                      <p className="text-2xl font-bold text-emerald-600">
                        {formatCurrency(lead.premium_estimated || 0, lead.currency)}
                      </p>
                    </div>
                    {lead.deductible_estimated && (
                      <div>
                        <p className="text-sm text-slate-500 mb-1">Deducible Estimado</p>
                        <p className="text-xl font-semibold text-slate-700">
                          {formatCurrency(lead.deductible_estimated, lead.currency)}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Product Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Briefcase className="h-5 w-5 text-blue-600" />
                    Producto Ofrecido
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {lead.company_name && (
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-slate-400" />
                        <span className="font-medium">{lead.company_name}</span>
                      </div>
                    )}
                    {lead.product_name && (
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-slate-400" />
                        <span>{lead.product_name}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Prospect Info */}
              {prospect && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2 justify-between">
                      <span className="flex items-center gap-2">
                        <User className="h-5 w-5 text-purple-600" />
                        Información del Prospecto
                      </span>
                      <div className="flex flex-col items-end gap-1.5">
                        {prospect.email && (
                          <Button size="sm" variant="outline" className="gap-1.5 w-full" onClick={() => setShowEmailComposer(true)}>
                            <Mail className="h-4 w-4" />
                            Enviar Email
                          </Button>
                        )}
                        {isEnabled('citas') && (
                          <Button size="sm" variant="outline" className="gap-1.5 w-full border-brand text-brand hover:bg-brand hover:text-white" onClick={() => setShowProposalForm(true)}>
                            <CalendarPlus className="h-4 w-4" />
                            Proponer Cita
                          </Button>
                        )}
                        {prospect.phone && (
                          <a
                            href={`https://wa.me/${prospect.phone.replace(/\D/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-full"
                          >
                            <Button size="sm" variant="outline" className="gap-1.5 w-full border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white">
                              <MessageCircle className="h-4 w-4" />
                              WhatsApp
                            </Button>
                          </a>
                        )}
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* Always visible: email + phone */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {prospect.email && (
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-slate-400 shrink-0" />
                          <span className="text-sm truncate">{prospect.email}</span>
                        </div>
                      )}
                      {prospect.phone && (
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-slate-400 shrink-0" />
                          <span className="text-sm">{prospect.phone}</span>
                        </div>
                      )}
                    </div>

                    {/* Toggle button */}
                    <button
                      onClick={() => setProspectExpanded(p => !p)}
                      className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {prospectExpanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                      {prospectExpanded ? 'Ocultar datos adicionales' : 'Ver más información'}
                    </button>

                    {/* Expandable section */}
                    {prospectExpanded && (
                      <div className="space-y-3 pt-1">
                        {/* Secondary phone + ID */}
                        {(prospect.phone_secondary || prospect.id_number) && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {prospect.phone_secondary && (
                              <div className="flex items-center gap-2">
                                <Phone className="h-4 w-4 text-slate-400 shrink-0" />
                                <span className="text-sm text-muted-foreground">{prospect.phone_secondary} <span className="text-xs">(secundario)</span></span>
                              </div>
                            )}
                            {prospect.id_number && (
                              <div className="flex items-center gap-2">
                                <CreditCard className="h-4 w-4 text-slate-400 shrink-0" />
                                <span className="text-sm">{prospect.id_type}: {prospect.id_number}</span>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Location */}
                        {(prospect.country || prospect.state || prospect.city || prospect.address) && (
                          <>
                            <Separator />
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {prospect.country && (
                                <div className="flex items-center gap-2">
                                  <Globe className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{prospect.country}</span>
                                </div>
                              )}
                              {(prospect.state || prospect.city) && (
                                <div className="flex items-center gap-2">
                                  <MapPin className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{[prospect.city, prospect.state].filter(Boolean).join(', ')}</span>
                                </div>
                              )}
                              {prospect.address && (
                                <div className="flex items-center gap-2 md:col-span-2">
                                  <MapPin className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{prospect.address}</span>
                                </div>
                              )}
                            </div>
                          </>
                        )}

                        {/* Personal data */}
                        {(prospect.birth_date || prospect.marital_status || prospect.nationality || prospect.occupation) && (
                          <>
                            <Separator />
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {prospect.occupation && (
                                <div className="flex items-center gap-2">
                                  <Briefcase className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{prospect.occupation}</span>
                                </div>
                              )}
                              {prospect.nationality && (
                                <div className="flex items-center gap-2">
                                  <Flag className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{prospect.nationality}</span>
                                </div>
                              )}
                              {prospect.birth_date && (
                                <div className="flex items-center gap-2">
                                  <Calendar className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{formatLocalDateTime(prospect.birth_date + 'T12:00', 'full').replace(' a las 12:00', '')}</span>
                                </div>
                              )}
                              {prospect.marital_status && (
                                <div className="flex items-center gap-2">
                                  <Heart className="h-4 w-4 text-slate-400 shrink-0" />
                                  <span className="text-sm">{prospect.marital_status}</span>
                                </div>
                              )}
                            </div>
                          </>
                        )}

                        {/* Notes */}
                        {prospect.notes && (
                          <>
                            <Separator />
                            <div>
                              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
                                <StickyNote className="h-3.5 w-3.5" /> Notas
                              </p>
                              <p className="text-sm whitespace-pre-wrap bg-muted/50 rounded-md px-3 py-2">{prospect.notes}</p>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Stage Selector */}
              {pipeline?.stages?.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <ArrowRightLeft className="h-4 w-4 text-blue-600" />
                      Cambiar Etapa
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-3">
                      <Select value={lead.pipeline_stage} onValueChange={handleStageChange} disabled={changingStage}>
                        <SelectTrigger className="flex-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {pipeline.stages.map(s => (
                            <SelectItem key={s.key} value={s.key}>
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: s.color || '#64748b' }} />
                                {s.label}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {changingStage && <Loader2 className="h-4 w-4 animate-spin text-blue-500 shrink-0" />}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Agent Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <User className="h-5 w-5 text-indigo-600" />
                    Agente Asignado
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-medium">{lead.assigned_agent_name || 'Sin asignar'}</p>
                  {lead.last_activity_at && (
                    <p className="text-sm text-slate-500 mt-2 flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Última actividad: {formatLocalDateTime(lead.last_activity_at)}
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Tabs: Notes & Activities */}
              <Tabs defaultValue="notes" className="w-full">
                <TabsList className="w-full">
                  <TabsTrigger value="notes" className="flex-1">
                    <FileText className="h-4 w-4 mr-2" />
                    Notas
                  </TabsTrigger>
                  <TabsTrigger value="activities" className="flex-1">
                    <History className="h-4 w-4 mr-2" />
                    Actividades ({activities.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="notes" className="mt-4">
                  <Card>
                    <CardContent className="pt-6">
                      {lead.notes ? (
                        <p className="text-sm text-slate-700 whitespace-pre-wrap">{lead.notes}</p>
                      ) : (
                        <p className="text-sm text-slate-400 italic">Sin notas registradas</p>
                      )}
                      
                      {lead.loss_reason && lead.pipeline_stage === 'PERDIDO' && (
                        <>
                          <Separator className="my-4" />
                          <div>
                            <p className="text-sm font-medium text-red-600 mb-2">Razón de pérdida:</p>
                            <p className="text-sm text-slate-700">{lead.loss_reason}</p>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="activities" className="mt-4">
                  {/* Quick Activity Form */}
                  <Card className="mb-4 border-blue-200 dark:border-blue-800">
                    <CardContent className="pt-4 space-y-3">
                      <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Nueva Actividad</p>
                      {/* Type selector */}
                      <div className="grid grid-cols-5 gap-1.5">
                        {ACTIVITY_TYPES.map(t => {
                          const Icon = t.icon;
                          const sel = activityType === t.value;
                          return (
                            <button
                              key={t.value}
                              type="button"
                              onClick={() => setActivityType(t.value)}
                              className={cn(
                                "flex flex-col items-center gap-1 rounded-lg border-2 py-2 text-xs font-medium transition-all",
                                sel ? "border-blue-500 bg-blue-50 dark:bg-blue-950/40 text-blue-700" : "border-slate-200 dark:border-zinc-700 text-slate-500 hover:border-slate-300"
                              )}
                            >
                              <Icon className={cn("h-3.5 w-3.5", sel ? "text-blue-600" : "text-slate-400")} />
                              {t.label}
                            </button>
                          );
                        })}
                      </div>

                      {/* Meeting date/time */}
                      {activityType === 'reunión' && (
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label className="text-xs mb-1 block">Fecha</Label>
                            <Input type="date" value={activityMeetingDate} onChange={e => setActivityMeetingDate(e.target.value)} className="h-9 text-sm" />
                          </div>
                          <div>
                            <Label className="text-xs mb-1 block">Hora</Label>
                            <Input type="time" value={activityMeetingTime} onChange={e => setActivityMeetingTime(e.target.value)} className="h-9 text-sm" />
                          </div>
                        </div>
                      )}

                      <Textarea
                        placeholder="Describe la actividad..."
                        value={activityDesc}
                        onChange={e => setActivityDesc(e.target.value)}
                        rows={2}
                        className="text-sm resize-none"
                      />
                      <Button
                        size="sm"
                        onClick={handleSaveActivity}
                        disabled={!activityType || !activityDesc.trim() || savingActivity}
                        className="w-full gap-2 bg-blue-600 hover:bg-blue-700"
                      >
                        {savingActivity
                          ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          : <Plus className="h-3.5 w-3.5" />
                        }
                        Registrar Actividad
                      </Button>
                    </CardContent>
                  </Card>

                  <div className="space-y-3">
                    {activities.length > 0 ? (
                      activities.map((activity, idx) => {
                        const ActivityIcon = activityIcons[activity.activity_type] || Clock;
                        const isEmail = activity.activity_type === 'email';
                        return (
                          <Card key={activity.id} className="hover:shadow-md transition-shadow">
                            <CardContent className="pt-4">
                              <div className="flex items-start gap-3">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isEmail ? 'bg-brand/10' : 'bg-blue-100'}`}>
                                  <ActivityIcon className={`h-5 w-5 ${isEmail ? 'text-brand' : 'text-blue-600'}`} />
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="flex-1">
                                      <Badge variant="outline" className="mb-2 text-xs">
                                        {activity.activity_type}
                                      </Badge>
                                      <p className="text-sm text-foreground mb-2">{activity.description}</p>
                                      <p className="text-xs text-muted-foreground">
                                        {activity.created_by_name || 'Usuario'} • {formatLocalDateTime(activity.created_date, 'short')}
                                      </p>
                                    </div>
                                    <div className="flex flex-col items-end gap-1.5">
                                      {isEmail && openedEmails[activity.id] && (
                                        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 gap-1 text-xs">
                                          <MailOpen className="h-3 w-3" />
                                          Abierto {openedEmails[activity.id].open_count > 1 ? `(${openedEmails[activity.id].open_count}x)` : ''}
                                        </Badge>
                                      )}
                                      {isEmail && activity.email_html && (
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          className="text-xs gap-1.5 flex-shrink-0"
                                          onClick={() => setEmailPreview(activity)}
                                        >
                                          <Mail className="h-3.5 w-3.5" />
                                          Ver email
                                        </Button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })
                    ) : (
                      <Card>
                        <CardContent className="py-8 text-center">
                          <History className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                          <p className="text-sm text-slate-400">No hay actividades registradas</p>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </TabsContent>
              </Tabs>

              {/* Email Preview Modal */}
              <EmailPreviewModal
                open={!!emailPreview}
                onClose={() => setEmailPreview(null)}
                activity={emailPreview}
              />

              {/* Appointment Proposal */}
              {isEnabled('citas') && <AppointmentProposalForm
                open={showProposalForm}
                onClose={() => setShowProposalForm(false)}
                lead={lead}
                prospect={prospect}
                currentUser={currentUser}
              />}

              {/* Email Composer */}
              <EmailComposer
                open={showEmailComposer}
                onClose={() => setShowEmailComposer(false)}
                lead={lead}
                prospect={prospect}
                onEmailSent={loadData}
              />

              {/* InsurDesk Link */}
              {lead.gportal_link && (
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="pt-4">
                    <a 
                      href={lead.gportal_link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
                    >
                      <TrendingUp className="h-4 w-4" />
                      Ver en InsurDesk
                    </a>
                  </CardContent>
                </Card>
              )}
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full">
            <p className="text-slate-400">Lead no encontrado</p>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}