import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Mail } from "lucide-react";

export default function EmailPreviewModal({ open, onClose, activity }) {
  if (!activity) return null;

  // Parse subject and html_body from activity description metadata
  const htmlBody = activity.email_html;
  const subject = activity.email_subject || '';
  const to = activity.email_to || '';

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-brand" />
            Vista previa del email
          </DialogTitle>
        </DialogHeader>

        {/* Email metadata */}
        <div className="bg-slate-50 rounded-lg p-3 text-sm space-y-1 border border-slate-200 flex-shrink-0">
          {to && (
            <div className="flex gap-2">
              <span className="text-slate-400 w-16 flex-shrink-0">Para:</span>
              <span className="text-slate-700 font-medium">{to}</span>
            </div>
          )}
          {subject && (
            <div className="flex gap-2">
              <span className="text-slate-400 w-16 flex-shrink-0">Asunto:</span>
              <span className="text-slate-700 font-medium">{subject}</span>
            </div>
          )}
        </div>

        {/* Email HTML preview */}
        <div className="flex-1 overflow-y-auto rounded-lg border border-slate-200 min-h-0">
          {htmlBody ? (
            <iframe
              srcDoc={htmlBody}
              title="Vista previa del email"
              className="w-full h-full min-h-[400px] border-0 rounded-lg"
              sandbox="allow-same-origin"
            />
          ) : (
            <div className="p-6 text-sm text-slate-500 whitespace-pre-wrap">
              {activity.description}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}