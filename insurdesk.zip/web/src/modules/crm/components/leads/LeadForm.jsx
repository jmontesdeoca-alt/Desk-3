import React, { useState, useEffect } from 'react';

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Loader2, Target, DollarSign, Building2, Package, UserCheck, ChevronsUpDown, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { api } from '@/api/client';
import TagSelector from '@/modules/crm/components/tags/TagSelector';
import { useBranches } from '@/lib/useBranches';

const CURRENCIES = ["USD", "EUR", "MXN", "COP", "PEN", "CLP"];

export default function LeadForm({ open, onClose, lead, prospectId, onSaved }) {
  const { branches } = useBranches();
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [prospects, setProspects] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [agents, setAgents] = useState([]);
  const [formData, setFormData] = useState({
    prospect_id: '',
    pipeline_id: '',
    branch: '',
    company_name: '',
    product_name: '',
    premium_estimated: '',
    currency: 'USD',
    pipeline_stage: '',
    notes: '',
    tags: []
  });
  const [errors, setErrors] = useState({});
  const [prospectOpen, setProspectOpen] = useState(false);
  const [prospectSearch, setProspectSearch] = useState('');

  // Single effect: runs when form opens, loads fresh data then sets formData atomically
  useEffect(() => {
    if (!open) return;
    setErrors({});

    // If editing, set formData immediately (synchronously) so the form shows data right away
    if (lead) {
      setFormData({
        prospect_id: lead.prospect_id || '',
        pipeline_id: lead.pipeline_id || '',
        branch: lead.branch || '',
        company_name: lead.company_name || '',
        product_name: lead.product_name || '',
        premium_estimated: lead.premium_estimated?.toString() || '',
        currency: lead.currency || 'USD',
        pipeline_stage: lead.pipeline_stage || '',
        notes: lead.notes || '',
        tags: lead.tags || [],
        assigned_agent_id: lead.assigned_agent_id || '',
        assigned_agent_name: lead.assigned_agent_name || ''
      });
    }

    // Always fetch dropdowns (prospects, pipelines, agents, user)
    Promise.all([
      api.functions.invoke('listPipelines').then(r => r.data?.pipelines || []).catch(() => []),
      api.auth.me(),
      api.functions.invoke('listAgents', {}).then(r => r.data?.agents || []).catch(() => [])
    ]).then(async ([pipelinesData, user, usersData]) => {
      const canSeeAll = user.crm_role === 'admin_crm' || user.crm_role === 'jefatura_crm' || user.role === 'admin';
      const prospectsData = canSeeAll
        ? await api.entities.Prospect.list('full_name')
        : await api.entities.Prospect.filter({ assigned_agent_id: user.id }, 'full_name');
      setCurrentUser(user);
      setProspects(prospectsData);
      setPipelines(pipelinesData);
      setAgents(usersData);

      if (lead) return; // formData already set above

      // New lead: use defaults
      const storedId = localStorage.getItem('pipeline_selected_id');
      const defaultPipeline = pipelinesData.find(p => p.id === storedId) || pipelinesData[0];

      setFormData({
        prospect_id: prospectId || '',
        pipeline_id: defaultPipeline?.id || '',
        pipeline_stage: defaultPipeline?.stages?.[0]?.key || '',
        branch: '',
        company_name: '',
        product_name: '',
        premium_estimated: '',
        currency: 'USD',
        notes: '',
        tags: prospectId ? (prospectsData.find(p => p.id === prospectId)?.tags || []) : []
      });
    }).catch(console.error);
  }, [open, lead, prospectId]);

  // When pipeline changes, set default stage to first stage of that pipeline
  const handlePipelineChange = (pipelineId) => {
    const pipeline = pipelines.find(p => p.id === pipelineId);
    const firstStage = pipeline?.stages?.[0]?.key || '';
    setFormData(prev => ({ ...prev, pipeline_id: pipelineId, pipeline_stage: firstStage }));
  };

  const loadInitialData = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.prospect_id) {
      newErrors.prospect_id = 'Debe seleccionar un prospecto';
    }

    if (!formData.pipeline_id) {
      newErrors.pipeline_id = 'Debe seleccionar un pipeline';
    }
    
    if (!formData.branch) {
      newErrors.branch = 'El ramo es obligatorio';
    }
    
    if (!formData.premium_estimated || parseFloat(formData.premium_estimated) <= 0) {
      newErrors.premium_estimated = 'La prima estimada es obligatoria';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setLoading(true);
    try {
      const selectedProspect = prospects.find(p => p.id === formData.prospect_id);
      const selectedPipeline = pipelines.find(p => p.id === formData.pipeline_id);
      const now = new Date().toISOString();
      
      const data = {
        ...formData,
        prospect_name: selectedProspect?.full_name || '',
        pipeline_name: selectedPipeline?.name || '',
        premium_estimated: parseFloat(formData.premium_estimated) || 0,
        assigned_agent_id: formData.assigned_agent_id || lead?.assigned_agent_id || currentUser?.id,
        assigned_agent_name: formData.assigned_agent_name || lead?.assigned_agent_name || currentUser?.full_name,
        last_activity_at: now
      };

      if (lead) {
        await api.entities.Lead.update(lead.id, data);
        // Notify if agent was reassigned
        const agentChanged = data.assigned_agent_id && data.assigned_agent_id !== lead.assigned_agent_id;
        if (agentChanged) {
          const agentUser = agents?.find(a => a.id === data.assigned_agent_id);
          api.functions.invoke('notifyLeadAssigned', {
            lead_id: lead.id,
            assigned_agent_id: data.assigned_agent_id,
            assigned_agent_name: data.assigned_agent_name,
            assigned_agent_email: agentUser?.email || '',
            prospect_name: data.prospect_name,
            pipeline_name: data.pipeline_name,
            branch: data.branch,
            assigned_by_name: currentUser?.full_name || ''
          }).catch(e => console.error('Notification error:', e));
        }
      } else {
        // Generate external_id for new leads
        const timestamp = Date.now();
        data.external_id = `CRM-LEAD-${timestamp}`;
        data.lead_status = 'ACTIVO';
        data.handoff_status = null;
        data.handoff_attempts = 0;
        const newLead = await api.entities.Lead.create(data);
        // Notify assigned agent (if different from current user)
        if (data.assigned_agent_id && data.assigned_agent_id !== currentUser?.id) {
          const agentUser = agents?.find(a => a.id === data.assigned_agent_id);
          api.functions.invoke('notifyLeadAssigned', {
            lead_id: newLead.id,
            assigned_agent_id: data.assigned_agent_id,
            assigned_agent_name: data.assigned_agent_name,
            assigned_agent_email: agentUser?.email || '',
            prospect_name: data.prospect_name,
            pipeline_name: data.pipeline_name,
            branch: data.branch,
            assigned_by_name: currentUser?.full_name || ''
          }).catch(e => console.error('Notification error:', e));
        }
      }
      
      onSaved?.();
      onClose();
    } catch (error) {
      console.error('Error saving lead:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-lg max-h-[95dvh] overflow-y-auto p-0 gap-0 rounded-t-2xl sm:rounded-2xl">
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-slate-100 dark:border-zinc-700 sticky top-0 bg-white dark:bg-zinc-900 z-10">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Target className="h-5 w-5 text-blue-600" />
            {lead ? 'Editar Lead' : 'Nuevo Lead'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="px-5 py-4 space-y-5">
          <div>
            <Label className="text-sm font-medium mb-1.5 block">Prospecto *</Label>
            <Popover open={prospectOpen} onOpenChange={setProspectOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={prospectOpen}
                  className={cn(
                    "w-full h-12 justify-between text-base font-normal",
                    errors.prospect_id && "border-red-500",
                    !formData.prospect_id && "text-muted-foreground"
                  )}
                >
                  {formData.prospect_id
                    ? (() => {
                        const p = prospects.find(p => p.id === formData.prospect_id);
                        return p ? `${p.full_name} — ${p.email}` : 'Seleccionar prospecto';
                      })()
                    : 'Seleccionar prospecto'}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" style={{ width: 'var(--radix-popover-trigger-width)' }}>
                <div className="flex flex-col">
                  <div className="p-2 border-b">
                    <Input
                      placeholder="Buscar prospecto..."
                      value={prospectSearch}
                      onChange={e => setProspectSearch(e.target.value)}
                      className="h-9"
                      autoFocus
                    />
                  </div>
                  <div className="max-h-72 overflow-y-auto overscroll-contain" onWheel={e => e.stopPropagation()}>
                    {(() => {
                      const normalize = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
                      const filtered = prospectSearch.trim()
                        ? prospects.filter(p =>
                            normalize(p.full_name).includes(normalize(prospectSearch)) ||
                            normalize(p.email).includes(normalize(prospectSearch))
                          )
                        : prospects;
                      if (filtered.length === 0) {
                        return <p className="text-sm text-muted-foreground text-center py-6">No se encontraron prospectos.</p>;
                      }
                      return filtered.map(prospect => (
                        <button
                          key={prospect.id}
                          type="button"
                          className={cn(
                            "w-full flex items-center gap-2 px-3 py-2.5 text-left hover:bg-accent transition-colors",
                            formData.prospect_id === prospect.id && "bg-accent"
                          )}
                          onClick={() => {
                            setFormData(prev => ({ ...prev, prospect_id: prospect.id }));
                            setProspectOpen(false);
                            setProspectSearch('');
                          }}
                        >
                          <Check className={cn("h-4 w-4 shrink-0", formData.prospect_id === prospect.id ? "opacity-100 text-blue-600" : "opacity-0")} />
                          <div>
                            <p className="text-sm font-medium">{prospect.full_name}</p>
                            <p className="text-xs text-muted-foreground">{prospect.email}</p>
                          </div>
                        </button>
                      ));
                    })()}
                  </div>
                </div>
              </PopoverContent>
            </Popover>
            {errors.prospect_id && (
              <p className="text-xs text-red-500 mt-1">{errors.prospect_id}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="pipeline_id" className="text-sm font-medium mb-1.5 block">Pipeline *</Label>
              <Select
                value={formData.pipeline_id}
                onValueChange={handlePipelineChange}
              >
                <SelectTrigger className={`h-12 text-base ${errors.pipeline_id ? 'border-red-500' : ''}`}>
                  <SelectValue placeholder="Pipeline" />
                </SelectTrigger>
                <SelectContent>
                  {pipelines.map(p => (
                    <SelectItem key={p.id} value={p.id} className="text-base py-3">{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.pipeline_id && (
                <p className="text-xs text-red-500 mt-1">{errors.pipeline_id}</p>
              )}
            </div>

            <div>
              <Label htmlFor="branch" className="text-sm font-medium mb-1.5 block">Ramo *</Label>
              <Select
                value={formData.branch}
                onValueChange={(value) => setFormData(prev => ({ ...prev, branch: value }))}
              >
                <SelectTrigger className={`h-12 text-base ${errors.branch ? 'border-red-500' : ''}`}>
                  <SelectValue placeholder="Ramo" />
                </SelectTrigger>
                <SelectContent>
                  {branches.map(branch => (
                    <SelectItem key={branch} value={branch} className="text-base py-3">{branch}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.branch && (
                <p className="text-xs text-red-500 mt-1">{errors.branch}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="company_name" className="text-sm font-medium mb-1.5 block">Compañía</Label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <Input
                  id="company_name"
                  value={formData.company_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, company_name: e.target.value }))}
                  placeholder="Aseguradora"
                  className="h-12 pl-10 text-base"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="product_name" className="text-sm font-medium mb-1.5 block">Producto</Label>
              <div className="relative">
                <Package className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <Input
                  id="product_name"
                  value={formData.product_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, product_name: e.target.value }))}
                  placeholder="Nombre"
                  className="h-12 pl-10 text-base"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <Label htmlFor="premium_estimated" className="text-sm font-medium mb-1.5 block">Prima Estimada *</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <Input
                  id="premium_estimated"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.premium_estimated}
                  onChange={(e) => setFormData(prev => ({ ...prev, premium_estimated: e.target.value }))}
                  placeholder="0.00"
                  className={`h-12 pl-10 text-base ${errors.premium_estimated ? 'border-red-500' : ''}`}
                  inputMode="decimal"
                />
              </div>
              {errors.premium_estimated && (
                <p className="text-xs text-red-500 mt-1">{errors.premium_estimated}</p>
              )}
            </div>
            <div>
              <Label htmlFor="currency" className="text-sm font-medium mb-1.5 block">Moneda</Label>
              <Select
                value={formData.currency}
                onValueChange={(value) => setFormData(prev => ({ ...prev, currency: value }))}
              >
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map(currency => (
                    <SelectItem key={currency} value={currency} className="text-base py-3">{currency}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {formData.pipeline_id && (
            <div>
              <Label htmlFor="pipeline_stage" className="text-sm font-medium mb-1.5 block">Etapa</Label>
              <Select
                value={formData.pipeline_stage}
                onValueChange={(value) => setFormData(prev => ({ ...prev, pipeline_stage: value }))}
              >
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder="Seleccionar etapa" />
                </SelectTrigger>
                <SelectContent>
                  {(pipelines.find(p => p.id === formData.pipeline_id)?.stages || []).map(stage => (
                    <SelectItem key={stage.key} value={stage.key} className="text-base py-3">{stage.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {agents.length > 0 && (
            <div>
              <Label htmlFor="assigned_agent" className="text-sm font-medium mb-1.5 block">Agente Asignado</Label>
              <Select
                value={formData.assigned_agent_id || lead?.assigned_agent_id || currentUser?.id || ''}
                onValueChange={(value) => {
                  const agent = agents.find(a => a.id === value);
                  setFormData(prev => ({
                    ...prev,
                    assigned_agent_id: value,
                    assigned_agent_name: agent?.full_name || ''
                  }));
                }}
              >
                <SelectTrigger className="h-12 text-base">
                  <UserCheck className="h-4 w-4 mr-2 text-slate-400" />
                  <SelectValue placeholder="Seleccionar agente" />
                </SelectTrigger>
                <SelectContent>
                  {agents.map(agent => (
                    <SelectItem key={agent.id} value={agent.id} className="text-base py-3">{agent.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label className="text-sm font-medium mb-1.5 block">Etiquetas</Label>
            <TagSelector
              value={formData.tags}
              onChange={(tags) => setFormData(prev => ({ ...prev, tags }))}
            />
          </div>

          <div>
            <Label htmlFor="notes" className="text-sm font-medium mb-1.5 block">Notas</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Observaciones, detalles importantes..."
              rows={3}
              className="text-base resize-none"
            />
          </div>

          <div className="flex gap-3 pt-2 pb-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 h-12 text-base">
              Cancelar
            </Button>
            <Button type="submit" disabled={loading} className="flex-1 h-12 text-base font-semibold">
              {loading && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              {lead ? 'Actualizar' : 'Crear Lead'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}