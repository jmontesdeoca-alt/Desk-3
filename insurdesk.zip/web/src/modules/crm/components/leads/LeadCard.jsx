import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  User, DollarSign, Building2, Clock, 
  MoreVertical, Edit, Trash2, MessageSquare,
  ThermometerSun, ThermometerSnowflake, Archive, Eye, Bell, Copy
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDistanceToNow, differenceInDays } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from "@/lib/utils";
import CloneLeadDialog from './CloneLeadDialog';

const branchColors = {
  'Vida': 'bg-purple-100 text-purple-700',
  'Salud': 'bg-rose-100 text-rose-700',
  'Viaje': 'bg-sky-100 text-sky-700',
  'Inversiones': 'bg-emerald-100 text-emerald-700',
  'General': 'bg-slate-100 text-slate-700'
};

export default function LeadCard({ lead, onEdit, onDelete, onAddActivity, onArchive, onView, onAddReminder, onCloned, isDragging }) {
  const [showCloneDialog, setShowCloneDialog] = useState(false);
  const lastActivityDate = lead.last_activity_at ? new Date(lead.last_activity_at) : null;
  const daysSinceActivity = lastActivityDate ? differenceInDays(new Date(), lastActivityDate) : null;
  
  const isHot = daysSinceActivity !== null && daysSinceActivity <= 7 && 
    ['CONTACTADO', 'COTIZADO', 'NEGOCIANDO'].includes(lead.pipeline_stage);
  const isCold = daysSinceActivity !== null && daysSinceActivity > 14;

  const formatCurrency = (amount, currency = 'USD') => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <>
    <Card className={cn(
      "p-3 bg-white dark:bg-zinc-800 hover:shadow-md transition-all cursor-grab active:cursor-grabbing select-none",
      isDragging && "shadow-lg ring-2 ring-blue-500",
      isHot && "border-l-4 border-l-orange-500",
      isCold && "border-l-4 border-l-blue-300"
    )}>
      <div className="flex items-start justify-between mb-2.5">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <User className="h-4 w-4 text-slate-400 shrink-0" />
          <span className="font-medium text-slate-900 dark:text-white text-sm truncate">
            {lead.prospect_name || 'Sin nombre'}
          </span>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-9 w-9 p-0 shrink-0 touch-manipulation">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuItem onClick={() => onView?.(lead)} className="py-3 text-base gap-3">
              <Eye className="h-4 w-4" />
              Ver Detalles
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onEdit?.(lead)} className="py-3 text-base gap-3">
              <Edit className="h-4 w-4" />
              Editar
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAddActivity?.(lead)} className="py-3 text-base gap-3">
              <MessageSquare className="h-4 w-4" />
              Agregar Actividad
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAddReminder?.(lead)} className="py-3 text-base gap-3">
              <Bell className="h-4 w-4" />
              Crear Recordatorio
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setShowCloneDialog(true)} className="py-3 text-base gap-3">
              <Copy className="h-4 w-4 text-blue-400" />
              <span className="text-blue-400">Clonar Lead</span>
            </DropdownMenuItem>
            {['GANADO', 'PERDIDO'].includes(lead.pipeline_stage) && (
              <DropdownMenuItem onClick={() => onArchive?.(lead)} className="py-3 text-base gap-3">
                <Archive className="h-4 w-4" />
                {lead.lead_status === 'ARCHIVADO' ? 'Desarchivar' : 'Archivar'}
              </DropdownMenuItem>
            )}
            <DropdownMenuItem 
              onClick={() => onDelete?.(lead)}
              className="py-3 text-base gap-3 text-red-600"
            >
              <Trash2 className="h-4 w-4" />
              Eliminar
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          <Badge className={cn("text-xs", branchColors[lead.branch] || branchColors['General'])}>
            {lead.branch}
          </Badge>
          {Array.isArray(lead.tags) && lead.tags.map(tag => (
            <span
              key={tag.id || tag}
              className="tag-chip inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium"
              style={{ '--tag': tag.color || '#64748b' }}
            >
              {tag.name || tag}
            </span>
          ))}
          {isHot && (
            <ThermometerSun className="h-4 w-4 text-orange-500" title="Lead caliente" />
          )}
          {isCold && (
            <ThermometerSnowflake className="h-4 w-4 text-blue-400" title="Lead frío" />
          )}
        </div>

        {lead.company_name && (
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-zinc-400">
            <Building2 className="h-3.5 w-3.5" />
            <span className="truncate">{lead.company_name}</span>
          </div>
        )}

        <div className="flex items-center gap-1.5">
          <DollarSign className="h-4 w-4 text-emerald-600" />
          <span className="font-semibold text-emerald-700">
            {formatCurrency(lead.premium_estimated, lead.currency)}
          </span>
        </div>

        {lastActivityDate && (
          <div className="flex items-center gap-1.5 text-xs text-slate-400 dark:text-zinc-500">
            <Clock className="h-3.5 w-3.5" />
            <span>
              {formatDistanceToNow(lastActivityDate, { addSuffix: true, locale: es })}
            </span>
          </div>
        )}
      </div>

      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-zinc-700">
        <p className="text-xs text-slate-500 dark:text-zinc-400 truncate">
          {lead.assigned_agent_name || 'Sin asignar'}
        </p>
      </div>
    </Card>

    <CloneLeadDialog
      open={showCloneDialog}
      onClose={() => setShowCloneDialog(false)}
      lead={lead}
      onCloned={onCloned}
    />
    </>
  );
}