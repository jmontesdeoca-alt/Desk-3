import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Phone, MessageCircle, Calendar, FileText, MoreHorizontal, AlertTriangle } from "lucide-react";
import { api } from '@/api/client';
import { format, addHours } from 'date-fns';
import { localDateAndTimeToISO, localDateForInput } from '@/lib/dateUtils';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const ACTIVITY_TYPES = [
  { value: 'llamada', label: 'Llamada', icon: Phone },
  { value: 'whatsapp', label: 'WhatsApp', icon: MessageCircle },
  { value: 'reunión', label: 'Reunión', icon: Calendar },
  { value: 'nota', label: 'Nota', icon: FileText },
  { value: 'otro', label: 'Otro', icon: MoreHorizontal }
];

export default function ActivityForm({ open, onClose, lead, onSaved }) {
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [formData, setFormData] = useState({
    activity_type: '',
    description: '',
    meeting_date: '',
    meeting_time: '',
    meeting_duration: '1'
  });
  const [errors, setErrors] = useState({});
  const [conflictDialog, setConflictDialog] = useState({ open: false, conflicts: [] });

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (open) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(9, 0, 0, 0);
      
      setFormData({
        activity_type: '',
        description: '',
        meeting_date: localDateForInput(tomorrow),
        meeting_time: '09:00',
        meeting_duration: '1'
      });
      setErrors({});
    }
  }, [open]);

  const loadUser = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.activity_type) {
      newErrors.activity_type = 'Seleccione un tipo de actividad';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'La descripción es obligatoria';
    }

    if (formData.activity_type === 'reunión') {
      if (!formData.meeting_date) {
        newErrors.meeting_date = 'La fecha es obligatoria para reuniones';
      }
      if (!formData.meeting_time) {
        newErrors.meeting_time = 'La hora es obligatoria para reuniones';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const checkAvailability = async () => {
    if (!formData.meeting_date || !formData.meeting_time || !currentUser) return [];

    const startDateTime = new Date(localDateAndTimeToISO(formData.meeting_date, formData.meeting_time));
    const endDateTime = addHours(startDateTime, parseFloat(formData.meeting_duration || '1'));

    try {
      const events = await api.entities.CalendarEvent.filter({
        assigned_to_id: currentUser.id,
        status: 'programado'
      });

      const conflicts = events.filter(event => {
        const eventStart = new Date(event.start_datetime);
        const eventEnd = new Date(event.end_datetime);
        
        return (
          (startDateTime >= eventStart && startDateTime < eventEnd) ||
          (endDateTime > eventStart && endDateTime <= eventEnd) ||
          (startDateTime <= eventStart && endDateTime >= eventEnd)
        );
      });

      return conflicts;
    } catch (error) {
      console.error('Error checking availability:', error);
      return [];
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm() || !lead) return;

    // Check availability for meetings
    if (formData.activity_type === 'reunión' && formData.meeting_date && formData.meeting_time) {
      const conflicts = await checkAvailability();
      if (conflicts.length > 0) {
        setConflictDialog({ open: true, conflicts });
        return;
      }
    }

    await saveActivity();
  };

  const saveActivity = async (forceCreate = false) => {
    setLoading(true);
    try {
      const now = new Date().toISOString();

      // Create the activity
      await api.entities.LeadActivity.create({
        lead_id: lead.id,
        lead_external_id: lead.external_id,
        activity_type: formData.activity_type,
        description: formData.description,
        created_by_name: currentUser?.full_name || ''
      });

      // Update lead's last_activity_at
      await api.entities.Lead.update(lead.id, {
        last_activity_at: now
      });

      // If it's a meeting, create calendar event
      if (formData.activity_type === 'reunión' && formData.meeting_date && formData.meeting_time) {
        try {
          const startDateTime = new Date(localDateAndTimeToISO(formData.meeting_date, formData.meeting_time));
          const endDateTime = addHours(startDateTime, parseFloat(formData.meeting_duration || '1'));

          const eventData = {
            title: `Reunión: ${lead.prospect_name}`,
            description: formData.description,
            event_type: 'reunión',
            start_datetime: startDateTime.toISOString(),
            end_datetime: endDateTime.toISOString(),
            lead_id: lead.id,
            lead_name: lead.prospect_name,
            prospect_id: lead.prospect_id,
            assigned_to_id: currentUser?.id,
            assigned_to_name: currentUser?.full_name
          };

          await api.functions.invoke('createUserGoogleCalendarEvent', { eventData });
          toast.success('Reunión agendada correctamente');
        } catch (calError) {
          console.error('Error creating calendar event:', calError);
          toast.error('Error al crear el evento en calendario');
        }
      } else {
        toast.success('Actividad registrada correctamente');
      }
      
      setConflictDialog({ open: false, conflicts: [] });
      onSaved?.();
      onClose();
    } catch (error) {
      console.error('Error saving activity:', error);
      toast.error('Error al guardar la actividad');
    } finally {
      setLoading(false);
    }
  };

  const selectedType = ACTIVITY_TYPES.find(t => t.value === formData.activity_type);

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="w-[calc(100vw-2rem)] max-w-md rounded-xl p-0 overflow-hidden">
          <DialogHeader className="px-5 pt-5 pb-0">
            <DialogTitle className="flex items-center gap-2 text-base">
              {selectedType?.icon && <selectedType.icon className="h-4 w-4 text-blue-600 shrink-0" />}
              Nueva Actividad
            </DialogTitle>
          </DialogHeader>

          <div className="px-5 pt-3 pb-5 space-y-4 overflow-y-auto max-h-[80vh]">
            {lead && (
              <div className="bg-slate-50 rounded-lg px-3 py-2">
                <p className="text-sm font-medium text-slate-700 truncate">{lead.prospect_name}</p>
                <p className="text-xs text-slate-400">{lead.external_id}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Tipo de actividad - botones visuales */}
              <div>
                <Label className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 block">
                  Tipo de Actividad *
                </Label>
                <div className="grid grid-cols-3 gap-2">
                  {ACTIVITY_TYPES.map(type => {
                    const Icon = type.icon;
                    const isSelected = formData.activity_type === type.value;
                    return (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, activity_type: type.value }))}
                        className={`flex flex-col items-center gap-1.5 rounded-lg border-2 px-2 py-2.5 transition-all text-xs font-medium
                          ${isSelected
                            ? 'border-blue-500 bg-blue-50 text-blue-700'
                            : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                          }`}
                      >
                        <Icon className={`h-4 w-4 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                        {type.label}
                      </button>
                    );
                  })}
                </div>
                {errors.activity_type && (
                  <p className="text-xs text-red-500 mt-1">{errors.activity_type}</p>
                )}
              </div>

              {formData.activity_type === 'reunión' && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="meeting_date" className="text-xs font-medium text-slate-600 mb-1 block">Fecha *</Label>
                      <Input
                        id="meeting_date"
                        type="date"
                        value={formData.meeting_date}
                        onChange={(e) => setFormData(prev => ({ ...prev, meeting_date: e.target.value }))}
                        className={`h-10 text-sm ${errors.meeting_date ? 'border-red-500' : ''}`}
                      />
                      {errors.meeting_date && (
                        <p className="text-xs text-red-500 mt-1">{errors.meeting_date}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="meeting_time" className="text-xs font-medium text-slate-600 mb-1 block">Hora *</Label>
                      <Input
                        id="meeting_time"
                        type="time"
                        value={formData.meeting_time}
                        onChange={(e) => setFormData(prev => ({ ...prev, meeting_time: e.target.value }))}
                        className={`h-10 text-sm ${errors.meeting_time ? 'border-red-500' : ''}`}
                      />
                      {errors.meeting_time && (
                        <p className="text-xs text-red-500 mt-1">{errors.meeting_time}</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs font-medium text-slate-600 mb-1 block">Duración</Label>
                    <Select
                      value={formData.meeting_duration}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, meeting_duration: value }))}
                    >
                      <SelectTrigger className="h-10 text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0.5">30 minutos</SelectItem>
                        <SelectItem value="1">1 hora</SelectItem>
                        <SelectItem value="1.5">1.5 horas</SelectItem>
                        <SelectItem value="2">2 horas</SelectItem>
                        <SelectItem value="3">3 horas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              <div>
                <Label htmlFor="description" className="text-xs font-medium text-slate-600 mb-1 block">
                  {formData.activity_type === 'reunión' ? 'Agenda / Tema *' : 'Descripción *'}
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder={formData.activity_type === 'reunión' ? 'Tema o agenda de la reunión...' : 'Detalle de la actividad realizada...'}
                  rows={3}
                  className={`text-sm resize-none ${errors.description ? 'border-red-500' : ''}`}
                />
                {errors.description && (
                  <p className="text-xs text-red-500 mt-1">{errors.description}</p>
                )}
              </div>

              <div className="flex gap-2 pt-1">
                <Button type="button" variant="outline" onClick={onClose} className="flex-1 h-10">
                  Cancelar
                </Button>
                <Button type="submit" disabled={loading} className="flex-1 h-10">
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Registrar
                </Button>
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>

    <AlertDialog open={conflictDialog.open} onOpenChange={(open) => !open && setConflictDialog({ open: false, conflicts: [] })}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            Conflicto de Horario
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-3">
            <p>Ya tienes {conflictDialog.conflicts.length} evento(s) programado(s) en este horario:</p>
            <div className="bg-amber-50 rounded-lg p-3 space-y-2">
              {conflictDialog.conflicts.map((event, idx) => (
                <div key={idx} className="text-sm">
                  <p className="font-medium text-amber-900">{event.title}</p>
                  <p className="text-amber-700">
                    {format(new Date(event.start_datetime), 'HH:mm')} - {format(new Date(event.end_datetime), 'HH:mm')}
                  </p>
                </div>
              ))}
            </div>
            <p className="text-sm">¿Deseas agendar esta reunión de todas formas?</p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => setConflictDialog({ open: false, conflicts: [] })}>
            Cancelar
          </AlertDialogCancel>
          <AlertDialogAction onClick={() => saveActivity(true)}>
            Agendar de todas formas
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}