import React, { useState, useMemo } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { cn } from "@/lib/utils";
import LeadCard from './LeadCard';
import { api } from '@/api/client';

export default function PipelineKanban({ leads, pipeline, onLeadEdit, onLeadDelete, onAddActivity, onAddReminder, onStageChange, onArchive, onView, onCloned, userId }) {
  // Use pipeline stages if provided, otherwise fallback to defaults
  const STAGES = pipeline?.stages?.length > 0
    ? pipeline.stages.map(s => ({ id: s.key, label: s.label, color: s.color }))
    : [
        { id: 'NUEVO', label: 'Nuevo', color: '#64748b' },
        { id: 'CONTACTADO', label: 'Contactado', color: '#2F4F9D' },
        { id: 'COTIZADO', label: 'Cotizado', color: '#f59e0b' },
        { id: 'NEGOCIANDO', label: 'Negociando', color: '#8b5cf6' },
        { id: 'GANADO', label: 'Ganado', color: '#10b981' },
        { id: 'PERDIDO', label: 'Perdido', color: '#ef4444' }
      ];
  const [draggingId, setDraggingId] = useState(null);

  // Con miles de leads, dibujar todas las tarjetas congela el navegador:
  // se agrupa una sola vez y cada columna dibuja por tandas (los totales siguen siendo de TODOS los leads).
  const PAGE_SIZE = 25;
  const [visible, setVisible] = useState({});

  const grouped = useMemo(() => {
    const map = {};
    for (const lead of leads) (map[lead.pipeline_stage] ||= []).push(lead);
    return map;
  }, [leads]);

  const getLeadsByStage = (stage) => grouped[stage] || [];

  const getTotalByStage = (stage) => {
    return getLeadsByStage(stage).reduce((sum, lead) => sum + (lead.premium_estimated || 0), 0);
  };

  const shownCount = (stage) => visible[stage] || PAGE_SIZE;
  const showMore = (stage) => setVisible(v => ({ ...v, [stage]: shownCount(stage) + PAGE_SIZE }));

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handleDragStart = (result) => {
    setDraggingId(result.draggableId);
  };

  const handleDragEnd = async (result) => {
    setDraggingId(null);
    
    if (!result.destination) return;
    
    const { draggableId, destination } = result;
    const newStage = destination.droppableId;
    
    const lead = leads.find(l => l.id === draggableId);
    if (!lead || lead.pipeline_stage === newStage) return;

    // Update in database
    try {
      const now = new Date().toISOString();
      await api.entities.Lead.update(draggableId, {
        pipeline_stage: newStage,
        last_activity_at: now
      });
      onStageChange?.(draggableId, newStage);

    } catch (error) {
      console.error('Error updating lead stage:', error);
    }
  };

  return (
    <DragDropContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div className="flex gap-4 overflow-x-auto pb-4" style={{ height: 'calc(100vh - 260px)' }}>
        {STAGES.map(stage => (
          <div key={stage.id} className="flex-shrink-0 w-72 flex flex-col h-full">
            {/* Encabezado fijo: el color de la etapa es solo un punto; el resto es neutro */}
            <div className="flex-shrink-0 rounded-t-lg px-3 py-2.5 flex items-center justify-between bg-muted/70 border border-b-0 border-border">
              <div className="flex items-center gap-2 min-w-0">
                <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: stage.color }} />
                <span className="text-sm font-medium text-foreground truncate">{stage.label}</span>
                <span className="text-xs text-muted-foreground tabular">{getLeadsByStage(stage.id).length}</span>
              </div>
              <span className="text-xs text-muted-foreground tabular">
                {formatCurrency(getTotalByStage(stage.id))}
              </span>
            </div>

            <Droppable droppableId={stage.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={cn(
                    "bg-muted/40 border border-t-0 border-border rounded-b-lg p-2.5 space-y-2.5 transition-colors overflow-y-auto flex-1",
                    snapshot.isDraggingOver && "bg-brand-soft ring-1 ring-brand/40 ring-inset"
                  )}
                >
                  {getLeadsByStage(stage.id).slice(0, shownCount(stage.id)).map((lead, index) => (
                    <Draggable key={lead.id} draggableId={lead.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                        >
                          <LeadCard
                            lead={lead}
                            isDragging={snapshot.isDragging}
                            onEdit={onLeadEdit}
                            onDelete={onLeadDelete}
                            onAddActivity={onAddActivity}
                            onAddReminder={onAddReminder}
                            onArchive={onArchive}
                            onView={onView}
                            onCloned={onCloned}
                          />
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}

                  {getLeadsByStage(stage.id).length > shownCount(stage.id) && (
                    <button
                      type="button"
                      onClick={() => showMore(stage.id)}
                      className="w-full rounded-md border border-dashed border-border py-2 text-xs text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                    >
                      Mostrar {Math.min(PAGE_SIZE, getLeadsByStage(stage.id).length - shownCount(stage.id))} más · quedan {getLeadsByStage(stage.id).length - shownCount(stage.id)}
                    </button>
                  )}

                  {getLeadsByStage(stage.id).length === 0 && (
                    <div className="text-center py-8 text-slate-400 dark:text-zinc-500 text-sm">
                      Arrastra leads aquí
                    </div>
                  )}
                </div>
              )}
            </Droppable>
          </div>
        ))}
      </div>
    </DragDropContext>
  );
}