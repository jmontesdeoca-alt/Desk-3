import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction
} from "@/components/ui/alert-dialog";
import { Loader2, RotateCcw, CheckCircle2, AlertTriangle, XCircle, FileSpreadsheet, RefreshCw, Users, Trash2, AlertCircle } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { toast } from 'sonner';

const STATUS_CONFIG = {
  success: { label: 'Exitosa', icon: CheckCircle2, className: 'bg-emerald-100 text-emerald-700' },
  partial: { label: 'Parcial', icon: AlertTriangle, className: 'bg-amber-100 text-amber-700' },
  failed: { label: 'Fallida', icon: XCircle, className: 'bg-red-100 text-red-700' },
};

export default function ImportHistoryTab() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reverting, setReverting] = useState(null);
  const [revertProgress, setRevertProgress] = useState({ current: 0, total: 0 });
  const [confirmRevert, setConfirmRevert] = useState(null);

  // Emergency cleanup state - prospects
  const [showEmergency, setShowEmergency] = useState(false);
  const [emergencyDate, setEmergencyDate] = useState(new Date().toISOString().split('T')[0]);
  const [emergencySearching, setEmergencySearching] = useState(false);
  const [emergencyProspects, setEmergencyProspects] = useState(null);
  const [confirmEmergency, setConfirmEmergency] = useState(false);
  const [emergencyDeleting, setEmergencyDeleting] = useState(false);
  const [emergencyProgress, setEmergencyProgress] = useState({ current: 0, total: 0 });

  // Emergency cleanup state - leads
  const [showLeadEmergency, setShowLeadEmergency] = useState(false);
  const [leadEmergencyDate, setLeadEmergencyDate] = useState(new Date().toISOString().split('T')[0]);
  const [leadEmergencySearching, setLeadEmergencySearching] = useState(false);
  const [leadEmergencyLeads, setLeadEmergencyLeads] = useState(null);
  const [confirmLeadEmergency, setConfirmLeadEmergency] = useState(false);
  const [leadEmergencyDeleting, setLeadEmergencyDeleting] = useState(false);
  const [leadEmergencyProgress, setLeadEmergencyProgress] = useState({ current: 0, total: 0 });

  const BATCH_SIZE = 50;

  const deleteBatched = async (ids, deleteFn) => {
    for (let i = 0; i < ids.length; i += BATCH_SIZE) {
      const batch = ids.slice(i, i + BATCH_SIZE);
      await Promise.all(batch.map(id => deleteFn(id).catch(() => {})));
      setRevertProgress(prev => ({ ...prev, current: Math.min(i + BATCH_SIZE, ids.length) }));
    }
  };

  useEffect(() => {
    loadHistory();
    // Subscribe to new ImportHistory records in real-time
    const unsubscribe = api.entities.ImportHistory.subscribe((event) => {
      if (event.type === 'create') {
        setHistory(prev => [event.data, ...prev]);
      } else if (event.type === 'update') {
        setHistory(prev => prev.map(h => h.id === event.id ? event.data : h));
      } else if (event.type === 'delete') {
        setHistory(prev => prev.filter(h => h.id !== event.id));
      }
    });
    return () => unsubscribe();
  }, []);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const data = await api.entities.ImportHistory.list('-created_date', 50);
      setHistory(data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchEmergency = async () => {
    setEmergencySearching(true);
    setEmergencyProspects(null);
    try {
      // Get ALL prospects created with source_channel = importacion_excel (pagination 200+)
      const all = await api.entities.Prospect.filter(
        { source_channel: 'importacion_excel' },
        '-created_date',
        500
      );
      // Filter by selected date
      const dateStr = emergencyDate; // YYYY-MM-DD
      const filtered = all.filter(p => {
        if (!p.created_date) return false;
        return p.created_date.startsWith(dateStr);
      });
      setEmergencyProspects(filtered);
    } catch (e) {
      toast.error('Error buscando prospectos: ' + e.message);
    } finally {
      setEmergencySearching(false);
    }
  };

  const handleEmergencyDelete = async () => {
    if (!emergencyProspects || emergencyProspects.length === 0) return;
    setEmergencyDeleting(true);
    setConfirmEmergency(false);
    setEmergencyProgress({ current: 0, total: emergencyProspects.length });
    try {
      const ids = emergencyProspects.map(p => p.id);
      await deleteBatched(ids, id => api.entities.Prospect.delete(id));
      toast.success(`${ids.length} prospectos eliminados correctamente.`);
      setEmergencyProspects(null);
      setShowEmergency(false);
    } catch (e) {
      toast.error('Error eliminando prospectos: ' + e.message);
    } finally {
      setEmergencyDeleting(false);
      setEmergencyProgress({ current: 0, total: 0 });
    }
  };

  const handleSearchLeadEmergency = async () => {
    setLeadEmergencySearching(true);
    setLeadEmergencyLeads(null);
    try {
      const all = await api.entities.Lead.list('-created_date', 500);
      const filtered = all.filter(l => l.created_date && l.created_date.startsWith(leadEmergencyDate));
      setLeadEmergencyLeads(filtered);
    } catch (e) {
      toast.error('Error buscando leads: ' + e.message);
    } finally {
      setLeadEmergencySearching(false);
    }
  };

  const handleLeadEmergencyDelete = async () => {
    if (!leadEmergencyLeads || leadEmergencyLeads.length === 0) return;
    setLeadEmergencyDeleting(true);
    setConfirmLeadEmergency(false);
    setLeadEmergencyProgress({ current: 0, total: leadEmergencyLeads.length });
    try {
      const ids = leadEmergencyLeads.map(l => l.id);
      for (let i = 0; i < ids.length; i += BATCH_SIZE) {
        const batch = ids.slice(i, i + BATCH_SIZE);
        await Promise.all(batch.map(id => api.entities.Lead.delete(id).catch(() => {})));
        setLeadEmergencyProgress(prev => ({ ...prev, current: Math.min(i + BATCH_SIZE, ids.length) }));
      }
      toast.success(`${ids.length} leads eliminados correctamente.`);
      setLeadEmergencyLeads(null);
      setShowLeadEmergency(false);
    } catch (e) {
      toast.error('Error eliminando leads: ' + e.message);
    } finally {
      setLeadEmergencyDeleting(false);
      setLeadEmergencyProgress({ current: 0, total: 0 });
    }
  };

  const handleRevert = async () => {
    if (!confirmRevert) return;
    const record = { ...confirmRevert }; // snapshot antes de limpiar estado
    setReverting(record.id);
    setConfirmRevert(null);

    try {
      const user = await api.auth.me();

      // --- Collect IDs to delete ---
      let leadIds = record.lead_ids || [];
      let prospectIds = record.prospect_ids || [];

      // Fallback: if prospect_ids is empty (payload too large at save time),
      // query by agent and creation date
      if (prospectIds.length === 0 && record.prospects_created > 0) {
        const importDate = record.created_date?.split('T')[0];
        const agentIds = record.assigned_agent_ids || [];

        // Fetch up to 1000 prospects created on the same day by any of the assigned agents
        const fetched = await api.entities.Prospect.list('-created_date', 1000);
        prospectIds = fetched
          .filter(p => {
            const sameDay = importDate && p.created_date?.startsWith(importDate);
            const sameAgent = agentIds.length === 0 || agentIds.includes(p.assigned_agent_id);
            return sameDay && sameAgent;
          })
          .map(p => p.id);
      }

      if (leadIds.length === 0 && record.leads_created > 0) {
        const importDate = record.created_date?.split('T')[0];
        const agentIds = record.assigned_agent_ids || [];
        const fetched = await api.entities.Lead.list('-created_date', 1000);
        leadIds = fetched
          .filter(l => {
            const sameDay = importDate && l.created_date?.startsWith(importDate);
            const sameAgent = agentIds.length === 0 || agentIds.includes(l.assigned_agent_id);
            return sameDay && sameAgent;
          })
          .map(l => l.id);
      }

      const totalItems = leadIds.length + prospectIds.length;
      setRevertProgress({ current: 0, total: totalItems });

      // Delete leads first (in batches)
      if (leadIds.length > 0) {
        await deleteBatched(leadIds, id => api.entities.Lead.delete(id));
      }

      // Delete prospects (in batches)
      if (prospectIds.length > 0) {
        setRevertProgress(prev => ({ ...prev, current: leadIds.length })); // reset counter for prospects phase
        await deleteBatched(prospectIds, id => api.entities.Prospect.delete(id));
      }

      // Mark as reverted
      await api.entities.ImportHistory.update(record.id, {
        reverted: true,
        reverted_at: new Date().toISOString(),
        reverted_by_name: user.full_name,
      });

      setHistory(prev => prev.map(h => h.id === record.id ? {
        ...h, reverted: true, reverted_at: new Date().toISOString(), reverted_by_name: user.full_name
      } : h));

      toast.success(`Importación revertida: ${prospectIds.length} prospectos y ${leadIds.length} leads eliminados.`);
    } catch (e) {
      toast.error('Error al revertir: ' + e.message);
    } finally {
      setReverting(null);
      setRevertProgress({ current: 0, total: 0 });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-brand" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{history.length} importaciones registradas</p>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={() => { setShowEmergency(v => !v); setShowLeadEmergency(false); }} className="gap-2 text-red-600 border-red-200 hover:bg-red-50">
            <Trash2 className="h-4 w-4" /> Limpiar prospectos
          </Button>
          <Button variant="outline" size="sm" onClick={() => { setShowLeadEmergency(v => !v); setShowEmergency(false); }} className="gap-2 text-orange-600 border-orange-200 hover:bg-orange-50">
            <Trash2 className="h-4 w-4" /> Limpiar leads
          </Button>
          <Button variant="outline" size="sm" onClick={loadHistory} className="gap-2">
            <RefreshCw className="h-4 w-4" /> Actualizar
          </Button>
        </div>
      </div>

      {/* Emergency cleanup panel */}
      {showEmergency && (
        <div className="border border-red-200 bg-red-50 dark:bg-red-950/20 rounded-xl p-4 space-y-3">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-700 text-sm">Limpieza de emergencia — Prospectos importados</p>
              <p className="text-xs text-red-600 mt-0.5">Busca y elimina prospectos creados por importación Excel en una fecha específica. Úsalo solo cuando el historial no registró la importación.</p>
            </div>
          </div>
          <div className="flex items-end gap-3">
            <div className="space-y-1 flex-1">
              <Label className="text-xs text-red-700">Fecha de importación</Label>
              <Input
                type="date"
                value={emergencyDate}
                onChange={e => { setEmergencyDate(e.target.value); setEmergencyProspects(null); }}
                className="h-9 border-red-200 focus:ring-red-400"
              />
            </div>
            <Button size="sm" onClick={handleSearchEmergency} disabled={emergencySearching} className="bg-red-600 hover:bg-red-700 text-white gap-1.5 h-9">
              {emergencySearching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
              Buscar
            </Button>
          </div>

          {emergencyProspects !== null && (
            <div className="bg-white dark:bg-zinc-900 border border-red-200 rounded-lg p-3 space-y-2">
              {emergencyProspects.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-2">No se encontraron prospectos importados en esa fecha.</p>
              ) : (
                <>
                  <p className="text-sm font-medium text-red-700">
                    Se encontraron <strong>{emergencyProspects.length} prospectos</strong> importados el {emergencyDate}
                  </p>
                  <div className="max-h-32 overflow-y-auto space-y-0.5">
                    {emergencyProspects.slice(0, 10).map(p => (
                      <p key={p.id} className="text-xs text-slate-500">• {p.full_name} {p.email ? `(${p.email})` : ''}</p>
                    ))}
                    {emergencyProspects.length > 10 && (
                      <p className="text-xs text-slate-400 italic">... y {emergencyProspects.length - 10} más</p>
                    )}
                  </div>
                  {emergencyDeleting && emergencyProgress.total > 0 && (
                    <div className="flex items-center gap-2 text-xs text-red-600">
                      <Loader2 className="h-3 w-3 animate-spin" />
                      <span>Eliminando {emergencyProgress.current} / {emergencyProgress.total}...</span>
                      <div className="flex-1 h-1.5 bg-red-100 rounded-full overflow-hidden">
                        <div className="h-full bg-red-500 rounded-full transition-all" style={{ width: `${Math.round((emergencyProgress.current / emergencyProgress.total) * 100)}%` }} />
                      </div>
                    </div>
                  )}
                  <Button
                    size="sm"
                    onClick={() => setConfirmEmergency(true)}
                    disabled={emergencyDeleting}
                    className="bg-red-600 hover:bg-red-700 text-white w-full gap-2"
                  >
                    <Trash2 className="h-4 w-4" />
                    Eliminar {emergencyProspects.length} prospectos permanentemente
                  </Button>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Emergency cleanup panel - Leads */}
      {showLeadEmergency && (
        <div className="border border-orange-200 bg-orange-50 dark:bg-orange-950/20 rounded-xl p-4 space-y-3">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-orange-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-orange-700 text-sm">Limpieza de emergencia — Leads creados</p>
              <p className="text-xs text-orange-600 mt-0.5">Busca y elimina todos los leads creados en una fecha específica. Úsalo para limpiar leads huérfanos o duplicados.</p>
            </div>
          </div>
          <div className="flex items-end gap-3">
            <div className="space-y-1 flex-1">
              <Label className="text-xs text-orange-700">Fecha de creación</Label>
              <Input
                type="date"
                value={leadEmergencyDate}
                onChange={e => { setLeadEmergencyDate(e.target.value); setLeadEmergencyLeads(null); }}
                className="h-9 border-orange-200 focus:ring-orange-400"
              />
            </div>
            <Button size="sm" onClick={handleSearchLeadEmergency} disabled={leadEmergencySearching} className="bg-orange-600 hover:bg-orange-700 text-white gap-1.5 h-9">
              {leadEmergencySearching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
              Buscar
            </Button>
          </div>

          {leadEmergencyLeads !== null && (
            <div className="bg-white dark:bg-zinc-900 border border-orange-200 rounded-lg p-3 space-y-2">
              {leadEmergencyLeads.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-2">No se encontraron leads creados en esa fecha.</p>
              ) : (
                <>
                  <p className="text-sm font-medium text-orange-700">
                    Se encontraron <strong>{leadEmergencyLeads.length} leads</strong> creados el {leadEmergencyDate}
                  </p>
                  <div className="max-h-32 overflow-y-auto space-y-0.5">
                    {leadEmergencyLeads.slice(0, 10).map(l => (
                      <p key={l.id} className="text-xs text-slate-500">• {l.prospect_name || l.external_id || l.id} {l.pipeline_name ? `(${l.pipeline_name})` : ''}</p>
                    ))}
                    {leadEmergencyLeads.length > 10 && (
                      <p className="text-xs text-slate-400 italic">... y {leadEmergencyLeads.length - 10} más</p>
                    )}
                  </div>
                  {leadEmergencyDeleting && leadEmergencyProgress.total > 0 && (
                    <div className="flex items-center gap-2 text-xs text-orange-600">
                      <Loader2 className="h-3 w-3 animate-spin" />
                      <span>Eliminando {leadEmergencyProgress.current} / {leadEmergencyProgress.total}...</span>
                      <div className="flex-1 h-1.5 bg-orange-100 rounded-full overflow-hidden">
                        <div className="h-full bg-orange-500 rounded-full transition-all" style={{ width: `${Math.round((leadEmergencyProgress.current / leadEmergencyProgress.total) * 100)}%` }} />
                      </div>
                    </div>
                  )}
                  <Button
                    size="sm"
                    onClick={() => setConfirmLeadEmergency(true)}
                    disabled={leadEmergencyDeleting}
                    className="bg-orange-600 hover:bg-orange-700 text-white w-full gap-2"
                  >
                    <Trash2 className="h-4 w-4" />
                    Eliminar {leadEmergencyLeads.length} leads permanentemente
                  </Button>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {history.length === 0 ? (
        <div className="text-center py-16 text-slate-400">
          <FileSpreadsheet className="h-10 w-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm">No hay importaciones registradas aún</p>
        </div>
      ) : (
        <div className="rounded-lg border border-slate-200 dark:border-zinc-700 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50 dark:bg-zinc-800">
                <TableHead>Archivo</TableHead>
                <TableHead>Fecha</TableHead>
                <TableHead>Importado por</TableHead>
                <TableHead>Agente asignado</TableHead>
                <TableHead>Prospectos</TableHead>
                <TableHead>Leads</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead className="text-right">Acción</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map(item => {
                const statusConf = STATUS_CONFIG[item.status] || STATUS_CONFIG.success;
                const StatusIcon = statusConf.icon;
                return (
                  <TableRow key={item.id} className={item.reverted ? 'opacity-50 bg-slate-50 dark:bg-zinc-900' : 'dark:border-zinc-700 dark:hover:bg-zinc-800/50'}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <FileSpreadsheet className="h-4 w-4 text-emerald-600 shrink-0" />
                        <span className="text-sm font-medium text-slate-700 dark:text-zinc-200 max-w-[160px] truncate">{item.file_name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs text-slate-500 dark:text-zinc-400 whitespace-nowrap">
                      {item.created_date ? format(new Date(item.created_date), "d MMM yyyy HH:mm", { locale: es }) : '-'}
                    </TableCell>
                    <TableCell className="text-sm text-slate-600 dark:text-zinc-300">{item.imported_by_name || '-'}</TableCell>
                    <TableCell className="text-sm text-slate-600 dark:text-zinc-300">
                      {item.assigned_agent_names && item.assigned_agent_names.length > 1 ? (
                        <Popover>
                          <PopoverTrigger asChild>
                            <button className="flex items-center gap-1.5 text-brand hover:underline">
                              <Users className="h-3.5 w-3.5" />
                              <span>{item.assigned_agent_names.length} agentes</span>
                            </button>
                          </PopoverTrigger>
                          <PopoverContent className="w-56 p-2">
                            <p className="text-xs font-semibold text-slate-500 mb-1.5 px-1">Agentes asignados</p>
                            <ul className="space-y-1">
                              {item.assigned_agent_names.map((name, i) => (
                                <li key={i} className="text-sm text-slate-700 dark:text-zinc-200 flex items-center gap-2 px-1 py-0.5 rounded hover:bg-slate-50 dark:hover:bg-zinc-800">
                                  <span className="w-5 h-5 rounded-full bg-brand/10 text-brand text-xs flex items-center justify-center font-bold shrink-0">{i + 1}</span>
                                  {name}
                                </li>
                              ))}
                            </ul>
                          </PopoverContent>
                        </Popover>
                      ) : (
                        item.assigned_agent_names?.[0] || item.assigned_agent_name || '-'
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-blue-100 text-blue-700">{item.prospects_created}</Badge>
                    </TableCell>
                    <TableCell>
                      {item.leads_created > 0
                        ? <Badge className="bg-purple-100 text-purple-700">{item.leads_created}</Badge>
                        : <span className="text-xs text-slate-400">—</span>
                      }
                    </TableCell>
                    <TableCell>
                      {item.reverted ? (
                        <Badge className="bg-slate-100 text-slate-500 gap-1">
                          <RotateCcw className="h-3 w-3" /> Revertida
                        </Badge>
                      ) : (
                        <Badge className={`${statusConf.className} gap-1`}>
                          <StatusIcon className="h-3 w-3" /> {statusConf.label}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {!item.reverted && item.status !== 'failed' && (
                        <div className="flex flex-col items-end gap-1">
                          {reverting === item.id && revertProgress.total > 0 && (
                            <div className="flex items-center gap-1.5 text-xs text-slate-400">
                              <span>{revertProgress.current}/{revertProgress.total}</span>
                              <div className="w-20 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-red-400 rounded-full transition-all duration-300"
                                  style={{ width: `${Math.round((revertProgress.current / revertProgress.total) * 100)}%` }}
                                />
                              </div>
                            </div>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={reverting === item.id}
                            onClick={() => setConfirmRevert(item)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50 gap-1.5 text-xs"
                          >
                            {reverting === item.id
                              ? <Loader2 className="h-3 w-3 animate-spin" />
                              : <RotateCcw className="h-3 w-3" />
                            }
                            {reverting === item.id ? 'Revirtiendo...' : 'Revertir'}
                          </Button>
                        </div>
                      )}
                      {item.reverted && (
                        <span className="text-xs text-slate-400">
                          por {item.reverted_by_name || '-'}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Emergency delete confirmation */}
      <AlertDialog open={confirmEmergency} onOpenChange={() => setConfirmEmergency(false)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="h-5 w-5" /> Confirmar eliminación masiva
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2 text-foreground">
              <p>Estás a punto de eliminar permanentemente <strong>{emergencyProspects?.length} prospectos</strong> importados el {emergencyDate}.</p>
              <p className="text-red-500 font-medium text-sm">Esta acción NO se puede deshacer.</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleEmergencyDelete} className="bg-red-600 hover:bg-red-700">
              Sí, eliminar {emergencyProspects?.length} prospectos
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Lead emergency delete confirmation */}
      <AlertDialog open={confirmLeadEmergency} onOpenChange={() => setConfirmLeadEmergency(false)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-orange-600">
              <Trash2 className="h-5 w-5" /> Confirmar eliminación de leads
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2 text-foreground">
              <p>Estás a punto de eliminar permanentemente <strong>{leadEmergencyLeads?.length} leads</strong> creados el {leadEmergencyDate}.</p>
              <p className="text-red-500 font-medium text-sm">Esta acción NO se puede deshacer.</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleLeadEmergencyDelete} className="bg-orange-600 hover:bg-orange-700">
              Sí, eliminar {leadEmergencyLeads?.length} leads
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirm revert dialog */}
      <AlertDialog open={!!confirmRevert} onOpenChange={() => setConfirmRevert(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <RotateCcw className="h-5 w-5" /> Revertir importación
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2 text-foreground">
              <p>¿Estás seguro? Esta acción eliminará permanentemente:</p>
              <ul className="list-disc list-inside text-sm space-y-1 text-foreground">
                <li><strong>{confirmRevert?.prospects_created}</strong> prospectos creados</li>
                {confirmRevert?.leads_created > 0 && (
                  <li><strong>{confirmRevert?.leads_created}</strong> leads creados</li>
                )}
              </ul>
              <p className="text-red-500 text-sm font-medium">Esta acción no se puede deshacer.</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleRevert} className="bg-red-600 hover:bg-red-700">
              Sí, revertir importación
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}