import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, Users, Check } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * ReassignAgentDialog
 * Props:
 *  - open: boolean
 *  - onClose: () => void
 *  - prospects: Prospect[]  (los seleccionados para reasignar)
 *  - onReassigned: () => void
 */
export default function ReassignAgentDialog({ open, onClose, prospects, onReassigned }) {
  const [agents, setAgents] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingAgents, setLoadingAgents] = useState(false);

  useEffect(() => {
    if (open) loadAgents();
  }, [open]);

  const loadAgents = async () => {
    setLoadingAgents(true);
    try {
      const res = await api.functions.invoke('listAgents', {});
      setAgents(res.data?.agents || []);
    } catch (e) {
      console.error('Error loading agents:', e);
    } finally {
      setLoadingAgents(false);
    }
  };

  const handleReassign = async () => {
    if (!selectedAgent || !prospects?.length) return;
    setLoading(true);
    try {
      await Promise.all(
        prospects.map(p =>
          api.entities.Prospect.update(p.id, {
            assigned_agent_id: selectedAgent.id,
            assigned_agent_name: selectedAgent.full_name,
          })
        )
      );
      onReassigned();
      handleClose();
    } catch (e) {
      console.error('Error reassigning:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedAgent(null);
    onClose();
  };

  const count = prospects?.length || 0;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            Reasignar Agente
          </DialogTitle>
          <DialogDescription>
            {count === 1
              ? `Selecciona el agente para "${prospects?.[0]?.full_name}"`
              : `Selecciona el agente para ${count} prospectos`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2 max-h-72 overflow-y-auto">
          {loadingAgents ? (
            <div className="flex justify-center py-6">
              <div className="h-6 w-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : agents.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-4">No hay agentes disponibles</p>
          ) : (
            agents.map(agent => (
              <button
                key={agent.id}
                onClick={() => setSelectedAgent(agent)}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-lg border-2 text-left transition-all",
                  selectedAgent?.id === agent.id
                    ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30"
                    : "border-slate-200 dark:border-zinc-700 hover:border-slate-300 dark:hover:border-zinc-500"
                )}
              >
                <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-zinc-700 flex items-center justify-center shrink-0">
                  <User className="h-4 w-4 text-slate-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{agent.full_name}</p>
                  <p className="text-xs text-slate-500 truncate">{agent.email}</p>
                </div>
                {agent.crm_role && (
                  <Badge variant="outline" className="text-xs shrink-0">
                    {agent.crm_role === 'admin_crm' ? 'Admin' : agent.crm_role === 'jefatura_crm' ? 'Jefatura' : 'Agente'}
                  </Badge>
                )}
                {selectedAgent?.id === agent.id && (
                  <Check className="h-4 w-4 text-blue-500 shrink-0" />
                )}
              </button>
            ))
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>Cancelar</Button>
          <Button
            onClick={handleReassign}
            disabled={!selectedAgent || loading}
            className="bg-blue-600 hover:bg-blue-700 gap-2"
          >
            {loading
              ? <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              : <Check className="h-4 w-4" />
            }
            Confirmar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}