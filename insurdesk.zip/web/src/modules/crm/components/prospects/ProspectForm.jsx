import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, User, Mail, Globe, ChevronDown, X, MapPin, Briefcase, ChevronUp, FileText } from "lucide-react";
import { api } from '@/api/client';
import TagSelector from '@/modules/crm/components/tags/TagSelector';

// Map country names to dial codes
const COUNTRY_DIAL_CODES = {
  "Ecuador": "+593", "Colombia": "+57", "Perú": "+51", "Venezuela": "+58",
  "Chile": "+56", "Argentina": "+54", "Bolivia": "+591", "Brasil": "+55",
  "Uruguay": "+598", "Paraguay": "+595", "Panamá": "+507", "Costa Rica": "+506",
  "Guatemala": "+502", "Honduras": "+504", "El Salvador": "+503", "Nicaragua": "+505",
  "México": "+52", "Cuba": "+53", "República Dominicana": "+1",
  "Puerto Rico": "+1", "Estados Unidos": "+1", "Canadá": "+1",
  "España": "+34", "Portugal": "+351", "Francia": "+33", "Italia": "+39",
  "Alemania": "+49", "Reino Unido": "+44", "Países Bajos": "+31",
  "Bélgica": "+32", "Suiza": "+41", "Suecia": "+46", "Noruega": "+47",
  "Dinamarca": "+45", "Finlandia": "+358", "Austria": "+43", "Polonia": "+48",
  "Rusia": "+7", "Ucrania": "+380", "China": "+86", "Japón": "+81",
  "India": "+91", "Australia": "+61", "Nueva Zelanda": "+64",
  "Sudáfrica": "+27", "Egipto": "+20", "Marruecos": "+212",
  "Nigeria": "+234", "Kenia": "+254", "Israel": "+972",
  "Arabia Saudita": "+966", "Emiratos Árabes Unidos": "+971",
  "Turquía": "+90", "Irán": "+98", "Irak": "+964",
  "Filipinas": "+63", "Indonesia": "+62", "Tailandia": "+66",
  "Vietnam": "+84", "Corea del Sur": "+82", "Singapur": "+65",
  "Malasia": "+60", "Pakistán": "+92", "Bangladesh": "+880",
};

// Sorted list for the dial code selector
const DIAL_CODE_OPTIONS = [
  { code: "+593", label: "EC · Ecuador +593" },
  { code: "+57",  label: "CO · Colombia +57" },
  { code: "+51",  label: "PE · Perú +51" },
  { code: "+58",  label: "VE · Venezuela +58" },
  { code: "+56",  label: "CL · Chile +56" },
  { code: "+54",  label: "AR · Argentina +54" },
  { code: "+591", label: "BO · Bolivia +591" },
  { code: "+55",  label: "BR · Brasil +55" },
  { code: "+598", label: "UY · Uruguay +598" },
  { code: "+595", label: "PY · Paraguay +595" },
  { code: "+507", label: "PA · Panamá +507" },
  { code: "+506", label: "CR · Costa Rica +506" },
  { code: "+502", label: "GT · Guatemala +502" },
  { code: "+504", label: "HN · Honduras +504" },
  { code: "+503", label: "SV · El Salvador +503" },
  { code: "+505", label: "NI · Nicaragua +505" },
  { code: "+52",  label: "MX · México +52" },
  { code: "+53",  label: "CU · Cuba +53" },
  { code: "+1",   label: "US · EE.UU./Canadá +1" },
  { code: "+34",  label: "ES · España +34" },
  { code: "+351", label: "PT · Portugal +351" },
  { code: "+33",  label: "FR · Francia +33" },
  { code: "+49",  label: "DE · Alemania +49" },
  { code: "+44",  label: "GB · Reino Unido +44" },
  { code: "+39",  label: "IT · Italia +39" },
  { code: "+7",   label: "RU · Rusia +7" },
  { code: "+86",  label: "CN · China +86" },
  { code: "+91",  label: "IN · India +91" },
  { code: "+61",  label: "AU · Australia +61" },
  { code: "+27",  label: "ZA · Sudáfrica +27" },
  { code: "+966", label: "SA · Arabia Saudita +966" },
  { code: "+971", label: "AE · EAU +971" },
  { code: "+90",  label: "TR · Turquía +90" },
];

const COUNTRIES = [
  "Afganistán","Albania","Alemania","Algeria","Andorra","Angola","Antigua y Barbuda",
  "Arabia Saudita","Argentina","Armenia","Australia","Austria","Azerbaiyán",
  "Bahamas","Bahrein","Bangladesh","Barbados","Bélgica","Belice","Benín",
  "Bielorrusia","Bolivia","Bosnia y Herzegovina","Botsuana","Brasil","Brunéi",
  "Bulgaria","Burkina Faso","Burundi","Bután",
  "Cabo Verde","Camboya","Camerún","Canadá","Catar","Chad","Chile","China",
  "Chipre","Colombia","Comoras","Congo","Corea del Norte","Corea del Sur",
  "Costa de Marfil","Costa Rica","Croacia","Cuba",
  "Dinamarca","Djibouti","Dominica",
  "Ecuador","Egipto","El Salvador","Emiratos Árabes Unidos","Eritrea","Eslovaquia",
  "Eslovenia","España","Estados Unidos","Estonia","Etiopía","Esuatini",
  "Fiji","Filipinas","Finlandia","Francia",
  "Gabón","Gambia","Georgia","Ghana","Granada","Grecia","Guatemala","Guinea",
  "Guinea Ecuatorial","Guinea-Bisáu","Guyana",
  "Haití","Honduras","Hungría",
  "India","Indonesia","Irak","Irán","Irlanda","Islandia","Islas Marshall",
  "Islas Salomón","Israel","Italia",
  "Jamaica","Japón","Jordania",
  "Kazajistán","Kenia","Kirguistán","Kiribati","Kuwait",
  "Laos","Lesoto","Letonia","Líbano","Liberia","Libia","Liechtenstein","Lituania","Luxemburgo",
  "Madagascar","Malasia","Malaui","Maldivas","Malí","Malta","Marruecos","Mauritania",
  "Mauricio","México","Micronesia","Moldavia","Mónaco","Mongolia","Montenegro","Mozambique","Myanmar",
  "Namibia","Nauru","Nepal","Nicaragua","Níger","Nigeria","Noruega","Nueva Zelanda",
  "Omán",
  "Países Bajos","Pakistán","Palaos","Palestina","Panamá","Papúa Nueva Guinea","Paraguay","Perú","Polonia","Portugal",
  "Puerto Rico",
  "Reino Unido","República Centroafricana","República Checa","República Democrática del Congo",
  "República Dominicana","Ruanda","Rumanía","Rusia",
  "Samoa","San Cristóbal y Nieves","San Marino","San Vicente y las Granadinas","Santa Lucía",
  "Santo Tomé y Príncipe","Senegal","Serbia","Seychelles","Sierra Leona","Singapur",
  "Siria","Somalia","Sri Lanka","Sudáfrica","Sudán","Sudán del Sur","Suecia","Suiza","Surinam",
  "Tailandia","Tanzania","Tayikistán","Timor Oriental","Togo","Tonga","Trinidad y Tobago",
  "Túnez","Turkmenistán","Turquía","Tuvalu",
  "Ucrania","Uganda","Uruguay","Uzbekistán",
  "Vanuatu","Venezuela","Vietnam",
  "Yemen",
  "Zambia","Zimbabue"
].sort((a, b) => a.localeCompare(b, 'es'));

function CountrySelector({ value, onChange }) {
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const normalize = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const filtered = COUNTRIES.filter(c => normalize(c).includes(normalize(search)));

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSelect = (country) => {
    onChange(country);
    setSearch('');
    setOpen(false);
  };

  const handleClear = (e) => {
    e.stopPropagation();
    onChange('');
    setSearch('');
  };

  return (
    <div className="relative" ref={ref}>
      <div
        className="flex items-center h-12 border border-input rounded-md bg-background px-3 gap-2 cursor-pointer"
        onClick={() => setOpen(prev => !prev)}
      >
        <Globe className="h-4 w-4 text-slate-400 shrink-0" />
        {open ? (
          <input
            autoFocus
            className="flex-1 text-base bg-transparent outline-none"
            placeholder="Buscar país..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <span className={`flex-1 text-base truncate ${value ? 'text-foreground' : 'text-muted-foreground'}`}>
            {value || 'Seleccionar país'}
          </span>
        )}
        {value && !open ? (
          <X className="h-4 w-4 text-slate-400 shrink-0" onClick={handleClear} />
        ) : (
          <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
        )}
      </div>
      {open && (
        <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-60 overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="px-3 py-3 text-sm text-muted-foreground">Sin resultados</div>
          ) : (
            filtered.map(country => (
              <div
                key={country}
                className={`px-3 py-3 text-base text-popover-foreground cursor-pointer hover:bg-accent hover:text-accent-foreground ${value === country ? 'bg-accent font-medium' : ''}`}
                onMouseDown={(e) => { e.preventDefault(); handleSelect(country); }}
              >
                {country}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

const ID_TYPES = ["Cédula", "Pasaporte", "RUC", "Otro"];

function parseFullName(fullName) {
  if (!fullName || !fullName.trim()) {
    return { first_names: '', last_names: '' };
  }

  const trimmed = fullName.trim();
  
  // Check if format is "APELLIDOS, NOMBRES"
  if (trimmed.includes(',')) {
    const parts = trimmed.split(',').map(p => p.trim());
    if (parts.length >= 2) {
      return {
        last_names: parts[0],
        first_names: parts.slice(1).join(' ')
      };
    }
  }

  // Standard format: try to split intelligently
  const words = trimmed.split(/\s+/);
  
  if (words.length === 1) {
    return { first_names: words[0], last_names: '' };
  }
  
  if (words.length === 2) {
    return { first_names: words[0], last_names: words[1] };
  }
  
  if (words.length === 3) {
    return { first_names: words[0], last_names: words.slice(1).join(' ') };
  }
  
  // 4+ words: assume first two are names, rest are last names
  if (words.length >= 4) {
    return {
      first_names: words.slice(0, 2).join(' '),
      last_names: words.slice(2).join(' ')
    };
  }

  return { first_names: trimmed, last_names: '' };
}

export default function ProspectForm({ open, onClose, prospect, onSaved }) {
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [dialCode, setDialCode] = useState('+593');
  const [phoneLocal, setPhoneLocal] = useState('');
  const [showExtra, setShowExtra] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '', first_names: '', last_names: '',
    id_type: '', id_number: '',
    birth_date: '', sex: '', marital_status: '', occupation: '', nationality: '',
    country: '', state: '', city: '', address: '',
    email: '', phone: '', phone_secondary: '',
    notes: '',
    tags: []
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (prospect) {
      // Decompose existing phone into dialCode + local
      const existingPhone = prospect.phone || '';
      let foundDial = '+593';
      let localPart = existingPhone;
      const sortedOptions = [...DIAL_CODE_OPTIONS].sort((a, b) => b.code.length - a.code.length);
      for (const opt of sortedOptions) {
        if (existingPhone.startsWith(opt.code)) {
          foundDial = opt.code;
          localPart = existingPhone.slice(opt.code.length).trim();
          break;
        }
      }
      setDialCode(foundDial);
      setPhoneLocal(localPart);
      setFormData({
        full_name: prospect.full_name || '', first_names: prospect.first_names || '', last_names: prospect.last_names || '',
        id_type: prospect.id_type || '', id_number: prospect.id_number || '',
        birth_date: prospect.birth_date || '', sex: prospect.sex || '', marital_status: prospect.marital_status || '',
        occupation: prospect.occupation || '', nationality: prospect.nationality || '',
        country: prospect.country || '', state: prospect.state || '', city: prospect.city || '', address: prospect.address || '',
        email: prospect.email || '', phone: prospect.phone || '', phone_secondary: prospect.phone_secondary || '',
        notes: prospect.notes || '',
        tags: prospect.tags || []
      });
      // Expand extra section if any extra field is filled
      const hasExtra = prospect.birth_date || prospect.sex || prospect.marital_status || prospect.occupation ||
        prospect.nationality || prospect.state || prospect.city || prospect.address || prospect.phone_secondary;
      setShowExtra(!!hasExtra);
    } else {
      setDialCode('+593');
      setPhoneLocal('');
      setShowExtra(false);
      setFormData({
        full_name: '', first_names: '', last_names: '',
        id_type: '', id_number: '',
        birth_date: '', sex: '', marital_status: '', occupation: '', nationality: '',
        country: '', state: '', city: '', address: '',
        email: '', phone: '', phone_secondary: '',
        notes: '',
        tags: []
      });
    }
    setErrors({});
  }, [prospect, open]);

  const loadUser = async () => {
    try {
      const user = await api.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const handleCountryChange = (value) => {
    setFormData(prev => ({ ...prev, country: value }));
    const autoCode = COUNTRY_DIAL_CODES[value];
    if (autoCode) setDialCode(autoCode);
  };

  const handlePhoneLocalChange = (value) => {
    // Strip any non-digit chars except spaces and dashes
    const cleaned = value.replace(/[^\d\s\-]/g, '');
    setPhoneLocal(cleaned);
    const full = cleaned.trim() ? `${dialCode}${cleaned.trim().replace(/\s|-/g, '')}` : '';
    setFormData(prev => ({ ...prev, phone: full }));
  };

  const handleDialCodeChange = (code) => {
    setDialCode(code);
    const full = phoneLocal.trim() ? `${code}${phoneLocal.trim().replace(/\s|-/g, '')}` : '';
    setFormData(prev => ({ ...prev, phone: full }));
  };

  const handleFullNameChange = (value) => {
    const parsed = parseFullName(value);
    setFormData(prev => ({
      ...prev,
      full_name: value,
      first_names: parsed.first_names,
      last_names: parsed.last_names
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.full_name.trim()) {
      newErrors.full_name = 'El nombre completo es obligatorio';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'El email es obligatorio';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email no válido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setLoading(true);
    try {
      const data = {
        ...formData,
        assigned_agent_id: prospect?.assigned_agent_id || currentUser?.id,
        assigned_agent_name: prospect?.assigned_agent_name || currentUser?.full_name
      };

      if (prospect) {
        await api.entities.Prospect.update(prospect.id, data);
      } else {
        await api.entities.Prospect.create(data);
      }
      
      onSaved?.();
      onClose();
    } catch (error) {
      console.error('Error saving prospect:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-lg max-h-[95dvh] overflow-y-auto p-0 gap-0 rounded-t-2xl sm:rounded-2xl">
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-slate-100 dark:border-zinc-700 sticky top-0 bg-white dark:bg-zinc-900 z-10">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <User className="h-5 w-5 text-blue-600" />
            {prospect ? 'Editar Prospecto' : 'Nuevo Prospecto'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="px-5 py-4 space-y-5">
          <div>
            <Label htmlFor="full_name" className="text-sm font-medium mb-1.5 block">Nombre Completo *</Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={(e) => handleFullNameChange(e.target.value)}
              placeholder="Juan Carlos Pérez García"
              className={`h-12 text-base ${errors.full_name ? 'border-red-500' : ''}`}
              autoComplete="name"
            />
            {errors.full_name && (
              <p className="text-xs text-red-500 mt-1">{errors.full_name}</p>
            )}
            {(formData.first_names || formData.last_names) && (
              <p className="text-xs text-slate-500 mt-1.5 bg-slate-50 rounded-md px-2 py-1">
                Nombres: <strong>{formData.first_names || '—'}</strong> · Apellidos: <strong>{formData.last_names || '—'}</strong>
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="id_type" className="text-sm font-medium mb-1.5 block">Tipo ID</Label>
              <Select
                value={formData.id_type}
                onValueChange={(value) => setFormData(prev => ({ ...prev, id_type: value }))}
              >
                <SelectTrigger className="h-12 text-base">
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  {ID_TYPES.map(type => (
                    <SelectItem key={type} value={type} className="text-base py-3">{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="id_number" className="text-sm font-medium mb-1.5 block">Número ID</Label>
              <Input
                id="id_number"
                value={formData.id_number}
                onChange={(e) => setFormData(prev => ({ ...prev, id_number: e.target.value }))}
                placeholder="1234567890"
                className="h-12 text-base"
                inputMode="numeric"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="country" className="text-sm font-medium mb-1.5 block">País</Label>
            <CountrySelector
              value={formData.country}
              onChange={handleCountryChange}
            />
          </div>

          {/* ── Datos adicionales (colapsable) ── */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <button
              type="button"
              onClick={() => setShowExtra(prev => !prev)}
              className="w-full flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 transition-colors text-sm font-medium text-slate-700"
            >
              <span className="flex items-center gap-2">
                <User className="h-4 w-4 text-slate-400" />
                Datos adicionales
                <span className="text-xs text-slate-400 font-normal">(edad, sexo, dirección, etc.)</span>
              </span>
              {showExtra ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
            </button>

            {showExtra && (
              <div className="px-4 py-4 space-y-4">
                {/* Fecha de nacimiento + Sexo */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-sm font-medium mb-1.5 block">Fecha de nacimiento</Label>
                    <Input
                      type="date"
                      value={formData.birth_date}
                      onChange={(e) => setFormData(prev => ({ ...prev, birth_date: e.target.value }))}
                      className="h-10 text-base"
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-medium mb-1.5 block">Sexo</Label>
                    <Select value={formData.sex} onValueChange={(v) => setFormData(prev => ({ ...prev, sex: v }))}>
                      <SelectTrigger className="h-10 text-base"><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                      <SelectContent>
                        {["Masculino", "Femenino", "Otro"].map(s => <SelectItem key={s} value={s} className="text-base py-2">{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Estado civil + Nacionalidad */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-sm font-medium mb-1.5 block">Estado civil</Label>
                    <Select value={formData.marital_status} onValueChange={(v) => setFormData(prev => ({ ...prev, marital_status: v }))}>
                      <SelectTrigger className="h-10 text-base"><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                      <SelectContent>
                        {["Soltero/a", "Casado/a", "Divorciado/a", "Viudo/a", "Unión libre"].map(s => <SelectItem key={s} value={s} className="text-base py-2">{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-sm font-medium mb-1.5 block">Nacionalidad</Label>
                    <Input
                      value={formData.nationality}
                      onChange={(e) => setFormData(prev => ({ ...prev, nationality: e.target.value }))}
                      placeholder="Ecuatoriana"
                      className="h-10 text-base"
                    />
                  </div>
                </div>

                {/* Ocupación */}
                <div>
                  <Label className="text-sm font-medium mb-1.5 block">Ocupación / Profesión</Label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                    <Input
                      value={formData.occupation}
                      onChange={(e) => setFormData(prev => ({ ...prev, occupation: e.target.value }))}
                      placeholder="Ingeniero, Médico, Empresario..."
                      className="h-10 pl-10 text-base"
                    />
                  </div>
                </div>

                {/* Provincia + Ciudad */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-sm font-medium mb-1.5 block">Provincia / Estado</Label>
                    <Input
                      value={formData.state}
                      onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
                      placeholder="Pichincha"
                      className="h-10 text-base"
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-medium mb-1.5 block">Ciudad</Label>
                    <Input
                      value={formData.city}
                      onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                      placeholder="Quito"
                      className="h-10 text-base"
                    />
                  </div>
                </div>

                {/* Dirección */}
                <div>
                  <Label className="text-sm font-medium mb-1.5 block">Dirección</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                    <Input
                      value={formData.address}
                      onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                      placeholder="Av. Principal 123"
                      className="h-10 pl-10 text-base"
                    />
                  </div>
                </div>

                {/* Teléfono secundario */}
                <div>
                  <Label className="text-sm font-medium mb-1.5 block">Teléfono secundario</Label>
                  <Input
                    value={formData.phone_secondary}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone_secondary: e.target.value }))}
                    placeholder="+593 99 999 9999"
                    className="h-10 text-base"
                    type="tel"
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="email" className="text-sm font-medium mb-1.5 block">Email *</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="correo@ejemplo.com"
                className={`h-12 pl-10 text-base ${errors.email ? 'border-red-500' : ''}`}
                autoComplete="email"
                inputMode="email"
              />
            </div>
            {errors.email && (
              <p className="text-xs text-red-500 mt-1">{errors.email}</p>
            )}
          </div>

          <div>
            <Label htmlFor="phone" className="text-sm font-medium mb-1.5 block">Teléfono</Label>
            <div className="flex gap-2">
              <Select value={dialCode} onValueChange={handleDialCodeChange}>
                <SelectTrigger className="h-12 text-base w-[140px] shrink-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {DIAL_CODE_OPTIONS.map(opt => (
                    <SelectItem key={opt.code} value={opt.code} className="text-sm py-2">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                id="phone"
                value={phoneLocal}
                onChange={(e) => handlePhoneLocalChange(e.target.value)}
                placeholder="99 999 9999"
                className="h-12 text-base flex-1"
                type="tel"
                autoComplete="tel"
                inputMode="tel"
              />
            </div>
            {formData.phone && (
              <p className="text-xs text-slate-400 mt-1">Se guardará como: <strong>{formData.phone}</strong></p>
            )}
          </div>

          <div>
            <Label className="text-sm font-medium mb-1.5 block">Etiquetas</Label>
            <TagSelector
              value={formData.tags}
              onChange={(tags) => setFormData(prev => ({ ...prev, tags }))}
            />
          </div>

          {/* Notas del prospecto */}
          <div>
            <Label className="text-sm font-medium mb-1.5 flex items-center gap-1.5">
              <FileText className="h-4 w-4 text-slate-400" />
              Notas del prospecto
              <span className="text-xs text-slate-400 font-normal">(ingresos, estado migratorio, etc.)</span>
            </Label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Ej: Ingresos mensuales $3,000. Residente permanente. Interesado en vida a largo plazo..."
              rows={3}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring resize-none"
            />
          </div>

          <div className="flex gap-3 pt-2 pb-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 h-12 text-base">
              Cancelar
            </Button>
            <Button type="submit" disabled={loading} className="flex-1 h-12 text-base font-semibold">
              {loading && <Loader2 className="mr-2 h-5 w-5 animate-spin" />}
              {prospect ? 'Actualizar' : 'Crear Prospecto'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}