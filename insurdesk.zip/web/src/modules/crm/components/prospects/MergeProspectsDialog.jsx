import React, { useState, useMemo } from 'react';
import { api } from '@/api/client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Search, Merge, User, Mail, Phone, CreditCard, AlertTriangle, Check } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * MergeProspectsDialog
 * Props:
 *  - open: boolean
 *  - onClose: () => void
 *  - sourceProspect: Prospect  (el prospecto "origen" seleccionado en la tabla)
 *  - allProspects: Prospect[]  (lista completa para buscar el destino)
 *  - onMerged: () => void
 */
export default function MergeProspectsDialog({ open, onClose, sourceProspect, allProspects, onMerged }) {
  const [search, setSearch] = useState('');
  const [targetProspect, setTargetProspect] = useState(null);
  const [masterChoice, setMasterChoice] = useState('source'); // 'source' | 'target'
  const [loading, setLoading] = useState(false);

  const candidates = useMemo(() => {
    if (!search || !sourceProspect) return [];
    const q = search.toLowerCase();
    return allProspects.filter(p =>
      p.id !== sourceProspect.id &&
      (p.full_name?.toLowerCase().includes(q) ||
        p.email?.toLowerCase().includes(q) ||
        p.phone?.includes(search) ||
        p.id_number?.includes(search))
    ).slice(0, 8);
  }, [search, allProspects, sourceProspect]);

  const master = masterChoice === 'source' ? sourceProspect : targetProspect;
  const duplicate = masterChoice === 'source' ? targetProspect : sourceProspect;

  const handleMerge = async () => {
    if (!master || !duplicate) return;
    setLoading(true);
    try {
      // 1. Move all leads from duplicate → master
      const leads = await api.entities.Lead.filter({ prospect_id: duplicate.id });
      await Promise.all(leads.map(lead =>
        api.entities.Lead.update(lead.id, {
          prospect_id: master.id,
          prospect_name: master.full_name,
        })
      ));

      // 2. Move all activities from duplicate → master (via lead_id chain, already moved above)
      // 3. Merge missing fields from duplicate into master (fill blanks)
      const mergedFields = {};
      const fillableFields = [
        'phone', 'phone_secondary', 'email', 'id_type', 'id_number',
        'birth_date', 'sex', 'marital_status', 'occupation', 'nationality',
        'country', 'state', 'city', 'address', 'notes',
      ];
      fillableFields.forEach(field => {
        if (!master[field] && duplicate[field]) {
          mergedFields[field] = duplicate[field];
        }
      });
      // Merge notes
      if (master.notes && duplicate.notes && master.notes !== duplicate.notes) {
        mergedFields.notes = `${master.notes}\n\n[Fusionado]: ${duplicate.notes}`;
      }
      // Merge tags
      const masterTagIds = (master.tags || []).map(t => t.id);
      const newTags = (duplicate.tags || []).filter(t => !masterTagIds.includes(t.id));
      if (newTags.length > 0) {
        mergedFields.tags = [...(master.tags || []), ...newTags];
      }

      if (Object.keys(mergedFields).length > 0) {
        await api.entities.Prospect.update(master.id, mergedFields);
      }

      // 4. Delete the duplicate
      await api.entities.Prospect.delete(duplicate.id);

      onMerged();
      handleClose();
    } catch (e) {
      console.error('Error merging prospects:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSearch('');
    setTargetProspect(null);
    setMasterChoice('source');
    onClose();
  };

  if (!sourceProspect) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Merge className="h-5 w-5 text-blue-600" />
            Fusionar Prospectos Duplicados
          </DialogTitle>
          <DialogDescription>
            Busca el prospecto duplicado, elige cuál conservar como principal y fusiona sus datos.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Step 1: Search */}
          <div>
            <p className="text-sm font-medium mb-2 text-slate-700 dark:text-zinc-300">
              1. Busca el prospecto duplicado a fusionar con <span className="font-bold">{sourceProspect.full_name}</span>
            </p>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Nombre, email, teléfono..."
                value={search}
                onChange={e => { setSearch(e.target.value); setTargetProspect(null); }}
                className="pl-10"
              />
            </div>
            {candidates.length > 0 && !targetProspect && (
              <div className="mt-2 border rounded-lg overflow-hidden divide-y dark:divide-zinc-700 dark:border-zinc-700">
                {candidates.map(p => (
                  <button
                    key={p.id}
                    onClick={() => setTargetProspect(p)}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-zinc-800 text-left transition-colors"
                  >
                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center shrink-0">
                      <User className="h-4 w-4 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{p.full_name}</p>
                      <p className="text-xs text-slate-500 truncate">{p.email} {p.phone ? `· ${p.phone}` : ''}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Step 2: Choose master */}
          {targetProspect && (
            <>
              <Separator />
              <div>
                <p className="text-sm font-medium mb-3 text-slate-700 dark:text-zinc-300">
                  2. Elige cuál conservar como prospecto principal
                </p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: 'source', prospect: sourceProspect, label: 'Prospecto origen' },
                    { key: 'target', prospect: targetProspect, label: 'Prospecto encontrado' },
                  ].map(({ key, prospect, label }) => (
                    <button
                      key={key}
                      onClick={() => setMasterChoice(key)}
                      className={cn(
                        "relative border-2 rounded-lg p-4 text-left transition-all",
                        masterChoice === key
                          ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30"
                          : "border-slate-200 dark:border-zinc-700 hover:border-slate-300"
                      )}
                    >
                      {masterChoice === key && (
                        <span className="absolute top-2 right-2 bg-blue-500 text-white rounded-full p-0.5">
                          <Check className="h-3 w-3" />
                        </span>
                      )}
                      <Badge variant="outline" className="mb-2 text-xs">{label}</Badge>
                      <p className="font-semibold text-sm">{prospect.full_name}</p>
                      <div className="space-y-1 mt-2">
                        {prospect.email && <p className="text-xs text-slate-500 flex items-center gap-1"><Mail className="h-3 w-3" />{prospect.email}</p>}
                        {prospect.phone && <p className="text-xs text-slate-500 flex items-center gap-1"><Phone className="h-3 w-3" />{prospect.phone}</p>}
                        {prospect.id_number && <p className="text-xs text-slate-500 flex items-center gap-1"><CreditCard className="h-3 w-3" />{prospect.id_type}: {prospect.id_number}</p>}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Warning */}
              <div className="flex items-start gap-2 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-700 rounded-lg p-3">
                <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-700 dark:text-amber-400">
                  Se conservará <strong>{master?.full_name}</strong> y se eliminarán permanentemente los datos de <strong>{duplicate?.full_name}</strong>. Los leads y datos faltantes se transferirán al principal.
                </p>
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>Cancelar</Button>
          <Button
            onClick={handleMerge}
            disabled={!targetProspect || loading}
            className="bg-blue-600 hover:bg-blue-700 gap-2"
          >
            {loading ? <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Merge className="h-4 w-4" />}
            Fusionar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}