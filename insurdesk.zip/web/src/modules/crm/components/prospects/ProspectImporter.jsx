import React, { useState, useRef, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Upload, FileSpreadsheet, Check, AlertCircle, Loader2, X, ArrowRight, ArrowLeft, Users, GitBranch, Tag, ChevronDown, Info } from "lucide-react";
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import TagSelector from '@/modules/crm/components/tags/TagSelector';
import { useBranches } from '@/lib/useBranches';

const PROSPECT_FIELDS = [
  { key: 'full_name',       label: 'Nombre completo',          required: true,  group: 'basic' },
  { key: 'email',           label: 'Email',                    required: false, group: 'basic' },
  { key: 'phone',           label: 'Teléfono',                 required: false, group: 'basic' },
  { key: 'phone_secondary', label: 'Teléfono secundario',      required: false, group: 'basic' },
  { key: 'id_type',         label: 'Tipo de identificación',   required: false, group: 'basic' },
  { key: 'id_number',       label: 'Número de identificación', required: false, group: 'basic' },
  { key: 'birth_date',      label: 'Fecha de nacimiento',      required: false, group: 'personal' },
  { key: 'sex',             label: 'Sexo',                     required: false, group: 'personal' },
  { key: 'marital_status',  label: 'Estado civil',             required: false, group: 'personal' },
  { key: 'occupation',      label: 'Ocupación / Profesión',    required: false, group: 'personal' },
  { key: 'nationality',     label: 'Nacionalidad',             required: false, group: 'personal' },
  { key: 'country',         label: 'País',                     required: false, group: 'location' },
  { key: 'state',           label: 'Provincia / Estado',       required: false, group: 'location' },
  { key: 'city',            label: 'Ciudad',                   required: false, group: 'location' },
  { key: 'address',         label: 'Dirección',                required: false, group: 'location' },
  { key: 'source_channel',  label: 'Canal de origen',          required: false, group: 'basic' },
  { key: 'notes',           label: 'Notas',                    required: false, group: 'basic' },
];

// --- Step 1: Upload file ---
function StepUpload({ file, rows, onFile, onClear, parseError }) {
  const fileRef = useRef();
  return (
    <div className="space-y-4">
      <div
        className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center cursor-pointer hover:border-brand hover:bg-blue-50/30 transition-all"
        onClick={() => fileRef.current?.click()}
      >
        <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={onFile} />
        {file ? (
          <div className="flex items-center justify-center gap-3">
            <FileSpreadsheet className="h-8 w-8 text-emerald-600" />
            <div className="text-left">
              <p className="font-medium text-slate-800">{file.name}</p>
              <p className="text-sm text-slate-500">{rows.length} filas encontradas</p>
            </div>
            <button className="ml-2 text-slate-400 hover:text-red-500" onClick={(e) => { e.stopPropagation(); onClear(); }}>
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <>
            <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="font-medium text-slate-600">Haz clic para seleccionar tu archivo Excel</p>
            <p className="text-xs text-slate-400 mt-1">Soporta .xlsx y .xls — cualquier formato de columnas</p>
          </>
        )}
      </div>
      {parseError && (
        <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg p-3 text-sm">
          <AlertCircle className="h-4 w-4 shrink-0" /> {parseError}
        </div>
      )}
    </div>
  );
}

// --- Step 2: Map fields ---
const GROUP_LABELS = { basic: 'Datos básicos', personal: 'Datos personales', location: 'Ubicación' };

function StepMapping({ headers, mapping, onChange }) {
  const groups = ['basic', 'personal', 'location'];
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">Asigna las columnas de tu archivo a los campos del CRM.</p>
      <div className="space-y-4 max-h-[380px] overflow-y-auto pr-1">
        {groups.map(group => {
          const fields = PROSPECT_FIELDS.filter(f => f.group === group);
          return (
            <div key={group}>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 px-1">{GROUP_LABELS[group]}</p>
              <div className="space-y-1.5">
                {fields.map(field => (
                  <div key={field.key} className="flex items-center gap-3 bg-muted rounded-lg px-3 py-2 border border-border">
                    <div className="w-44 shrink-0">
                      <span className="text-sm font-medium text-foreground">{field.label}</span>
                      {field.required && <span className="ml-1 text-red-500 text-xs">*</span>}
                    </div>
                    <Select value={mapping[field.key] || '__none__'} onValueChange={val => onChange(field.key, val === '__none__' ? '' : val)}>
                      <SelectTrigger className="h-8 text-xs flex-1">
                        <SelectValue placeholder="— no asignar —" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">— no asignar —</SelectItem>
                        {headers.map(h => (
                          <SelectItem key={h} value={h}>{h}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {mapping[field.key] && (
                      <Badge className="bg-emerald-100 text-emerald-700 text-xs shrink-0">✓</Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// --- Step 3: Assignment & Lead options ---
function AgentMultiSelect({ agents, selectedIds, onChange }) {
  const [open, setOpen] = React.useState(false);

  const toggle = (id) => {
    if (selectedIds.includes(id)) {
      onChange(selectedIds.filter(x => x !== id));
    } else {
      onChange([...selectedIds, id]);
    }
  };

  const selectedAgents = agents.filter(a => selectedIds.includes(a.id));

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-2 border border-input rounded-md px-3 py-2 text-sm bg-background hover:bg-muted transition-colors min-h-[40px]"
      >
        <div className="flex flex-wrap gap-1 flex-1 min-w-0">
          {selectedAgents.length === 0 ? (
            <span className="text-muted-foreground">Selecciona uno o más agentes...</span>
          ) : selectedAgents.length === 1 ? (
            <span className="truncate">{selectedAgents[0].full_name}</span>
          ) : (
            <span className="text-brand font-medium">{selectedAgents.length} agentes seleccionados</span>
          )}
        </div>
        <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full bg-popover border border-border rounded-md shadow-lg max-h-56 overflow-y-auto">
          {agents.map(a => {
            const selected = selectedIds.includes(a.id);
            return (
              <button
                key={a.id}
                type="button"
                onClick={() => toggle(a.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm hover:bg-muted transition-colors text-left ${selected ? 'bg-blue-50 dark:bg-blue-950/30' : ''}`}
              >
                <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${selected ? 'bg-brand border-brand' : 'border-input'}`}>
                  {selected && <Check className="h-3 w-3 text-white" />}
                </div>
                <div className="min-w-0">
                  <p className="font-medium truncate">{a.full_name}</p>
                  {a.email && <p className="text-xs text-muted-foreground truncate">{a.email}</p>}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function StepOptions({ agents, pipelines, options, onChange }) {
  const { branches } = useBranches();
  const selectedPipeline = pipelines.find(p => p.id === options.pipeline_id);
  const stages = selectedPipeline?.stages || [];
  const selectedAgentIds = options.agent_ids || [];
  const selectedCount = selectedAgentIds.length;

  return (
    <div className="space-y-5">
      {/* Agent assignment */}
      <div className="space-y-2">
        <Label className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Users className="h-4 w-4 text-brand" /> Asignar prospectos a
        </Label>
        <AgentMultiSelect
          agents={agents}
          selectedIds={selectedAgentIds}
          onChange={ids => onChange('agent_ids', ids)}
        />
        {selectedCount > 1 && (
          <p className="text-xs text-brand bg-blue-50 dark:bg-blue-950/30 px-3 py-1.5 rounded-md">
            Los prospectos se asignarán equitativamente entre los agentes seleccionados
          </p>
        )}
      </div>

      <div className="border-t border-slate-100 pt-4 space-y-4">
        {/* Create leads toggle */}
        <div className="flex items-center justify-between bg-muted rounded-lg px-4 py-3 border border-border">
          <div>
            <p className="text-sm font-semibold text-foreground flex items-center gap-2">
              <GitBranch className="h-4 w-4 text-brand" /> Crear leads automáticamente
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">Se creará un lead por cada prospecto importado</p>
          </div>
          <Switch
            checked={!!options.create_leads}
            onCheckedChange={v => onChange('create_leads', v)}
          />
        </div>

        {options.create_leads && (
          <div className="space-y-3 pl-2 border-l-2 border-brand/30">
            {/* Pipeline */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-foreground">Pipeline</Label>
              <Select value={options.pipeline_id || ''} onValueChange={v => { onChange('pipeline_id', v); onChange('pipeline_stage', ''); }}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Selecciona un pipeline..." />
                </SelectTrigger>
                <SelectContent>
                  {pipelines.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Stage */}
            {stages.length > 0 && (
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-foreground">Etapa inicial</Label>
                <Select value={options.pipeline_stage || ''} onValueChange={v => onChange('pipeline_stage', v)}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Selecciona la etapa..." />
                  </SelectTrigger>
                  <SelectContent>
                    {stages.map(s => (
                      <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Branch */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-foreground">Ramo</Label>
              <Select value={options.branch || ''} onValueChange={v => onChange('branch', v)}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Selecciona el ramo..." />
                </SelectTrigger>
                <SelectContent>
                  {branches.map(b => (
                    <SelectItem key={b} value={b}>{b}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Tags for leads */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-foreground flex items-center gap-1.5">
                <Tag className="h-3.5 w-3.5" /> Etiquetas para los leads (opcional)
              </Label>
              <TagSelector
                value={options.tags || []}
                onChange={v => onChange('tags', v)}
                placeholder="Selecciona etiquetas..."
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// --- Step 3.5: Confirmation summary ---
function StepConfirm({ rows, mapping, options, agents, pipelines }) {
  const selectedAgents = agents.filter(a => (options.agent_ids || []).includes(a.id));
  const selectedPipeline = pipelines.find(p => p.id === options.pipeline_id);
  const mappedFields = Object.entries(mapping).filter(([, v]) => !!v);

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4">
        <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-amber-800 text-sm">Revisa antes de importar</p>
          <p className="text-xs text-amber-700 mt-0.5">Esta acción creará registros nuevos en el CRM. Verifica que todo sea correcto.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-50 dark:bg-zinc-800 rounded-lg p-3 border border-border">
          <p className="text-xs text-muted-foreground mb-1">Registros a importar</p>
          <p className="text-2xl font-bold text-brand">{rows.length}</p>
          <p className="text-xs text-muted-foreground">prospectos</p>
        </div>
        <div className="bg-slate-50 dark:bg-zinc-800 rounded-lg p-3 border border-border">
          <p className="text-xs text-muted-foreground mb-1">Campos mapeados</p>
          <p className="text-2xl font-bold text-slate-700 dark:text-zinc-200">{mappedFields.length}</p>
          <p className="text-xs text-muted-foreground">de {Object.keys(mapping).length > 0 ? mappedFields.length : '—'} columnas</p>
        </div>
      </div>

      <div className="space-y-2 text-sm">
        <div className="flex items-center gap-2 py-2 border-b border-border">
          <Users className="h-4 w-4 text-brand shrink-0" />
          <span className="text-muted-foreground">Agentes:</span>
          <span className="font-medium text-foreground">
            {selectedAgents.length === 0 ? '—' : selectedAgents.length === 1
              ? selectedAgents[0].full_name
              : `${selectedAgents.length} agentes (round-robin)`}
          </span>
        </div>
        <div className="flex items-center gap-2 py-2 border-b border-border">
          <GitBranch className="h-4 w-4 text-brand shrink-0" />
          <span className="text-muted-foreground">Crear leads:</span>
          <span className="font-medium text-foreground">
            {options.create_leads
              ? `Sí — Pipeline: ${selectedPipeline?.name || '—'} / ${options.branch || '—'}`
              : 'No'}
          </span>
        </div>
        {options.create_leads && (
          <div className="flex items-center gap-2 py-2 border-b border-border">
            <Check className="h-4 w-4 text-emerald-600 shrink-0" />
            <span className="text-muted-foreground">Leads a crear:</span>
            <span className="font-medium text-emerald-700">{rows.length} leads</span>
          </div>
        )}
      </div>
    </div>
  );
}

// --- Step 4: Result ---
function StepResult({ result, failedRows, onRetry }) {
  return (
    <div className="space-y-3">
      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-3">
        <div className="flex items-center gap-2 text-emerald-700 font-semibold">
          <Check className="h-5 w-5" /> Importación completada
        </div>
        <div className="flex gap-3 flex-wrap">
          <Badge className="bg-emerald-100 text-emerald-700">{result.created} prospectos creados</Badge>
          {result.leads_created > 0 && <Badge className="bg-blue-100 text-blue-700">{result.leads_created} leads creados</Badge>}
          {result.skipped > 0 && <Badge className="bg-amber-100 text-amber-700">{result.skipped} omitidos</Badge>}
          {result.errors?.length > 0 && <Badge className="bg-red-100 text-red-700">{result.errors.length} errores</Badge>}
        </div>
        {result.errors?.length > 0 && (
          <ul className="text-xs text-red-600 space-y-0.5 max-h-24 overflow-y-auto">
            {result.errors.slice(0, 5).map((e, i) => <li key={i}>• {e}</li>)}
          </ul>
        )}
      </div>
      {failedRows?.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-amber-800">{failedRows.length} fila(s) con error</p>
            <p className="text-xs text-amber-700 mt-0.5 mb-3">Puedes reintentar solo las filas que fallaron sin volver a importar las exitosas.</p>
            <Button size="sm" onClick={onRetry} className="bg-amber-600 hover:bg-amber-700 text-white gap-1.5">
              <ArrowRight className="h-3.5 w-3.5" /> Reintentar {failedRows.length} fila(s) con error
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// --- Main Component ---
export default function ProspectImporter({ open, onClose, onImported }) {
  const [step, setStep] = useState(1); // 1: upload, 2: mapping, 3: options, 4: confirm, 5: result
  const [file, setFile] = useState(null);
  const [rows, setRows] = useState([]);
  const [parseError, setParseError] = useState('');
  const [mapping, setMapping] = useState({});
  const [options, setOptions] = useState({ create_leads: false, agent_ids: [] });
  const [agents, setAgents] = useState([]);
  const [pipelines, setPipelines] = useState([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [failedRows, setFailedRows] = useState([]);

  useEffect(() => {
    if (open) {
      loadData();
    }
  }, [open]);

  const loadData = async () => {
    try {
      const [agentsRes, pipelinesRes] = await Promise.all([
        api.functions.invoke('listAgents'),
        api.functions.invoke('listPipelines'),
      ]);
      setAgents(agentsRes.data?.agents || []);
      setPipelines(pipelinesRes.data?.pipelines || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handleFileChange = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    setFile(f);
    setParseError('');
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const wb = XLSX.read(evt.target.result, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws, { defval: '' });
        setRows(data);
        // Auto-map fields
        const headers = data.length > 0 ? Object.keys(data[0]) : [];
        const autoMap = {};
        const normalize = s => s.toLowerCase().replace(/[\s_-]+/g, '_');
        PROSPECT_FIELDS.forEach(field => {
          const match = headers.find(h => normalize(h) === field.key || normalize(h).includes(field.key.split('_')[0]));
          if (match) autoMap[field.key] = match;
        });
        setMapping(autoMap);
      } catch (err) {
        setParseError('No se pudo leer el archivo.');
        setRows([]);
      }
    };
    reader.readAsArrayBuffer(f);
  };

  const handleMappingChange = (fieldKey, colName) => {
    setMapping(prev => ({ ...prev, [fieldKey]: colName }));
  };

  const handleOptionsChange = (key, value) => {
    setOptions(prev => ({ ...prev, [key]: value }));
  };

  const BATCH_SIZE = 10;

  const handleImport = async () => {
    setLoading(true);
    setProgress({ current: 0, total: rows.length });

    const selectedAgentIds = options.agent_ids || [];
    const selectedAgents = agents.filter(a => selectedAgentIds.includes(a.id));
    const selectedPipeline = pipelines.find(p => p.id === options.pipeline_id);

    const importOptions = {
      ...options,
      pipeline_name: selectedPipeline?.name || '',
      agent_ids: selectedAgents.map(a => a.id),
      agent_names: selectedAgents.map(a => a.full_name),
      agent_id: selectedAgents[0]?.id || '',
      agent_name: selectedAgents[0]?.full_name || '',
      file_name: file?.name || 'archivo_importado',
    };

    const accumulated = { created: 0, leads_created: 0, skipped: 0, errors: [], failed_rows: [], prospect_ids: [], lead_ids: [] };
    let rrOffset = 0;

    try {
      const totalBatches = Math.ceil(rows.length / BATCH_SIZE);

      for (let i = 0; i < rows.length; i += BATCH_SIZE) {
        const batch = rows.slice(i, i + BATCH_SIZE);
        const batchIndex = Math.floor(i / BATCH_SIZE);
        const isLastBatch = batchIndex === totalBatches - 1;

        const res = await api.functions.invoke('importProspects', {
          rows: batch,
          mapping,
          options: {
            ...importOptions,
            skip_history: true, // history is now saved by frontend after all batches
            rr_offset: rrOffset,
            accumulated_created: accumulated.created,
            accumulated_leads: accumulated.leads_created,
            accumulated_prospect_ids: accumulated.prospect_ids,
            accumulated_lead_ids: accumulated.lead_ids,
          }
        });

        if (res.data) {
          accumulated.created += res.data.created || 0;
          accumulated.leads_created += res.data.leads_created || 0;
          accumulated.skipped += res.data.skipped || 0;
          accumulated.errors.push(...(res.data.errors || []));
          accumulated.failed_rows.push(...(res.data.failed_rows || []));
          accumulated.prospect_ids.push(...(res.data.prospect_ids || []));
          accumulated.lead_ids.push(...(res.data.lead_ids || []));
          rrOffset = res.data.rr_offset ?? (rrOffset + batch.length);
        }

        setProgress({ current: Math.min(i + BATCH_SIZE, rows.length), total: rows.length });
        // 1 second delay between batches to avoid rate limit
        if (i + BATCH_SIZE < rows.length) {
          await new Promise(r => setTimeout(r, 1000));
        }
      }

      // Save import history from frontend (always, after all batches complete)
      try {
        const selectedPipelineForHistory = pipelines.find(p => p.id === importOptions.pipeline_id);
        const selectedAgentsForHistory = agents.filter(a => (importOptions.agent_ids || []).includes(a.id));
        const status = accumulated.errors.length === 0 ? 'success' : (accumulated.created > 0 ? 'partial' : 'failed');
        const currentUser = await api.auth.me();
        await api.entities.ImportHistory.create({
          file_name: file?.name || 'archivo_importado',
          imported_by_id: currentUser?.id || '',
          imported_by_name: currentUser?.full_name || currentUser?.email || '',
          prospects_created: accumulated.created,
          leads_created: accumulated.leads_created,
          skipped: accumulated.skipped,
          errors_count: accumulated.errors.length,
          status,
          prospect_ids: accumulated.prospect_ids,
          lead_ids: accumulated.lead_ids,
          assigned_agent_ids: selectedAgentsForHistory.map(a => a.id),
          assigned_agent_names: selectedAgentsForHistory.map(a => a.full_name),
          pipeline_name: selectedPipelineForHistory?.name || '',
          reverted: false,
        });
      } catch (histErr) {
        console.error('Error guardando historial:', histErr);
      }

      setResult(accumulated);
      setFailedRows(accumulated.failed_rows || []);
      if (accumulated.created > 0) {
        toast.success(`${accumulated.created} prospectos importados`);
      }
      setStep(5);
    } catch (err) {
      toast.error('Error al importar: ' + err.message);
    } finally {
      setLoading(false);
      setProgress({ current: 0, total: 0 });
    }
  };

  const handleRetryFailed = () => {
    // Reset to confirmation step with only the failed rows
    setRows(failedRows);
    setFailedRows([]);
    setResult(null);
    setStep(4);
  };

  const handleClose = (notifyImported = false) => {
    if (notifyImported) onImported?.();
    setStep(1); setFile(null); setRows([]); setParseError('');
    setMapping({}); setOptions({ create_leads: false, agent_ids: [] }); setResult(null);
    setFailedRows([]);
    onClose();
  };

  const headers = rows.length > 0 ? Object.keys(rows[0]) : [];
  const canProceedStep1 = rows.length > 0 && !parseError;
  const canProceedStep2 = !!mapping.full_name;
  const canProceedStep3 = (options.agent_ids || []).length > 0 &&
    (!options.create_leads || (options.pipeline_id && options.pipeline_stage && options.branch));

  const STEPS = ['Archivo', 'Mapear campos', 'Asignación', 'Confirmar', 'Resultado'];

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="w-[calc(100vw-2rem)] max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl p-0">
        <DialogHeader className="px-6 pt-6 pb-0">
          <DialogTitle className="flex items-center gap-2 text-base">
            <FileSpreadsheet className="h-5 w-5 text-emerald-600" />
            Importar Prospectos desde Excel
          </DialogTitle>
          {/* Step indicator */}
          <div className="flex items-center gap-1 mt-3">
            {STEPS.map((s, i) => (
              <React.Fragment key={i}>
                <div className={`flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-full transition-all ${
                  step === i + 1 ? 'bg-brand text-white' :
                  step > i + 1 ? 'bg-emerald-100 text-emerald-700' :
                  'bg-slate-100 text-slate-400'
                }`}>
                  {step > i + 1 ? <Check className="h-3 w-3" /> : <span>{i + 1}</span>}
                  <span className="hidden sm:inline">{s}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`h-px flex-1 ${step > i + 1 ? 'bg-emerald-300' : 'bg-slate-200'}`} />}
              </React.Fragment>
            ))}
          </div>
        </DialogHeader>

        <div className="px-6 py-4 min-h-[280px]">
          {step === 1 && (
            <StepUpload
              file={file} rows={rows} parseError={parseError}
              onFile={handleFileChange}
              onClear={() => { setFile(null); setRows([]); setMapping({}); }}
            />
          )}
          {step === 2 && <StepMapping headers={headers} mapping={mapping} onChange={handleMappingChange} />}
          {step === 3 && <StepOptions agents={agents} pipelines={pipelines} options={options} onChange={handleOptionsChange} />}
          {step === 4 && <StepConfirm rows={rows} mapping={mapping} options={options} agents={agents} pipelines={pipelines} />}
          {step === 5 && result && <StepResult result={result} failedRows={failedRows} onRetry={handleRetryFailed} />}
        </div>

        <div className="px-6 pb-6 flex justify-between gap-2 border-t border-border pt-4">
          {/* Left button */}
          {step < 4 && step > 1 && (
            <Button variant="outline" onClick={() => setStep(s => s - 1)}>
              <ArrowLeft className="h-4 w-4 mr-1" /> Atrás
            </Button>
          )}
          {step === 1 && (
            <Button variant="outline" onClick={() => handleClose(false)}>Cancelar</Button>
          )}
          {step === 4 && (
            <Button variant="outline" onClick={() => setStep(3)}>
              <ArrowLeft className="h-4 w-4 mr-1" /> Atrás
            </Button>
          )}
          {step === 5 && (
            <Button className="bg-brand hover:bg-brand-dark" onClick={() => handleClose(true)}>
              Cerrar y actualizar
            </Button>
          )}

          {/* Right button */}
          {step === 1 && (
            <Button onClick={() => setStep(2)} disabled={!canProceedStep1} className="bg-brand hover:bg-brand-dark gap-1">
              Siguiente <ArrowRight className="h-4 w-4" />
            </Button>
          )}
          {step === 2 && (
            <Button onClick={() => setStep(3)} disabled={!canProceedStep2} className="bg-brand hover:bg-brand-dark gap-1">
              Siguiente <ArrowRight className="h-4 w-4" />
            </Button>
          )}
          {step === 3 && (
            <Button onClick={() => setStep(4)} disabled={!canProceedStep3} className="bg-brand hover:bg-brand-dark gap-1">
              Revisar <ArrowRight className="h-4 w-4" />
            </Button>
          )}
          {step === 4 && (
            <div className="flex flex-col items-end gap-1.5">
              {loading && progress.total > 0 && (
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span>{progress.current} / {progress.total} prospectos guardados</span>
                  <div className="w-32 h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                      style={{ width: `${Math.round((progress.current / progress.total) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
              <Button onClick={handleImport} disabled={loading} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {loading ? 'Importando...' : `Confirmar e importar ${rows.length} prospectos`}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}