import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Plus, Trash2, GripVertical, Loader2, Check, Users, Globe } from "lucide-react";

const STAGE_COLORS = ['#64748b', '#2F4F9D', '#8b5cf6', '#f59e0b', '#10b981', '#ef4444', '#ec4899', '#06b6d4'];
const PIPELINE_COLORS = ['#2F4F9D', '#8b5cf6', '#10b981', '#f59e0b', '#ec4899', '#06b6d4', '#ef4444', '#f97316'];

export default function PipelineEditor({ pipeline, onSave, onClose }) {
  const isNew = !pipeline?.id;

  const [name, setName] = useState(pipeline?.name || '');
  const [description, setDescription] = useState(pipeline?.description || '');
  const [color, setColor] = useState(pipeline?.color || '#2F4F9D');
  const [stages, setStages] = useState(
    pipeline?.stages || [
      { key: 'NUEVO', label: 'Nuevo', color: '#64748b', is_won: false, is_lost: false },
      { key: 'CONTACTADO', label: 'Contactado', color: '#2F4F9D', is_won: false, is_lost: false },
      { key: 'GANADO', label: 'Ganado', color: '#10b981', is_won: true, is_lost: false },
      { key: 'PERDIDO', label: 'Perdido', color: '#ef4444', is_won: false, is_lost: true },
    ]
  );
  const [visibilityType, setVisibilityType] = useState(pipeline?.visibility_type || 'all');
  const [allowedAgentIds, setAllowedAgentIds] = useState(pipeline?.allowed_agent_ids || []);
  const [agents, setAgents] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.functions.invoke('listAgents').then(res => setAgents(res.data?.agents || [])).catch(() => {});
  }, []);

  const addStage = () => {
    setStages([...stages, {
      key: `ETAPA_${Date.now()}`,
      label: 'Nueva Etapa',
      color: '#64748b',
      is_won: false,
      is_lost: false
    }]);
  };

  const removeStage = (idx) => {
    setStages(stages.filter((_, i) => i !== idx));
  };

  const updateStage = (idx, field, value) => {
    setStages(stages.map((s, i) => {
      if (i !== idx) return s;
      const updated = { ...s, [field]: value };
      if (field === 'label') {
        updated.key = value.toUpperCase().replace(/\s+/g, '_').replace(/[^A-Z0-9_]/g, '');
      }
      if (field === 'is_won' && value) updated.is_lost = false;
      if (field === 'is_lost' && value) updated.is_won = false;
      return updated;
    }));
  };

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      const data = { name: name.trim(), description, color, stages, is_active: true, visibility_type: visibilityType, allowed_agent_ids: visibilityType === 'specific_agents' ? allowedAgentIds : [] };
      if (isNew) {
        await api.entities.Pipeline.create(data);
      } else {
        await api.entities.Pipeline.update(pipeline.id, data);
      }
      onSave();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isNew ? 'Nuevo Pipeline' : `Editar Pipeline: ${pipeline.name}`}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>Nombre del Pipeline *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="ej: B2B, B2C, Corporativo..." />
            </div>
            <div className="col-span-2">
              <Label>Descripción</Label>
              <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Descripción opcional" />
            </div>
          </div>

          {/* Color */}
          <div>
            <Label>Color del Pipeline</Label>
            <div className="flex gap-2 mt-2 flex-wrap">
              {PIPELINE_COLORS.map(c => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className="w-8 h-8 rounded-full border-2 transition-all"
                  style={{
                    backgroundColor: c,
                    borderColor: color === c ? 'white' : 'transparent',
                    transform: color === c ? 'scale(1.2)' : 'scale(1)'
                  }}
                />
              ))}
            </div>
          </div>

          {/* Visibility */}
          <div className="space-y-3">
            <Label>Visibilidad del Pipeline</Label>
            <div className="flex gap-3">
              <button
                onClick={() => setVisibilityType('all')}
                className={`flex-1 flex items-center gap-2 p-3 rounded-lg border-2 transition-all text-left ${visibilityType === 'all' ? 'border-brand bg-brand/10 dark:bg-brand/20' : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300 dark:hover:border-zinc-600'}`}
              >
                <Globe className={`h-4 w-4 flex-shrink-0 ${visibilityType === 'all' ? 'text-brand' : 'text-slate-400 dark:text-zinc-500'}`} />
                <div>
                  <p className={`text-sm font-medium ${visibilityType === 'all' ? 'text-brand' : 'text-slate-700 dark:text-zinc-300'}`}>Todos los agentes</p>
                  <p className="text-xs text-slate-400 dark:text-zinc-500">Visible para todos</p>
                </div>
              </button>
              <button
                onClick={() => setVisibilityType('specific_agents')}
                className={`flex-1 flex items-center gap-2 p-3 rounded-lg border-2 transition-all text-left ${visibilityType === 'specific_agents' ? 'border-brand bg-brand/10 dark:bg-brand/20' : 'border-slate-200 dark:border-zinc-700 hover:border-slate-300 dark:hover:border-zinc-600'}`}
              >
                <Users className={`h-4 w-4 flex-shrink-0 ${visibilityType === 'specific_agents' ? 'text-brand' : 'text-slate-400 dark:text-zinc-500'}`} />
                <div>
                  <p className={`text-sm font-medium ${visibilityType === 'specific_agents' ? 'text-brand' : 'text-slate-700 dark:text-zinc-300'}`}>Agentes específicos</p>
                  <p className="text-xs text-slate-400 dark:text-zinc-500">Solo los seleccionados</p>
                </div>
              </button>
            </div>

            {visibilityType === 'specific_agents' && (
              <div className="space-y-2">
                <p className="text-xs text-slate-500 dark:text-zinc-400">Selecciona los agentes que pueden ver este pipeline:</p>
                <div className="max-h-40 overflow-y-auto space-y-1 border dark:border-zinc-700 rounded-lg p-2 bg-slate-50 dark:bg-zinc-800">
                  {agents.map(agent => {
                    const isSelected = allowedAgentIds.includes(agent.id);
                    return (
                      <button
                        key={agent.id}
                        onClick={() => setAllowedAgentIds(isSelected
                          ? allowedAgentIds.filter(id => id !== agent.id)
                          : [...allowedAgentIds, agent.id]
                        )}
                        className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition-colors ${isSelected ? 'bg-brand/15 text-brand dark:bg-brand/25' : 'hover:bg-slate-100 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300'}`}
                      >
                        <div className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 ${isSelected ? 'bg-brand border-brand' : 'border-slate-300 dark:border-zinc-600'}`}>
                          {isSelected && <Check className="h-3 w-3 text-white" />}
                        </div>
                        <span className="truncate">{agent.full_name || agent.email}</span>
                        {agent.crm_role === 'admin_crm' && <Badge className="ml-auto text-xs py-0 bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-400">Admin</Badge>}
                      </button>
                    );
                  })}
                </div>
                {allowedAgentIds.length > 0 && (
                  <p className="text-xs text-brand">{allowedAgentIds.length} agente(s) seleccionado(s)</p>
                )}
              </div>
            )}
          </div>

          {/* Stages */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Etapas del Pipeline</Label>
              <Button size="sm" variant="outline" onClick={addStage} className="gap-1">
                <Plus className="h-3 w-3" /> Agregar Etapa
              </Button>
            </div>

            <div className="space-y-2">
              {stages.map((stage, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 dark:bg-zinc-800 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <GripVertical className="h-4 w-4 text-slate-300 dark:text-zinc-500 flex-shrink-0" />

                  {/* Stage color */}
                  <div className="flex gap-1">
                    {STAGE_COLORS.map(c => (
                      <button
                        key={c}
                        onClick={() => updateStage(idx, 'color', c)}
                        className="w-4 h-4 rounded-full transition-all"
                        style={{
                          backgroundColor: c,
                          outline: stage.color === c ? '2px solid white' : '2px solid transparent',
                          outlineOffset: '1px'
                        }}
                      />
                    ))}
                  </div>

                  <Input
                    value={stage.label}
                    onChange={(e) => updateStage(idx, 'label', e.target.value)}
                    className="flex-1 h-8 text-sm bg-white dark:bg-zinc-900 dark:text-white dark:border-zinc-600 dark:placeholder:text-zinc-500"
                    placeholder="Nombre de la etapa"
                  />

                  <button
                    onClick={() => updateStage(idx, 'is_won', !stage.is_won)}
                    title="Etapa de ganado"
                    className={`px-2 py-1 rounded text-xs font-medium transition-colors ${stage.is_won ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400' : 'bg-slate-100 text-slate-400 dark:bg-zinc-700 dark:text-zinc-400'}`}
                  >
                    ✓ Ganado
                  </button>
                  <button
                    onClick={() => updateStage(idx, 'is_lost', !stage.is_lost)}
                    title="Etapa de perdido"
                    className={`px-2 py-1 rounded text-xs font-medium transition-colors ${stage.is_lost ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400' : 'bg-slate-100 text-slate-400 dark:bg-zinc-700 dark:text-zinc-400'}`}
                  >
                    ✗ Perdido
                  </button>

                  <button onClick={() => removeStage(idx)} className="text-slate-400 dark:text-zinc-500 hover:text-red-500 dark:hover:text-red-400 transition-colors">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving || !name.trim()}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isNew ? 'Crear Pipeline' : 'Guardar Cambios'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}