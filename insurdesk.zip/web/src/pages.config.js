/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AdminPanel from './pages/AdminPanel';
import AgentCommissions from './pages/AgentCommissions';
import AgentDashboard from './pages/AgentDashboard';
import AgentProfitability from './pages/AgentProfitability';
import AgentProfitabilityDetail from './pages/AgentProfitabilityDetail';
import AgentStructure from './pages/AgentStructure';
import Agents from './pages/Agents';
import AuditLogs from './pages/AuditLogs';
import Claims from './pages/Claims';
import ClientDetail from './pages/ClientDetail';
import Clients from './pages/Clients';
import CommissionPDFSettings from './pages/CommissionPDFSettings';
import Commissions from './pages/Commissions';
import CustomReports from './pages/CustomReports';
import Dashboard from './pages/Dashboard';
import EmailLog from './pages/EmailLog';
import Endorsements from './pages/Endorsements';
import LeaderboardAgents from './pages/LeaderboardAgents';
import MyTasks from './pages/MyTasks';
import Notifications from './pages/Notifications';
import Payments from './pages/Payments';
import CrmSettings from './pages/CrmSettings';
import PlanSettings from './pages/PlanSettings';
import Policies from './pages/Policies';
import PolicyDetail from './pages/PolicyDetail';
import PolicyImport from './pages/PolicyImport';
import Renewals from './pages/Renewals';
import Reports from './pages/Reports';
import SalesTargets from './pages/SalesTargets';
import Settings from './pages/Settings';
import SettingsBadges from './pages/SettingsBadges';
import SettingsBranches from './pages/SettingsBranches';
import SettingsCommissionTables from './pages/SettingsCommissionTables';
import SettingsCompanies from './pages/SettingsCompanies';
import SettingsLines from './pages/SettingsLines';
import SettingsProducts from './pages/SettingsProducts';
import SystemDataImport from './pages/SystemDataImport';
import TaskManagement from './pages/TaskManagement';
import UserManagement from './pages/UserManagement';
import UserProfile from './pages/UserProfile';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AdminPanel": AdminPanel,
    "AgentCommissions": AgentCommissions,
    "AgentDashboard": AgentDashboard,
    "AgentProfitability": AgentProfitability,
    "AgentProfitabilityDetail": AgentProfitabilityDetail,
    "AgentStructure": AgentStructure,
    "Agents": Agents,
    "AuditLogs": AuditLogs,
    "Claims": Claims,
    "ClientDetail": ClientDetail,
    "Clients": Clients,
    "CommissionPDFSettings": CommissionPDFSettings,
    "Commissions": Commissions,
    "CustomReports": CustomReports,
    "Dashboard": Dashboard,
    "EmailLog": EmailLog,
    "Endorsements": Endorsements,
    "LeaderboardAgents": LeaderboardAgents,
    "MyTasks": MyTasks,
    "Notifications": Notifications,
    "Payments": Payments,
    "CrmSettings": CrmSettings,
    "PlanSettings": PlanSettings,
    "Policies": Policies,
    "PolicyDetail": PolicyDetail,
    "PolicyImport": PolicyImport,
    "Renewals": Renewals,
    "Reports": Reports,
    "SalesTargets": SalesTargets,
    "Settings": Settings,
    "SettingsBadges": SettingsBadges,
    "SettingsBranches": SettingsBranches,
    "SettingsCommissionTables": SettingsCommissionTables,
    "SettingsCompanies": SettingsCompanies,
    "SettingsLines": SettingsLines,
    "SettingsProducts": SettingsProducts,
    "SystemDataImport": SystemDataImport,
    "TaskManagement": TaskManagement,
    "UserManagement": UserManagement,
    "UserProfile": UserProfile,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};