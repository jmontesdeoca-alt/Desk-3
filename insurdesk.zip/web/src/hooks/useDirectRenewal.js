import { api } from '@/api/client';

/**
 * Executes a direct policy renewal:
 * - Creates new active policy
 * - Generates payment schedule
 * - Generates commissions (walk up hierarchy)
 * - Records a confirmed Renewal entry
 * - Marks original policy as 'renovada'
 */
export async function executeDirectRenewal(policy, renewalForm) {
  const newPremium = parseFloat(renewalForm.new_premium);
  const newCommissionable = parseFloat(renewalForm.new_commissionable_premium);
  const frequency = renewalForm.payment_frequency;
  const frequencyMap = { mensual: 12, trimestral: 4, semestral: 2, anual: 1, unico: 1 };
  const installments = frequencyMap[frequency] || 12;
  const installmentAmount = parseFloat((newPremium / installments).toFixed(2));
  const newPolicyNumber = `${policy.policy_number}-R${new Date().getFullYear()}`;

  // 1. Create new active policy
  const newPolicy = await api.entities.Policy.create({
    policy_number: newPolicyNumber,
    policy_category: policy.policy_category,
    issue_date: policy.issue_date || policy.start_date,
    client_id: policy.client_id,
    client_name: policy.client_name,
    contractor_id: policy.contractor_id,
    contractor_name: policy.contractor_name,
    product_id: policy.product_id,
    product_name: policy.product_name,
    company_id: policy.company_id,
    company_name: policy.company_name,
    line_id: policy.line_id,
    line_name: policy.line_name,
    branch_id: policy.branch_id,
    branch_name: policy.branch_name,
    agent_id: policy.agent_id,
    agent_name: policy.agent_name,
    currency: policy.currency,
    annual_premium: newPremium,
    commissionable_premium: newCommissionable,
    payment_frequency: frequency,
    installment_amount: installmentAmount,
    installment_months: policy.installment_months,
    start_date: renewalForm.new_start_date,
    end_date: renewalForm.new_end_date,
    status: 'activa',
    policy_type: 'renovacion',
    country: policy.country,
    insured_amount: policy.insured_amount,
    deductible_1: policy.deductible_1,
    deductible_2: policy.deductible_2,
    sum_insured: policy.sum_insured,
    dependents: policy.dependents,
    vehicle_data: policy.vehicle_data,
    property_data: policy.property_data,
    renewed_from_policy_id: policy.id,
    notes: `Renovación directa de póliza ${policy.policy_number}`
  });

  // 2. Generate payment schedule
  const startDate = new Date(renewalForm.new_start_date + 'T00:00:00');
  for (let i = 0; i < installments; i++) {
    const dueDate = new Date(startDate);
    if (frequency === 'mensual') dueDate.setMonth(dueDate.getMonth() + i);
    else if (frequency === 'trimestral') dueDate.setMonth(dueDate.getMonth() + (i * 3));
    else if (frequency === 'semestral') dueDate.setMonth(dueDate.getMonth() + (i * 6));
    await api.entities.Payment.create({
      policy_id: newPolicy.id,
      policy_number: newPolicyNumber,
      client_name: policy.client_name,
      due_date: dueDate.toISOString().split('T')[0],
      period: dueDate.toLocaleString('es', { month: 'long', year: 'numeric' }),
      amount: installmentAmount,
      currency: policy.currency,
      status: 'pendiente',
      installment_number: i + 1
    });
  }

  // 3. Generate renewal commissions (differential, walk up hierarchy)
  const [agents, assignments, tables] = await Promise.all([
    api.entities.Agent.list(),
    api.entities.AgentCommissionAssignment.list(),
    api.entities.CommissionTable.list()
  ]);

  const generatedFor = new Set();
  const walkUp = async (agentId, level = 1) => {
    if (!agentId || generatedFor.has(agentId)) return;
    const agent = agents.find(a => a.id === agentId);
    if (!agent) return;

    const assignment = assignments.find(a =>
      a.agent_id === agentId && a.company_id === policy.company_id && a.line_id === policy.line_id
    );
    if (assignment) {
      const table = tables.find(t => t.id === assignment.commission_table_id);
      if (table) {
        const productComm = table.product_commissions?.find(pc => pc.product_id === policy.product_id);
        if (productComm && productComm.renewal_percentage > 0) {
          let commissionPct = productComm.renewal_percentage;
          // Differential: subtract downline commission
          const downlineAssignment = assignments.find(a2 => {
            const ag = agents.find(ag2 => ag2.id === a2.agent_id && ag2.upline_agent_id === agentId);
            return ag && a2.company_id === policy.company_id && a2.line_id === policy.line_id;
          });
          if (downlineAssignment) {
            const dlTable = tables.find(t => t.id === downlineAssignment.commission_table_id);
            if (dlTable) {
              const dlPc = dlTable.product_commissions?.find(pc => pc.product_id === policy.product_id);
              if (dlPc) commissionPct = Math.max(0, commissionPct - dlPc.renewal_percentage);
            }
          }
          if (commissionPct > 0) {
            await api.entities.Commission.create({
              policy_id: newPolicy.id,
              policy_number: newPolicyNumber,
              product_id: policy.product_id,
              product_name: policy.product_name,
              company_id: policy.company_id,
              company_name: policy.company_name,
              agent_id: agentId,
              agent_name: agent.name,
              client_name: policy.client_name,
              level,
              base_amount: newCommissionable,
              commission_pct: commissionPct,
              commission_amount: parseFloat((newCommissionable * commissionPct / 100).toFixed(2)),
              currency: policy.currency,
              generation_date: new Date().toISOString().split('T')[0],
              status: 'pendiente_liberar',
              source_type: 'renovacion'
            });
            generatedFor.add(agentId);
          }
        }
      }
    }
    if (agent.upline_agent_id) await walkUp(agent.upline_agent_id, level + 1);
  };
  await walkUp(policy.agent_id);

  // 4. Record confirmed renewal
  await api.entities.Renewal.create({
    original_policy_id: policy.id,
    original_policy_number: policy.policy_number,
    new_policy_id: newPolicy.id,
    client_name: policy.client_name,
    product_name: policy.product_name,
    renewal_date: new Date().toISOString().split('T')[0],
    new_start_date: renewalForm.new_start_date,
    new_end_date: renewalForm.new_end_date,
    current_premium: policy.annual_premium,
    new_premium: newPremium,
    new_commissionable_premium: newCommissionable,
    payment_frequency: frequency,
    currency: policy.currency,
    status: 'confirmada'
  });

  // 5. Mark original policy as renewed
  await api.entities.Policy.update(policy.id, { status: 'renovada' });

  return newPolicyNumber;
}