import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import StatusBadge from '@/components/ui/StatusBadge';
import { FileText, ExternalLink, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const statusOrder = { activa: 0, en_riesgo: 1, renovada: 2, vencida: 3, cancelada: 4 };

export default function ClientPoliciesTab({ policies = [] }) {
  const [filter, setFilter] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  const filters = [
    { key: 'all', label: 'Todas', count: policies.length },
    { key: 'activa', label: 'Activas', count: policies.filter(p => p.status === 'activa').length },
    { key: 'vencida', label: 'Vencidas', count: policies.filter(p => p.status === 'vencida').length },
    { key: 'cancelada', label: 'Canceladas', count: policies.filter(p => p.status === 'cancelada').length },
  ];

  const sorted = [...policies].sort((a, b) => (statusOrder[a.status] ?? 9) - (statusOrder[b.status] ?? 9));
  const visible = filter === 'all' ? sorted : sorted.filter(p => p.status === filter);

  const safeDate = (d) => {
    if (!d) return null;
    const dt = new Date(d + (d.includes('T') ? '' : 'T00:00:00'));
    return isNaN(dt.getTime()) ? null : dt;
  };

  if (policies.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground/70">
        <FileText className="h-10 w-10 mx-auto mb-3 opacity-30" />
        <p>No hay pólizas registradas</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter pills */}
      <div className="flex flex-wrap gap-2">
        {filters.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
              filter === f.key
                ? 'bg-brand-strong text-white'
                : 'bg-muted text-muted-foreground hover:bg-secondary'
            }`}
          >
            {f.label} {f.count > 0 && <span className="ml-1 opacity-70">({f.count})</span>}
          </button>
        ))}
      </div>

      {/* Policy cards */}
      <div className="space-y-3">
        {visible.map(policy => {
          const expanded = expandedId === policy.id;
          const startDt = safeDate(policy.start_date);
          const endDt = safeDate(policy.end_date);
          const now = new Date();
          const daysLeft = endDt ? Math.ceil((endDt - now) / (1000 * 60 * 60 * 24)) : null;

          return (
            <div key={policy.id} className="border border-border rounded-lg overflow-hidden bg-card hover:border-input transition-colors">
              <div
                className="flex items-center justify-between p-4 cursor-pointer"
                onClick={() => setExpandedId(expanded ? null : policy.id)}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center shrink-0">
                    <FileText className="h-4 w-4 text-foreground" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-foreground text-sm">{policy.policy_number || '—'}</span>
                      <StatusBadge status={policy.status} />
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{policy.product_name} · {policy.company_name}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0 ml-2">
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-semibold text-foreground">
                      {policy.currency} {policy.annual_premium?.toLocaleString() || '—'}
                    </p>
                    <p className="text-xs text-muted-foreground/70">anual</p>
                  </div>
                  {expanded ? <ChevronUp className="h-4 w-4 text-muted-foreground/70" /> : <ChevronDown className="h-4 w-4 text-muted-foreground/70" />}
                </div>
              </div>

              {expanded && (
                <div className="border-t border-border p-4 bg-muted/40 grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground/70 mb-0.5">Vigencia desde</p>
                    <p className="font-medium">{startDt ? format(startDt, 'dd MMM yyyy', { locale: es }) : '—'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground/70 mb-0.5">Vigencia hasta</p>
                    <p className={`font-medium ${daysLeft !== null && daysLeft <= 30 && daysLeft > 0 ? 'text-orange-600 dark:text-orange-400' : ''}`}>
                      {endDt ? format(endDt, 'dd MMM yyyy', { locale: es }) : '—'}
                      {daysLeft !== null && daysLeft > 0 && daysLeft <= 60 && (
                        <span className="ml-1 text-xs text-orange-500">({daysLeft}d)</span>
                      )}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground/70 mb-0.5">Frecuencia</p>
                    <p className="font-medium capitalize">{policy.payment_frequency || '—'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground/70 mb-0.5">Ramo</p>
                    <p className="font-medium">{policy.line_name || '—'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground/70 mb-0.5">Agente</p>
                    <p className="font-medium">{policy.agent_name || '—'}</p>
                  </div>
                  <div className="flex items-end">
                    <Link to={createPageUrl(`PolicyDetail?id=${policy.id}`)}>
                      <Button size="sm" variant="outline" className="gap-1">
                        <ExternalLink className="h-3.5 w-3.5" /> Ver detalle
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}