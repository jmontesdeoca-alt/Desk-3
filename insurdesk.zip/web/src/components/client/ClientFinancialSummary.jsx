import React from 'react';
import { AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const safeDate = (d) => {
  if (!d) return null;
  const dt = new Date(d.includes('T') ? d : d + 'T00:00:00');
  return isNaN(dt.getTime()) ? null : dt;
};

export default function ClientFinancialSummary({ payments = [], policies = [] }) {
  const pending = payments.filter(p => p.status === 'pendiente');
  const overdue = payments.filter(p => p.status === 'atrasado');
  const paid = payments.filter(p => p.status === 'pagado');

  const currency = policies[0]?.currency || payments[0]?.currency || 'USD';

  const totalPending = pending.reduce((s, p) => s + (p.amount || 0), 0);
  const totalOverdue = overdue.reduce((s, p) => s + (p.amount || 0), 0);
  const totalPaid = paid.reduce((s, p) => s + (p.amount || 0), 0);

  // Upcoming payments (next 60 days)
  const now = new Date();
  const upcoming = pending
    .filter(p => {
      const d = safeDate(p.due_date);
      return d && d >= now;
    })
    .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
    .slice(0, 5);

  const statCards = [
    { label: 'Pagado (total)', value: totalPaid, icon: CheckCircle, color: 'text-green-600 dark:text-green-400', bg: 'bg-green-500/10' },
    { label: 'Pendiente', value: totalPending, icon: Clock, color: 'text-foreground', bg: 'bg-muted' },
    { label: 'Vencido', value: totalOverdue, icon: AlertCircle, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-500/10' },
  ];

  if (payments.length === 0) {
    return (
      <div className="text-center py-10 text-muted-foreground/70 text-sm">
        Sin movimientos financieros registrados
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        {statCards.map(s => {
          const Icon = s.icon;
          return (
            <div key={s.label} className={`rounded-xl p-3 ${s.bg}`}>
              <div className="flex items-center gap-1.5 mb-1">
                <Icon className={`h-3.5 w-3.5 ${s.color}`} />
                <span className="text-xs text-muted-foreground">{s.label}</span>
              </div>
              <p className={`text-base font-bold ${s.color}`}>
                {currency} {s.value.toLocaleString()}
              </p>
            </div>
          );
        })}
      </div>

      {/* Overdue alert */}
      {overdue.length > 0 && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-100">
          <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
          <div className="text-sm text-red-600 dark:text-red-400">
            <span className="font-medium">{overdue.length} cuota(s) vencida(s)</span>
            {' '}por {currency} {totalOverdue.toLocaleString()}
          </div>
        </div>
      )}

      {/* Upcoming payments */}
      {upcoming.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Próximos vencimientos</h4>
          <div className="space-y-2">
            {upcoming.map(pay => {
              const dt = safeDate(pay.due_date);
              const daysLeft = dt ? Math.ceil((dt - now) / (1000 * 60 * 60 * 24)) : null;
              return (
                <div key={pay.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="text-sm font-medium text-foreground/80">{pay.policy_number || '—'}</p>
                    <p className="text-xs text-muted-foreground/70">{dt ? format(dt, 'dd MMM yyyy', { locale: es }) : '—'}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-foreground">{pay.currency} {pay.amount?.toLocaleString()}</p>
                    {daysLeft !== null && (
                      <p className={`text-xs ${daysLeft <= 7 ? 'text-red-500' : daysLeft <= 30 ? 'text-orange-500' : 'text-muted-foreground/70'}`}>
                        en {daysLeft}d
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}