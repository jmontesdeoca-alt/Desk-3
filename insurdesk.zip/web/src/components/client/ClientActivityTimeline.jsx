import React from 'react';
import { FileText, DollarSign, AlertTriangle, RefreshCw, Shield, UserPlus } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const safeDate = (d) => {
  if (!d) return null;
  const dt = new Date(d.includes('T') ? d : d + 'T00:00:00');
  return isNaN(dt.getTime()) ? null : dt;
};

const eventConfig = {
  policy_created: { icon: FileText, color: 'bg-muted text-foreground', label: 'Póliza creada' },
  policy_renewed: { icon: RefreshCw, color: 'bg-green-500/10 text-green-600 dark:text-green-400', label: 'Póliza renovada' },
  policy_cancelled: { icon: AlertTriangle, color: 'bg-red-500/10 text-red-600 dark:text-red-400', label: 'Póliza cancelada' },
  policy_expired: { icon: AlertTriangle, color: 'bg-orange-500/10 text-orange-600 dark:text-orange-400', label: 'Póliza vencida' },
  payment_made: { icon: DollarSign, color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400', label: 'Pago registrado' },
  claim_opened: { icon: Shield, color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400', label: 'Siniestro abierto' },
  client_created: { icon: UserPlus, color: 'bg-muted text-muted-foreground', label: 'Cliente registrado' },
};

export default function ClientActivityTimeline({ policies = [], payments = [], claims = [], clientCreatedDate }) {
  // Build timeline events
  const events = [];

  if (clientCreatedDate) {
    const dt = safeDate(clientCreatedDate);
    if (dt) events.push({ type: 'client_created', date: dt, description: 'Cliente registrado en el sistema' });
  }

  policies.forEach(p => {
    const created = safeDate(p.created_date);
    if (created) {
      events.push({
        type: p.policy_type === 'renovacion' ? 'policy_renewed' : 'policy_created',
        date: created,
        description: `${p.policy_number || 'Póliza'} - ${p.product_name || ''}`,
        sub: p.company_name,
      });
    }
    if (p.status === 'cancelada') {
      const upd = safeDate(p.updated_date);
      if (upd) events.push({ type: 'policy_cancelled', date: upd, description: `${p.policy_number || 'Póliza'} cancelada` });
    }
    if (p.status === 'vencida') {
      const end = safeDate(p.end_date);
      if (end) events.push({ type: 'policy_expired', date: end, description: `${p.policy_number || 'Póliza'} vencida` });
    }
  });

  payments.forEach(pay => {
    const dt = safeDate(pay.payment_date || pay.due_date);
    if (dt && pay.status === 'pagado') {
      events.push({
        type: 'payment_made',
        date: dt,
        description: `Pago ${pay.currency || ''} ${pay.amount?.toLocaleString() || ''}`,
        sub: pay.policy_number,
      });
    }
  });

  claims.forEach(c => {
    const dt = safeDate(c.event_date || c.created_date);
    if (dt) {
      events.push({
        type: 'claim_opened',
        date: dt,
        description: `Siniestro: ${c.claim_type || 'Sin tipo'}`,
        sub: c.policy_number,
      });
    }
  });

  // Sort by date desc
  events.sort((a, b) => b.date - a.date);
  const recent = events.slice(0, 20);

  if (recent.length === 0) {
    return (
      <div className="text-center py-10 text-muted-foreground/70 text-sm">
        Sin actividad registrada
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute left-5 top-0 bottom-0 w-px bg-secondary" />
      <div className="space-y-4">
        {recent.map((ev, i) => {
          const cfg = eventConfig[ev.type] || eventConfig.policy_created;
          const Icon = cfg.icon;
          return (
            <div key={i} className="flex gap-4 relative">
              <div className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 z-10 ${cfg.color}`}>
                <Icon className="h-4 w-4" />
              </div>
              <div className="flex-1 pb-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">{ev.description}</p>
                    {ev.sub && <p className="text-xs text-muted-foreground/70">{ev.sub}</p>}
                  </div>
                  <span className="text-xs text-muted-foreground/70 shrink-0">
                    {format(ev.date, 'dd MMM yyyy', { locale: es })}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}