import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import StatusBadge from '@/components/ui/StatusBadge';
import { Mail, Phone, MapPin, Calendar, CreditCard, Building2, FileText, Pencil } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function ClientInfoCard({ client, policies = [], onEdit }) {
  const activePolicies = policies.filter(p => p.status === 'activa');
  const totalPremium = activePolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
  const currency = activePolicies[0]?.currency || 'USD';

  return (
    <div className="space-y-4">
      {/* Avatar + Name */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="h-2 bg-gradient-to-r from-brand-mid to-brand" />
        <CardContent className="pt-5 pb-4">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-gradient-to-br from-brand-mid to-brand flex items-center justify-center text-white font-bold text-lg">
                {client.client_type === 'persona'
                  ? (client.first_name?.[0] || '') + (client.last_name?.[0] || '')
                  : (client.company_name?.[0] || '?')}
              </div>
              <div>
                <StatusBadge status={client.status} />
                <p className="text-xs text-muted-foreground/70 mt-1 capitalize">{client.client_type}</p>
              </div>
            </div>
            {onEdit && (
              <Button variant="ghost" size="icon" onClick={onEdit} className="text-muted-foreground/70 hover:text-foreground/80">
                <Pencil className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2 text-muted-foreground">
              <CreditCard className="h-4 w-4 mt-0.5 text-muted-foreground/70 shrink-0" />
              <span className="uppercase tracking-wide font-mono text-xs">{client.document_type?.toUpperCase()} · {client.document_id}</span>
            </div>
            {client.email && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4 text-muted-foreground/70 shrink-0" />
                <span className="truncate">{client.email}</span>
              </div>
            )}
            {client.phone && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4 text-muted-foreground/70 shrink-0" />
                <span>{client.phone}</span>
              </div>
            )}
            {(client.city || client.country) && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4 text-muted-foreground/70 shrink-0" />
                <span>{[client.city, client.country].filter(Boolean).join(', ')}</span>
              </div>
            )}
            {client.birth_date && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="h-4 w-4 text-muted-foreground/70 shrink-0" />
                <span>{format(new Date(client.birth_date + 'T00:00:00'), 'dd MMM yyyy', { locale: es })}</span>
              </div>
            )}
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4 text-slate-300 shrink-0" />
              <span className="text-xs">Alta: {format(new Date(client.created_date), 'dd/MM/yyyy', { locale: es })}</span>
            </div>
          </div>

          {client.notes && (
            <div className="mt-4 pt-3 border-t border-border">
              <p className="text-xs text-muted-foreground italic">{client.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="border-0 shadow-sm p-3">
          <div className="flex items-center gap-2 mb-1">
            <FileText className="h-4 w-4 text-foreground" />
            <span className="text-xs text-muted-foreground">Pólizas activas</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{activePolicies.length}</p>
          <p className="text-xs text-muted-foreground/70">de {policies.length} total</p>
        </Card>
        <Card className="border-0 shadow-sm p-3">
          <div className="flex items-center gap-2 mb-1">
            <Building2 className="h-4 w-4 text-green-500" />
            <span className="text-xs text-muted-foreground">Prima anual</span>
          </div>
          <p className="text-lg font-bold text-foreground">
            {totalPremium > 0 ? `${currency} ${totalPremium.toLocaleString()}` : '—'}
          </p>
          <p className="text-xs text-muted-foreground/70">activas</p>
        </Card>
      </div>
    </div>
  );
}