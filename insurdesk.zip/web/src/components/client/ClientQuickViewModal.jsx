import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Loader2, User, Mail, Phone, MapPin, FileText, Calendar, Shield } from 'lucide-react';
import StatusBadge from '@/components/ui/StatusBadge';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';

export default function ClientQuickViewModal({ clientId, open, onOpenChange }) {
  const [client, setClient] = useState(null);
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (open && clientId) {
      loadClient();
    } else {
      setClient(null);
      setPolicies([]);
      setError(null);
    }
  }, [open, clientId]);

  const loadClient = async () => {
    setLoading(true);
    setError(null);
    const res = await api.functions.invoke('getClientForAgent', { client_id: clientId });
    if (res.data?.client) {
      setClient(res.data.client);
      setPolicies(res.data.policies || []);
    } else {
      setError(res.data?.error || 'Error al cargar cliente');
    }
    setLoading(false);
  };

  const fullName = client
    ? client.client_type === 'empresa'
      ? client.company_name
      : `${client.first_name || ''} ${client.last_name || ''}`.trim()
    : '';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-foreground" />
            Información del Cliente
          </DialogTitle>
        </DialogHeader>

        {loading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-foreground" />
          </div>
        )}

        {error && (
          <div className="text-center py-8 text-red-500">
            <p>{error}</p>
          </div>
        )}

        {client && !loading && (
          <div className="space-y-4">
            {/* Header */}
            <div className="flex items-center gap-3 p-4 bg-muted rounded-lg border border-blue-100">
              <div className="h-12 w-12 rounded-full bg-blue-200 flex items-center justify-center">
                <User className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <p className="text-lg font-bold text-foreground">{fullName}</p>
                <div className="flex gap-2 mt-1">
                  <Badge variant="outline" className="text-xs capitalize">{client.client_type}</Badge>
                  <Badge variant={client.status === 'activo' ? 'default' : 'secondary'} className="text-xs capitalize">
                    {client.status}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Info Grid */}
            <div className="grid grid-cols-1 gap-3">
              {client.document_id && (
                <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                  <FileText className="h-4 w-4 text-muted-foreground/70 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground capitalize">{client.document_type || 'Documento'}</p>
                    <p className="font-medium text-sm">{client.document_id}</p>
                  </div>
                </div>
              )}

              {client.email && (
                <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                  <Mail className="h-4 w-4 text-muted-foreground/70 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="font-medium text-sm">{client.email}</p>
                  </div>
                </div>
              )}

              {client.phone && (
                <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                  <Phone className="h-4 w-4 text-muted-foreground/70 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">Teléfono</p>
                    <p className="font-medium text-sm">{client.phone}</p>
                  </div>
                </div>
              )}

              {(client.country || client.city) && (
                <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                  <MapPin className="h-4 w-4 text-muted-foreground/70 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">Ubicación</p>
                    <p className="font-medium text-sm">{[client.city, client.country].filter(Boolean).join(', ')}</p>
                  </div>
                </div>
              )}

              {client.birth_date && (
                <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                  <Calendar className="h-4 w-4 text-muted-foreground/70 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">Fecha de Nacimiento</p>
                    <p className="font-medium text-sm">
                      {format(new Date(client.birth_date + 'T00:00:00'), 'dd/MM/yyyy')}
                    </p>
                  </div>
                </div>
              )}

              {client.address && (
                <div className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                  <MapPin className="h-4 w-4 text-muted-foreground/70 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground">Dirección</p>
                    <p className="font-medium text-sm">{client.address}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Policies */}
            {policies.length > 0 && (
              <div className="border-t pt-3">
                <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1">
                  <Shield className="h-3 w-3" /> Pólizas ({policies.length})
                </p>
                <div className="space-y-2">
                  {policies.map(p => (
                    <a
                      key={p.id}
                      href={createPageUrl(`PolicyDetail?id=${p.id}`)}
                      className="flex items-center justify-between p-2.5 bg-muted/40 rounded-lg hover:bg-muted border border-transparent hover:border-border transition-colors group"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-foreground group-hover:underline">{p.policy_number}</p>
                        <p className="text-xs text-muted-foreground truncate">{p.product_name} · {p.company_name}</p>
                      </div>
                      <StatusBadge status={p.status} />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}