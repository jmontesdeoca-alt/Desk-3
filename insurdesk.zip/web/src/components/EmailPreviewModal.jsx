import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

export default function EmailPreviewModal({ open, onOpenChange, email }) {
  if (!email) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Vista Previa del Correo</DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4"
            onClick={() => onOpenChange(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="space-y-4">
          {/* Email Header Info */}
          <div className="grid grid-cols-2 gap-4 bg-muted/40 p-4 rounded-lg">
            <div>
              <p className="text-xs font-medium text-muted-foreground">De:</p>
              <p className="text-sm text-foreground">InsurDesk Sistema</p>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground">Para:</p>
              <p className="text-sm text-foreground">{email.recipient_email}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground">Asunto:</p>
              <p className="text-sm text-foreground font-medium">{email.subject}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground">Destinatario:</p>
              <p className="text-sm text-foreground">{email.recipient_name}</p>
            </div>
          </div>

          {/* Email Body Preview */}
          <div className="border border-border rounded-lg overflow-hidden bg-card">
            <iframe
              srcDoc={email.body || '<p style="padding: 20px; color: #666;">No hay contenido para mostrar</p>'}
              className="w-full h-96 border-none"
              style={{ backgroundColor: '#fff' }}
              title="Email Preview"
            />
          </div>

          {/* Error Message if exists */}
          {email.error_message && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
              <p className="text-sm font-medium text-red-600 dark:text-red-400 mb-1">Mensaje de Error:</p>
              <p className="text-sm text-red-600 dark:text-red-400">{email.error_message}</p>
            </div>
          )}

          <div className="flex justify-end pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cerrar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}