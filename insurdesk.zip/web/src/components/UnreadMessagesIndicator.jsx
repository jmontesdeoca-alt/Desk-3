import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';

export default function UnreadMessagesIndicator() {
  const [unreadCount, setUnreadCount] = useState(0);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadUnreadCount();
    const unsubscribe = subscribeToMessages();
    return () => unsubscribe?.();
  }, []);

  const loadUnreadCount = async () => {
    try {
      const [user, messages] = await Promise.all([
        api.auth.me(),
        api.entities.Message.list('-created_date', 200)
      ]);
      
      setCurrentUser(user);
      const unread = messages.filter(msg => 
        !msg.read_by?.includes(user.id) && 
        (msg.recipient_ids?.includes(user.id) || msg.mentioned_ids?.includes(user.id) || !msg.recipient_ids?.length)
      ).length;
      
      setUnreadCount(unread);
    } catch (error) {
      console.error('Error loading unread count:', error);
    }
  };

  const subscribeToMessages = () => {
    try {
      return api.entities.Message.subscribe(() => {
        // Recargar el conteo real cada vez que haya cambios (incluye mark-as-read)
        loadUnreadCount();
      });
    } catch (error) {
      console.error('Error subscribing:', error);
    }
  };

  if (unreadCount === 0) return null;

  return (
    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse font-semibold">
      {unreadCount > 9 ? '9+' : unreadCount}
    </span>
  );
}