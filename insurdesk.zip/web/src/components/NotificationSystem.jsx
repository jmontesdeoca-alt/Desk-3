import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, X, Check, AlertTriangle, CheckCircle, Users, FileText, DollarSign, Shield } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function NotificationSystem({ recipientType = 'admin' }) {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    loadNotifications();
    const interval = setInterval(loadNotifications, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = async () => {
    try {
      const currentUser = await api.auth.me();
      const data = await api.entities.Notification.filter(
        { recipient_type: recipientType },
        '-notification_date',
        50
      );
      setNotifications(data);
    } catch (error) {
      console.error('Error loading notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId) => {
    await api.entities.Notification.update(notificationId, { read: true });
    loadNotifications();
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.read);
    for (const notification of unread) {
      await api.entities.Notification.update(notification.id, { read: true });
    }
    loadNotifications();
  };

  const deleteNotification = async (notificationId) => {
    await api.entities.Notification.delete(notificationId);
    loadNotifications();
  };

  const getIcon = (type) => {
    switch (type) {
      case 'nuevo_usuario': return Users;
      case 'comision_generada': return DollarSign;
      case 'vencimiento_poliza': return FileText;
      case 'pago_vencido': return AlertTriangle;
      case 'siniestro_actualizado': return Shield;
      default: return Bell;
    }
  };

  const getColor = (type) => {
    switch (type) {
      case 'nuevo_usuario': return 'text-foreground bg-muted';
      case 'comision_generada': return 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10';
      case 'vencimiento_poliza': return 'text-amber-600 dark:text-amber-400 bg-amber-500/10';
      case 'pago_vencido': return 'text-red-600 dark:text-red-400 bg-red-500/10';
      case 'siniestro_actualizado': return 'text-purple-600 dark:text-purple-400 bg-purple-500/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;
  const displayNotifications = showAll ? notifications : notifications.slice(0, 5);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-3">
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-brand" />
            Notificaciones
          </CardTitle>
          {unreadCount > 0 && (
            <Badge className="bg-red-500 text-white">{unreadCount}</Badge>
          )}
        </div>
        {unreadCount > 0 && (
          <Button size="sm" variant="outline" onClick={markAllAsRead}>
            <CheckCircle className="h-4 w-4 mr-2" />
            Marcar todas como leídas
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-center text-muted-foreground/70 py-8">Cargando notificaciones...</p>
        ) : notifications.length === 0 ? (
          <p className="text-center text-muted-foreground/70 py-8">No hay notificaciones</p>
        ) : (
          <div className="space-y-3">
            {displayNotifications.map((notification) => {
              const Icon = getIcon(notification.notification_type);
              const colorClass = getColor(notification.notification_type);
              
              return (
                <div 
                  key={notification.id} 
                  className={`p-4 rounded-lg border transition-all ${
                    notification.read 
                      ? 'bg-muted/40 border-border' 
                      : 'bg-card border-brand shadow-sm'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${colorClass}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-foreground">{notification.title}</h4>
                          <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                          <p className="text-xs text-muted-foreground/70 mt-2">
                            {format(new Date(notification.notification_date || notification.created_date), "dd MMM yyyy, HH:mm", { locale: es })}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 ml-3">
                          {!notification.read && (
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => markAsRead(notification.id)}
                              title="Marcar como leída"
                            >
                              <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                            </Button>
                          )}
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            onClick={() => deleteNotification(notification.id)}
                            title="Eliminar"
                          >
                            <X className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            
            {notifications.length > 5 && (
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setShowAll(!showAll)}
              >
                {showAll ? 'Ver menos' : `Ver todas (${notifications.length})`}
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}