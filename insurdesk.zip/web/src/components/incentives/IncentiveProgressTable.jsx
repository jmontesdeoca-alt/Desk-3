import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, TrendingUp, Users, User, BarChart2, Download, FileSpreadsheet, FileText } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import AgentIncentiveDetailModal from './AgentIncentiveDetailModal';

const fmt = (n, currency = 'USD') =>
  new Intl.NumberFormat('es-EC', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n || 0);

function isPolicyParticipant(policy, incentive) {
  const { participants } = incentive;
  // If no participants defined, all policies count (legacy)
  if (!participants || (!participants.companies?.length && !participants.products?.length)) return true;

  const participantCompanyIds = new Set((participants.companies || []).map(c => c.id));
  const participantProductIds = new Set((participants.products || []).map(p => p.id));

  // Company must be in participants
  if (!participantCompanyIds.has(policy.company_id)) return false;

  // If specific products are selected for this company, only those count
  const companyHasProductRestriction = (participants.products || []).some(p => p.company_id === policy.company_id);
  if (companyHasProductRestriction && !participantProductIds.has(policy.product_id)) return false;

  return true;
}

function getEffectiveMultiplier(policy, incentive) {
  const { rules = [], boost_rules = [] } = incentive;

  const companyMultipliers = {};
  const productMultipliers = {};
  rules.forEach(r => {
    if (r.rule_type === 'company') companyMultipliers[r.id] = parseFloat(r.multiplier);
    else productMultipliers[r.id] = parseFloat(r.multiplier);
  });

  // Base multiplier
  let multiplier = 1;
  if (policy.product_id && productMultipliers[policy.product_id] !== undefined) {
    multiplier = productMultipliers[policy.product_id];
  } else if (policy.company_id && companyMultipliers[policy.company_id] !== undefined) {
    multiplier = companyMultipliers[policy.company_id];
  }

  // Add boost rules that apply to this policy's issue_date
  boost_rules.forEach(b => {
    if (!b.start_date || !b.end_date || !b.id) return;
    if (policy.issue_date < b.start_date || policy.issue_date > b.end_date) return;
    const additional = parseFloat(b.additional_multiplier || 0);
    if (b.rule_type === 'product' && policy.product_id === b.id) {
      multiplier += additional;
    } else if (b.rule_type === 'company' && policy.company_id === b.id) {
      // Only apply company boost if no product rule already applied
      const hasProductRule = policy.product_id && productMultipliers[policy.product_id] !== undefined;
      if (!hasProductRule) multiplier += additional;
    }
  });

  return multiplier;
}

function calcAgentProgress(agentId, policies, incentive) {
  const { start_date, end_date } = incentive;

  let total = 0;
  policies.forEach(p => {
    if (p.agent_id !== agentId) return;
    if (p.policy_type !== 'nuevo_negocio') return;
    if (!p.issue_date || p.issue_date < start_date || p.issue_date > end_date) return;
    if (p.status === 'cancelada') return;
    if (!isPolicyParticipant(p, incentive)) return;

    const basePremium = parseFloat(p.annual_premium || p.commissionable_premium || 0);
    total += basePremium * getEffectiveMultiplier(p, incentive);
  });

  return total;
}

function calcAgencyProgress(agentId, allAgents, policies, incentive) {
  // Find all agents in the structure (downlines) of this agent
  const getDownlines = (id) => {
    const direct = allAgents.filter(a => a.upline_agent_id === id);
    let all = [id];
    direct.forEach(d => { all = all.concat(getDownlines(d.id)); });
    return all;
  };
  const structureIds = getDownlines(agentId);
  let total = 0;
  structureIds.forEach(id => {
    total += calcAgentProgress(id, policies, incentive);
  });
  return total;
}

function getStageReached(amount, stages) {
  if (!stages || stages.length === 0) return null;
  const sorted = [...stages].sort((a, b) => b.threshold_amount - a.threshold_amount);
  return sorted.find(s => amount >= s.threshold_amount) || null;
}

export default function IncentiveProgressTable({ incentive, restrictToAgentId = null }) {
  const [agents, setAgents] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState('both'); // individual | agency | both
  const [detailAgent, setDetailAgent] = useState(null);
  const [detailViewMode, setDetailViewMode] = useState('individual');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const [ag, pol] = await Promise.all([
        api.entities.Agent.list('name', 500),
        api.entities.Policy.list('-start_date', 2000)
      ]);
      setAgents(ag);
      setPolicies(pol);
      setLoading(false);
    };
    load();
  }, [incentive.id]);

  if (loading) return <div className="py-12 text-center text-muted-foreground">Calculando cumplimiento...</div>;

  const targetFor = incentive.target_for || ['agent_individual', 'agent_agency'];
  const showIndividual = targetFor.includes('agent_individual') && (viewMode === 'individual' || viewMode === 'both');
  const showAgency = targetFor.includes('agent_agency') && (viewMode === 'agency' || viewMode === 'both');

  // Determine agents that have structure (have downlines)
  const hasDownlines = (id) => agents.some(a => a.upline_agent_id === id);

  // Build downline set for gerencial restriction
  const getAllDownlines = (id) => {
    const direct = agents.filter(a => a.upline_agent_id === id);
    let all = [id];
    direct.forEach(d => { all = all.concat(getAllDownlines(d.id)); });
    return all;
  };
  const allowedAgentIds = restrictToAgentId ? new Set(getAllDownlines(restrictToAgentId)) : null;

  const rows = agents
    .filter(a => a.status === 'activo')
    .filter(a => !allowedAgentIds || allowedAgentIds.has(a.id))
    .filter(a => !search || a.name?.toLowerCase().includes(search.toLowerCase()) || a.alias?.toLowerCase().includes(search.toLowerCase()))
    .map(agent => {
      const individualAmt = showIndividual ? calcAgentProgress(agent.id, policies, incentive) : 0;
      const agencyAmt = (showAgency && hasDownlines(agent.id)) ? calcAgencyProgress(agent.id, agents, policies, incentive) : 0;
      return { agent, individualAmt, agencyAmt, hasStructure: hasDownlines(agent.id) };
    })
    .filter(r => r.individualAmt > 0 || r.agencyAmt > 0)
    .sort((a, b) => {
      const aMax = Math.max(a.individualAmt, a.agencyAmt);
      const bMax = Math.max(b.individualAmt, b.agencyAmt);
      return bMax - aMax;
    });

  const target = parseFloat(incentive.target_amount || 0);
  const stages = (incentive.stages || []).sort((a, b) => a.threshold_amount - b.threshold_amount);

  // ─── Export: reutiliza el array `rows` ya calculado (cero duplicación de cálculo) ──
  const buildExportRows = () => rows.map(({ agent, individualAmt, agencyAmt, hasStructure }, idx) => {
    const indPct = target > 0 ? Math.min(100, (individualAmt / target) * 100) : 0;
    const agPct = target > 0 ? Math.min(100, (agencyAmt / target) * 100) : 0;
    const stageInd = getStageReached(individualAmt, stages);
    const stageAg = getStageReached(agencyAmt, stages);
    const bestStage = stageAg || stageInd;
    const missing = Math.max(0, target - Math.max(individualAmt, agencyAmt));
    const wonMain = Math.max(individualAmt, agencyAmt) >= target;
    const etapa = wonMain ? 'Meta principal' : bestStage ? bestStage.reward_description : 'Sin etapa aún';
    return {
      '#': idx + 1,
      'Agente / Agencia': agent.name,
      'Tipo': agent.agent_type,
      ...(showIndividual ? { 'Individual': Math.round(individualAmt), 'Individual %': indPct.toFixed(1) + '%' } : {}),
      ...(showAgency ? { 'Agencia': hasStructure ? Math.round(agencyAmt) : '', 'Agencia %': hasStructure ? agPct.toFixed(1) + '%' : '' } : {}),
      'Etapa alcanzada': etapa,
      'Le falta': wonMain ? 0 : Math.round(missing),
      'Estado': wonMain ? 'Cumplido' : 'En progreso'
    };
  });

  const handleExport = (format) => {
    if (rows.length === 0) { toast.error('No hay datos para exportar'); return; }
    const data = buildExportRows();
    const ws = XLSX.utils.json_to_sheet(data);
    // Anchos de columna automáticos
    const colWidths = Object.keys(data[0] || {}).map(k => ({ wch: Math.max(k.length, 14) }));
    ws['!cols'] = colWidths;
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Cumplimiento');
    const safeName = incentive.name.replace(/[^\w\s-]/g, '').replace(/\s+/g, '_');
    if (format === 'csv') {
      XLSX.writeFile(wb, `cumplimiento_${safeName}.csv`, { bookType: 'csv' });
    } else {
      XLSX.writeFile(wb, `cumplimiento_${safeName}.xlsx`);
    }
    toast.success(`Exportado ${data.length} registro(s) en ${format.toUpperCase()}`);
  };

  return (
    <>
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Buscar agente..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {targetFor.includes('agent_individual') && targetFor.includes('agent_agency') && (
          <div className="flex gap-1">
            <Button size="sm" variant={viewMode === 'both' ? 'default' : 'outline'} onClick={() => setViewMode('both')}><Users className="h-4 w-4 mr-1" />Ambos</Button>
            <Button size="sm" variant={viewMode === 'individual' ? 'default' : 'outline'} onClick={() => setViewMode('individual')}><User className="h-4 w-4 mr-1" />Individual</Button>
            <Button size="sm" variant={viewMode === 'agency' ? 'default' : 'outline'} onClick={() => setViewMode('agency')}><TrendingUp className="h-4 w-4 mr-1" />Agencia</Button>
          </div>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="sm" variant="outline" disabled={loading || rows.length === 0}>
              <Download className="h-4 w-4 mr-1" />Exportar
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleExport('xlsx')}>
              <FileSpreadsheet className="h-4 w-4 mr-2 text-green-600 dark:text-green-400" />Excel (.xlsx)
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport('csv')}>
              <FileText className="h-4 w-4 mr-2 text-foreground" />CSV (.csv)
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Stages legend */}
      {stages.length > 0 && (
        <div className="flex flex-wrap gap-2 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
          <span className="text-xs font-semibold text-amber-600 dark:text-amber-400 mr-1">Etapas:</span>
          {stages.map((s, i) => (
            <Badge key={i} variant="outline" className="text-amber-600 dark:text-amber-400 border-amber-400 text-xs">
              {fmt(s.threshold_amount, incentive.currency)}: {s.reward_description}
            </Badge>
          ))}
          <Badge variant="outline" className="text-green-600 dark:text-green-400 border-green-400 text-xs">
            {fmt(target, incentive.currency)}: META PRINCIPAL
          </Badge>
        </div>
      )}

      {/* Table */}
      <div className="border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted border-b">
              <tr>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">#</th>
                <th className="text-left px-4 py-3 font-semibold text-muted-foreground">Agente / Agencia</th>
                {showIndividual && <th className="text-center px-3 py-3 font-semibold text-foreground">Individual</th>}
                {showAgency && <th className="text-center px-3 py-3 font-semibold text-purple-600 dark:text-purple-400">Agencia</th>}
                <th className="text-center px-3 py-3 font-semibold text-muted-foreground">Etapa alcanzada</th>
                <th className="text-right px-4 py-3 font-semibold text-muted-foreground">Le falta</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-muted-foreground">Sin datos de cumplimiento para este incentivo</td></tr>
              )}
              {rows.map(({ agent, individualAmt, agencyAmt, hasStructure }, idx) => {
                const indPct = target > 0 ? Math.min(100, (individualAmt / target) * 100) : 0;
                const agPct = target > 0 ? Math.min(100, (agencyAmt / target) * 100) : 0;
                const stageInd = getStageReached(individualAmt, stages);
                const stageAg = getStageReached(agencyAmt, stages);
                const bestStage = stageAg || stageInd;
                const bestAmt = Math.max(individualAmt, agencyAmt);
                const missing = Math.max(0, target - bestAmt);
                const wonMain = bestAmt >= target;

                return (
                  <tr key={agent.id} className="border-b hover:bg-muted/40 transition-colors">
                    <td className="px-4 py-3 text-muted-foreground/70 font-medium">{idx + 1}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{agent.name}</div>
                      <div className="flex gap-1 mt-0.5">
                        <Badge variant="outline" className="text-xs capitalize py-0">{agent.agent_type}</Badge>
                        {hasStructure && showAgency && <Badge className="text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30 py-0">Con estructura</Badge>}
                      </div>
                    </td>
                    {showIndividual && (
                      <td className="px-3 py-3 min-w-[160px]">
                        <div className="text-center font-semibold text-foreground">{fmt(individualAmt, incentive.currency)}</div>
                        <Progress value={indPct} className="mt-1 h-2 [&>div]:bg-primary" />
                        <div className="text-center text-xs text-muted-foreground mt-0.5">{indPct.toFixed(1)}%</div>
                      </td>
                    )}
                    {showAgency && (
                      <td className="px-3 py-3 min-w-[160px]">
                        {hasStructure ? (
                          <>
                            <div className="text-center font-semibold text-purple-600 dark:text-purple-400">{fmt(agencyAmt, incentive.currency)}</div>
                            <Progress value={agPct} className="mt-1 h-2 [&>div]:bg-purple-500" />
                            <div className="text-center text-xs text-muted-foreground mt-0.5">{agPct.toFixed(1)}%</div>
                          </>
                        ) : (
                          <div className="text-center text-xs text-muted-foreground/70">—</div>
                        )}
                      </td>
                    )}
                    <td className="px-3 py-3 text-center">
                      {wonMain ? (
                        <Badge className="bg-green-600 text-white text-xs">🏆 Meta principal</Badge>
                      ) : bestStage ? (
                        <Badge className="bg-amber-500 text-white text-xs">🎯 {bestStage.reward_description}</Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground/70">Sin etapa aún</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {wonMain ? (
                        <span className="text-green-600 dark:text-green-400 font-semibold text-xs">✓ Cumplido</span>
                      ) : (
                        <span className="font-medium text-foreground/80">{fmt(missing, incentive.currency)}</span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                     <div className="flex gap-1">
                       {showIndividual && (
                         <Button size="sm" variant="ghost" className="text-foreground hover:text-foreground hover:bg-muted px-2" title="Detalle individual"
                           onClick={() => { setDetailViewMode('individual'); setDetailAgent(agent); }}>
                           <BarChart2 className="h-4 w-4" />
                         </Button>
                       )}
                       {showAgency && hasStructure && (
                         <Button size="sm" variant="ghost" className="text-purple-600 dark:text-purple-400 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-purple-500/10 px-2" title="Detalle estructura"
                           onClick={() => { setDetailViewMode('agency'); setDetailAgent(agent); }}>
                           <Users className="h-4 w-4" />
                         </Button>
                       )}
                     </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    {detailAgent && (
      <AgentIncentiveDetailModal
        open={!!detailAgent}
        onOpenChange={(v) => { if (!v) setDetailAgent(null); }}
        agent={detailAgent}
        policies={policies}
        incentive={incentive}
        allAgents={agents}
        viewMode={detailViewMode}
      />
    )}
    </>
  );
}