import React, { useState, useEffect, useMemo } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, ChevronDown, ChevronRight, Building2, Package, Zap } from 'lucide-react';
import { toast } from 'sonner';

const STEPS = ['Base', 'Participantes', 'Ponderación', 'Boosts'];

export default function IncentiveForm({ open, onOpenChange, incentive, onSave }) {
  const [step, setStep] = useState(0);
  const [companies, setCompanies] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expandedCompanies, setExpandedCompanies] = useState({});

  const emptyForm = {
    name: '', description: '', start_date: '', end_date: '',
    currency: 'USD', target_amount: '', status: 'active',
    target_for: ['agent_individual', 'agent_agency'],
    stages: [],
    // participants: { companies: [{id, name}], products: [{id, name, company_id, company_name}] }
    participants: { companies: [], products: [] },
    rules: [],
    boost_rules: []
  };
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    api.entities.InsuranceCompany.list('name', 200).then(setCompanies).catch(() => {});
    api.entities.Product.list('product_name', 500).then(setProducts).catch(() => {});
  }, []);

  useEffect(() => {
    if (open) {
      setStep(0);
      setExpandedCompanies({});
      setForm(incentive ? {
        ...emptyForm, ...incentive,
        target_for: incentive.target_for || ['agent_individual', 'agent_agency'],
        stages: incentive.stages || [],
        participants: incentive.participants || { companies: [], products: [] },
        rules: incentive.rules || [],
        boost_rules: incentive.boost_rules || []
      } : emptyForm);
    }
  }, [open, incentive]);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  // ─── Step 1: Base ───────────────────────────────────────────────────────────

  const toggleTargetFor = (val) => {
    const cur = form.target_for || [];
    set('target_for', cur.includes(val) ? cur.filter(x => x !== val) : [...cur, val]);
  };

  const addStage = () => set('stages', [...form.stages, { threshold_amount: '', reward_description: '' }]);
  const updateStage = (i, key, val) => {
    const s = [...form.stages];
    s[i] = { ...s[i], [key]: val };
    set('stages', s);
  };
  const removeStage = (i) => set('stages', form.stages.filter((_, idx) => idx !== i));

  // ─── Step 2: Participants ───────────────────────────────────────────────────

  const selectedCompanyIds = useMemo(() => new Set((form.participants.companies || []).map(c => c.id)), [form.participants.companies]);
  const selectedProductIds = useMemo(() => new Set((form.participants.products || []).map(p => p.id)), [form.participants.products]);

  // Products grouped by company
  const productsByCompany = useMemo(() => {
    const map = {};
    products.forEach(p => {
      const key = p.company_id || '_none';
      if (!map[key]) map[key] = [];
      map[key].push(p);
    });
    return map;
  }, [products]);

  const toggleCompany = (company) => {
    const cur = form.participants.companies || [];
    const curProds = form.participants.products || [];
    const compProds = productsByCompany[company.id] || [];

    if (selectedCompanyIds.has(company.id)) {
      // Remove company and all its products
      set('participants', {
        companies: cur.filter(c => c.id !== company.id),
        products: curProds.filter(p => p.company_id !== company.id)
      });
    } else {
      // Add company
      set('participants', {
        companies: [...cur, { id: company.id, name: company.name }],
        products: curProds
      });
    }
  };

  const toggleProduct = (product) => {
    const cur = form.participants.products || [];
    if (selectedProductIds.has(product.id)) {
      set('participants', { ...form.participants, products: cur.filter(p => p.id !== product.id) });
    } else {
      set('participants', {
        ...form.participants,
        products: [...cur, { id: product.id, name: product.product_name, company_id: product.company_id, company_name: product.company_name }]
      });
    }
  };

  const toggleExpandCompany = (id) => setExpandedCompanies(prev => ({ ...prev, [id]: !prev[id] }));

  // ─── Step 3: Rules ──────────────────────────────────────────────────────────

  // Only show participants in rules
  const ruleableCompanies = form.participants.companies || [];
  const ruleableProducts = form.participants.products || [];

  const addRule = () => set('rules', [...form.rules, { rule_type: 'company', id: '', name: '', multiplier: 1 }]);
  const updateRule = (i, key, val) => {
    setForm(f => {
      const r = [...f.rules];
      if (key === 'rule_type') {
        r[i] = { ...r[i], rule_type: val, id: '', name: '' };
      } else if (key === 'entity' && val) {
        const parsed = JSON.parse(val);
        r[i] = { ...r[i], id: parsed.id, name: parsed.name };
      } else {
        r[i] = { ...r[i], [key]: val };
      }
      return { ...f, rules: r };
    });
  };
  const removeRule = (i) => set('rules', form.rules.filter((_, idx) => idx !== i));

  // ─── Step 4: Boost Rules ────────────────────────────────────────────────────

  const addBoost = () => set('boost_rules', [...(form.boost_rules || []), {
    rule_type: 'company', id: '', name: '', additional_multiplier: 0.5,
    start_date: '', end_date: '', label: ''
  }]);
  const updateBoost = (i, key, val) => {
    setForm(f => {
      const b = [...(f.boost_rules || [])];
      if (key === 'rule_type') {
        b[i] = { ...b[i], rule_type: val, id: '', name: '' };
      } else if (key === 'entity' && val) {
        const parsed = JSON.parse(val);
        b[i] = { ...b[i], id: parsed.id, name: parsed.name };
      } else {
        b[i] = { ...b[i], [key]: val };
      }
      return { ...f, boost_rules: b };
    });
  };
  const removeBoost = (i) => set('boost_rules', (form.boost_rules || []).filter((_, idx) => idx !== i));

  // ─── Submit ─────────────────────────────────────────────────────────────────

  const handleSubmit = async () => {
    if (!form.name || !form.start_date || !form.end_date || !form.target_amount) {
      toast.error('Completa los campos obligatorios');
      return;
    }
    setLoading(true);
    try {
      const data = {
        ...form,
        target_amount: parseFloat(form.target_amount),
        stages: form.stages.map(s => ({ ...s, threshold_amount: parseFloat(s.threshold_amount) })),
        rules: form.rules.map(r => ({ ...r, multiplier: parseFloat(r.multiplier) })),
        boost_rules: (form.boost_rules || []).map(b => ({ ...b, additional_multiplier: parseFloat(b.additional_multiplier) }))
      };
      if (incentive?.id) {
        await api.entities.Incentive.update(incentive.id, data);
        toast.success('Incentivo actualizado');
      } else {
        await api.entities.Incentive.create(data);
        toast.success('Incentivo creado');
      }
      onSave();
      onOpenChange(false);
    } catch (e) {
      toast.error('Error al guardar');
    }
    setLoading(false);
  };

  const canGoNext = () => {
    if (step === 0) return !!(form.name && form.start_date && form.end_date && form.target_amount);
    if (step === 1) return selectedCompanyIds.size > 0;
    return true;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{incentive ? 'Editar Incentivo' : 'Nuevo Incentivo'}</DialogTitle>
          {/* Step indicator */}
          <div className="flex items-center gap-0 mt-3">
            {STEPS.map((s, i) => (
              <React.Fragment key={i}>
                <button
                  onClick={() => i < step && setStep(i)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                    i === step ? 'bg-primary text-white' :
                    i < step ? 'bg-muted text-foreground cursor-pointer hover:bg-blue-200' :
                    'bg-muted text-muted-foreground/70 cursor-not-allowed'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                    i === step ? 'bg-card text-foreground' :
                    i < step ? 'bg-blue-700 text-white' : 'bg-muted-foreground/30 text-muted-foreground'
                  }`}>{i + 1}</span>
                  {s}
                </button>
                {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 mx-1 ${i < step ? 'bg-blue-400' : 'bg-secondary'}`} />}
              </React.Fragment>
            ))}
          </div>
        </DialogHeader>

        <div className="space-y-5 py-2">

          {/* ── STEP 0: Base ── */}
          {step === 0 && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1 md:col-span-2">
                  <Label>Nombre *</Label>
                  <Input value={form.name} onChange={e => set('name', e.target.value.toUpperCase())} placeholder="NOMBRE DEL INCENTIVO" />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <Label>Descripción</Label>
                  <Textarea value={form.description} onChange={e => set('description', e.target.value)} rows={2} />
                </div>
                <div className="space-y-1">
                  <Label>Fecha inicio *</Label>
                  <Input type="date" value={form.start_date} onChange={e => set('start_date', e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Fecha fin *</Label>
                  <Input type="date" value={form.end_date} onChange={e => set('end_date', e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Moneda</Label>
                  <Select value={form.currency} onValueChange={v => set('currency', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['USD','COP','MXN','EUR','PEN','CLP','ARS'].map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Monto objetivo principal *</Label>
                  <Input type="number" value={form.target_amount} onChange={e => set('target_amount', e.target.value)} placeholder="100000" />
                </div>
                <div className="space-y-1">
                  <Label>Estado</Label>
                  <Select value={form.status} onValueChange={v => set('status', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Activo</SelectItem>
                      <SelectItem value="pending">Pendiente</SelectItem>
                      <SelectItem value="completed">Completado</SelectItem>
                      <SelectItem value="cancelled">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Califica como</Label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox checked={form.target_for?.includes('agent_individual')} onCheckedChange={() => toggleTargetFor('agent_individual')} />
                      <span className="text-sm">Agente individual</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox checked={form.target_for?.includes('agent_agency')} onCheckedChange={() => toggleTargetFor('agent_agency')} />
                      <span className="text-sm">Agencia</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Stages */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-base font-semibold">Etapas intermedias</Label>
                  <Button variant="outline" size="sm" onClick={addStage}><Plus className="h-4 w-4 mr-1" />Agregar</Button>
                </div>
                {form.stages.length === 0 && <p className="text-sm text-muted-foreground">Sin etapas intermedias</p>}
                <div className="space-y-2">
                  {form.stages.map((s, i) => (
                    <div key={i} className="flex gap-2 items-start p-3 border rounded-lg bg-muted/40">
                      <div className="flex-1">
                        <Input type="number" placeholder="Monto umbral" value={s.threshold_amount} onChange={e => updateStage(i, 'threshold_amount', e.target.value)} />
                      </div>
                      <div className="flex-[2]">
                        <Input placeholder="Descripción del premio (ej: Bono pasajes)" value={s.reward_description} onChange={e => updateStage(i, 'reward_description', e.target.value)} />
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeStage(i)} className="text-red-500 hover:text-red-600 dark:hover:text-red-400 mt-0.5">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* ── STEP 1: Participantes ── */}
          {step === 1 && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Selecciona las compañías que participan en este incentivo. Despliega cada una para elegir productos específicos (si no seleccionas ningún producto, participan <strong>todos</strong> los de esa compañía).
              </p>
              {companies.length === 0 && <p className="text-sm text-muted-foreground">Cargando compañías...</p>}
              <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1">
                {companies.map(company => {
                  const isSelected = selectedCompanyIds.has(company.id);
                  const compProds = productsByCompany[company.id] || [];
                  const isExpanded = expandedCompanies[company.id];
                  const selectedProdsOfCompany = (form.participants.products || []).filter(p => p.company_id === company.id);

                  return (
                    <div key={company.id} className={`border rounded-lg overflow-hidden transition-colors ${isSelected ? 'border-border bg-muted/30' : 'border-border'}`}>
                      {/* Company row */}
                      <div className="flex items-center gap-3 p-3">
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleCompany(company)}
                        />
                        <Building2 className={`h-4 w-4 ${isSelected ? 'text-foreground' : 'text-muted-foreground/70'}`} />
                        <span className={`flex-1 font-medium text-sm ${isSelected ? 'text-foreground' : 'text-foreground/80'}`}>{company.name}</span>
                        {isSelected && selectedProdsOfCompany.length > 0 && (
                          <Badge className="bg-muted text-foreground text-xs border-border">
                            {selectedProdsOfCompany.length} producto{selectedProdsOfCompany.length !== 1 ? 's' : ''}
                          </Badge>
                        )}
                        {isSelected && selectedProdsOfCompany.length === 0 && compProds.length > 0 && (
                          <Badge variant="outline" className="text-xs text-muted-foreground">Todos los productos</Badge>
                        )}
                        {isSelected && compProds.length > 0 && (
                          <button
                            onClick={() => toggleExpandCompany(company.id)}
                            className="text-muted-foreground/70 hover:text-muted-foreground p-1 rounded"
                          >
                            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                          </button>
                        )}
                      </div>

                      {/* Products dropdown */}
                      {isSelected && isExpanded && compProds.length > 0 && (
                        <div className="border-t border-border bg-card px-3 py-2 space-y-1.5">
                          <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                            <Package className="h-3 w-3" />
                            Selecciona productos específicos (opcional):
                          </p>
                          {compProds.map(prod => (
                            <label key={prod.id} className="flex items-center gap-2 cursor-pointer hover:bg-muted/40 rounded px-2 py-1">
                              <Checkbox
                                checked={selectedProductIds.has(prod.id)}
                                onCheckedChange={() => toggleProduct(prod)}
                              />
                              <span className="text-sm text-foreground/80">{prod.product_name}</span>
                              {prod.line_name && <Badge variant="outline" className="text-xs py-0">{prod.line_name}</Badge>}
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              {selectedCompanyIds.size > 0 && (
                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 text-sm text-green-600 dark:text-green-400">
                  ✓ {selectedCompanyIds.size} compañía{selectedCompanyIds.size !== 1 ? 's' : ''} seleccionada{selectedCompanyIds.size !== 1 ? 's' : ''}
                  {selectedProductIds.size > 0 && ` · ${selectedProductIds.size} producto${selectedProductIds.size !== 1 ? 's' : ''} específico${selectedProductIds.size !== 1 ? 's' : ''}`}
                </div>
              )}
            </div>
          )}

          {/* ── STEP 2: Reglas de ponderación ── */}
          {step === 2 && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Asigna multiplicadores a las compañías o productos participantes. Lo que no tenga regla contará al ×1.
              </p>
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={addRule}><Plus className="h-4 w-4 mr-1" />Agregar regla</Button>
              </div>
              {form.rules.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">Sin reglas — todas las compañías/productos participantes cuentan al ×1</p>
              )}
              <div className="space-y-2">
                {form.rules.map((r, i) => (
                  <div key={i} className="flex gap-2 items-center p-3 border rounded-lg bg-muted/40 flex-wrap">
                    <Select value={r.rule_type} onValueChange={v => updateRule(i, 'rule_type', v)}>
                      <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="company">Compañía</SelectItem>
                        <SelectItem value="product">Producto</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select
                      value={r.id ? JSON.stringify({ id: r.id, name: r.name }) : ''}
                      onValueChange={v => updateRule(i, 'entity', v)}
                    >
                      <SelectTrigger className="flex-1 min-w-[180px]">
                        <SelectValue placeholder="Seleccionar..." />
                      </SelectTrigger>
                      <SelectContent>
                        {r.rule_type === 'company'
                          ? ruleableCompanies.map(c => (
                              <SelectItem key={c.id} value={JSON.stringify({ id: c.id, name: c.name })}>{c.name}</SelectItem>
                            ))
                          : ruleableProducts.map(p => (
                              <SelectItem key={p.id} value={JSON.stringify({ id: p.id, name: p.name })}>
                                {p.name}{p.company_name ? ` — ${p.company_name}` : ''}
                              </SelectItem>
                            ))
                        }
                      </SelectContent>
                    </Select>
                    <div className="flex items-center gap-1">
                      <Label className="text-xs whitespace-nowrap">Multiplicador</Label>
                      <Input type="number" step="0.1" min="0" className="w-20" value={r.multiplier} onChange={e => updateRule(i, 'multiplier', e.target.value)} />
                    </div>
                    <Badge variant="outline" className={parseFloat(r.multiplier) > 1 ? 'text-green-600 dark:text-green-400 border-green-500/30' : parseFloat(r.multiplier) < 1 ? 'text-red-600 dark:text-red-400 border-red-500/30' : ''}>
                      {parseFloat(r.multiplier) > 0 ? `×${r.multiplier}` : '—'}
                    </Badge>
                    <Button variant="ghost" size="icon" onClick={() => removeRule(i)} className="text-red-500 hover:text-red-600 dark:hover:text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── STEP 3: Boosts temporales ── */}
          {step === 3 && (
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                <Zap className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <p className="text-sm text-amber-600 dark:text-amber-400">
                  Los <strong>boosts</strong> son multiplicadores adicionales que se suman al multiplicador base durante un período específico. Ejemplo: si una compañía ya tiene ×1.5 base y agregas un boost de +0.5, durante ese período valdrá ×2.
                </p>
              </div>
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={addBoost}>
                  <Zap className="h-4 w-4 mr-1 text-amber-500" />Agregar boost
                </Button>
              </div>
              {(form.boost_rules || []).length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">Sin boosts — puedes agregar varios para diferentes períodos del año</p>
              )}
              <div className="space-y-3">
                {(form.boost_rules || []).map((b, i) => (
                  <div key={i} className="p-3 border-2 border-amber-500/30 rounded-lg bg-amber-50/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4 text-amber-500" />
                        <span className="text-sm font-semibold text-amber-600 dark:text-amber-400">Boost {i + 1}</span>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeBoost(i)} className="text-red-500 hover:text-red-600 dark:hover:text-red-400 h-7 w-7">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs">Nombre del boost (opcional)</Label>
                        <Input placeholder="Ej: Boost mayo-junio" value={b.label} onChange={e => updateBoost(i, 'label', e.target.value)} className="text-sm" />
                      </div>
                      <div className="flex gap-2 items-end">
                        <div className="space-y-1 flex-1">
                          <Label className="text-xs">Aplica a</Label>
                          <Select value={b.rule_type} onValueChange={v => updateBoost(i, 'rule_type', v)}>
                            <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="company">Compañía</SelectItem>
                              <SelectItem value="product">Producto</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1 flex-[2]">
                          <Label className="text-xs">Seleccionar</Label>
                          <Select
                            value={b.id ? JSON.stringify({ id: b.id, name: b.name }) : ''}
                            onValueChange={v => updateBoost(i, 'entity', v)}
                          >
                            <SelectTrigger className="text-sm"><SelectValue placeholder="Seleccionar..." /></SelectTrigger>
                            <SelectContent>
                              {b.rule_type === 'company'
                                ? ruleableCompanies.map(c => (
                                    <SelectItem key={c.id} value={JSON.stringify({ id: c.id, name: c.name })}>{c.name}</SelectItem>
                                  ))
                                : ruleableProducts.map(p => (
                                    <SelectItem key={p.id} value={JSON.stringify({ id: p.id, name: p.name })}>
                                      {p.name}{p.company_name ? ` — ${p.company_name}` : ''}
                                    </SelectItem>
                                  ))
                              }
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Período: Desde</Label>
                        <Input type="date" value={b.start_date} onChange={e => updateBoost(i, 'start_date', e.target.value)} className="text-sm" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Período: Hasta</Label>
                        <Input type="date" value={b.end_date} onChange={e => updateBoost(i, 'end_date', e.target.value)} className="text-sm" />
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <Label className="text-xs">Multiplicador adicional (se suma al base)</Label>
                        <div className="flex items-center gap-2">
                          <Input type="number" step="0.1" min="0.1" className="w-24 text-sm" value={b.additional_multiplier} onChange={e => updateBoost(i, 'additional_multiplier', e.target.value)} />
                          <Badge className="bg-amber-500 text-white border-amber-600">
                            +{b.additional_multiplier} al base
                          </Badge>
                          {b.name && (
                            <span className="text-xs text-amber-600 dark:text-amber-400">
                              → {b.name} tendrá ×{(1 + parseFloat(b.additional_multiplier || 0)).toFixed(1)} si no tiene base, o más si ya tiene ponderación
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex-row justify-between items-center">
          <div>
            {step > 0 && (
              <Button variant="outline" onClick={() => setStep(s => s - 1)}>← Anterior</Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            {step < STEPS.length - 1 ? (
              <Button onClick={() => setStep(s => s + 1)} disabled={!canGoNext()}>
                Siguiente →
              </Button>
            ) : (
              <Button onClick={handleSubmit} disabled={loading}>
                {loading ? 'Guardando...' : 'Guardar'}
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}