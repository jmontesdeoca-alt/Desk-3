import React, { useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';

const fmt = (n, currency = 'USD') =>
  new Intl.NumberFormat('es-EC', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n || 0);

function isPolicyParticipant(policy, incentive) {
  const { participants } = incentive;
  if (!participants || (!participants.companies?.length && !participants.products?.length)) return true;
  const participantCompanyIds = new Set((participants.companies || []).map(c => c.id));
  const participantProductIds = new Set((participants.products || []).map(p => p.id));
  if (!participantCompanyIds.has(policy.company_id)) return false;
  const companyHasProductRestriction = (participants.products || []).some(p => p.company_id === policy.company_id);
  if (companyHasProductRestriction && !participantProductIds.has(policy.product_id)) return false;
  return true;
}

function getFilteredPolicies(agentId, policies, incentive) {
  const { start_date, end_date } = incentive;
  return policies.filter(p =>
    p.agent_id === agentId &&
    p.policy_type === 'nuevo_negocio' &&
    p.issue_date >= start_date &&
    p.issue_date <= end_date &&
    p.status !== 'cancelada' &&
    isPolicyParticipant(p, incentive)
  );
}

function getMultiplier(policy, rules = [], boost_rules = []) {
  // Base multiplier from rules
  const productRule = rules.find(r => r.rule_type === 'product' && r.id === policy.product_id);
  const companyRule = rules.find(r => r.rule_type === 'company' && r.id === policy.company_id);
  let multiplier = productRule ? parseFloat(productRule.multiplier)
    : companyRule ? parseFloat(companyRule.multiplier)
    : 1;

  // Add applicable boosts
  boost_rules.forEach(b => {
    if (!b.start_date || !b.end_date || !b.id) return;
    if (!policy.issue_date || policy.issue_date < b.start_date || policy.issue_date > b.end_date) return;
    const additional = parseFloat(b.additional_multiplier || 0);
    if (b.rule_type === 'product' && policy.product_id === b.id) {
      multiplier += additional;
    } else if (b.rule_type === 'company' && policy.company_id === b.id && !productRule) {
      multiplier += additional;
    }
  });

  return multiplier;
}

function getDownlineIds(agentId, allAgents) {
  const direct = allAgents.filter(a => a.upline_agent_id === agentId);
  let all = [agentId];
  direct.forEach(d => { all = all.concat(getDownlineIds(d.id, allAgents)); });
  return all;
}

export default function AgentIncentiveDetailModal({ open, onOpenChange, agent, policies, incentive, allAgents = [], viewMode = 'individual' }) {
  const isAgency = viewMode === 'agency';

  const agentPolicies = useMemo(() => {
    if (!agent || !incentive) return [];
    if (isAgency && allAgents.length > 0) {
      const structureIds = new Set(getDownlineIds(agent.id, allAgents));
      return policies
        .filter(p => structureIds.has(p.agent_id))
        .filter(p =>
          p.policy_type === 'nuevo_negocio' &&
          p.issue_date >= incentive.start_date &&
          p.issue_date <= incentive.end_date &&
          p.status !== 'cancelada' &&
          isPolicyParticipant(p, incentive)
        );
    }
    return getFilteredPolicies(agent.id, policies, incentive);
  }, [agent?.id, policies, incentive, isAgency, allAgents]);

  // Group by company → then by product
  const byCompany = useMemo(() => {
    if (!agent || !incentive) return [];
    const companyMap = {};
    agentPolicies.forEach(p => {
      const compKey = p.company_id || 'sin_compania';
      const compLabel = p.company_name || 'Sin compañía';
      if (!companyMap[compKey]) companyMap[compKey] = { label: compLabel, basePremium: 0, weightedPremium: 0, count: 0, byProduct: {} };

      const prodKey = p.product_id || 'sin_producto';
      const prodLabel = p.product_name || 'Sin producto';
      if (!companyMap[compKey].byProduct[prodKey]) {
        companyMap[compKey].byProduct[prodKey] = { label: prodLabel, basePremium: 0, weightedPremium: 0, count: 0, policies: [] };
      }

      const base = parseFloat(p.annual_premium || p.commissionable_premium || 0);
      const mult = getMultiplier(p, incentive.rules, incentive.boost_rules || []);
      const weighted = base * mult;

      companyMap[compKey].basePremium += base;
      companyMap[compKey].weightedPremium += weighted;
      companyMap[compKey].count += 1;
      companyMap[compKey].byProduct[prodKey].basePremium += base;
      companyMap[compKey].byProduct[prodKey].weightedPremium += weighted;
      companyMap[compKey].byProduct[prodKey].count += 1;
      companyMap[compKey].byProduct[prodKey].policies.push({ ...p, _base: base, _mult: mult, _weighted: weighted });
    });

    return Object.values(companyMap)
      .map(c => ({ ...c, products: Object.values(c.byProduct).sort((a, b) => b.weightedPremium - a.weightedPremium) }))
      .sort((a, b) => b.weightedPremium - a.weightedPremium);
  }, [agentPolicies, incentive?.rules]);

  if (!agent || !incentive) return null;

  const totalWeighted = byCompany.reduce((s, c) => s + c.weightedPremium, 0);
  const target = parseFloat(incentive.target_amount || 0);
  const pct = target > 0 ? Math.min(100, (totalWeighted / target) * 100) : 0;
  const currency = incentive.currency || 'USD';
  const hasRules = incentive.rules && incentive.rules.length > 0;

  const handlePrint = () => {
    const companiesHtml = byCompany.map(company => {
      const productsHtml = company.products.map(prod => {
        const policiesHtml = prod.policies.map(pol => `
          <div class="policy-row">
            <span>${pol.policy_number || pol.id?.slice(-6) || '—'} &nbsp; ${pol.client_name || '—'}</span>
            <span>${hasRules && pol._mult !== 1 ? `<span class="mult">×${pol._mult}</span> &nbsp;` : ''}${fmt(pol._weighted, currency)}</span>
          </div>
        `).join('');
        return `
          <div class="product-block">
            <div class="product-title">${prod.label} <span style="font-weight:normal;color:#64748b;font-size:11px;">${prod.count} póliza${prod.count !== 1 ? 's' : ''}</span>
              ${hasRules && prod.weightedPremium !== prod.basePremium ? `<span style="float:right;font-size:11px;color:#64748b;">base: ${fmt(prod.basePremium, currency)}</span>` : ''}
              <span style="float:right;font-size:13px;font-weight:bold;color:#1e293b;">${fmt(prod.weightedPremium, currency)}</span>
            </div>
            <div style="padding-left:8px;">${policiesHtml}</div>
          </div>
        `;
      }).join('');
      return `
        <div class="company-block">
          <div class="company-header">
            <span>${company.label} <span class="badge">${company.count} póliza${company.count !== 1 ? 's' : ''}</span></span>
            <span>${fmt(company.weightedPremium, currency)}${hasRules && company.weightedPremium !== company.basePremium ? `<br><span style="font-size:11px;font-weight:normal;color:#64748b;">base: ${fmt(company.basePremium, currency)}</span>` : ''}</span>
          </div>
          ${productsHtml}
        </div>
      `;
    }).join('');

    const win = window.open('', '_blank');
    win.document.write(`
      <html>
        <head>
          <title>Cumplimiento - ${agent.name}</title>
          <style>
            body { font-family: Arial, sans-serif; font-size: 13px; color: #1e293b; padding: 28px; max-width: 760px; margin: 0 auto; }
            h1 { font-size: 20px; margin-bottom: 2px; }
            .subtitle { color: #64748b; font-size: 13px; margin-bottom: 18px; }
            .summary { background: #f1f5f9; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; }
            .summary-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
            .big-amount { font-size: 24px; font-weight: bold; color: #1d4ed8; }
            .progress-bar-bg { background: #e2e8f0; border-radius: 4px; height: 8px; margin: 8px 0 4px; }
            .progress-bar-fill { background: #3b82f6; border-radius: 4px; height: 8px; }
            .progress-labels { display: flex; justify-content: space-between; color: #64748b; font-size: 11px; }
            .company-block { border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 14px; overflow: hidden; }
            .company-header { background: #f1f5f9; padding: 10px 14px; display: flex; justify-content: space-between; font-weight: bold; }
            .product-block { padding: 8px 14px; border-top: 1px solid #f1f5f9; }
            .product-title { color: #1d4ed8; font-size: 12px; font-weight: bold; margin-bottom: 5px; overflow: hidden; }
            .policy-row { display: flex; justify-content: space-between; font-size: 11px; color: #475569; padding: 3px 8px; background: #f8fafc; border-radius: 4px; margin-bottom: 2px; }
            .badge { display: inline-block; background: #dbeafe; color: #1e40af; border-radius: 4px; padding: 1px 7px; font-size: 11px; margin-left: 6px; font-weight: normal; }
            .mult { color: #d97706; font-weight: bold; }
            .footer { margin-top: 24px; color: #94a3b8; font-size: 11px; text-align: right; border-top: 1px solid #e2e8f0; padding-top: 8px; }
            @media print { body { padding: 0; } }
          </style>
        </head>
        <body>
          <h1>${agent.name}</h1>
          <div class="subtitle">${incentive.name} &nbsp;·&nbsp; ${incentive.start_date} al ${incentive.end_date}</div>
          <div class="summary">
            <div class="summary-row">
              <span style="font-size:13px;color:#475569;">Prima ${hasRules ? 'ponderada' : ''} total</span>
              <span class="big-amount">${fmt(totalWeighted, currency)}</span>
            </div>
            <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${pct.toFixed(1)}%"></div></div>
            <div class="progress-labels"><span>${pct.toFixed(1)}% del objetivo</span><span>Meta: ${fmt(target, currency)}</span></div>
          </div>
          <div>${companiesHtml}</div>
          <div class="footer">Generado el ${new Date().toLocaleDateString('es-EC', { day:'2-digit', month:'long', year:'numeric' })}</div>
        </body>
      </html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 400);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-lg">Detalle de cumplimiento — {agent.name}</DialogTitle>
              <p className="text-sm text-muted-foreground">{incentive.name} · {isAgency ? 'Estructura completa' : 'Individual'}</p>
            </div>
            <Button variant="outline" size="sm" onClick={handlePrint} className="ml-4 shrink-0 gap-1.5">
              <Printer className="h-4 w-4" />
              Imprimir PDF
            </Button>
          </div>
        </DialogHeader>

        <div id="incentive-detail-print">
        {/* Summary */}
        <div className="bg-muted/40 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-muted-foreground">Prima {hasRules ? 'ponderada' : ''} total</span>
            <span className="text-xl font-bold text-foreground">{fmt(totalWeighted, currency)}</span>
          </div>
          <Progress value={pct} className="h-3 [&>div]:bg-primary" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{pct.toFixed(1)}% del objetivo</span>
            <span>Meta: {fmt(target, currency)}</span>
          </div>
        </div>

        {/* Breakdown by company */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-foreground/80">Desglose por compañía</h3>
          {byCompany.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">Sin pólizas en el período</p>
          )}
          {byCompany.map((company, i) => {
            const compPct = totalWeighted > 0 ? (company.weightedPremium / totalWeighted) * 100 : 0;
            return (
              <div key={i} className="border rounded-lg overflow-hidden">
                {/* Company header */}
                <div className="flex justify-between items-center bg-muted px-4 py-2.5">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-foreground">{company.label}</span>
                    <Badge variant="outline" className="text-xs">{company.count} póliza{company.count !== 1 ? 's' : ''}</Badge>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-foreground">{fmt(company.weightedPremium, currency)}</div>
                    {hasRules && company.weightedPremium !== company.basePremium && (
                      <div className="text-xs text-muted-foreground">base: {fmt(company.basePremium, currency)}</div>
                    )}
                  </div>
                </div>
                <div className="px-4 py-1.5">
                  <div className="flex items-center gap-2">
                    <Progress value={compPct} className="flex-1 h-1 [&>div]:bg-blue-400" />
                    <span className="text-xs text-muted-foreground/70 w-10 text-right">{compPct.toFixed(0)}%</span>
                  </div>
                </div>

                {/* Products within this company */}
                <div className="divide-y divide-border">
                  {company.products.map((prod, j) => {
                    const prodPct = company.weightedPremium > 0 ? (prod.weightedPremium / company.weightedPremium) * 100 : 0;
                    return (
                      <div key={j} className="px-4 py-2 space-y-1.5">
                        {/* Product header */}
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-foreground bg-muted border border-border rounded px-2 py-0.5">{prod.label}</span>
                            <span className="text-xs text-muted-foreground/70">{prod.count} póliza{prod.count !== 1 ? 's' : ''}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-sm font-semibold text-foreground/80">{fmt(prod.weightedPremium, currency)}</span>
                            {hasRules && prod.weightedPremium !== prod.basePremium && (
                              <div className="text-xs text-muted-foreground/70">base: {fmt(prod.basePremium, currency)}</div>
                            )}
                          </div>
                        </div>

                        {/* Policies in this product */}
                        <div className="space-y-0.5 pl-2">
                          {prod.policies.map((pol, k) => (
                            <div key={k} className="flex justify-between items-center text-xs text-muted-foreground bg-muted/40 rounded px-2 py-1">
                              <div className="flex gap-2 items-center">
                                <span className="font-mono text-muted-foreground/70">{pol.policy_number || pol.id?.slice(-6)}</span>
                                <span>{pol.client_name || '—'}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                {hasRules && pol._mult !== 1 && (
                                  <span className="text-amber-600 dark:text-amber-400 font-medium">×{pol._mult}</span>
                                )}
                                <span className="font-medium">{fmt(pol._weighted, currency)}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
        </div>{/* end print wrapper */}
      </DialogContent>
    </Dialog>
  );
}