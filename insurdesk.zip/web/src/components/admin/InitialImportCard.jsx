import React, { useEffect, useState } from 'react';
import { Lock, Unlock, Wrench, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { api } from '@/api/client';

const call = async (fn, payload) => (await api.functions.invoke(fn, payload)).data;

/** Cierre de la importación inicial: repara las relaciones por id y, al cerrar, exige IDs en todo lo posterior. */
export default function InitialImportCard() {
  const [closed, setClosed] = useState(null);
  const [report, setReport] = useState(null);
  const [busy, setBusy] = useState('');
  const load = async () => setClosed((await call('initialImport', { action: 'status' })).closed);
  useEffect(() => { load().catch(() => {}); }, []);

  const run = async (key, fn) => { setBusy(key); try { await fn(); } catch (e) { toast.error(e.message || 'Error'); } finally { setBusy(''); } };
  const review = () => run('review', async () => setReport(await call('repairRelations', { dryRun: true })));
  const apply = () => run('apply', async () => {
    const r = await call('repairRelations', { dryRun: false });
    toast.success(`Relaciones reparadas (${r.registros_modificados} registros)`);
    setReport(await call('repairRelations', { dryRun: true }));
  });
  const change = (action) => run(action, async () => {
    try { await call('initialImport', { action }); await load(); toast.success(action === 'close' ? 'Importación inicial cerrada' : 'Importación inicial reabierta'); }
    catch (e) { if (e.status === 409) { setReport(e.data?.report || null); toast.error('Aún hay relaciones por reparar'); } else throw e; }
  });

  const List = ({ title, items }) => (items?.length ? (
    <div className="mt-3">
      <p className="text-sm font-medium">{title} ({items.length}{items.length >= 25 ? '+' : ''})</p>
      <ul className="mt-1 max-h-32 overflow-auto text-xs text-muted-foreground space-y-0.5">
        {items.map((i, k) => <li key={k}>{i.entidad}.{i.campo}: {i.valor ?? i.id}</li>)}
      </ul>
    </div>
  ) : null);

  return (
    <Card className="p-5 mb-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2">
            <p className="font-semibold">Importación inicial</p>
            {closed === null ? null : closed
              ? <Badge variant="outline" className="gap-1"><Lock className="h-3 w-3" /> Cerrada</Badge>
              : <Badge variant="outline" className="gap-1 border-amber-500/40 text-amber-500"><Unlock className="h-3 w-3" /> Abierta</Badge>}
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            {closed
              ? 'Las importaciones y escrituras deben traer el ID de compañía, ramo, producto, agente y póliza. Ya no se enlaza por nombre.'
              : 'Mientras esté abierta se puede importar enlazando por nombre. Al terminar: revisa, repara y cierra; desde entonces todo se enlaza por ID.'}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={review} disabled={!!busy}>{busy === 'review' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wrench className="h-4 w-4 mr-1" />}Revisar relaciones</Button>
          {report && (report.vinculados_por_nombre + report.nombres_actualizados + report.codes_asignados + report.listas_normalizadas > 0) && <Button onClick={apply} disabled={!!busy}>Reparar relaciones</Button>}
          {closed ? <Button variant="outline" onClick={() => change('reopen')} disabled={!!busy}>Reabrir</Button> : <Button onClick={() => change('close')} disabled={!!busy}>Cerrar importación inicial</Button>}
        </div>
      </div>
      {report && (
        <div className="mt-4 rounded-lg border border-border p-3 text-sm">
          <p>Por enlazar por nombre: <b>{report.vinculados_por_nombre}</b> · Nombres a refrescar: <b>{report.nombres_actualizados}</b> · Códigos a asignar: <b>{report.codes_asignados}</b> · Listas a normalizar: <b>{report.listas_normalizadas}</b></p>
          <List title="Sin coincidencia (revisar a mano)" items={report.sin_coincidencia} />
          <List title="Nombres ambiguos (hay más de un registro igual)" items={report.ambiguos} />
          <List title="Referencias a registros que ya no existen" items={report.huerfanos} />
        </div>
      )}
    </Card>
  );
}
