import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { HardDrive, FileText, Shield, DollarSign, AlertTriangle, CheckCircle } from "lucide-react";

const STORAGE_LIMIT_GB = 50; // Default 50 GB limit
const STORAGE_LIMIT_BYTES = STORAGE_LIMIT_GB * 1024 * 1024 * 1024;

function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const gb = bytes / (1024 * 1024 * 1024);
  if (gb >= 1) return `${gb.toFixed(2)} GB`;
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(1)} MB`;
  const kb = bytes / 1024;
  if (kb >= 1) return `${kb.toFixed(0)} KB`;
  return `${bytes} B`;
}

const documentTypeLabels = {
  certificado: 'Certificado',
  endoso: 'Endoso',
  pago_escaneado: 'Comprobante de Pago',
  recibo: 'Recibo',
  poliza_original: 'Póliza Original',
  identificacion: 'Identificación',
  siniestro_evidencia: 'Evidencia de Siniestro',
  informe_medico: 'Informe Médico',
  factura: 'Factura',
  otro: 'Otro'
};

export default function StorageMeter() {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [storageLimit, setStorageLimit] = useState(STORAGE_LIMIT_BYTES);
  const [limitGB, setLimitGB] = useState(STORAGE_LIMIT_GB);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load all documents and storage limit setting in parallel
      const [docs, settings] = await Promise.all([
        api.entities.Document.list(),
        api.entities.AppSettings.filter({ setting_key: 'storage_limit_gb' }).catch(() => [])
      ]);
      setDocuments(docs);

      if (settings.length > 0) {
        const gb = parseFloat(settings[0].setting_value) || STORAGE_LIMIT_GB;
        setLimitGB(gb);
        setStorageLimit(gb * 1024 * 1024 * 1024);
      } else {
        // Create default setting if it doesn't exist
        await api.entities.AppSettings.create({
          setting_key: 'storage_limit_gb',
          setting_value: String(STORAGE_LIMIT_GB),
          setting_type: 'number',
          description: 'Límite de almacenamiento en GB para Azure Blob Storage'
        }).catch(() => {});
      }
    } catch (error) {
      console.error('Error loading storage data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Calculate totals
  const totalUsed = documents.reduce((sum, d) => sum + (d.file_size || 0), 0);
  const pctUsed = Math.min((totalUsed / storageLimit) * 100, 100);

  // By entity type
  const byEntityType = documents.reduce((acc, d) => {
    const key = d.entity_type || 'Otro';
    acc[key] = (acc[key] || 0) + (d.file_size || 0);
    return acc;
  }, {});

  // By document type
  const byDocType = documents.reduce((acc, d) => {
    const key = d.document_type || 'otro';
    if (!acc[key]) acc[key] = { count: 0, size: 0 };
    acc[key].count++;
    acc[key].size += d.file_size || 0;
    return acc;
  }, {});

  const sortedDocTypes = Object.entries(byDocType).sort((a, b) => b[1].size - a[1].size);

  // Bar color thresholds
  const barColor = pctUsed < 70
    ? 'bg-emerald-500'
    : pctUsed < 90
    ? 'bg-amber-500'
    : 'bg-red-500';

  const statusColor = pctUsed < 70
    ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10'
    : pctUsed < 90
    ? 'text-amber-600 dark:text-amber-400 bg-amber-500/10'
    : 'text-red-600 dark:text-red-400 bg-red-500/10';

  const statusIcon = pctUsed < 70
    ? <CheckCircle className="h-4 w-4" />
    : <AlertTriangle className="h-4 w-4" />;

  const statusLabel = pctUsed < 70
    ? 'Normal'
    : pctUsed < 90
    ? 'Advertencia'
    : 'Crítico';

  const entityIcons = {
    Policy: <FileText className="h-4 w-4 text-foreground" />,
    Client: <Shield className="h-4 w-4 text-emerald-500" />,
    Claim: <AlertTriangle className="h-4 w-4 text-amber-500" />,
    Payment: <DollarSign className="h-4 w-4 text-purple-500" />,
    Endorsement: <FileText className="h-4 w-4 text-muted-foreground" />
  };

  const entityLabels = {
    Policy: 'Pólizas',
    Client: 'Clientes',
    Claim: 'Siniestros',
    Payment: 'Pagos',
    Endorsement: 'Endosos'
  };

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 flex items-center justify-center h-48">
          <div className="h-6 w-6 border-2 border-input border-t-blue-500 rounded-full animate-spin" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Main Storage Meter */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HardDrive className="h-5 w-5 text-brand" />
              Almacenamiento
            </div>
            <Badge className={`flex items-center gap-1 ${statusColor}`}>
              {statusIcon}
              {statusLabel}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Progress bar */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="font-medium text-foreground/80">{formatBytes(totalUsed)} usados</span>
              <span className="text-muted-foreground">Límite: {limitGB} GB</span>
            </div>
            {/* Segmented bar: green/yellow/red zones */}
            <div className="relative h-5 rounded-full bg-muted overflow-hidden">
              {/* Zone backgrounds */}
              <div className="absolute inset-0 flex">
                <div className="h-full bg-emerald-500/10" style={{ width: '70%' }} />
                <div className="h-full bg-amber-500/10" style={{ width: '20%' }} />
                <div className="h-full bg-red-500/10" style={{ width: '10%' }} />
              </div>
              {/* Fill */}
              <div
                className={`absolute left-0 top-0 h-full transition-all duration-700 ${barColor} opacity-90`}
                style={{ width: `${pctUsed}%` }}
              />
              {/* Zone markers */}
              <div className="absolute left-[70%] top-0 h-full w-px bg-white/60" />
              <div className="absolute left-[90%] top-0 h-full w-px bg-white/60" />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground/70 mt-1">
              <span>{pctUsed.toFixed(1)}% utilizado</span>
              <span>{formatBytes(storageLimit - totalUsed)} disponibles</span>
            </div>
          </div>

          {/* Alert messages */}
          {pctUsed >= 90 && (
            <div className="flex items-center gap-2 p-3 bg-red-500/10 rounded-lg text-red-600 dark:text-red-400 text-sm">
              <AlertTriangle className="h-4 w-4 flex-shrink-0" />
              <span>Almacenamiento crítico. Considera eliminar archivos o ampliar el límite.</span>
            </div>
          )}
          {pctUsed >= 70 && pctUsed < 90 && (
            <div className="flex items-center gap-2 p-3 bg-amber-500/10 rounded-lg text-amber-600 dark:text-amber-400 text-sm">
              <AlertTriangle className="h-4 w-4 flex-shrink-0" />
              <span>Almacenamiento al {pctUsed.toFixed(0)}%. Monitorea el uso regularmente.</span>
            </div>
          )}

          {/* Summary by entity type */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {Object.entries(byEntityType).map(([type, size]) => (
              <div key={type} className="flex items-center gap-2 p-3 bg-muted/40 rounded-lg">
                {entityIcons[type] || <FileText className="h-4 w-4 text-muted-foreground/70" />}
                <div>
                  <p className="text-xs text-muted-foreground">{entityLabels[type] || type}</p>
                  <p className="text-sm font-semibold text-foreground">{formatBytes(size)}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detail by document type */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4 text-brand" />
            Detalle por Tipo de Documento
            <span className="ml-auto text-sm font-normal text-muted-foreground">{documents.length} archivos</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {sortedDocTypes.length === 0 ? (
            <p className="text-center text-muted-foreground/70 py-6 text-sm">No hay documentos registrados</p>
          ) : (
            <div className="space-y-2">
              {sortedDocTypes.map(([type, { count, size }]) => {
                const pct = totalUsed > 0 ? (size / totalUsed) * 100 : 0;
                return (
                  <div key={type} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground/80 font-medium">{documentTypeLabels[type] || type}</span>
                      <div className="flex items-center gap-3 text-muted-foreground">
                        <span>{count} archivo{count !== 1 ? 's' : ''}</span>
                        <span className="font-semibold text-foreground">{formatBytes(size)}</span>
                      </div>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-brand rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}