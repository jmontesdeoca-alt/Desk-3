import React, { useState, useEffect, useCallback, memo } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle
} from '@/components/ui/dialog';
import { Plus, Pencil, Trash2, Loader2, Tag } from 'lucide-react';
import { toast } from 'sonner';
import {
  POLICY_TAG_ICONS, POLICY_TAG_COLORS, POLICY_TAG_COLOR_NAMES,
  getTagIcon, getTagColorClasses
} from '@/components/policy/policyTagIcons';
import PageHeader from '@/components/ui/PageHeader';

const IconPicker = memo(({ value, onChange }) => {
  const iconNames = Object.keys(POLICY_TAG_ICONS);
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger><SelectValue /></SelectTrigger>
      <SelectContent className="max-h-60">
        {iconNames.map(name => {
          const Icon = POLICY_TAG_ICONS[name];
          return (
            <SelectItem key={name} value={name}>
              <div className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                {name}
              </div>
            </SelectItem>
          );
        })}
      </SelectContent>
    </Select>
  );
});

export default function PolicyTagManager() {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTag, setEditingTag] = useState(null);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({ name: '', icon: 'Tag', color: 'slate', status: 'activo' });

  const handleIconChange = useCallback((v) => {
    setFormData(prev => ({ ...prev, icon: v }));
  }, []);

  useEffect(() => {
    loadTags();
  }, []);

  const loadTags = async () => {
    setLoading(true);
    try {
      const data = await api.entities.PolicyTag.list();
      setTags(data.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (err) {
      toast.error('Error al cargar etiquetas: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const openCreate = () => {
    setEditingTag(null);
    setFormData({ name: '', icon: 'Tag', color: 'slate', status: 'activo' });
    setDialogOpen(true);
  };

  const openEdit = (tag) => {
    setEditingTag(tag);
    setFormData({ name: tag.name, icon: tag.icon, color: tag.color || 'slate', status: tag.status || 'activo' });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) {
      toast.error('El nombre es obligatorio');
      return;
    }
    setSaving(true);
    try {
      if (editingTag) {
        await api.entities.PolicyTag.update(editingTag.id, formData);
        toast.success('Etiqueta actualizada');
      } else {
        await api.entities.PolicyTag.create(formData);
        toast.success('Etiqueta creada');
      }
      setDialogOpen(false);
      loadTags();
    } catch (err) {
      toast.error('Error al guardar: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (tag) => {
    if (!confirm(`¿Eliminar la etiqueta "${tag.name}"?`)) return;
    try {
      await api.entities.PolicyTag.delete(tag.id);
      toast.success('Etiqueta eliminada');
      loadTags();
    } catch (err) {
      toast.error('Error al eliminar: ' + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-4xl mx-auto">
        <PageHeader
          title="Etiquetas de Pólizas"
          subtitle="Configura las etiquetas que se pueden asignar a las pólizas"
          backTo="AdminPanel"
          icon={Tag}
          actions={
            <Button onClick={openCreate} className="gap-2">
              <Plus className="h-4 w-4" /> Nueva Etiqueta
            </Button>
          }
        />

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-foreground" />
          </div>
        ) : tags.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-12 text-center">
              <Tag className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">No hay etiquetas configuradas</p>
              <Button onClick={openCreate} className="gap-2">
                <Plus className="h-4 w-4" /> Crear primera etiqueta
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {tags.map(tag => {
              const Icon = getTagIcon(tag.icon);
              const colorClass = getTagColorClasses(tag.color);
              return (
                <Card key={tag.id} className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-sm font-medium border ${colorClass}`}>
                        <Icon className="h-4 w-4" />
                        {tag.name}
                      </span>
                      {tag.status === 'inactivo' && (
                        <span className="text-xs text-muted-foreground/70 bg-muted px-2 py-0.5 rounded-full">inactiva</span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground mb-3">
                      Icono: <code className="text-foreground/80">{tag.icon}</code> · Color: <code className="text-foreground/80">{tag.color || 'slate'}</code>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(tag)} className="gap-1.5">
                        <Pencil className="h-3.5 w-3.5" /> Editar
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => handleDelete(tag)} className="gap-1.5 text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400">
                        <Trash2 className="h-3.5 w-3.5" /> Eliminar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingTag ? 'Editar Etiqueta' : 'Nueva Etiqueta'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre *</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ej: Discapacitado, Cartera cedida entrante"
                />
              </div>

              <div className="space-y-2">
                <Label>Icono</Label>
                <IconPicker value={formData.icon} onChange={handleIconChange} />
              </div>

              <div className="space-y-2">
                <Label>Color</Label>
                <div className="flex flex-wrap gap-2">
                  {POLICY_TAG_COLOR_NAMES.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData({ ...formData, color })}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                        POLICY_TAG_COLORS[color]
                      } ${formData.color === color ? 'ring-2 ring-ring ring-offset-1' : ''}`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Estado</Label>
                <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activo">Activo</SelectItem>
                    <SelectItem value="inactivo">Inactivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Preview */}
              <div className="p-3 bg-muted/40 rounded-lg border">
                <p className="text-xs text-muted-foreground mb-2">Vista previa:</p>
                {(() => {
                  const Icon = getTagIcon(formData.icon);
                  const colorClass = getTagColorClasses(formData.color);
                  return (
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-sm font-medium border ${colorClass}`}>
                      <Icon className="h-4 w-4" />
                      {formData.name || 'Nombre de etiqueta'}
                    </span>
                  );
                })()}
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
                <Button onClick={handleSave} disabled={saving}>
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingTag ? 'Guardar' : 'Crear'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}