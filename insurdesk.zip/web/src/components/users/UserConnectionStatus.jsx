import React, { useMemo, useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wifi, Clock, Loader2 } from 'lucide-react';
import { formatRelativeTime, formatLocalTime } from '@/components/dateUtils';

// Considera "online" si estuvo activo en los últimos 10 minutos
const ONLINE_THRESHOLD_MS = 10 * 60 * 1000;

function getStatusInfo(lastSeen) {
  if (!lastSeen) return { isOnline: false, label: 'Sin registro' };
  const diff = Date.now() - new Date(lastSeen).getTime();
  const isOnline = diff < ONLINE_THRESHOLD_MS;
  const label = isOnline
    ? `activo a las ${formatLocalTime(lastSeen)}`
    : formatRelativeTime(lastSeen);
  return { isOnline, label };
}

export default function UserConnectionStatus() {
  const [liveUsers, setLiveUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  // Cargar usuarios desde listAllUsers (visible para todos)
  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const response = await api.functions.invoke('listAllUsers');
      setLiveUsers(response.data?.users || []);
    } catch (error) {
      console.error('Error loading users:', error);
      setLiveUsers([]);
    } finally {
      setLoading(false);
    }
  };

  // Auto-refresco cada 60 segundos para actualizar last_seen
  useEffect(() => {
    const interval = setInterval(loadUsers, 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const usersWithStatus = useMemo(() => {
    return [...liveUsers]
      .map(u => ({ ...u, ...getStatusInfo(u.last_seen) }))
      .sort((a, b) => {
        // Online primero, luego por last_seen desc
        if (a.isOnline !== b.isOnline) return a.isOnline ? -1 : 1;
        if (!a.last_seen && !b.last_seen) return 0;
        if (!a.last_seen) return 1;
        if (!b.last_seen) return -1;
        return new Date(b.last_seen) - new Date(a.last_seen);
      });
  }, [liveUsers]);

  const onlineCount = usersWithStatus.filter(u => u.isOnline).length;

  return (
    <Card className="border-0 shadow-sm mb-6">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center gap-2">
            <Wifi className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            Estado de Conexión de Usuarios
          </div>
          <div className="flex items-center gap-3 text-sm font-normal">
            <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse inline-block" />
              {onlineCount} en línea
            </span>
            <span className="flex items-center gap-1.5 text-muted-foreground/70">
              <span className="h-2.5 w-2.5 rounded-full bg-muted-foreground/30 inline-block" />
              {usersWithStatus.length - onlineCount} desconectados
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground/70" />
          </div>
        ) : (
         <div className="overflow-y-auto" style={{ maxHeight: '336px' }}>
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {usersWithStatus.map(user => (
            <div
              key={user.id}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                user.isOnline
                  ? 'bg-emerald-500/10 border-emerald-500/30'
                  : 'bg-muted/40 border-border'
              }`}
            >
              {/* Avatar con indicador */}
              <div className="relative flex-shrink-0">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center font-semibold text-sm ${
                  user.isOnline
                    ? 'bg-emerald-500 text-white'
                    : 'bg-muted-foreground/30 text-muted-foreground'
                }`}>
                  {(user.full_name || user.email || '?').charAt(0).toUpperCase()}
                </div>
                <span className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white ${
                  user.isOnline ? 'bg-emerald-500' : 'bg-muted-foreground/50'
                }`} />
              </div>

              {/* Info */}
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground truncate">
                  {user.full_name || user.display_name || user.email}
                </p>
                <p className="text-xs text-muted-foreground truncate capitalize">
                  {user.app_role || user.role || 'Sin rol'}
                </p>
                <div className="flex items-center gap-1 mt-0.5">
                  {user.isOnline ? (
                    <Wifi className="h-3 w-3 text-emerald-500 flex-shrink-0" />
                  ) : (
                    <Clock className="h-3 w-3 text-muted-foreground/70 flex-shrink-0" />
                  )}
                  <span className={`text-xs truncate ${user.isOnline ? 'text-emerald-600 dark:text-emerald-400 font-medium' : 'text-muted-foreground/70'}`}>
                    {user.isOnline ? `En línea · ${user.label}` : user.label}
                  </span>
                </div>
              </div>
            </div>
          ))}
          </div>
          </div>
          )}
          </CardContent>
    </Card>
  );
}