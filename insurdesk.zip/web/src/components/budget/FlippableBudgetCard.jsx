import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, TrendingUp, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

export default function FlippableBudgetCard({ budget, onEdit, onDelete }) {
  const [flipped, setFlipped] = useState(false);
  const frontRef = useRef(null);
  const backRef = useRef(null);
  const [cardHeight, setCardHeight] = useState('auto');

  useEffect(() => {
    const updateHeight = () => {
      const frontH = frontRef.current?.scrollHeight || 0;
      const backH = backRef.current?.scrollHeight || 0;
      setCardHeight(Math.max(frontH, backH) + 'px');
    };
    updateHeight();
    window.addEventListener('resize', updateHeight);
    return () => window.removeEventListener('resize', updateHeight);
  }, [budget]);

  const progress = (budget.total / budget.target_amount) * 100;
  const isCompleted = budget.total >= budget.target_amount;

  return (
    <div
      className="relative w-full cursor-pointer"
      style={{ perspective: '1200px', height: cardHeight }}
      onClick={() => setFlipped(f => !f)}
    >
      <motion.div
        className="relative w-full"
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.5, ease: 'easeInOut' }}
        style={{ transformStyle: 'preserve-3d', height: cardHeight }}
      >
        {/* FRONT */}
        <div
          ref={frontRef}
          className="absolute inset-0 w-full rounded-xl border bg-card shadow-sm p-4 flex flex-col gap-3"
          style={{ backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden' }}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <Briefcase className="h-4 w-4 text-foreground shrink-0" />
                <h3 className="font-semibold text-foreground truncate">{budget.name}</h3>
              </div>
              <div className="flex flex-wrap gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
                <span>{new Date(budget.start_date + 'T12:00:00').toLocaleDateString()} – {new Date(budget.end_date + 'T12:00:00').toLocaleDateString()}</span>
                {budget.company_name && <span>• {budget.company_name}</span>}
                {budget.line_name && <span>• {budget.line_name}</span>}
              </div>
            </div>
            <div className="text-right shrink-0">
              <p className="text-xs text-muted-foreground">Objetivo</p>
              <p className="text-base font-bold text-foreground whitespace-nowrap">{budget.currency} ${budget.target_amount.toLocaleString()}</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-2 bg-muted rounded-lg border border-border">
              <p className="text-xs text-muted-foreground mb-0.5">Total Vendido</p>
              <p className="text-sm font-bold text-foreground">${budget.total.toLocaleString()}</p>
            </div>
            <div className="p-2 bg-green-500/10 rounded-lg border border-green-500/30">
              <p className="text-xs text-muted-foreground mb-0.5">Pagadas</p>
              <p className="text-sm font-bold text-green-600 dark:text-green-400">${budget.paid.toLocaleString()}</p>
            </div>
            <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/30">
              <p className="text-xs text-muted-foreground mb-0.5">Pendientes</p>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400">${budget.unpaid.toLocaleString()}</p>
            </div>
          </div>

          {/* Progress */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Cumplimiento</span>
              <span className="font-semibold text-foreground">{Math.min(progress, 100).toFixed(0)}%</span>
            </div>
            <Progress value={Math.min(progress, 100)} className="h-2" />
          </div>

          {isCompleted && (
            <div className="text-sm font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              ¡Presupuesto completado!
            </div>
          )}

          {budget.productBreakdown && budget.productBreakdown.length > 0 && (
            <p className="text-xs text-muted-foreground/70 text-center">Toca para ver detalle por producto →</p>
          )}

          {/* Actions - stop flip propagation */}
          <div
            className="flex justify-end gap-2 pt-2 border-t mt-auto"
            onClick={e => e.stopPropagation()}
          >
            <Button variant="ghost" size="sm" onClick={() => onEdit(budget)}>✏️ Editar</Button>
            <Button variant="ghost" size="sm" onClick={() => onDelete(budget.id)} className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* BACK */}
        <div
          ref={backRef}
          className="absolute inset-0 w-full rounded-xl border bg-gradient-to-br from-blue-50 to-background shadow-sm p-4 flex flex-col gap-3"
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Briefcase className="h-4 w-4 text-foreground" />
              <h3 className="font-semibold text-foreground">Detalle por Producto</h3>
            </div>
            <span className="text-xs text-muted-foreground/70 truncate max-w-[40%]">{budget.name}</span>
          </div>

          {budget.productBreakdown && budget.productBreakdown.length > 0 ? (
            <div className="space-y-2 overflow-y-auto flex-1">
              {budget.productBreakdown.map((prod, idx) => {
                const pct = budget.total > 0 ? (prod.total / budget.total) * 100 : 0;
                return (
                  <div key={idx} className="space-y-0.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground/80 truncate max-w-[65%]">{prod.product_name}</span>
                      <span className="font-semibold text-foreground">${prod.total.toLocaleString('es', { maximumFractionDigits: 0 })}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-secondary rounded-full h-1.5">
                        <div className="bg-primary h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground/70 w-8 text-right">{pct.toFixed(0)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-6">Sin detalle por producto</p>
          )}

          {/* Actions on back too */}
          <div
            className="flex items-center justify-between pt-2 border-t mt-auto"
            onClick={e => e.stopPropagation()}
          >
            <p className="text-xs text-muted-foreground/70">← Toca para volver</p>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => { onEdit(budget); setFlipped(false); }}>✏️ Editar</Button>
              <Button variant="ghost" size="sm" onClick={() => onDelete(budget.id)} className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}