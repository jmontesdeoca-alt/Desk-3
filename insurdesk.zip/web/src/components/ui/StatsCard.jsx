import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

// Tarjeta de métrica sobria: fondo neutro y un único detalle de color en el icono.
// "variant" ya no pinta toda la tarjeta; solo matiza el icono para distinguir el tipo de métrica.
const ICON_TONE = {
  default: 'text-muted-foreground bg-muted',
  primary: 'text-brand bg-brand-soft',
  success: 'text-emerald-700 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-500/10',
  warning: 'text-amber-700 bg-amber-50 dark:text-amber-400 dark:bg-amber-500/10',
  danger: 'text-red-700 bg-red-50 dark:text-red-400 dark:bg-red-500/10',
  purple: 'text-brand bg-brand-soft',
};

export default function StatsCard({ title, value, subtitle, icon: Icon, trend, trendUp, className, variant = 'default' }) {
  return (
    <Card className={cn("transition-colors hover:border-foreground/20", className)}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1.5 min-w-0">
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-3xl font-semibold tracking-tight text-foreground tabular">{value}</p>
            {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
            {trend && (
              <div className={cn("flex items-center gap-1 text-xs font-medium", trendUp ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400")}>
                <span>{trendUp ? '↑' : '↓'}</span>
                <span>{trend}</span>
              </div>
            )}
          </div>
          {Icon && (
            <div className={cn("p-2 rounded-md shrink-0", ICON_TONE[variant] || ICON_TONE.default)}>
              <Icon className="h-5 w-5" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
