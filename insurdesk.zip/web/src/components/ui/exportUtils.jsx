import * as XLSX from 'xlsx';
import { formatDate, formatDateTime, TIMEZONE } from '@/lib/dateUtils';

/**
 * Formatea una fecha (date-only) para exports — usa zona horaria del navegador.
 * @param {string|Date} date - Fecha en formato YYYY-MM-DD o Date
 * @param {string} fmt - Patrón date-fns (default "dd/MM/yyyy")
 * @returns {string}
 */
export function formatDateForExport(date, fmt = 'dd/MM/yyyy') {
  return formatDate(date, fmt);
}

/**
 * Formatea un datetime (ISO) para exports — incluye zona horaria del navegador.
 * @param {string|Date} date - ISO datetime o Date
 * @param {string} fmt - Patrón date-fns (default "dd/MM/yyyy HH:mm")
 * @returns {string}
 */
export function formatDateTimeForExport(date, fmt = 'dd/MM/yyyy HH:mm') {
  return formatDateTime(date, fmt);
}

/**
 * Retorna el label de zona horaria para incluir en headers de export.
 * Ej: " (Hora local: America/Guayaquil)"
 */
export function getTimezoneLabel() {
  return ` (Hora local: ${TIMEZONE})`;
}

/**
 * Export data to CSV with proper UTF-8 encoding (supports tildes and ñ)
 */
export function exportToCSV({ headers, rows, filename }) {
  const csvRows = rows.map(row =>
    row.map(cell => {
      const val = cell === null || cell === undefined ? '' : String(cell);
      return `"${val.replace(/"/g, '""')}"`;
    }).join(',')
  );

  const csvContent = [headers.join(','), ...csvRows].join('\n');

  // Add BOM for UTF-8 to ensure Excel and other apps render accents/ñ correctly
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

/**
 * Export data to Excel (.xlsx) with proper column widths
 * headers: string[]
 * rows: array of arrays (values in same order as headers)
 * filename: string
 */
export function exportToExcel({ headers, rows, filename, sheetName = 'Datos' }) {
  // Build data array: first row is headers, then data rows
  const wsData = [
    headers,
    ...rows.map(row => headers.map((_, i) => row[i] !== undefined && row[i] !== null ? row[i] : ''))
  ];

  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Auto column widths based on content
  const colWidths = headers.map((header, colIdx) => {
    const maxLen = Math.max(
      header.length,
      ...rows.map(row => String(row[colIdx] !== null && row[colIdx] !== undefined ? row[colIdx] : '').length)
    );
    return { wch: Math.min(Math.max(maxLen + 2, 10), 40) };
  });
  ws['!cols'] = colWidths;

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  const xlsxFilename = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  XLSX.writeFile(wb, xlsxFilename);
}