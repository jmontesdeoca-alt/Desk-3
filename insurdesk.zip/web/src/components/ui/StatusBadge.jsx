import React from 'react';
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const statusStyles = {
  // General
  activo: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  activa: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  inactivo: "bg-muted text-muted-foreground border-border",
  inactiva: "bg-muted text-muted-foreground border-border",
  
  // Pólizas
  vencida: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30",
  cancelada: "bg-muted text-muted-foreground border-border",
  en_renovacion: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30",
  en_riesgo: "bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/30",
  
  // Pagos
  pagado: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  pendiente: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30",
  atrasado: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30",
  
  // Renovaciones
  propuesta: "bg-brand-soft/20 text-brand-strong border-brand-soft",
  confirmada: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  rechazada: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30",
  
  // Siniestros
  en_proceso: "bg-brand-soft/20 text-brand-strong border-brand-soft",
  aprobado: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  rechazado: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30",
  
  // Comisiones
  calculada: "bg-brand-soft/20 text-brand-strong border-brand-soft",
  pagada: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  reversada: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30",
};

const statusLabels = {
  activo: "Activo",
  activa: "Activa",
  inactivo: "Inactivo",
  inactiva: "Inactiva",
  vencida: "Vencida",
  cancelada: "Cancelada",
  en_renovacion: "En Renovación",
  en_riesgo: "En Riesgo",
  pagado: "Pagado",
  pendiente: "Pendiente",
  atrasado: "Atrasado",
  propuesta: "Propuesta",
  confirmada: "Confirmada",
  rechazada: "Rechazada",
  en_proceso: "En Proceso",
  aprobado: "Aprobado",
  rechazado: "Rechazado",
  calculada: "Calculada",
  pagada: "Pagada",
  reversada: "Reversada",
};

export default function StatusBadge({ status, className }) {
  const style = statusStyles[status] || "bg-muted text-muted-foreground border-border";
  const label = statusLabels[status] || status;
  
  return (
    <Badge variant="outline" className={cn("font-medium border", style, className)}>
      {label}
    </Badge>
  );
}