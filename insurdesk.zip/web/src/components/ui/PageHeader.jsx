import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PageHeader({ 
  title, 
  subtitle, 
  backTo, 
  actions,
  icon: Icon 
}) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
      <div className="flex items-start gap-4">
        {backTo && (
          <Link to={createPageUrl(backTo)}>
            <Button variant="ghost" size="icon" className="mt-1 hover:bg-muted">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
        )}
        <div className="flex items-center gap-3">
          {Icon && (
            <div className="p-2.5 rounded-lg bg-muted">
              <Icon className="h-5 w-5 text-foreground" />
            </div>
          )}
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">{title}</h1>
            {subtitle && <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>}
          </div>
        </div>
      </div>
      {actions && (
        <div className="flex items-center gap-3">
          {actions}
        </div>
      )}
    </div>
  );
}