import { BRAND } from '@/lib/brand';

/** Marca para las pantallas del CRM (una sola identidad: la del producto). */
export const useBrand = () => ({ brand: { app_name: BRAND.name, logo_url: BRAND.logo } });
