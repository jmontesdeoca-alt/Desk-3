import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Loader2, Trash2, ShieldAlert, CheckCircle } from 'lucide-react';

/**
 * DeleteSafetyDialog
 * Props:
 * - open: bool
 * - onOpenChange: fn
 * - title: string (e.g. "Eliminar póliza")
 * - entityDescription: string (e.g. 'la póliza "P-001"')
 * - checkUsage: async fn → { usageItems: [{label, count, detail?}] }
 * - onConfirm: async fn (called when user confirms deletion)
 */
export default function DeleteSafetyDialog({
  open,
  onOpenChange,
  title = "Eliminar registro",
  entityDescription = "este registro",
  checkUsage,
  onConfirm,
}) {
  const [checking, setChecking] = useState(false);
  const [usageItems, setUsageItems] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (open && checkUsage) {
      setUsageItems(null);
      setChecking(true);
      checkUsage()
        .then(({ usageItems: items }) => setUsageItems(items || []))
        .catch(() => setUsageItems([]))
        .finally(() => setChecking(false));
    }
  }, [open]);

  const handleConfirm = async () => {
    setDeleting(true);
    try {
      await onConfirm();
      onOpenChange(false);
    } finally {
      setDeleting(false);
    }
  };

  const hasUsage = usageItems && usageItems.length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {checking ? (
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground/70" />
            ) : hasUsage ? (
              <ShieldAlert className="h-5 w-5 text-amber-500" />
            ) : (
              <Trash2 className="h-5 w-5 text-red-500" />
            )}
            {title}
          </DialogTitle>
          <DialogDescription>
            {checking
              ? "Verificando si el registro está en uso..."
              : hasUsage
              ? `Este registro está siendo utilizado en otras partes del sistema.`
              : `¿Estás seguro de que deseas eliminar ${entityDescription}?`}
          </DialogDescription>
        </DialogHeader>

        {/* Checking state */}
        {checking && (
          <div className="flex items-center justify-center py-6">
            <Loader2 className="h-8 w-8 animate-spin text-foreground" />
            <span className="ml-3 text-muted-foreground">Verificando dependencias...</span>
          </div>
        )}

        {/* Usage details */}
        {!checking && hasUsage && (
          <div className="space-y-3">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
              <div className="flex items-start gap-2 mb-3">
                <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm font-semibold text-amber-600 dark:text-amber-400">
                  El registro está siendo usado en:
                </p>
              </div>
              <ul className="space-y-2">
                {usageItems.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 font-bold text-xs flex-shrink-0">
                      {item.count}
                    </span>
                    <div>
                      <span className="font-medium text-foreground">{item.label}</span>
                      {item.detail && (
                        <p className="text-xs text-muted-foreground mt-0.5">{item.detail}</p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <p className="text-sm text-muted-foreground font-medium">
              ¿Deseas eliminar {entityDescription} de todas formas? Esta acción no se puede deshacer.
            </p>
          </div>
        )}

        {/* Safe to delete */}
        {!checking && !hasUsage && usageItems !== null && (
          <div className="bg-muted/40 border border-border rounded-lg p-4 flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground">
              No se encontraron dependencias activas. Se eliminará permanentemente {entityDescription}.
            </p>
          </div>
        )}

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={deleting}
          >
            Cancelar
          </Button>
          <Button
            variant="destructive"
            onClick={handleConfirm}
            disabled={checking || deleting}
            className="gap-2"
          >
            {deleting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Trash2 className="h-4 w-4" />
            )}
            {hasUsage ? "Eliminar de todas formas" : "Eliminar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}