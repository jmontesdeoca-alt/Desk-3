import React from 'react';
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { AlertTriangle, AlertCircle, CheckCircle, Info } from "lucide-react";

const variants = {
  warning: {
    bg: "bg-amber-500/10 border-amber-500/30",
    icon: AlertTriangle,
    iconColor: "text-amber-600 dark:text-amber-400"
  },
  error: {
    bg: "bg-red-500/10 border-red-500/30",
    icon: AlertCircle,
    iconColor: "text-red-600 dark:text-red-400"
  },
  success: {
    bg: "bg-emerald-500/10 border-emerald-500/30",
    icon: CheckCircle,
    iconColor: "text-emerald-600 dark:text-emerald-400"
  },
  info: {
    bg: "bg-muted border-border",
    icon: Info,
    iconColor: "text-foreground"
  }
};

export default function AlertCard({ 
  variant = "info", 
  title, 
  description, 
  count,
  onClick,
  className 
}) {
  const { bg, icon: Icon, iconColor } = variants[variant];
  
  return (
    <Card 
      className={cn(
        "p-4 border cursor-pointer transition-all hover:shadow-md",
        bg,
        className
      )}
      onClick={onClick}
    >
      <div className="flex items-start gap-3">
        <Icon className={cn("h-5 w-5 mt-0.5 flex-shrink-0", iconColor)} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <p className="font-semibold text-foreground">{title}</p>
            {count !== undefined && (
              <span className={cn("px-2 py-0.5 rounded-full text-sm font-bold", iconColor, bg)}>
                {count}
              </span>
            )}
          </div>
          {description && (
            <p className="text-sm text-muted-foreground mt-0.5">{description}</p>
          )}
        </div>
      </div>
    </Card>
  );
}