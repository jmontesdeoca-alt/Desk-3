import React, { useState, useRef } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, ChevronLeft, ChevronRight, Download, ChevronDown, ArrowUpDown } from "lucide-react";
import { cn } from "@/lib/utils";

export default function DataTable({ 
  columns, 
  data = [], 
  searchable = true, 
  searchPlaceholder = "Buscar...",
  searchKeys = [],
  onRowClick,
  pageSize = 10,
  exportable = false,
  onExport,
  onExportExcel,
  exportFilename = 'datos',
  exportHeaders = null,
  exportRows = null,
  emptyMessage = "No hay datos disponibles",
  sortable = true,
  defaultSortField = null,
  defaultSortOrder = 'desc',
  initialSearch = "",
  onSearchChange = null,
  actions = null,
  selectable = false,
  onSelectionChange = null,
  selectableFilter = null
}) {
  const [search, setSearch] = React.useState(initialSearch);
  const [page, setPage] = useState(0);
  const [sortField, setSortField] = useState(defaultSortField);
  const [sortOrder, setSortOrder] = useState(defaultSortOrder);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const prevDataIdsRef = useRef(null);

  // Actualizar búsqueda cuando cambia initialSearch
  React.useEffect(() => {
    setSearch(initialSearch);
  }, [initialSearch]);

  // Notificar cambios de selección al padre (solo cuando selectedIds cambia, no cuando data cambia)
  const onSelectionChangeRef = useRef(onSelectionChange);
  onSelectionChangeRef.current = onSelectionChange;
  React.useEffect(() => {
    if (onSelectionChangeRef.current) {
      const selectedRows = data.filter(row => selectedIds.has(row.id));
      onSelectionChangeRef.current(selectedRows);
    }
  }, [selectedIds]); // eslint-disable-line react-hooks/exhaustive-deps

  // Limpiar selección SOLO cuando los IDs del dataset cambian realmente (nueva carga de datos)
  React.useEffect(() => {
    const newIds = data.map(r => r.id).join(',');
    if (prevDataIdsRef.current !== null && prevDataIdsRef.current !== newIds) {
      setSelectedIds(new Set());
    }
    prevDataIdsRef.current = newIds;
  }, [data]);

  const selectableRows = selectable
    ? (selectableFilter ? data.filter(selectableFilter) : data)
    : [];

  const toggleRow = (id) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    const pageSelectableIds = paginatedData
      .filter(row => !selectableFilter || selectableFilter(row))
      .map(r => r.id);
    const allSelected = pageSelectableIds.every(id => selectedIds.has(id));
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (allSelected) pageSelectableIds.forEach(id => next.delete(id));
      else pageSelectableIds.forEach(id => next.add(id));
      return next;
    });
  };

  // Sync search with parent
  const handleSearchChange = (value) => {
    setSearch(value);
    setPage(0);
    onSearchChange?.(value);
  };

  // Normalize text by removing accents/tildes
  const normalizeText = (text) => {
    return String(text || "")
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  };

  let filteredData = data.filter(row => {
    if (!search) return true;
    
    const normalizedSearch = normalizeText(search);
    
    // If searchKeys are provided, search in those specific keys
    if (searchKeys.length > 0) {
      return searchKeys.some(key => {
        const value = row[key];
        const normalizedValue = normalizeText(value);
        
        // For name field, also check if search matches first name, last name, or any combination
        if (key === 'name') {
          const searchParts = normalizedSearch.split(/\s+/).filter(Boolean);
          const valueParts = normalizedValue.split(/\s+/).filter(Boolean);
          
          // Check if any search part matches any value part
          return searchParts.every(searchPart => 
            valueParts.some(valuePart => valuePart.includes(searchPart))
          );
        }
        
        return normalizedValue.includes(normalizedSearch);
      });
    }
    
    // Otherwise search in columns
    return columns.some(col => {
      const value = col.accessorKey ? row[col.accessorKey] : col.accessor?.(row);
      return normalizeText(value).includes(normalizedSearch);
    });
  });

  // Sort data
  if (sortField && sortable) {
    filteredData = [...filteredData].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      
      // Handle dates
      if (aVal && typeof aVal === 'string' && aVal.match(/^\d{4}-\d{2}-\d{2}/)) {
        const aTime = new Date(aVal).getTime();
        const bTime = bVal ? new Date(bVal).getTime() : 0;
        aVal = isNaN(aTime) ? 0 : aTime;
        bVal = isNaN(bTime) ? 0 : bTime;
      }

      // Handle null/undefined
      if (aVal == null) aVal = '';
      if (bVal == null) bVal = '';
      
      if (sortOrder === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });
  }

  const totalPages = Math.ceil(filteredData.length / pageSize);
  const paginatedData = filteredData.slice(page * pageSize, (page + 1) * pageSize);

  const handleSort = (field) => {
    if (!sortable || !field) return;
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
         {searchable && (
           <div className="relative flex-1 max-w-sm">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
             <Input
               placeholder={searchPlaceholder}
               value={search}
               onChange={(e) => handleSearchChange(e.target.value)}
               className="pl-9 bg-card border-border"
             />
           </div>
         )}
         <div className="flex items-center gap-2">
           {actions}
           {exportable && (onExport || onExportExcel) && (
             <DropdownMenu>
               <DropdownMenuTrigger asChild>
                 <Button variant="outline" size="sm" className="gap-2">
                   <Download className="h-4 w-4" />
                   <span className="hidden sm:inline">Exportar</span>
                   <ChevronDown className="h-3 w-3" />
                 </Button>
               </DropdownMenuTrigger>
               <DropdownMenuContent align="end">
                 {onExport && (
                   <DropdownMenuItem onClick={onExport} className="gap-2">
                     <Download className="h-4 w-4" />
                     Descargar CSV
                   </DropdownMenuItem>
                 )}
                 {onExportExcel && (
                   <DropdownMenuItem onClick={onExportExcel} className="gap-2">
                     <Download className="h-4 w-4" />
                     Descargar Excel
                   </DropdownMenuItem>
                 )}
               </DropdownMenuContent>
             </DropdownMenu>
           )}
         </div>
       </div>

      {/* Desktop Table View */}
      <div className="hidden md:block rounded-xl border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/80 hover:bg-muted/80">
              {selectable && (
                <TableHead className="w-10">
                  <Checkbox
                    checked={
                      paginatedData.filter(r => !selectableFilter || selectableFilter(r)).length > 0 &&
                      paginatedData.filter(r => !selectableFilter || selectableFilter(r)).every(r => selectedIds.has(r.id))
                    }
                    onCheckedChange={toggleAll}
                  />
                </TableHead>
              )}
              {columns.map((col, i) => (
                <TableHead 
                  key={i} 
                  className={cn(
                    "text-muted-foreground font-semibold text-xs uppercase tracking-wide",
                    sortable && col.accessorKey && "cursor-pointer hover:bg-muted select-none",
                    col.className
                  )}
                  onClick={() => handleSort(col.accessorKey)}
                >
                  <div className="flex items-center gap-2">
                    {col.header}
                    {sortable && col.accessorKey && (
                      <span className={cn(
                        "transition-opacity",
                        sortField === col.accessorKey ? "opacity-100 text-foreground" : "opacity-0 group-hover:opacity-50"
                      )}>
                        {sortField === col.accessorKey ? (
                          sortOrder === 'asc' ? '↑' : '↓'
                        ) : (
                          <ArrowUpDown className="h-3 w-3" />
                        )}
                      </span>
                    )}
                  </div>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedData.length === 0 ? (
              <TableRow>
                <TableCell colSpan={selectable ? columns.length + 1 : columns.length} className="h-32 text-center text-muted-foreground/70">
                  {emptyMessage}
                </TableCell>
              </TableRow>
            ) : (
              paginatedData.map((row, i) => {
                const isSelectable = !selectableFilter || selectableFilter(row);
                const isSelected = selectedIds.has(row.id);
                return (
                  <TableRow 
                    key={row.id || i} 
                    onClick={() => onRowClick?.(row)}
                    className={cn(
                      "transition-colors",
                      onRowClick && "cursor-pointer hover:bg-muted/50",
                      isSelected && "bg-muted/70"
                    )}
                  >
                    {selectable && (
                      <TableCell className="w-10" onClick={e => e.stopPropagation()}>
                        {isSelectable && (
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => toggleRow(row.id)}
                          />
                        )}
                      </TableCell>
                    )}
                    {columns.map((col, j) => (
                      <TableCell key={j} className={cn("text-foreground/80", col.cellClassName)}>
                        {col.cell ? col.cell(row) : (col.accessorKey ? row[col.accessorKey] : col.accessor?.(row))}
                      </TableCell>
                    ))}
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {paginatedData.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground/70">
              {emptyMessage}
            </CardContent>
          </Card>
        ) : (
          paginatedData.map((row, i) => {
            const isSelectable = !selectableFilter || selectableFilter(row);
            const isSelected = selectedIds.has(row.id);
            return (
            <Card 
              key={row.id || i} 
              className={cn(
                "transition-all hover:shadow-md",
                onRowClick && "cursor-pointer active:scale-[0.98]",
                isSelected && "border-border bg-muted/50"
              )}
              onClick={() => onRowClick?.(row)}
            >
              <CardContent className="p-4 space-y-3">
                {selectable && isSelectable && (
                  <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    <Checkbox checked={isSelected} onCheckedChange={() => toggleRow(row.id)} />
                    <span className="text-xs text-muted-foreground">Seleccionar</span>
                  </div>
                )}
                {columns.map((col, j) => {
                  if (!col.header) return null;
                  const value = col.cell ? col.cell(row) : (col.accessorKey ? row[col.accessorKey] : col.accessor?.(row));
                  return (
                    <div key={j} className="flex justify-between items-start gap-3">
                      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide min-w-[100px]">
                        {col.header}
                      </span>
                      <div className="flex-1 text-right text-sm text-foreground">
                        {value}
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
            );
          })
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between px-2">
          <p className="text-sm text-muted-foreground">
            Mostrando {page * pageSize + 1} - {Math.min((page + 1) * pageSize, filteredData.length)} de {filteredData.length}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm text-muted-foreground px-2">
              {page + 1} / {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}