import React, { useState, useRef } from 'react';
import { Loader2 } from 'lucide-react';

export default function PullToRefresh({ onRefresh, children }) {
  const [pulling, setPulling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const startY = useRef(0);
  const threshold = 80;

  const handleTouchStart = (e) => {
    if (window.scrollY === 0) {
      startY.current = e.touches[0].clientY;
    }
  };

  const handleTouchMove = (e) => {
    if (refreshing || window.scrollY > 0) return;
    
    const currentY = e.touches[0].clientY;
    const distance = currentY - startY.current;
    
    if (distance > 0) {
      setPulling(true);
      setPullDistance(Math.min(distance, threshold * 1.5));
    }
  };

  const handleTouchEnd = async () => {
    if (pullDistance >= threshold && !refreshing) {
      setRefreshing(true);
      try {
        await onRefresh();
      } finally {
        setRefreshing(false);
      }
    }
    setPulling(false);
    setPullDistance(0);
    startY.current = 0;
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="relative"
    >
      {/* Pull indicator */}
      <div
        className="absolute top-0 left-0 right-0 flex justify-center items-center transition-all lg:hidden"
        style={{
          height: pulling || refreshing ? '60px' : '0px',
          opacity: pulling || refreshing ? 1 : 0,
          transform: `translateY(${pulling ? Math.min(pullDistance - 60, 0) : -60}px)`
        }}
      >
        <div className="bg-card rounded-full p-3 shadow-lg">
          <Loader2 
            className={`h-5 w-5 text-brand ${refreshing ? 'animate-spin' : ''}`}
            style={{
              transform: refreshing ? '' : `rotate(${pullDistance * 2}deg)`
            }}
          />
        </div>
      </div>
      
      {children}
    </div>
  );
}