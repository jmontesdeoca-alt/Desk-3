import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, ChevronRight, Loader2 } from 'lucide-react';
import FlippableTargetCard from './FlippableTargetCard';

/**
 * Renders a collapsible group of targets for a single agent.
 * Targets (with calculated progress) are loaded on first expand and cached.
 */
export default function AgentTargetGroup({
  agentId,
  agentName,
  rawTargets,       // SalesTarget records without current_value
  policies,         // all policies (already loaded)
  agents,           // all agents (already loaded)
  onEdit,
  onDelete,
  onRefresh,
  // cache helpers
  getCached,
  setCache,
}) {
  const [expanded, setExpanded] = useState(false);
  const [loadingTargets, setLoadingTargets] = useState(false);
  const [computedTargets, setComputedTargets] = useState(null); // null = not loaded yet

  const toggle = async () => {
    const willExpand = !expanded;
    setExpanded(willExpand);

    if (willExpand && computedTargets === null) {
      // Check cache first
      const cached = getCached(agentId);
      if (cached) {
        setComputedTargets(cached);
        return;
      }

      setLoadingTargets(true);
      const results = await Promise.all(
        rawTargets.map(async (target) => {
          const { total, companyBreakdown } = await calculateCurrentValue(target, policies, agents);
          return { ...target, current_value: total, companyBreakdown };
        })
      );
      setCache(agentId, results);
      setComputedTargets(results);
      setLoadingTargets(false);
    }
  };

  // When rawTargets change (e.g. after a refresh/edit), invalidate computed cache for this agent
  const prevRawRef = useRef(rawTargets);
  useEffect(() => {
    if (prevRawRef.current !== rawTargets) {
      prevRawRef.current = rawTargets;
      setComputedTargets(null); // force re-compute on next expand
    }
  }, [rawTargets]);

  const displayTargets = computedTargets || [];

  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      {/* Header row - always visible */}
      <button
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/40 transition-colors text-left"
        onClick={toggle}
      >
        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center shrink-0">
          <span className="text-sm font-bold text-foreground">
            {(agentName || '?').charAt(0).toUpperCase()}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-foreground truncate">{agentName}</p>
          <p className="text-xs text-muted-foreground/70">
            {rawTargets.length} objetivo{rawTargets.length !== 1 ? 's' : ''}
          </p>
        </div>
        {loadingTargets ? (
          <Loader2 className="h-4 w-4 text-muted-foreground/70 animate-spin shrink-0" />
        ) : expanded ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground/70 shrink-0" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground/70 shrink-0" />
        )}
      </button>

      {/* Expanded content */}
      {expanded && !loadingTargets && (
        <div className="border-t divide-y">
          {displayTargets.map(target => (
            <div key={target.id} className="p-3">
              <FlippableTargetCard
                target={target}
                onEdit={onEdit}
                onDelete={onDelete}
                onRefresh={onRefresh}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── helpers (same logic as SalesTargets page) ───────────────────────────────

function getAgentStructure(agentId, allAgents) {
  const root = allAgents.find(a => a.id === agentId);
  const result = root ? [root] : [];
  allAgents.filter(a => a.upline_agent_id === agentId).forEach(child => {
    result.push(...getAgentStructure(child.id, allAgents));
  });
  return result;
}

async function calculateCurrentValue(target, allPolicies, allAgents) {
  const startDate = new Date(target.start_date);
  const endDate = new Date(target.end_date);

  let relevant = allPolicies.filter(p => {
    if (!p.start_date) return false;
    // Exclude cancelled policies
    if (p.status === 'cancelada') return false;
    const d = new Date(p.start_date + 'T00:00:00');
    const start = new Date(target.start_date + 'T00:00:00');
    const end = new Date(target.end_date + 'T00:00:00');
    return d >= start && d <= end;
  });

  if (target.target_type === 'individual') {
    relevant = relevant.filter(p => p.agent_id === target.agent_id);
  } else if (target.target_type === 'structure') {
    const ids = new Set(getAgentStructure(target.agent_id, allAgents).map(a => a.id));
    relevant = relevant.filter(p => ids.has(p.agent_id));
  }

  if (target.companies && target.companies.length > 0) {
    const ids = new Set(target.companies.map(c => c.company_id));
    relevant = relevant.filter(p => ids.has(p.company_id));
  }

  if (!target.all_lines && target.lines && target.lines.length > 0) {
    const ids = new Set(target.lines.map(l => l.line_id));
    relevant = relevant.filter(p => ids.has(p.line_id));
  }

  const getValue = (p) => {
    switch (target.metric) {
      case 'new_policies': return 1;
      case 'premium_volume': return p.annual_premium || 0;
      case 'commission_value': return p.commissionable_premium || 0;
      default: return 0;
    }
  };

  const total = relevant.reduce((sum, p) => sum + getValue(p), 0);

  const companyMap = {};
  relevant.forEach(p => {
    if (!p.company_id) return;
    if (!companyMap[p.company_id]) {
      companyMap[p.company_id] = { company_id: p.company_id, company_name: p.company_name || 'Sin nombre', value: 0 };
    }
    companyMap[p.company_id].value += getValue(p);
  });
  const companyBreakdown = Object.values(companyMap).sort((a, b) => b.value - a.value);

  return { total, companyBreakdown };
}