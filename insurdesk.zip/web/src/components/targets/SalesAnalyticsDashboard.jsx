import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line
} from 'recharts';
import { TrendingUp, Target, Briefcase, Award, AlertTriangle } from 'lucide-react';
import { formatMoney } from '@/lib/formatMoney';

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#F97316', '#84CC16'];

const fmt = (n, metric) => {
  if (metric === 'new_policies') return Math.round(n).toLocaleString();
  return '$' + formatMoney(n);
};

const pct = (current, target) => target > 0 ? Math.min(Math.round((current / target) * 100), 100) : 0;

// ── Helpers ──────────────────────────────────────────────────────────────────

function getAgentStructure(agentId, allAgents) {
  const root = allAgents.find(a => a.id === agentId);
  const result = root ? [root] : [];
  allAgents.filter(a => a.upline_agent_id === agentId).forEach(child => {
    result.push(...getAgentStructure(child.id, allAgents));
  });
  return result;
}

function calculateTargetCurrent(target, policies, agents) {
  let relevant = policies.filter(p => {
    if (!p.start_date || p.status === 'cancelada') return false;
    const d = new Date(p.start_date + 'T00:00:00');
    const start = new Date(target.start_date + 'T00:00:00');
    const end = new Date(target.end_date + 'T00:00:00');
    return d >= start && d <= end;
  });

  if (target.target_type === 'individual') {
    relevant = relevant.filter(p => p.agent_id === target.agent_id);
  } else if (target.target_type === 'structure') {
    const ids = new Set(getAgentStructure(target.agent_id, agents).map(a => a.id));
    relevant = relevant.filter(p => ids.has(p.agent_id));
  }

  if (target.companies?.length > 0) {
    const ids = new Set(target.companies.map(c => c.company_id));
    relevant = relevant.filter(p => ids.has(p.company_id));
  }

  if (!target.all_lines && target.lines?.length > 0) {
    const ids = new Set(target.lines.map(l => l.line_id));
    relevant = relevant.filter(p => ids.has(p.line_id));
  }

  const getValue = (p) => {
    switch (target.metric) {
      case 'new_policies': return 1;
      case 'premium_volume': return p.annual_premium || 0;
      case 'commission_value': return p.commissionable_premium || 0;
      default: return 0;
    }
  };

  return relevant.reduce((sum, p) => sum + getValue(p), 0);
}

// ── Tooltip personalizado ─────────────────────────────────────────────────────
const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-sm">
      <p className="font-semibold text-foreground/80 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full" style={{ background: p.color }} />
          {p.name}: <strong>{typeof p.value === 'number' && p.name !== 'Pólizas' ? '$' + formatMoney(p.value) : p.value.toLocaleString()}</strong>
        </p>
      ))}
    </div>
  );
};

// ── Sub-componentes ───────────────────────────────────────────────────────────

function StatMiniCard({ icon: Icon, label, value, sub, color }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
          <Icon className="h-5 w-5 text-white" />
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-xl font-bold text-foreground">{value}</p>
          {sub && <p className="text-xs text-muted-foreground/70">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

function AgentComplianceChart({ targets, policies, agents }) {
  const data = useMemo(() => {
    const agentMap = {};
    targets.forEach(t => {
      if (!agentMap[t.agent_id]) agentMap[t.agent_id] = { name: t.agent_name?.split(' ')[0] || 'Agente', total: 0, target: 0, count: 0 };
      const current = calculateTargetCurrent(t, policies, agents);
      agentMap[t.agent_id].total += current;
      agentMap[t.agent_id].target += (t.target_value || 0);
      agentMap[t.agent_id].count += 1;
    });
    return Object.values(agentMap)
      .map(a => ({ ...a, cumplimiento: pct(a.total, a.target) }))
      .sort((a, b) => b.cumplimiento - a.cumplimiento)
      .slice(0, 10);
  }, [targets, policies, agents]);

  if (!data.length) return <p className="text-center text-muted-foreground/70 py-8">Sin datos</p>;

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} layout="vertical" margin={{ left: 10, right: 30 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis type="number" domain={[0, 100]} tickFormatter={v => `${v}%`} tick={{ fontSize: 11 }} />
        <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={80} />
        <Tooltip content={({ active, payload, label }) => {
          if (!active || !payload?.length) return null;
          return (
            <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-sm">
              <p className="font-semibold text-foreground/80">{label}</p>
              <p className="text-foreground">Cumplimiento: <strong>{payload[0]?.value}%</strong></p>
            </div>
          );
        }} />
        <Bar dataKey="cumplimiento" name="Cumplimiento" radius={[0, 4, 4, 0]}>
          {data.map((entry, i) => (
            <Cell key={i} fill={entry.cumplimiento >= 100 ? '#10B981' : entry.cumplimiento >= 70 ? '#3B82F6' : entry.cumplimiento >= 40 ? '#F59E0B' : '#EF4444'} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function MetricDistributionChart({ targets }) {
  const data = useMemo(() => {
    const counts = { new_policies: 0, premium_volume: 0, commission_value: 0 };
    targets.forEach(t => { if (counts[t.metric] !== undefined) counts[t.metric]++; });
    return [
      { name: 'Pólizas Nuevas', value: counts.new_policies },
      { name: 'Vol. Prima', value: counts.premium_volume },
      { name: 'Comisiones', value: counts.commission_value },
    ].filter(d => d.value > 0);
  }, [targets]);

  if (!data.length) return <p className="text-center text-muted-foreground/70 py-8">Sin datos</p>;

  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
          {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Pie>
        <Tooltip />
        <Legend iconType="circle" iconSize={8} formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
      </PieChart>
    </ResponsiveContainer>
  );
}

function BudgetComplianceChart({ budgets }) {
  const data = useMemo(() =>
    budgets
      .filter(b => b.target_amount > 0)
      .map(b => ({
        name: b.name?.length > 16 ? b.name.slice(0, 14) + '…' : b.name,
        objetivo: b.target_amount,
        alcanzado: b.total || 0,
        pct: pct(b.total || 0, b.target_amount)
      }))
      .sort((a, b) => b.pct - a.pct)
      .slice(0, 6),
    [budgets]
  );

  if (!data.length) return <p className="text-center text-muted-foreground/70 py-8">Sin presupuestos</p>;

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data} margin={{ left: 0, right: 10, bottom: 30 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-25} textAnchor="end" interval={0} />
        <YAxis tick={{ fontSize: 11 }} tickFormatter={v => '$' + (v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v)} />
        <Tooltip content={<CustomTooltip />} />
        <Legend iconSize={8} formatter={(v) => <span className="text-xs">{v}</span>} />
        <Bar dataKey="objetivo" name="Objetivo" fill="#CBD5E1" radius={[4, 4, 0, 0]} />
        <Bar dataKey="alcanzado" name="Alcanzado" radius={[4, 4, 0, 0]}>
          {data.map((entry, i) => (
            <Cell key={i} fill={entry.pct >= 100 ? '#10B981' : entry.pct >= 70 ? '#3B82F6' : entry.pct >= 40 ? '#F59E0B' : '#EF4444'} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function MonthlyTrendChart({ policies }) {
  const data = useMemo(() => {
    const monthMap = {};
    policies
      .filter(p => p.start_date && p.status !== 'cancelada')
      .forEach(p => {
        const d = new Date(p.start_date + 'T00:00:00');
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        if (!monthMap[key]) monthMap[key] = { mes: key, polizas: 0, prima: 0 };
        monthMap[key].polizas += 1;
        monthMap[key].prima += p.annual_premium || 0;
      });
    return Object.values(monthMap).sort((a, b) => a.mes.localeCompare(b.mes)).slice(-12);
  }, [policies]);

  if (!data.length) return <p className="text-center text-muted-foreground/70 py-8">Sin datos</p>;

  const fmt12 = (v) => {
    const [y, m] = v.split('-');
    return ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'][parseInt(m) - 1] + ' ' + y.slice(2);
  };

  return (
    <ResponsiveContainer width="100%" height={220}>
      <LineChart data={data} margin={{ left: 0, right: 10 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="mes" tickFormatter={fmt12} tick={{ fontSize: 10 }} />
        <YAxis yAxisId="left" tick={{ fontSize: 10 }} tickFormatter={v => v >= 1000 ? (v/1000).toFixed(0)+'k' : v} />
        <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} tickFormatter={v => '$' + (v >= 1000 ? (v/1000).toFixed(0)+'k' : v)} />
        <Tooltip content={({ active, payload, label }) => {
          if (!active || !payload?.length) return null;
          return (
            <div className="bg-card border border-border rounded-lg p-3 shadow-lg text-sm">
              <p className="font-semibold text-foreground/80 mb-1">{fmt12(label)}</p>
              <p className="text-foreground">Pólizas: <strong>{payload[0]?.value}</strong></p>
              <p className="text-emerald-600 dark:text-emerald-400">Prima: <strong>${formatMoney(payload[1]?.value)}</strong></p>
            </div>
          );
        }} />
        <Line yAxisId="left" type="monotone" dataKey="polizas" name="Pólizas" stroke="#3B82F6" strokeWidth={2} dot={{ r: 3 }} />
        <Line yAxisId="right" type="monotone" dataKey="prima" name="Prima" stroke="#10B981" strokeWidth={2} dot={{ r: 3 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

function TopAgentsTable({ targets, policies, agents }) {
  const rows = useMemo(() => {
    const agentMap = {};
    targets.filter(t => t.status === 'activo').forEach(t => {
      if (!agentMap[t.agent_id]) agentMap[t.agent_id] = { name: t.agent_name, targets: [] };
      const current = calculateTargetCurrent(t, policies, agents);
      agentMap[t.agent_id].targets.push({ metric: t.metric, current, target: t.target_value });
    });
    return Object.values(agentMap)
      .map(a => {
        const avgPct = a.targets.length
          ? Math.round(a.targets.reduce((s, t) => s + pct(t.current, t.target), 0) / a.targets.length)
          : 0;
        return { name: a.name, avgPct, count: a.targets.length };
      })
      .sort((a, b) => b.avgPct - a.avgPct)
      .slice(0, 5);
  }, [targets, policies, agents]);

  if (!rows.length) return null;

  return (
    <div className="space-y-2">
      {rows.map((r, i) => (
        <div key={r.name} className="flex items-center gap-3">
          <div className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
            i === 0 ? 'bg-yellow-400 text-white' : i === 1 ? 'bg-muted-foreground/30 text-foreground/80' : i === 2 ? 'bg-amber-600 text-white' : 'bg-muted text-muted-foreground'
          }`}>
            {i + 1}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-center mb-0.5">
              <span className="text-sm font-medium text-foreground/80 truncate">{r.name}</span>
              <span className={`text-xs font-bold ${r.avgPct >= 100 ? 'text-emerald-600 dark:text-emerald-400' : r.avgPct >= 70 ? 'text-foreground' : 'text-amber-600 dark:text-amber-400'}`}>
                {r.avgPct}%
              </span>
            </div>
            <Progress value={r.avgPct} className="h-1.5" />
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function SalesAnalyticsDashboard({ targets, budgets, policies, agents }) {
  const activeTargets = targets.filter(t => t.status === 'activo');

  const summary = useMemo(() => {
    let onTrack = 0, atRisk = 0, behind = 0;
    activeTargets.forEach(t => {
      const current = calculateTargetCurrent(t, policies, agents);
      const p = pct(current, t.target_value);
      if (p >= 80) onTrack++;
      else if (p >= 40) atRisk++;
      else behind++;
    });
    const budgetPct = budgets.length
      ? Math.round(budgets.reduce((s, b) => s + pct(b.total || 0, b.target_amount), 0) / budgets.length)
      : 0;
    return { onTrack, atRisk, behind, budgetPct, total: activeTargets.length };
  }, [activeTargets, policies, agents, budgets]);

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatMiniCard icon={Target} label="Objetivos activos" value={summary.total} sub={`${summary.onTrack} al día`} color="bg-primary" />
        <StatMiniCard icon={TrendingUp} label="En camino (≥80%)" value={summary.onTrack} color="bg-emerald-500" />
        <StatMiniCard icon={AlertTriangle} label="En riesgo (40–79%)" value={summary.atRisk} color="bg-amber-500" />
        <StatMiniCard icon={Briefcase} label="Cumpl. prom. presup." value={`${summary.budgetPct}%`} color="bg-purple-500" />
      </div>

      {/* Row 1: Trend + Agent compliance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground/80">Tendencia de Emisión (últimos 12 meses)</CardTitle>
          </CardHeader>
          <CardContent>
            <MonthlyTrendChart policies={policies} />
            <p className="text-xs text-muted-foreground/70 mt-2 text-center">Evolución mensual de pólizas emitidas (azul) y prima anual acumulada (verde). Permite identificar meses de mayor producción.</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground/80">Cumplimiento por Agente</CardTitle>
          </CardHeader>
          <CardContent>
            <AgentComplianceChart targets={activeTargets} policies={policies} agents={agents} />
            <p className="text-xs text-muted-foreground/70 mt-2 text-center">% de cumplimiento promedio de los objetivos activos por agente. Verde ≥100%, azul ≥70%, amarillo ≥40%, rojo &lt;40%.</p>
          </CardContent>
        </Card>
      </div>

      {/* Row 2: Budgets + Top agents + Metric mix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="border-0 shadow-sm lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground/80">Presupuestos de Compañía</CardTitle>
          </CardHeader>
          <CardContent>
            <BudgetComplianceChart budgets={budgets} />
            <p className="text-xs text-muted-foreground/70 mt-2 text-center">Compara el monto objetivo (gris) vs. lo alcanzado (color) en cada presupuesto de compañía configurado.</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground/80 flex items-center gap-2">
              <Award className="h-4 w-4 text-yellow-500" />
              Top Agentes (objetivos activos)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TopAgentsTable targets={activeTargets} policies={policies} agents={agents} />
            {activeTargets.length === 0 && <p className="text-center text-muted-foreground/70 py-8 text-sm">Sin objetivos activos</p>}
            <p className="text-xs text-muted-foreground/70 mt-3 text-center">Ranking de agentes según el cumplimiento promedio de todos sus objetivos activos.</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-foreground/80">Distribución de Métricas</CardTitle>
          </CardHeader>
          <CardContent>
            <MetricDistributionChart targets={targets} />
            <p className="text-xs text-muted-foreground/70 mt-2 text-center">Muestra qué tipo de métrica se usa más entre todos los objetivos creados: pólizas, prima o comisiones.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}