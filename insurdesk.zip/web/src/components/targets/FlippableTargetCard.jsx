import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Trash2, Users, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

const METRIC_COLORS = {
  premium_volume: 'bg-primary',
  new_policies: 'bg-emerald-500',
  commission_value: 'bg-amber-500',
};

export default function FlippableTargetCard({ target, onEdit, onDelete, onRefresh }) {
  const [flipped, setFlipped] = useState(false);
  const frontRef = useRef(null);
  const backRef = useRef(null);
  const [cardHeight, setCardHeight] = useState('auto');

  useEffect(() => {
    const updateHeight = () => {
      const frontH = frontRef.current?.scrollHeight || 0;
      const backH = backRef.current?.scrollHeight || 0;
      setCardHeight(Math.max(frontH, backH) + 'px');
    };
    updateHeight();
    window.addEventListener('resize', updateHeight);
    return () => window.removeEventListener('resize', updateHeight);
  }, [target]);

  const progress = Math.min(((target.current_value || 0) / target.target_value) * 100, 100);
  const isCompleted = (target.current_value || 0) >= target.target_value;

  const formatValue = (val) => {
    if (target.metric === 'new_policies') return Math.round(val || 0).toString();
    return `$${(val || 0).toLocaleString('es', { maximumFractionDigits: 0 })}`;
  };

  const hasCompanyBreakdown = target.companyBreakdown && target.companyBreakdown.length > 0;
  const hasStructureContribs = target.target_type === 'structure' && target.structure_contributions && target.structure_contributions.length > 0;
  const hasBackDetail = hasCompanyBreakdown || hasStructureContribs;

  return (
    <div
      className="relative w-full cursor-pointer"
      style={{ perspective: '1200px', height: cardHeight }}
      onClick={() => setFlipped(f => !f)}
    >
      <motion.div
        className="relative w-full"
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.5, ease: 'easeInOut' }}
        style={{ transformStyle: 'preserve-3d', height: cardHeight }}
      >
        {/* FRONT */}
        <div
          ref={frontRef}
          className="absolute inset-0 w-full rounded-xl border bg-card shadow-sm p-4 flex flex-col gap-3"
          style={{ backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden' }}
        >
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-0.5">
                <h3 className="font-semibold text-foreground truncate">{target.agent_name}</h3>
                <span className={`text-xs px-2 py-0.5 rounded flex items-center gap-1 shrink-0 ${
                  target.target_type === 'individual'
                    ? 'bg-muted text-foreground'
                    : 'bg-purple-500/10 text-purple-600 dark:text-purple-400'
                }`}>
                  {target.target_type === 'structure' && <Users className="h-3 w-3" />}
                  {target.target_type === 'individual' ? 'Individual' : 'Estructura'}
                </span>
              </div>
              <p className="text-sm text-muted-foreground flex items-center gap-1.5">
                <span className={`inline-block w-2.5 h-2.5 rounded-full shrink-0 ${METRIC_COLORS[target.metric] || 'bg-muted-foreground/50'}`} />
                {getMetricLabel(target.metric)}
              </p>
              {target.all_lines === false && target.lines && target.lines.length > 0 && (
                <p className="text-xs text-muted-foreground/70 mt-0.5">
                  Ramos: {target.lines.map(l => l.line_name).join(', ')}
                </p>
              )}
            </div>
            <div className="text-right shrink-0">
              <p className="text-xs text-muted-foreground/70">
                {new Date(target.start_date).toLocaleDateString()} – {new Date(target.end_date).toLocaleDateString()}
              </p>
              {target.bonus_amount > 0 && (
                <p className="text-sm font-medium text-emerald-600 dark:text-emerald-400 mt-0.5">
                  💰 Bono: {formatValue(target.bonus_amount)}
                </p>
              )}
            </div>
          </div>

          {/* Companies chips */}
          {target.companies && target.companies.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {target.companies.map((c, i) => (
                <span key={i} className="text-xs bg-muted text-muted-foreground rounded px-2 py-0.5 flex items-center gap-1">
                  <Building2 className="h-3 w-3" />
                  {c.company_name}
                </span>
              ))}
            </div>
          )}

          {/* Progress */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progreso</span>
              <span className="font-semibold text-foreground">
                {formatValue(target.current_value)} / {formatValue(target.target_value)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Progress value={progress} className="flex-1 h-2" />
              <span className="text-sm font-medium text-muted-foreground w-10 text-right">{progress.toFixed(0)}%</span>
            </div>
          </div>

          {isCompleted && (
            <div className="text-sm font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              ¡Objetivo completado!
            </div>
          )}

          {/* Structure contributions shown on FRONT */}
          {hasStructureContribs && (
            <div className="bg-purple-500/10 rounded-lg p-3 space-y-1">
              <p className="text-xs font-medium text-purple-600 dark:text-purple-400 mb-1 flex items-center gap-1">
                <Users className="h-3 w-3" /> Aporte por Agente
              </p>
              {target.structure_contributions.map((contrib, idx) => (
                <div key={idx} className="flex justify-between text-xs">
                  <span className="text-muted-foreground truncate max-w-[70%]">{contrib.agent_name}</span>
                  <span className="font-medium text-purple-600 dark:text-purple-400">{formatValue(contrib.contribution_value)}</span>
                </div>
              ))}
            </div>
          )}

          {hasCompanyBreakdown && (
            <p className="text-xs text-muted-foreground/70 text-center">Toca para ver detalle por compañía →</p>
          )}

          {/* Actions */}
          <div
            className="flex justify-end gap-2 pt-2 border-t mt-auto flex-wrap"
            onClick={e => e.stopPropagation()}
          >
            {target.target_type === 'structure' && (
              <Button variant="ghost" size="sm" className="text-foreground hover:text-foreground" onClick={() => onRefresh(target)}>
                🔄 Actualizar
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => onEdit(target)}>✏️ Editar</Button>
            <Button variant="ghost" size="sm" onClick={() => onDelete(target.id)} className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* BACK */}
        <div
          ref={backRef}
          className="absolute inset-0 w-full rounded-xl border bg-gradient-to-br from-blue-50 to-background shadow-sm p-4 flex flex-col gap-3"
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-foreground" />
              <h3 className="font-semibold text-foreground">Detalle por Compañía</h3>
            </div>
            <span className="text-xs text-muted-foreground/70 truncate max-w-[40%]">{target.agent_name}</span>
          </div>

          {/* Company breakdown — always shown on back if available */}
          {hasCompanyBreakdown ? (
            <div className="space-y-2 overflow-y-auto flex-1">
              {target.companyBreakdown.map((co, idx) => {
                const pct = (target.current_value || 0) > 0 ? (co.value / target.current_value) * 100 : 0;
                return (
                  <div key={idx} className="space-y-0.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-foreground/80 truncate max-w-[65%] flex items-center gap-1">
                        <Building2 className="h-3 w-3 text-muted-foreground/70 shrink-0" />
                        {co.company_name}
                      </span>
                      <span className="font-semibold text-foreground">{formatValue(co.value)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-secondary rounded-full h-1.5">
                        <div className="bg-primary h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground/70 w-8 text-right">{pct.toFixed(0)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}

          {!hasBackDetail && (
            <p className="text-sm text-muted-foreground text-center py-6">Sin detalle adicional</p>
          )}

          {/* Actions on back */}
          <div
            className="flex items-center justify-between pt-2 border-t mt-auto flex-wrap gap-2"
            onClick={e => e.stopPropagation()}
          >
            <p className="text-xs text-muted-foreground/70">← Toca para volver</p>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => { onEdit(target); setFlipped(false); }}>✏️ Editar</Button>
              <Button variant="ghost" size="sm" onClick={() => onDelete(target.id)} className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function getMetricLabel(metric) {
  const labels = {
    new_policies: 'Pólizas Nuevas',
    premium_volume: 'Volumen de Prima',
    commission_value: 'Valor en Comisiones'
  };
  return labels[metric] || metric;
}