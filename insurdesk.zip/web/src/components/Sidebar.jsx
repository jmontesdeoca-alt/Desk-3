import React, { memo } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { Search, LogOut, ChevronLeft, UserCircle, Sun, Moon } from 'lucide-react';
import { useTheme } from '@/lib/theme';
import BellNotifications from '@/components/BellNotifications';
import BrandLogo from '@/components/BrandLogo';
import { BRAND } from '@/lib/brand';

function Sidebar({
  user,
  sidebarCollapsed,
  setSidebarCollapsed,
  navItems,
  onSearchOpen,
  onLogout
}) {
  const location = useLocation();
  const { isDark, toggle } = useTheme();
  const isActivePage = (path) => location.pathname.includes(path);

  return (
    <aside
      className={`hidden lg:flex fixed top-0 left-0 bottom-0 z-50 flex-col bg-sidebar border-r border-sidebar-border transition-[width] duration-300 ease-out ${sidebarCollapsed ? 'w-16' : 'w-64'}`}
      style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className={`flex items-center shrink-0 ${sidebarCollapsed ? 'flex-col justify-center gap-2 py-3' : 'justify-between px-4 h-16'}`}>
        <Link to={createPageUrl('Dashboard')} className="flex items-center" aria-label={BRAND.name}>
          {sidebarCollapsed ? <BrandLogo variant="icon" className="h-8 w-8" /> : <BrandLogo className="h-7 w-auto" />}
        </Link>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="text-muted-foreground hover:text-foreground shrink-0 h-8 w-8"
        >
          <ChevronLeft className={`h-4 w-4 transition-transform duration-300 ${sidebarCollapsed ? 'rotate-180' : ''}`} />
        </Button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5">
        {navItems.map((item, idx) => {
          if (item.heading) return sidebarCollapsed ? <div key={`h-${idx}`} className="my-2 mx-3 border-t border-sidebar-border" /> : <p key={`h-${idx}`} className="px-3 pt-4 pb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">{item.heading}</p>;
          const Icon = item.icon;
          const active = isActivePage(item.path);
          return (
            <Link key={item.path} to={createPageUrl(item.path)} title={sidebarCollapsed ? item.name : undefined}>
              <div
                className={`flex items-center h-9 rounded-lg text-sm transition-colors ${sidebarCollapsed ? 'justify-center' : 'gap-3 px-3'} ${
                  active
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground font-medium'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground'
                }`}
              >
                <Icon className={`h-[18px] w-[18px] shrink-0 ${active ? 'text-foreground' : ''}`} />
                {!sidebarCollapsed && <span className="truncate">{item.name}</span>}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="shrink-0 px-3 py-3 border-t border-sidebar-border space-y-1">
        <button
          type="button"
          className={`flex w-full items-center h-9 rounded-lg border border-input bg-background/40 text-sm text-muted-foreground hover:text-foreground hover:border-ring/50 transition-colors ${sidebarCollapsed ? 'justify-center' : 'gap-2 px-3'}`}
          onClick={onSearchOpen}
        >
          <Search className="h-4 w-4 shrink-0" />
          {!sidebarCollapsed && <span>Buscar…</span>}
        </button>
        {user && (
          <Link to={createPageUrl('UserProfile')}>
            <div className={`flex items-center ${sidebarCollapsed ? 'justify-center' : 'gap-3 px-3'} py-2 rounded-lg hover:bg-sidebar-accent/70 transition-colors`}>
              <UserCircle className="h-6 w-6 shrink-0 text-muted-foreground" />
              {!sidebarCollapsed && (
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{user.display_name || user.full_name}</p>
                  <p className="text-xs text-muted-foreground capitalize truncate">{user.app_role || user.role}</p>
                </div>
              )}
            </div>
          </Link>
        )}
        <div className={`flex ${sidebarCollapsed ? 'flex-col items-center' : 'items-center justify-between'} pt-1 px-1`}>
          <BellNotifications />
          <Button
            variant="ghost"
            size="icon"
            onClick={toggle}
            title={isDark ? 'Modo claro' : 'Modo oscuro'}
            className="text-muted-foreground hover:text-foreground h-9 w-9"
          >
            {isDark ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onLogout}
            className="text-muted-foreground hover:text-foreground h-9 w-9"
          >
            <LogOut className="h-[18px] w-[18px]" />
          </Button>
        </div>
      </div>
    </aside>
  );
}

export default memo(Sidebar);
