import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Award, TrendingUp } from 'lucide-react';

export default function AgentDetailModal({ 
  open, 
  onOpenChange, 
  agent, 
  badges, 
  stats, 
  metric,
  chartData 
}) {
  const [persistence, setPersistence] = useState(null);
  const [loadingPersistence, setLoadingPersistence] = useState(false);

  useEffect(() => {
    if (open && agent) {
      calculatePersistence();
    }
  }, [open, agent]);

  const calculatePersistence = async () => {
    setLoadingPersistence(true);
    try {
      // Fecha actual y fecha de hace 12 meses
      const now = new Date();
      const twelveMonthsAgo = new Date(now.getFullYear() - 1, now.getMonth(), 1);
      const currentPeriodStart = new Date(now.getFullYear(), now.getMonth(), 1);

      // Obtener pólizas de renovación del periodo actual del agente
      const renewalPolicies = await api.entities.Policy.filter({
        agent_id: agent.id,
        policy_type: 'renovacion',
        start_date: { $gte: currentPeriodStart.toISOString().split('T')[0] }
      });

      if (renewalPolicies.length === 0) {
        setPersistence(0);
        setLoadingPersistence(false);
        return;
      }

      // Obtener los IDs de las pólizas originales
      const originalPolicyIds = renewalPolicies
        .map(p => p.renewed_from_policy_id)
        .filter(id => id);

      if (originalPolicyIds.length === 0) {
        setPersistence(0);
        setLoadingPersistence(false);
        return;
      }

      // Obtener las pólizas originales
      const allPolicies = await api.entities.Policy.list();
      const originalPolicies = allPolicies.filter(p => originalPolicyIds.includes(p.id));

      // Calcular suma de primas
      const totalRenewedPremium = renewalPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
      const totalOriginalPremium = originalPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);

      // Calcular porcentaje de persistencia
      const persistencePercentage = totalOriginalPremium > 0 
        ? (totalRenewedPremium / totalOriginalPremium) * 100 
        : 0;

      setPersistence(persistencePercentage);
    } catch (error) {
      console.error('Error calculating persistence:', error);
      setPersistence(0);
    }
    setLoadingPersistence(false);
  };

  if (!agent) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{agent.name}</DialogTitle>
        </DialogHeader>

        {/* Estadísticas Clave */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="pt-6 text-center">
              <p className="text-3xl font-bold text-foreground">
                {metric === 'commissions' 
                  ? `$${agent.value.toFixed(0)}` 
                  : metric === 'premium'
                  ? `$${agent.value.toFixed(0)}`
                  : agent.value}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                {metric === 'policies' ? 'Pólizas' : metric === 'premium' ? 'Prima Total' : 'Comisiones'}
              </p>
            </CardContent>
          </Card>

          {stats && (
            <>
              <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100">
                <CardContent className="pt-6 text-center">
                  <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">{stats.policies}</p>
                  <p className="text-sm text-muted-foreground mt-2">Pólizas</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
                <CardContent className="pt-6 text-center">
                  <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">${stats.premium.toFixed(0)}</p>
                  <p className="text-sm text-muted-foreground mt-2">Prima</p>
                </CardContent>
              </Card>
            </>
          )}

          <Card className="bg-gradient-to-br from-amber-50 to-amber-100">
            <CardContent className="pt-6 text-center">
              {loadingPersistence ? (
                <p className="text-2xl text-muted-foreground/70">...</p>
              ) : (
                <>
                  <div className="flex items-center justify-center gap-1">
                    <TrendingUp className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                    <p className="text-3xl font-bold text-amber-600 dark:text-amber-400">
                      {persistence !== null ? `${persistence.toFixed(1)}%` : 'N/A'}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">Persistencia</p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Insignias */}
        {badges && badges.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Insignias ({badges.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {badges.map(badge => (
                  <div key={badge.id} className="flex items-center gap-3 p-3 bg-muted/40 rounded-lg">
                    <span className="text-3xl">{badge.icon}</span>
                    <div>
                      <p className="font-medium text-foreground text-sm">{badge.name}</p>
                      <p className="text-xs text-muted-foreground">{badge.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Gráfico de Rendimiento */}
        {chartData && chartData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Rendimiento a lo Largo del Tiempo</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#0A8FBE" 
                    name={metric === 'policies' ? 'Pólizas' : metric === 'premium' ? 'Prima ($)' : 'Comisiones ($)'}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </DialogContent>
    </Dialog>
  );
}