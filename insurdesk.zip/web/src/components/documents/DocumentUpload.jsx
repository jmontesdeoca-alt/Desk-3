import React, { useState } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Upload, Loader2, X } from "lucide-react";
import { toast } from "sonner";

export default function DocumentUpload({ 
  open, 
  onClose, 
  entityType, 
  entityId, 
  entityReference,
  onUploadComplete 
}) {
  const [file, setFile] = useState(null);
  const [documentType, setDocumentType] = useState('');
  const [description, setDescription] = useState('');
  const [uploading, setUploading] = useState(false);

  const documentTypes = {
    Policy: [
      { value: 'certificado', label: 'Certificado' },
      { value: 'endoso', label: 'Endoso' },
      { value: 'poliza_original', label: 'Póliza Original' },
      { value: 'recibo', label: 'Recibo' },
      { value: 'otro', label: 'Otro' }
    ],
    Client: [
      { value: 'identificacion', label: 'Identificación' },
      { value: 'otro', label: 'Otro' }
    ],
    Claim: [
      { value: 'siniestro_evidencia', label: 'Evidencia' },
      { value: 'informe_medico', label: 'Informe Médico' },
      { value: 'factura', label: 'Factura' },
      { value: 'otro', label: 'Otro' }
    ],
    Payment: [
      { value: 'pago_escaneado', label: 'Comprobante de Pago' },
      { value: 'recibo', label: 'Recibo' },
      { value: 'otro', label: 'Otro' }
    ],
    Endorsement: [
      { value: 'endoso', label: 'Endoso' },
      { value: 'otro', label: 'Otro' }
    ]
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      // Validate file size (max 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        toast.error('El archivo es muy grande. Máximo 10MB');
        return;
      }
      setFile(selectedFile);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file || !documentType) {
      toast.error('Por favor selecciona un archivo y tipo de documento');
      return;
    }

    setUploading(true);
    try {
      const currentUser = await api.auth.me();
      
      // Upload file to Azure Blob Storage — convert to base64 for JSON transport
      const arrayBuffer = await file.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);
      let binary = '';
      const chunkSize = 8192;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
      }
      const base64 = btoa(binary);

      const azureRes = await api.functions.invoke('uploadAzureDocument', {
        fileBase64: base64,
        fileName: file.name,
        mimeType: file.type || 'application/octet-stream',
        clienteId: entityType === 'Client' ? entityId : (entityReference || entityId),
        polizaId: entityId,
        carpeta: entityType === 'Client' ? 'cliente' : 'compania',
        tipoDocumento: documentType
      });
      const { blobPath, fileName, contentType, size, url } = azureRes.data;

      // Check if there's a current version of this document type for this entity
      const existingDocs = await api.entities.Document.filter({
        entity_type: entityType,
        entity_id: entityId,
        document_type: documentType,
        is_current_version: true
      });

      let version = 1;
      let previousVersionId = null;

      if (existingDocs.length > 0) {
        const latestDoc = existingDocs[0];
        version = (latestDoc.version || 1) + 1;
        previousVersionId = latestDoc.id;
        await api.entities.Document.update(latestDoc.id, { is_current_version: false });
      }

      // Create document record with Azure blob path
      await api.entities.Document.create({
        file_name: fileName,
        file_url: url,
        file_type: contentType,
        file_size: size,
        document_type: documentType,
        entity_type: entityType,
        entity_id: entityId,
        entity_reference: entityReference,
        version,
        previous_version_id: previousVersionId,
        is_current_version: true,
        description,
        uploaded_by: currentUser.email,
        upload_date: new Date().toISOString().split('T')[0],
        blob_path: blobPath
      });

      toast.success('Documento cargado exitosamente');
      onUploadComplete?.();
      handleClose();
    } catch (error) {
      console.error('Error uploading document:', error);
      toast.error('Error al cargar el documento');
    } finally {
      setUploading(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setDocumentType('');
    setDescription('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Cargar Documento</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Tipo de Documento *</Label>
            <Select value={documentType} onValueChange={setDocumentType}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona tipo" />
              </SelectTrigger>
              <SelectContent>
                {documentTypes[entityType]?.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Archivo *</Label>
            <div className="border-2 border-dashed border-input rounded-lg p-6 text-center">
              {!file ? (
                <label className="cursor-pointer">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground/70 mb-2" />
                  <p className="text-sm text-muted-foreground">Click para seleccionar archivo</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">Máximo 10MB</p>
                  <Input
                    type="file"
                    onChange={handleFileChange}
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                  />
                </label>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="text-left">
                    <p className="text-sm font-medium text-foreground">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024).toFixed(0)} KB
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => setFile(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Descripción</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descripción o notas sobre el documento..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={uploading}>
              {uploading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Cargar Documento
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}