import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, FileImage, FileSpreadsheet, FileArchive, File,
  Download, Clock, User, Upload, Trash2,
  ChevronDown, ChevronUp, Loader2 
} from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { toast } from "sonner";
import DocumentUpload from './DocumentUpload';

export default function DocumentList({ entityType, entityId, entityReference, currentUser }) {
  const [documents, setDocuments] = useState([]);
  const [inheritedDocuments, setInheritedDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUpload, setShowUpload] = useState(false);
  const [expandedDocs, setExpandedDocs] = useState(new Set());
  const [docToDelete, setDocToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (entityId) {
      loadDocuments();
    }
  }, [entityId]);

  const loadDocuments = async () => {
    setLoading(true);
    try {
      const docs = await api.entities.Document.filter({
        entity_type: entityType,
        entity_id: entityId
      }, '-upload_date');
      setDocuments(docs);

      // If it's a policy, check if it's a renewal and load inherited docs from original policy chain
      if (entityType === 'Policy') {
        const policy = await api.entities.Policy.filter({ id: entityId });
        if (policy[0]?.renewed_from_policy_id) {
          // Walk the renewal chain and collect all ancestor policy IDs
          const ancestorIds = [];
          let currentPolicyId = policy[0].renewed_from_policy_id;
          while (currentPolicyId) {
            ancestorIds.push(currentPolicyId);
            const ancestor = await api.entities.Policy.filter({ id: currentPolicyId });
            currentPolicyId = ancestor[0]?.renewed_from_policy_id || null;
          }
          if (ancestorIds.length > 0) {
            // Load docs from all ancestors
            const allInherited = [];
            for (const aid of ancestorIds) {
              const ancestorDocs = await api.entities.Document.filter({
                entity_type: 'Policy',
                entity_id: aid
              }, '-upload_date');
              allInherited.push(...ancestorDocs);
            }
            setInheritedDocuments(allInherited);
          }
        } else {
          setInheritedDocuments([]);
        }
      }
    } catch (error) {
      console.error('Error loading documents:', error);
      toast.error('Error al cargar documentos');
    } finally {
      setLoading(false);
    }
  };

  const getFileIcon = (doc) => {
    const mime = (doc.file_type || '').toLowerCase();
    const name = (doc.file_name || '').toLowerCase();
    if (mime.includes('pdf') || name.endsWith('.pdf')) return <FileText className="h-9 w-9 text-red-500" />;
    if (mime.includes('image') || /\.(jpg|jpeg|png|gif|webp|svg)$/.test(name)) return <FileImage className="h-9 w-9 text-foreground" />;
    if (mime.includes('spreadsheet') || mime.includes('excel') || /\.(xls|xlsx|csv)$/.test(name)) return <FileSpreadsheet className="h-9 w-9 text-green-600 dark:text-green-400" />;
    if (mime.includes('zip') || mime.includes('rar') || /\.(zip|rar|7z)$/.test(name)) return <FileArchive className="h-9 w-9 text-yellow-500" />;
    if (mime.includes('word') || /\.(doc|docx)$/.test(name)) return <FileText className="h-9 w-9 text-foreground" />;
    return <File className="h-9 w-9 text-muted-foreground/70" />;
  };

  const handleDownload = async (doc) => {
    try {
      let url = doc.file_url;
      // If stored in Azure (has blob_path), get a fresh SAS URL
      if (doc.blob_path) {
        const res = await api.functions.invoke('getAzureDocumentUrl', {
          blobPath: doc.blob_path,
          expiresInSeconds: 300
        });
        url = res.data.url;
      }
      window.open(url, '_blank');
    } catch (error) {
      console.error('Error opening document:', error);
      toast.error('Error al abrir el documento');
    }
  };

  const handleDelete = async () => {
    if (!docToDelete) return;
    setDeleting(true);
    try {
      await api.functions.invoke('deleteAzureDocument', {
        documentId: docToDelete.id,
        blobPath: docToDelete.blob_path || null,
        fileUrl: docToDelete.file_url || null
      });
      toast.success('Documento eliminado');
      setDocToDelete(null);
      loadDocuments();
    } catch (error) {
      console.error('Error deleting document:', error);
      toast.error('Error al eliminar el documento');
    } finally {
      setDeleting(false);
    }
  };

  const toggleExpanded = (docId) => {
    setExpandedDocs(prev => {
      const next = new Set(prev);
      if (next.has(docId)) {
        next.delete(docId);
      } else {
        next.add(docId);
      }
      return next;
    });
  };

  const getVersionHistory = (doc) => {
    return documents.filter(d => 
      d.document_type === doc.document_type &&
      d.entity_id === doc.entity_id &&
      !d.is_current_version
    ).sort((a, b) => b.version - a.version);
  };

  const documentTypeLabels = {
    certificado: 'Certificado',
    endoso: 'Endoso',
    pago_escaneado: 'Comprobante de Pago',
    recibo: 'Recibo',
    poliza_original: 'Póliza Original',
    identificacion: 'Identificación',
    siniestro_evidencia: 'Evidencia',
    informe_medico: 'Informe Médico',
    factura: 'Factura',
    otro: 'Otro'
  };

  const currentDocuments = documents.filter(d => d.is_current_version);
  const currentInherited = inheritedDocuments.filter(d => d.is_current_version);

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">Documentos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground/70" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-0 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Documentos ({currentDocuments.length + currentInherited.length})
          </CardTitle>
          <Button 
            onClick={() => setShowUpload(true)}
            size="sm"
            className="gap-2"
          >
            <Upload className="h-4 w-4" />
            Cargar Documento
          </Button>
        </CardHeader>
        <CardContent>
          {currentDocuments.length === 0 && currentInherited.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground/70">
              <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No hay documentos adjuntos</p>
            </div>
          ) : (
            <div className="space-y-3">
              {currentDocuments.map(doc => {
                const versionHistory = getVersionHistory(doc);
                const isExpanded = expandedDocs.has(doc.id);
                
                return (
                  <div key={doc.id} className="border rounded-lg overflow-hidden">
                    <div className="p-4 bg-muted/40">
                      <div className="flex items-start justify-between gap-4">
                        {/* File icon — clickeable */}
                        <button
                          onClick={() => handleDownload(doc)}
                          className="flex-shrink-0 p-2 rounded-lg hover:bg-secondary transition-colors cursor-pointer"
                          title="Ver / Descargar"
                        >
                          {getFileIcon(doc)}
                        </button>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-medium text-foreground truncate">
                              {doc.file_name}
                            </h4>
                            <Badge variant="outline" className="text-xs">
                              {documentTypeLabels[doc.document_type]}
                            </Badge>
                            {doc.version > 1 && (
                              <Badge variant="outline" className="text-xs bg-muted text-foreground">
                                v{doc.version}
                              </Badge>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {format(new Date(doc.upload_date), 'dd MMM yyyy', { locale: es })}
                            </span>
                            <span className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {doc.uploaded_by}
                            </span>
                            <span>
                              {(doc.file_size / 1024).toFixed(0)} KB
                            </span>
                          </div>
                          {doc.description && (
                            <p className="text-sm text-muted-foreground mt-2">{doc.description}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownload(doc)}
                            className="gap-2"
                          >
                            <Download className="h-4 w-4" />
                            Abrir
                          </Button>
                          {(currentUser?.role === 'admin' || currentUser?.app_role === 'admin') && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setDocToDelete(doc)}
                              className="text-red-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-500/10"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                          {versionHistory.length > 0 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleExpanded(doc.id)}
                            >
                              {isExpanded ? (
                                <ChevronUp className="h-4 w-4" />
                              ) : (
                                <ChevronDown className="h-4 w-4" />
                              )}
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {isExpanded && versionHistory.length > 0 && (
                      <div className="border-t bg-card p-4">
                        <p className="text-sm font-medium text-foreground/80 mb-3">
                          Versiones Anteriores
                        </p>
                        <div className="space-y-2">
                          {versionHistory.map(oldDoc => (
                            <div 
                              key={oldDoc.id}
                              className="flex items-center justify-between p-3 bg-muted/40 rounded-lg"
                            >
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <p className="text-sm font-medium text-foreground/80 truncate">
                                    {oldDoc.file_name}
                                  </p>
                                  <Badge variant="outline" className="text-xs bg-muted">
                                    v{oldDoc.version}
                                  </Badge>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  {format(new Date(oldDoc.upload_date), 'dd MMM yyyy HH:mm', { locale: es })}
                                </p>
                              </div>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDownload(oldDoc)}
                              >
                                <Download className="h-3 w-3" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              {currentInherited.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wide mb-2 flex items-center gap-2">
                    <FileText className="h-3 w-3" /> Documentos heredados de póliza anterior
                  </p>
                  <div className="space-y-2">
                    {currentInherited.map(doc => (
                      <div key={doc.id} className="border rounded-lg overflow-hidden opacity-80">
                        <div className="p-3 bg-muted/40 flex items-center gap-3">
                          <button onClick={() => handleDownload(doc)} className="flex-shrink-0 p-1 rounded hover:bg-secondary transition-colors">
                            {getFileIcon(doc)}
                          </button>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-foreground text-sm truncate">{doc.file_name}</p>
                            <p className="text-xs text-muted-foreground/70">{documentTypeLabels[doc.document_type]} · {doc.entity_id}</p>
                          </div>
                          <Button variant="outline" size="sm" onClick={() => handleDownload(doc)}>
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <DocumentUpload
        open={showUpload}
        onClose={() => setShowUpload(false)}
        entityType={entityType}
        entityId={entityId}
        entityReference={entityReference}
        onUploadComplete={loadDocuments}
      />

      <AlertDialog open={!!docToDelete} onOpenChange={(open) => !open && setDocToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar documento?</AlertDialogTitle>
            <AlertDialogDescription>
              Se eliminará <strong>{docToDelete?.file_name}</strong> de forma permanente. Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}