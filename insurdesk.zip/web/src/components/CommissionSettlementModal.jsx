import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, FileText, AlertCircle } from "lucide-react";
import { api } from '@/api/client';

export default function CommissionSettlementModal({ open, onOpenChange, commissions, agentId, onGenerate, isLoading }) {
  const [adminExpensesPct, setAdminExpensesPct] = useState(0);
  const [discounts, setDiscounts] = useState(0);
  const [notes, setNotes] = useState('');
  const [pendingNegative, setPendingNegative] = useState(null);
  const [loadingNegative, setLoadingNegative] = useState(true);

  useEffect(() => {
    const loadPendingNegative = async () => {
      if (open && agentId) {
        setLoadingNegative(true);
        const negatives = await api.entities.AgentNegativeBalance.filter({ 
          agent_id: agentId, 
          status: 'pendiente' 
        });
        setPendingNegative(negatives.length > 0 ? negatives[0] : null);
        setLoadingNegative(false);
      }
    };
    loadPendingNegative();
  }, [open, agentId]);

  const totalCommissionable = parseFloat(commissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0).toFixed(2));
  const adminExpensesAmount = parseFloat(((totalCommissionable * parseFloat(adminExpensesPct || 0)) / 100).toFixed(2));
  const pendingNegativeAmount = pendingNegative ? Math.abs(pendingNegative.negative_amount) : 0;
  const totalToCollect = parseFloat((totalCommissionable - adminExpensesAmount - parseFloat(discounts || 0) - pendingNegativeAmount).toFixed(2));

  const handleGenerate = () => {
    onGenerate({
      total_commissionable: totalCommissionable,
      administrative_expenses_pct: parseFloat((parseFloat(adminExpensesPct || 0)).toFixed(2)),
      administrative_expenses_amount: adminExpensesAmount,
      discounts: parseFloat((parseFloat(discounts || 0)).toFixed(2)),
      pending_negative_amount: pendingNegativeAmount,
      pending_negative_id: pendingNegative?.id || null,
      total_to_collect: totalToCollect,
      notes: notes
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-foreground" />
            Generar Liquidación de Comisiones
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
            <p className="text-sm text-amber-600 dark:text-amber-400">
              <strong>⚠️ Liquidación Obligatoria:</strong> Para liberar las comisiones y cambiarlas a "Pendiente de Pagar", debe generar el PDF de liquidación.
            </p>
            <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">
              <strong>{commissions.length}</strong> comisión{commissions.length !== 1 ? 'es' : ''} pendiente{commissions.length !== 1 ? 's' : ''} de liberar
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Gastos Administrativos (%)</Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                max="100"
                value={adminExpensesPct}
                onChange={(e) => setAdminExpensesPct(e.target.value)}
                placeholder="0.00"
              />
              <p className="text-xs text-muted-foreground">
                Monto calculado: ${adminExpensesAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>

            <div className="space-y-2">
              <Label>Descuentos</Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                value={discounts}
                onChange={(e) => setDiscounts(e.target.value)}
                placeholder="0.00"
              />
              <p className="text-xs text-muted-foreground">Monto libre</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notas</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Observaciones, aclaraciones o detalles adicionales..."
              rows={4}
            />
          </div>

          {loadingNegative ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground/70" />
            </div>
          ) : (
            <>
              {pendingNegative && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-red-600 dark:text-red-400">Saldo Negativo Pendiente</p>
                      <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                        Este agente tiene un saldo negativo pendiente de {pendingNegative.currency} ${Math.abs(pendingNegative.negative_amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} que será descontado de esta liquidación.
                      </p>
                      {pendingNegative.origin_settlement_number && (
                        <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                          Origen: Liquidación #{pendingNegative.origin_settlement_number}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-muted/40 rounded-lg p-4 space-y-2">
                <h3 className="font-semibold text-foreground mb-3">Resumen de Liquidación</h3>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total a comisionar:</span>
                  <span className="font-medium">${totalCommissionable.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Gastos administrativos:</span>
                  <span className="font-medium text-red-600 dark:text-red-400">-${adminExpensesAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Descuentos:</span>
                  <span className="font-medium text-red-600 dark:text-red-400">-${parseFloat(discounts || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                {pendingNegative && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Negativos pendientes:</span>
                    <span className="font-medium text-red-600 dark:text-red-400">-${pendingNegativeAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                )}
                <div className="border-t border-input pt-2 mt-2">
                  <div className="flex justify-between">
                    <span className="font-bold text-foreground">Total a cobrar:</span>
                    <span className={`font-bold text-lg ${totalToCollect >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                      ${totalToCollect.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  {totalToCollect < 0 && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1 text-right">
                      Este negativo se trasladará a la próxima liquidación
                    </p>
                  )}
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
              Cancelar
            </Button>
            <Button onClick={handleGenerate} disabled={isLoading || loadingNegative}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Generar PDF y Liberar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}