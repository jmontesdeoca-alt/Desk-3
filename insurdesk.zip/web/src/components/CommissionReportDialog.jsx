import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { Loader2, FileSpreadsheet, FileText, Calendar, Filter } from 'lucide-react';
import { exportToExcel } from '@/components/ui/exportUtils';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function CommissionReportDialog({ open, onOpenChange }) {
  const [settlements, setSettlements] = useState([]);
  const [commissions, setCommissions] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [branchFilter, setBranchFilter] = useState('all');
  const [reportData, setReportData] = useState(null);

  useEffect(() => {
    if (open) loadData();
  }, [open]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [settlementsData, commissionsData, companiesData, branchesData] = await Promise.all([
        api.entities.CommissionSettlement.list('-settlement_date', 5000),
        api.entities.Commission.list('-generation_date', 10000),
        api.entities.InsuranceCompany.list('name', 1000),
        api.entities.Branch.list('name', 100)
      ]);
      setSettlements(settlementsData);
      setCommissions(commissionsData);
      setCompanies(companiesData);
      setBranches(branchesData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Error al cargar datos');
    } finally {
      setLoading(false);
    }
  };

  const buildReport = () => {
    if (!dateFrom || !dateTo) {
      toast.error('Selecciona un rango de fechas');
      return null;
    }

    const from = new Date(dateFrom);
    const to = new Date(dateTo);
    to.setHours(23, 59, 59, 999);

    // Build set of company IDs that belong to the selected branch
    const companyIdsByBranch = branchFilter !== 'all'
      ? new Set(companies.filter(comp => comp.branch_id === branchFilter).map(comp => comp.id))
      : null;

    // Build map of commission_id -> company_id for branch filtering
    const commCompanyMap = {};
    commissions.forEach(c => { commCompanyMap[c.id] = c.company_id; });

    const filtered = settlements.filter(s => {
      if (!s.settlement_date) return false;
      const d = new Date(s.settlement_date);
      if (d < from || d > to) return false;
      // Branch filter: check if any commission in this settlement belongs to a company in the branch
      if (companyIdsByBranch) {
        const settlementCommIds = s.commission_ids || [];
        const hasCommInBranch = settlementCommIds.some(cid => {
          const compId = commCompanyMap[cid];
          return compId && companyIdsByBranch.has(compId);
        });
        if (!hasCommInBranch) return false;
      }
      return true;
    });

    // Group by agent
    const agentMap = {};
    filtered.forEach(s => {
      const key = s.agent_id || 'unknown';
      if (!agentMap[key]) {
        agentMap[key] = {
          agent_name: s.agent_name || 'N/A',
          subtotal: 0,
          ga: 0,
          discounts: 0,
          total: 0,
          currency: s.currency || 'USD',
          count: 0
        };
      }
      agentMap[key].subtotal += s.total_commissionable || 0;
      agentMap[key].ga += s.administrative_expenses_amount || 0;
      agentMap[key].discounts += s.discounts || 0;
      agentMap[key].total += s.total_to_collect || 0;
      agentMap[key].count += 1;
    });

    const rows = Object.values(agentMap).sort((a, b) => b.subtotal - a.subtotal);
    const totals = rows.reduce((acc, r) => ({
      subtotal: acc.subtotal + r.subtotal,
      ga: acc.ga + r.ga,
      discounts: acc.discounts + r.discounts,
      total: acc.total + r.total
    }), { subtotal: 0, ga: 0, discounts: 0, total: 0 });

    return { rows, totals, currency: rows[0]?.currency || 'USD', count: filtered.length };
  };

  const handleGenerate = () => {
    const data = buildReport();
    if (!data) return;
    setReportData(data);
  };

  const fmt = (val) => `$ ${Number(val || 0).toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const handleExportExcel = () => {
    if (!reportData) { toast.error('Genera el reporte primero'); return; }
    const headers = ['#', 'Agente', 'SubTotal', 'GA 1,5%', 'Descuentos', 'Total'];
    const rows = reportData.rows.map((r, i) => [
      i + 1, r.agent_name,
      Number(r.subtotal).toFixed(2),
      Number(r.ga).toFixed(2),
      Number(r.discounts).toFixed(2),
      Number(r.total).toFixed(2)
    ]);
    rows.push(['', 'TOTALES', reportData.totals.subtotal.toFixed(2), reportData.totals.ga.toFixed(2), reportData.totals.discounts.toFixed(2), reportData.totals.total.toFixed(2)]);
    exportToExcel({ headers, rows, filename: `reporte_comisiones_${dateFrom}_${dateTo}`, sheetName: 'Reporte Comisiones' });
  };

  const handleExportPDF = () => {
    if (!reportData) { toast.error('Genera el reporte primero'); return; }
    setGenerating(true);
    try {
      const doc = new jsPDF({ orientation: 'landscape', format: 'a4' });
      const branchName = branchFilter !== 'all' ? branches.find(b => b.id === branchFilter)?.name : 'Todas las sedes';

      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text('REPORTE DE COMISIONES PAGADAS', 15, 20);

      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`Período: ${format(new Date(dateFrom), 'dd/MM/yyyy')} - ${format(new Date(dateTo), 'dd/MM/yyyy')}`, 15, 28);
      doc.text(`Sede: ${branchName}`, 15, 33);
      doc.text(`Generado: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`, 15, 38);
      doc.text(`Moneda: ${reportData.currency}`, 15, 43);

      const tableRows = reportData.rows.map((r, i) => [
        String(i + 1), r.agent_name, fmt(r.subtotal), fmt(r.ga),
        r.discounts > 0 ? fmt(r.discounts) : '$ -', fmt(r.total)
      ]);

      autoTable(doc, {
        startY: 48,
        head: [['#', 'Agente', 'SubTotal', 'GA 1,5%', 'Descuentos', 'Total']],
        body: tableRows,
        foot: [['', 'TOTALES', fmt(reportData.totals.subtotal), fmt(reportData.totals.ga), fmt(reportData.totals.discounts), fmt(reportData.totals.total)]],
        theme: 'grid',
        headStyles: { fillColor: [30, 58, 138], textColor: 255, fontSize: 9 },
        footStyles: { fillColor: [219, 234, 254], textColor: 0, fontSize: 9, fontStyle: 'bold' },
        bodyStyles: { fontSize: 8 },
        columnStyles: {
          0: { cellWidth: 12, halign: 'center' },
          1: { cellWidth: 60 },
          2: { cellWidth: 40, halign: 'right' },
          3: { cellWidth: 35, halign: 'right' },
          4: { cellWidth: 35, halign: 'right' },
          5: { cellWidth: 40, halign: 'right' }
        }
      });

      doc.save(`reporte_comisiones_${dateFrom}_${dateTo}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Error al generar PDF');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Reporte de Comisiones Pagadas</DialogTitle>
          <DialogDescription>Resumen de comisiones pagadas por agente en un período</DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-foreground" />
          </div>
        ) : (
          <>
            {/* Filters */}
            <div className="flex flex-wrap items-end gap-4 p-4 bg-muted/40 rounded-lg">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Filter className="h-4 w-4" />
                <span className="text-sm font-medium">Filtros:</span>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Desde</Label>
                <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Hasta</Label>
                <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Sede</Label>
                <Select value={branchFilter} onValueChange={setBranchFilter}>
                  <SelectTrigger className="w-44">
                    <SelectValue placeholder="Sede" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las sedes</SelectItem>
                    {branches.map(branch => (
                      <SelectItem key={branch.id} value={branch.id}>{branch.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleGenerate} className="gap-2">
                <Calendar className="h-4 w-4" /> Generar
              </Button>
            </div>

            {reportData && (
              <>
                {/* Export buttons */}
                <div className="flex justify-end gap-2 mt-4">
                  <Button onClick={handleExportExcel} variant="outline" size="sm" className="gap-2">
                    <FileSpreadsheet className="h-4 w-4" /> Excel
                  </Button>
                  <Button onClick={handleExportPDF} variant="outline" size="sm" className="gap-2" disabled={generating}>
                    {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />} PDF
                  </Button>
                </div>

                {/* Summary stats */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground mb-1">SubTotal</p>
                    <p className="text-base font-bold text-foreground dark:text-white">{fmt(reportData.totals.subtotal)}</p>
                  </Card>
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground mb-1">Gastos Admin.</p>
                    <p className="text-base font-bold text-orange-600 dark:text-orange-400">{fmt(reportData.totals.ga)}</p>
                  </Card>
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground mb-1">Descuentos</p>
                    <p className="text-base font-bold text-red-600 dark:text-red-400">{fmt(reportData.totals.discounts)}</p>
                  </Card>
                  <Card className="p-3">
                    <p className="text-xs text-muted-foreground mb-1">Total a Pagar</p>
                    <p className="text-base font-bold text-emerald-600 dark:text-emerald-400">{fmt(reportData.totals.total)}</p>
                  </Card>
                </div>

                {/* Table */}
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted dark:bg-blue-900/30 text-foreground/80 ">
                        <th className="px-3 py-2 text-center font-semibold w-10">#</th>
                        <th className="px-3 py-2 text-left font-semibold">Agente</th>
                        <th className="px-3 py-2 text-right font-semibold">SubTotal</th>
                        <th className="px-3 py-2 text-right font-semibold">GA 1,5%</th>
                        <th className="px-3 py-2 text-right font-semibold">Descuentos</th>
                        <th className="px-3 py-2 text-right font-semibold">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reportData.rows.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-3 py-8 text-center text-muted-foreground/70">
                            No hay liquidaciones en el período seleccionado
                          </td>
                        </tr>
                      ) : (
                        reportData.rows.map((r, i) => (
                          <tr key={i} className="border-b border-border ">
                            <td className="px-3 py-2 text-center text-muted-foreground">{i + 1}</td>
                            <td className="px-3 py-2 font-medium text-foreground dark:text-white">{r.agent_name}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{fmt(r.subtotal)}</td>
                            <td className="px-3 py-2 text-right tabular-nums text-orange-600 dark:text-orange-400">{fmt(r.ga)}</td>
                            <td className="px-3 py-2 text-right tabular-nums text-red-600 dark:text-red-400">{r.discounts > 0 ? fmt(r.discounts) : '$ -'}</td>
                            <td className="px-3 py-2 text-right tabular-nums font-semibold text-emerald-600 dark:text-emerald-400">{fmt(r.total)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="bg-muted dark:bg-blue-900/30 font-bold text-foreground/80 ">
                        <td className="px-3 py-2 text-center" colSpan={2}>TOTALES</td>
                        <td className="px-3 py-2 text-right tabular-nums">{fmt(reportData.totals.subtotal)}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-orange-600 dark:text-orange-400">{fmt(reportData.totals.ga)}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-red-600 dark:text-red-400">{fmt(reportData.totals.discounts)}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-emerald-600 dark:text-emerald-400">{fmt(reportData.totals.total)}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                <p className="text-xs text-muted-foreground/70 mt-3">
                  {reportData.rows.length} agentes • {reportData.count} liquidaciones en el período
                </p>
              </>
            )}

            {!reportData && !loading && (
              <div className="text-center text-muted-foreground/70 py-12">
                <Calendar className="h-10 w-10 mx-auto mb-3 opacity-50" />
                <p className="text-sm">Selecciona un rango de fechas y genera el reporte</p>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}