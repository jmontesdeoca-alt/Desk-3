import React, { useState, useEffect, useRef } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, X, Send, Loader2, Sparkles } from 'lucide-react';
import { cn } from "@/lib/utils";
import ReactMarkdown from 'react-markdown';

// ─── Helpers ────────────────────────────────────────────────────────────────

const normalize = (t) =>
  (t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();

const MONTH_MAP = {
  enero: '01', febrero: '02', marzo: '03', abril: '04', mayo: '05', junio: '06',
  julio: '07', agosto: '08', septiembre: '09', octubre: '10', noviembre: '11', diciembre: '12',
  jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
  jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
};

// Detecta si la pregunta habla de ventas / producción / emisión
function detectQueryIntent(q) {
  const n = normalize(q);
  const isSales = /venta|vend|emiti|emision|nuevo negocio|produccion|prima|poliz/.test(n);
  const isCommission = /comision|comisiones/.test(n);
  const isPayment = /pago|cobro|cuota|pendiente|atrasado/.test(n);

  // Extraer mes y año
  let month = null, year = null;
  const monthMatch = n.match(/(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/);
  if (monthMatch) month = MONTH_MAP[monthMatch[1]];

  const yearMatch = n.match(/20\d{2}/);
  if (yearMatch) year = yearMatch[0];

  // También detectar "mes actual", "este mes"
  if (!month && !year && /este mes|mes actual/.test(n)) {
    const now = new Date();
    month = String(now.getMonth() + 1).padStart(2, '0');
    year = String(now.getFullYear());
  }

  // Detectar tipo de póliza
  let policyType = null;
  if (/nuevo negocio|nuevos negocios/.test(n)) policyType = 'nuevo_negocio';
  if (/renovacion|renovaciones/.test(n)) policyType = 'renovacion';

  // Detectar campo de fecha
  let dateField = 'issue_date'; // por defecto emisión
  if (/vigencia|inicio|start/.test(n)) dateField = 'start_date';
  if (/creacion|creado/.test(n)) dateField = 'created_date';

  return { isSales, isCommission, isPayment, month, year, policyType, dateField };
}

function buildDateRange(month, year) {
  if (!month && !year) return { date_from: null, date_to: null };
  const y = year || String(new Date().getFullYear());
  if (month) {
    const lastDay = new Date(parseInt(y), parseInt(month), 0).getDate();
    return { date_from: `${y}-${month}-01`, date_to: `${y}-${month}-${lastDay}` };
  }
  return { date_from: `${y}-01-01`, date_to: `${y}-12-31` };
}

// ─── Componente ─────────────────────────────────────────────────────────────

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [catalog, setCatalog] = useState(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    api.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    if (isOpen && !catalog) loadCatalog();
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const loadCatalog = async () => {
    try {
      const res = await api.functions.invoke('aiQueryData', { query_type: 'catalog' });
      setCatalog(res.data);
    } catch {}
  };

  // Detecta si en la pregunta se menciona una compañía o agente del catálogo
  const findEntityInQuery = (q) => {
    if (!catalog) return { company: null, agent: null, line: null };
    const n = normalize(q);

    // Compañía: requiere que al menos 2 palabras significativas coincidan, o una muy específica (>7 chars)
    const company = catalog.companies?.find(c => {
      const words = normalize(c.name).split(' ').filter(w => w.length > 4);
      if (words.length === 0) return false;
      const matches = words.filter(w => n.includes(w));
      return matches.length >= 2 || (matches.length === 1 && matches[0].length > 7);
    }) || null;

    // Agente: solo si el usuario escribe al menos 2 palabras del nombre del agente (o el alias exacto)
    const agent = catalog.agents?.find(a => {
      const aliasN = normalize(a.alias || '');
      // Alias exacto en la query
      if (aliasN && aliasN.length > 3 && n.includes(aliasN)) return true;
      // Al menos 2 palabras significativas del nombre presentes en la query
      const nameWords = normalize(a.name).split(' ').filter(w => w.length > 4);
      const matches = nameWords.filter(w => n.includes(w));
      return matches.length >= 2;
    }) || null;

    // Ramo: coincidencia exacta del nombre completo
    const line = catalog.lines?.find(l =>
      n.includes(normalize(l.name))
    ) || null;

    return { company, agent, line };
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const query = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: query }]);
    setInput('');
    setLoading(true);

    try {
      const intent = detectQueryIntent(query);
      const { company, agent, line } = findEntityInQuery(query);
      const { date_from, date_to } = buildDateRange(intent.month, intent.year);

      let dataContext = '';

      // Si detectamos una consulta de ventas/pólizas con fecha → consultar datos reales
      if (intent.isSales && (date_from || date_to || company || agent || intent.policyType)) {
        const params = {
          query_type: 'policies_summary',
          date_from,
          date_to,
          date_field: intent.dateField,
          company_id: company?.id || null,
          agent_id: agent?.id || null,
          line_id: line?.id || null,
          policy_type: intent.policyType || null,
        };

        const res = await api.functions.invoke('aiQueryData', params);
        const d = res.data;

        dataContext = `
DATOS REALES DEL SISTEMA (resultado de consulta filtrada):
- Filtros aplicados: ${date_from ? `desde ${date_from}` : ''} ${date_to ? `hasta ${date_to}` : ''} ${date_field_label(intent.dateField)} ${company ? `| Compañía: ${company.name}` : ''} ${agent ? `| Agente: ${agent.name}` : ''} ${line ? `| Ramo: ${line.name}` : ''} ${intent.policyType ? `| Tipo: ${intent.policyType}` : ''}
- Total pólizas: ${d.summary?.total_policies}
- Prima anual total: USD ${(d.summary?.total_annual_premium || 0).toLocaleString('es-EC', { minimumFractionDigits: 2 })}
- Prima comisionable total: USD ${(d.summary?.total_commissionable_premium || 0).toLocaleString('es-EC', { minimumFractionDigits: 2 })}
${d.by_company?.length ? `\nPOR COMPAÑÍA:\n${d.by_company.map(r => `  • ${r.company}: ${r.count} pólizas | USD ${r.premium.toLocaleString('es-EC')}`).join('\n')}` : ''}
${d.by_type?.length ? `\nPOR TIPO:\n${d.by_type.map(r => `  • ${typeLabel(r.type)}: ${r.count} pólizas | USD ${r.premium.toLocaleString('es-EC')}`).join('\n')}` : ''}
${d.by_line?.length ? `\nPOR RAMO:\n${d.by_line.map(r => `  • ${r.line}: ${r.count} pólizas | USD ${r.premium.toLocaleString('es-EC')}`).join('\n')}` : ''}
${d.top_agents?.length ? `\nTOP AGENTES:\n${d.top_agents.map(r => `  • ${r.agent}: ${r.count} pólizas | USD ${r.premium.toLocaleString('es-EC')}`).join('\n')}` : ''}`;
      } else if (intent.isCommission) {
        const params = {
          query_type: 'commissions_summary',
          date_from,
          date_to,
          company_id: company?.id || null,
          agent_id: agent?.id || null,
        };
        const res = await api.functions.invoke('aiQueryData', params);
        const d = res.data;
        dataContext = `
DATOS REALES - COMISIONES:
- Total registros: ${d.summary?.total_commissions}
- Monto total: USD ${(d.summary?.total_amount || 0).toLocaleString('es-EC', { minimumFractionDigits: 2 })}
${d.by_status?.length ? `\nPOR ESTADO:\n${d.by_status.map(r => `  • ${commStatusLabel(r.status)}: ${r.count} | USD ${r.amount.toLocaleString('es-EC')}`).join('\n')}` : ''}`;
      } else if (intent.isPayment) {
        const params = {
          query_type: 'payments_summary',
          date_from,
          date_to,
        };
        const res = await api.functions.invoke('aiQueryData', params);
        const d = res.data;
        dataContext = `
DATOS REALES - PAGOS:
- Total: ${d.summary?.total_payments}
- Monto: USD ${(d.summary?.total_amount || 0).toLocaleString('es-EC', { minimumFractionDigits: 2 })}
${d.by_status?.length ? `\nPOR ESTADO:\n${d.by_status.map(r => `  • ${r.status}: ${r.count} | USD ${r.amount.toLocaleString('es-EC')}`).join('\n')}` : ''}`;
      }

      // Si no detectamos intent claro pero hay fecha → consultar igual pólizas
      if (!dataContext && (date_from || date_to)) {
        const res = await api.functions.invoke('aiQueryData', {
          query_type: 'policies_summary',
          date_from,
          date_to,
          date_field: intent.dateField,
        });
        const d = res.data;
        dataContext = `
DATOS REALES DEL SISTEMA:
- Total pólizas en el período: ${d.summary?.total_policies}
- Prima anual total: USD ${(d.summary?.total_annual_premium || 0).toLocaleString('es-EC', { minimumFractionDigits: 2 })}
${d.by_type?.length ? `\nPOR TIPO:\n${d.by_type.map(r => `  • ${typeLabel(r.type)}: ${r.count} pólizas | USD ${r.premium.toLocaleString('es-EC')}`).join('\n')}` : ''}`;
      }

      const systemPrompt = `Eres el asistente IA de InsurDesk (sistema de gestión de broker de seguros).
ROL DEL USUARIO: ${user?.app_role || 'admin'}

REGLAS:
1. Responde SIEMPRE con los datos reales que se te proporcionan a continuación — NO digas que no tienes información si los datos están presentes.
2. Si los datos están vacíos (total = 0), confirma que en ese período/filtro no hay registros.
3. Si la pregunta es ambigua (no especifica si es fecha de emisión, inicio de vigencia, etc.), pregunta antes de responder.
4. Si no se especifica compañía y hay múltiples, muestra el resumen por compañía.
5. Respuestas concisas, en español, sin emojis.
6. Usa markdown para estructurar (negrita, listas).
7. Siempre muestra: número de pólizas Y sumatoria de prima cuando la pregunta sea sobre ventas/producción.`;

      const response = await api.integrations.Core.InvokeLLM({
        prompt: `${systemPrompt}

${dataContext || 'No se realizó consulta específica. Responde basándote en tu conocimiento del sistema y pide más detalles si es necesario.'}

PREGUNTA DEL USUARIO: ${query}

INSTRUCCIÓN FINAL: Si tienes datos reales arriba, úsalos para responder. Si la pregunta requiere un filtro que no se pudo aplicar (ej: nombre de agente no encontrado en catálogo), indícalo y sugiere cómo reformular.`,
      });

      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Error al procesar la consulta. Por favor intenta de nuevo.'
      }]);
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <>
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="hidden lg:flex fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg bg-gradient-to-r from-brand to-brand-mid hover:shadow-lg transition-all z-50"
          size="icon"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}

      {isOpen && (
        <Card className="hidden lg:flex fixed bottom-6 right-6 w-96 h-[600px] shadow-lg z-50 flex-col border-2 border-brand/20">
          <div className="p-4 border-b bg-gradient-to-r from-brand to-brand-mid text-white flex items-center justify-between rounded-t-lg">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              <h3 className="font-semibold">Asistente IA</h3>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-white hover:bg-white/20">
              <X className="h-5 w-5" />
            </Button>
          </div>

          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="text-center py-8">
                <Sparkles className="h-12 w-12 text-brand mx-auto mb-3" />
                <p className="text-sm text-muted-foreground mb-2 font-medium">Hola, soy el asistente de InsurDesk</p>
                <p className="text-xs text-muted-foreground mb-4">Consulta datos en tiempo real del sistema.</p>
                <div className="text-left space-y-2">
                  {[
                    'Ventas junio 2026',
                    'Nuevo negocio en BMI mayo 2026',
                    'Producción del agente Montesdeoca',
                    'Comisiones pendientes de pagar',
                  ].map(s => (
                    <button key={s} onClick={() => setInput(s)}
                      className="w-full text-left text-xs bg-muted hover:bg-secondary rounded-md px-3 py-2 text-muted-foreground transition-colors">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((msg, idx) => (
                  <div key={idx} className={cn("flex", msg.role === 'user' ? 'justify-end' : 'justify-start')}>
                    <div className={cn(
                      "max-w-[85%] rounded-lg p-3 text-sm",
                      msg.role === 'user' ? 'bg-brand text-white' : 'bg-muted text-foreground'
                    )}>
                      {msg.role === 'assistant'
                        ? <ReactMarkdown className="prose prose-sm max-w-none prose-p:my-1 prose-li:my-0">{msg.content}</ReactMarkdown>
                        : <span>{msg.content}</span>}
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex justify-start">
                    <div className="bg-muted rounded-lg p-3 flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin text-brand" />
                      <span className="text-xs text-muted-foreground">Consultando datos...</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </ScrollArea>

          <div className="p-4 border-t bg-muted/40">
            <div className="flex gap-2">
              <Input
                placeholder="Ej: Ventas junio 2026 en Equivida..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                disabled={loading}
                className="flex-1 text-sm"
              />
              <Button onClick={handleSend} disabled={!input.trim() || loading} className="bg-brand hover:bg-brand-strong">
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground/70 mt-2 text-center">Datos en tiempo real · InsurDesk</p>
          </div>
        </Card>
      )}
    </>
  );
}

// ─── Helpers de etiquetas ────────────────────────────────────────────────────
function typeLabel(t) {
  const map = { nuevo_negocio: 'Nuevo negocio', renovacion: 'Renovación', cambio_broker: 'Cambio broker', cesion_cartera: 'Cesión cartera', otro: 'Otro' };
  return map[t] || t;
}
function commStatusLabel(s) {
  const map = { pendiente_liberar: 'Pendiente liberar', pendiente_pagar: 'Pendiente pagar', pagada: 'Pagada' };
  return map[s] || s;
}
function date_field_label(f) {
  const map = { issue_date: '(fecha emisión)', start_date: '(inicio vigencia)', created_date: '(fecha creación)' };
  return map[f] || '';
}