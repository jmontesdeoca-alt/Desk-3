import React from 'react';
import { useForm } from 'react-hook-form';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loader2 } from "lucide-react";
import CountrySelect from '@/components/ui/CountrySelect';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function ClientForm({ open, onOpenChange, onSubmit, initialData, isLoading }) {
  const { t } = useTranslation();
  const [duplicateDialogOpen, setDuplicateDialogOpen] = React.useState(false);
  const [pendingData, setPendingData] = React.useState(null);
  const [duplicateName, setDuplicateName] = React.useState('');

  // Ensure all fields are preserved during edits
  const { register, handleSubmit, watch, setValue, reset, formState: { errors, isSubmitting } } = useForm({
    defaultValues: initialData || {
      client_type: 'persona',
      status: 'activo',
      document_type: 'cedula'
    }
  });

  React.useEffect(() => {
    if (open && initialData) {
      // Cargar todos los datos existentes al editar
      Object.keys(initialData).forEach(key => {
        setValue(key, initialData[key]);
      });
    } else if (open && !initialData) {
      reset({
        client_type: 'persona',
        status: 'activo',
        document_type: 'cedula'
      });
    }
  }, [open, initialData, reset, setValue]);

  const clientType = watch('client_type');

  const handleFormSubmit = async (data) => {
    // Solo validar duplicados al crear (no al editar)
    if (!initialData) {
      const fullName = data.client_type === 'persona'
        ? `${data.first_name || ''} ${data.last_name || ''}`.trim().toUpperCase()
        : (data.company_name || '').trim().toUpperCase();

      if (fullName) {
        const existingClients = await api.entities.Client.list();
        const duplicate = existingClients.find(c => {
          const existingName = c.client_type === 'persona'
            ? `${c.first_name || ''} ${c.last_name || ''}`.trim().toUpperCase()
            : (c.company_name || '').trim().toUpperCase();
          return existingName === fullName;
        });

        if (duplicate) {
          setPendingData(data);
          setDuplicateName(fullName);
          setDuplicateDialogOpen(true);
          return;
        }
      }
    }
    onSubmit(data);
  };

  const handleConfirmDuplicate = () => {
    setDuplicateDialogOpen(false);
    onSubmit(pendingData);
    setPendingData(null);
  };

  return (
    <>
    <AlertDialog open={duplicateDialogOpen} onOpenChange={setDuplicateDialogOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Cliente duplicado</AlertDialogTitle>
          <AlertDialogDescription>
            {`Ya existe un cliente con el nombre "${duplicateName}". ¿Deseas crearlo de todas formas?`}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => setPendingData(null)}>Cancelar</AlertDialogCancel>
          <AlertDialogAction onClick={handleConfirmDuplicate}>Crear de todas formas</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? t('clients.edit') : t('clients.new')}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('clients.clientType')} *</Label>
              <Select 
                value={watch('client_type')} 
                onValueChange={(v) => setValue('client_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="persona">{t('clients.person')}</SelectItem>
                  <SelectItem value="empresa">{t('clients.company')}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t('common.status')}</Label>
              <Select 
                value={watch('status')} 
                onValueChange={(v) => setValue('status', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="activo">{t('common.active')}</SelectItem>
                  <SelectItem value="inactivo">{t('common.inactive')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {clientType === 'persona' ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t('clients.firstName')}</Label>
                <Input
                  {...register('first_name')}
                  placeholder="JUAN CARLOS"
                  onChange={(e) => setValue('first_name', e.target.value.toUpperCase())}
                  onPaste={(e) => { e.preventDefault(); const text = e.clipboardData.getData('text'); setValue('first_name', (watch('first_name') || '') + text.toUpperCase()); }}
                />
              </div>
              <div className="space-y-2">
                <Label>{t('clients.lastName')}</Label>
                <Input
                  {...register('last_name')}
                  placeholder="PÉREZ GARCÍA"
                  onChange={(e) => setValue('last_name', e.target.value.toUpperCase())}
                  onPaste={(e) => { e.preventDefault(); const text = e.clipboardData.getData('text'); setValue('last_name', (watch('last_name') || '') + text.toUpperCase()); }}
                />
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>{t('clients.companyName')}</Label>
              <Input
                {...register('company_name')}
                placeholder="EMPRESA S.A."
                onChange={(e) => setValue('company_name', e.target.value.toUpperCase())}
                onPaste={(e) => { e.preventDefault(); const text = e.clipboardData.getData('text'); setValue('company_name', (watch('company_name') || '') + text.toUpperCase()); }}
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('clients.documentType')}</Label>
              <Select 
                value={watch('document_type')} 
                onValueChange={(v) => setValue('document_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cedula">{t('clients.cedula')}</SelectItem>
                  <SelectItem value="pasaporte">{t('clients.passport')}</SelectItem>
                  <SelectItem value="nit">NIT</SelectItem>
                  <SelectItem value="ruc">RUC</SelectItem>
                  <SelectItem value="otro">{t('common.other')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t('clients.documentId')}</Label>
              <Input {...register('document_id')} placeholder="12345678" />
              {errors.document_id && <p className="text-sm text-red-500">Requerido</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('common.country')} *</Label>
              <CountrySelect
                value={watch('country')}
                onValueChange={(v) => setValue('country', v)}
              />
              {errors.country && <p className="text-sm text-red-500">Requerido</p>}
            </div>
            <div className="space-y-2">
              <Label>{t('common.city')}</Label>
              <Input {...register('city')} placeholder="Bogotá" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t('common.address')}</Label>
            <Input {...register('address')} placeholder="Calle 123 #45-67" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('common.email')}</Label>
              <Input {...register('email')} type="email" placeholder="correo@ejemplo.com" />
            </div>
            <div className="space-y-2">
              <Label>{t('common.phone')}</Label>
              <Input {...register('phone')} placeholder="+57 300 123 4567" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t('agents.birthDate')}</Label>
            <Input {...register('birth_date')} type="date" />
          </div>

          <div className="space-y-2">
            <Label>{t('common.notes')}</Label>
            <Textarea {...register('notes')} placeholder={t('clients.notesPlaceholder')} />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting || isLoading}>
              {(isSubmitting || isLoading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {initialData ? t('common.saveChanges') : t('clients.new')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
    </>
  );
}