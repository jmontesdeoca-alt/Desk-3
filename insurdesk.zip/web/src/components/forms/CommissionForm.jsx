import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";


import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";

export default function CommissionForm({ open, onOpenChange, onSubmit, initialData, isLoading }) {
  const [formData, setFormData] = useState({
    base_amount: '',
    commission_pct: '',
    commission_amount: '',
    status: 'pendiente_liberar',
    notes: ''
  });

  useEffect(() => {
    if (initialData) {
      setFormData({
        base_amount: initialData.base_amount || '',
        commission_pct: initialData.commission_pct || '',
        commission_amount: initialData.commission_amount || '',
        status: initialData.status || 'pendiente_liberar',
        notes: initialData.notes || ''
      });
    } else {
      setFormData({
        base_amount: '',
        commission_pct: '',
        commission_amount: '',
        status: 'pendiente_liberar',
        notes: ''
      });
    }
  }, [initialData, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      base_amount: parseFloat(formData.base_amount),
      commission_pct: parseFloat(formData.commission_pct),
      commission_amount: parseFloat(formData.commission_amount)
    });
  };

  const calculateCommission = () => {
    const base = parseFloat(formData.base_amount) || 0;
    const pct = parseFloat(formData.commission_pct) || 0;
    const amount = (base * pct) / 100;
    setFormData(prev => ({ ...prev, commission_amount: amount.toFixed(2) }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Editar Comisión</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Monto Base *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.base_amount}
                onChange={(e) => setFormData({ ...formData, base_amount: e.target.value })}
                onBlur={calculateCommission}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Porcentaje Comisión *</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.commission_pct}
                onChange={(e) => setFormData({ ...formData, commission_pct: e.target.value })}
                onBlur={calculateCommission}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Monto Comisión *</Label>
            <Input
              type="number"
              step="0.01"
              value={formData.commission_amount}
              onChange={(e) => setFormData({ ...formData, commission_amount: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Notas</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Agregar notas sobre esta corrección..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Guardar Cambios
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}