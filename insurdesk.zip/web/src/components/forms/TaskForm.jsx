import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2 } from 'lucide-react';
import ClientSelect from "@/components/forms/ClientSelect";
import PolicySelect from "@/components/forms/PolicySelect";

export default function TaskForm({ open, onClose, onSuccess, task = null }) {
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [clients, setClients] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [clientsLoading, setClientsLoading] = useState(false);
  const [policiesLoading, setPoliciesLoading] = useState(false);
  const [clientsLoaded, setClientsLoaded] = useState(false);
  const [policiesLoaded, setPoliciesLoaded] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    assigned_to_user_id: '',
    priority: 'media',
    due_date: '',
    reminder_enabled: false,
    reminder_date_time: '',
    related_type: 'none',
    related_client_id: '',
    related_policy_id: ''
  });

  useEffect(() => {
    if (open) {
      loadData();
      if (task) {
        setFormData({
          title: task.title || '',
          description: task.description || '',
          assigned_to_user_id: task.assigned_to_user_id || '',
          priority: task.priority || 'media',
          due_date: task.due_date || '',
          reminder_enabled: task.reminder_enabled || false,
          reminder_date_time: task.reminder_date_time ? task.reminder_date_time.substring(0, 16) : '',
          related_type: task.related_type || 'none',
          related_client_id: task.related_client_id || '',
          related_policy_id: task.related_policy_id || ''
        });
      } else {
        setFormData({
          title: '',
          description: '',
          assigned_to_user_id: '',
          priority: 'media',
          due_date: '',
          reminder_enabled: false,
          reminder_date_time: '',
          related_type: 'none',
          related_client_id: '',
          related_policy_id: ''
        });
      }
    }
  }, [open, task]);

  const loadData = async () => {
    try {
      const [userData, usersResponse] = await Promise.all([
        api.auth.me(),
        api.functions.invoke('listAllUsers', {})
      ]);
      setCurrentUser(userData);
      setUsers(usersResponse.data?.users || []);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const loadClients = async () => {
    if (clientsLoaded || clientsLoading) return;
    setClientsLoading(true);
    try {
      const clientsData = await api.entities.Client.list();
      setClients(clientsData);
      setClientsLoaded(true);
    } catch (error) {
      console.error('Error loading clients:', error);
    } finally {
      setClientsLoading(false);
    }
  };

  const loadPolicies = async () => {
    if (policiesLoaded || policiesLoading) return;
    setPoliciesLoading(true);
    try {
      const policiesData = await api.entities.Policy.list();
      setPolicies(policiesData);
      setPoliciesLoaded(true);
    } catch (error) {
      console.error('Error loading policies:', error);
    } finally {
      setPoliciesLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const assignedUser = users.find(u => u.id === formData.assigned_to_user_id);
      
      let relatedClient = null;
      let relatedPolicy = null;

      if (formData.related_type === 'cliente' && formData.related_client_id) {
        relatedClient = clients.find(c => c.id === formData.related_client_id);
      }
      if (formData.related_type === 'poliza' && formData.related_policy_id) {
        relatedPolicy = policies.find(p => p.id === formData.related_policy_id);
      }

      const taskData = {
        ...formData,
        assigned_to_user_name: assignedUser?.full_name || '',
        created_by_user_id: currentUser.id,
        created_by_user_name: currentUser.full_name,
        related_client_name: relatedClient ? `${relatedClient.first_name || ''} ${relatedClient.last_name || ''}`.trim() || relatedClient.company_name : '',
        related_policy_number: relatedPolicy?.policy_number || '',
        related_client_id: formData.related_type === 'cliente' ? formData.related_client_id : null,
        related_policy_id: formData.related_type === 'poliza' ? formData.related_policy_id : null,
        reminder_date_time: formData.reminder_enabled && formData.reminder_date_time ? formData.reminder_date_time : null
      };

      if (task) {
        await api.entities.Task.update(task.id, taskData);
        onSuccess();
        onClose();
      } else {
        // Get unique sequential number before creating
        let taskSequence = null;
        try {
          const seqRes = await api.functions.invoke('getNextTaskSequence', {});
          taskSequence = seqRes.data?.sequence ?? null;
        } catch (err) {
          console.error('Error getting task sequence:', err);
        }
        if (taskSequence != null) {
          taskData.task_sequence = taskSequence;
        }

        // Optimistic update
        const pendingTask = { 
          ...taskData, 
          id: 'pending-' + Date.now(), 
          status: 'pendiente',
          _isPending: true 
        };
        onSuccess(pendingTask, true);
        onClose();

        const newTask = await api.entities.Task.create(taskData);
        
        // Create in-app notification
        await api.entities.Notification.create({
          notification_type: 'otro',
          recipient_type: 'agente',
          recipient_id: formData.assigned_to_user_id,
          recipient_email: assignedUser?.email || '',
          recipient_name: assignedUser?.full_name || '',
          title: 'Nueva tarea asignada',
          message: `Se te ha asignado la tarea: ${formData.title}`,
          related_entity_type: 'Task',
          related_entity_id: newTask.id,
          notification_date: new Date().toISOString().split('T')[0],
          read: false,
          sent: false
        });

        // Send email notification if assigned user has email
        if (assignedUser?.email) {
          const taskCode = taskSequence != null
            ? `TAREA-${String(taskSequence).padStart(4, '0')}`
            : '';
          api.functions.invoke('sendTaskNotification', {
            assignedUserEmail: assignedUser.email,
            assignedUserName: assignedUser.full_name || '',
            taskTitle: formData.title,
            taskDescription: formData.description || '',
            taskPriority: formData.priority,
            taskDueDate: formData.due_date,
            createdByName: currentUser?.full_name || '',
            taskCode
          }).catch(err => console.error('Error sending task email:', err));
        }
      }
    } catch (error) {
      console.error('Error saving task:', error);
      alert('Error al guardar la tarea');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{task ? 'Editar Tarea' : 'Nueva Tarea'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Título *</Label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              required
            />
          </div>

          <div>
            <Label>Descripción</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Asignar a *</Label>
              <Select value={formData.assigned_to_user_id} onValueChange={(val) => setFormData({...formData, assigned_to_user_id: val})}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar usuario" />
                </SelectTrigger>
                <SelectContent>
                  {users.map(u => (
                    <SelectItem key={u.id} value={u.id}>{u.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Prioridad *</Label>
              <Select value={formData.priority} onValueChange={(val) => setFormData({...formData, priority: val})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="baja">🟢 Baja</SelectItem>
                  <SelectItem value="media">🟡 Media</SelectItem>
                  <SelectItem value="alta">🔴 Alta</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Fecha límite *</Label>
            <Input
              type="date"
              value={formData.due_date}
              onChange={(e) => setFormData({...formData, due_date: e.target.value})}
              required
            />
          </div>

          <div className="flex items-center gap-2">
            <Checkbox
              checked={formData.reminder_enabled}
              onCheckedChange={(checked) => setFormData({...formData, reminder_enabled: checked})}
            />
            <Label>Activar recordatorio</Label>
          </div>

          {formData.reminder_enabled && (
            <div>
              <Label>Fecha y hora del recordatorio</Label>
              <Input
                type="datetime-local"
                value={formData.reminder_date_time}
                onChange={(e) => setFormData({...formData, reminder_date_time: e.target.value})}
              />
            </div>
          )}

          <div>
            <Label>Relacionar con</Label>
            <Select value={formData.related_type} onValueChange={(val) => {
              setFormData({...formData, related_type: val, related_client_id: '', related_policy_id: ''});
              if (val === 'cliente') loadClients();
              if (val === 'poliza') loadPolicies();
            }}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Ninguno</SelectItem>
                <SelectItem value="cliente">Cliente</SelectItem>
                <SelectItem value="poliza">Póliza</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.related_type === 'cliente' && (
            <div>
              <Label>Cliente *</Label>
              {clientsLoading ? (
                <div className="flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground border rounded-md">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Cargando clientes...
                </div>
              ) : (
                <ClientSelect
                  clients={clients}
                  value={formData.related_client_id}
                  onValueChange={(val) => setFormData({...formData, related_client_id: val})}
                />
              )}
            </div>
          )}

          {formData.related_type === 'poliza' && (
            <div>
              <Label>Póliza *</Label>
              {policiesLoading ? (
                <div className="flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground border rounded-md">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Cargando pólizas...
                </div>
              ) : (
                <PolicySelect
                  policies={policies}
                  value={formData.related_policy_id}
                  onValueChange={(val) => setFormData({...formData, related_policy_id: val})}
                />
              )}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {task ? 'Actualizar' : 'Crear'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}