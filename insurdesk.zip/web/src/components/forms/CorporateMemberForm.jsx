import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import { api } from '@/api/client';
import { toast } from "sonner";

export default function CorporateMemberForm({ open, onOpenChange, onSubmit, initialData, isLoading, policyInfo }) {
  const [dependents, setDependents] = useState([]);
  
  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm({
    defaultValues: initialData || {
      member_type: 'TITULAR',
      relationship: 'TITULAR',
      status: 'activo'
    }
  });

  useEffect(() => {
    if (open && initialData) {
      reset(initialData);
      // If editing a titular, load their dependents
      if (initialData.member_type === 'TITULAR') {
        loadDependents(initialData.id);
      } else {
        setDependents([]);
      }
    } else if (open && !initialData) {
      reset({
        member_type: 'TITULAR',
        relationship: 'TITULAR',
        status: 'activo',
        document_type: 'cedula'
      });
      setDependents([]);
    }
  }, [open, initialData, reset]);

  const loadDependents = async (titularId) => {
    const deps = await api.entities.CorporateMember.filter({
      parent_member_id: titularId,
      member_type: 'DEPENDIENTE'
    });
    setDependents(deps.map(d => ({
      ...d,
      id: d.id // Mark as existing
    })));
  };

  const memberType = watch('member_type');
  const relationship = watch('relationship');

  // Auto-update relationship when member type changes
  useEffect(() => {
    if (memberType === 'TITULAR') {
      setValue('relationship', 'TITULAR');
      setValue('parent_member_id', undefined);
    }
  }, [memberType, setValue]);

  const handleFormSubmit = async (data) => {
    if (memberType === 'TITULAR') {
      // Calculate coverage tier
      const dependentCount = dependents.filter(d => d.first_name && d.last_name).length;
      const coverage_tier = dependentCount === 0 ? 'TITULAR_SOLO' :
                           dependentCount === 1 ? 'TITULAR_MAS1' : 'FAMILIA';
      
      const titularData = {
        ...data,
        policy_id: policyInfo.id,
        policy_number: policyInfo.policy_number,
        member_type: 'TITULAR',
        relationship: 'TITULAR',
        coverage_tier,
        enrollment_date: data.enrollment_date || new Date().toISOString().split('T')[0]
      };
      
      let titularId;
      if (initialData) {
        // Editing existing titular
        await onSubmit(titularData);
        titularId = initialData.id;
      } else {
        // Creating new titular
        const createdTitular = await onSubmit(titularData);
        titularId = createdTitular?.id;
      }
      
      // Validate we have titularId before proceeding with dependents
      if (!titularId) {
        toast.error('Error al crear titular - no se puede agregar dependientes');
        return;
      }
      
      // Create new dependents (those without id)
      const newDependents = dependents.filter(d => d.first_name && d.last_name && !d.id);
      if (newDependents.length > 0) {
        for (const dep of newDependents) {
          await api.entities.CorporateMember.create({
            policy_id: policyInfo.id,
            policy_number: policyInfo.policy_number,
            member_type: 'DEPENDIENTE',
            parent_member_id: titularId,
            relationship: dep.relationship,
            first_name: dep.first_name,
            last_name: dep.last_name,
            document_type: dep.document_type || 'cedula',
            document_id: dep.document_id || '',
            birth_date: dep.birth_date || null,
            email: dep.email || null,
            phone: dep.phone || null,
            enrollment_date: data.enrollment_date || new Date().toISOString().split('T')[0],
            status: 'activo'
          });
        }
      }
      
      // Recalculate coverage tier after all changes
      const allDeps = await api.entities.CorporateMember.filter({
        parent_member_id: titularId,
        member_type: 'DEPENDIENTE',
        status: 'activo'
      });
      const finalCoverageTier = allDeps.length === 0 ? 'TITULAR_SOLO' :
                                allDeps.length === 1 ? 'TITULAR_MAS1' : 'FAMILIA';
      await api.entities.CorporateMember.update(titularId, { coverage_tier: finalCoverageTier });
    } else {
      // DEPENDIENTE - not supported in this form anymore
      toast.error('Use el formulario del titular para agregar dependientes');
      return;
    }

    onOpenChange(false);
  };

  const addDependent = () => {
    setDependents([...dependents, { 
      first_name: '', 
      last_name: '', 
      relationship: 'CONYUGE', 
      document_id: '', 
      birth_date: '',
      document_type: 'cedula'
    }]);
  };

  const updateDependent = (index, field, value) => {
    const updated = [...dependents];
    updated[index][field] = value;
    setDependents(updated);
  };

  const removeDependent = (index) => {
    setDependents(dependents.filter((_, i) => i !== index));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Editar Afiliado' : 'Nuevo Afiliado'}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Nombres *</Label>
              <Input {...register('first_name', { required: true })} placeholder="JUAN CARLOS" />
              {errors.first_name && <p className="text-sm text-red-500">Requerido</p>}
            </div>
            <div className="space-y-2">
              <Label>Apellidos *</Label>
              <Input {...register('last_name', { required: true })} placeholder="PÉREZ GÓMEZ" />
              {errors.last_name && <p className="text-sm text-red-500">Requerido</p>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Tipo de Documento</Label>
              <Select 
                value={watch('document_type')} 
                onValueChange={(v) => setValue('document_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cedula">Cédula</SelectItem>
                  <SelectItem value="pasaporte">Pasaporte</SelectItem>
                  <SelectItem value="ruc">RUC</SelectItem>
                  <SelectItem value="otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Número de Documento *</Label>
              <Input {...register('document_id', { required: true })} placeholder="0123456789" />
              {errors.document_id && <p className="text-sm text-red-500">Requerido</p>}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Fecha de Nacimiento</Label>
              <Input {...register('birth_date')} type="date" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input {...register('email')} type="email" placeholder="EMAIL@EJEMPLO.COM" />
            </div>
            <div className="space-y-2">
              <Label>Teléfono</Label>
              <Input {...register('phone')} placeholder="0999999999" />
            </div>
          </div>

          {/* Dependents Section - Only for TITULAR */}
          {memberType === 'TITULAR' && (
            <div className="space-y-3 p-4 bg-muted/40 rounded-lg border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Dependientes del Titular</Label>
                  <p className="text-xs text-muted-foreground mt-1">
                    {dependents.length === 0 && 'Titular Solo'}
                    {dependents.length === 1 && 'Titular +1'}
                    {dependents.length >= 2 && 'Familia'}
                  </p>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={addDependent}>
                  Agregar Dependiente
                </Button>
              </div>

              {dependents.map((dep, index) => (
                <div key={index} className="grid grid-cols-4 gap-3 p-3 bg-card rounded-lg border relative">
                  <div className="space-y-1">
                    <Label className="text-xs">Nombres</Label>
                    <Input
                      value={dep.first_name}
                      onChange={(e) => updateDependent(index, 'first_name', e.target.value)}
                      placeholder="NOMBRES"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Apellidos</Label>
                    <Input
                      value={dep.last_name}
                      onChange={(e) => updateDependent(index, 'last_name', e.target.value)}
                      placeholder="APELLIDOS"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Relación</Label>
                    <Select
                      value={dep.relationship}
                      onValueChange={(v) => updateDependent(index, 'relationship', v)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CONYUGE">Cónyuge</SelectItem>
                        <SelectItem value="HIJO">Hijo/a</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Documento</Label>
                    <Input
                      value={dep.document_id}
                      onChange={(e) => updateDependent(index, 'document_id', e.target.value)}
                      placeholder="ID"
                    />
                  </div>
                  <div className="space-y-1 col-span-2">
                    <Label className="text-xs">Fecha Nacimiento</Label>
                    <Input
                      type="date"
                      value={dep.birth_date}
                      onChange={(e) => updateDependent(index, 'birth_date', e.target.value)}
                    />
                  </div>
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={() => removeDependent(index)}
                    className="col-span-2"
                  >
                    Eliminar
                  </Button>
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {initialData ? 'Guardar Cambios' : 'Crear Afiliado'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}