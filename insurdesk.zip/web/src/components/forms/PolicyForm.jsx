import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2, UserPlus, X } from "lucide-react";
import { api } from '@/api/client';
import CountrySelect from '@/components/ui/CountrySelect';
import AgentSelect from '@/components/forms/AgentSelect';
import ClientSelect from '@/components/forms/ClientSelect';
import ClientForm from '@/components/forms/ClientForm';
import PolicyTagSelect from '@/components/forms/PolicyTagSelect';
import { toast } from "sonner";
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function PolicyForm({ open, onOpenChange, onSubmit, initialData, isLoading, lines: propLines, agents: propAgents, companies: propCompanies, prefillData }) {
  const { t } = useTranslation();
  const [clients, setClients] = useState([]);
  const [products, setProducts] = useState([]);
  const [loadingClients, setLoadingClients] = useState(false);
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [dependents, setDependents] = useState([]);
  const [vehicleData, setVehicleData] = useState({ brand: '', model: '', year: '', plate: '' });
  const [propertyData, setPropertyData] = useState({ property_type: '', property_value: '', address: '', protections: '' });
  const [corporateRates, setCorporateRates] = useState({ 
    rate_titular_solo: '', 
    rate_titular_mas1: '', 
    rate_familia: '' 
  });
  const [showClientForm, setShowClientForm] = useState(false);
  const [clientLoading, setClientLoading] = useState(false);
  const [selectedTags, setSelectedTags] = useState([]);
  const submittingRef = useRef(false);
  const [submitting, setSubmitting] = useState(false);
  
  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm({
    defaultValues: initialData || {
      line_id: '',
      company_id: '',
      currency: 'USD',
      payment_frequency: 'mensual',
      status: 'activa',
      dependents: []
    }
  });

  // Use pre-loaded data from parent (lines, agents, companies), filtered to active-only
  const lines = useMemo(() =>
    (propLines || []).filter(l => !l.status || l.status === 'activo').sort((a, b) => a.name.localeCompare(b.name)),
    [propLines]
  );
  const agents = useMemo(() =>
    (propAgents || []).filter(a => !a.status || a.status === 'activo').sort((a, b) => a.name.localeCompare(b.name)),
    [propAgents]
  );
  const companies = useMemo(() =>
    (propCompanies || []).filter(c => !c.status || c.status === 'activa').sort((a, b) => a.name.localeCompare(b.name)),
    [propCompanies]
  );

  // Only fetch clients and products (data not available from parent)
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const loadData = async () => {
      setLoadingClients(true);
      setLoadingProducts(true);
      try {
        const [clientsData, productsData] = await Promise.all([
          api.entities.Client.list(),
          api.entities.Product.filter({ status: 'activo' })
        ]);
        if (cancelled) return;
        const sortedClients = clientsData.sort((a, b) => {
          const nameA = getClientName(a).toUpperCase();
          const nameB = getClientName(b).toUpperCase();
          return nameA.localeCompare(nameB);
        });
        const sortedProducts = productsData.sort((a, b) => a.product_name.localeCompare(b.product_name));
        setClients(sortedClients);
        setProducts(sortedProducts);
      } finally {
        if (!cancelled) {
          setLoadingClients(false);
          setLoadingProducts(false);
        }
      }
    };
    loadData();
    return () => { cancelled = true; };
  }, [open]);

  const selectedLineId = watch('line_id');
  const selectedCompanyId = watch('company_id');

  // Filter companies by selected line
  const availableCompanies = selectedLineId 
    ? companies.filter(c => (c.line_ids?.includes(selectedLineId) || c.lines?.includes(lines.find(l => l.id === selectedLineId)?.name)))
    : [];

  // Filter products by selected line and company
  const availableProducts = (selectedLineId && selectedCompanyId)
    ? products.filter(p => p.line_id === selectedLineId && p.company_id === selectedCompanyId)
    : [];

  useEffect(() => {
    const loadInitialData = async () => {
      if (open && initialData) {
        // Cargar todos los datos existentes al editar usando reset
        reset(initialData);
        setDependents(initialData.dependents || []);
        setSelectedTags(initialData.tags || []);
        
        // Load vehicle data if editing
        if (initialData?.vehicle_data) {
          setVehicleData(initialData.vehicle_data);
        }
        
        // Load property data if editing
        if (initialData?.property_data) {
          setPropertyData(initialData.property_data);
        }
        
        // Load corporate rates if editing a corporate policy
        if (initialData.policy_category === 'CORPORATIVA' && initialData.id) {
          const rates = await api.entities.CorporateRatePlan.filter({ policy_id: initialData.id });
          if (rates.length > 0) {
            setCorporateRates({
              rate_titular_solo: rates[0].rate_titular_solo || '',
              rate_titular_mas1: rates[0].rate_titular_mas1 || '',
              rate_familia: rates[0].rate_familia || ''
            });
          }
        }
      } else if (open && !initialData) {
        reset({
          line_id: '',
          company_id: '',
          currency: 'USD',
          payment_frequency: 'mensual',
          status: 'activa',
          policy_type: 'nuevo_negocio',
          start_date: '',
          end_date: '',
          issue_date: '',
          dependents: [],
          ...prefillData
        });
        setDependents([]);
        setSelectedTags([]);
        setVehicleData({ brand: '', model: '', year: '', plate: '' });
        setPropertyData({ property_type: '', property_value: '', address: '', protections: '' });
        setCorporateRates({ rate_titular_solo: '', rate_titular_mas1: '', rate_familia: '' });
      }
    };
    
    loadInitialData();
  }, [open, initialData, reset]);

  const selectedProductId = watch('product_id');
  const annualPremium = watch('annual_premium');
  const paymentFrequency = watch('payment_frequency');
  const installmentMonths = watch('installment_months');
  const lineName = watch('line_name');
  const policyCategory = watch('policy_category');
  const agentId = watch('agent_id');
  const lineId = watch('line_id');
  const companyId = watch('company_id');
  const clientId = watch('client_id');
  const contractorId = watch('contractor_id');
  const startDate = watch('start_date');
  const endDate = watch('end_date');
  const commissionablePremium = watch('commissionable_premium');
  const sumInsured = watch('sum_insured');

  // Block frequency/premium changes when policy has paid payments
  const [hasPaidPayments, setHasPaidPayments] = useState(false);

  useEffect(() => {
    const checkPaidPayments = async () => {
      if (open && initialData?.id) {
        try {
          const payments = await api.entities.Payment.filter({ policy_id: initialData.id, status: 'pagado' });
          const hasPaidBase = payments.some(p => !p.payment_group || p.payment_group === 'base');
          setHasPaidPayments(hasPaidBase);
        } catch {
          setHasPaidPayments(false);
        }
      } else {
        setHasPaidPayments(false);
      }
    };
    checkPaidPayments();
  }, [open, initialData]);

  // Computed: list missing fields for debug
  const missingFields = [];
  if (!agentId) missingFields.push('Agente');
  if (!lineId) missingFields.push('Ramo');
  if (!companyId) missingFields.push('Compañía');
  if (!selectedProductId) missingFields.push('Producto');
  if (!startDate) missingFields.push('Vigencia Desde');
  if (!endDate) missingFields.push('Vigencia Hasta');
  if (policyCategory === 'CORPORATIVA') {
    if (!contractorId) missingFields.push('Contratante');
    if (!corporateRates.rate_titular_solo || !corporateRates.rate_titular_mas1 || !corporateRates.rate_familia) missingFields.push('Tarifas corporativas');
  } else {
    if (!clientId) missingFields.push('Cliente');
    if (!annualPremium) missingFields.push('Prima Anual');
    if (!commissionablePremium) missingFields.push('Prima Comisionable');
  }
  if (lineName?.toLowerCase().includes('vida') && !sumInsured) missingFields.push('Suma Asegurada (Vida)');
  if (lineName?.toLowerCase().includes('auto') && !sumInsured) missingFields.push('Suma Asegurada (Auto)');
  const isFormValid = missingFields.length === 0;

  useEffect(() => {
    if (selectedProductId) {
      const product = products.find(p => p.id === selectedProductId);
      if (product) {
        setValue('product_name', product.product_name);
        
        // Set policy category based on product
        const productCategory = product.product_category || 'INDIVIDUAL';
        setValue('policy_category', productCategory);
        
        // If product is from Salud line, populate health-related fields
        if (product.line_name?.toLowerCase().includes('salud')) {
          setValue('insured_amount', product.insured_amount || 0);
          // Reset deductibles when product changes
          setValue('deductible_1', '');
          setValue('deductible_2', '');
        }
      }
    }
  }, [selectedProductId, products, setValue]);

  useEffect(() => {
    if (selectedLineId) {
      const line = lines.find(l => l.id === selectedLineId);
      if (line) {
        setValue('line_name', line.name);
      }
    }
  }, [selectedLineId, lines, setValue]);

  useEffect(() => {
    if (selectedCompanyId) {
      const company = companies.find(c => c.id === selectedCompanyId);
      if (company) {
        setValue('company_id', company.id);
        setValue('company_name', company.name);
        setValue('branch_id', company.branch_id);
        setValue('branch_name', company.branch_name);
      }
    }
  }, [selectedCompanyId, companies, setValue]);

  useEffect(() => {
    if (annualPremium && paymentFrequency) {
      let divisor;
      if (paymentFrequency === 'mensual') {
        divisor = parseInt(installmentMonths) || 12;
      } else {
        const divisors = { trimestral: 4, semestral: 2, anual: 1, unico: 1 };
        divisor = divisors[paymentFrequency] || 1;
      }
      const installment = parseFloat(annualPremium) / divisor;
      setValue('installment_amount', installment.toFixed(2));
    }
  }, [annualPremium, paymentFrequency, installmentMonths, setValue]);

  const handleFormSubmit = async (data) => {
    // Guard síncrono contra doble-envío (cierre del vector principal de duplicados por doble-clic / internet inestable)
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSubmitting(true);

    try {
      if (isLoading) return;

      // Block frequency/premium changes if policy has paid payments
      if (initialData && hasPaidPayments) {
        const freqChanged = data.payment_frequency !== initialData.payment_frequency;
        const premiumChanged = parseFloat(data.annual_premium) !== parseFloat(initialData.annual_premium || 0);
        const monthsChanged = parseInt(data.installment_months || 12) !== parseInt(initialData.installment_months || 12);
        if (freqChanged || premiumChanged || monthsChanged) {
          toast.error('No se puede modificar la frecuencia de pago o el valor de la prima porque la póliza ya tiene pagos registrados.');
          return;
        }
      }

      // Validar número de póliza duplicado por compañía (pre-check rápido; la validación definitiva la hace createPolicy en backend)
      if (!initialData && data.policy_number && data.company_id) {
        const existing = await api.entities.Policy.filter({ policy_number: data.policy_number, company_id: data.company_id });
        if (existing.length > 0) {
          toast.error(`Ya existe una póliza con el número "${data.policy_number}" para esta compañía.`);
          return;
        }
      }
      
      // Validar que issue_date no sea posterior a start_date
      if (data.issue_date && data.start_date) {
        if (new Date(data.issue_date) > new Date(data.start_date)) {
          toast.error('La fecha de emisión no puede ser posterior a la fecha de inicio de vigencia.');
          return;
        }
      }
      
      const client = data.policy_category === 'CORPORATIVA' 
        ? clients.find(c => c.id === data.contractor_id)
        : clients.find(c => c.id === data.client_id);
      const agent = agents.find(a => a.id === data.agent_id);
      const company = companies.find(c => c.id === data.company_id);
      const policyData = {
        ...data,
        policy_number: data.policy_number?.trim() || undefined,
        issue_date: data.issue_date || data.start_date,
        agent_name: agent?.name || '',
        tags: selectedTags.length > 0 ? selectedTags : undefined,
        annual_premium: data.policy_category === 'CORPORATIVA' ? 0 : parseFloat(data.annual_premium),
        commissionable_premium: data.policy_category === 'CORPORATIVA' ? 0 : parseFloat(data.commissionable_premium),
        installment_amount: data.policy_category === 'CORPORATIVA' ? 0 : parseFloat(data.installment_amount || 0),
        payment_frequency: data.policy_category === 'CORPORATIVA' ? 'mensual' : data.payment_frequency,
        insured_amount: data.insured_amount ? parseFloat(data.insured_amount) : undefined,
        deductible_1: data.deductible_1 ? parseFloat(data.deductible_1) : undefined,
        deductible_2: data.deductible_2 ? parseFloat(data.deductible_2) : undefined,
        sum_insured: data.sum_insured ? parseFloat(data.sum_insured) : undefined,
        dependents: data.policy_category === 'INDIVIDUAL' ? dependents : [],
        vehicle_data: lineName?.toLowerCase().includes('auto') ? {
          ...vehicleData,
          year: vehicleData.year ? parseInt(vehicleData.year) : undefined
        } : undefined,
        property_data: lineName?.toLowerCase().includes('hogar') && propertyData.property_type ? {
          property_type: propertyData.property_type,
          property_value: propertyData.property_value ? parseFloat(propertyData.property_value) : 0,
          address: propertyData.address || '',
          protections: propertyData.protections || ''
        } : undefined
      };

      // For corporate policies, validate and save rate plan
      if (data.policy_category === 'CORPORATIVA') {
        if (!corporateRates.rate_titular_solo || !corporateRates.rate_titular_mas1 || !corporateRates.rate_familia) {
          toast.error('Debe especificar todas las tarifas para póliza corporativa');
          return;
        }
      }

      // Set client or contractor fields based on category
      if (data.policy_category === 'CORPORATIVA') {
        policyData.contractor_name = client ? (client.client_type === 'persona' ? `${client.first_name} ${client.last_name}` : client.company_name) : '';
        policyData.client_id = undefined;
        policyData.client_name = undefined;
      } else {
        policyData.client_name = client ? (client.client_type === 'persona' ? `${client.first_name} ${client.last_name}` : client.company_name) : '';
        policyData.contractor_id = undefined;
        policyData.contractor_name = undefined;
      }

      // Call parent submit and await the result
      const createdPolicy = await onSubmit(policyData);

      // If corporate policy, save or update rate plan
      if (data.policy_category === 'CORPORATIVA' && (createdPolicy?.id || initialData?.id)) {
        const policyId = createdPolicy?.id || initialData?.id;

        // Check if rate plan exists
        const existingRates = await api.entities.CorporateRatePlan.filter({ policy_id: policyId });

        const rateData = {
          policy_id: policyId,
          policy_number: data.policy_number,
          currency: data.currency,
          rate_titular_solo: parseFloat(corporateRates.rate_titular_solo),
          rate_titular_mas1: parseFloat(corporateRates.rate_titular_mas1),
          rate_familia: parseFloat(corporateRates.rate_familia),
          effective_from: data.start_date,
          effective_to: data.end_date
        };

        if (existingRates.length > 0) {
          // Update existing rate plan
          await api.entities.CorporateRatePlan.update(existingRates[0].id, rateData);
        } else {
          // Create new rate plan
          await api.entities.CorporateRatePlan.create(rateData);
        }
      }

      // If not editing (is new policy) AND policy was successfully created, send emails
      if (!initialData && createdPolicy && createdPolicy.id) {
        await sendNewPolicyEmails(createdPolicy, agent, client, company);
      }
      } catch (error) {
        console.error('Error en handleFormSubmit:', error);
        toast.error(`Error al guardar póliza: ${error.message || 'Error desconocido'}`);
      } finally {
        submittingRef.current = false;
        setSubmitting(false);
      }
  };
  
  const sendNewPolicyEmails = async (policyData, agent, client, company) => {
    // Check if automatic emails are enabled
    const emailSettings = await api.entities.AppSettings.filter({ 
      setting_key: 'automatic_emails_enabled' 
    });
    
    if (emailSettings.length > 0 && emailSettings[0].setting_value !== 'true') {
      return; // Don't send if disabled
    }
    
    const recipients = [];
    
    // Add the selling agent
    if (agent?.email) {
      recipients.push({ 
        agentData: agent, 
        reason: 'agente vendedor' 
      });
    }
    
    // Find upline Nivel 2 agent
    if (agent?.upline_agent_id) {
      let currentAgent = agent;
      const allAgents = await api.entities.Agent.list();
      
      while (currentAgent.upline_agent_id) {
        const upline = allAgents.find(a => a.id === currentAgent.upline_agent_id);
        if (!upline) break;
        
        if (upline.is_nivel_2 && upline.email) {
          // Check if not already in recipients
          if (!recipients.find(r => r.agentData.email === upline.email)) {
            recipients.push({ 
              agentData: upline, 
              reason: 'agente Nivel 2' 
            });
          }
          break; // Solo el primer Nivel 2 encontrado
        }
        
        currentAgent = upline;
      }
    }
    
    // Send emails to all recipients
    for (const recipient of recipients) {
      await sendEmailToAgent(policyData, recipient.agentData, client, company, recipient.reason);
    }
  };
  
  const sendEmailToAgent = async (policyData, agent, client, company, reason) => {
    if (!agent?.email) {
      await api.entities.EmailLog.create({
        recipient_email: agent?.email || 'N/A',
        recipient_name: agent?.name || 'Desconocido',
        email_type: 'nueva_poliza',
        subject: `Nueva Póliza ${policyData.policy_number}`,
        body: '',
        status: 'no_enviado',
        error_message: 'El agente no tiene email configurado',
        related_entity_type: 'Policy',
        related_entity_id: policyData.id,
        related_entity_reference: policyData.policy_number,
        sent_date: new Date().toISOString().split('T')[0]
      });
      return;
    }
    
    const clientName = client ? (client.client_type === 'persona' ? `${client.first_name} ${client.last_name}` : client.company_name) : '';
    
    try {
      // Get admin email for BCC
      const adminUsers = await api.entities.User.filter({ role: 'admin' });
      const adminEmail = adminUsers.length > 0 ? adminUsers[0].email : null;
      
      // Get Nivel 2 agent email for BCC
      let nivel2Email = null;
      if (agent.upline_agent_id) {
        const allAgents = await api.entities.Agent.list();
        let currentAgent = agent;
        
        while (currentAgent.upline_agent_id) {
          const upline = allAgents.find(a => a.id === currentAgent.upline_agent_id);
          if (!upline) break;
          
          if (upline.is_nivel_2 && upline.email) {
            nivel2Email = upline.email;
            break;
          }
          
          currentAgent = upline;
        }
      }
      
      // Build BCC list (Nivel 2 + admin)
      const bccEmails = [adminEmail, nivel2Email].filter(Boolean);
      const bccString = bccEmails.length > 0 ? bccEmails.join(',') : undefined;
      
      // CC: correo operativo del agente receptor (si existe)
      const ccString = agent.operational_email || undefined;
      
      // Enviar email usando función backend con estructura específica para API externa
      await api.functions.invoke('sendEmail', {
        to: agent.email,
        bcc: bccString,
        cc: ccString,
        type: 'NEW_POLICY',
        data: {
          agente: agent.name,
          poliza: policyData.policy_number,
          cliente: clientName,
          compania: company?.name || '',
          producto: policyData.product_name,
          moneda: policyData.currency,
          monto: policyData.annual_premium || 0,
          fecha_inicio: policyData.start_date,
          fecha_fin: policyData.end_date
        }
      });
      
      // Log de envío exitoso
      await api.entities.EmailLog.create({
        recipient_email: agent.email,
        recipient_name: agent.name,
        email_type: 'nueva_poliza',
        subject: `Nueva Póliza ${policyData.policy_number}`,
        body: JSON.stringify({ agente: agent.name, poliza: policyData.policy_number, cliente: clientName }),
        status: 'enviado',
        related_entity_type: 'Policy',
        related_entity_id: policyData.id,
        related_entity_reference: policyData.policy_number,
        sent_date: new Date().toISOString().split('T')[0]
      });
    } catch (error) {
      // Log de error
      await api.entities.EmailLog.create({
        recipient_email: agent.email,
        recipient_name: agent.name,
        email_type: 'nueva_poliza',
        subject: `Nueva Póliza ${policyData.policy_number}`,
        body: '',
        status: 'error',
        error_message: `${error.message || 'Error desconocido al enviar email'} (${reason})`,
        related_entity_type: 'Policy',
        related_entity_id: policyData.id,
        related_entity_reference: policyData.policy_number,
        sent_date: new Date().toISOString().split('T')[0]
      });
    }
  };
  


  const addDependent = () => {
    const isVida = lineName?.toLowerCase().includes('vida');
    if (isVida) {
      setDependents([...dependents, { name: '', relationship: '', document_id: '', beneficiary_type: 'principal', percentage: 0 }]);
    } else {
      setDependents([...dependents, { name: '', relationship: '', birth_date: '', document_id: '' }]);
    }
  };

  const updateDependent = (index, field, value) => {
    const updated = [...dependents];
    updated[index][field] = value;
    setDependents(updated);
  };

  const removeDependent = (index) => {
    setDependents(dependents.filter((_, i) => i !== index));
  };

  const getTotalPercentage = (type) => {
    return dependents
      .filter(dep => dep.beneficiary_type === type)
      .reduce((sum, dep) => sum + (parseFloat(dep.percentage) || 0), 0);
  };

  const getClientName = (client) => {
    return client.client_type === 'persona' 
      ? `${client.first_name || ''} ${client.last_name || ''}`.trim() 
      : client.company_name || '';
  };

  const handleCreateClient = async (clientData) => {
    setClientLoading(true);
    try {
      const newClient = await api.entities.Client.create(clientData);
      toast.success('Cliente creado exitosamente');
      
      // Reload clients list
      const updatedClients = await api.entities.Client.list();
      const sortedClients = updatedClients.sort((a, b) => {
        const nameA = getClientName(a).toUpperCase();
        const nameB = getClientName(b).toUpperCase();
        return nameA.localeCompare(nameB);
      });
      setClients(sortedClients);
      
      // Set the new client as selected
      if (policyCategory === 'CORPORATIVA') {
        setValue('contractor_id', newClient.id);
      } else {
        setValue('client_id', newClient.id);
      }
      
      setShowClientForm(false);
    } catch (error) {
      toast.error('Error al crear cliente: ' + error.message);
    }
    setClientLoading(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" onOpenAutoFocus={(e) => {
        // Reset form when dialog opens
        if (!initialData && open) {
          reset({
            line_id: '',
            company_id: '',
            currency: 'USD',
            payment_frequency: 'mensual',
            status: 'activa',
            policy_type: 'nuevo_negocio',
            start_date: '',
            end_date: '',
            issue_date: '',
            dependents: [],
            ...prefillData
          });
          setDependents([]);
          setVehicleData({ brand: '', model: '', year: '', plate: '' });
          setPropertyData({ property_type: '', property_value: '', address: '', protections: '' });
          setCorporateRates({ rate_titular_solo: '', rate_titular_mas1: '', rate_familia: '' });
        }
      }}>
         <DialogHeader>
           <DialogTitle>{initialData ? t('policies.edit') : t('policies.new')}</DialogTitle>
         </DialogHeader>
        
          <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>{t('policies.policyNumber')}</Label>
                <Input {...register('policy_number')} placeholder="POL-2024-001 (opcional)" />
              </div>
              <div className="space-y-2">
                <Label>{t('policies.policyType')}</Label>
                <Select 
                  value={watch('policy_type')} 
                  onValueChange={(v) => setValue('policy_type', v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nuevo_negocio">{t('policies.newBusiness')}</SelectItem>
                    <SelectItem value="renovacion">{t('policies.renewal')}</SelectItem>
                    <SelectItem value="cambio_broker">{t('policies.brokerChange')}</SelectItem>
                    <SelectItem value="cesion_cartera">{t('policies.portfolioCession')}</SelectItem>
                    <SelectItem value="otro">{t('common.other')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{t('common.status')}</Label>
                <Select 
                  value={watch('status')} 
                  onValueChange={(v) => setValue('status', v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activa">{t('policies.active')}</SelectItem>
                    <SelectItem value="vencida">{t('policies.expired')}</SelectItem>
                    <SelectItem value="cancelada">{t('policies.cancelled')}</SelectItem>
                    <SelectItem value="renovada">{t('policies.renewed')}</SelectItem>
                    <SelectItem value="en_riesgo">{t('policies.atRisk')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {policyCategory === 'CORPORATIVA' ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>{t('policyDetail.contractor')} * {loadingClients && <Loader2 className="inline h-3 w-3 animate-spin ml-1 text-foreground" />}</Label>
                    <button
                      type="button"
                      onClick={() => setShowClientForm(true)}
                      className="text-xs text-foreground hover:text-foreground flex items-center gap-1"
                    >
                      <UserPlus className="h-3 w-3" />
                      {t('policies.newContractor')}
                    </button>
                  </div>
                  <ClientSelect
                    clients={clients}
                    value={watch('contractor_id')}
                    onValueChange={(v) => {
                      setValue('contractor_id', v);
                      const contractor = clients.find(c => c.id === v);
                      if (contractor) {
                        setValue('contractor_name', contractor.client_type === 'empresa' ? contractor.company_name : `${contractor.first_name} ${contractor.last_name}`);
                      }
                    }}
                    placeholder={loadingClients ? "Cargando clientes..." : "Buscar contratante..."}
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>{t('policies.client')} * {loadingClients && <Loader2 className="inline h-3 w-3 animate-spin ml-1 text-foreground" />}</Label>
                    <button
                      type="button"
                      onClick={() => setShowClientForm(true)}
                      className="text-xs text-foreground hover:text-foreground flex items-center gap-1"
                    >
                      <UserPlus className="h-3 w-3" />
                      {t('clients.new')}
                    </button>
                  </div>
                  <ClientSelect
                    clients={clients}
                    value={watch('client_id')}
                    onValueChange={(v) => setValue('client_id', v)}
                    placeholder={loadingClients ? "Cargando clientes..." : "Buscar cliente..."}
                  />
                </div>
              )}
              <div className="space-y-2">
                <Label>{t('policies.agent')} *</Label>
                <AgentSelect
                  agents={agents}
                  value={watch('agent_id')}
                  onValueChange={(v) => setValue('agent_id', v)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t('policies.line')} *</Label>
              <Select 
                value={watch('line_id')} 
                onValueChange={(v) => {
                  setValue('line_id', v);
                  setValue('company_id', '');
                  setValue('product_id', '');
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('policies.selectLine')} />
                </SelectTrigger>
                <SelectContent>
                  {lines.map(line => (
                    <SelectItem key={line.id} value={line.id}>
                      {line.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t('policies.company')} *</Label>
              <Select 
                value={watch('company_id')} 
                onValueChange={(v) => {
                  setValue('company_id', v);
                  setValue('product_id', '');
                }}
                disabled={!watch('line_id')}
              >
                <SelectTrigger>
                  <SelectValue placeholder={watch('line_id') ? t('policies.selectCompany') : t('policies.selectLineFirst')} />
                </SelectTrigger>
                <SelectContent>
                  {availableCompanies.map(company => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t('policies.product')} *</Label>
              <Select 
                value={watch('product_id')} 
                onValueChange={(v) => setValue('product_id', v)}
                disabled={!watch('company_id') || loadingProducts}
              >
                <SelectTrigger>
                  <SelectValue placeholder={loadingProducts ? "Cargando productos..." : (watch('company_id') ? t('policies.selectProduct') : t('policies.selectCompanyFirst'))} />
                </SelectTrigger>
                <SelectContent>
                  {availableProducts.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.product_name} {product.product_type && `(${product.product_type})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t('common.currency')}</Label>
              <Select 
                value={watch('currency')} 
                onValueChange={(v) => setValue('currency', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="COP">COP</SelectItem>
                  <SelectItem value="MXN">MXN</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="PEN">PEN</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <PolicyTagSelect value={selectedTags} onChange={setSelectedTags} />

            {policyCategory === 'INDIVIDUAL' && (
              <>
                {hasPaidPayments && (
                  <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                    <p className="text-sm text-amber-600 dark:text-amber-400">
                      ⚠️ Esta póliza tiene pagos registrados. La frecuencia de pago y el valor de la prima no se pueden modificar.
                    </p>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>{t('policies.annualPremium')} *</Label>
                    <Input 
                      {...register('annual_premium', { required: true })} 
                      type="number" 
                      step="0.01"
                      placeholder="1200.00"
                      disabled={hasPaidPayments}
                      className={hasPaidPayments ? "bg-muted cursor-not-allowed" : ""}
                    />
                    {errors.annual_premium && <p className="text-sm text-red-500">Requerido</p>}
                  </div>
                  <div className="space-y-2">
                    <Label>{t('policies.commissionablePremium')} *</Label>
                    <Input 
                      {...register('commissionable_premium', { required: true })} 
                      type="number" 
                      step="0.01"
                      placeholder="1000.00" 
                    />
                    {errors.commissionable_premium && <p className="text-sm text-red-500">Requerido</p>}
                  </div>
                  <div className="space-y-2">
                    <Label>{t('policies.paymentFrequency')}</Label>
                    <Select 
                      value={watch('payment_frequency')} 
                      onValueChange={(v) => {
                        if (hasPaidPayments) return;
                        setValue('payment_frequency', v);
                        if (v === 'mensual' && !watch('installment_months')) {
                          setValue('installment_months', 12);
                        }
                      }}
                      disabled={hasPaidPayments}
                    >
                      <SelectTrigger className={hasPaidPayments ? "bg-muted cursor-not-allowed" : ""}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mensual">{t('payments.monthly')}</SelectItem>
                        <SelectItem value="trimestral">{t('payments.quarterly')}</SelectItem>
                        <SelectItem value="semestral">{t('payments.semiannual')}</SelectItem>
                        <SelectItem value="anual">{t('payments.annual')}</SelectItem>
                        <SelectItem value="unico">{t('payments.single')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {watch('payment_frequency') === 'mensual' && (
                  <div className="space-y-2">
                    <Label>{t('policies.installmentMonths')}</Label>
                    <Select
                      value={String(watch('installment_months') || 12)}
                      onValueChange={(v) => { if (hasPaidPayments) return; setValue('installment_months', parseInt(v)); }}
                      disabled={hasPaidPayments}
                    >
                      <SelectTrigger className={hasPaidPayments ? "bg-muted cursor-not-allowed" : ""}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(n => (
                          <SelectItem key={n} value={String(n)}>{n} {n === 12 ? 'meses (estándar)' : 'meses'}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="p-3 bg-muted/40 rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    {t('policyDetail.installmentValue')}: <span className="font-semibold">{watch('currency')} {watch('installment_amount') || '0.00'}</span>
                    {watch('payment_frequency') === 'mensual' && (
                      <span className="text-muted-foreground/70 ml-2">({watch('installment_months') || 12} {t('policies.installments')})</span>
                    )}
                  </p>
                </div>
              </>
            )}

            {policyCategory === 'CORPORATIVA' && (
              <div className="space-y-4 p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <div>
                  <p className="text-sm text-purple-600 dark:text-purple-400 font-semibold mb-1">
                    📋 Tarifario Mensual - Póliza Corporativa
                  </p>
                  <p className="text-xs text-purple-600 dark:text-purple-400">
                    Defina las tarifas mensuales por tipo de afiliado
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-purple-600 dark:text-purple-400">Titular Solo *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={corporateRates.rate_titular_solo}
                      onChange={(e) => setCorporateRates({...corporateRates, rate_titular_solo: e.target.value})}
                      placeholder="0.00"
                      className="bg-card"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-purple-600 dark:text-purple-400">Titular +1 *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={corporateRates.rate_titular_mas1}
                      onChange={(e) => setCorporateRates({...corporateRates, rate_titular_mas1: e.target.value})}
                      placeholder="0.00"
                      className="bg-card"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-purple-600 dark:text-purple-400">Familia (2+) *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={corporateRates.rate_familia}
                      onChange={(e) => setCorporateRates({...corporateRates, rate_familia: e.target.value})}
                      placeholder="0.00"
                      className="bg-card"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>{t('policies.issueDate')}</Label>
              <Input 
                {...register('issue_date')} 
                type="date"
                max={watch('start_date') || undefined}
              />
              <p className="text-xs text-muted-foreground">
                Si no se especifica, se usará la fecha de inicio de vigencia
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>{t('common.country')} *</Label>
                <CountrySelect
                  value={watch('country')}
                  onValueChange={(v) => setValue('country', v)}
                />
              </div>
              <div className="space-y-2">
                <Label>{t('policies.startDate')} *</Label>
                <Input 
                  {...register('start_date', { required: true })} 
                  type="date"
                  onChange={(e) => {
                    // Notificar a react-hook-form del cambio
                    setValue('start_date', e.target.value, { shouldValidate: true });
                    const val = e.target.value;
                    if (val && val.length === 10) {
                      const startDate = new Date(val);
                      if (!isNaN(startDate.getTime())) {
                        const endDate = new Date(startDate);
                        endDate.setDate(endDate.getDate() + 365);
                        setValue('end_date', endDate.toISOString().split('T')[0]);
                      }
                    }
                  }}
                  onBlur={(e) => {
                    const val = e.target.value;
                    if (val && val.length === 10 && !watch('issue_date')) {
                      const startDate = new Date(val);
                      if (!isNaN(startDate.getTime())) {
                        setValue('issue_date', val);
                      }
                    }
                  }}
                />
                {errors.start_date && <p className="text-sm text-red-500">Requerido</p>}
              </div>
              <div className="space-y-2">
                <Label>{t('policies.endDate')} *</Label>
                <Input {...register('end_date', { required: true })} type="date" />
                {errors.end_date && <p className="text-sm text-red-500">{t('errors.requiredField')}</p>}
                <p className="text-xs text-muted-foreground">{t('policies.autoCalculated')}</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t('common.notes')}</Label>
              <Textarea {...register('notes')} placeholder={t('policies.notesPlaceholder')} />
            </div>

            {lineName?.toLowerCase().includes('salud') && selectedProductId && (() => {
              const product = products.find(p => p.id === selectedProductId);
              // Migrar valores antiguos a arrays si es necesario
              let ded1Opts = product?.deductible_1_options || [];
              let ded2Opts = product?.deductible_2_options || [];
              
              if (ded1Opts.length === 0 && typeof product?.deductible_1 === 'number') {
                ded1Opts = [product.deductible_1];
              }
              if (ded2Opts.length === 0 && typeof product?.deductible_2 === 'number') {
                ded2Opts = [product.deductible_2];
              }
              
              return (
                <div className="grid grid-cols-3 gap-4 p-4 bg-muted rounded-lg border border-border">
                  <div className="space-y-2">
                    <Label className="text-foreground">
                      Monto Asegurado
                      {!(product?.insured_amount > 0) && (
                        <span className="ml-1 text-xs text-foreground font-normal">(editable)</span>
                      )}
                    </Label>
                    <Input 
                      {...register('insured_amount')} 
                      type="number" 
                      step="0.01"
                      readOnly={product?.insured_amount > 0}
                      className={product?.insured_amount > 0 ? "bg-muted cursor-not-allowed" : "bg-card"}
                      placeholder="0 = Ilimitado"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-foreground">Deducible 1 (Dentro del País) *</Label>
                    {ded1Opts.length > 0 ? (
                      <Select 
                        value={String(watch('deductible_1'))} 
                        onValueChange={(v) => setValue('deductible_1', parseFloat(v))}
                      >
                        <SelectTrigger className="bg-card">
                          <SelectValue placeholder="Seleccionar" />
                        </SelectTrigger>
                        <SelectContent>
                          {ded1Opts.map((option, idx) => (
                            <SelectItem key={idx} value={String(option)}>
                              ${option.toLocaleString()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input 
                        {...register('deductible_1')} 
                        type="number" 
                        step="0.01"
                        className="bg-card"
                        placeholder="No hay opciones"
                      />
                    )}
                    {errors.deductible_1 && <p className="text-sm text-red-500">Requerido</p>}
                  </div>
                  <div className="space-y-2">
                    <Label className="text-foreground">Deducible 2 (Fuera del País)</Label>
                    {ded2Opts.length > 0 ? (
                      <Select 
                        value={String(watch('deductible_2') || '0')} 
                        onValueChange={(v) => setValue('deductible_2', parseFloat(v))}
                      >
                        <SelectTrigger className="bg-card">
                          <SelectValue placeholder="Seleccionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">Sin deducible</SelectItem>
                          {ded2Opts.map((option, idx) => (
                            <SelectItem key={idx} value={String(option)}>
                              ${option.toLocaleString()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input 
                        {...register('deductible_2')} 
                        type="number" 
                        step="0.01"
                        className="bg-card"
                        placeholder="Opcional"
                      />
                    )}
                  </div>
                  <div className="col-span-3 mt-1">
                    <p className="text-xs text-foreground italic">
                      💡 El deducible se aplica según el país limitante de la cobertura: <strong>Deducible 1</strong> aplica para atenciones <strong>dentro del país</strong>, y <strong>Deducible 2</strong> para atenciones <strong>fuera del país</strong>.
                    </p>
                  </div>
                </div>
              );
            })()}

            {lineName?.toLowerCase().includes('vida') && (
              <div className="p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <Label className="text-purple-600 dark:text-purple-400 text-base font-semibold mb-3 block">SUMA ASEGURADA</Label>
                <p className="text-sm text-purple-600 dark:text-purple-400 mb-3">Valor total que reciben los dependientes en caso de fallecimiento</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-purple-600 dark:text-purple-400">Moneda</Label>
                    <Input 
                      value={watch('currency')} 
                      readOnly
                      className="bg-card"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-purple-600 dark:text-purple-400">Monto *</Label>
                    <Input 
                      {...register('sum_insured', { 
                        required: lineName?.toLowerCase().includes('vida'),
                        min: 0
                      })} 
                      type="number" 
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      className="bg-card"
                    />
                    {errors.sum_insured && <p className="text-sm text-red-500">Requerido</p>}
                  </div>
                </div>
              </div>
            )}

            {/* Datos del Bien (para Hogar) */}
            {lineName?.toLowerCase().includes('hogar') && (
              <div className="space-y-4">
                <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                  <Label className="text-green-600 dark:text-green-400 text-base font-semibold mb-3 block">DATOS DEL BIEN</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-green-600 dark:text-green-400">Tipo de Bien *</Label>
                      <Select
                        value={propertyData.property_type}
                        onValueChange={(v) => setPropertyData({...propertyData, property_type: v})}
                      >
                        <SelectTrigger className="bg-card">
                          <SelectValue placeholder="Seleccionar tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="casa">Casa</SelectItem>
                          <SelectItem value="departamento">Departamento</SelectItem>
                          <SelectItem value="edificio">Edificio</SelectItem>
                          <SelectItem value="bodega">Bodega</SelectItem>
                          <SelectItem value="otros">Otros</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-green-600 dark:text-green-400">Valor del Bien *</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={propertyData.property_value}
                        onChange={(e) => setPropertyData({...propertyData, property_value: e.target.value})}
                        placeholder="Valor comercial"
                        className="bg-card"
                      />
                    </div>
                    <div className="col-span-2 space-y-2">
                      <Label className="text-green-600 dark:text-green-400">Dirección *</Label>
                      <Input
                        value={propertyData.address}
                        onChange={(e) => setPropertyData({...propertyData, address: e.target.value})}
                        placeholder="Dirección completa del bien"
                        className="bg-card"
                      />
                    </div>
                    <div className="col-span-2 space-y-2">
                      <Label className="text-green-600 dark:text-green-400">Protecciones</Label>
                      <Textarea
                        value={propertyData.protections}
                        onChange={(e) => setPropertyData({...propertyData, protections: e.target.value})}
                        placeholder="Alarmas, cámaras, seguridad, etc."
                        className="bg-card h-20"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Datos del Vehículo y Cobertura (para Auto) */}
            {lineName?.toLowerCase().includes('auto') && (
              <div className="space-y-4">
                <div className="p-4 bg-orange-500/10 rounded-lg border border-orange-500/30">
                  <Label className="text-orange-600 dark:text-orange-400 text-base font-semibold mb-3 block">DATOS DEL VEHÍCULO</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-orange-600 dark:text-orange-400">Marca *</Label>
                      <Input
                        value={vehicleData.brand}
                        onChange={(e) => setVehicleData({...vehicleData, brand: e.target.value})}
                        placeholder="Toyota, Honda, etc."
                        className="bg-card"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-orange-600 dark:text-orange-400">Modelo *</Label>
                      <Input
                        value={vehicleData.model}
                        onChange={(e) => setVehicleData({...vehicleData, model: e.target.value})}
                        placeholder="Corolla, Civic, etc."
                        className="bg-card"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-orange-600 dark:text-orange-400">Año *</Label>
                      <Input
                        type="number"
                        min="1900"
                        max={new Date().getFullYear() + 1}
                        value={vehicleData.year}
                        onChange={(e) => setVehicleData({...vehicleData, year: e.target.value})}
                        placeholder="2024"
                        className="bg-card"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-orange-600 dark:text-orange-400">Placa *</Label>
                      <Input
                        value={vehicleData.plate}
                        onChange={(e) => setVehicleData({...vehicleData, plate: e.target.value.toUpperCase()})}
                        placeholder="ABC-1234"
                        className="bg-card"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 p-4 bg-orange-500/10 rounded-lg border border-orange-500/30">
                  <div className="space-y-2">
                    <Label className="text-orange-600 dark:text-orange-400">Suma Asegurada *</Label>
                    <Input 
                      {...register('sum_insured', { 
                        required: lineName?.toLowerCase().includes('auto')
                      })} 
                      type="number" 
                      step="0.01"
                      placeholder="Valor comercial del vehículo"
                      className="bg-card"
                    />
                    {errors.sum_insured && <p className="text-sm text-red-500">Requerido</p>}
                  </div>
                  <div className="space-y-2">
                    <Label className="text-orange-600 dark:text-orange-400">Deducible</Label>
                    <Input 
                      {...register('deductible_1')} 
                      type="number" 
                      step="0.01"
                      placeholder="Deducible aplicable"
                      className="bg-card"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Suma Asegurada genérica - para ramos distintos a salud, auto, hogar y vida */}
            {lineName && 
              !lineName.toLowerCase().includes('salud') &&
              !lineName.toLowerCase().includes('auto') &&
              !lineName.toLowerCase().includes('hogar') &&
              !lineName.toLowerCase().includes('vida') && (
              <div className="p-4 bg-muted/40 rounded-lg border border-border">
                <Label className="text-foreground text-base font-semibold mb-3 block">SUMA ASEGURADA</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-foreground/80">Moneda</Label>
                    <Input value={watch('currency')} readOnly className="bg-card" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-foreground/80">Monto</Label>
                    <Input 
                      {...register('sum_insured', { min: 0 })} 
                      type="number" 
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      className="bg-card"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Dependientes / Beneficiarios - Solo para pólizas INDIVIDUALES */}
            {!lineName?.toLowerCase().includes('auto') && !lineName?.toLowerCase().includes('hogar') && policyCategory === 'INDIVIDUAL' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-base">
                    {lineName?.toLowerCase().includes('vida') ? t('policyDetail.beneficiaries') : t('policyDetail.dependents')}
                  </Label>
                  <Button type="button" variant="outline" size="sm" onClick={addDependent}>
                    <UserPlus className="h-4 w-4 mr-2" />
                    {lineName?.toLowerCase().includes('vida') ? t('policies.addBeneficiary') : t('policies.addDependent')}
                  </Button>
                </div>
              
              {dependents.length > 0 && (
                <div className="space-y-3 border rounded-lg p-3">
                  {lineName?.toLowerCase().includes('vida') && (
                    <div className="p-2 bg-purple-500/10 rounded-lg border border-purple-500/30 space-y-1">
                      <p className="text-sm text-purple-600 dark:text-purple-400">
                        Principales: <span className="font-bold">{getTotalPercentage('principal')}%</span>
                        {getTotalPercentage('principal') !== 100 && (
                          <span className="text-red-600 dark:text-red-400 ml-2">⚠️ Debe sumar 100%</span>
                        )}
                      </p>
                      <p className="text-sm text-purple-600 dark:text-purple-400">
                        Contingentes: <span className="font-bold">{getTotalPercentage('contingente')}%</span>
                        {getTotalPercentage('contingente') !== 100 && getTotalPercentage('contingente') > 0 && (
                          <span className="text-red-600 dark:text-red-400 ml-2">⚠️ Debe sumar 100%</span>
                        )}
                      </p>
                    </div>
                  )}
                  
                  {dependents.map((dep, index) => (
                    <div key={index} className={`grid ${lineName?.toLowerCase().includes('vida') ? 'grid-cols-5' : 'grid-cols-4'} gap-3 p-3 bg-muted/40 rounded-lg relative`}>
                      <div className="space-y-1">
                        <Label className="text-xs">{t('common.name')}</Label>
                        <Input
                          value={dep.name}
                          onChange={(e) => updateDependent(index, 'name', e.target.value)}
                          placeholder="Nombre completo"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">{t('policyDetail.relationship')}</Label>
                        <Select
                          value={dep.relationship}
                          onValueChange={(v) => updateDependent(index, 'relationship', v)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="conyuge">Cónyuge</SelectItem>
                            <SelectItem value="hijo">Hijo/a</SelectItem>
                            <SelectItem value="padre">Padre</SelectItem>
                            <SelectItem value="madre">Madre</SelectItem>
                            <SelectItem value="hermano">Hermano/a</SelectItem>
                            <SelectItem value="otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">{t('clients.documentId')}</Label>
                        <Input
                          value={dep.document_id}
                          onChange={(e) => updateDependent(index, 'document_id', e.target.value)}
                          placeholder="ID"
                        />
                      </div>
                      
                      {lineName?.toLowerCase().includes('vida') ? (
                        <>
                          <div className="space-y-1">
                            <Label className="text-xs">{t('common.type')}</Label>
                            <Select
                              value={dep.beneficiary_type}
                              onValueChange={(v) => updateDependent(index, 'beneficiary_type', v)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Tipo" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="principal">Principal</SelectItem>
                                <SelectItem value="contingente">Contingente</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">{t('policyDetail.benefitPct')}</Label>
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              step="0.01"
                              value={dep.percentage}
                              onChange={(e) => updateDependent(index, 'percentage', e.target.value)}
                              placeholder="0"
                            />
                          </div>
                        </>
                      ) : (
                        <div className="space-y-1">
                          <Label className="text-xs">{t('agents.birthDate')}</Label>
                          <Input
                            type="date"
                            value={dep.birth_date}
                            onChange={(e) => updateDependent(index, 'birth_date', e.target.value)}
                          />
                        </div>
                      )}
                      
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-red-500/10 hover:bg-red-500/20"
                        onClick={() => removeDependent(index)}
                      >
                        <X className="h-4 w-4 text-red-600 dark:text-red-400" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                {t('common.cancel')}
              </Button>
              <Button type="submit" disabled={isLoading || submitting || !isFormValid} title={!isFormValid ? t('policies.completeRequired') : ''}>
                {(isLoading || submitting) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {initialData ? t('common.saveChanges') : t('policies.new')}
              </Button>
            </div>
            {!isFormValid && (
              <p className="text-xs text-amber-600 dark:text-amber-400 text-center -mt-2">
                ⚠️ Falta: {missingFields.join(', ')}
              </p>
            )}
          </form>

          <ClientForm
          open={showClientForm}
          onOpenChange={setShowClientForm}
          onSubmit={handleCreateClient}
          isLoading={clientLoading}
        />
      </DialogContent>
    </Dialog>
  );
}