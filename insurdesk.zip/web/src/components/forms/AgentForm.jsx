import { useFeatures } from '@/lib/FeatureContext';
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2, RefreshCw } from "lucide-react";
import { api } from '@/api/client';
import CountrySelect from '@/components/ui/CountrySelect';
import AgentSelect from '@/components/forms/AgentSelect';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function AgentForm({ open, onOpenChange, onSubmit, initialData, isLoading }) {
  const { limit: featureLimit } = useFeatures();
  const structureLevels = featureLimit('structure');
  const hasStructure = structureLevels > 1;
  const { t } = useTranslation();
  const [agents, setAgents] = useState([]);
  const [loadingAgents, setLoadingAgents] = useState(true);
  const [recalculating, setRecalculating] = useState(false);
  const [checkingDuplicate, setCheckingDuplicate] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState(null);
  
  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm({
    defaultValues: initialData || {
      agent_type: 'agente',
      status: 'activo',
      level: 1,
      skip_user_creation: false
    }
  });

  useEffect(() => {
    const loadAgents = async () => {
      setLoadingAgents(true);
      const agentsData = await api.entities.Agent.list();
      setAgents(agentsData.filter(a => a.id !== initialData?.id));
      setLoadingAgents(false);
    };
    if (open) loadAgents();
  }, [open, initialData]);

  useEffect(() => {
    if (open && initialData) {
      // Cargar todos los datos existentes al editar usando reset
      // Esperar a que los agentes estén cargados antes de hacer reset
      if (!loadingAgents) {
        reset(initialData);
      }
    } else if (open && !initialData) {
      reset({
        agent_type: 'agente',
        status: 'activo',
        level: 1,
        is_nivel_2: false,
        is_gapartner: false,
        alias: '',
        name: '',
        email: '',
        phone: '',
        country: '',
        upline_agent_id: null,
        user_email: ''
      });
    }
  }, [open, initialData, loadingAgents, reset]);

  const uplineId = watch('upline_agent_id');
  const agentName = watch('name');

  // Verificar duplicados al escribir el nombre
  useEffect(() => {
    const checkDuplicate = async () => {
      if (!agentName || agentName.trim().length < 3) {
        setDuplicateWarning(null);
        return;
      }

      setCheckingDuplicate(true);
      try {
        const existingAgents = await api.entities.Agent.filter({});
        const normalizedName = agentName.trim().toUpperCase();
        
        const duplicate = existingAgents.find(a => 
          a.name.trim().toUpperCase() === normalizedName && 
          a.id !== initialData?.id
        );

        if (duplicate) {
          setDuplicateWarning(`Ya existe un agente con este nombre: ${duplicate.name} (${duplicate.country})`);
        } else {
          setDuplicateWarning(null);
        }
      } catch (error) {
        console.error('Error checking duplicate:', error);
      }
      setCheckingDuplicate(false);
    };

    const timeoutId = setTimeout(checkDuplicate, 500);
    return () => clearTimeout(timeoutId);
  }, [agentName, initialData?.id]);

  useEffect(() => {
    // Solo calcular el nivel automáticamente si NO estamos editando
    if (!initialData && uplineId) {
      const upline = agents.find(a => a.id === uplineId);
      if (upline) {
        setValue('upline_agent_name', upline.name);
        setValue('level', (upline.level || 1) + 1);
      }
    } else if (!initialData && !uplineId) {
      setValue('upline_agent_name', '');
      setValue('level', 1);
    }
  }, [uplineId, agents, initialData, setValue]);

  const handleFormSubmit = (data) => {
    onSubmit({
      ...data,
      level: parseInt(data.level) || 1
    });
  };

  const handleRecalculateLevel = async () => {
    if (!initialData?.id) return;
    
    setRecalculating(true);
    try {
      const response = await api.functions.invoke('recalculateAgentLevels', {
        event: { type: 'update', entity_id: initialData.id }
      });
      
      if (response.data.success && response.data.updates?.length > 0) {
        const update = response.data.updates.find(u => u.id === initialData.id);
        if (update) {
          setValue('level', update.newLevel);
          alert(`Nivel actualizado de ${update.oldLevel} a ${update.newLevel}`);
        } else {
          alert('El nivel ya está correcto');
        }
      } else {
        alert('El nivel ya está correcto');
      }
    } catch (error) {
      console.error('Error recalculating level:', error);
      alert('Error al recalcular el nivel');
    }
    setRecalculating(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? t('agents.edit') : t('agents.new')}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('common.type')} *</Label>
              <Select 
                value={watch('agent_type')} 
                onValueChange={(v) => setValue('agent_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="agente">{t('agents.agent')}</SelectItem>
                  <SelectItem value="agencia">{t('agents.agency')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t('common.status')}</Label>
              <Select 
                value={watch('status')} 
                onValueChange={(v) => setValue('status', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="activo">{t('common.active')}</SelectItem>
                  <SelectItem value="inactivo">{t('common.inactive')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('common.name')} *</Label>
              <div className="relative">
                <Input
                  {...register('name', { required: true })}
                  placeholder="NOMBRE COMPLETO O DE AGENCIA"
                  onChange={(e) => setValue('name', e.target.value.toUpperCase())}
                  onPaste={(e) => { e.preventDefault(); const text = e.clipboardData.getData('text'); setValue('name', (watch('name') || '') + text.toUpperCase()); }}
                />
                {checkingDuplicate && (
                  <Loader2 className="absolute right-3 top-3 h-4 w-4 animate-spin text-muted-foreground/70" />
                )}
              </div>
              {errors.name && <p className="text-sm text-red-500">Requerido</p>}
              {duplicateWarning && (
                <p className="text-sm text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1">
                  ⚠️ {duplicateWarning}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>{t('common.country')} *</Label>
              <CountrySelect
                value={watch('country')}
                onValueChange={(v) => setValue('country', v)}
              />
              {errors.country && <p className="text-sm text-red-500">Requerido</p>}
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t('agents.alias')} ({t('common.optional')})</Label>
            <Input {...register('alias')} placeholder="Ej: Fito Páez" />
            <p className="text-xs text-muted-foreground">
              Alias comercial o nombre alternativo para búsqueda. No se usa en reportes ni liquidaciones.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('common.email')} *</Label>
              <Input {...register('email', { required: true })} type="email" placeholder="correo@ejemplo.com" />
              {errors.email && <p className="text-sm text-red-500">Requerido</p>}
            </div>
            <div className="space-y-2">
              <Label>{t('common.phone')}</Label>
              <Input {...register('phone')} placeholder="+57 300 123 4567" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t('agents.operationalEmail')} ({t('common.optional')})</Label>
            <Input {...register('operational_email')} type="email" placeholder="operativo@ejemplo.com" />
            <p className="text-xs text-muted-foreground">Correo de la persona operativa de contacto, si aplica.</p>
          </div>

          <div className="space-y-2">
            <Label>{t('agents.birthDate')}</Label>
            <Input {...register('birth_date')} type="date" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            {hasStructure && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>{t('agents.upline')}</Label>
                {initialData && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleRecalculateLevel}
                    disabled={recalculating}
                    className="h-6 px-2 text-xs"
                  >
                    {recalculating ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <RefreshCw className="h-3 w-3" />
                    )}
                    <span className="ml-1">Recalcular nivel</span>
                  </Button>
                )}
                </div>
                <AgentSelect
                agents={agents}
                value={watch('upline_agent_id') || ''}
                onValueChange={(v) => setValue('upline_agent_id', v || null)}
                placeholder="Sin superior (nivel 1)"
                />
                {Number.isFinite(structureLevels) && <p className="text-xs text-muted-foreground">Tu plan permite hasta {structureLevels} niveles de estructura.</p>}
                <p className="text-xs text-muted-foreground">Nivel calculado: {watch('level')}</p>
                </div>
            )}
            <div className="space-y-2">
              <Label>{t('agents.userEmail')}</Label>
              <Input {...register('user_email')} type="email" placeholder="usuario@ejemplo.com" />
              <p className="text-xs text-muted-foreground">Vincular con cuenta de usuario existente</p>
            </div>
          </div>

          <div className="space-y-3 p-4 bg-muted/40 rounded-lg">
            <Label className="font-semibold">Clasificación</Label>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="is_nivel_2"
                  {...register('is_nivel_2')}
                  className="rounded"
                />
                <Label htmlFor="is_nivel_2" className="cursor-pointer text-orange-600 dark:text-orange-400 font-medium">Es Partner</Label>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="is_gapartner"
                  {...register('is_gapartner')}
                  className="rounded"
                />
                <Label htmlFor="is_gapartner" className="cursor-pointer text-emerald-600 dark:text-emerald-400 font-medium">Es GAPartner+</Label>
              </div>
            </div>
          </div>

          {!initialData && (
            <div className="space-y-3 p-4 bg-muted rounded-lg border border-border">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="skip_user_creation"
                  {...register('skip_user_creation')}
                  className="rounded"
                />
                <Label htmlFor="skip_user_creation" className="cursor-pointer text-foreground font-medium">
                  No crear usuario automáticamente
                </Label>
              </div>
              <p className="text-xs text-foreground">
                Al crear el agente se enviará automáticamente una invitación al correo registrado para que pueda acceder a la plataforma con perfil de agente. Marca esta opción si no deseas crear el usuario.
              </p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isLoading || duplicateWarning}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {initialData ? t('common.saveChanges') : t('agents.new')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}