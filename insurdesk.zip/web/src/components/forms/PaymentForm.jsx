import React from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";

export default function PaymentForm({ open, onOpenChange, onSubmit, initialData, isLoading, policyInfo }) {
  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm({
    defaultValues: initialData || {
      status: 'pendiente',
      payment_method: 'transferencia',
      currency: policyInfo?.currency || 'USD',
      amount: policyInfo?.installment_amount || 0
    }
  });

  React.useEffect(() => {
    if (initialData) {
      reset(initialData);
    } else {
      reset({
        status: 'pendiente',
        payment_method: 'transferencia',
        currency: policyInfo?.currency || 'USD',
        amount: policyInfo?.installment_amount || 0,
        policy_id: policyInfo?.id,
        policy_number: policyInfo?.policy_number,
        client_name: policyInfo?.client_name
      });
    }
  }, [initialData, policyInfo, reset]);

  const handleFormSubmit = (data) => {
    const paymentData = {
      ...data,
      amount: parseFloat(data.amount)
    };
    
    // Optimistic update - add pending payment immediately
    if (!initialData) {
      const pendingPayment = {
        ...paymentData,
        id: 'pending-' + Date.now(),
        _isPending: true
      };
      onSubmit(pendingPayment, true); // Pass pending flag
    } else {
      onSubmit(paymentData);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Editar Pago' : 'Registrar Pago'}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          {policyInfo && (
            <div className="p-3 bg-muted/40 rounded-lg">
              <p className="text-sm text-muted-foreground">
                Póliza: <span className="font-semibold">{policyInfo.policy_number}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Cliente: <span className="font-semibold">{policyInfo.client_name}</span>
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Fecha de Vencimiento *</Label>
              <Input {...register('due_date', { required: true })} type="date" />
              {errors.due_date && <p className="text-sm text-red-500">Requerido</p>}
            </div>
            <div className="space-y-2">
              <Label>Fecha de Pago</Label>
              <Input {...register('payment_date')} type="date" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Período</Label>
              <Input {...register('period')} placeholder="Enero 2024" />
            </div>
            <div className="space-y-2">
              <Label>Número de Cuota</Label>
              <Input {...register('installment_number')} type="number" min="1" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Monto *</Label>
              <Input 
                {...register('amount', { required: true })} 
                type="number" 
                step="0.01"
              />
              {errors.amount && <p className="text-sm text-red-500">Requerido</p>}
            </div>
            <div className="space-y-2">
              <Label>Moneda</Label>
              <Select 
                value={watch('currency')} 
                onValueChange={(v) => setValue('currency', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="COP">COP</SelectItem>
                  <SelectItem value="MXN">MXN</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Método de Pago</Label>
              <Select 
                value={watch('payment_method')} 
                onValueChange={(v) => setValue('payment_method', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="efectivo">Efectivo</SelectItem>
                  <SelectItem value="transferencia">Transferencia</SelectItem>
                  <SelectItem value="tarjeta">Tarjeta</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                  <SelectItem value="otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Estado</Label>
              <Select 
                value={watch('status')} 
                onValueChange={(v) => setValue('status', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pendiente">Pendiente</SelectItem>
                  <SelectItem value="pagado">Pagado</SelectItem>
                  <SelectItem value="atrasado">Atrasado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notas</Label>
            <Textarea {...register('notes')} placeholder="Observaciones..." rows={3} />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {initialData ? 'Guardar Cambios' : 'Registrar Pago'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}