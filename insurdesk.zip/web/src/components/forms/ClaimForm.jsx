import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2, Receipt } from "lucide-react";
import { api } from '@/api/client';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';
import ClaimInvoiceDetail from '@/components/claims/ClaimInvoiceDetail';

export default function ClaimForm({ open, onOpenChange, onSubmit, initialData, isLoading, policyInfo }) {
  const { t } = useTranslation();
  const [corporateMembers, setCorporateMembers] = useState([]);
  const [selectedTitular, setSelectedTitular] = useState(null);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [hasInvoiceDetail, setHasInvoiceDetail] = useState(initialData?.has_invoice_detail || false);
  const [invoiceDetails, setInvoiceDetails] = useState(initialData?.invoice_details || []);
  
  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm({
    defaultValues: initialData || {
      status: 'en_proceso',
      currency: policyInfo?.currency || 'USD',
      affected_person: 'titular'
    }
  });

  useEffect(() => {
    const loadMembersData = async () => {
      if (open && policyInfo?.policy_category === 'CORPORATIVA') {
        setLoadingMembers(true);
        const members = await api.entities.CorporateMember.filter({ 
          policy_id: policyInfo.id,
          status: 'activo'
        });
        setCorporateMembers(members);
        setLoadingMembers(false);
      }
    };
    
    loadMembersData();
  }, [open, policyInfo]);

  useEffect(() => {
    if (initialData) {
      reset(initialData);
      setHasInvoiceDetail(initialData.has_invoice_detail || false);
      setInvoiceDetails(initialData.invoice_details || []);
    } else if (policyInfo) {
      reset({
        status: 'en_proceso',
        currency: policyInfo.currency || 'USD',
        policy_id: policyInfo.id,
        policy_number: policyInfo.policy_number,
        client_id: policyInfo.client_id,
        client_name: policyInfo.client_name,
        claim_number: `SIN-${Date.now().toString().slice(-6)}`,
        affected_person: 'titular'
      });
      setSelectedTitular(null);
    }
  }, [initialData, policyInfo, reset]);

  const handleFormSubmit = (data) => {
    // If using invoice detail, derive claimed_amount from sum of invoices
    const derivedClaimed = hasInvoiceDetail
      ? invoiceDetails.reduce((s, inv) => s + (parseFloat(inv.amount_claimed) || 0), 0)
      : parseFloat(data.claimed_amount) || 0;

    const sanitizedInvoices = invoiceDetails.map(inv => ({
      ...inv,
      amount_claimed: parseFloat(inv.amount_claimed) || 0,
      amount_paid: parseFloat(inv.amount_paid) || 0,
    }));

    const claimData = {
      ...data,
      claimed_amount: derivedClaimed,
      paid_amount: 0, // always starts at 0 (paid later on settlement)
      has_invoice_detail: hasInvoiceDetail,
      invoice_details: hasInvoiceDetail ? sanitizedInvoices : []
    };
    
    // For corporate policies, add member info
    if (policyInfo?.policy_category === 'CORPORATIVA') {
      if (data.affected_person === 'titular' && data.corporate_member_id) {
        const member = corporateMembers.find(m => m.id === data.corporate_member_id);
        if (member) {
          claimData.corporate_member_id = member.id;
          claimData.corporate_member_name = `${member.first_name} ${member.last_name}`;
        }
      } else if (data.affected_person === 'dependiente' && data.dependent_member_id) {
        const dependent = corporateMembers.find(m => m.id === data.dependent_member_id);
        if (dependent) {
          claimData.corporate_member_id = dependent.id;
          claimData.corporate_member_name = `${dependent.first_name} ${dependent.last_name}`;
        }
      }
    }
    
    // Optimistic update - add pending claim immediately
    if (!initialData) {
      const pendingClaim = {
        ...claimData,
        id: 'pending-' + Date.now(),
        _isPending: true
      };
      onSubmit(pendingClaim, true);
      onOpenChange(false);
    } else {
      onSubmit(claimData);
      onOpenChange(false);
    }
  };

  const dependents = policyInfo?.dependents || [];
  
  const affectedPersonValue = watch('affected_person');
  const selectedMemberId = watch('corporate_member_id');
  
  // Get dependents for selected titular
  const availableDependents = selectedTitular 
    ? corporateMembers.filter(m => m.parent_member_id === selectedTitular && m.member_type === 'DEPENDIENTE')
    : [];
  
  // Get all titulares for corporate policies
  const titulares = corporateMembers.filter(m => m.member_type === 'TITULAR');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? t('claims.edit') : t('claims.new')}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          {policyInfo && (
            <div className="p-3 bg-muted/40 rounded-lg">
              <p className="text-sm text-muted-foreground">
                {t('nav.policies')}: <span className="font-semibold">{policyInfo.policy_number}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                {t('policies.client')}: <span className="font-semibold">{policyInfo.client_name}</span>
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('claims.claimNumber')} *</Label>
              <Input {...register('claim_number', { required: true })} />
              {errors.claim_number && <p className="text-sm text-red-500">Requerido</p>}
            </div>
            <div className="space-y-2">
              <Label>{t('claims.eventDate')} *</Label>
              <Input {...register('event_date', { required: true })} type="date" />
              {errors.event_date && <p className="text-sm text-red-500">Requerido</p>}
            </div>
          </div>

          {policyInfo?.policy_category === 'CORPORATIVA' ? (
            <>
              <div className="space-y-2">
                <Label>{t('claims.affectedPerson')} *</Label>
                <Select 
                  value={watch('affected_person')} 
                  onValueChange={(v) => {
                    setValue('affected_person', v);
                    setSelectedTitular(null);
                    setValue('corporate_member_id', '');
                    setValue('dependent_member_id', '');
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="titular">{t('claims.holder')}</SelectItem>
                    <SelectItem value="dependiente">{t('claims.dependent')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {affectedPersonValue === 'titular' && (
                <div className="space-y-2">
                  <Label>{t('claims.selectHolder')} *</Label>
                  <Select 
                    value={watch('corporate_member_id')} 
                    onValueChange={(v) => {
                      setValue('corporate_member_id', v);
                      setSelectedTitular(v);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('claims.selectHolderPlaceholder')} />
                    </SelectTrigger>
                    <SelectContent>
                      {titulares.map((titular) => (
                        <SelectItem key={titular.id} value={titular.id}>
                          {titular.first_name} {titular.last_name} - {titular.document_id}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {affectedPersonValue === 'dependiente' && (
                <>
                  <div className="space-y-2">
                    <Label>{t('claims.selectHolder')} *</Label>
                    <Select 
                      value={selectedTitular || ''} 
                      onValueChange={(v) => {
                        setSelectedTitular(v);
                        setValue('dependent_member_id', '');
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={t('claims.selectHolderFirst')} />
                      </SelectTrigger>
                      <SelectContent>
                        {titulares.map((titular) => (
                          <SelectItem key={titular.id} value={titular.id}>
                            {titular.first_name} {titular.last_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedTitular && (
                    <div className="space-y-2">
                      <Label>{t('claims.selectDependent')} *</Label>
                      {availableDependents.length > 0 ? (
                        <Select 
                          value={watch('dependent_member_id')} 
                          onValueChange={(v) => setValue('dependent_member_id', v)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={t('claims.selectDependentPlaceholder')} />
                          </SelectTrigger>
                          <SelectContent>
                            {availableDependents.map((dep) => (
                              <SelectItem key={dep.id} value={dep.id}>
                                {dep.first_name} {dep.last_name} ({dep.relationship})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <div className="p-3 bg-amber-500/10 rounded-lg border border-amber-500/30 text-sm text-amber-600 dark:text-amber-400">
                         {t('claims.noMemberDependents')}
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}

              <div className="space-y-2">
                <Label>{t('claims.claimType')} *</Label>
                <Input {...register('claim_type', { required: true })} placeholder={t('claims.claimTypePlaceholder')} />
                {errors.claim_type && <p className="text-sm text-red-500">{t('errors.requiredField')}</p>}
              </div>
            </>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t('claims.affectedPerson')} *</Label>
                <Select 
                  value={watch('affected_person')} 
                  onValueChange={(v) => {
                    setValue('affected_person', v);
                    if (v === 'titular') {
                      setValue('dependent_name', '');
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="titular">{t('claims.holder')}</SelectItem>
                    <SelectItem value="dependiente">{t('claims.dependent')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {watch('affected_person') === 'dependiente' && (
                <div className="space-y-2">
                  <Label>{t('claims.selectDependent')} *</Label>
                  <Select 
                    value={watch('dependent_name')} 
                    onValueChange={(v) => setValue('dependent_name', v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('claims.selectDependentPlaceholder')} />
                    </SelectTrigger>
                    <SelectContent>
                      {dependents.map((dep, index) => (
                        <SelectItem key={index} value={dep.name}>
                          {dep.name} ({dep.relationship})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label>{t('claims.claimType')} *</Label>
                <Input {...register('claim_type', { required: true })} placeholder={t('claims.claimTypePlaceholder')} />
                {errors.claim_type && <p className="text-sm text-red-500">{t('errors.requiredField')}</p>}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('common.currency')}</Label>
              <Select 
                value={watch('currency')} 
                onValueChange={(v) => setValue('currency', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="COP">COP</SelectItem>
                  <SelectItem value="MXN">MXN</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Invoice detail toggle */}
          <div className="border rounded-lg p-3 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground/80">Detalle de Facturas</span>
                <span className="text-xs text-muted-foreground/70">(opcional)</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setHasInvoiceDetail(!hasInvoiceDetail);
                  if (hasInvoiceDetail) setInvoiceDetails([]);
                }}
                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${hasInvoiceDetail ? 'bg-primary' : 'bg-muted-foreground/30'}`}
              >
                <span className={`inline-block h-3.5 w-3.5 rounded-full bg-card transition-transform ${hasInvoiceDetail ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>

            {hasInvoiceDetail ? (
              <ClaimInvoiceDetail
                invoices={invoiceDetails}
                onChange={setInvoiceDetails}
                currency={watch('currency') || 'USD'}
              />
            ) : (
              <div className="space-y-2">
                <Label>{t('claims.claimedAmount')} *</Label>
                <Input 
                  {...register('claimed_amount', { required: !hasInvoiceDetail })} 
                  type="number" 
                  step="0.01"
                />
                {errors.claimed_amount && <p className="text-sm text-red-500">Requerido</p>}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>{t('claims.observations')}</Label>
            <Textarea {...register('observations')} placeholder={t('claims.observationsPlaceholder')} rows={3} />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {initialData ? t('common.saveChanges') : t('claims.register')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}