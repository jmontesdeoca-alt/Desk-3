import React, { useState } from 'react';
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";

export default function AgentSelect({ agents, value, onValueChange, disabled }) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const normalizeText = (text) => {
    if (!text) return '';
    return text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  };

  const matchesSearch = (agent) => {
    const normalized = normalizeText(searchTerm);
    const nameMatch = normalizeText(agent.name).includes(normalized);
    const aliasMatch = agent.alias && normalizeText(agent.alias).includes(normalized);
    return nameMatch || aliasMatch;
  };

  const wasFoundByAlias = (agent) => {
    if (!searchTerm || !agent.alias) return false;
    const normalized = normalizeText(searchTerm);
    const aliasMatch = normalizeText(agent.alias).includes(normalized);
    const nameMatch = normalizeText(agent.name).includes(normalized);
    return aliasMatch && !nameMatch;
  };

  const filteredAgents = agents.filter(matchesSearch);
  const selectedAgent = agents.find(a => a.id === value);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
          disabled={disabled}
        >
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="truncate">{selectedAgent ? selectedAgent.name : "Buscar agente..."}</span>
            {selectedAgent?.alias && (
              <Badge variant="secondary" className="text-xs shrink-0">Alias</Badge>
            )}
          </div>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput 
            placeholder="Buscar por nombre o alias..." 
            value={searchTerm}
            onValueChange={setSearchTerm}
          />
          <CommandEmpty>No se encontró ningún agente.</CommandEmpty>
          <CommandGroup className="max-h-64 overflow-auto">
            {filteredAgents.map((agent) => {
              const foundByAlias = wasFoundByAlias(agent);
              return (
                <CommandItem
                  key={agent.id}
                  value={agent.id}
                  onSelect={() => {
                    onValueChange(agent.id === value ? '' : agent.id);
                    setOpen(false);
                    setSearchTerm('');
                  }}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === agent.id ? "opacity-100" : "opacity-0"
                    )}
                  />
                  <div className="flex items-center gap-2 flex-1">
                    <span>{agent.name}</span>
                    {(foundByAlias || agent.alias) && (
                      <Badge variant="secondary" className="text-xs">
                        Alias
                      </Badge>
                    )}
                  </div>
                </CommandItem>
              );
            })}
          </CommandGroup>
        </Command>
      </PopoverContent>
    </Popover>
  );
}