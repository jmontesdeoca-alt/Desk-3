import React, { useState } from 'react';
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function ClientSelect({ clients, value, onValueChange, disabled, placeholder = "Buscar cliente..." }) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const normalizeText = (text) => {
    if (!text) return '';
    return text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  };

  const getClientName = (client) => {
    return client.client_type === 'persona' 
      ? `${client.first_name || ''} ${client.last_name || ''}`.trim() 
      : client.company_name || '';
  };

  const matchesSearch = (client) => {
    const normalized = normalizeText(searchTerm);
    const fullName = getClientName(client);
    const nameMatch = normalizeText(fullName).includes(normalized);
    
    // Para personas, también buscar por first_name y last_name por separado
    if (client.client_type === 'persona') {
      const firstNameMatch = normalizeText(client.first_name || '').includes(normalized);
      const lastNameMatch = normalizeText(client.last_name || '').includes(normalized);
      return nameMatch || firstNameMatch || lastNameMatch;
    }
    
    return nameMatch;
  };

  const filteredClients = clients.filter(matchesSearch);
  const selectedClient = clients.find(c => c.id === value);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
          disabled={disabled}
        >
          <span className="truncate min-w-0">
            {selectedClient ? `${getClientName(selectedClient)} - ${selectedClient.document_id}` : placeholder}
          </span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput 
            placeholder="Buscar por nombre o apellido..." 
            value={searchTerm}
            onValueChange={setSearchTerm}
          />
          <CommandEmpty>No se encontró ningún cliente.</CommandEmpty>
          <CommandGroup className="max-h-64 overflow-auto">
            {filteredClients.map((client) => (
              <CommandItem
                key={client.id}
                value={client.id}
                onSelect={() => {
                  onValueChange(client.id === value ? '' : client.id);
                  setOpen(false);
                  setSearchTerm('');
                }}
              >
                <Check
                  className={cn(
                    "mr-2 h-4 w-4",
                    value === client.id ? "opacity-100" : "opacity-0"
                  )}
                />
                <div className="flex flex-col">
                  <span>{getClientName(client)}</span>
                  <span className="text-xs text-muted-foreground">{client.document_id}</span>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        </Command>
      </PopoverContent>
    </Popover>
  );
}