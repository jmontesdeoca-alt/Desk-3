import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from 'lucide-react';

/**
 * mode: 'propuesta' | 'directa'
 */
export default function RenewalFormDialog({ open, onOpenChange, policy, form, onFormChange, onCreateProposal, onRenewDirect, saving }) {
  if (!policy) return null;

  const isDirect = form.mode === 'directa';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {isDirect ? 'Renovar Póliza Directamente' : 'Crear Propuesta de Renovación'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Policy Summary */}
          <div className="p-4 bg-muted/40 rounded-lg space-y-1">
            <p className="text-sm text-muted-foreground">Póliza a renovar</p>
            <p className="font-semibold">{policy.policy_number}</p>
            <p className="text-sm">{policy.client_name}</p>
            <p className="text-sm text-muted-foreground">{policy.product_name}</p>
            <p className="text-sm font-medium mt-1">
              Prima actual: {policy.currency} {policy.annual_premium?.toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground/70">
              Vigencia actual: {policy.start_date} → {policy.end_date}
            </p>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nueva Prima Anual</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={form.new_premium}
                  onChange={(e) => onFormChange({ ...form, new_premium: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Prima Comisionable</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={form.new_commissionable_premium}
                  onChange={(e) => onFormChange({ ...form, new_commissionable_premium: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Frecuencia de Pago</Label>
              <Select
                value={form.payment_frequency}
                onValueChange={(value) => onFormChange({ ...form, payment_frequency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mensual">Mensual</SelectItem>
                  <SelectItem value="trimestral">Trimestral</SelectItem>
                  <SelectItem value="semestral">Semestral</SelectItem>
                  <SelectItem value="anual">Anual</SelectItem>
                  <SelectItem value="unico">Único</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nueva Vigencia Desde</Label>
                <Input
                  type="date"
                  value={form.new_start_date}
                  onChange={(e) => onFormChange({ ...form, new_start_date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Nueva Vigencia Hasta</Label>
                <Input
                  type="date"
                  value={form.new_end_date}
                  onChange={(e) => onFormChange({ ...form, new_end_date: e.target.value })}
                />
              </div>
            </div>
          </div>

          {isDirect && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-sm text-amber-600 dark:text-amber-400">
              <strong>⚠️ Renovación directa:</strong> La póliza original pasará a estado <strong>renovada</strong> y se creará una nueva póliza activa con sus cuotas y comisiones generadas automáticamente.
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-2 border-t">
            <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            {!isDirect && (
              <Button onClick={onCreateProposal} disabled={saving} className="bg-primary hover:bg-primary/90">
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Crear Propuesta
              </Button>
            )}
            {isDirect && (
              <Button onClick={onRenewDirect} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700">
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Renovar
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}