import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

export default function EndorsementForm({ open, onOpenChange, onSubmit, policyInfo, isLoading }) {
  const { t } = useTranslation();
  const { register, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm({
    defaultValues: {
      endorsement_type: 'cambio_datos',
      status: 'pendiente',
      endorsement_date: new Date().toISOString().split('T')[0],
      effective_date: new Date().toISOString().split('T')[0]
    }
  });

  useEffect(() => {
    if (open && policyInfo) {
      const endorsementNum = `END-${policyInfo.policy_number}-${Date.now().toString().slice(-6)}`;
      reset({
        endorsement_type: 'cambio_datos',
        status: 'pendiente',
        endorsement_date: new Date().toISOString().split('T')[0],
        effective_date: new Date().toISOString().split('T')[0],
        endorsement_number: endorsementNum,
        policy_id: policyInfo.id,
        policy_number: policyInfo.policy_number,
        previous_annual_premium: policyInfo.annual_premium,
        new_annual_premium: policyInfo.annual_premium,
        reason: '',
        notes: '',
        premium_difference: 0
      });
    }
  }, [open, policyInfo, reset]);

  const endorsementType = watch('endorsement_type');
  const previousPremium = watch('previous_annual_premium');
  const newPremium = watch('new_annual_premium');
  const effectiveDate = watch('effective_date');

  useEffect(() => {
    if (endorsementType === 'cancelacion' && policyInfo && effectiveDate) {
      const startDate = new Date(policyInfo.start_date);
      const endDate = new Date(policyInfo.end_date);
      const cancelDate = new Date(effectiveDate);
      const totalDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
      const remainingDays = Math.ceil((endDate - cancelDate) / (1000 * 60 * 60 * 24));
      if (remainingDays > 0 && totalDays > 0) {
        const unearnedPremium = (policyInfo.annual_premium * remainingDays) / totalDays;
        const newPremiumValue = policyInfo.annual_premium - unearnedPremium;
        setValue('new_annual_premium', newPremiumValue.toFixed(2));
        setValue('premium_difference', (-unearnedPremium).toFixed(2));
      }
    } else if (endorsementType === 'exclusion_dependiente' && newPremium) {
      // Exclusion: user enters the amount to reduce (positive), we negate it
      const reduction = parseFloat(newPremium) || 0;
      setValue('premium_difference', (-reduction).toFixed(2));
    } else if (previousPremium && newPremium) {
      const difference = parseFloat(newPremium) - parseFloat(previousPremium);
      setValue('premium_difference', difference.toFixed(2));
    }
  }, [endorsementType, previousPremium, newPremium, effectiveDate, policyInfo, setValue]);

  const handleFormSubmit = (data) => {
    const prevPremium = parseFloat(data.previous_annual_premium) || 0;
    const newPremium = parseFloat(data.new_annual_premium) || 0;
    const diff = newPremium - prevPremium;
    onSubmit({
      ...data,
      previous_annual_premium: prevPremium,
      new_annual_premium: newPremium,
      premium_difference: parseFloat(data.premium_difference) || diff
    });
  };

  const showPremiumFields = ['aumento_prima', 'reduccion_prima', 'inclusion_dependiente', 'exclusion_dependiente'].includes(endorsementType);
  const isCancellation = endorsementType === 'cancelacion';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('endorsements.new')} - {policyInfo?.policy_number}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('endorsements.number')} *</Label>
              <Input {...register('endorsement_number', { required: true })} readOnly className="bg-muted/40" />
            </div>
            <div className="space-y-2">
              <Label>{t('endorsements.type')} *</Label>
              <Select 
                value={watch('endorsement_type')} 
                onValueChange={(v) => setValue('endorsement_type', v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aumento_prima">{t('endorsements.premiumIncrease')}</SelectItem>
                  <SelectItem value="reduccion_prima">{t('endorsements.premiumReduction')}</SelectItem>
                  <SelectItem value="cancelacion">{t('endorsements.cancellation')}</SelectItem>
                  <SelectItem value="cambio_beneficiarios">{t('endorsements.beneficiaryChange')}</SelectItem>
                  <SelectItem value="cambio_cobertura">{t('endorsements.coverageChange')}</SelectItem>
                  <SelectItem value="inclusion_dependiente">{t('endorsements.dependentInclusion')}</SelectItem>
                  <SelectItem value="exclusion_dependiente">{t('endorsements.dependentExclusion')}</SelectItem>
                  <SelectItem value="cambio_datos">{t('endorsements.dataChange')}</SelectItem>
                  <SelectItem value="otro">{t('common.other')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('endorsements.date')} *</Label>
              <Input {...register('endorsement_date', { required: true })} type="date" />
            </div>
            <div className="space-y-2">
              <Label>{t('endorsements.effectiveDate')} *</Label>
              <Input {...register('effective_date', { required: true })} type="date" />
            </div>
          </div>

          {isCancellation && (
            <>
              <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/30">
                <h4 className="font-semibold text-red-600 dark:text-red-400 mb-2">⚠ {t('endorsements.cancellation')}</h4>
                <p className="text-sm text-red-600 dark:text-red-400 mb-3">
                  {t('endorsements.cancellationDesc')}
                </p>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <Label className="text-red-600 dark:text-red-400 text-xs">{t('endorsements.totalPremium')}</Label>
                    <Input 
                      {...register('previous_annual_premium')} 
                      type="number" 
                      step="0.01"
                      readOnly
                      className="bg-card text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-red-600 dark:text-red-400 text-xs">{t('endorsements.earnedPremium')}</Label>
                    <Input 
                      {...register('new_annual_premium')} 
                      type="number" 
                      step="0.01"
                      readOnly
                      className="bg-card text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-red-600 dark:text-red-400 text-xs">{t('endorsements.premiumToReverse')}</Label>
                    <Input 
                      {...register('premium_difference')} 
                      readOnly
                      className="bg-card font-semibold text-red-600 dark:text-red-400 text-sm"
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          {showPremiumFields && !isCancellation && (
            <>
              <div className="grid grid-cols-3 gap-4 p-4 bg-amber-500/10 rounded-lg border border-amber-500/30">
                <div className="space-y-2">
                  <Label className="text-amber-600 dark:text-amber-400">{t('endorsements.previousPremium')}</Label>
                  <Input 
                    {...register('previous_annual_premium')} 
                    type="number" 
                    step="0.01"
                    readOnly
                    className="bg-card"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-amber-600 dark:text-amber-400">
                    {endorsementType === 'inclusion_dependiente' ? t('endorsements.additionalPremium') :
                     endorsementType === 'exclusion_dependiente' ? t('endorsements.amountToReduce') : t('endorsements.newPremium')}
                  </Label>
                  <Input 
                    {...register('new_annual_premium', { required: true })} 
                    type="number" 
                    step="0.01"
                    min="0"
                    placeholder={
                      endorsementType === 'inclusion_dependiente' ? 'Costo del dependiente' :
                      endorsementType === 'exclusion_dependiente' ? 'Ej: 120.00' : ''
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-amber-600 dark:text-amber-400">{t('policyDetail.premiumDiff')}</Label>
                  <Input 
                    {...register('premium_difference')} 
                    readOnly
                    className={`bg-card font-semibold ${
                      parseFloat(watch('premium_difference') || 0) > 0 
                        ? 'text-green-600 dark:text-green-400' 
                        : 'text-red-600 dark:text-red-400'
                    }`}
                  />
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                {parseFloat(watch('premium_difference') || 0) > 0 
                  ? `✓ ${t('endorsements.positiveCommissions')}`
                  : parseFloat(watch('premium_difference') || 0) < 0
                    ? `⚠ ${t('endorsements.negativeCommissions')}`
                    : ''}
              </p>
            </>
          )}

          <div className="space-y-2">
            <Label>{t('endorsements.reason')} *</Label>
            <Textarea 
              {...register('reason', { required: true })} 
              rows={3}
              placeholder={t('endorsements.reasonPlaceholder')}
            />
            {errors.reason && <p className="text-sm text-red-500">{t('errors.requiredField')}</p>}
          </div>

          <div className="space-y-2">
            <Label>{t('endorsements.additionalNotes')}</Label>
            <Textarea 
              {...register('notes')} 
              rows={2}
              placeholder={t('endorsements.notesPlaceholder')}
            />
          </div>

          <div className="space-y-2">
            <Label>{t('common.status')}</Label>
            <Select 
              value={watch('status')} 
              onValueChange={(v) => setValue('status', v)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pendiente">{t('endorsements.pending')}</SelectItem>
                <SelectItem value="aprobado">{t('endorsements.approved')}</SelectItem>
                <SelectItem value="aplicado">{t('endorsements.applied')}</SelectItem>
                <SelectItem value="rechazado">{t('endorsements.rejected')}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {t('endorsements.create')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}