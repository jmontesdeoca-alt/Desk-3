import React, { useState } from 'react';
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function PolicySelect({ policies, value, onValueChange, disabled, placeholder = "Buscar póliza..." }) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const normalizeText = (text) => {
    if (!text) return '';
    return text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  };

  const matchesSearch = (policy) => {
    const normalized = normalizeText(searchTerm);
    const numberMatch = normalizeText(policy.policy_number || '').includes(normalized);
    const clientMatch = normalizeText(policy.client_name || '').includes(normalized);
    return numberMatch || clientMatch;
  };

  const filteredPolicies = policies.filter(matchesSearch);
  const selectedPolicy = policies.find(p => p.id === value);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
          disabled={disabled}
        >
          <span className="truncate min-w-0">
            {selectedPolicy ? `${selectedPolicy.policy_number} - ${selectedPolicy.client_name}` : placeholder}
          </span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput
            placeholder="Buscar por número o cliente..."
            value={searchTerm}
            onValueChange={setSearchTerm}
          />
          <CommandEmpty>No se encontró ninguna póliza.</CommandEmpty>
          <CommandGroup className="max-h-64 overflow-auto">
            {filteredPolicies.map((policy) => (
              <CommandItem
                key={policy.id}
                value={policy.id}
                onSelect={() => {
                  onValueChange(policy.id === value ? '' : policy.id);
                  setOpen(false);
                  setSearchTerm('');
                }}
              >
                <Check
                  className={cn(
                    "mr-2 h-4 w-4",
                    value === policy.id ? "opacity-100" : "opacity-0"
                  )}
                />
                <div className="flex flex-col">
                  <span>{policy.policy_number}</span>
                  <span className="text-xs text-muted-foreground">{policy.client_name}</span>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        </Command>
      </PopoverContent>
    </Popover>
  );
}