import React, { useState, useEffect, useRef } from 'react';
import { api } from '@/api/client';
import { Label } from '@/components/ui/label';
import { Loader2, Tag, ChevronDown, X, Check } from 'lucide-react';
import { getTagIcon, getTagColorClasses } from '@/components/policy/policyTagIcons';

export default function PolicyTagSelect({ value = [], onChange }) {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const loadTags = async () => {
      try {
        const data = await api.entities.PolicyTag.filter({ status: 'activo' });
        setTags(data.sort((a, b) => a.name.localeCompare(b.name)));
      } catch (err) {
        console.error('Error loading policy tags:', err);
      } finally {
        setLoading(false);
      }
    };
    loadTags();
  }, []);

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const toggleTag = (tag) => {
    const isSelected = value.some(t => t.id === tag.id);
    if (isSelected) {
      onChange(value.filter(t => t.id !== tag.id));
    } else {
      onChange([...value, { id: tag.id, name: tag.name, icon: tag.icon, color: tag.color }]);
    }
  };

  const removeTag = (tagId) => {
    onChange(value.filter(t => t.id !== tagId));
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        Cargando etiquetas...
      </div>
    );
  }

  if (tags.length === 0) return null;

  return (
    <div className="relative space-y-2" ref={ref}>
      <Label className="flex items-center gap-1.5">
        <Tag className="h-3.5 w-3.5" />
        Etiquetas (opcional)
      </Label>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
      >
        <span className="truncate text-muted-foreground">
          {value.length > 0 ? `${value.length} etiqueta(s) seleccionada(s)` : 'Seleccionar etiquetas...'}
        </span>
        <ChevronDown className="h-4 w-4 opacity-50 shrink-0 ml-2" />
      </button>
      {open && (
        <div className="absolute left-0 right-0 z-50 mt-1 rounded-md border bg-card shadow-lg max-h-64 overflow-auto">
          {tags.map(tag => {
            const Icon = getTagIcon(tag.icon);
            const colorClass = getTagColorClasses(tag.color);
            const isSelected = value.some(t => t.id === tag.id);
            return (
              <div
                key={tag.id}
                className="flex items-center gap-2 px-3 py-2 hover:bg-muted/40 cursor-pointer text-sm"
                onClick={() => toggleTag(tag)}
              >
                <div className={`h-4 w-4 rounded border flex items-center justify-center transition-colors shrink-0 ${isSelected ? 'bg-primary border-primary' : 'border-input bg-card'}`}>
                  {isSelected && <Check className="h-3 w-3 text-white" />}
                </div>
                <Icon className="h-4 w-4 text-muted-foreground" />
                <span className="flex-1">{tag.name}</span>
                <span className={`px-2 py-0.5 rounded-full text-xs border ${colorClass}`}>vista</span>
              </div>
            );
          })}
        </div>
      )}
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {value.map(tag => {
            const Icon = getTagIcon(tag.icon);
            const colorClass = getTagColorClasses(tag.color);
            return (
              <span
                key={tag.id}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${colorClass}`}
              >
                <Icon className="h-3 w-3" />
                {tag.name}
                <button
                  type="button"
                  onClick={() => removeTag(tag.id)}
                  className="ml-0.5 hover:bg-black/10 rounded-full p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            );
          })}
        </div>
      )}
    </div>
  );
}