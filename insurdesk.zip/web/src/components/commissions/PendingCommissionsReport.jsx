import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Loader2, FileSearch, Download, AlertCircle, ArrowUpDown } from 'lucide-react';
import * as XLSX from 'xlsx';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { round2 } from '@/lib/formatMoney';

export default function PendingCommissionsReport({ open, onOpenChange }) {
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState([]);
  const [generated, setGenerated] = useState(false);
  const [branchFilter, setBranchFilter] = useState('all');
  const [companyFilter, setCompanyFilter] = useState('all');
  const [branches, setBranches] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [search, setSearch] = useState('');
  const [totalPendingInstallments, setTotalPendingInstallments] = useState(0);
  const [sortField, setSortField] = useState('pending_due_date');
  const [sortOrder, setSortOrder] = useState('asc');

  useEffect(() => {
    if (open) {
      loadFilters();
    } else {
      setReportData([]);
      setGenerated(false);
      setBranchFilter('all');
      setCompanyFilter('all');
      setSearch('');
      setSortField('pending_due_date');
      setSortOrder('asc');
    }
  }, [open]);

  const loadFilters = async () => {
    try {
      const [branchesData, companiesData] = await Promise.all([
        api.entities.Branch.list('name', 100),
        api.entities.InsuranceCompany.list('name', 1000),
      ]);
      setBranches(branchesData);
      setCompanies(companiesData);
    } catch (error) {
      console.error('Error loading filters:', error);
      toast.error('Error al cargar filtros');
    }
  };

  // Companies filtered by selected branch
  const filteredCompanies = branchFilter !== 'all'
    ? companies.filter((c) => c.branch_id === branchFilter)
    : companies;

  const generateReport = async () => {
    setLoading(true);
    try {
      // Call backend function which paginates through ALL data server-side
      // (frontend SDK is capped at 5000 records per call, which misses most past-due payments)
      const response = await api.functions.invoke('getPendingCommissionsReport', {
        branchFilter,
        companyFilter,
      });

      const report = response.data?.report || [];
      const totalPending = response.data?.totalPending || 0;

      setReportData(report);
      setTotalPendingInstallments(totalPending);
      setGenerated(true);

      if (report.length === 0) {
        toast.success('No se encontraron comisiones pendientes con los filtros seleccionados.');
      } else {
        toast.success(`Reporte generado: ${report.length} póliza(s) con ${totalPending} cuota(s) pendientes.`);
      }
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Error al generar el reporte: ' + (error.message || 'Error desconocido'));
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Apply search + sort
  const filteredReport = React.useMemo(() => {
    let result = reportData;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (r) =>
          r.policy_number?.toLowerCase().includes(q) ||
          r.client_name?.toLowerCase().includes(q)
      );
    }
    const sorted = [...result].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      if (sortField === 'pending_due_date' || sortField === 'issue_date') {
        aVal = aVal ? new Date(aVal).getTime() : 0;
        bVal = bVal ? new Date(bVal).getTime() : 0;
      }
      if (typeof aVal === 'string') {
        return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortOrder === 'asc' ? (aVal || 0) - (bVal || 0) : (bVal || 0) - (aVal || 0);
    });
    return sorted;
  }, [reportData, search, sortField, sortOrder]);

  const handleExportExcel = () => {
    const headers = [
      'Número de póliza',
      'Asegurado',
      'Branch',
      'Compañía',
      'Fecha de emisión / renovación',
      'Fecha de vencimiento de cuota pendiente',
      'Número de cuota pendiente',
      'Valor de cuota',
      'Cantidad de cuotas pendientes',
    ];

    const rows = filteredReport.map((r) => [
      r.policy_number || '',
      r.client_name || '',
      r.branch_name || '',
      r.company_name || '',
      r.issue_date ? new Date(r.issue_date + 'T00:00:00') : '',
      r.pending_due_date ? new Date(r.pending_due_date + 'T00:00:00') : '',
      r.pending_installment_number || '',
      round2(r.installment_value || 0),
      r.pending_count || 0,
    ]);

    const wsData = [headers, ...rows];
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    ws['!cols'] = [
      { wch: 22 }, { wch: 30 }, { wch: 15 }, { wch: 25 },
      { wch: 24 }, { wch: 30 }, { wch: 20 }, { wch: 15 }, { wch: 24 },
    ];

    // Set date format for date columns (E=4 and F=5)
    for (let i = 1; i <= rows.length; i++) {
      const cellE = ws[XLSX.utils.encode_cell({ r: i, c: 4 })];
      const cellF = ws[XLSX.utils.encode_cell({ r: i, c: 5 })];
      if (cellE && cellE.t === 'd') cellE.z = 'dd/mm/yyyy';
      if (cellF && cellF.t === 'd') cellF.z = 'dd/mm/yyyy';
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Comisiones Pendientes');
    XLSX.writeFile(wb, 'comisiones_pendientes_cobro.xlsx');
  };

  const SortHeader = ({ label, field, className = '' }) => (
    <th
      className={`px-3 py-2 text-left font-medium cursor-pointer select-none hover:bg-secondary ${className}`}
      onClick={() => handleSort(field)}
    >
      <div className="flex items-center gap-1">
        {label}
        <ArrowUpDown className={`h-3 w-3 ${sortField === field ? 'text-foreground' : 'text-muted-foreground/70'}`} />
      </div>
    </th>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-7xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Comisiones Pendientes de Cobro</DialogTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Identifica pólizas cuyas comisiones deberían haberse generado hace más de 45 días y aún no se encuentran registradas. La validación es independiente del estado de pago de las cuotas.
          </p>
        </DialogHeader>

        {/* Filters */}
        <div className="flex flex-wrap items-end gap-4 mb-4">
          <div>
            <label className="text-sm font-medium mb-1 block">Branch</label>
            <Select
              value={branchFilter}
              onValueChange={(v) => {
                setBranchFilter(v);
                setCompanyFilter('all');
              }}
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Todos los Branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los Branch</SelectItem>
                {branches.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {b.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block">Compañía</label>
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Todas las compañías" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las compañías</SelectItem>
                {filteredCompanies.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={generateReport} disabled={loading} className="gap-2">
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <FileSearch className="h-4 w-4" />
            )}
            Generar Reporte
          </Button>

          {generated && reportData.length > 0 && (
            <Button onClick={handleExportExcel} variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Descargar Excel
            </Button>
          )}
        </div>

        {/* Report info */}
        {generated && (
          <div className="flex flex-wrap items-center gap-6 mb-4 text-sm bg-muted/40 rounded-lg px-4 py-3">
            <span className="text-muted-foreground ">
              Reporte generado al: <strong>{format(new Date(), 'dd/MM/yyyy')}</strong>
            </span>
            <span className="text-muted-foreground ">
              Pólizas con comisiones pendientes:{' '}
              <strong className="text-red-600 dark:text-red-400">{reportData.length}</strong>
            </span>
            <span className="text-muted-foreground ">
              Cuotas pendientes detectadas:{' '}
              <strong className="text-red-600 dark:text-red-400">{totalPendingInstallments}</strong>
            </span>
          </div>
        )}

        {/* Search */}
        {generated && reportData.length > 0 && (
          <Input
            placeholder="Buscar por número de póliza o nombre del asegurado..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="mb-4"
          />
        )}

        {/* Table */}
        {generated && reportData.length > 0 && (
          <div className="border rounded-lg overflow-auto max-h-[50vh]">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-muted z-10">
                <tr>
                  <SortHeader label="Póliza" field="policy_number" />
                  <SortHeader label="Asegurado" field="client_name" />
                  <SortHeader label="Branch" field="branch_name" />
                  <SortHeader label="Compañía" field="company_name" />
                  <SortHeader label="Emisión/Renovación" field="issue_date" />
                  <SortHeader label="Venc. Cuota Pend." field="pending_due_date" />
                  <SortHeader label="N° Cuota" field="pending_installment_number" className="text-center" />
                  <th className="px-3 py-2 text-right font-medium">Valor Cuota</th>
                  <SortHeader label="Cant. Pend." field="pending_count" className="text-center" />
                </tr>
              </thead>
              <tbody>
                {filteredReport.map((row, i) => (
                  <tr
                    key={i}
                    className="border-t hover:bg-muted/40 "
                  >
                    <td className="px-3 py-2 font-medium">{row.policy_number}</td>
                    <td className="px-3 py-2">{row.client_name}</td>
                    <td className="px-3 py-2">{row.branch_name}</td>
                    <td className="px-3 py-2">{row.company_name}</td>
                    <td className="px-3 py-2">
                      {row.issue_date ? format(new Date(row.issue_date), 'dd/MM/yyyy') : '-'}
                    </td>
                    <td className="px-3 py-2 text-red-600 dark:text-red-400 font-medium">
                      {format(new Date(row.pending_due_date), 'dd/MM/yyyy')}
                    </td>
                    <td className="px-3 py-2 text-center">{row.pending_installment_number}</td>
                    <td className="px-3 py-2 text-right whitespace-nowrap">
                      {row.currency}{' '}
                      {row.installment_value?.toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </td>
                    <td className="px-3 py-2 text-center">
                      <span className="inline-flex items-center justify-center min-w-6 h-6 px-1.5 rounded-full bg-red-500/10 text-red-600 dark:text-red-400 font-medium text-xs">
                        {row.pending_count}
                      </span>
                    </td>
                  </tr>
                ))}
                {filteredReport.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-3 py-8 text-center text-muted-foreground/70">
                      No se encontraron resultados con la búsqueda actual
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Empty state — no pending commissions */}
        {generated && reportData.length === 0 && !loading && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <AlertCircle className="h-12 w-12 text-emerald-400 mb-3" />
            <p className="text-muted-foreground font-medium">
              No hay comisiones pendientes de cobro
            </p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              Todas las pólizas con los filtros seleccionados tienen sus comisiones al día.
            </p>
          </div>
        )}

        {/* Initial state — before generating */}
        {!generated && !loading && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <FileSearch className="h-12 w-12 text-slate-300 mb-3" />
            <p className="text-muted-foreground">Seleccione los filtros y genere el reporte</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}