import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Loader2, User } from 'lucide-react';
import { formatLocalDateTime } from '@/components/dateUtils';

export default function AuditHistoryPopover({ entityType, entityId, children }) {
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (open && entityId) {
      loadAuditLogs();
    }
  }, [open, entityId]);

  const loadAuditLogs = async () => {
    setLoading(true);
    try {
      const logs = await api.entities.AuditLog.filter({
        entity_type: entityType,
        entity_id: entityId
      });
      // Sort by date descending
      const sortedLogs = logs.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
      setAuditLogs(sortedLogs);
    } catch (error) {
      console.error('Error loading audit logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActionLabel = (action) => {
    const labels = {
      CREATE: 'Creación',
      UPDATE: 'Modificación',
      DELETE: 'Eliminación'
    };
    return labels[action] || action;
  };

  const getChangesDescription = (log) => {
    if (!log.changes) return 'Sin detalles';
    
    try {
      const changes = typeof log.changes === 'string' ? JSON.parse(log.changes) : log.changes;
      const keys = Object.keys(changes);
      
      if (keys.length === 0) return 'Sin cambios específicos';
      if (keys.length <= 3) return keys.join(', ');
      return `${keys.slice(0, 3).join(', ')} y ${keys.length - 3} más`;
    } catch {
      return 'Sin detalles';
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        {children}
      </PopoverTrigger>
      <PopoverContent className="w-96 max-h-96 overflow-y-auto" align="end">
        <div className="space-y-3">
          <h4 className="font-semibold text-sm">Historial de Cambios</h4>
          
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground/70" />
            </div>
          ) : auditLogs.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No hay historial disponible</p>
          ) : (
            <div className="space-y-2">
              {auditLogs.map((log, index) => (
                <div key={log.id || index} className="border-l-2 border-border pl-3 pb-2">
                  <div className="flex items-start gap-2">
                    <div className="flex-shrink-0 mt-1">
                      {log.action === 'CREATE' ? (
                        <div className="h-2 w-2 rounded-full bg-green-500" />
                      ) : log.action === 'UPDATE' ? (
                        <div className="h-2 w-2 rounded-full bg-primary" />
                      ) : (
                        <div className="h-2 w-2 rounded-full bg-red-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-medium text-foreground">
                          {getActionLabel(log.action)}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {log.created_date ? formatLocalDateTime(log.created_date) : '-'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        <User className="h-3 w-3 text-muted-foreground/70" />
                        <span className="text-xs text-muted-foreground">{log.user_email || 'Usuario desconocido'}</span>
                      </div>
                      {log.changes && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Campos: {getChangesDescription(log)}
                        </p>
                      )}
                      {log.details && (
                        <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}