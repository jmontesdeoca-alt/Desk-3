import React from 'react';
import { getTagIcon, getTagColorClasses } from './policyTagIcons';

export default function PolicyTagBadges({ tags, size = 'sm', showName = true, className = '' }) {
  if (!tags || tags.length === 0) return null;

  const sizeClasses = size === 'xs'
    ? 'px-1.5 py-0.5 text-[10px] gap-0.5'
    : size === 'sm'
      ? 'px-2 py-0.5 text-xs gap-1'
      : 'px-2.5 py-1 text-sm gap-1';

  const iconSize = size === 'xs' ? 'h-2.5 w-2.5' : 'h-3 w-3';

  return (
    <div className={`flex flex-wrap gap-1 ${className}`}>
      {tags.map(tag => {
        const Icon = getTagIcon(tag.icon);
        const colorClass = getTagColorClasses(tag.color);
        return (
          <span
            key={tag.id}
            className={`inline-flex items-center rounded-full border font-medium ${colorClass} ${sizeClasses}`}
            title={tag.name}
          >
            <Icon className={iconSize} />
            {showName && <span>{tag.name}</span>}
          </span>
        );
      })}
    </div>
  );
}