import React, { useState, useEffect, useRef } from 'react';
import { api } from '@/api/client';
import { Label } from '@/components/ui/label';
import { Loader2, Tag, ChevronDown, X, Check } from 'lucide-react';
import { getTagIcon, getTagColorClasses } from '@/components/policy/policyTagIcons';

/**
 * Multi-select tag filter with include/exclude mode for reports.
 * @param {string[]} includeTagIds - tag IDs to include (policies with at least one of these)
 * @param {string[]} excludeTagIds - tag IDs to exclude (policies with any of these are filtered out)
 * @param {function} onIncludeChange - callback when include list changes
 * @param {function} onExcludeChange - callback when exclude list changes
 */
export default function PolicyTagFilter({ includeTagIds = [], excludeTagIds = [], onIncludeChange, onExcludeChange }) {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const loadTags = async () => {
      try {
        const data = await api.entities.PolicyTag.filter({ status: 'activo' });
        setTags(data.sort((a, b) => a.name.localeCompare(b.name)));
      } catch (err) {
        console.error('Error loading policy tags:', err);
      } finally {
        setLoading(false);
      }
    };
    loadTags();
  }, []);

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const toggleInclude = (tagId) => {
    if (includeTagIds.includes(tagId)) {
      onIncludeChange(includeTagIds.filter(id => id !== tagId));
    } else {
      onIncludeChange([...includeTagIds, tagId]);
      // Remove from exclude if adding to include
      if (excludeTagIds.includes(tagId)) {
        onExcludeChange(excludeTagIds.filter(id => id !== tagId));
      }
    }
  };

  const toggleExclude = (tagId) => {
    if (excludeTagIds.includes(tagId)) {
      onExcludeChange(excludeTagIds.filter(id => id !== tagId));
    } else {
      onExcludeChange([...excludeTagIds, tagId]);
      // Remove from include if adding to exclude
      if (includeTagIds.includes(tagId)) {
        onIncludeChange(includeTagIds.filter(id => id !== tagId));
      }
    }
  };

  const clearAll = () => {
    onIncludeChange([]);
    onExcludeChange([]);
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        Cargando etiquetas...
      </div>
    );
  }

  if (tags.length === 0) return null;

  const hasSelection = includeTagIds.length > 0 || excludeTagIds.length > 0;

  return (
    <div className="relative space-y-2" ref={ref}>
      <Label className="flex items-center gap-1.5">
        <Tag className="h-3.5 w-3.5" />
        Etiquetas de Póliza
      </Label>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring"
      >
        <span className="truncate text-muted-foreground">
          {hasSelection
            ? `${includeTagIds.length} incluir, ${excludeTagIds.length} excluir`
            : 'Filtrar por etiquetas...'}
        </span>
        <div className="flex items-center gap-1">
          {hasSelection && (
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => { e.stopPropagation(); clearAll(); }}
              className="text-muted-foreground/70 hover:text-muted-foreground"
            >
              <X className="h-3.5 w-3.5" />
            </span>
          )}
          <ChevronDown className="h-4 w-4 opacity-50 shrink-0 ml-1" />
        </div>
      </button>
      {open && (
        <div className="absolute left-0 right-0 z-50 mt-1 rounded-md border bg-card shadow-lg max-h-80 overflow-auto">
          <div className="sticky top-0 bg-card border-b px-3 py-2 grid grid-cols-2 gap-2 text-xs font-semibold text-muted-foreground">
            <div className="text-center">Incluir</div>
            <div className="text-center">Excluir</div>
          </div>
          {tags.map(tag => {
            const Icon = getTagIcon(tag.icon);
            const colorClass = getTagColorClasses(tag.color);
            const isIncluded = includeTagIds.includes(tag.id);
            const isExcluded = excludeTagIds.includes(tag.id);
            return (
              <div
                key={tag.id}
                className="flex items-center gap-2 px-3 py-2 hover:bg-muted/40 text-sm border-b"
              >
                <Icon className="h-4 w-4 text-muted-foreground shrink-0" />
                <span className={`flex-1 px-2 py-0.5 rounded-full text-xs font-medium border ${colorClass} truncate`}>
                  {tag.name}
                </span>
                <div
                  className="flex items-center justify-center cursor-pointer"
                  onClick={() => toggleInclude(tag.id)}
                >
                  <div className={`h-4 w-4 rounded border flex items-center justify-center transition-colors ${isIncluded ? 'bg-primary border-primary' : 'border-input bg-card'}`}>
                    {isIncluded && <Check className="h-3 w-3 text-white" />}
                  </div>
                </div>
                <div
                  className="flex items-center justify-center cursor-pointer"
                  onClick={() => toggleExclude(tag.id)}
                >
                  <div className={`h-4 w-4 rounded border flex items-center justify-center transition-colors ${isExcluded ? 'bg-red-600 border-red-600' : 'border-input bg-card'}`}>
                    {isExcluded && <Check className="h-3 w-3 text-white" />}
                  </div>
                </div>
              </div>
            );
          })}
          <div className="sticky bottom-0 bg-muted/40 border-t px-3 py-2 text-xs text-muted-foreground">
            Incluir: muestra solo pólizas con esa etiqueta · Excluir: oculta pólizas con esa etiqueta
          </div>
        </div>
      )}
    </div>
  );
}