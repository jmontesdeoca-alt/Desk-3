import React, { useState } from 'react';
import { api } from '@/api/client';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Mail, Phone, Users, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AgentInfoPopover({ agentId, agentName }) {
  const [agent, setAgent] = useState(null);
  const [structureHead, setStructureHead] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const loadAgentInfo = async () => {
    if (loaded || loading) return;
    setLoading(true);
    try {
      const agents = await api.entities.Agent.list();
      const found = agents.find(a => a.id === agentId);
      setAgent(found || null);

      // Walk up hierarchy to find head of structure (first upline with is_nivel_2 = true)
      if (found) {
        let current = found;
        let head = null;
        const visited = new Set();
        while (current?.upline_agent_id && !visited.has(current.id)) {
          visited.add(current.id);
          const upline = agents.find(a => a.id === current.upline_agent_id);
          if (!upline) break;
          if (upline.is_nivel_2) {
            head = upline;
            break;
          }
          current = upline;
        }
        setStructureHead(head);
      }
      setLoaded(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Popover onOpenChange={(open) => { if (open) loadAgentInfo(); }}>
      <PopoverTrigger asChild>
        <button className="text-foreground hover:underline text-sm text-left">
          {agentName}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-4" align="start">
        {loading ? (
          <p className="text-sm text-muted-foreground/70 text-center py-2">Cargando...</p>
        ) : agent ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-foreground">{agent.name}</p>
              <Link to={createPageUrl(`Agents?id=${agentId}`)} className="text-foreground hover:text-foreground">
                <ExternalLink className="h-3.5 w-3.5" />
              </Link>
            </div>
            {agent.alias && (
              <p className="text-xs text-muted-foreground -mt-2">"{agent.alias}"</p>
            )}
            <div className="space-y-2 text-sm">
              {agent.email && (
                <div className="flex items-center gap-2 text-foreground/80">
                  <Mail className="h-3.5 w-3.5 text-muted-foreground/70 shrink-0" />
                  <a href={`mailto:${agent.email}`} className="truncate hover:text-foreground">{agent.email}</a>
                </div>
              )}
              {agent.operational_email && (
                <div className="flex items-center gap-2 text-foreground/80">
                  <Mail className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                  <a href={`mailto:${agent.operational_email}`} className="truncate hover:text-foreground text-xs">{agent.operational_email} <span className="text-muted-foreground/70">(operativo)</span></a>
                </div>
              )}
              {agent.phone && (
                <div className="flex items-center gap-2 text-foreground/80">
                  <Phone className="h-3.5 w-3.5 text-muted-foreground/70 shrink-0" />
                  <a href={`tel:${agent.phone}`} className="hover:text-foreground">{agent.phone}</a>
                </div>
              )}
              {structureHead && (
                <div className="flex items-start gap-2 text-foreground/80 pt-1 border-t">
                  <Users className="h-3.5 w-3.5 text-muted-foreground/70 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground/70">Cabeza de Estructura</p>
                    <p className="font-medium">{structureHead.name}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground/70">No se encontró información del agente</p>
        )}
      </PopoverContent>
    </Popover>
  );
}