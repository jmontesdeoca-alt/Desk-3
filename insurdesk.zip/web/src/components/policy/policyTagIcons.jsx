import {
  Accessibility, ArrowLeftRight, Star, Shield, AlertTriangle, Tag,
  Heart, UserCheck, Building, Car, Home, Briefcase, Flag, Crown,
  Award, Zap, Globe, Users, FileText, DollarSign, Calendar,
  CheckCircle, XCircle, Clock, Lock, Unlock, Eye, EyeOff,
  TrendingUp, TrendingDown, Package, Gift, BookOpen, Phone, Mail,
  MapPin, Navigation, Compass, Anchor, Plane, Bike, Truck, Ship
} from 'lucide-react';

// Curated map of allowed icons for policy tags
export const POLICY_TAG_ICONS = {
  Accessibility, ArrowLeftRight, Star, Shield, AlertTriangle, Tag,
  Heart, UserCheck, Building, Car, Home, Briefcase, Flag, Crown,
  Award, Zap, Globe, Users, FileText, DollarSign, Calendar,
  CheckCircle, XCircle, Clock, Lock, Unlock, Eye, EyeOff,
  TrendingUp, TrendingDown, Package, Gift, BookOpen, Phone, Mail,
  MapPin, Navigation, Compass, Anchor, Plane, Bike, Truck, Ship
};

// Color options for policy tags
export const POLICY_TAG_COLORS = {
  blue: 'bg-muted text-foreground border-border',
  green: 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/30',
  amber: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
  red: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30',
  purple: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30',
  pink: 'bg-pink-500/10 text-pink-600 dark:text-pink-400 border-pink-500/30',
  cyan: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border-cyan-500/30',
  orange: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/30',
  slate: 'bg-muted text-foreground/80 border-border',
};

export const POLICY_TAG_COLOR_NAMES = Object.keys(POLICY_TAG_COLORS);

// Get icon component by name, fallback to Tag
export const getTagIcon = (iconName) => POLICY_TAG_ICONS[iconName] || Tag;

// Get color classes by name, fallback to slate
export const getTagColorClasses = (colorName) => POLICY_TAG_COLORS[colorName] || POLICY_TAG_COLORS.slate;