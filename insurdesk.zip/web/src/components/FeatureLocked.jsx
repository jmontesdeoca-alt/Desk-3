import React from 'react';
import { Link } from 'react-router-dom';
import { Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useFeatures } from '@/lib/FeatureContext';
import { createPageUrl } from '@/utils';

// Pantalla que se muestra al abrir una página cuyo módulo no está en el plan.
export default function FeatureLocked({ feature }) {
  const { features, planName } = useFeatures();
  const info = features?.[feature];
  return (
    <div className="min-h-[60vh] flex items-center justify-center p-6">
      <div className="max-w-md text-center space-y-4">
        <div className="mx-auto h-12 w-12 rounded-xl bg-muted grid place-items-center"><Lock className="h-5 w-5 text-muted-foreground" /></div>
        <h1 className="text-xl font-semibold">{info?.name || 'Este módulo'} no está incluido en tu plan</h1>
        <p className="text-sm text-muted-foreground">
          {info?.description ? `${info.description} ` : ''}Tu plan actual es <span className="font-medium text-foreground">{planName || 'Nivel 1'}</span>. Contacta a tu proveedor para ampliarlo.
        </p>
        <div className="flex justify-center gap-2">
          <Link to="/"><Button variant="outline">Volver al inicio</Button></Link>
          <Link to={createPageUrl('PlanSettings')}><Button>Ver mi plan</Button></Link>
        </div>
      </div>
    </div>
  );
}
