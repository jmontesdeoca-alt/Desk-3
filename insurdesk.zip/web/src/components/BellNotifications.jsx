import React, { useState, useEffect, useCallback } from 'react';
import { Bell, CheckCheck } from 'lucide-react';
import { api } from '@/api/client';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { formatRelativeTime, formatLocalDateTime } from '@/components/dateUtils';
import { toast } from 'sonner';

export default function BellNotifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [userId, setUserId] = useState(null);
  const [agentId, setAgentId] = useState(null);

  // Resolve current user id + agent_id (agent_id used for commission/payment notifications,
  // user.id used for task assignment notifications)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const user = await api.auth.me();
        if (!user?.id || cancelled) return;
        setUserId(user.id);
        try {
          const roles = await api.entities.UserRole.filter({ email: user.email });
          if (cancelled) return;
          if (roles && roles.length > 0 && roles[0].agent_id) {
            setAgentId(roles[0].agent_id);
          }
        } catch {
          // No agent_id — user will only see notifications targeted to their user.id
        }
      } catch (e) {
        console.error('Error resolving user', e);
        setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const loadNotifications = useCallback(async () => {
    if (!userId) return;
    try {
      // Fetch notifications targeted to the user (task assignments use user.id as recipient_id)
      // and to the agent (commissions/payments use agent_id as recipient_id)
      const queries = [
        api.entities.Notification.filter({ recipient_id: userId }, '-notification_date', 50)
      ];
      if (agentId && agentId !== userId) {
        queries.push(api.entities.Notification.filter({ recipient_id: agentId }, '-notification_date', 50));
      }
      const results = await Promise.all(queries);

      // Combine and deduplicate by id
      const seen = new Set();
      const all = [];
      for (const list of results) {
        for (const n of (list || [])) {
          if (!seen.has(n.id)) {
            seen.add(n.id);
            all.push(n);
          }
        }
      }
      all.sort((a, b) => new Date(b.notification_date) - new Date(a.notification_date));
      setNotifications(all.slice(0, 50));
    } catch (e) {
      console.error('Error loading notifications', e);
    } finally {
      setLoading(false);
    }
  }, [userId, agentId]);

  // Load when userId resolves + auto-refresh every 30s
  useEffect(() => {
    if (!userId) return;
    loadNotifications();
    const interval = setInterval(loadNotifications, 30000);
    return () => clearInterval(interval);
  }, [userId, loadNotifications]);

  // Refresh on dropdown open
  useEffect(() => {
    if (open && userId) {
      loadNotifications();
    }
  }, [open, userId, loadNotifications]);

  // Realtime subscription
  useEffect(() => {
    if (!userId) return;
    const unsubscribe = api.entities.Notification.subscribe(() => {
      loadNotifications();
    });
    return unsubscribe;
  }, [userId, loadNotifications]);

  const unread = notifications.filter(n => !n.read);

  const markAsRead = async (id) => {
    try {
      await api.entities.Notification.update(id, { read: true });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (e) {
      toast.error('Error al marcar como leída');
    }
  };

  const handleNotificationClick = (n) => {
    setSelected(n);
  };

  const markAllAsRead = async () => {
    const unreadIds = unread.map(n => n.id);
    if (unreadIds.length === 0) return;
    try {
      await api.entities.Notification.bulkUpdate(
        unreadIds.map(id => ({ id, read: true }))
      );
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      toast.success('Todas las notificaciones marcadas como leídas');
    } catch (e) {
      toast.error('Error al marcar todas como leídas');
    }
  };

  const truncate = (text, len = 80) => {
    if (!text) return '';
    return text.length > len ? text.slice(0, len) + '…' : text;
  };

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className="relative text-muted-foreground hover:text-foreground hover:bg-accent rounded-md p-2 transition-colors"
            aria-label="Notificaciones"
          >
            <Bell className="h-5 w-5" />
            {unread.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                {unread.length > 99 ? '99+' : unread.length}
              </span>
            )}
          </button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-80 sm:w-96 p-0">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <h3 className="font-semibold text-sm">Notificaciones</h3>
            {unread.length > 0 && (
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={markAllAsRead}>
                <CheckCheck className="h-3.5 w-3.5 mr-1" /> Marcar todas
              </Button>
            )}
          </div>
          <div className="max-h-96 overflow-y-auto">
            {loading ? (
              <div className="p-8 text-center text-sm text-muted-foreground/70">Cargando…</div>
            ) : notifications.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground/70">No tienes notificaciones pendientes</div>
            ) : (
              notifications.map(n => {
                const isUnread = !n.read;
                return (
                  <button
                    key={n.id}
                    onClick={() => handleNotificationClick(n)}
                    className={`w-full text-left px-4 py-3 border-b last:border-0 hover:bg-muted/40 transition-colors ${isUnread ? 'bg-muted/50' : ''}`}
                  >
                    <div className="flex items-start gap-2">
                      {isUnread && <span className="mt-1.5 h-2 w-2 rounded-full bg-primary flex-shrink-0" />}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-3 whitespace-pre-wrap">{n.message}</p>
                        <p className="text-[10px] text-muted-foreground/70 mt-1">{formatRelativeTime(n.notification_date)}</p>
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </PopoverContent>
      </Popover>

      <Dialog open={!!selected} onOpenChange={(v) => !v && setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-lg pr-8">{selected?.title}</DialogTitle>
            <DialogDescription>
              {selected?.notification_date && formatLocalDateTime(selected.notification_date)}
            </DialogDescription>
          </DialogHeader>
          <div className="py-3">
            <p className="text-sm text-foreground/80 whitespace-pre-wrap leading-relaxed">{selected?.message}</p>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            {!selected?.read && (
              <Button onClick={() => { markAsRead(selected.id); setSelected({ ...selected, read: true }); }}>
                <CheckCheck className="h-4 w-4 mr-1" /> Marcar como leída
              </Button>
            )}
            <DialogClose asChild>
              <Button variant="outline">Cerrar</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}