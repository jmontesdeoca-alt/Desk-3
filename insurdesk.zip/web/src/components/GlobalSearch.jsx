import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  FileText, User, DollarSign, Shield, TrendingUp, 
  Search, Loader2, ArrowRight 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function GlobalSearch({ open, onOpenChange }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [results, setResults] = useState({
    policies: [],
    clients: [],
    payments: [],
    claims: [],
    commissions: [],
    agents: []
  });

  useEffect(() => {
    api.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  useEffect(() => {
    if (!open) {
      setSearchTerm('');
      setResults({
        policies: [],
        clients: [],
        payments: [],
        claims: [],
        commissions: [],
        agents: []
      });
    }
  }, [open]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchTerm.length >= 2) {
        performSearch();
      } else {
        setResults({
          policies: [],
          clients: [],
          payments: [],
          claims: [],
          commissions: []
        });
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  const normalizeText = (text) => {
    if (!text) return '';
    return text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  };

  const isAgente = currentUser?.app_role === 'agente';

  const performSearch = async () => {
    setLoading(true);
    const term = searchTerm.toUpperCase();
    const normalized = normalizeText(searchTerm);

    try {
      if (isAgente) {
        // Agentes solo ven sus pólizas y pagos
        const [policies, payments] = await Promise.all([
          api.entities.Policy.list(),
          api.entities.Payment.list(),
        ]);
        setResults({
          policies: policies.filter(p =>
            p.policy_number?.toUpperCase().includes(term) ||
            p.client_name?.toUpperCase().includes(term) ||
            p.product_name?.toUpperCase().includes(term) ||
            p.company_name?.toUpperCase().includes(term)
          ).slice(0, 5),
          clients: [],
          payments: payments.filter(p =>
            p.policy_number?.toUpperCase().includes(term) ||
            p.client_name?.toUpperCase().includes(term)
          ).slice(0, 5),
          claims: [],
          commissions: [],
          agents: []
        });
      } else {
        const [policies, clients, payments, claims, commissions, agents] = await Promise.all([
          api.entities.Policy.list(),
          api.entities.Client.list(),
          api.entities.Payment.list(),
          api.entities.Claim.list(),
          api.entities.Commission.list(),
          api.entities.Agent.list()
        ]);
        setResults({
          policies: policies.filter(p =>
            p.policy_number?.toUpperCase().includes(term) ||
            p.client_name?.toUpperCase().includes(term) ||
            p.product_name?.toUpperCase().includes(term) ||
            p.company_name?.toUpperCase().includes(term)
          ).slice(0, 5),
          clients: clients.filter(c =>
            c.first_name?.toUpperCase().includes(term) ||
            c.last_name?.toUpperCase().includes(term) ||
            c.company_name?.toUpperCase().includes(term) ||
            c.document_id?.includes(searchTerm) ||
            c.email?.toUpperCase().includes(term)
          ).slice(0, 5),
          payments: payments.filter(p =>
            p.policy_number?.toUpperCase().includes(term) ||
            p.client_name?.toUpperCase().includes(term)
          ).slice(0, 5),
          claims: claims.filter(c =>
            c.claim_number?.toUpperCase().includes(term) ||
            c.policy_number?.toUpperCase().includes(term) ||
            c.client_name?.toUpperCase().includes(term)
          ).slice(0, 5),
          commissions: commissions.filter(c =>
            c.policy_number?.toUpperCase().includes(term) ||
            c.agent_name?.toUpperCase().includes(term) ||
            c.client_name?.toUpperCase().includes(term)
          ).slice(0, 5),
          agents: agents.filter(a => {
            const nameMatch = normalizeText(a.name).includes(normalized);
            const emailMatch = normalizeText(a.email).includes(normalized);
            const aliasMatch = a.alias && normalizeText(a.alias).includes(normalized);
            return nameMatch || emailMatch || aliasMatch;
          }).slice(0, 5)
        });
      }
    } catch (error) {
      console.error('Error searching:', error);
    }

    setLoading(false);
  };

  const handleClose = () => {
    onOpenChange(false);
  };

  const totalResults = Object.values(results).reduce((sum, arr) => sum + arr.length, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] p-0">
        <div className="p-4 border-b">
          <div className="flex items-center gap-3">
            <Search className="h-5 w-5 text-muted-foreground/70" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar pólizas, clientes, comisiones, siniestros..."
              className="border-0 focus-visible:ring-0 text-lg"
              autoFocus
            />
            {loading && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground/70" />}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Presiona <kbd className="px-2 py-1 bg-muted rounded text-xs">Ctrl+K</kbd> para buscar desde cualquier página
          </p>
        </div>

        <ScrollArea className="max-h-[500px]">
          {searchTerm.length < 2 ? (
            <div className="p-8 text-center text-muted-foreground">
              <Search className="h-12 w-12 mx-auto mb-3 text-slate-300" />
              <p>Escribe al menos 2 caracteres para buscar</p>
            </div>
          ) : loading ? (
            <div className="p-8 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-foreground mx-auto" />
            </div>
          ) : totalResults === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <p>No se encontraron resultados</p>
            </div>
          ) : (
            <div className="p-4 space-y-4">
              {/* Pólizas */}
              {results.policies.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-foreground/80">
                    <FileText className="h-4 w-4" />
                    Pólizas ({results.policies.length})
                  </div>
                  <div className="space-y-1">
                    {results.policies.map(policy => (
                      <Link
                        key={policy.id}
                        to={createPageUrl(`PolicyDetail?id=${policy.id}`)}
                        onClick={handleClose}
                      >
                        <div className="p-3 hover:bg-muted/40 rounded-lg flex items-center justify-between group">
                          <div>
                            <p className="font-medium text-foreground">{policy.policy_number}</p>
                            <p className="text-sm text-muted-foreground">{policy.client_name} · {policy.product_name}</p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground/70 group-hover:text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Clientes */}
              {results.clients.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-foreground/80">
                    <User className="h-4 w-4" />
                    Clientes ({results.clients.length})
                  </div>
                  <div className="space-y-1">
                    {results.clients.map(client => (
                      <Link
                        key={client.id}
                        to={createPageUrl(`ClientDetail?id=${client.id}`)}
                        onClick={handleClose}
                      >
                        <div className="p-3 hover:bg-muted/40 rounded-lg flex items-center justify-between group">
                          <div>
                            <p className="font-medium text-foreground">
                              {client.client_type === 'persona' 
                                ? `${client.first_name} ${client.last_name}` 
                                : client.company_name}
                            </p>
                            <p className="text-sm text-muted-foreground">{client.document_id} · {client.email}</p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground/70 group-hover:text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Pagos */}
              {results.payments.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-foreground/80">
                    <DollarSign className="h-4 w-4" />
                    Pagos ({results.payments.length})
                  </div>
                  <div className="space-y-1">
                    {results.payments.map(payment => (
                      <Link
                        key={payment.id}
                        to={createPageUrl(`Payments`)}
                        onClick={handleClose}
                      >
                        <div className="p-3 hover:bg-muted/40 rounded-lg flex items-center justify-between group">
                          <div>
                            <p className="font-medium text-foreground">{payment.policy_number}</p>
                            <p className="text-sm text-muted-foreground">
                              {payment.client_name} · Cuota #{payment.installment_number} · {payment.currency} {payment.amount?.toLocaleString()}
                            </p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground/70 group-hover:text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Siniestros */}
              {results.claims.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-foreground/80">
                    <Shield className="h-4 w-4" />
                    Siniestros ({results.claims.length})
                  </div>
                  <div className="space-y-1">
                    {results.claims.map(claim => (
                      <Link
                        key={claim.id}
                        to={createPageUrl(`Claims`)}
                        onClick={handleClose}
                      >
                        <div className="p-3 hover:bg-muted/40 rounded-lg flex items-center justify-between group">
                          <div>
                            <p className="font-medium text-foreground">{claim.claim_number}</p>
                            <p className="text-sm text-muted-foreground">
                              {claim.client_name} · {claim.claim_type} · {claim.currency} {claim.claimed_amount?.toLocaleString()}
                            </p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground/70 group-hover:text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Comisiones */}
              {results.commissions.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-foreground/80">
                    <TrendingUp className="h-4 w-4" />
                    Comisiones ({results.commissions.length})
                  </div>
                  <div className="space-y-1">
                    {results.commissions.map(commission => (
                      <Link
                        key={commission.id}
                        to={createPageUrl(`Commissions`)}
                        onClick={handleClose}
                      >
                        <div className="p-3 hover:bg-muted/40 rounded-lg flex items-center justify-between group">
                          <div>
                            <p className="font-medium text-foreground">{commission.policy_number}</p>
                            <p className="text-sm text-muted-foreground">
                              {commission.agent_name} · Nivel {commission.level} · {commission.currency} {commission.commission_amount?.toLocaleString()}
                            </p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground/70 group-hover:text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Agentes */}
              {results.agents.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm font-semibold text-foreground/80">
                    <User className="h-4 w-4" />
                    Agentes ({results.agents.length})
                  </div>
                  <div className="space-y-1">
                    {results.agents.map(agent => (
                      <Link
                        key={agent.id}
                        to={createPageUrl(`Agents`)}
                        onClick={handleClose}
                        state={{ selectedAgentId: agent.id }}
                      >
                        <div className="p-3 hover:bg-muted/40 rounded-lg flex items-center justify-between group">
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium text-foreground">{agent.name}</p>
                              {agent.alias && (
                                <span className="text-xs bg-muted text-foreground px-2 py-0.5 rounded">
                                  Alias: {agent.alias}
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">{agent.email} · {agent.country}</p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground/70 group-hover:text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}