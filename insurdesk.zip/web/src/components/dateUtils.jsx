/**
 * Utilidades de fecha para display con zona horaria AUTO-DETECTADA del navegador.
 * Re-exporta desde src/lib/dateUtils.js para compatibilidad con imports existentes.
 *
 * Funciones legacy mantenidas para no romper imports existentes:
 *   - formatLocalDateTime(date)  → "01 mar 2026, 12:40"
 *   - formatLocalTime(date)       → "12:40"
 *   - formatRelativeTime(date)    → "hace 5 min"
 */

import { TIMEZONE, formatDateTime, formatTime, parseDate, parseLocalDate, formatDate, toLocalDateString, toLocalISOString, todayLocal } from '@/lib/dateUtils';

// Re-exportar utilidades modernas para nuevos código
export { TIMEZONE, formatDateTime, formatTime, parseDate, parseLocalDate, formatDate, toLocalDateString, toLocalISOString, todayLocal };
export { formatDateTime as formatLocalDateTimeISO } from '@/lib/dateUtils';

/**
 * Formatea fecha + hora en la zona horaria del navegador.
 * Ejemplo: "13 mar 2026, 12:40"
 */
export function formatLocalDateTime(date) {
  if (!date) return '';
  let d;
  if (typeof date === 'string') {
    // Si no termina en Z o con offset, asumimos que es UTC y lo forzamos
    const normalized = /[Zz]$|[+-]\d{2}:\d{2}$/.test(date) ? date : date + 'Z';
    d = new Date(normalized);
  } else {
    d = date;
  }
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('es-EC', {
    timeZone: TIMEZONE,
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}

/**
 * Formatea solo la hora en la zona horaria del navegador.
 * Ejemplo: "12:40"
 */
export function formatLocalTime(date) {
  if (!date) return '';
  let d;
  if (typeof date === 'string') {
    const normalized = /[Zz]$|[+-]\d{2}:\d{2}$/.test(date) ? date : date + 'Z';
    d = new Date(normalized);
  } else {
    d = date;
  }
  if (isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('es-EC', {
    timeZone: TIMEZONE,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}

/**
 * Retorna tiempo relativo ("hace 5 minutos") — no depende de TZ, usa diff en ms puro.
 */
export function formatRelativeTime(date) {
  if (!date) return 'Sin registro';
  let d;
  if (typeof date === 'string') {
    const normalized = /[Zz]$|[+-]\d{2}:\d{2}$/.test(date) ? date : date + 'Z';
    d = new Date(normalized);
  } else {
    d = date;
  }
  if (isNaN(d.getTime())) return 'Fecha inválida';
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (diff < 60000) return 'hace un momento';
  if (mins < 60) return `hace ${mins} min`;
  if (hours < 24) return `hace ${hours}h`;
  if (days === 1) return 'ayer';
  return `hace ${days} días`;
}