import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Loader2, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function NewConversationDialog({ open, onOpenChange, onConversationCreated }) {
  const [type, setType] = useState('general');
  const [items, setItems] = useState([]);
  const [selectedId, setSelectedId] = useState('');
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(false);

  useEffect(() => {
    if (open && type !== 'general') {
      loadItems();
    }
  }, [open, type]);

  const loadItems = async () => {
    setFetching(true);
    try {
      let data = [];
      if (type === 'policy') {
        data = await api.entities.Policy.list();
        setItems(data.map(p => ({ 
          id: p.id, 
          label: `${p.policy_number || 'Sin número'} - ${p.client_name || 'Sin cliente'}` 
        })));
      } else if (type === 'task') {
        data = await api.entities.Task.list();
        setItems(data.map(t => ({ 
          id: t.id, 
          label: t.title || 'Sin título' 
        })));
      }
    } catch (error) {
      console.error('Error loading items:', error);
      toast.error('Error cargando datos');
    } finally {
      setFetching(false);
    }
  };

  const handleCreate = async () => {
    if (type !== 'general' && !selectedId) {
      toast.error('Selecciona un elemento');
      return;
    }
    if (type === 'general' && !title.trim()) {
      toast.error('Escribe un título para la conversación');
      return;
    }

    setLoading(true);
    try {
      const convId = type === 'general' ? `general_${Date.now()}` : selectedId;
      const convTitle = type === 'general' ? title : items.find(i => i.id === selectedId)?.label || 'Nueva conversación';
      
      // Crear primer mensaje para iniciar la conversación
      const currentUser = await api.auth.me();
      await api.entities.Message.create({
        sender_id: currentUser.id,
        sender_name: currentUser.full_name,
        sender_email: currentUser.email,
        content: '👋 Conversación iniciada',
        conversation_type: type,
        conversation_id: convId,
        conversation_title: convTitle,
        is_read: false,
        read_by: [currentUser.id]
      });

      onConversationCreated({ 
        conversationType: type, 
        conversationId: convId, 
        conversationTitle: convTitle 
      });
      
      onOpenChange(false);
      setType('general');
      setSelectedId('');
      setTitle('');
      toast.success('Conversación iniciada');
    } catch (error) {
      console.error('Error creating conversation:', error);
      toast.error('Error al crear conversación');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Nueva Conversación
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="type">Tipo</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">Conversación General</SelectItem>
                <SelectItem value="policy">Sobre Póliza</SelectItem>
                <SelectItem value="task">Sobre Tarea</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {type !== 'general' && (
            <div className="space-y-2">
              <Label htmlFor="item">Seleccionar {type === 'policy' ? 'Póliza' : 'Tarea'}</Label>
              {fetching ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground/70" />
                </div>
              ) : (
                <Select value={selectedId} onValueChange={setSelectedId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona..." />
                  </SelectTrigger>
                  <SelectContent>
                    {items.map(item => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          )}

          {type === 'general' && (
            <div className="space-y-2">
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                placeholder="Ej: Consulta sobre comisiones"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
          )}
        </div>

        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleCreate} disabled={loading || fetching}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Creando...
              </>
            ) : (
              'Crear'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}