import React, { useState, useEffect, useRef } from 'react';
import { api } from '@/api/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Send, Loader2, MessageSquare, User } from 'lucide-react';
import { formatLocalTime } from '@/components/dateUtils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function MessageThread({ conversationType, conversationId, conversationTitle, onClose, initialRecipients = null }) {
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]); // lazy-loaded solo cuando se necesita
  const [usersLoaded, setUsersLoaded] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [selectedRecipients, setSelectedRecipients] = useState(initialRecipients || []);
  const [mentionSuggestions, setMentionSuggestions] = useState([]);
  const [showMentions, setShowMentions] = useState(false);
  const [chatCreator, setChatCreator] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadData();
    const unsubscribe = subscribeToMessages();
    return () => unsubscribe?.();
  }, [conversationType, conversationId]);

  useEffect(() => {
    if (initialRecipients) {
      setSelectedRecipients(initialRecipients);
    }
  }, [initialRecipients]);

  // Cargar usuarios solo cuando se necesitan (privado o menciones @)
  const ensureUsersLoaded = async () => {
    if (usersLoaded) return;
    try {
      const response = await api.functions.invoke('listAllUsers');
      setUsers(response.data?.users || []);
      setUsersLoaded(true);
    } catch (e) {
      console.error('Error loading users:', e);
    }
  };

  const markMessagesAsRead = (msgs, user) => {
    const unread = msgs.filter(msg => !msg.read_by?.includes(user.id));
    if (unread.length === 0) return;
    // Fire-and-forget, no await para no bloquear la UI
    unread.forEach(msg =>
      api.entities.Message.update(msg.id, {
        read_by: [...(msg.read_by || []), user.id]
      })
    );
  };

  const loadData = async () => {
    setLoading(true);
    try {
      // Solo cargamos el usuario actual y los mensajes — sin listAllUsers
      const [user, messagesData] = await Promise.all([
        api.auth.me(),
        api.entities.Message.filter({ conversation_id: conversationId }, 'created_date', 100)
      ]);

      setCurrentUser(user);
      setMessages(messagesData);
      markMessagesAsRead(messagesData, user);

      // Detectar privacidad: si cualquier mensaje tiene recipient_ids
      const privateMsg = messagesData.find(m => m.recipient_ids?.length > 0);
      if (privateMsg) {
        setChatCreator(privateMsg.sender_id);
        const allRecipients = new Set();
        messagesData.forEach(m => {
          if (m.recipient_ids?.length > 0) {
            m.recipient_ids.forEach(id => allRecipients.add(id));
          }
        });
        setSelectedRecipients([...allRecipients]);
      } else {
        setSelectedRecipients([]);
        setChatCreator(null);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToMessages = () => {
    try {
      return api.entities.Message.subscribe((event) => {
        if (event.data?.conversation_id === conversationId) {
          if (event.type === 'create') {
            setMessages(prev => [...prev, event.data]);
            setCurrentUser(user => {
              if (user && !event.data.read_by?.includes(user.id)) {
                api.entities.Message.update(event.data.id, {
                  read_by: [...(event.data.read_by || []), user.id]
                });
              }
              return user;
            });
          } else if (event.type === 'update') {
            setMessages(prev => prev.map(m => m.id === event.id ? event.data : m));
          } else if (event.type === 'delete') {
            setMessages(prev => prev.filter(m => m.id !== event.id));
          }
        }
      });
    } catch (error) {
      console.error('Error subscribing to messages:', error);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const extractMentions = (text) => {
    const mentionRegex = /@(\w+)/g;
    const matches = [];
    let match;
    while ((match = mentionRegex.exec(text)) !== null) {
      matches.push(match[1].toLowerCase());
    }
    return matches;
  };

  const handleMessageChange = async (e) => {
    const text = e.target.value;
    setNewMessage(text);

    const lastWord = text.split(' ').pop();
    if (lastWord.startsWith('@')) {
      await ensureUsersLoaded();
      const searchTerm = lastWord.slice(1).toLowerCase();
      const filtered = users.filter(u =>
        u.full_name?.toLowerCase().includes(searchTerm) ||
        u.email?.toLowerCase().includes(searchTerm)
      );
      setMentionSuggestions(filtered);
      setShowMentions(filtered.length > 0);
    } else {
      setShowMentions(false);
    }
  };

  const insertMention = (user) => {
    const words = newMessage.split(' ');
    words[words.length - 1] = `@${user.full_name}`;
    setNewMessage(words.join(' ') + ' ');
    setShowMentions(false);
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !currentUser) return;

    setSending(true);
    try {
      const mentionedWords = extractMentions(newMessage);
      const mentionedIds = users
        .filter(u => mentionedWords.includes(u.full_name?.toLowerCase()))
        .map(u => u.id);

      await api.entities.Message.create({
        sender_id: currentUser.id,
        sender_name: currentUser.full_name,
        sender_email: currentUser.email,
        content: newMessage,
        conversation_type: conversationType,
        conversation_id: conversationId,
        conversation_title: conversationTitle,
        recipient_ids: selectedRecipients.length > 0 ? selectedRecipients : [],
        mentioned_ids: mentionedIds,
        is_read: false,
        read_by: [currentUser.id]
      });
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSending(false);
    }
  };

  const handleDeleteChat = async () => {
    setDeleting(true);
    try {
      await Promise.all(messages.map(msg => api.entities.Message.delete(msg.id)));
      setShowDeleteDialog(false);
      onClose();
    } catch (error) {
      console.error('Error deleting chat:', error);
    } finally {
      setDeleting(false);
    }
  };

  // Para mostrar nombre del remitente usamos el campo desnormalizado sender_name
  const getSenderName = (msg) => msg.sender_name || 'Usuario';

  // Nombre de recipient desde usuarios cargados (solo si están disponibles)
  const getRecipientName = (id) => {
    const u = users.find(u => u.id === id);
    return u?.full_name || id;
  };

  if (loading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="py-12 flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground/70" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm flex flex-col h-[600px]">
      <CardHeader className="flex flex-row items-center justify-between border-b">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-foreground" />
          <div>
            <CardTitle className="text-lg">{conversationTitle}</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              {messages.length} mensajes
              {selectedRecipients.length > 0 && (
                <span className="ml-2 text-foreground">• Chat privado</span>
              )}
            </p>
          </div>
        </div>
        <div className="flex gap-1">
          {currentUser?.role === 'admin' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDeleteDialog(true)}
              className="text-red-600 dark:text-red-400 hover:text-red-600 dark:hover:text-red-400"
            >
              🗑️
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={onClose}>✕</Button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-muted-foreground/70">
            <p>No hay mensajes aún. ¡Inicia la conversación!</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isOwn = currentUser?.id === msg.sender_id;
            const isPrivateChat = selectedRecipients.length > 0;

            if (isPrivateChat) {
              if (!isOwn && !msg.recipient_ids?.includes(currentUser?.id)) return null;
            } else {
              if (msg.recipient_ids?.length > 0 && !isOwn && !msg.recipient_ids?.includes(currentUser?.id)) return null;
            }

            return (
              <div key={msg.id} className={`flex gap-3 ${isOwn ? 'justify-end' : ''}`}>
                {!isOwn && (
                  <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0 text-xs font-semibold">
                    {getSenderName(msg).charAt(0).toUpperCase()}
                  </div>
                )}
                <div className={`max-w-xs ${isOwn ? 'flex flex-col items-end' : ''}`}>
                  {!isOwn && (
                    <p className="text-xs text-muted-foreground font-medium mb-1">
                      {getSenderName(msg)}
                    </p>
                  )}
                  <div className={`rounded-lg px-3 py-2 ${
                    isOwn ? 'bg-primary text-white' : 'bg-muted text-foreground'
                  } ${msg.mentioned_ids?.includes(currentUser?.id) ? 'ring-2 ring-yellow-400' : ''}`}>
                    <p className="text-sm break-words">{msg.content}</p>
                  </div>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    {formatLocalTime(msg.created_date)}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </CardContent>

      <div className="border-t p-4 space-y-2">
        {selectedRecipients.length > 0 && (
          <div className="flex flex-wrap gap-1 bg-muted p-2 rounded-lg text-xs">
            {selectedRecipients.map(id => (
              <div key={id} className="bg-muted text-foreground px-2 py-1 rounded flex items-center gap-1">
                {usersLoaded ? getRecipientName(id) : id}
                {currentUser?.id === chatCreator && (
                  <button onClick={() => {
                    const newRecipients = selectedRecipients.filter(rid => rid !== id);
                    setSelectedRecipients(newRecipients);
                    if (newRecipients.length === 0) setChatCreator(null);
                  }} className="font-bold">×</button>
                )}
              </div>
            ))}
            <span className="text-muted-foreground px-2 py-1">Chat privado</span>
          </div>
        )}

        <div className="relative flex gap-2">
          {selectedRecipients.length === 0 && !chatCreator && (
            <DropdownMenu onOpenChange={async (open) => { if (open) await ensureUsersLoaded(); }}>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1">
                  <User className="h-3 w-3" />
                  Privado
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 max-h-48 overflow-y-auto">
                {users.map(u => (
                  <DropdownMenuItem
                    key={u.id}
                    onClick={() => {
                      setSelectedRecipients([u.id]);
                      setChatCreator(currentUser?.id);
                    }}
                  >
                    {u.full_name || u.email}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={handleMessageChange}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey && !sending && newMessage.trim()) {
                  e.preventDefault();
                  handleSendMessage(e);
                }
              }}
              placeholder={selectedRecipients.length > 0 ? 'Mensaje privado...' : 'Escribe @ para mencionar...'}
              disabled={sending}
            />
            {showMentions && selectedRecipients.length === 0 && (
              <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-lg shadow-lg z-10 mt-1">
                {mentionSuggestions.map(u => (
                  <div
                    key={u.id}
                    onClick={() => insertMention(u)}
                    className="px-3 py-2 hover:bg-muted cursor-pointer text-sm"
                  >
                    @{u.full_name}
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button type="submit" size="icon" disabled={sending || !newMessage.trim()} onClick={handleSendMessage}>
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Eliminar chat</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que quieres eliminar este chat? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)} disabled={deleting}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDeleteChat} disabled={deleting}>
              {deleting ? 'Eliminando...' : 'Eliminar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}