import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageSquare, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const CACHE_KEY = 'msg_conversations_cache';

function processMessages(messages, user) {
  // Una conversación es privada si CUALQUIER mensaje tiene recipient_ids
  // (Las menciones @ van en mentioned_ids, no en recipient_ids)
  const conversationMeta = {};
  messages.forEach(msg => {
    const key = `${msg.conversation_type}:${msg.conversation_id}`;
    if (!conversationMeta[key]) {
      conversationMeta[key] = { isPrivate: false, participants: new Set() };
    }
    if (msg.recipient_ids?.length > 0) {
      conversationMeta[key].isPrivate = true;
      conversationMeta[key].participants.add(msg.sender_id);
      msg.recipient_ids.forEach(id => conversationMeta[key].participants.add(id));
    }
  });

  const grouped = messages.reduce((acc, msg) => {
    const key = `${msg.conversation_type}:${msg.conversation_id}`;
    const meta = conversationMeta[key];

    // Ocultar conversaciones privadas donde el usuario no participa
    if (meta.isPrivate && !meta.participants.has(user.id)) return acc;

    if (!acc[key]) {
      acc[key] = {
        conversationType: msg.conversation_type,
        conversationId: msg.conversation_id,
        conversationTitle: msg.conversation_title,
        lastMessage: msg.content,
        lastMessageTime: msg.created_date,
        unreadCount: 0
      };
    } else {
      if (new Date(msg.created_date) > new Date(acc[key].lastMessageTime)) {
        acc[key].lastMessage = msg.content;
        acc[key].lastMessageTime = msg.created_date;
      }
    }
    if (!msg.read_by?.includes(user.id)) {
      acc[key].unreadCount++;
    }
    return acc;
  }, {});

  return Object.values(grouped).sort((a, b) =>
    new Date(b.lastMessageTime) - new Date(a.lastMessageTime)
  );
}

export default function MessageList({ onSelectConversation }) {
  const [conversations, setConversations] = useState(() => {
    // Cargar caché inmediatamente para mostrar algo mientras llegan los datos
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      return cached ? JSON.parse(cached) : [];
    } catch { return []; }
  });
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    const unsubscribe = api.entities.Message.subscribe(() => loadData());
    return () => unsubscribe?.();
  }, []);

  const loadData = async () => {
    try {
      const [user, messages] = await Promise.all([
        api.auth.me(),
        api.entities.Message.list('-created_date', 500)
      ]);
      setCurrentUser(user);
      const result = processMessages(messages, user);
      setConversations(result);
      localStorage.setItem(CACHE_KEY, JSON.stringify(result));
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-foreground" />
          Conversaciones
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading && conversations.length === 0 ? (
          <div className="py-8 flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground/70" />
          </div>
        ) : conversations.length === 0 ? (
          <p className="text-center text-muted-foreground/70 py-8">No hay conversaciones aún</p>
        ) : (
          <div className="space-y-2">
            {conversations.map((conv) => (
              <div
                key={`${conv.conversationType}:${conv.conversationId}`}
                onClick={() => onSelectConversation(conv)}
                className="p-3 rounded-lg border border-border hover:border-border hover:bg-muted/40 cursor-pointer transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">
                      {conv.conversationTitle}
                    </p>
                    <p className="text-sm text-muted-foreground truncate mt-1">
                      {conv.lastMessage}
                    </p>
                  </div>
                  {conv.unreadCount > 0 && (
                    <span className="ml-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center flex-shrink-0">
                      {conv.unreadCount > 9 ? '9+' : conv.unreadCount}
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {format(new Date(conv.lastMessageTime), 'dd MMM HH:mm', { locale: es })}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}