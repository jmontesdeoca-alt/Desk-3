import React, { useState, useMemo } from 'react';
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Globe, Trophy, FileText, X } from 'lucide-react';
import { convertToUSD } from '@/lib/currencyConversion';
import { formatMoney, round2 } from '@/lib/formatMoney';
import { useIsMobile } from '@/hooks/use-mobile';

// Banderas emoji simples por país (normalizado a mayúsculas)
const COUNTRY_FLAGS = {
  'COLOMBIA': '🇨🇴',
  'MEXICO': '🇲🇽',
  'MÉXICO': '🇲🇽',
  'PERU': '🇵🇪',
  'PERÚ': '🇵🇪',
  'CHILE': '🇨🇱',
  'ARGENTINA': '🇦🇷',
  'ECUADOR': '🇪🇨',
  'VENEZUELA': '🇻🇪',
  'PANAMA': '🇵🇦',
  'PANAMÁ': '🇵🇦',
  'COSTA RICA': '🇨🇷',
  'ESPAÑA': '🇪🇸',
  'SPAIN': '🇪🇸',
  'ESTADOS UNIDOS': '🇺🇸',
  'USA': '🇺🇸',
  'UNITED STATES': '🇺🇸',
  'BRASIL': '🇧🇷',
  'BRAZIL': '🇧🇷',
  'URUGUAY': '🇺🇾',
  'PARAGUAY': '🇵🇾',
  'BOLIVIA': '🇧🇴',
  'GUATEMALA': '🇬🇹',
  'HONDURAS': '🇭🇳',
  'EL SALVADOR': '🇸🇻',
  'NICARAGUA': '🇳🇮',
  'DOMINICANA': '🇩🇴',
  'REPUBLICA DOMINICANA': '🇩🇴',
};

const getFlag = (country) => COUNTRY_FLAGS[(country || '').toUpperCase()] || '🌍';

export default function SalesByCountryList({ filteredPolicies, trmMap }) {
  const isMobile = useIsMobile();
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Cálculo de ventas por país (USD, con round2)
  const countryData = useMemo(() => {
    const map = {};
    filteredPolicies.forEach(p => {
      const country = p.country || 'Sin país';
      const usd = round2(convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap));
      if (!map[country]) {
        map[country] = { country, total: 0, count: 0, policies: [], byAgent: {} };
      }
      map[country].total = round2(map[country].total + usd);
      map[country].count += 1;
      map[country].policies.push({ ...p, _usd: usd });

      const agentId = p.agent_id || 'sin_agente';
      if (!map[country].byAgent[agentId]) {
        map[country].byAgent[agentId] = { name: p.agent_name || 'Sin agente', total: 0, count: 0 };
      }
      map[country].byAgent[agentId].total = round2(map[country].byAgent[agentId].total + usd);
      map[country].byAgent[agentId].count += 1;
    });

    return Object.values(map)
      .map(c => ({
        ...c,
        topAgents: Object.values(c.byAgent)
          .sort((a, b) => b.total - a.total)
          .slice(0, 3),
        topPolicies: [...c.policies]
          .sort((a, b) => b._usd - a._usd)
          .slice(0, 3),
      }))
      .sort((a, b) => b.total - a.total);
  }, [filteredPolicies, trmMap]);

  const maxTotal = countryData.length > 0 ? countryData[0].total : 0;

  const handleSelect = (country) => {
    if (isMobile) {
      setSelectedCountry(country);
      setMobileOpen(true);
    } else {
      setSelectedCountry(prev => (prev && prev.country === country.country ? null : country));
    }
  };

  const closeDesktop = () => setSelectedCountry(null);

  const DetailPanel = ({ country, onClose }) => {
    if (!country) return null;
    return (
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-bold text-base text-foreground flex items-center gap-2">
            <span className="text-xl">{getFlag(country.country)}</span>
            {country.country}
          </h4>
          {onClose && (
            <button
              onClick={onClose}
              className="text-muted-foreground/70 hover:text-foreground/80 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="bg-muted rounded-lg p-2">
            <p className="text-xs text-muted-foreground">Total Primas</p>
            <p className="text-lg font-bold text-foreground">USD {formatMoney(country.total)}</p>
          </div>
          <div className="bg-muted/40 rounded-lg p-2">
            <p className="text-xs text-muted-foreground">N° Pólizas</p>
            <p className="text-lg font-bold text-foreground/80">{country.count}</p>
          </div>
        </div>

        {/* Top 3 Vendedores */}
        <div className="mb-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1">
            <Trophy className="h-3 w-3" /> Top 3 Vendedores
          </p>
          <div className="space-y-2">
            {country.topAgents.map((agent, i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-2.5">
                <div className="flex items-center justify-between">
                  <div className="min-w-0">
                    <p className="font-medium text-sm text-foreground truncate">{agent.name}</p>
                    <p className="text-xs text-muted-foreground/70">{agent.count} póliza{agent.count !== 1 ? 's' : ''}</p>
                  </div>
                  <p className="font-bold text-sm text-emerald-600 dark:text-emerald-400 shrink-0 ml-2">USD {formatMoney(agent.total)}</p>
                </div>
              </div>
            ))}
            {country.topAgents.length === 0 && (
              <p className="text-xs text-muted-foreground/70">Sin vendedores</p>
            )}
          </div>
        </div>

        {/* Top 3 Pólizas */}
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1">
            <FileText className="h-3 w-3" /> Top 3 Pólizas
          </p>
          <div className="space-y-2">
            {country.topPolicies.map((policy, i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-2.5">
                <div className="flex items-center justify-between">
                  <div className="min-w-0">
                    <p className="font-medium text-sm text-foreground truncate">{policy.policy_number || '—'}</p>
                    <p className="text-xs text-muted-foreground/70 truncate">
                      {policy.client_name || '—'} · {policy.product_name || '—'}
                    </p>
                  </div>
                  <p className="font-bold text-sm text-foreground shrink-0 ml-2">USD {formatMoney(policy._usd)}</p>
                </div>
              </div>
            ))}
            {country.topPolicies.length === 0 && (
              <p className="text-xs text-muted-foreground/70">Sin pólizas</p>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center gap-2 mb-3">
        <Globe className="h-4 w-4 text-foreground" />
        <span className="text-sm font-semibold text-foreground/80">Ventas por País</span>
        <span className="ml-auto text-xs text-muted-foreground/70">{countryData.length} país{countryData.length !== 1 ? 'es' : ''}</span>
      </div>

      {countryData.length === 0 ? (
        <div className="flex-1 flex items-center justify-center text-center text-muted-foreground/70 text-sm py-8">
          No hay datos de ventas por país para los filtros seleccionados
        </div>
      ) : (
        <div className="flex-1 flex gap-3 min-h-0">
          {/* Lista de países */}
          <div className={`space-y-1.5 overflow-y-auto pr-1 ${selectedCountry && !isMobile ? 'w-1/2' : 'w-full'}`}>
            {countryData.map((c, idx) => {
              const active = selectedCountry?.country === c.country;
              return (
                <div
                  key={c.country}
                  onClick={() => handleSelect(c)}
                  className={`p-2.5 rounded-lg cursor-pointer transition-colors border select-none ${
                    active
                      ? 'bg-muted border-border'
                      : 'bg-muted/40 border-transparent hover:bg-muted'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="flex items-center justify-center h-7 w-7 rounded-full bg-muted text-foreground font-semibold text-xs shrink-0">
                      {idx + 1}
                    </div>
                    <span className="text-lg shrink-0">{getFlag(c.country)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-sm text-foreground truncate">{c.country}</p>
                      <p className="text-xs text-muted-foreground/70">{c.count} póliza{c.count !== 1 ? 's' : ''}</p>
                    </div>
                    <p className="font-bold text-sm text-emerald-600 dark:text-emerald-400 shrink-0">USD {formatMoney(c.total)}</p>
                  </div>
                  {/* Barra de progreso relativa */}
                  <div className="mt-1.5 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${active ? 'bg-primary' : 'bg-blue-300'}`}
                      style={{ width: `${maxTotal > 0 ? (c.total / maxTotal) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Panel de detalle (escritorio, a la derecha) */}
          {selectedCountry && !isMobile && (
            <div className="w-1/2 border-l border-border pl-3 overflow-y-auto">
              <DetailPanel country={selectedCountry} onClose={closeDesktop} />
            </div>
          )}
        </div>
      )}

      {/* Bottom sheet móvil */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="bottom" className="bg-transparent p-0 border-0 shadow-none rounded-t-3xl">
          <div className="ios-bubble-up mx-3 mb-3 rounded-3xl bg-card border border-border shadow-[0_8px_32px_rgba(0,0,0,0.25)] overflow-hidden max-h-[80vh] overflow-y-auto" style={{ paddingBottom: 'max(env(safe-area-inset-bottom), 12px)' }}>
            <div className="flex justify-center pt-2.5 pb-1">
              <div className="h-1.5 w-10 rounded-full bg-muted-foreground/30" />
            </div>
            {selectedCountry && (
              <div className="px-4 pb-4">
                <DetailPanel country={selectedCountry} />
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}