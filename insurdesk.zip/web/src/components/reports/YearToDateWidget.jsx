import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Minus, CalendarDays } from 'lucide-react';
import { convertToUSD } from '@/lib/currencyConversion';

/**
 * Widget YTD (Year to Date)
 * Compara primas (issue_date) del año actual vs año anterior
 * hasta la misma fecha límite (date_to del filtro, o hoy si no hay).
 * Aplica los mismos filtros de la tabla (excepto el rango de fechas).
 * Todas las primas se convierten a USD usando la TRM de la fecha de emisión.
 */
export default function YearToDateWidget({ policies, filters, agents, companies, trmMap }) {
  const { currentYTD, lastYTD, cutoffLabel, currentYear, lastYear } = useMemo(() => {
    // Determinar fecha corte (date_to del filtro o hoy)
    const today = new Date();
    const cutoff = filters.date_to ? new Date(filters.date_to) : today;

    // Normalizar a medianoche para comparaciones de fecha
    const toMidnight = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const cutoffDay = toMidnight(cutoff);

    const currentYear = cutoffDay.getFullYear();
    const lastYear = currentYear - 1;

    // Límites año actual: 1 enero año actual → cutoff
    const currentStart = new Date(currentYear, 0, 1);
    const currentEnd = cutoffDay;

    // Misma ventana pero año anterior
    const lastStart = new Date(lastYear, 0, 1);
    const lastEnd = new Date(lastYear, cutoffDay.getMonth(), cutoffDay.getDate());

    // Función auxiliar: aplicar filtros que NO sean de fecha, tipo ni estado
    // El widget YTD ignora filtros de estado y tipo de póliza; aplica su propia lógica:
    // - Excluye renovaciones (policy_type='renovacion') para comparar emisión real año a año
    // - Año actual: solo pólizas activas (lo que está vivo hoy)
    // - Año anterior: activas + renovadas (producción exitosa del periodo)
    const matchesNonDateFilters = (policy) => {
      // Excluir renovaciones; pólizas sin policy_type (legacy) se cuentan como nuevo negocio
      if (policy.policy_type === 'renovacion') return false;

      if (filters.line_id !== 'all' && policy.line_id !== filters.line_id) return false;
      if (filters.product_id !== 'all' && policy.product_id !== filters.product_id) return false;
      if (filters.currency !== 'all' && policy.currency !== filters.currency) return false;
      if (filters.payment_frequency !== 'all' && policy.payment_frequency !== filters.payment_frequency) return false;

      if (filters.company_id !== 'all' && policy.company_id !== filters.company_id) return false;

      if (filters.branch_id !== 'all') {
        const companyIdsInBranch = new Set(
          companies.filter(c => c.branch_id === filters.branch_id).map(c => c.id)
        );
        if (!companyIdsInBranch.has(policy.company_id)) return false;
      }

      if (filters.agent_id !== 'all') {
        if (filters.include_structure) {
          const structure = getStructure(filters.agent_id, agents);
          if (!structure.includes(policy.agent_id)) return false;
        } else {
          if (policy.agent_id !== filters.agent_id) return false;
        }
      }

      if (filters.agent_type !== 'all') {
        const agentIds = agents.filter(a => a.agent_type === filters.agent_type).map(a => a.id);
        if (!agentIds.includes(policy.agent_id)) return false;
      }

      if (filters.is_nivel_2 !== 'all') {
        const agentIds = agents.filter(a => a.is_nivel_2 === (filters.is_nivel_2 === 'true')).map(a => a.id);
        if (!agentIds.includes(policy.agent_id)) return false;
      }

      if (filters.is_gapartner !== 'all') {
        const agentIds = agents.filter(a => a.is_gapartner === (filters.is_gapartner === 'true')).map(a => a.id);
        if (!agentIds.includes(policy.agent_id)) return false;
      }

      return true;
    };

    const sumPremiums = (pols) =>
      pols.reduce((sum, p) => sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0);

    const inRange = (issueDate, start, end) => {
      if (!issueDate) return false;
      const d = toMidnight(new Date(issueDate));
      return d >= start && d <= end;
    };

    // Año actual: solo pólizas activas (lo que está vivo hoy)
    const currentYTD = sumPremiums(
      policies.filter(p =>
        inRange(p.issue_date, currentStart, currentEnd) &&
        matchesNonDateFilters(p) &&
        p.status === 'activa'
      )
    );

    // Año anterior: todo el nuevo negocio emitido ese año, sin importar su estado actual
    // (aunque se haya cancelado o renovado después, sigue siendo una venta de ese año)
    const lastYTD = sumPremiums(
      policies.filter(p =>
        inRange(p.issue_date, lastStart, lastEnd) &&
        matchesNonDateFilters(p)
      )
    );

    const cutoffLabel = `${cutoffDay.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' })}`;

    return { currentYTD, lastYTD, cutoffLabel, currentYear, lastYear };
  }, [policies, filters, agents, companies, trmMap]);

  const diff = currentYTD - lastYTD;
  const pct = lastYTD > 0 ? ((diff / lastYTD) * 100).toFixed(1) : null;
  const isUp = diff > 0;
  const isFlat = diff === 0;

  const fmt = (val) => {
    if (val >= 1_000_000) return `$${(val / 1_000_000).toFixed(2)}M`;
    if (val >= 1_000) return `$${(val / 1_000).toFixed(2)}K`;
    return `$${val.toFixed(2)}`;
  };

  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground/80">
          <CalendarDays className="h-4 w-4 text-foreground" />
          Comparativo Year to Date
          <span className="ml-auto text-xs font-normal text-muted-foreground/70">al {cutoffLabel}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Barra de comparación */}
        <div className="space-y-2">
          {/* Año actual */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium text-foreground">{currentYear} YTD</span>
              <span className="font-bold text-foreground">{fmt(currentYTD)}</span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all"
                style={{ width: `${Math.max(currentYTD, lastYTD) > 0 ? (currentYTD / Math.max(currentYTD, lastYTD)) * 100 : 0}%` }}
              />
            </div>
          </div>

          {/* Año anterior */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium text-muted-foreground">{lastYear} YTD</span>
              <span className="font-bold text-muted-foreground">{fmt(lastYTD)}</span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-muted-foreground/50 rounded-full transition-all"
                style={{ width: `${Math.max(currentYTD, lastYTD) > 0 ? (lastYTD / Math.max(currentYTD, lastYTD)) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>

        {/* Variación */}
        <div className={`flex items-center justify-between rounded-lg p-3 ${
          isFlat ? 'bg-muted/40' : isUp ? 'bg-green-500/10' : 'bg-red-500/10'
        }`}>
          <div className="flex items-center gap-2">
            {isFlat
              ? <Minus className="h-5 w-5 text-muted-foreground/70" />
              : isUp
                ? <TrendingUp className="h-5 w-5 text-green-600 dark:text-green-400" />
                : <TrendingDown className="h-5 w-5 text-red-500" />
            }
            <span className={`text-sm font-semibold ${isFlat ? 'text-muted-foreground' : isUp ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {isFlat ? 'Sin variación' : isUp ? 'Crecimiento' : 'Caída'}
            </span>
          </div>
          <div className="text-right">
            <p className={`text-lg font-bold ${isFlat ? 'text-muted-foreground' : isUp ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {pct !== null ? `${isUp ? '+' : ''}${pct}%` : 'N/A'}
            </p>
            <p className="text-xs text-muted-foreground/70">
              {isUp ? '+' : ''}{fmt(diff)} vs {lastYear}
            </p>
          </div>
        </div>

        <p className="text-xs text-muted-foreground/70 text-center">
          Basado en <strong>Fecha de Emisión</strong> · Filtros activos aplicados
        </p>
      </CardContent>
    </Card>
  );
}

function getStructure(agentId, agents) {
  const structure = [agentId];
  const findDownline = (id) => {
    agents.filter(a => a.upline_agent_id === id).forEach(agent => {
      structure.push(agent.id);
      findDownline(agent.id);
    });
  };
  findDownline(agentId);
  return structure;
}