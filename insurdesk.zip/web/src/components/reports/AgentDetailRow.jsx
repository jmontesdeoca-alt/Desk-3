import React, { useState, useRef, useEffect } from 'react';
import { formatMoney } from '@/lib/formatMoney';

export default function AgentDetailRow({ agent, idx }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  // Close on click outside
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const maxCompanyValue = agent.byCompany.length > 0 ? agent.byCompany[0].value : 1;

  return (
    <div ref={ref} className="relative">
      <div
        className="flex items-center justify-between p-3 bg-muted/40 rounded-lg cursor-pointer hover:bg-muted transition-colors select-none"
        onClick={() => setOpen(o => !o)}
        title="Clic para ver desglose por compañía"
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-muted text-foreground font-semibold shrink-0">
            {idx + 1}
          </div>
          <div>
            <p className="font-medium text-foreground ">{agent.name}</p>
            <p className="text-sm text-muted-foreground">
              {agent.count} póliza{agent.count !== 1 ? 's' : ''}
              <span className="ml-2 text-xs text-blue-400 font-medium">
                {open ? '▲ ocultar' : '▼ ver detalle'}
              </span>
            </p>
          </div>
        </div>
        <p className="font-bold text-emerald-600 dark:text-emerald-400 shrink-0">USD {formatMoney(agent.total)}</p>
      </div>

      {/* Inline expandable detail */}
      {open && (
        <div className="mt-1 mb-1 ml-11 bg-card border border-border rounded-lg p-3 shadow-sm">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Desglose por compañía</p>
          <div className="space-y-2">
            {agent.byCompany.map((c, i) => (
              <div key={i} className="space-y-0.5">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium text-foreground/80 truncate max-w-[160px]">{c.name}</span>
                  <div className="flex items-center gap-3 shrink-0 ml-2">
                    <span className="text-muted-foreground/70 text-xs">{c.count} póliza{c.count !== 1 ? 's' : ''}</span>
                    <span className="font-semibold text-foreground text-xs">
                      USD {formatMoney(c.value)}
                    </span>
                  </div>
                </div>
                {/* Mini progress bar */}
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-400 rounded-full"
                    style={{ width: `${Math.round((c.value / maxCompanyValue) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}