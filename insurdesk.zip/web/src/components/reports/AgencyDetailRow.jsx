import React, { useState } from 'react';
import { Users } from 'lucide-react';
import { formatMoney } from '@/lib/formatMoney';

export default function AgencyDetailRow({ agency, idx }) {
  const [open, setOpen] = useState(false);

  const maxAgentValue = agency.agents.length > 0 ? agency.agents[0].total : 1;

  return (
    <div>
      <div
        className="flex items-center justify-between p-3 bg-muted/40 rounded-lg cursor-pointer hover:bg-muted transition-colors select-none"
        onClick={() => setOpen(o => !o)}
        title="Clic para ver desglose por agente"
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 font-semibold shrink-0 text-sm">
            {idx + 1}
          </div>
          <div>
            <p className="font-medium text-foreground ">{agency.name}</p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-3 w-3" />
              <span>{agency.structureCount} agente{agency.structureCount !== 1 ? 's' : ''} en estructura</span>
              <span>·</span>
              <span>{agency.totalPolicies} póliza{agency.totalPolicies !== 1 ? 's' : ''}</span>
              <span className="ml-1 text-xs text-purple-400 font-medium">
                {open ? '▲ ocultar' : '▼ ver detalle'}
              </span>
            </div>
          </div>
        </div>
        <div className="text-right shrink-0">
          <p className="font-bold text-emerald-600 dark:text-emerald-400">USD {formatMoney(agency.totalPremium)}</p>
          <p className="text-xs text-muted-foreground/70">total estructura</p>
        </div>
      </div>

      {open && (
        <div className="mt-1 mb-1 ml-11 bg-card border border-border rounded-lg p-3 shadow-sm">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Desglose por agente</p>
          <div className="space-y-2">
            {agency.agents.map((agent, i) => (
              <div key={i} className="space-y-0.5">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2 min-w-0">
                    {agent.isHead && (
                      <span className="text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 px-1.5 py-0.5 rounded font-medium shrink-0">Cabeza</span>
                    )}
                    <span className="font-medium text-foreground/80 truncate">{agent.name}</span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 ml-2">
                    <span className="text-muted-foreground/70 text-xs">{agent.count} póliza{agent.count !== 1 ? 's' : ''}</span>
                    <span className="font-semibold text-foreground text-xs">
                      USD {formatMoney(agent.total)}
                    </span>
                  </div>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-400 rounded-full"
                    style={{ width: `${Math.round((agent.total / maxAgentValue) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}