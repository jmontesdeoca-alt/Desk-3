import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, addMonths, subMonths, isPast } from 'date-fns';
import { es } from 'date-fns/locale';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const AGENT_COLORS = [
  'bg-primary', 'bg-emerald-500', 'bg-violet-500', 'bg-orange-500',
  'bg-pink-500', 'bg-teal-500', 'bg-indigo-500', 'bg-rose-500',
  'bg-cyan-500', 'bg-amber-500', 'bg-lime-500', 'bg-fuchsia-500',
];

export default function AgentCalendar({ tasks = [], renewals = [], policies = [], agents = [], ownAgentId = null }) {
  const [currentDate, setCurrentDate] = useState(new Date());

  // Build consistent color map per agent_id
  const agentColorMap = {};
  let colorIdx = 0;
  policies.forEach(p => {
    if (p.agent_id && !(p.agent_id in agentColorMap)) {
      agentColorMap[p.agent_id] = AGENT_COLORS[colorIdx % AGENT_COLORS.length];
      colorIdx++;
    }
  });

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { locale: es });
  const endDate = endOfWeek(monthEnd, { locale: es });

  const rows = [];
  let days = [];
  let day = startDate;

  while (day <= endDate) {
    for (let i = 0; i < 7; i++) {
      days.push(day);
      day = addDays(day, 1);
    }
    rows.push(days);
    days = [];
  }

  const getItemsForDay = (date) => {
    const dayTasks = tasks.filter(task => {
      if (!task.due_date) return false;
      return isSameDay(new Date(task.due_date), date);
    });

    // Mostrar pólizas activas que vencen en este día (próximas renovaciones)
    const dayPolicies = policies.filter(policy => {
      if (!policy.end_date || policy.status !== 'activa') return false;
      return isSameDay(new Date(policy.end_date), date);
    });

    return { tasks: dayTasks, renewals: dayPolicies };
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'alta': return 'bg-red-500';
      case 'media': return 'bg-amber-500';
      case 'baja': return 'bg-emerald-500';
      default: return 'bg-muted-foreground';
    }
  };

  const getRenewalColor = (agentId) => agentColorMap[agentId] || 'bg-primary';

  const renderDay = (day) => {
    const { tasks: dayTasks, renewals: dayRenewals } = getItemsForDay(day);
    const isCurrentMonth = isSameMonth(day, currentDate);
    const isToday = isSameDay(day, new Date());
    const isPastDay = isPast(day) && !isToday;
    const totalItems = dayTasks.length + dayRenewals.length;

    if (totalItems === 0) {
      return (
        <div
          key={day.toString()}
          className={`min-h-24 p-2 border border-border ${
            !isCurrentMonth ? 'bg-muted/40' : 'bg-card'
          } ${isToday ? 'ring-2 ring-ring' : ''}`}
        >
          <div className={`text-sm font-medium mb-1 ${
            !isCurrentMonth ? 'text-muted-foreground/70' : 
            isToday ? 'text-foreground font-bold' : 
            'text-foreground/80'
          }`}>
            {format(day, 'd')}
          </div>
        </div>
      );
    }

    return (
      <Popover key={day.toString()}>
        <PopoverTrigger asChild>
          <div
            className={`min-h-24 p-2 border border-border cursor-pointer hover:bg-muted/40 ${
              !isCurrentMonth ? 'bg-muted/40' : 'bg-card'
            } ${isToday ? 'ring-2 ring-ring' : ''}`}
          >
            <div className={`text-sm font-medium mb-1 ${
              !isCurrentMonth ? 'text-muted-foreground/70' : 
              isToday ? 'text-foreground font-bold' : 
              'text-foreground/80'
            }`}>
              {format(day, 'd')}
            </div>
            <div className="space-y-0.5">
              {dayTasks.slice(0, 2).map((task, idx) => (
                <div
                  key={`task-${idx}`}
                  className={`text-xs px-1.5 py-0.5 rounded truncate ${
                    task.status === 'completada' 
                      ? 'bg-muted text-muted-foreground line-through' 
                      : `${getPriorityColor(task.priority)} text-white`
                  }`}
                  title={task.title}
                >
                  📋 {task.title}
                </div>
              ))}
              {dayRenewals.slice(0, 2).map((renewal, idx) => (
                <div
                  key={`renewal-${idx}`}
                  className={`text-xs px-1.5 py-0.5 rounded truncate ${getRenewalColor(renewal.agent_id)} text-white`}
                  title={`${renewal.policy_number} — ${renewal.agent_name}`}
                >
                  🔄 {renewal.policy_number}
                </div>
              ))}
              {totalItems > 4 && (
                <div className="text-xs text-muted-foreground text-center">
                  +{totalItems - 4} más
                </div>
              )}
            </div>
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-96" align="start">
          <div className="space-y-3">
            <div className="font-semibold text-sm border-b pb-2">
              {format(day, "d 'de' MMMM, yyyy", { locale: es })}
            </div>

            {dayTasks.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-muted-foreground mb-2">📋 Tareas</div>
                {dayTasks.map((task) => (
                  <div
                    key={task.id}
                    className="p-2 hover:bg-muted/40 rounded border border-border mb-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className={`font-medium text-sm ${
                          task.status === 'completada' ? 'line-through text-muted-foreground' : 'text-foreground'
                        }`}>
                          {task.title}
                        </div>
                        {task.description && (
                          <div className="text-xs text-muted-foreground mt-1 line-clamp-2">
                            {task.description}
                          </div>
                        )}
                      </div>
                      <Badge className={`${getPriorityColor(task.priority)} text-white text-xs`}>
                        {task.priority}
                      </Badge>
                    </div>
                    {task.status === 'pendiente' && isPastDay && (
                      <div className="text-xs text-red-600 dark:text-red-400 font-semibold mt-1">
                        ⚠️ Vencida
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {dayRenewals.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-muted-foreground mb-2">🔄 Renovaciones Pendientes</div>
                {dayRenewals.map((policy) => {
                  const color = getRenewalColor(policy.agent_id);
                  const isOwn = policy.agent_id === ownAgentId;
                  return (
                    <div
                      key={policy.id}
                      className={`p-2 rounded border mb-2 border-l-4 ${color.replace('bg-', 'border-l-')} bg-muted/40`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <div className="font-medium text-sm text-foreground">
                            {policy.policy_number}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {policy.client_name}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <div className={`w-2 h-2 rounded-full ${color}`}></div>
                            <span className="text-xs text-muted-foreground">
                              {isOwn ? 'Mi póliza' : policy.agent_name}
                            </span>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Prima: {policy.currency} {policy.annual_premium?.toLocaleString()}
                          </div>
                        </div>
                        <Badge className={`${color} text-white text-xs`}>
                          Vence hoy
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </PopoverContent>
      </Popover>
    );
  };

  return (
    <div className="bg-card rounded-xl border border-border p-4">
      {/* Header with navigation */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">
          {format(currentDate, "MMMM yyyy", { locale: es }).charAt(0).toUpperCase() + 
           format(currentDate, "MMMM yyyy", { locale: es }).slice(1)}
        </h3>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentDate(subMonths(currentDate, 1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentDate(new Date())}
          >
            Hoy
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentDate(addMonths(currentDate, 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 mb-3 text-xs flex-wrap">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-red-500"></div>
          <span>Tarea Alta</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-amber-500"></div>
          <span>Tarea Media</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-emerald-500"></div>
          <span>Tarea Baja</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-muted border"></div>
          <span>Completada</span>
        </div>
        {/* Dynamic legend per agent */}
        {Object.entries(agentColorMap).map(([aId, color]) => {
          const agentObj = agents.find(a => a.id === aId);
          if (!agentObj) return null;
          const label = aId === ownAgentId ? 'Mis renovaciones' : agentObj.name;
          return (
            <div key={aId} className="flex items-center gap-1">
              <div className={`w-3 h-3 rounded ${color}`}></div>
              <span className="truncate max-w-[120px]">{label}</span>
            </div>
          );
        })}
      </div>

      {/* Calendar grid */}
      <div className="overflow-x-auto">
        <div className="min-w-[700px]">
          {/* Day headers */}
          <div className="grid grid-cols-7 gap-0 mb-2">
            {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map((day) => (
              <div key={day} className="text-center text-sm font-semibold text-muted-foreground py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar days */}
          {rows.map((week, idx) => (
            <div key={idx} className="grid grid-cols-7 gap-0">
              {week.map((day) => renderDay(day))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}