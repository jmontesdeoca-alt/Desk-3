import React, { useState, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ChevronDown, ChevronUp, ChevronLeft, ChevronRight } from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';
import { useTranslation } from 'react-i18next';
import '@/components/i18n';

const SLIDES_THRESHOLD = 3;

export default function BirthdayWidget({ birthdays }) {
  const { t } = useTranslation();
  const [collapsed, setCollapsed] = useState(false);
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: false, align: 'start' });

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);

  const useCarousel = birthdays.length > SLIDES_THRESHOLD;

  return (
    <Card className="border-0 shadow-sm bg-gradient-to-r from-pink-50 to-purple-50 dark:from-pink-900/20 dark:to-purple-900/20">
      <CardHeader
        className="cursor-pointer select-none pb-2"
        onClick={() => setCollapsed(c => !c)}
      >
        <CardTitle className="text-lg font-semibold flex items-center justify-between">
          <span className="flex items-center gap-2">
            🎉 {t('dashboard.todayBirthdays')}
            <span className="text-sm font-normal text-purple-600 dark:text-purple-400 dark:text-purple-400">
              ({birthdays.length})
            </span>
          </span>
          {collapsed
            ? <ChevronDown className="h-5 w-5 text-purple-500" />
            : <ChevronUp className="h-5 w-5 text-purple-500" />
          }
        </CardTitle>
      </CardHeader>

      {!collapsed && (
        <CardContent className="pt-0">
          {useCarousel ? (
            <div className="relative">
              {/* Botones de navegación */}
              <button
                onClick={scrollPrev}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 z-10 bg-card border border-border rounded-full p-1 shadow-sm hover:bg-purple-500/10 transition-colors"
              >
                <ChevronLeft className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              </button>
              <button
                onClick={scrollNext}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-3 z-10 bg-card border border-border rounded-full p-1 shadow-sm hover:bg-purple-500/10 transition-colors"
              >
                <ChevronRight className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              </button>

              {/* Carrusel */}
              <div className="overflow-hidden mx-2" ref={emblaRef}>
                <div className="flex gap-3">
                  {birthdays.map((birthday, idx) => (
                    <div key={idx} className="flex-none w-[calc(50%-6px)] sm:w-[calc(33.333%-8px)]">
                      <BirthdayCard birthday={birthday} t={t} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Vista lista normal si hay 3 o menos */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {birthdays.map((birthday, idx) => (
                <BirthdayCard key={idx} birthday={birthday} t={t} />
              ))}
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
}

function BirthdayCard({ birthday, t }) {
  return (
    <div className="flex items-center justify-between p-3 bg-card rounded-lg h-full">
      <div className="min-w-0 flex-1">
        <p className="font-medium text-foreground dark:text-white truncate">{birthday.name}</p>
        <p className="text-xs text-muted-foreground truncate">{birthday.type} • {birthday.email}</p>
      </div>
      <div className="text-right ml-2 shrink-0">
        <span className="text-2xl">🎂</span>
        <p className="text-xs text-purple-600 dark:text-purple-400 dark:text-purple-400 font-medium">{birthday.age} {t('dashboard.years')}</p>
      </div>
    </div>
  );
}