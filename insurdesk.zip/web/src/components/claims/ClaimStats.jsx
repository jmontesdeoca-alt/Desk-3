import React from 'react';
import StatCard from '@/components/ui/StatCard';
import { Clock, CheckCircle, AlertCircle, DollarSign } from 'lucide-react';

export default function ClaimStats({ claims }) {
  const inProcess = claims.filter(c => c.status === 'en_proceso').length;
  const approved = claims.filter(c => c.status === 'aprobado').length;
  const totalClaimed = claims.reduce((sum, c) => sum + (c.claimed_amount || 0), 0);
  const totalPaid = claims.reduce((sum, c) => sum + (c.paid_amount || 0), 0);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <StatCard title="En Proceso" value={inProcess} icon={Clock} iconBg="bg-muted" iconColor="text-foreground" />
      <StatCard title="Aprobados" value={approved} icon={CheckCircle} iconBg="bg-emerald-500/10" iconColor="text-emerald-600 dark:text-emerald-400" />
      <StatCard title="Total Reclamado" value={`$${totalClaimed.toLocaleString()}`} icon={AlertCircle} iconBg="bg-amber-500/10" iconColor="text-amber-600 dark:text-amber-400" />
      <StatCard title="Total Pagado" value={`$${totalPaid.toLocaleString()}`} icon={DollarSign} iconBg="bg-purple-500/10" iconColor="text-purple-600 dark:text-purple-400" />
    </div>
  );
}