import React, { useState } from 'react';
import { api } from '@/api/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import StatusBadge from '@/components/ui/StatusBadge';
import DocumentList from '@/components/documents/DocumentList';
import ClaimHistoryTimeline from './ClaimHistoryTimeline';
import ClaimAddendums from './ClaimAddendums';
import { format } from 'date-fns';
import { CheckCircle, XCircle, DollarSign, Loader2, AlertTriangle, FileQuestion } from 'lucide-react';
import { toast } from 'sonner';
import ClaimReportPanel from './ClaimReportPanel';
import ClaimInvoiceDetail from './ClaimInvoiceDetail';
import ClaimInfoRequests from './ClaimInfoRequests';

export default function ClaimDetailDialog({ claim, open, onOpenChange, onSaved }) {
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState({});
  const [approveMode, setApproveMode] = useState(false);
  const [approveAmount, setApproveAmount] = useState('');
  const [approveNote, setApproveNote] = useState('');
  const [liquidationInvoices, setLiquidationInvoices] = useState([]);

  // Derived totals
  const addendumsClaimed = (claim?.addendums || []).reduce((s, a) => s + (a.additional_amount || 0), 0);
  const addendumsPaid    = (claim?.addendums || []).reduce((s, a) => s + (a.paid_amount || 0), 0);
  // If using invoice detail, also compute invoice-level liquidation
  const invoicePaid      = claim?.has_invoice_detail
    ? (claim?.invoice_details || []).reduce((s, inv) => s + (parseFloat(inv.amount_paid) || 0), 0)
    : 0;
  const totalClaimed     = (claim?.claimed_amount || 0) + addendumsClaimed;
  const totalPaid        = claim?.has_invoice_detail
    ? invoicePaid + addendumsPaid
    : (claim?.paid_amount || 0) + addendumsPaid;
  const difference       = totalClaimed - totalPaid;

  const canEdit = true; // pass role check from parent if needed

  const addHistoryEntry = async (updatedClaim, action, amount, note) => {
    const user = await api.auth.me();
    const entry = {
      date: new Date().toISOString(),
      action,
      user_email: user.email,
      user_name: user.full_name || user.email,
      ...(amount != null && { amount }),
      ...(note && { note }),
    };
    return [...(updatedClaim.history || []), entry];
  };

  // ── Status change actions ──────────────────────────────────────────
  const handleApprove = async () => {
    setSaving(true);

    let amount, newStatus, actionType, updateData;

    if (claim.has_invoice_detail) {
      const updatedInvoices = liquidationInvoices.map(inv => ({
        ...inv,
        amount_paid: parseFloat(inv.amount_paid) || 0,
      }));
      const totalLiquidado = updatedInvoices.reduce((s, inv) => s + (inv.amount_paid || 0), 0);
      const totalReclamado = updatedInvoices.reduce((s, inv) => s + (parseFloat(inv.amount_claimed) || 0), 0);
      const isPartial = totalLiquidado < totalReclamado;
      amount = totalLiquidado;
      newStatus = isPartial ? 'pagado_parcial' : 'pagado';
      actionType = isPartial ? 'pago_parcial' : 'pago';
      updateData = {
        status: newStatus,
        paid_amount: totalLiquidado,
        invoice_details: updatedInvoices,
        payment_date: new Date().toISOString().split('T')[0],
        ...(approveNote && { difference_note: approveNote }),
      };
    } else {
      amount = parseFloat(approveAmount);
      if (!amount) { setSaving(false); return; }
      const isPartial = amount < claim.claimed_amount;
      newStatus = isPartial ? 'pagado_parcial' : 'pagado';
      actionType = isPartial ? 'pago_parcial' : 'pago';
      updateData = {
        status: newStatus,
        paid_amount: amount,
        payment_date: new Date().toISOString().split('T')[0],
        ...(approveNote && { difference_note: approveNote }),
      };
    }

    const historyEntries = [
      { date: new Date().toISOString(), action: 'aprobado', user_email: '', user_name: '' },
      { date: new Date().toISOString(), action: actionType, user_email: '', user_name: '', amount, ...(approveNote && { note: approveNote }) },
    ];
    const user = await api.auth.me();
    const enriched = historyEntries.map(e => ({ ...e, user_email: user.email, user_name: user.full_name || user.email }));
    const history = [...(claim.history || []), ...enriched];

    await api.entities.Claim.update(claim.id, { ...updateData, history });
    toast.success('Siniestro aprobado y pago registrado');
    setSaving(false);
    setApproveMode(false);
    setApproveAmount('');
    setApproveNote('');
    setLiquidationInvoices([]);
    onSaved();
    onOpenChange(false);
  };

  const handleReject = async () => {
    const note = window.prompt('Motivo de rechazo (opcional):') ?? '';
    setSaving(true);
    const history = await addHistoryEntry(claim, 'rechazado', null, note || null);
    await api.entities.Claim.update(claim.id, { status: 'rechazado', history });
    toast.success('Siniestro rechazado');
    setSaving(false);
    onSaved();
    onOpenChange(false);
  };

  const handlePay = async (payData) => {
    setSaving(true);

    let amount, newStatus, actionType, updateData;

    if (claim.has_invoice_detail) {
      const updatedInvoices = payData.invoices.map(inv => ({
        ...inv,
        amount_paid: parseFloat(inv.amount_paid) || 0,
      }));
      const totalLiquidado = updatedInvoices.reduce((s, inv) => s + (inv.amount_paid || 0), 0);
      const totalReclamado = updatedInvoices.reduce((s, inv) => s + (parseFloat(inv.amount_claimed) || 0), 0);
      const isPartial = totalLiquidado < totalReclamado;
      amount = totalLiquidado;
      newStatus = isPartial ? 'pagado_parcial' : 'pagado';
      actionType = isPartial ? 'pago_parcial' : 'pago';
      updateData = {
        status: newStatus,
        paid_amount: totalLiquidado,
        invoice_details: updatedInvoices,
        payment_date: new Date().toISOString().split('T')[0],
        ...(payData.note && { difference_note: payData.note }),
      };
    } else {
      amount = payData.amount;
      const isPartial = amount < claim.claimed_amount;
      newStatus = isPartial ? 'pagado_parcial' : 'pagado';
      actionType = isPartial ? 'pago_parcial' : 'pago';
      updateData = {
        status: newStatus,
        paid_amount: amount,
        payment_date: new Date().toISOString().split('T')[0],
        ...(payData.note && { difference_note: payData.note }),
      };
    }

    const history = await addHistoryEntry(claim, actionType, amount, payData.note || null);
    await api.entities.Claim.update(claim.id, { ...updateData, history });
    toast.success('Pago registrado');
    setSaving(false);
    onSaved();
    onOpenChange(false);
  };

  // ── Addendums ──────────────────────────────────────────────────────
  const handleAddAddendum = async (addendum) => {
    setSaving(true);
    const newAddendums = [...(claim.addendums || []), addendum];
    const history = await addHistoryEntry(claim, 'alcance_agregado', addendum.additional_amount, addendum.description);
    await api.entities.Claim.update(claim.id, { addendums: newAddendums, history });
    toast.success('Alcance agregado');
    setSaving(false);
    onSaved();
  };

  const handleUpdateAddendum = async (idx, data) => {
    setSaving(true);
    const newAddendums = [...(claim.addendums || [])];
    const prev = newAddendums[idx];
    newAddendums[idx] = { ...prev, ...data };

    let action = 'nota';
    if (data.status === 'aprobado' && prev.status !== 'aprobado') action = 'alcance_aprobado';
    if (data.status === 'rechazado' && prev.status !== 'rechazado') action = 'alcance_rechazado';
    if (data.status === 'pagado' && prev.status !== 'pagado') action = 'alcance_pagado';

    const history = await addHistoryEntry(claim, action, data.paid_amount, data.rejection_note);
    await api.entities.Claim.update(claim.id, { addendums: newAddendums, history });
    toast.success('Alcance actualizado');
    setSaving(false);
    onSaved();
  };

  // ── Inline edit ────────────────────────────────────────────────────
  const startEdit = () => {
    setEditData({
      claim_type:     claim.claim_type,
      event_date:     claim.event_date,
      claimed_amount: claim.claimed_amount,
      observations:   claim.observations || '',
      affected_person: claim.affected_person || '',
      dependent_name: claim.dependent_name || '',
    });
    setEditMode(true);
  };

  const saveEdit = async () => {
    setSaving(true);
    const history = await addHistoryEntry(claim, 'nota', null, 'Información del siniestro actualizada');
    await api.entities.Claim.update(claim.id, { ...editData, history });
    toast.success('Siniestro actualizado');
    setSaving(false);
    setEditMode(false);
    onSaved();
  };

  if (!claim) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            Siniestro {claim.claim_number}
            <StatusBadge status={claim.status} />
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="detail">
          <TabsList className="w-full">
            <TabsTrigger value="detail" className="flex-1">Detalle</TabsTrigger>
            <TabsTrigger value="payments" className="flex-1">Pagos</TabsTrigger>
            {claim.has_invoice_detail && (
              <TabsTrigger value="invoices" className="flex-1">Facturas</TabsTrigger>
            )}
            <TabsTrigger value="addendums" className="flex-1">Alcances</TabsTrigger>
            <TabsTrigger value="history" className="flex-1">Historial</TabsTrigger>
            <TabsTrigger value="documents" className="flex-1">Docs</TabsTrigger>
            <TabsTrigger value="info_requests" className="flex-1 gap-1">
              <FileQuestion className="h-3.5 w-3.5" />Info
            </TabsTrigger>
            <TabsTrigger value="report" className="flex-1">Informe</TabsTrigger>
          </TabsList>

          {/* ── DETALLE ── */}
          <TabsContent value="detail" className="space-y-4 pt-4">
            {editMode ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Tipo de Siniestro</Label>
                    <Input value={editData.claim_type} onChange={e => setEditData({...editData, claim_type: e.target.value})} />
                  </div>
                  <div>
                    <Label>Fecha del Evento</Label>
                    <Input type="date" value={editData.event_date} onChange={e => setEditData({...editData, event_date: e.target.value})} />
                  </div>
                  <div>
                    <Label>Monto Reclamado ({claim.currency})</Label>
                    <Input type="number" value={editData.claimed_amount} onChange={e => setEditData({...editData, claimed_amount: parseFloat(e.target.value)})} />
                  </div>
                  <div>
                    <Label>Persona Afectada</Label>
                    <Select value={editData.affected_person} onValueChange={v => setEditData({...editData, affected_person: v})}>
                      <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="titular">Titular</SelectItem>
                        <SelectItem value="dependiente">Dependiente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {editData.affected_person === 'dependiente' && (
                    <div className="col-span-2">
                      <Label>Nombre del Dependiente</Label>
                      <Input value={editData.dependent_name} onChange={e => setEditData({...editData, dependent_name: e.target.value})} />
                    </div>
                  )}
                  <div className="col-span-2">
                    <Label>Observaciones</Label>
                    <Textarea value={editData.observations} onChange={e => setEditData({...editData, observations: e.target.value})} rows={3} />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={saveEdit} disabled={saving}>{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Guardar Cambios'}</Button>
                  <Button variant="ghost" onClick={() => setEditMode(false)}>Cancelar</Button>
                </div>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Póliza</p>
                    <Link to={createPageUrl(`PolicyDetail?id=${claim.policy_id}`)} className="text-foreground hover:underline text-sm font-medium">
                      {claim.policy_number}
                    </Link>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Cliente</p>
                    <p className="text-sm font-medium">{claim.client_name}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Tipo de Siniestro</p>
                    <p className="text-sm font-medium">{claim.claim_type}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Fecha del Evento</p>
                    <p className="text-sm font-medium">{claim.event_date ? format(new Date(claim.event_date), 'dd/MM/yyyy') : '-'}</p>
                  </div>
                  {claim.dependent_name && (
                    <div>
                      <p className="text-xs text-muted-foreground">Dependiente Afectado</p>
                      <p className="text-sm font-medium">{claim.dependent_name}</p>
                    </div>
                  )}
                  {claim.corporate_member_name && (
                    <div>
                      <p className="text-xs text-muted-foreground">Afiliado Corporativo</p>
                      <p className="text-sm font-medium">{claim.corporate_member_name}</p>
                    </div>
                  )}
                </div>
                {claim.observations && (
                  <div>
                    <p className="text-xs text-muted-foreground">Observaciones</p>
                    <p className="text-sm bg-muted/40 rounded p-3">{claim.observations}</p>
                  </div>
                )}
                <Button variant="outline" size="sm" onClick={startEdit}>Editar Información</Button>

                {/* Status actions */}
                {claim.status === 'en_proceso' && (
                  <div className="pt-2 border-t space-y-3">
                    {approveMode ? (
                      <div className="space-y-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                        <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                          <CheckCircle className="h-4 w-4" /> Aprobar Siniestro
                        </p>
                        {claim.has_invoice_detail ? (
                          <>
                            <div>
                              <Label className="text-emerald-600 dark:text-emerald-400">Liquidación por factura ({claim.currency})</Label>
                              <p className="text-xs text-muted-foreground mt-1">Ingresa el monto liquidado para cada factura.</p>
                            </div>
                            <ClaimInvoiceDetail
                              invoices={liquidationInvoices}
                              onChange={setLiquidationInvoices}
                              currency={claim.currency}
                              readOnly={true}
                              canLiquidate={true}
                            />
                            {(() => {
                              const totalLiquidado = liquidationInvoices.reduce((s, inv) => s + (parseFloat(inv.amount_paid) || 0), 0);
                              const totalReclamado = liquidationInvoices.reduce((s, inv) => s + (parseFloat(inv.amount_claimed) || 0), 0);
                              const isPartial = totalLiquidado < totalReclamado;
                              return (
                                <>
                                  <div className="bg-card rounded-lg p-3 border border-emerald-500/30">
                                    <div className="flex justify-between text-sm">
                                      <span className="text-muted-foreground">Total Liquidado:</span>
                                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{claim.currency} {totalLiquidado.toLocaleString('es', { minimumFractionDigits: 2 })}</span>
                                    </div>
                                    {isPartial && totalLiquidado > 0 && (
                                      <div className="flex justify-between text-sm mt-1">
                                        <span className="text-amber-600 dark:text-amber-400">Diferencia:</span>
                                        <span className="font-bold text-amber-600 dark:text-amber-400">{claim.currency} {(totalReclamado - totalLiquidado).toLocaleString('es', { minimumFractionDigits: 2 })}</span>
                                      </div>
                                    )}
                                  </div>
                                  {isPartial && totalLiquidado > 0 && (
                                    <div>
                                      <Label className="text-amber-600 dark:text-amber-400">
                                        Nota de diferencia <span className="text-red-500">*</span>
                                        <span className="ml-1 font-normal text-muted-foreground">(liquidación menor al reclamado)</span>
                                      </Label>
                                      <Textarea
                                        value={approveNote}
                                        onChange={e => setApproveNote(e.target.value)}
                                        rows={2}
                                        placeholder="Ej: Deducible aplicado, gasto no amparado por la póliza..."
                                      />
                                    </div>
                                  )}
                                  <div className="flex gap-2">
                                    <Button
                                      onClick={handleApprove}
                                      disabled={saving || totalLiquidado === 0 || (isPartial && !approveNote)}
                                      className="flex-1 gap-2 bg-emerald-600 hover:bg-emerald-700"
                                    >
                                      {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle className="h-4 w-4" /> Confirmar Aprobación</>}
                                    </Button>
                                    <Button variant="ghost" onClick={() => { setApproveMode(false); setApproveAmount(''); setApproveNote(''); setLiquidationInvoices([]); }}>
                                      Cancelar
                                    </Button>
                                  </div>
                                </>
                              );
                            })()}
                          </>
                        ) : (
                          <>
                            <div>
                              <Label>Monto a pagar ({claim.currency}) <span className="text-red-500">*</span></Label>
                              <Input
                                type="number"
                                step="0.01"
                                placeholder={`Reclamado: ${claim.claimed_amount?.toLocaleString()}`}
                                value={approveAmount}
                                onChange={e => setApproveAmount(e.target.value)}
                                autoFocus
                              />
                              <p className="text-xs text-muted-foreground mt-1">Monto total reclamado: {claim.currency} {claim.claimed_amount?.toLocaleString()}</p>
                            </div>
                            {approveAmount && parseFloat(approveAmount) < claim.claimed_amount && (
                              <div>
                                <Label className="text-amber-600 dark:text-amber-400">
                                  Nota de diferencia <span className="text-red-500">*</span>
                                  <span className="ml-1 font-normal text-muted-foreground">(pago menor al reclamado)</span>
                                </Label>
                                <Textarea
                                  value={approveNote}
                                  onChange={e => setApproveNote(e.target.value)}
                                  rows={2}
                                  placeholder="Ej: Deducible aplicado, gasto no amparado por la póliza..."
                                />
                              </div>
                            )}
                            <div className="flex gap-2">
                              <Button
                                onClick={handleApprove}
                                disabled={saving || !approveAmount || (parseFloat(approveAmount) < claim.claimed_amount && !approveNote)}
                                className="flex-1 gap-2 bg-emerald-600 hover:bg-emerald-700"
                              >
                                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle className="h-4 w-4" /> Confirmar Aprobación</>}
                              </Button>
                              <Button variant="ghost" onClick={() => { setApproveMode(false); setApproveAmount(''); setApproveNote(''); }}>
                                Cancelar
                              </Button>
                            </div>
                          </>
                        )}
                      </div>
                    ) : (
                      <div className="flex gap-3">
                        <Button onClick={() => {
                          setApproveMode(true);
                          if (claim.has_invoice_detail) {
                            setLiquidationInvoices((claim.invoice_details || []).map(inv => ({ ...inv })));
                          }
                        }} disabled={saving} className="flex-1 gap-2 bg-emerald-600 hover:bg-emerald-700">
                          <CheckCircle className="h-4 w-4" /> Aprobar
                        </Button>
                        <Button variant="outline" onClick={handleReject} disabled={saving} className="flex-1 gap-2">
                          <XCircle className="h-4 w-4" /> Rechazar
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </TabsContent>

          {/* ── PAGOS ── */}
          <TabsContent value="payments" className="space-y-4 pt-4">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-muted/40 rounded-lg p-3 text-center">
                <p className="text-xs text-muted-foreground">Total Reclamado</p>
                <p className="text-lg font-bold text-foreground">{claim.currency} {totalClaimed.toLocaleString()}</p>
              </div>
              <div className="bg-emerald-500/10 rounded-lg p-3 text-center">
                <p className="text-xs text-muted-foreground">Total Pagado</p>
                <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{claim.currency} {totalPaid.toLocaleString()}</p>
              </div>
              <div className={`rounded-lg p-3 text-center ${difference > 0 ? 'bg-amber-500/10' : 'bg-muted/40'}`}>
                <p className="text-xs text-muted-foreground">Diferencia</p>
                <p className={`text-lg font-bold ${difference > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground/70'}`}>
                  {claim.currency} {difference.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Payment dates */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">Fecha de Pago</p>
                <p className="font-medium">{claim.payment_date ? format(new Date(claim.payment_date), 'dd/MM/yyyy') : 'Sin registrar'}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Estado</p>
                <StatusBadge status={claim.status} />
              </div>
            </div>

            {/* Difference note */}
            {claim.difference_note && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                  <p className="text-xs font-medium text-amber-600 dark:text-amber-400">Nota de Diferencia</p>
                </div>
                <p className="text-sm text-amber-600 dark:text-amber-400">{claim.difference_note}</p>
              </div>
            )}

            {/* Register Payment */}
            {(() => {
              const hasPendingAddendum = (claim.addendums || []).some(a => a.status === 'aprobado');
              const canPay = claim.status === 'aprobado' || hasPendingAddendum;
              return canPay ? (
                <PaymentForm claim={claim} currency={claim.currency} onPay={handlePay} saving={saving} />
              ) : null;
            })()}
          </TabsContent>

          {/* ── FACTURAS ── */}
          {claim.has_invoice_detail && (
            <TabsContent value="invoices" className="pt-4 space-y-3">
              <ClaimInvoiceDetail
                invoices={claim.invoice_details || []}
                currency={claim.currency}
                readOnly={true}
              />
            </TabsContent>
          )}

          {/* ── ALCANCES ── */}
          <TabsContent value="addendums" className="pt-4">
            <ClaimAddendums
              addendums={claim.addendums}
              currency={claim.currency}
              onAdd={handleAddAddendum}
              onUpdate={handleUpdateAddendum}
              canEdit={canEdit}
            />
          </TabsContent>

          {/* ── HISTORIAL ── */}
          <TabsContent value="history" className="pt-4">
            <ClaimHistoryTimeline history={claim.history} />
          </TabsContent>

          {/* ── DOCUMENTOS ── */}
          <TabsContent value="documents" className="pt-4">
            <DocumentList
              entityType="Claim"
              entityId={claim.id}
              entityReference={claim.claim_number}
            />
          </TabsContent>

          {/* ── SOLICITUDES INFO ── */}
          <TabsContent value="info_requests" className="pt-4">
            <ClaimInfoRequests claim={claim} />
          </TabsContent>

          {/* ── INFORME ── */}
          <TabsContent value="report" className="pt-2">
            <ClaimReportPanel claim={claim} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// ── Sub-component: PaymentForm ────────────────────────────────────────
function PaymentForm({ claim, currency, onPay, saving }) {
  const [amount, setAmount] = useState(claim.claimed_amount || '');
  const [note, setNote] = useState('');
  const [payInvoices, setPayInvoices] = useState(
    claim.has_invoice_detail ? (claim.invoice_details || []).map(inv => ({ ...inv })) : []
  );

  if (claim.has_invoice_detail) {
    const totalLiquidado = payInvoices.reduce((s, inv) => s + (parseFloat(inv.amount_paid) || 0), 0);
    const totalReclamado = payInvoices.reduce((s, inv) => s + (parseFloat(inv.amount_claimed) || 0), 0);
    const isPartial = totalLiquidado < totalReclamado;

    return (
      <div className="border-t pt-4 space-y-3">
        <p className="text-sm font-medium text-foreground/80">Registrar Pago por Factura</p>
        <ClaimInvoiceDetail
          invoices={payInvoices}
          onChange={setPayInvoices}
          currency={currency}
          readOnly={true}
          canLiquidate={true}
        />
        <div className="bg-muted/40 rounded-lg p-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total Liquidado:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400">{currency} {totalLiquidado.toLocaleString('es', { minimumFractionDigits: 2 })}</span>
          </div>
        </div>
        {isPartial && totalLiquidado > 0 && (
          <div>
            <Label className="text-amber-600 dark:text-amber-400">
              Nota de diferencia <span className="text-red-500">*</span>
            </Label>
            <Textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              rows={2}
              placeholder="Explica el motivo de la diferencia..."
            />
          </div>
        )}
        <Button
          className="w-full gap-2"
          disabled={saving || totalLiquidado === 0 || (isPartial && !note)}
          onClick={() => onPay({ invoices: payInvoices, note })}
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><DollarSign className="h-4 w-4" /> Registrar Pago</>}
        </Button>
      </div>
    );
  }

  const isPartial = parseFloat(amount) < claim.claimed_amount;

  return (
    <div className="border-t pt-4 space-y-3">
      <p className="text-sm font-medium text-foreground/80">Registrar Pago</p>
      <div>
        <Label>Monto Pagado ({currency})</Label>
        <Input
          type="number"
          step="0.01"
          value={amount}
          onChange={e => setAmount(e.target.value)}
        />
      </div>
      {isPartial && amount && (
        <div>
          <Label className="text-amber-600 dark:text-amber-400">
            Nota de diferencia <span className="text-red-500">*</span>
            <span className="ml-1 font-normal text-muted-foreground">(Monto menor al reclamado)</span>
          </Label>
          <Textarea
            value={note}
            onChange={e => setNote(e.target.value)}
            rows={2}
            placeholder="Explica el motivo de la diferencia: deducible, gasto no amparado, etc."
          />
        </div>
      )}
      <Button
        className="w-full gap-2"
        disabled={saving || !amount || (isPartial && !note)}
        onClick={() => onPay({ amount: parseFloat(amount), note })}
      >
        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <><DollarSign className="h-4 w-4" /> Registrar Pago</>}
      </Button>
    </div>
  );
}