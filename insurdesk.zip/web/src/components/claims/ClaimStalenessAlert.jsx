import React, { useMemo, useState } from 'react';
import { differenceInDays } from 'date-fns';
import { AlertTriangle, ChevronDown, ChevronUp, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

const STALE_DAYS = 15;

function getLastActivityDate(claim) {
  // Check history for the most recent entry
  if (claim.history && claim.history.length > 0) {
    const dates = claim.history
      .map(h => h.date)
      .filter(Boolean)
      .map(d => new Date(d))
      .filter(d => !isNaN(d));
    if (dates.length > 0) return new Date(Math.max(...dates));
  }
  // Check addendums
  if (claim.addendums && claim.addendums.length > 0) {
    const dates = claim.addendums
      .map(a => a.date)
      .filter(Boolean)
      .map(d => new Date(d))
      .filter(d => !isNaN(d));
    if (dates.length > 0) return new Date(Math.max(...dates));
  }
  // Fallback to created_date
  return claim.created_date ? new Date(claim.created_date) : null;
}

export default function ClaimStalenessAlert({ claims, onOpenDetail }) {
  const [expanded, setExpanded] = useState(true);

  const staleClaims = useMemo(() => {
    const today = new Date();
    return claims
      .filter(c => c.status === 'en_proceso' || c.status === 'aprobado' || c.status === 'pagado_parcial')
      .map(c => {
        const lastActivity = getLastActivityDate(c);
        const daysSince = lastActivity ? differenceInDays(today, lastActivity) : null;
        return { ...c, daysSince };
      })
      .filter(c => c.daysSince !== null && c.daysSince >= STALE_DAYS)
      .sort((a, b) => b.daysSince - a.daysSince);
  }, [claims]);

  if (staleClaims.length === 0) return null;

  const visible = expanded ? staleClaims : staleClaims.slice(0, 3);

  return (
    <div className="mb-6 border border-amber-500/30 bg-amber-500/10 rounded-xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-amber-500/10 border-b border-amber-500/30">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
          <span className="font-semibold text-amber-600 dark:text-amber-400 text-sm">
            {staleClaims.length} siniestro{staleClaims.length > 1 ? 's' : ''} sin actividad por más de {STALE_DAYS} días
          </span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="text-amber-600 dark:text-amber-400 hover:bg-amber-500/20 h-7 text-xs gap-1"
          onClick={() => setExpanded(prev => !prev)}
        >
          {expanded ? <><ChevronUp className="h-3 w-3" /> Colapsar</> : <><ChevronDown className="h-3 w-3" /> Ver todos</>}
        </Button>
      </div>

      {/* Table */}
      {expanded && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-amber-500/30 bg-amber-500/10">
                <th className="text-left px-4 py-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">Siniestro</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">Cliente</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">Tipo</th>
                <th className="text-left px-4 py-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">Estado</th>
                <th className="text-right px-4 py-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase">Sin actividad</th>
                {onOpenDetail && <th className="px-4 py-2"></th>}
              </tr>
            </thead>
            <tbody>
              {staleClaims.map(c => (
                <tr key={c.id} className="border-b border-amber-100 last:border-0 hover:bg-amber-100/60 transition-colors">
                  <td className="px-4 py-2.5 font-mono text-xs font-semibold text-amber-600 dark:text-amber-400">{c.claim_number || '—'}</td>
                  <td className="px-4 py-2.5 text-foreground/80">{c.client_name}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{c.claim_type}</td>
                  <td className="px-4 py-2.5">
                    <span className="inline-block text-xs px-2 py-0.5 rounded-full font-medium bg-amber-500/20 text-amber-600 dark:text-amber-400 capitalize">
                      {c.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <span className={`font-bold text-sm ${c.daysSince >= 30 ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>
                      {c.daysSince} días
                    </span>
                  </td>
                  {onOpenDetail && (
                    <td className="px-4 py-2.5 text-right">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onOpenDetail(c)}>
                        <Eye className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                      </Button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}