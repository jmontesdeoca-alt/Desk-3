import React from 'react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { CheckCircle, XCircle, DollarSign, Plus, FileText, MessageSquare, LogIn } from 'lucide-react';

const actionConfig = {
  ingreso:           { label: 'Siniestro ingresado',      icon: LogIn,         color: 'bg-muted text-foreground' },
  aprobado:          { label: 'Siniestro aprobado',       icon: CheckCircle,   color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
  rechazado:         { label: 'Siniestro rechazado',      icon: XCircle,       color: 'bg-red-500/10 text-red-600 dark:text-red-400' },
  pago:              { label: 'Pago registrado',          icon: DollarSign,    color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  pago_parcial:      { label: 'Pago parcial registrado',  icon: DollarSign,    color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400' },
  alcance_agregado:  { label: 'Alcance presentado',       icon: Plus,          color: 'bg-sky-500/10 text-sky-600 dark:text-sky-400' },
  alcance_aprobado:  { label: 'Alcance aprobado',         icon: CheckCircle,   color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
  alcance_rechazado: { label: 'Alcance rechazado',        icon: XCircle,       color: 'bg-red-500/10 text-red-600 dark:text-red-400' },
  alcance_pagado:    { label: 'Alcance pagado',           icon: DollarSign,    color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  nota:              { label: 'Nota agregada',            icon: MessageSquare, color: 'bg-muted text-muted-foreground' },
  documento:         { label: 'Documento adjuntado',      icon: FileText,      color: 'bg-muted text-foreground' },
};

export default function ClaimHistoryTimeline({ history = [] }) {
  if (!history.length) {
    return <p className="text-sm text-muted-foreground/70 text-center py-6">Sin historial registrado.</p>;
  }

  const sorted = [...history].sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <div className="space-y-4">
      {sorted.map((entry, idx) => {
        const config = actionConfig[entry.action] || { label: entry.action, icon: MessageSquare, color: 'bg-muted text-muted-foreground' };
        const Icon = config.icon;
        return (
          <div key={idx} className="flex gap-3">
            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${config.color}`}>
              <Icon className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-medium text-foreground">{config.label}</p>
                <span className="text-xs text-muted-foreground/70 whitespace-nowrap">
                  {entry.date ? format(new Date(entry.date), 'dd MMM yyyy HH:mm', { locale: es }) : '-'}
                </span>
              </div>
              {entry.amount != null && (
                <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">
                  Monto: ${entry.amount.toLocaleString()}
                </p>
              )}
              {entry.note && (
                <p className="text-sm text-muted-foreground mt-0.5 bg-muted/40 rounded p-2">{entry.note}</p>
              )}
              <p className="text-xs text-muted-foreground/70 mt-0.5">{entry.user_name || entry.user_email}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}