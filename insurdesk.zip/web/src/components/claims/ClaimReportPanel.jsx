import React, { useState } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Mail, Download, Loader2, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

// ── HTML del informe ──────────────────────────────────────────────────
function buildReportHTML(claim, totals) {
  const { totalClaimed, totalPaid, difference } = totals;
  const fmt = (n) => (n ?? 0).toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtDate = (d) => d ? format(new Date(d), 'dd/MM/yyyy') : '—';
  const statusLabel = {
    en_proceso: 'En Proceso', aprobado: 'Aprobado', rechazado: 'Rechazado',
    pagado: 'Pagado', pagado_parcial: 'Pagado Parcial'
  }[claim.status] || claim.status;
  const statusColor = {
    en_proceso: '#f59e0b', aprobado: '#10b981', rechazado: '#ef4444',
    pagado: '#3b82f6', pagado_parcial: '#f97316'
  }[claim.status] || '#6b7280';

  const addendums = claim.addendums || [];
  const invoices  = (claim.has_invoice_detail && claim.invoice_details?.length) ? claim.invoice_details : [];
  const invoiceTypeLabel = { examenes: 'Exámenes', medicina: 'Medicina', imagenes: 'Imágenes', honorarios: 'Honorarios', otros: 'Otros' };
  const invTotalClaimed  = invoices.reduce((s, i) => s + (parseFloat(i.amount_claimed) || 0), 0);
  const invTotalPaid     = invoices.reduce((s, i) => s + (parseFloat(i.amount_paid)    || 0), 0);

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Informe de Siniestro ${claim.claim_number}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; color: #1e293b; }
    .wrapper { max-width: 760px; margin: 0 auto; background: #ffffff; }
    /* Header */
    .header { background: linear-gradient(135deg, #001E2E 0%, #004B6F 60%, #0A8FBE 100%); padding: 36px 40px; color: white; }
    .header-top { display: flex; justify-content: space-between; align-items: flex-start; }
    .brand { font-size: 26px; font-weight: 800; letter-spacing: -0.5px; }
    .brand span { color: #76DDF9; }
    .badge { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; padding: 5px 14px; font-size: 12px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; }
    .header-title { margin-top: 22px; }
    .header-title h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
    .header-title p { font-size: 13px; color: rgba(255,255,255,0.7); }
    .status-pill { display: inline-block; background: ${statusColor}; color: white; border-radius: 20px; padding: 4px 14px; font-size: 12px; font-weight: 700; letter-spacing: 0.5px; margin-top: 10px; text-transform: uppercase; }
    /* Sections */
    .content { padding: 32px 40px; }
    .section { margin-bottom: 28px; }
    .section-title { font-size: 11px; font-weight: 700; color: #0A8FBE; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; padding-bottom: 6px; border-bottom: 2px solid #e2e8f0; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
    .field-label { font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px; }
    .field-value { font-size: 14px; color: #1e293b; font-weight: 500; }
    /* Financial summary cards */
    .fin-card { border-radius: 10px; padding: 16px; text-align: center; }
    .fin-card.claimed { background: #f1f5f9; border: 1px solid #e2e8f0; }
    .fin-card.paid    { background: #ecfdf5; border: 1px solid #a7f3d0; }
    .fin-card.diff    { background: ${difference > 0 ? '#fffbeb' : '#f0fdf4'}; border: 1px solid ${difference > 0 ? '#fde68a' : '#bbf7d0'}; }
    .fin-label { font-size: 10px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .fin-value { font-size: 20px; font-weight: 800; }
    .fin-card.claimed .fin-value { color: #334155; }
    .fin-card.paid    .fin-value { color: #059669; }
    .fin-card.diff    .fin-value { color: ${difference > 0 ? '#b45309' : '#16a34a'}; }
    /* Difference note */
    .diff-note { background: #fffbeb; border: 1px solid #fde68a; border-left: 4px solid #f59e0b; border-radius: 8px; padding: 14px 16px; }
    .diff-note-title { font-size: 11px; font-weight: 700; color: #92400e; text-transform: uppercase; margin-bottom: 6px; }
    .diff-note-text { font-size: 13px; color: #78350f; line-height: 1.5; }
    /* Observations */
    .obs-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; font-size: 13px; color: #475569; line-height: 1.6; }
    /* Addendums table */
    .table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .table th { background: #f1f5f9; color: #475569; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 700; padding: 8px 12px; text-align: left; border-bottom: 2px solid #e2e8f0; }
    .table td { padding: 9px 12px; border-bottom: 1px solid #f1f5f9; color: #334155; }
    .table tr:last-child td { border-bottom: none; }
    .addendum-status { display: inline-block; border-radius: 10px; padding: 2px 9px; font-size: 11px; font-weight: 600; }
    /* Footer */
    .footer { background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 20px 40px; text-align: center; }
    .footer p { font-size: 11px; color: #94a3b8; line-height: 1.6; }
    .footer strong { color: #64748b; }
  </style>
</head>
<body>
<div class="wrapper">
  <!-- HEADER -->
  <div class="header">
    <div class="header-top">
      <div class="brand">GA<span>Portal</span></div>
      <div class="badge">Informe de Siniestro</div>
    </div>
    <div class="header-title">
      <h1>Siniestro N.° ${claim.claim_number || '—'}</h1>
      <p>Generado el ${format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
      <div class="status-pill">${statusLabel}</div>
    </div>
  </div>

  <!-- CONTENT -->
  <div class="content">

    <!-- INFORMACIÓN DE LA PÓLIZA -->
    <div class="section">
      <div class="section-title">Información de la Póliza</div>
      <div class="grid-2">
        <div>
          <div class="field-label">Número de Póliza</div>
          <div class="field-value">${claim.policy_number || '—'}</div>
        </div>
        <div>
          <div class="field-label">Asegurado / Cliente</div>
          <div class="field-value">${claim.client_name || '—'}</div>
        </div>
      </div>
    </div>

    <!-- DETALLE DEL SINIESTRO -->
    <div class="section">
      <div class="section-title">Detalle del Siniestro</div>
      <div class="grid-2">
        <div>
          <div class="field-label">Tipo de Siniestro</div>
          <div class="field-value">${claim.claim_type || '—'}</div>
        </div>
        <div>
          <div class="field-label">Fecha del Evento</div>
          <div class="field-value">${fmtDate(claim.event_date)}</div>
        </div>
        <div>
          <div class="field-label">Persona Afectada</div>
          <div class="field-value">${claim.affected_person === 'dependiente' ? 'Dependiente' : claim.affected_person === 'titular' ? 'Titular' : '—'}</div>
        </div>
        ${claim.dependent_name ? `<div>
          <div class="field-label">Nombre del Dependiente</div>
          <div class="field-value">${claim.dependent_name}</div>
        </div>` : ''}
        ${claim.corporate_member_name ? `<div>
          <div class="field-label">Afiliado Corporativo</div>
          <div class="field-value">${claim.corporate_member_name}</div>
        </div>` : ''}
        <div>
          <div class="field-label">Moneda</div>
          <div class="field-value">${claim.currency || 'USD'}</div>
        </div>
      </div>
    </div>

    <!-- RESUMEN FINANCIERO -->
    <div class="section">
      <div class="section-title">Resumen Financiero</div>
      <div class="grid-3">
        <div class="fin-card claimed">
          <div class="fin-label">Total Reclamado</div>
          <div class="fin-value">${claim.currency} ${fmt(totalClaimed)}</div>
        </div>
        <div class="fin-card paid">
          <div class="fin-label">Total Pagado</div>
          <div class="fin-value">${claim.currency} ${fmt(totalPaid)}</div>
        </div>
        <div class="fin-card diff">
          <div class="fin-label">Diferencia</div>
          <div class="fin-value">${claim.currency} ${fmt(difference)}</div>
        </div>
      </div>
      ${claim.payment_date ? `<div style="margin-top:12px;"><div class="field-label">Fecha de Pago</div><div class="field-value">${fmtDate(claim.payment_date)}</div></div>` : ''}
    </div>

    <!-- NOTA DE DIFERENCIA -->
    ${claim.difference_note ? `
    <div class="section">
      <div class="section-title">Nota de Diferencia</div>
      <div class="diff-note">
        <div class="diff-note-title">⚠ Motivo de la diferencia en el pago</div>
        <div class="diff-note-text">${claim.difference_note}</div>
      </div>
    </div>` : ''}

    <!-- OBSERVACIONES -->
    ${claim.observations ? `
    <div class="section">
      <div class="section-title">Observaciones</div>
      <div class="obs-box">${claim.observations}</div>
    </div>` : ''}

    <!-- DETALLE DE FACTURAS -->
    ${invoices.length > 0 ? `
    <div class="section">
      <div class="section-title">Detalle de Facturas (${invoices.length})</div>
      <table class="table">
        <thead>
          <tr>
            <th>N.° Factura</th>
            <th>Fecha</th>
            <th>Tipo</th>
            <th>Descripción</th>
            <th style="text-align:right">Presentado</th>
            <th style="text-align:right">Liquidado</th>
          </tr>
        </thead>
        <tbody>
          ${invoices.map(inv => `<tr>
            <td>${inv.invoice_number || '—'}</td>
            <td>${inv.invoice_date ? format(new Date(inv.invoice_date), 'dd/MM/yyyy') : '—'}</td>
            <td>${invoiceTypeLabel[inv.invoice_type] || inv.invoice_type || '—'}</td>
            <td>${inv.description || '—'}</td>
            <td style="text-align:right;font-weight:600">${claim.currency} ${fmt(inv.amount_claimed)}</td>
            <td style="text-align:right;font-weight:600;color:${parseFloat(inv.amount_paid) > 0 ? '#059669' : '#94a3b8'}">${claim.currency} ${fmt(inv.amount_paid)}</td>
          </tr>`).join('')}
        </tbody>
        <tfoot>
          <tr style="background:#f1f5f9;font-weight:700">
            <td colspan="4" style="padding:9px 12px;text-align:right;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;color:#475569">Total</td>
            <td style="padding:9px 12px;text-align:right">${claim.currency} ${fmt(invTotalClaimed)}</td>
            <td style="padding:9px 12px;text-align:right;color:#059669">${claim.currency} ${fmt(invTotalPaid)}</td>
          </tr>
        </tfoot>
      </table>
    </div>` : ''}

    <!-- ALCANCES -->
    ${addendums.length > 0 ? `
    <div class="section">
      <div class="section-title">Alcances al Siniestro (${addendums.length})</div>
      <table class="table">
        <thead>
          <tr>
            <th>Descripción</th>
            <th>Fecha</th>
            <th>Reclamado</th>
            <th>Pagado</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>
          ${addendums.map(a => {
            const sColor = { pendiente:'#f59e0b', aprobado:'#10b981', rechazado:'#ef4444', pagado:'#3b82f6' }[a.status] || '#6b7280';
            const sLabel = { pendiente:'Pendiente', aprobado:'Aprobado', rechazado:'Rechazado', pagado:'Pagado' }[a.status] || a.status;
            return `<tr>
              <td>${a.description || '—'}</td>
              <td>${a.date ? format(new Date(a.date), 'dd/MM/yyyy') : '—'}</td>
              <td>${claim.currency} ${fmt(a.additional_amount)}</td>
              <td>${claim.currency} ${fmt(a.paid_amount)}</td>
              <td><span class="addendum-status" style="background:${sColor}20;color:${sColor};border:1px solid ${sColor}40">${sLabel}</span></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>` : ''}

  </div>

  <!-- FOOTER -->
  <div class="footer">
    <p><strong>InsurDesk</strong> — Sistema de Gestión de Seguros</p>
    <p>Este documento es un informe generado automáticamente. Fecha de emisión: ${format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
  </div>
</div>
</body>
</html>`;
}

// ── Main component ─────────────────────────────────────────────────────
export default function ClaimReportPanel({ claim }) {
  const [sending, setSending] = useState(null); // 'client' | 'agent' | null
  const [downloading, setDownloading] = useState(false);

  const addendumsClaimed = (claim?.addendums || []).reduce((s, a) => s + (a.additional_amount || 0), 0);
  const addendumsPaid    = (claim?.addendums || []).reduce((s, a) => s + (a.paid_amount || 0), 0);
  const invoicePaid      = claim?.has_invoice_detail
    ? (claim?.invoice_details || []).reduce((s, inv) => s + (parseFloat(inv.amount_paid) || 0), 0)
    : 0;
  const totalClaimed     = (claim?.claimed_amount || 0) + addendumsClaimed;
  const totalPaid        = claim?.has_invoice_detail
    ? invoicePaid + addendumsPaid
    : (claim?.paid_amount || 0) + addendumsPaid;
  const difference       = totalClaimed - totalPaid;

  const html = buildReportHTML(claim, { totalClaimed, totalPaid, difference });

  const handleSend = async (recipientType) => {
    setSending(recipientType);
    try {
      const res = await api.functions.invoke('sendClaimReport', {
        claim_id: claim.id,
        recipient_type: recipientType,
        html_body: html,
      });
      if (res.data?.success) {
        const sentTo = res.data.sent_to;
        const bcc = res.data.bcc;
        const msg = bcc
          ? `Informe enviado a ${sentTo} (con copia a ${bcc})`
          : `Informe enviado a ${sentTo}`;
        toast.success(msg);
      } else {
        throw new Error(res.data?.error || 'Error al enviar');
      }
    } catch (e) {
      toast.error(`Error: ${e.message}`);
    } finally {
      setSending(null);
    }
  };

  const handleDownloadPDF = () => {
    setDownloading(true);
    const win = window.open('', '_blank');
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); setDownloading(false); }, 800);
  };

  return (
    <div className="space-y-5 pt-2">
      {/* Preview card */}
      <div className="bg-muted/40 border border-border rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <FileText className="h-4 w-4 text-brand" />
          <p className="text-sm font-semibold text-foreground/80">Vista previa del informe</p>
        </div>
        <div
          className="rounded border border-border bg-card overflow-hidden"
          style={{ height: 300, overflowY: 'auto', fontSize: 11 }}
          dangerouslySetInnerHTML={{ __html: html }}
        />
      </div>

      {/* Send buttons */}
      <div className="border border-border rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <Mail className="h-4 w-4 text-brand" />
          <p className="text-sm font-semibold text-foreground/80">Enviar informe por correo</p>
        </div>

        <Button
          className="w-full gap-2 bg-brand hover:bg-[#007fa8]"
          onClick={() => handleSend('client')}
          disabled={!!sending}
        >
          {sending === 'client' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
          {sending === 'client' ? 'Enviando...' : 'Enviar al Cliente'}
        </Button>

        <div className="relative flex items-center gap-2">
          <div className="flex-1 border-t border-border" />
          <span className="text-xs text-muted-foreground/70">o</span>
          <div className="flex-1 border-t border-border" />
        </div>

        <Button
          variant="outline"
          className="w-full gap-2 border-brand text-brand hover:bg-brand/5"
          onClick={() => handleSend('agent')}
          disabled={!!sending}
        >
          {sending === 'agent' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
          {sending === 'agent' ? 'Enviando...' : 'Enviar al Agente'}
        </Button>
        <p className="text-xs text-muted-foreground/70 text-center">
          Se enviará al agente de la póliza con copia a su cabeza de estructura (Nivel 2)
        </p>
      </div>

      {/* Download PDF */}
      <div className="border border-border rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Download className="h-4 w-4 text-muted-foreground" />
          <p className="text-sm font-semibold text-foreground/80">Descargar como PDF</p>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          Se abrirá el informe en una nueva ventana. Usa "Guardar como PDF" en el diálogo de impresión.
        </p>
        <Button
          variant="outline"
          className="w-full gap-2"
          onClick={handleDownloadPDF}
          disabled={downloading}
        >
          {downloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
          {downloading ? 'Generando...' : 'Descargar PDF'}
        </Button>
      </div>
    </div>
  );
}