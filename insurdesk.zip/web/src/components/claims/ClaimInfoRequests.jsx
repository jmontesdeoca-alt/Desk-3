import React, { useState, useEffect } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, CheckCircle2, Circle, Mail, Loader2, AlertTriangle, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ClaimInfoRequests({ claim }) {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [sendingId, setSendingId] = useState(null);
  const [autoEmails, setAutoEmails] = useState({ client_email: '', agent_email: '', agent_name: '' });
  const [form, setForm] = useState({
    requested_by: 'Aseguradora',
    request_date: new Date().toISOString().split('T')[0],
    description: '',
    due_date: '',
    notes: '',
  });

  useEffect(() => {
    loadRequests();
    loadEmailsFromPolicy();
  }, [claim.id]);

  const loadEmailsFromPolicy = async () => {
    if (!claim.policy_id) return;
    try {
      const policies = await api.entities.Policy.filter({ id: claim.policy_id });
      const policy = policies[0];
      if (!policy) return;

      const emails = { client_email: '', agent_email: '', agent_name: policy.agent_name || '' };

      // Get client email
      const clientId = policy.client_id || claim.client_id;
      if (clientId) {
        const clients = await api.entities.Client.filter({ id: clientId });
        if (clients[0]?.email) emails.client_email = clients[0].email;
      }

      // Get agent email
      if (policy.agent_id) {
        const agents = await api.entities.Agent.filter({ id: policy.agent_id });
        if (agents[0]?.email) {
          emails.agent_email = agents[0].email;
          emails.agent_name = agents[0].name || policy.agent_name || '';
        }
      }

      setAutoEmails(emails);
    } catch {}
  };

  const loadRequests = async () => {
    setLoading(true);
    const data = await api.entities.AdditionalInfoRequest.filter({ claim_id: claim.id }, '-created_date');
    setRequests(data);
    setLoading(false);
  };

  const handleCreate = async () => {
    if (!form.description.trim()) {
      toast.error('La descripción es requerida');
      return;
    }
    setSaving(true);
    await api.entities.AdditionalInfoRequest.create({
      ...form,
      client_email: autoEmails.client_email,
      agent_email: autoEmails.agent_email,
      agent_name: autoEmails.agent_name,
      claim_id: claim.id,
      claim_number: claim.claim_number,
      policy_number: claim.policy_number,
      client_name: claim.client_name,
      is_fulfilled: false,
    });
    toast.success('Solicitud de información creada');
    setShowForm(false);
    setForm({
      requested_by: 'Aseguradora',
      request_date: new Date().toISOString().split('T')[0],
      description: '',
      due_date: '',
      notes: '',
    });
    setSaving(false);
    await loadRequests();
  };

  const handleToggleFulfilled = async (req) => {
    const newValue = !req.is_fulfilled;
    await api.entities.AdditionalInfoRequest.update(req.id, {
      is_fulfilled: newValue,
      fulfilled_date: newValue ? new Date().toISOString().split('T')[0] : null,
    });
    toast.success(newValue ? 'Marcado como entregado' : 'Marcado como pendiente');
    await loadRequests();
  };

  const handleSendEmail = async (req) => {
    setSendingId(req.id);
    try {
      const res = await api.functions.invoke('sendInfoRequest', { info_request_id: req.id });
      if (res.data?.success) {
        toast.success(`Correo enviado a: ${res.data.sent_to?.join(', ')}`);
      } else {
        toast.error(res.data?.error || 'Error al enviar');
      }
    } catch (e) {
      toast.error(`Error: ${e.message}`);
    }
    setSendingId(null);
  };

  const handleDelete = async (req) => {
    if (!window.confirm('¿Eliminar esta solicitud?')) return;
    await api.entities.AdditionalInfoRequest.delete(req.id);
    toast.success('Solicitud eliminada');
    await loadRequests();
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground/70" /></div>;
  }

  const pending = requests.filter(r => !r.is_fulfilled);
  const fulfilled = requests.filter(r => r.is_fulfilled);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-foreground/80">
            Solicitudes de información adicional
          </span>
          {pending.length > 0 && (
            <span className="bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" /> {pending.length} pendiente{pending.length > 1 ? 's' : ''}
            </span>
          )}
        </div>
        <Button size="sm" variant="outline" onClick={() => setShowForm(!showForm)} className="gap-1.5">
          <Plus className="h-3.5 w-3.5" /> Nueva solicitud
        </Button>
      </div>

      {/* New form */}
      {showForm && (
        <div className="border border-border rounded-lg p-4 bg-muted space-y-3">
          <p className="text-sm font-semibold text-foreground">Nueva solicitud de información</p>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">Solicitado por *</Label>
              <Select value={form.requested_by} onValueChange={v => setForm({...form, requested_by: v})}>
                <SelectTrigger className="h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Aseguradora">Aseguradora</SelectItem>
                  <SelectItem value="InsurDesk">InsurDesk</SelectItem>
                  <SelectItem value="Agente">Agente</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Fecha de solicitud *</Label>
              <Input type="date" value={form.request_date} onChange={e => setForm({...form, request_date: e.target.value})} className="h-8 text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Fecha límite</Label>
              <Input type="date" value={form.due_date} onChange={e => setForm({...form, due_date: e.target.value})} className="h-8 text-sm" />
            </div>
            <div className="space-y-1 col-span-2">
              <Label className="text-xs">Destinatarios (desde la póliza)</Label>
              <div className="bg-card border border-border rounded-md px-3 py-2 text-sm text-muted-foreground flex flex-col gap-1">
                {autoEmails.client_email
                  ? <span>📧 Cliente: <span className="font-medium text-foreground">{autoEmails.client_email}</span></span>
                  : <span className="text-muted-foreground/70 italic">Sin email de cliente en la póliza</span>
                }
                {autoEmails.agent_email
                  ? <span>📋 Agente: <span className="font-medium text-foreground">{autoEmails.agent_email}</span></span>
                  : <span className="text-muted-foreground/70 italic">Sin email de agente en la póliza</span>
                }
              </div>
            </div>
          </div>
          
          <div className="space-y-1">
            <Label className="text-xs">Descripción de la información requerida *</Label>
            <Textarea
              value={form.description}
              onChange={e => setForm({...form, description: e.target.value})}
              placeholder="Detalle qué documentos o información se requieren..."
              rows={3}
              className="text-sm"
            />
          </div>
          
          <div className="space-y-1">
            <Label className="text-xs">Notas adicionales</Label>
            <Input value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} placeholder="Opcional..." className="h-8 text-sm" />
          </div>

          <div className="flex gap-2 pt-1">
            <Button size="sm" onClick={handleCreate} disabled={saving} className="gap-1.5">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
              {saving ? 'Guardando...' : 'Crear solicitud'}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setShowForm(false)}>Cancelar</Button>
          </div>
        </div>
      )}

      {/* Pending requests */}
      {pending.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wide">Pendientes ({pending.length})</p>
          {pending.map(req => (
            <RequestCard
              key={req.id}
              req={req}
              onToggle={handleToggleFulfilled}
              onSendEmail={handleSendEmail}
              onDelete={handleDelete}
              sendingId={sendingId}
            />
          ))}
        </div>
      )}

      {/* Fulfilled requests */}
      {fulfilled.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wide">Entregadas ({fulfilled.length})</p>
          {fulfilled.map(req => (
            <RequestCard
              key={req.id}
              req={req}
              onToggle={handleToggleFulfilled}
              onSendEmail={handleSendEmail}
              onDelete={handleDelete}
              sendingId={sendingId}
            />
          ))}
        </div>
      )}

      {requests.length === 0 && !showForm && (
        <div className="text-center py-8 text-muted-foreground/70">
          <AlertTriangle className="h-8 w-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">No hay solicitudes de información para este siniestro</p>
        </div>
      )}
    </div>
  );
}

function RequestCard({ req, onToggle, onSendEmail, onDelete, sendingId }) {
  return (
    <div className={`border rounded-lg p-3 ${req.is_fulfilled ? 'bg-emerald-500/10 border-emerald-500/30 opacity-75' : 'bg-card border-amber-500/30'}`}>
      <div className="flex items-start gap-3">
        <button
          onClick={() => onToggle(req)}
          className="mt-0.5 shrink-0"
          title={req.is_fulfilled ? 'Marcar como pendiente' : 'Marcar como entregado'}
        >
          {req.is_fulfilled
            ? <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            : <Circle className="h-5 w-5 text-amber-400" />
          }
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span className="text-xs font-semibold text-muted-foreground">{req.requested_by}</span>
            <span className="text-xs text-muted-foreground/70">{req.request_date}</span>
            {req.due_date && (
              <span className={`text-xs font-semibold px-1.5 py-0.5 rounded ${req.is_fulfilled ? 'text-muted-foreground/70' : 'text-red-600 dark:text-red-400 bg-red-500/10'}`}>
                Límite: {req.due_date}
              </span>
            )}
            {req.is_fulfilled && req.fulfilled_date && (
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">✓ Entregado: {req.fulfilled_date}</span>
            )}
          </div>
          <p className="text-sm text-foreground/80 leading-relaxed">{req.description}</p>
          {req.notes && <p className="text-xs text-muted-foreground/70 mt-1">{req.notes}</p>}
          {(req.client_email || req.agent_email) && (
            <p className="text-xs text-muted-foreground/70 mt-1">
              📧 {[req.client_email, req.agent_email].filter(Boolean).join(' | cc: ')}
            </p>
          )}
        </div>
        <div className="flex gap-1 shrink-0">
          {!req.is_fulfilled && (req.client_email || req.agent_email) && (
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-foreground hover:bg-muted"
              onClick={() => onSendEmail(req)}
              disabled={sendingId === req.id}
              title="Enviar correo de notificación"
            >
              {sendingId === req.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Mail className="h-3.5 w-3.5" />}
            </Button>
          )}
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 text-red-400 hover:bg-red-500/10"
            onClick={() => onDelete(req)}
            title="Eliminar solicitud"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}