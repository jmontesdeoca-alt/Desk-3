import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';
import { format } from 'date-fns';

const statusColors = {
  pendiente: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
  aprobado:  'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
  rechazado: 'bg-red-500/10 text-red-600 dark:text-red-400',
  pagado:    'bg-purple-500/10 text-purple-600 dark:text-purple-400',
};

export default function ClaimAddendums({ addendums = [], currency = 'USD', onAdd, onUpdate, canEdit }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ description: '', additional_amount: '', date: new Date().toISOString().split('T')[0] });
  const [editingIdx, setEditingIdx] = useState(null);
  const [editData, setEditData] = useState({});

  const handleAdd = () => {
    if (!form.description || !form.additional_amount) return;
    onAdd({
      id: crypto.randomUUID(),
      date: form.date,
      description: form.description,
      additional_amount: parseFloat(form.additional_amount),
      paid_amount: 0,
      status: 'pendiente',
      rejection_note: '',
    });
    setForm({ description: '', additional_amount: '', date: new Date().toISOString().split('T')[0] });
    setShowForm(false);
  };

  const handleSaveEdit = (idx) => {
    onUpdate(idx, editData);
    setEditingIdx(null);
    setEditData({});
  };

  return (
    <div className="space-y-4">
      {addendums.length === 0 && !showForm && (
        <p className="text-sm text-muted-foreground/70 text-center py-4">Sin alcances registrados.</p>
      )}

      {addendums.map((a, idx) => (
        <div key={a.id || idx} className="border border-border rounded-lg p-4 space-y-2">
          {editingIdx === idx ? (
            <div className="space-y-3">
              <div>
                <Label>Descripción</Label>
                <Textarea value={editData.description} onChange={e => setEditData({...editData, description: e.target.value})} rows={2} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Monto reclamado</Label>
                  <Input type="number" value={editData.additional_amount} onChange={e => setEditData({...editData, additional_amount: parseFloat(e.target.value)})} />
                </div>
                <div>
                  <Label>Monto pagado</Label>
                  <Input type="number" value={editData.paid_amount || ''} onChange={e => setEditData({...editData, paid_amount: parseFloat(e.target.value)})} />
                </div>
              </div>
              <div>
                <Label>Estado</Label>
                <Select value={editData.status} onValueChange={v => setEditData({...editData, status: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pendiente">Pendiente</SelectItem>
                    <SelectItem value="aprobado">Aprobado</SelectItem>
                    <SelectItem value="rechazado">Rechazado</SelectItem>
                    <SelectItem value="pagado">Pagado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {(editData.status === 'rechazado' || (editData.paid_amount < editData.additional_amount)) && (
                <div>
                  <Label>Nota de rechazo / diferencia</Label>
                  <Textarea value={editData.rejection_note || ''} onChange={e => setEditData({...editData, rejection_note: e.target.value})} rows={2} />
                </div>
              )}
              <div className="flex gap-2">
                <Button size="sm" onClick={() => handleSaveEdit(idx)}>Guardar</Button>
                <Button size="sm" variant="ghost" onClick={() => setEditingIdx(null)}>Cancelar</Button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{a.description}</p>
                  <p className="text-xs text-muted-foreground/70">{a.date ? format(new Date(a.date), 'dd/MM/yyyy') : '-'}</p>
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${statusColors[a.status] || 'bg-muted text-muted-foreground'}`}>
                  {a.status}
                </span>
              </div>
              <div className="flex gap-4 text-sm">
                <span className="text-muted-foreground">Reclamado: <strong>{currency} {a.additional_amount?.toLocaleString()}</strong></span>
                {a.paid_amount != null && a.paid_amount > 0 && (
                  <span className="text-emerald-600 dark:text-emerald-400">Pagado: <strong>{currency} {a.paid_amount?.toLocaleString()}</strong></span>
                )}
              </div>
              {a.rejection_note && (
                <p className="text-xs text-muted-foreground bg-muted/40 rounded p-2">{a.rejection_note}</p>
              )}
              {canEdit && (
                <Button size="sm" variant="outline" onClick={() => { setEditingIdx(idx); setEditData({...a}); }}>
                  Editar
                </Button>
              )}
            </>
          )}
        </div>
      ))}

      {canEdit && (
        showForm ? (
          <div className="border border-dashed border-input rounded-lg p-4 space-y-3">
            <p className="text-sm font-medium text-foreground/80">Nuevo Alcance</p>
            <div>
              <Label>Fecha</Label>
              <Input type="date" value={form.date} onChange={e => setForm({...form, date: e.target.value})} />
            </div>
            <div>
              <Label>Descripción / Justificación</Label>
              <Textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} rows={2} placeholder="Describe el gasto adicional o información complementaria..." />
            </div>
            <div>
              <Label>Monto adicional reclamado ({currency})</Label>
              <Input type="number" value={form.additional_amount} onChange={e => setForm({...form, additional_amount: e.target.value})} placeholder="0.00" />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={handleAdd}>Agregar Alcance</Button>
              <Button size="sm" variant="ghost" onClick={() => setShowForm(false)}>Cancelar</Button>
            </div>
          </div>
        ) : (
          <Button variant="outline" size="sm" className="w-full gap-2" onClick={() => setShowForm(true)}>
            <Plus className="h-4 w-4" /> Agregar Alcance
          </Button>
        )
      )}
    </div>
  );
}