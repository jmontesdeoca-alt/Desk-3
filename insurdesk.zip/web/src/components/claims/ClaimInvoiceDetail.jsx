import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Receipt } from 'lucide-react';

const INVOICE_TYPES = {
  examenes: 'Exámenes',
  medicina: 'Medicina',
  imagenes: 'Imágenes',
  honorarios: 'Honorarios',
  otros: 'Otros'
};

const emptyInvoice = () => ({
  id: Date.now().toString(),
  invoice_number: '',
  invoice_date: '',
  invoice_type: '',
  description: '',
  amount_claimed: '',
  amount_paid: '',
  notes: ''
});

export default function ClaimInvoiceDetail({ invoices = [], onChange, currency = 'USD', readOnly = false, canLiquidate = false }) {
  const [expandedIdx, setExpandedIdx] = useState(null);

  const addInvoice = () => {
    const updated = [...invoices, emptyInvoice()];
    onChange(updated);
    setExpandedIdx(updated.length - 1);
  };

  const removeInvoice = (idx) => {
    const updated = invoices.filter((_, i) => i !== idx);
    onChange(updated);
    if (expandedIdx === idx) setExpandedIdx(null);
  };

  const updateInvoice = (idx, field, value) => {
    const updated = invoices.map((inv, i) => i === idx ? { ...inv, [field]: value } : inv);
    onChange(updated);
  };

  const totalClaimed = invoices.reduce((s, inv) => s + (parseFloat(inv.amount_claimed) || 0), 0);
  const totalPaid = invoices.reduce((s, inv) => s + (parseFloat(inv.amount_paid) || 0), 0);

  return (
    <div className="space-y-3">
      {/* Totals summary */}
      {invoices.length > 0 && (
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted/40 rounded-lg p-3 text-center">
            <p className="text-xs text-muted-foreground">Total Reclamado</p>
            <p className="text-base font-bold text-foreground">{currency} {totalClaimed.toLocaleString('es', { minimumFractionDigits: 2 })}</p>
          </div>
          <div className="bg-emerald-500/10 rounded-lg p-3 text-center">
            <p className="text-xs text-muted-foreground">Total Liquidado</p>
            <p className="text-base font-bold text-emerald-600 dark:text-emerald-400">{currency} {totalPaid.toLocaleString('es', { minimumFractionDigits: 2 })}</p>
          </div>
        </div>
      )}

      {/* Invoice list */}
      <div className="space-y-2">
        {invoices.map((inv, idx) => (
          <div key={inv.id || idx} className="border rounded-lg overflow-hidden">
            {/* Header row */}
            <div
              className="flex items-center justify-between px-3 py-2 bg-muted/40 cursor-pointer hover:bg-muted"
              onClick={() => setExpandedIdx(expandedIdx === idx ? null : idx)}
            >
              <div className="flex items-center gap-2 text-sm">
                <Receipt className="h-4 w-4 text-muted-foreground/70" />
                <span className="font-medium text-foreground/80">
                  {inv.invoice_number || `Factura ${idx + 1}`}
                </span>
                {inv.invoice_type && (
                  <span className="text-xs bg-muted text-foreground px-2 py-0.5 rounded-full">
                    {INVOICE_TYPES[inv.invoice_type]}
                  </span>
                )}
                {inv.amount_claimed && (
                  <span className="text-xs text-muted-foreground ml-2">
                    {currency} {parseFloat(inv.amount_claimed).toLocaleString('es', { minimumFractionDigits: 2 })}
                  </span>
                )}
              </div>
              {!readOnly && (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-red-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-500/10"
                  onClick={(e) => { e.stopPropagation(); removeInvoice(idx); }}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>

            {/* Expanded detail */}
            {expandedIdx === idx && (
              <div className="p-3 space-y-3 border-t">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">N° Factura</Label>
                    <Input
                      value={inv.invoice_number}
                      onChange={e => updateInvoice(idx, 'invoice_number', e.target.value)}
                      placeholder="Ej: FAC-001"
                      disabled={readOnly}
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Fecha de Factura</Label>
                    <Input
                      type="date"
                      value={inv.invoice_date}
                      onChange={e => updateInvoice(idx, 'invoice_date', e.target.value)}
                      disabled={readOnly}
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Tipo de Gasto *</Label>
                    <Select
                      value={inv.invoice_type}
                      onValueChange={v => updateInvoice(idx, 'invoice_type', v)}
                      disabled={readOnly}
                    >
                      <SelectTrigger className="h-8 text-sm">
                        <SelectValue placeholder="Seleccionar" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(INVOICE_TYPES).map(([val, label]) => (
                          <SelectItem key={val} value={val}>{label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Monto Reclamado ({currency}) *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={inv.amount_claimed}
                      onChange={e => updateInvoice(idx, 'amount_claimed', e.target.value)}
                      disabled={readOnly}
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Monto Liquidado ({currency})</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={inv.amount_paid}
                      onChange={e => updateInvoice(idx, 'amount_paid', e.target.value)}
                      disabled={readOnly && !canLiquidate}
                      placeholder="0.00 — se completa al liquidar"
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Descripción</Label>
                    <Input
                      value={inv.description}
                      onChange={e => updateInvoice(idx, 'description', e.target.value)}
                      disabled={readOnly}
                      placeholder="Descripción del gasto"
                      className="h-8 text-sm"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Notas</Label>
                  <Textarea
                    value={inv.notes}
                    onChange={e => updateInvoice(idx, 'notes', e.target.value)}
                    disabled={readOnly}
                    rows={2}
                    placeholder="Notas adicionales sobre esta factura..."
                    className="text-sm"
                  />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {!readOnly && (
        <Button type="button" variant="outline" size="sm" onClick={addInvoice} className="w-full gap-2">
          <Plus className="h-4 w-4" /> Agregar Factura
        </Button>
      )}

      {invoices.length === 0 && readOnly && (
        <p className="text-sm text-muted-foreground/70 text-center py-4">No hay facturas registradas</p>
      )}
    </div>
  );
}