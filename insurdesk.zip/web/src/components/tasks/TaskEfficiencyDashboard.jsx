import React, { useMemo, useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Legend
} from 'recharts';
import { AlertTriangle, CheckCircle2, Timer, TrendingUp, Users, Gauge, Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { isPast, parseISO, differenceInHours, differenceInCalendarDays, subMonths, subDays } from 'date-fns';

const hoursToReadable = (hours) => {
  if (hours == null || isNaN(hours)) return '—';
  if (hours < 1) return `${Math.round(hours * 60)} min`;
  if (hours < 24) return `${hours.toFixed(1)} h`;
  const days = hours / 24;
  return `${days.toFixed(1)} d`;
};

const getStatusColor = (pct) => {
  if (pct >= 80) return 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
  if (pct >= 50) return 'text-amber-600 dark:text-amber-400 bg-amber-500/10 border-amber-500/30';
  return 'text-red-600 dark:text-red-400 bg-red-500/10 border-red-500/30';
};

// Score a task vs its deadline (by calendar day).
// 3 = before deadline, 2 = on deadline, 1 = after deadline, 0 = not completed
const scoreTask = (t) => {
  if (!t.completed_at) return { score: 0, bucket: 'noCumplida' };
  if (!t.due_date) return { score: 3, bucket: 'antes' };
  try {
    const diff = differenceInCalendarDays(parseISO(t.completed_at), parseISO(t.due_date));
    if (diff < 0) return { score: 3, bucket: 'antes' };
    if (diff === 0) return { score: 2, bucket: 'en' };
    return { score: 1, bucket: 'fuera' };
  } catch {
    return { score: 3, bucket: 'antes' };
  }
};

export default function TaskEfficiencyDashboard({ tasks, users }) {
  const [sortBy, setSortBy] = useState('resolution');
  const [period, setPeriod] = useState('all');

  // Filter tasks by creation date based on selected period
  const filteredTasks = useMemo(() => {
    if (period === 'all') return tasks;
    const now = new Date();
    let cutoff;
    if (period === 'month') cutoff = subMonths(now, 1);
    else if (period === 'quarter') cutoff = subMonths(now, 3);
    else if (period === 'year') cutoff = subDays(subMonths(now, 12), 0);
    else cutoff = null;
    if (!cutoff) return tasks;
    return tasks.filter(t => {
      if (!t.created_date) return false;
      try { return parseISO(t.created_date) >= cutoff; } catch { return false; }
    });
  }, [tasks, period]);

  // Build per-user metrics
  const userMetrics = useMemo(() => {
    const byUser = {};
    filteredTasks.forEach(t => {
      const uid = t.assigned_to_user_id;
      if (!uid) return;
      if (!byUser[uid]) {
        const u = users.find(x => x.id === uid);
        byUser[uid] = {
          userId: uid,
          name: t.assigned_to_user_name || u?.full_name || 'Sin nombre',
          email: u?.email || '',
          total: 0,
          pendiente: 0,
          en_proceso: 0,
          finalizado: 0,
          vencidas: 0,
          actionTimes: [],
          resolutionTimes: [],
          onTime: 0,
          lateCompleted: 0,
          scoreSum: 0,
          scoreAntes: 0,
          scoreEn: 0,
          scoreFuera: 0,
          scoreNoCumplida: 0,
        };
      }
      const m = byUser[uid];
      m.total++;

      // Deadline-based scoring
      const s = scoreTask(t);
      m.scoreSum += s.score;
      if (s.bucket === 'antes') m.scoreAntes++;
      else if (s.bucket === 'en') m.scoreEn++;
      else if (s.bucket === 'fuera') m.scoreFuera++;
      else m.scoreNoCumplida++;

      if (t.status === 'pendiente') m.pendiente++;
      if (t.status === 'en_proceso') m.en_proceso++;
      if (t.status === 'finalizado' || t.status === 'completada') m.finalizado++;

      // Overdue: not finished and due_date passed
      if ((t.status === 'pendiente' || t.status === 'en_proceso') && t.due_date) {
        try {
          if (isPast(parseISO(t.due_date))) m.vencidas++;
        } catch {}
      }

      // Time to action: started_at - created_date
      if (t.started_at && t.created_date) {
        try {
          const h = differenceInHours(parseISO(t.started_at), parseISO(t.created_date));
          if (h >= 0) m.actionTimes.push(h);
        } catch {}
      }

      // Resolution time: completed_at - created_date
      if (t.completed_at && t.created_date) {
        try {
          const h = differenceInHours(parseISO(t.completed_at), parseISO(t.created_date));
          if (h >= 0) m.resolutionTimes.push(h);
        } catch {}
        // On-time check
        if (t.due_date) {
          try {
            if (parseISO(t.completed_at) <= parseISO(t.due_date)) m.onTime++;
            else m.lateCompleted++;
          } catch {}
        } else {
          m.onTime++;
        }
      }
    });

    return Object.values(byUser).map(m => {
      const avgAction = m.actionTimes.length
        ? m.actionTimes.reduce((a, b) => a + b, 0) / m.actionTimes.length
        : null;
      const avgResolution = m.resolutionTimes.length
        ? m.resolutionTimes.reduce((a, b) => a + b, 0) / m.resolutionTimes.length
        : null;
      const completedWithDue = m.onTime + m.lateCompleted;
      const onTimePct = completedWithDue > 0 ? (m.onTime / completedWithDue) * 100 : null;
      const maxScore = m.total * 3;
      const efficiencyPct = maxScore > 0 ? (m.scoreSum / maxScore) * 100 : null;
      return {
        ...m,
        avgAction,
        avgResolution,
        onTimePct,
        efficiencyPct,
      };
    });
  }, [filteredTasks, users]);

  // Global KPIs
  const kpis = useMemo(() => {
    const total = filteredTasks.length;
    const overdue = filteredTasks.filter(t =>
      (t.status === 'pendiente' || t.status === 'en_proceso') &&
      t.due_date &&
      (() => { try { return isPast(parseISO(t.due_date)); } catch { return false; } })()
    ).length;
    const allActionTimes = [];
    const allResolutionTimes = [];
    let onTime = 0;
    let lateCompleted = 0;
    filteredTasks.forEach(t => {
      if (t.started_at && t.created_date) {
        try {
          const h = differenceInHours(parseISO(t.started_at), parseISO(t.created_date));
          if (h >= 0) allActionTimes.push(h);
        } catch {}
      }
      if (t.completed_at && t.created_date) {
        try {
          const h = differenceInHours(parseISO(t.completed_at), parseISO(t.created_date));
          if (h >= 0) allResolutionTimes.push(h);
        } catch {}
        if (t.due_date) {
          try {
            if (parseISO(t.completed_at) <= parseISO(t.due_date)) onTime++;
            else lateCompleted++;
          } catch {}
        } else {
          onTime++;
        }
      }
    });
    const avgAction = allActionTimes.length
      ? allActionTimes.reduce((a, b) => a + b, 0) / allActionTimes.length
      : null;
    const avgResolution = allResolutionTimes.length
      ? allResolutionTimes.reduce((a, b) => a + b, 0) / allResolutionTimes.length
      : null;
    const completedTotal = onTime + lateCompleted;
    const onTimePct = completedTotal > 0 ? (onTime / completedTotal) * 100 : null;
    let totalScore = 0;
    filteredTasks.forEach(t => { totalScore += scoreTask(t).score; });
    const maxScore = filteredTasks.length * 3;
    const efficiencyPct = maxScore > 0 ? (totalScore / maxScore) * 100 : null;
    return { total, overdue, avgAction, avgResolution, onTimePct, completedTotal, efficiencyPct };
  }, [filteredTasks]);

  // Chart data
  const chartData = useMemo(() => {
    let arr = [...userMetrics];
    if (sortBy === 'resolution') {
      arr.sort((a, b) => (b.avgResolution ?? -1) - (a.avgResolution ?? -1));
    } else if (sortBy === 'action') {
      arr.sort((a, b) => (b.avgAction ?? -1) - (a.avgAction ?? -1));
    } else if (sortBy === 'vencidas') {
      arr.sort((a, b) => b.vencidas - a.vencidas);
    } else if (sortBy === 'ontime') {
      arr.sort((a, b) => (b.onTimePct ?? -1) - (a.onTimePct ?? -1));
    }
    return arr.map(m => ({
      name: m.name.length > 15 ? m.name.substring(0, 13) + '…' : m.name,
      'Toma de acción (h)': m.avgAction != null ? Math.round(m.avgAction * 10) / 10 : 0,
      'Resolución (h)': m.avgResolution != null ? Math.round(m.avgResolution * 10) / 10 : 0,
    }));
  }, [userMetrics, sortBy]);

  const handleExport = () => {
    const rows = userMetrics.map(m => ({
      'Ejecutivo': m.name,
      'Email': m.email,
      'Total asignadas': m.total,
      'Pendientes': m.pendiente,
      'En proceso': m.en_proceso,
      'Finalizadas': m.finalizado,
      'Vencidas': m.vencidas,
      'Tiempo prom. toma acción (h)': m.avgAction != null ? m.avgAction.toFixed(1) : '',
      'Tiempo prom. resolución (h)': m.avgResolution != null ? m.avgResolution.toFixed(1) : '',
      '% A tiempo': m.onTimePct != null ? m.onTimePct.toFixed(0) + '%' : '',
      'Eficiencia plazo': m.efficiencyPct != null ? m.efficiencyPct.toFixed(0) + '%' : '',
      'Antes del plazo': m.scoreAntes,
      'En el plazo': m.scoreEn,
      'Fuera del plazo': m.scoreFuera,
      'No cumplida': m.scoreNoCumplida,
    }));
    const headers = Object.keys(rows[0] || {});
    const csv = [
      headers.join(','),
      ...rows.map(r => headers.map(h => `"${r[h] ?? ''}"`).join(','))
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cumplimiento_tareas_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const kpiCards = [
    {
      label: 'Tareas vencidas',
      value: kpis.overdue,
      icon: AlertTriangle,
      color: 'text-red-600 dark:text-red-400',
      bg: 'bg-red-500/10',
      border: 'border-red-500/30',
    },
    {
      label: 'Tiempo prom. toma de acción',
      value: hoursToReadable(kpis.avgAction),
      icon: Gauge,
      color: 'text-foreground',
      bg: 'bg-muted',
      border: 'border-border',
    },
    {
      label: 'Tiempo prom. de resolución',
      value: hoursToReadable(kpis.avgResolution),
      icon: Timer,
      color: 'text-foreground',
      bg: 'bg-indigo-500/10',
      border: 'border-indigo-500/30',
    },
    {
      label: '% Cumplimiento a tiempo',
      value: kpis.onTimePct != null ? `${kpis.onTimePct.toFixed(0)}%` : '—',
      icon: CheckCircle2,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30',
    },
    {
      label: 'Eficiencia vs plazo',
      value: kpis.efficiencyPct != null ? `${kpis.efficiencyPct.toFixed(0)}%` : '—',
      icon: Gauge,
      color: 'text-violet-600 dark:text-violet-400',
      bg: 'bg-violet-500/10',
      border: 'border-violet-500/30',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Period filter */}
      <div className="flex items-center justify-end gap-2">
        <label className="text-xs text-muted-foreground">Período (por fecha de creación):</label>
        <select
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="text-xs border border-border rounded-md px-2 py-1.5 bg-card"
        >
          <option value="all">Total</option>
          <option value="year">Último año</option>
          <option value="quarter">Último trimestre</option>
          <option value="month">Último mes</option>
        </select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {kpiCards.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className={`rounded-xl border p-4 ${kpi.border} ${kpi.bg}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-1">{kpi.label}</p>
                  <p className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</p>
                </div>
                <Icon className={`h-8 w-8 ${kpi.color} opacity-80`} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Chart */}
      <div className="bg-card rounded-xl border border-border p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground/80 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              Comparativa por ejecutivo
            </h3>
            <p className="text-xs text-muted-foreground/70 mt-0.5">Tiempos promedio en horas</p>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-xs text-muted-foreground">Ordenar por:</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-xs border border-border rounded-md px-2 py-1 bg-card"
            >
              <option value="resolution">Tiempo de resolución</option>
              <option value="action">Tiempo de toma de acción</option>
              <option value="vencidas">Tareas vencidas</option>
              <option value="ontime">% A tiempo</option>
            </select>
          </div>
        </div>
        {chartData.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground/70 text-sm">Sin datos suficientes para el gráfico</div>
        ) : (
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-20} textAnchor="end" height={70} interval={0} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip
                contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', fontSize: '12px' }}
                formatter={(v) => [`${v} h`, '']}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Bar dataKey="Toma de acción (h)" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Resolución (h)" fill="#6366f1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Detailed Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h3 className="text-sm font-semibold text-foreground/80 flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            Eficiencia por ejecutivo
          </h3>
          <Button size="sm" variant="outline" onClick={handleExport} className="gap-1.5">
            <Download className="h-3.5 w-3.5" />
            Exportar
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40 text-muted-foreground text-xs uppercase tracking-wide">
                <th className="text-left px-4 py-3 font-medium">Ejecutivo</th>
                <th className="text-center px-3 py-3 font-medium">Asignadas</th>
                <th className="text-center px-3 py-3 font-medium">Pend.</th>
                <th className="text-center px-3 py-3 font-medium">En proc.</th>
                <th className="text-center px-3 py-3 font-medium">Final.</th>
                <th className="text-center px-3 py-3 font-medium">Vencidas</th>
                <th className="text-center px-3 py-3 font-medium">Toma acción</th>
                <th className="text-center px-3 py-3 font-medium">Resolución</th>
                <th className="text-center px-3 py-3 font-medium">% A tiempo</th>
                <th className="text-center px-3 py-3 font-medium">Eficiencia plazo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {userMetrics.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-10 text-muted-foreground/70">Sin datos</td>
                </tr>
              ) : (
                userMetrics.map(m => (
                  <tr key={m.userId} className="hover:bg-muted/40">
                    <td className="px-4 py-3">
                      <div className="font-medium text-foreground">{m.name}</div>
                      {m.email && <div className="text-xs text-muted-foreground/70">{m.email}</div>}
                    </td>
                    <td className="text-center px-3 py-3 text-foreground/80">{m.total}</td>
                    <td className="text-center px-3 py-3">
                      <span className="text-amber-600 dark:text-amber-400 font-medium">{m.pendiente}</span>
                    </td>
                    <td className="text-center px-3 py-3">
                      <span className="text-foreground font-medium">{m.en_proceso}</span>
                    </td>
                    <td className="text-center px-3 py-3">
                      <span className="text-emerald-600 dark:text-emerald-400 font-medium">{m.finalizado}</span>
                    </td>
                    <td className="text-center px-3 py-3">
                      {m.vencidas > 0 ? (
                        <span className="inline-flex items-center justify-center min-w-[28px] px-1.5 py-0.5 rounded-full text-xs font-semibold text-red-600 dark:text-red-400 bg-red-500/10">
                          {m.vencidas}
                        </span>
                      ) : (
                        <span className="text-slate-300">0</span>
                      )}
                    </td>
                    <td className="text-center px-3 py-3 text-foreground/80">{hoursToReadable(m.avgAction)}</td>
                    <td className="text-center px-3 py-3 text-foreground/80">{hoursToReadable(m.avgResolution)}</td>
                    <td className="text-center px-3 py-3">
                      {m.onTimePct != null ? (
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${getStatusColor(m.onTimePct)}`}>
                          {m.onTimePct.toFixed(0)}%
                        </span>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                    <td className="text-center px-3 py-3">
                      {m.efficiencyPct != null ? (
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${getStatusColor(m.efficiencyPct)}`}>
                          {m.efficiencyPct.toFixed(0)}%
                        </span>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}