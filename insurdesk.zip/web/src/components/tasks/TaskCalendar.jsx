import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, addMonths, subMonths, isPast } from 'date-fns';
import { es } from 'date-fns/locale';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export default function TaskCalendar({ tasks = [], onTaskClick }) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { locale: es });
  const endDate = endOfWeek(monthEnd, { locale: es });

  const rows = [];
  let days = [];
  let day = startDate;

  while (day <= endDate) {
    for (let i = 0; i < 7; i++) {
      days.push(day);
      day = addDays(day, 1);
    }
    rows.push(days);
    days = [];
  }

  const getTasksForDay = (date) => {
    return tasks.filter(task => {
      if (!task.due_date) return false;
      return isSameDay(new Date(task.due_date), date);
    });
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'alta': return 'bg-red-500';
      case 'media': return 'bg-amber-500';
      case 'baja': return 'bg-emerald-500';
      default: return 'bg-muted-foreground';
    }
  };

  const renderDay = (day) => {
    const dayTasks = getTasksForDay(day);
    const isCurrentMonth = isSameMonth(day, currentDate);
    const isToday = isSameDay(day, new Date());
    const isPastDay = isPast(day) && !isToday;

    if (dayTasks.length === 0) {
      return (
        <div
          key={day.toString()}
          className={`min-h-24 p-2 border border-border ${
            !isCurrentMonth ? 'bg-muted/40' : 'bg-card'
          } ${isToday ? 'ring-2 ring-ring' : ''}`}
        >
          <div className={`text-sm font-medium mb-1 ${
            !isCurrentMonth ? 'text-muted-foreground/70' : 
            isToday ? 'text-foreground font-bold' : 
            'text-foreground/80'
          }`}>
            {format(day, 'd')}
          </div>
        </div>
      );
    }

    return (
      <Popover key={day.toString()}>
        <PopoverTrigger asChild>
          <div
            className={`min-h-24 p-2 border border-border cursor-pointer hover:bg-muted/40 ${
              !isCurrentMonth ? 'bg-muted/40' : 'bg-card'
            } ${isToday ? 'ring-2 ring-ring' : ''}`}
          >
            <div className={`text-sm font-medium mb-1 ${
              !isCurrentMonth ? 'text-muted-foreground/70' : 
              isToday ? 'text-foreground font-bold' : 
              'text-foreground/80'
            }`}>
              {format(day, 'd')}
            </div>
            <div className="space-y-1">
              {dayTasks.slice(0, 3).map((task, idx) => (
                <div
                  key={idx}
                  className={`text-xs px-1.5 py-0.5 rounded truncate ${
                    task.status === 'completada' || task.status === 'finalizado'
                      ? 'bg-muted text-muted-foreground line-through'
                      : `${getPriorityColor(task.priority)} text-white`
                  }`}
                >
                  {task.title}
                </div>
              ))}
              {dayTasks.length > 3 && (
                <div className="text-xs text-muted-foreground text-center">
                  +{dayTasks.length - 3} más
                </div>
              )}
            </div>
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="start">
          <div className="space-y-2">
            <div className="font-semibold text-sm border-b pb-2">
              {format(day, "d 'de' MMMM, yyyy", { locale: es })}
            </div>
            {dayTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => onTaskClick?.(task)}
                className="p-2 hover:bg-muted/40 rounded cursor-pointer border border-border"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className={`font-medium text-sm ${
                      task.status === 'completada' || task.status === 'finalizado' ? 'line-through text-muted-foreground' : 'text-foreground'
                    }`}>
                      {task.title}
                    </div>
                    {task.description && (
                      <div className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {task.description}
                      </div>
                    )}
                  </div>
                  <Badge className={`${getPriorityColor(task.priority)} text-white text-xs`}>
                    {task.priority}
                  </Badge>
                </div>
                {(task.status === 'pendiente' || task.status === 'en_proceso') && isPastDay && (
                  <div className="text-xs text-red-600 dark:text-red-400 font-semibold mt-1">
                    ⚠️ Vencida
                  </div>
                )}
              </div>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    );
  };

  return (
    <div className="bg-card rounded-xl border border-border p-4">
      {/* Header with navigation */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">
          {format(currentDate, "MMMM yyyy", { locale: es }).charAt(0).toUpperCase() + 
           format(currentDate, "MMMM yyyy", { locale: es }).slice(1)}
        </h3>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentDate(subMonths(currentDate, 1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentDate(new Date())}
          >
            Hoy
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentDate(addMonths(currentDate, 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 mb-3 text-xs">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-red-500"></div>
          <span>Alta</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-amber-500"></div>
          <span>Media</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-emerald-500"></div>
          <span>Baja</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded bg-muted border"></div>
          <span>Finalizada</span>
        </div>
      </div>

      {/* Calendar grid */}
      <div className="overflow-x-auto">
        <div className="min-w-[700px]">
          {/* Day headers */}
          <div className="grid grid-cols-7 gap-0 mb-2">
            {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map((day) => (
              <div key={day} className="text-center text-sm font-semibold text-muted-foreground py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar days */}
          {rows.map((week, idx) => (
            <div key={idx} className="grid grid-cols-7 gap-0">
              {week.map((day) => renderDay(day))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}