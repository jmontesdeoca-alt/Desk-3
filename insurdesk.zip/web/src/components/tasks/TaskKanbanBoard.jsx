import React from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Clock, AlertTriangle, FileText, Users, GripVertical } from 'lucide-react';
import { format, differenceInDays, differenceInHours, isPast, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { formatTaskCode } from './taskCode';

const COLUMNS = [
  { id: 'pendiente', title: 'Pendientes', dot: 'bg-muted-foreground/50', headerBg: 'bg-muted/40', countBg: 'bg-secondary text-foreground/80' },
  { id: 'en_proceso', title: 'En Proceso', dot: 'bg-primary', headerBg: 'bg-muted', countBg: 'bg-blue-200 text-foreground' },
  { id: 'finalizado', title: 'Finalizado', dot: 'bg-emerald-500', headerBg: 'bg-emerald-500/10', countBg: 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' }
];

const PRIORITY_STYLES = {
  alta: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30',
  media: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
  baja: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
};
const PRIORITY_LABELS = { alta: '🔴 Alta', media: '🟡 Media', baja: '🟢 Baja' };

const normalizeStatus = (status) => {
  if (status === 'completada') return 'finalizado';
  return status || 'pendiente';
};

const getTimeRemaining = (dueDate) => {
  if (!dueDate) return { text: 'Sin fecha', className: 'text-muted-foreground/70', icon: Clock };
  const due = parseISO(dueDate);
  const now = new Date();
  if (isPast(due)) {
    const days = Math.abs(differenceInDays(now, due));
    return { text: `Vencida hace ${days}d`, className: 'text-red-600 dark:text-red-400', icon: AlertTriangle };
  }
  const days = differenceInDays(due, now);
  const hours = differenceInHours(due, now);
  if (days === 0) return { text: hours <= 0 ? 'Vence hoy' : `Faltan ${hours}h`, className: 'text-orange-600 dark:text-orange-400', icon: Clock };
  if (days <= 3) return { text: `Faltan ${days}d`, className: 'text-amber-600 dark:text-amber-400', icon: Clock };
  return { text: `Faltan ${days}d`, className: 'text-muted-foreground', icon: Clock };
};

function TaskCard({ task, onTaskClick }) {
  const timeInfo = getTimeRemaining(task.due_date);
  const TimeIcon = timeInfo.icon;
  const isFinalizado = normalizeStatus(task.status) === 'finalizado';

  return (
    <Draggable draggableId={task.id} index={task.index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          onClick={() => onTaskClick(task)}
          className={`bg-card rounded-lg border border-border p-3 shadow-sm hover:shadow-md transition-shadow cursor-pointer group ${
            snapshot.isDragging ? 'shadow-lg ring-2 ring-blue-300 rotate-1' : ''
          }`}
        >
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-1.5">
              {task.task_sequence && (
                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold tracking-wide bg-brand-deep text-brand-soft">
                  {formatTaskCode(task.task_sequence)}
                </span>
              )}
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${PRIORITY_STYLES[task.priority] || PRIORITY_STYLES.media}`}>
                {PRIORITY_LABELS[task.priority] || PRIORITY_LABELS.media}
              </span>
            </div>
            <GripVertical className="h-4 w-4 text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>

          <div className={`font-medium text-sm text-foreground mb-1 ${isFinalizado ? 'line-through text-muted-foreground/70' : ''}`}>
            {task.title}
          </div>
          {task.description && (
            <div className="text-xs text-muted-foreground mb-2 line-clamp-2">{task.description}</div>
          )}

          {task.due_date && (
            <div className={`flex items-center gap-1 text-xs mb-2 ${timeInfo.className}`}>
              <TimeIcon className="h-3 w-3" />
              <span>{format(parseISO(task.due_date), 'dd/MM/yyyy', { locale: es })}</span>
              <span className="opacity-70">· {timeInfo.text}</span>
            </div>
          )}

          {task.related_type === 'cliente' && task.related_client_id && (
            <Link
              to={createPageUrl(`ClientDetail?id=${task.related_client_id}`)}
              onClick={(e) => e.stopPropagation()}
              className="text-xs text-foreground hover:underline flex items-center gap-1 mt-1"
            >
              <Users className="h-3 w-3" />
              {task.related_client_name}
            </Link>
          )}
          {task.related_type === 'poliza' && task.related_policy_id && (
            <Link
              to={createPageUrl(`PolicyDetail?id=${task.related_policy_id}`)}
              onClick={(e) => e.stopPropagation()}
              className="text-xs text-foreground hover:underline flex items-center gap-1 mt-1"
            >
              <FileText className="h-3 w-3" />
              {task.related_policy_number}
            </Link>
          )}
        </div>
      )}
    </Draggable>
  );
}

export default function TaskKanbanBoard({ tasks, onTaskClick, onStatusChange }) {
  const columns = COLUMNS.map((col) => ({
    ...col,
    items: tasks
      .filter((t) => normalizeStatus(t.status) === col.id)
      .sort((a, b) => {
        const priorityOrder = { alta: 3, media: 2, baja: 1 };
        return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
      })
  }));

  const onDragEnd = (result) => {
    if (!result.destination) return;
    if (result.source.droppableId === result.destination.droppableId) return;
    onStatusChange(result.draggableId, result.destination.droppableId);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {columns.map((col) => (
          <Droppable key={col.id} droppableId={col.id}>
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={`rounded-xl border border-border flex flex-col min-h-[400px] transition-colors ${
                  snapshot.isDraggingOver ? 'bg-muted/50' : 'bg-muted/50'
                }`}
              >
                <div className={`flex items-center justify-between px-4 py-3 rounded-t-xl ${col.headerBg}`}>
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${col.dot}`} />
                    <span className="font-semibold text-sm text-foreground/80">{col.title}</span>
                  </div>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${col.countBg}`}>
                    {col.items.length}
                  </span>
                </div>
                <div className="flex-1 p-3 space-y-3 overflow-y-auto">
                  {col.items.length === 0 && (
                    <div className="text-xs text-muted-foreground/70 text-center py-8 border-2 border-dashed border-border rounded-lg">
                      Arrastra tareas aquí
                    </div>
                  )}
                  {col.items.map((task, idx) => (
                    <TaskCard key={task.id} task={{ ...task, index: idx }} onTaskClick={onTaskClick} />
                  ))}
                  {provided.placeholder}
                </div>
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}