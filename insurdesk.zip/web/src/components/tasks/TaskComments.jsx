import React, { useState, useEffect, useRef } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageSquare, Send, Loader2, UserCircle } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export default function TaskComments({ task, onCommentsUpdated }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [currentUser, setCurrentUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const listRef = useRef(null);

  useEffect(() => {
    setComments(task?.comments || []);
  }, [task]);

  useEffect(() => {
    api.auth.me()
      .then(u => setCurrentUser(u))
      .catch(() => setCurrentUser(null));
  }, []);

  const handleAdd = async () => {
    const text = newComment.trim();
    if (!text || !task || !currentUser) return;

    setSaving(true);
    const comment = {
      id: crypto.randomUUID(),
      text,
      created_date: new Date().toISOString(),
      user_id: currentUser.id,
      user_name: currentUser.full_name || currentUser.email,
      user_email: currentUser.email,
    };

    const updatedComments = [...comments, comment];
    setComments(updatedComments);
    setNewComment('');

    try {
      await api.entities.Task.update(task.id, { comments: updatedComments });
      onCommentsUpdated?.({ ...task, comments: updatedComments });
    } catch (error) {
      console.error('Error adding comment:', error);
      setComments(comments);
      alert('Error al guardar el comentario');
    } finally {
      setSaving(false);
    }
  };

  const sorted = [...comments].sort((a, b) =>
    new Date(a.created_date) - new Date(b.created_date)
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm font-semibold text-foreground/80">
        <MessageSquare className="h-4 w-4 text-muted-foreground/70" />
        Comentarios y acciones
        {comments.length > 0 && (
          <span className="text-xs font-normal text-muted-foreground/70">({comments.length})</span>
        )}
      </div>

      {/* Comments list */}
      <div ref={listRef} className="space-y-2 max-h-64 overflow-y-auto pr-1">
        {sorted.length === 0 ? (
          <p className="text-sm text-muted-foreground/70 text-center py-4">
            Sin comentarios aún. Registra aquí las acciones realizadas.
          </p>
        ) : (
          sorted.map((c) => (
            <div key={c.id} className="flex gap-2.5 bg-muted/40 rounded-lg p-3 border border-border">
              <UserCircle className="h-7 w-7 text-muted-foreground/70 shrink-0 mt-0.5" />
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-xs font-semibold text-foreground/80 truncate">
                    {c.user_name || 'Usuario'}
                  </span>
                  <span className="text-[10px] text-muted-foreground/70 shrink-0">
                    {(() => {
                      try {
                        return format(parseISO(c.created_date), "dd/MM/yyyy HH:mm", { locale: es });
                      } catch {
                        return '';
                      }
                    })()}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap mt-0.5 break-words">
                  {c.text}
                </p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add comment */}
      <div className="space-y-2 border-t border-border pt-3">
        <Textarea
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Escribe un comentario o registra una acción realizada..."
          rows={2}
          className="text-sm resize-none"
          disabled={saving}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
              e.preventDefault();
              handleAdd();
            }
          }}
        />
        <div className="flex justify-end">
          <Button
            size="sm"
            onClick={handleAdd}
            disabled={!newComment.trim() || saving || !currentUser}
            className="gap-1.5"
          >
            {saving ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Send className="h-3.5 w-3.5" />
            )}
            Comentar
          </Button>
        </div>
      </div>
    </div>
  );
}