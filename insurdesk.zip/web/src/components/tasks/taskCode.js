export const formatTaskCode = (seq) => {
  if (!seq) return '';
  return `TAREA-${String(seq).padStart(4, '0')}`;
};