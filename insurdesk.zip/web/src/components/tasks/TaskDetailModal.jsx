import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { api } from '@/api/client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, FileText, Users, User, Calendar, AlignLeft, Loader2 } from 'lucide-react';
import { format, isPast, differenceInDays, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import TaskComments from '@/components/tasks/TaskComments';
import { formatTaskCode } from './taskCode';

export default function TaskDetailModal({ task, open, onClose, onComplete, onTaskUpdated }) {
  const [currentTask, setCurrentTask] = useState(task);
  const [loadingTask, setLoadingTask] = useState(false);

  // Refresh task from server when modal opens — ensures comments are always current
  useEffect(() => {
    if (open && task?.id) {
      setLoadingTask(true);
      api.entities.Task.get(task.id)
        .then(fresh => {
          setCurrentTask(fresh);
          onTaskUpdated?.(fresh);
        })
        .catch(() => setCurrentTask(task))
        .finally(() => setLoadingTask(false));
    } else if (!open) {
      setCurrentTask(task);
    }
  }, [open, task?.id]);

  if (!currentTask) return null;

  const isOverdue = currentTask.due_date && isPast(parseISO(currentTask.due_date)) && currentTask.status !== 'completada' && currentTask.status !== 'finalizado';
  const daysRemaining = currentTask.due_date ? differenceInDays(parseISO(currentTask.due_date), new Date()) : null;

  const priorityConfig = {
    alta: { label: 'Alta', className: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30' },
    media: { label: 'Media', className: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30' },
    baja: { label: 'Baja', className: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30' },
  };

  const priority = priorityConfig[currentTask.priority] || priorityConfig.media;

  const handleCommentsUpdated = (updated) => {
    setCurrentTask(updated);
    onTaskUpdated?.(updated);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className={currentTask.status === 'completada' || currentTask.status === 'finalizado' ? 'line-through text-muted-foreground' : ''}>
            {currentTask.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Status & Priority */}
          <div className="flex items-center gap-3 flex-wrap">
            {currentTask.task_sequence && (
              <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-bold tracking-wide bg-brand-deep text-brand-soft">
                {formatTaskCode(currentTask.task_sequence)}
              </span>
            )}
            <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium border ${priority.className}`}>
              {currentTask.priority === 'alta' ? '🔴' : currentTask.priority === 'media' ? '🟡' : '🟢'} {priority.label}
            </span>
            <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium border ${
              currentTask.status === 'completada' || currentTask.status === 'finalizado'
                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                : currentTask.status === 'en_proceso'
                ? 'bg-muted text-foreground border-border'
                : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
            }`}>
              {currentTask.status === 'completada' || currentTask.status === 'finalizado' ? '✅ Finalizada' : currentTask.status === 'en_proceso' ? '🔄 En Proceso' : '⏳ Pendiente'}
            </span>
          </div>

          {/* Description */}
          {currentTask.description && (
            <div className="flex gap-3">
              <AlignLeft className="h-4 w-4 text-muted-foreground/70 mt-0.5 shrink-0" />
              <p className="text-sm text-foreground/80 whitespace-pre-wrap">{currentTask.description}</p>
            </div>
          )}

          {/* Due date */}
          <div className="flex gap-3 items-center">
            <Calendar className="h-4 w-4 text-muted-foreground/70 shrink-0" />
            <div>
              <span className="text-sm text-foreground/80">
                {currentTask.due_date ? format(parseISO(currentTask.due_date), "dd 'de' MMMM yyyy", { locale: es }) : 'Sin fecha'}
              </span>
              {currentTask.due_date && currentTask.status !== 'completada' && currentTask.status !== 'finalizado' && (
                <span className={`ml-2 text-xs font-semibold ${isOverdue ? 'text-red-600 dark:text-red-400' : daysRemaining <= 3 ? 'text-amber-600 dark:text-amber-400' : 'text-muted-foreground'}`}>
                  {isOverdue
                    ? `Vencida hace ${Math.abs(daysRemaining)} día(s)`
                    : daysRemaining === 0
                    ? 'Vence hoy'
                    : `Faltan ${daysRemaining} día(s)`}
                </span>
              )}
            </div>
          </div>

          {/* Assigned by */}
          {currentTask.created_by_user_name && (
            <div className="flex gap-3 items-center">
              <User className="h-4 w-4 text-muted-foreground/70 shrink-0" />
              <span className="text-sm text-foreground/80">
                Asignada por <span className="font-medium">{currentTask.created_by_user_name}</span>
              </span>
            </div>
          )}

          {/* Related */}
          {currentTask.related_type === 'cliente' && currentTask.related_client_id && (
            <div className="flex gap-3 items-center">
              <Users className="h-4 w-4 text-muted-foreground/70 shrink-0" />
              <Link
                to={createPageUrl(`ClientDetail?id=${currentTask.related_client_id}`)}
                className="text-sm text-foreground hover:underline"
                onClick={onClose}
              >
                {currentTask.related_client_name}
              </Link>
            </div>
          )}
          {currentTask.related_type === 'poliza' && currentTask.related_policy_id && (
            <div className="flex gap-3 items-center">
              <FileText className="h-4 w-4 text-muted-foreground/70 shrink-0" />
              <Link
                to={createPageUrl(`PolicyDetail?id=${currentTask.related_policy_id}`)}
                className="text-sm text-foreground hover:underline"
                onClick={onClose}
              >
                Póliza {currentTask.related_policy_number}
              </Link>
            </div>
          )}

          {/* Completed at */}
          {(currentTask.status === 'completada' || currentTask.status === 'finalizado') && currentTask.completed_at && (
            <div className="flex gap-3 items-center">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
              <span className="text-sm text-muted-foreground">
                Finalizada el {format(parseISO(currentTask.completed_at), "dd/MM/yyyy 'a las' HH:mm", { locale: es })}
              </span>
            </div>
          )}
        </div>

        {/* Comments & actions history */}
        <div className="border-t border-border pt-3">
          {loadingTask ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground/70" />
            </div>
          ) : (
            <TaskComments task={currentTask} onCommentsUpdated={handleCommentsUpdated} />
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-2 border-t">
          <Button variant="outline" onClick={onClose}>Cerrar</Button>
          {(currentTask.status === 'pendiente' || currentTask.status === 'en_proceso') && onComplete && (
            <Button
              onClick={() => { onComplete(currentTask); onClose(); }}
              className="gap-2 bg-emerald-600 hover:bg-emerald-700"
            >
              <CheckCircle2 className="h-4 w-4" />
              Marcar como finalizada
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}