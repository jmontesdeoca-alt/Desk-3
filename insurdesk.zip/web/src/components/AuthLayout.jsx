import React from "react";
import BrandLogo from "@/components/BrandLogo";
import { BRAND } from "@/lib/brand";

export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex bg-background">
      {/* Panel de marca */}
      <div className="hidden lg:flex lg:w-[44%] bg-brand-deep text-white flex-col justify-between p-12 xl:p-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '22px 22px' }} />
        <div className="relative z-10"><BrandLogo onDark className="h-9 w-auto" /></div>
        <div className="relative z-10 max-w-md">
          <h2 className="text-4xl xl:text-[44px] font-semibold leading-[1.1] tracking-tight">
            Gestión de seguros,<br />simple y ordenada.
          </h2>
          <p className="text-white/60 mt-5 text-base leading-relaxed">
            Pólizas, comisiones, siniestros y reportes en un solo lugar, con la información siempre al día.
          </p>
        </div>
        <p className="relative z-10 text-xs text-white/40">© {new Date().getFullYear()} {BRAND.name}</p>
      </div>

      {/* Formulario */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 sm:px-12 lg:p-12 xl:p-16">
        <div className="lg:hidden mb-10"><BrandLogo className="h-9 w-auto" /></div>
        <div className="w-full max-w-sm">
          <div className="mb-8">
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">{title}</h1>
            {subtitle && <p className="text-muted-foreground mt-1.5 text-sm">{subtitle}</p>}
          </div>
          {children}
          {footer && <p className="text-sm text-muted-foreground mt-8 hidden">{footer}</p>}
        </div>
      </div>
    </div>
  );
}
