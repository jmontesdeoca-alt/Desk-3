import React from 'react';
import { BRAND } from '@/lib/brand';

/** Logo del producto. `onDark` fuerza la versión para fondos oscuros; sin él sigue el tema. */
export default function BrandLogo({ variant = 'full', onDark = false, className = 'h-8 w-auto' }) {
  if (variant === 'icon') return <img src={BRAND.icon} alt={BRAND.name} className={className} />;
  if (onDark) return <img src={BRAND.logoOnDark} alt={BRAND.name} className={className} />;
  return (
    <>
      <img src={BRAND.logo} alt={BRAND.name} className={`${className} dark:hidden`} />
      <img src={BRAND.logoOnDark} alt={BRAND.name} className={`${className} hidden dark:block`} />
    </>
  );
}
