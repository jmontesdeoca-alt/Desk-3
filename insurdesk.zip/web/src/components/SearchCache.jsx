import { useState, useEffect } from 'react';

export function useSearchCache(pageKey) {
  const [searchQuery, setSearchQuery] = useState('');

  // Cargar búsqueda guardada al montar
  useEffect(() => {
    const cached = localStorage.getItem(`search_${pageKey}`);
    if (cached) {
      setSearchQuery(cached);
    }
  }, [pageKey]);

  // Guardar en localStorage cuando cambia
  const updateSearch = (query) => {
    setSearchQuery(query);
    if (query && query.trim()) {
      localStorage.setItem(`search_${pageKey}`, query);
    } else {
      localStorage.removeItem(`search_${pageKey}`);
      setSearchQuery('');
    }
  };

  // Limpiar búsqueda
  const clearSearch = () => {
    setSearchQuery('');
    localStorage.removeItem(`search_${pageKey}`);
  };

  return { searchQuery, updateSearch, clearSearch };
}