import React, { useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldX, Clock } from 'lucide-react';
import { api } from '@/api/client';

export default function AccessDenied() {
  const [userEmail, setUserEmail] = useState('');
  const [isPending, setIsPending] = useState(false);

  useEffect(() => {
    checkUserStatus();
  }, []);

  const checkUserStatus = async () => {
    try {
      const authUser = await api.auth.me();
      setUserEmail(authUser.email);
      
      // Check if user has a pending profile
      const profiles = await api.entities.User.filter({ email: authUser.email });
      if (profiles.length > 0 && profiles[0].status === 'pending_activation') {
        setIsPending(true);
      }
    } catch (error) {
      console.error('Error checking user status:', error);
    }
  };

  const handleLogout = async () => {
    await api.auth.logout();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-6">
      <Card className="max-w-md w-full shadow-lg border-0">
        <CardHeader className="text-center pb-4">
          <div className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
            isPending ? 'bg-amber-500/10' : 'bg-red-500/10'
          }`}>
            {isPending ? (
              <Clock className="h-8 w-8 text-amber-600 dark:text-amber-400" />
            ) : (
              <ShieldX className="h-8 w-8 text-red-600 dark:text-red-400" />
            )}
          </div>
          <CardTitle className="text-2xl font-bold text-foreground">
            {isPending ? 'Activación Pendiente' : 'Acceso Denegado'}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <div className="space-y-2">
            {isPending ? (
              <>
                <p className="text-muted-foreground">
                  Tu usuario aún no ha sido habilitado por un administrador.
                </p>
                <p className="text-sm text-muted-foreground">
                  Por favor contacta con el administrador para que active tu cuenta.
                </p>
              </>
            ) : (
              <>
                <p className="text-muted-foreground">
                  Tu usuario ({userEmail}) aún no ha sido habilitado por un administrador.
                </p>
                <p className="text-sm text-muted-foreground">
                  Solicita al administrador que te asigne un rol en InsurDesk.
                </p>
              </>
            )}
          </div>
          
          <div className="pt-4">
            <Button 
              onClick={handleLogout}
              variant="outline"
              className="w-full"
            >
              Cerrar Sesión
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}