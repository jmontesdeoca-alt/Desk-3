import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, AlertTriangle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function MFABanner({ graceDeadline }) {
  const navigate = useNavigate();
  if (!graceDeadline) return null;

  const deadline = new Date(graceDeadline);
  const now = new Date();
  const daysLeft = Math.ceil((deadline - now) / (1000 * 60 * 60 * 24));

  if (daysLeft <= 0) return null;

  const isUrgent = daysLeft <= 2;

  return (
    <div className={`px-4 py-3 flex items-center justify-between gap-3 ${isUrgent ? 'bg-red-500/10 border-b border-red-500/30' : 'bg-amber-500/10 border-b border-amber-500/30'}`}>
      <div className="flex items-center gap-3 min-w-0">
        {isUrgent ? (
          <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400 shrink-0" />
        ) : (
          <Shield className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0" />
        )}
        <div className="min-w-0">
          <p className={`text-sm font-medium ${isUrgent ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>
            {isUrgent
              ? `¡Último día! Configura MFA hoy o perderás acceso`
              : `Tienes ${daysLeft} ${daysLeft === 1 ? 'día' : 'días'} para configurar MFA`}
          </p>
          <p className={`text-xs ${isUrgent ? 'text-red-600 dark:text-red-400' : 'text-amber-600 dark:text-amber-400'}`}>
            La verificación en dos pasos será obligatoria a partir del {deadline.toLocaleDateString()}
          </p>
        </div>
      </div>
      <Button
        size="sm"
        variant={isUrgent ? 'destructive' : 'default'}
        onClick={() => navigate('/MFASetup')}
        className="shrink-0 gap-1"
      >
        Configurar <ArrowRight className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}