import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api/client';
import { useAuth } from '@/lib/AuthContext';
import { QRCodeSVG } from 'qrcode.react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Smartphone, Mail, Loader2, CheckCircle2, ArrowLeft, Copy } from 'lucide-react';
import { toast } from 'sonner';

export default function MFASetupPage() {
  const navigate = useNavigate();
  const { checkAppState } = useAuth();
  const [step, setStep] = useState('choose'); // choose | totp | email | done
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [otpauthUrl, setOtpauthUrl] = useState('');
  const [secret, setSecret] = useState('');
  const [code, setCode] = useState('');
  const [emailSent, setEmailSent] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleChooseMethod = async (method) => {
    setLoading(true);
    try {
      const res = await api.functions.invoke('setupMFA', { method });
      const data = res.data || res;

      if (method === 'totp') {
        setOtpauthUrl(data.otpauthUrl);
        setSecret(data.secret);
        setStep('totp');
      } else {
        setStep('email');
      }
    } catch (err) {
      toast.error('Error al configurar MFA: ' + (err.message || 'Error desconocido'));
    } finally {
      setLoading(false);
    }
  };

  const handleSendEmailCode = async () => {
    setLoading(true);
    try {
      await api.functions.invoke('sendMFAEmailOTP', {});
      setEmailSent(true);
      toast.success('Código enviado a tu correo');
    } catch (err) {
      toast.error('Error al enviar código: ' + (err.message || 'Error desconocido'));
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    if (code.length !== 6) {
      toast.error('Ingresa un código de 6 dígitos');
      return;
    }
    setVerifying(true);
    try {
      const res = await api.functions.invoke('verifyMFA', { code, setup: true });
      const data = res.data || res;

      if (data.success) {
        const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 horas
        localStorage.setItem('mfa_verified', JSON.stringify({ verified: true, expiresAt }));
        setStep('done');
        toast.success('MFA activado correctamente');
        // Refrescar el estado de autenticación para que user.mfa_enabled se actualice
        await checkAppState();
        setTimeout(() => navigate('/'), 2000);
      } else {
        toast.error(data.error || 'Código incorrecto');
      }
    } catch (err) {
      toast.error('Error al verificar: ' + (err.message || 'Error desconocido'));
    } finally {
      setVerifying(false);
    }
  };

  const copySecret = () => {
    navigator.clipboard.writeText(secret);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-3">
            <Shield className="h-8 w-8 text-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Configurar MFA</h1>
          <p className="text-sm text-muted-foreground mt-1">
            La autenticación de dos factores es obligatoria para acceder a InsurDesk
          </p>
        </div>

        {step === 'choose' && (
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg">Elige tu método de verificación</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <button
                onClick={() => handleChooseMethod('totp')}
                disabled={loading}
                className="w-full p-4 rounded-xl border-2 border-border hover:border-primary hover:bg-muted transition-all text-left flex items-start gap-3 disabled:opacity-50"
              >
                <Smartphone className="h-6 w-6 text-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium text-foreground">App de Autenticador</p>
                  <p className="text-sm text-muted-foreground">Google Authenticator, Microsoft Authenticator, etc.</p>
                </div>
              </button>
              <button
                onClick={() => handleChooseMethod('email')}
                disabled={loading}
                className="w-full p-4 rounded-xl border-2 border-border hover:border-primary hover:bg-muted transition-all text-left flex items-start gap-3 disabled:opacity-50"
              >
                <Mail className="h-6 w-6 text-foreground mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium text-foreground">Código por Email</p>
                  <p className="text-sm text-muted-foreground">Recibe un código de 6 dígitos en cada inicio de sesión</p>
                </div>
              </button>
              {loading && (
                <div className="flex justify-center py-2">
                  <Loader2 className="h-5 w-5 animate-spin text-foreground" />
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {step === 'totp' && (
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Smartphone className="h-5 w-5 text-foreground" />
                Configurar Authenticator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                1. Escanea este código QR con tu app de autenticador
              </p>
              <div className="flex justify-center p-4 bg-card rounded-xl border">
                {otpauthUrl && <QRCodeSVG value={otpauthUrl} size={200} />}
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">
                  2. Si no puedes escanear, ingresa este código manualmente:
                </p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 p-2 bg-muted rounded text-xs font-mono break-all">
                    {secret}
                  </code>
                  <Button size="icon" variant="outline" onClick={copySecret} title="Copiar">
                    {copied ? <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label>3. Ingresa el código de 6 dígitos de tu app</Label>
                <Input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="text-center text-2xl tracking-widest font-mono"
                />
              </div>
              <Button onClick={handleVerify} disabled={verifying || code.length !== 6} className="w-full">
                {verifying && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Verificar y Activar
              </Button>
              <Button variant="ghost" onClick={() => { setStep('choose'); setCode(''); }} className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" /> Volver
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 'email' && (
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Mail className="h-5 w-5 text-foreground" />
                Verificación por Email
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Recibirás un código de 6 dígitos en tu correo electrónico en cada inicio de sesión.
              </p>
              {!emailSent ? (
                <Button onClick={handleSendEmailCode} disabled={loading} className="w-full">
                  {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Enviar código de verificación
                </Button>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label>Ingresa el código de 6 dígitos</Label>
                    <Input
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      value={code}
                      onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                      placeholder="000000"
                      className="text-center text-2xl tracking-widest font-mono"
                    />
                  </div>
                  <Button onClick={handleVerify} disabled={verifying || code.length !== 6} className="w-full">
                    {verifying && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Verificar y Activar
                  </Button>
                  <Button variant="ghost" onClick={handleSendEmailCode} disabled={loading} className="w-full text-sm">
                    Reenviar código
                  </Button>
                </>
              )}
              <Button variant="ghost" onClick={() => { setStep('choose'); setCode(''); setEmailSent(false); }} className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" /> Volver
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 'done' && (
          <Card className="border-0 shadow-lg">
            <CardContent className="pt-6 text-center">
              <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-foreground mb-2">¡MFA Activado!</h2>
              <p className="text-sm text-muted-foreground">Redirigiendo al panel...</p>
              <div className="flex justify-center mt-4">
                <Loader2 className="h-6 w-6 animate-spin text-foreground" />
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}