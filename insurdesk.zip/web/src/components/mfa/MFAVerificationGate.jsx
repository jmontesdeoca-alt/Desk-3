import React, { useState } from 'react';
import { api } from '@/api/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Loader2, Mail, Smartphone } from 'lucide-react';
import { toast } from 'sonner';

export default function MFAVerificationGate({ user, onVerified }) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [emailSending, setEmailSending] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const method = user?.mfa_method || 'totp';

  const handleSendEmailCode = async () => {
    setEmailSending(true);
    try {
      await api.functions.invoke('sendMFAEmailOTP', {});
      setEmailSent(true);
      toast.success('Código enviado a tu correo');
    } catch (err) {
      toast.error('Error al enviar código: ' + (err.message || 'Error'));
    } finally {
      setEmailSending(false);
    }
  };

  const handleVerify = async () => {
    if (code.length !== 6) {
      toast.error('Ingresa un código de 6 dígitos');
      return;
    }
    setLoading(true);
    try {
      const res = await api.functions.invoke('verifyMFA', { code, setup: false });
      const data = res.data || res;

      if (data.success) {
        const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 horas
        localStorage.setItem('mfa_verified', JSON.stringify({ verified: true, expiresAt }));
        onVerified();
      } else {
        toast.error(data.error || 'Código incorrecto');
        setCode('');
      }
    } catch (err) {
      toast.error('Error al verificar: ' + (err.message || 'Error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-card rounded-2xl shadow-lg">
        <div className="p-6 text-center border-b">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-3">
            <Shield className="h-8 w-8 text-foreground" />
          </div>
          <h2 className="text-xl font-bold text-foreground">Verificación MFA</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {method === 'totp'
              ? 'Ingresa el código de tu app de autenticador'
              : 'Te enviaremos un código a tu correo'}
          </p>
        </div>

        <div className="p-6 space-y-4">
          {method === 'totp' ? (
            <>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                <Smartphone className="h-4 w-4 text-foreground" />
                Abre tu app de autenticador
              </div>
              <div className="space-y-2">
                <Label>Código de 6 dígitos</Label>
                <Input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                  onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
                  placeholder="000000"
                  className="text-center text-2xl tracking-widest font-mono"
                  autoFocus
                />
              </div>
              <Button onClick={handleVerify} disabled={loading || code.length !== 6} className="w-full">
                {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Verificar
              </Button>
            </>
          ) : (
            <>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                <Mail className="h-4 w-4 text-foreground" />
                {user?.email}
              </div>
              {!emailSent ? (
                <Button onClick={handleSendEmailCode} disabled={emailSending} className="w-full">
                  {emailSending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Enviar código
                </Button>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label>Código de 6 dígitos</Label>
                    <Input
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      value={code}
                      onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                      onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
                      placeholder="000000"
                      className="text-center text-2xl tracking-widest font-mono"
                      autoFocus
                    />
                  </div>
                  <Button onClick={handleVerify} disabled={loading || code.length !== 6} className="w-full">
                    {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Verificar
                  </Button>
                  <Button variant="ghost" onClick={handleSendEmailCode} disabled={emailSending} className="w-full text-sm">
                    Reenviar código
                  </Button>
                </>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}