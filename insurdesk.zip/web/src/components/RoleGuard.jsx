import { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth } from '@/lib/AuthContext';
import { canAccessPage } from '@/lib/routePermissions';

function DeniedRedirect() {
  useEffect(() => {
    toast.error('No tienes acceso a esta página');
  }, []);
  return <Navigate to="/" replace />;
}

export default function RoleGuard({ pageName, children }) {
  const { user, isLoadingAuth } = useAuth();

  // Wait for auth to resolve before deciding — avoids flashing a false denial
  if (isLoadingAuth || !user) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-border border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!canAccessPage(pageName, user)) {
    return <DeniedRedirect />;
  }

  return children;
}