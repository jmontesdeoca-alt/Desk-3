// Cliente del backend propio de InsurDesk. Expone la misma superficie que usaba la app
// (entidades, funciones, auth, integraciones) para que el resto del código no cambie.
import { appParams, tokenStore } from '@/lib/app-params';

const API = appParams.apiUrl;

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message || `Error ${status}`);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
    this.response = { status, data };
  }
}

async function request(method, path, { body, query, formData, auth = true } = {}) {
  const headers = {};
  const token = tokenStore.get();
  if (auth && token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (formData) payload = formData;
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  let url = `${API}${path}`;
  if (query) {
    const q = new URLSearchParams();
    Object.entries(query).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') q.set(k, v); });
    const s = q.toString();
    if (s) url += `?${s}`;
  }
  let res;
  try { res = await fetch(url, { method, headers, body: payload }); }
  catch (e) { throw new ApiError('No se pudo conectar con el servidor', 0, null); }
  const text = await res.text();
  let data = null;
  if (text) { try { data = JSON.parse(text); } catch { data = text; } }
  if (!res.ok) throw new ApiError((data && (data.message || data.error)) || res.statusText, res.status, data);
  return data;
}

// ---------- Tiempo real (SSE con cabecera Authorization) ----------
function subscribe(entity, callback) {
  let stopped = false;
  let controller;
  const run = async () => {
    while (!stopped) {
      controller = new AbortController();
      try {
        const token = tokenStore.get();
        const res = await fetch(`${API}/api/entities/${entity}/stream`, { headers: token ? { Authorization: `Bearer ${token}` } : {}, signal: controller.signal });
        if (!res.ok || !res.body) throw new Error('stream');
        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = '';
        while (!stopped) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          let i;
          while ((i = buf.indexOf('\n\n')) >= 0) {
            const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
            const line = chunk.split('\n').find((l) => l.startsWith('data: '));
            if (line) { try { callback(JSON.parse(line.slice(6))); } catch { /* ignorar */ } }
          }
        }
      } catch { /* reintentar */ }
      if (!stopped) await new Promise((r) => setTimeout(r, 3000));
    }
  };
  run();
  return () => { stopped = true; controller?.abort(); };
}

function entityApi(name) {
  const base = `/api/entities/${name}`;
  return {
    list: (sort, limit, skip, fields) => request('GET', base, { query: { sort, limit, skip, fields: Array.isArray(fields) ? fields.join(',') : fields } }),
    filter: (query, sort, limit, skip, fields) => request('POST', `${base}/filter`, { body: { query: query || {}, sort, limit, skip, fields } }),
    get: (id) => request('GET', `${base}/${id}`),
    create: (data) => request('POST', base, { body: data }),
    bulkCreate: (items) => request('POST', `${base}/bulk`, { body: items }),
    update: (id, data) => request('PUT', `${base}/${id}`, { body: data }),
    bulkUpdate: (items) => request('POST', `${base}/bulk-update`, { body: items }),
    delete: (id) => request('DELETE', `${base}/${id}`),
    deleteMany: (query) => request('POST', `${base}/delete-many`, { body: { query } }),
    subscribe: (cb) => subscribe(name, cb),
  };
}
const entities = new Proxy({}, { get: (target, name) => (typeof name === 'string' ? (target[name] ||= entityApi(name)) : undefined) });

// ---------- Auth ----------
const auth = {
  me: () => request('GET', '/api/auth/me'),
  updateMe: (data) => request('PATCH', '/api/auth/me', { body: data }),
  isAuthenticated: async () => { if (!tokenStore.get()) return false; try { await auth.me(); return true; } catch { return false; } },
  setToken: (t) => tokenStore.set(t),
  loginViaEmailPassword: async (email, password) => {
    const r = await request('POST', '/api/auth/login', { body: { email, password }, auth: false });
    tokenStore.set(r.access_token);
    return r;
  },
  register: (data) => request('POST', '/api/auth/register', { body: data, auth: false }),
  verifyOtp: (data) => request('POST', '/api/auth/verify-otp', { body: data, auth: false }),
  resendOtp: (email) => request('POST', '/api/auth/resend-otp', { body: { email }, auth: false }),
  resetPasswordRequest: (email) => request('POST', '/api/auth/reset-password-request', { body: { email }, auth: false }),
  resetPassword: (data) => request('POST', '/api/auth/reset-password', { body: data, auth: false }),
  loginWithProvider: (provider, returnTo = '/') => { window.location.href = `${API}/api/auth/${provider}?return_to=${encodeURIComponent(returnTo)}`; },
  logout: (redirectUrl) => {
    tokenStore.clear();
    if (typeof window !== 'undefined') window.location.href = redirectUrl ? `/login?returnTo=${encodeURIComponent(new URL(redirectUrl, window.location.origin).pathname)}` : '/login';
  },
  redirectToLogin: (returnUrl) => {
    const rt = returnUrl ? new URL(returnUrl, window.location.origin).pathname : '/';
    window.location.href = `/login?returnTo=${encodeURIComponent(rt)}`;
  },
};

// ---------- Funciones backend ----------
const functions = {
  invoke: async (name, payload = {}) => {
    const data = await request('POST', `/api/functions/${name}`, { body: payload });
    return { data, status: 200 };
  },
};

// ---------- Integraciones ----------
const integrations = {
  Core: {
    UploadFile: async ({ file }) => { const fd = new FormData(); fd.append('file', file); return request('POST', '/api/files/upload', { formData: fd }); },
    InvokeLLM: (params) => request('POST', '/api/integrations/core/InvokeLLM', { body: params }),
    SendEmail: (params) => request('POST', '/api/integrations/core/SendEmail', { body: params }),
    ExtractDataFromUploadedFile: (params) => request('POST', '/api/integrations/core/ExtractDataFromUploadedFile', { body: params }),
  },
};

export const api = {
  auth,
  entities,
  functions,
  integrations,
  users: { inviteUser: (email, role) => request('POST', '/api/auth/invite', { body: { email, role } }) },
  appLogs: { logUserInApp: async () => ({}) },
  apiUrl: API,
};
export default api;
