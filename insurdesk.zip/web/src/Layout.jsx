import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { api } from '@/api/client';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  FileText, Shield, TrendingUp, DollarSign, BarChart3, 
  Settings, Home, ClipboardList, MoreHorizontal, UserCircle, Users, RefreshCw
} from 'lucide-react';
import Sidebar from '@/components/Sidebar';
import AccessDenied from '@/components/AccessDenied';
import MFAVerificationGate from '@/components/mfa/MFAVerificationGate';
import MFABanner from '@/components/mfa/MFABanner';
import { Toaster } from "sonner";
import GlobalSearch from '@/components/GlobalSearch';
import AIAssistant from '@/components/AIAssistant';
import { AnimatePresence, motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/lib/AuthContext';
import { useFeatures } from '@/lib/FeatureContext';
import { useTheme } from '@/lib/theme';
import { MODULE_FEATURE, crmNavItems } from '@/modules/registry';
import '@/components/i18n';

export default function Layout({ children, currentPageName }) {
  const { t, i18n } = useTranslation();
  const { user: contextUser, userRoleInfo } = useAuth();
  const { has, pageEnabled } = useFeatures();
  const { isDark, toggle: toggleTheme } = useTheme();
  const [user, setUser] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuDrawerOpen, setMobileMenuDrawerOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mfaVerified, setMfaVerified] = useState(() => {
    try {
      const raw = localStorage.getItem('mfa_verified');
      if (!raw) return false;
      const parsed = JSON.parse(raw);
      if (parsed.expiresAt && Date.now() > parsed.expiresAt) {
        localStorage.removeItem('mfa_verified');
        return false;
      }
      return parsed.verified === true;
    } catch {
      return false;
    }
  });
  const location = useLocation();
  const navigate = useNavigate();
  const scrollPositions = useRef({});

  useEffect(() => {
    loadUser();

    // Ping last_seen solo cuando hay actividad real del usuario
    let activityTimer = null;

    const handleActivity = () => {
      // Debounce: espera 30s sin actividad antes de enviar el ping
      clearTimeout(activityTimer);
      activityTimer = setTimeout(() => {
        updateLastSeen();
      }, 30000);
    };

    const events = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'];
    events.forEach(e => window.addEventListener(e, handleActivity, { passive: true }));

    // Ping inicial al cargar
    updateLastSeen();

    // Heartbeat: actualizar last_seen cada 5 minutos (reducido para aliviar carga en la API de User)
    const heartbeat = setInterval(() => {
      updateLastSeen();
    }, 300000);

    return () => {
      clearTimeout(activityTimer);
      clearInterval(heartbeat);
      events.forEach(e => window.removeEventListener(e, handleActivity));
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Preserve scroll position for mobile tabs (ref, no re-render)
  useEffect(() => {
    const handleScroll = () => {
      scrollPositions.current[location.pathname] = window.scrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [location.pathname]);

  // Restore scroll position only when pathname changes
  useEffect(() => {
    const savedPosition = scrollPositions.current[location.pathname];
    if (savedPosition !== undefined) {
      window.scrollTo(0, savedPosition);
    }
  }, [location.pathname]);

  const updateLastSeen = async () => {
    try {
      await api.auth.updateMe({ last_seen: new Date().toISOString() });
    } catch {}
  };

  const loadUser = async () => {
    try {
      // User + UserRole info already loaded by AuthContext — no need to re-fetch
      if (!contextUser || !userRoleInfo || !userRoleInfo.app_role) {
        console.error('Missing UserRole data:', { email: contextUser?.email, userRoleInfo });
        setUser(null);
        return;
      }

      const enrichedUser = {
        ...contextUser,
        app_role: userRoleInfo.app_role,
        agent_id: userRoleInfo.agent_id,
        status: userRoleInfo.status || 'pending_activation',
        crm_access_enabled: userRoleInfo.crm_access_enabled ?? contextUser?.crm_access_enabled ?? false
      };

      // Auto-activate user on first login if pending
      if (enrichedUser.status === 'pending_activation' && userRoleInfo.id) {
        try {
          await api.entities.UserRole.update(userRoleInfo.id, { status: 'active' });
          enrichedUser.status = 'active';
        } catch (err) {
          console.error('Error activating user:', err);
        }
      }

      await updateLastSeen();
      setUser(enrichedUser);
    } catch (error) {
      console.error('Error loading user:', error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = useCallback(async () => {
    localStorage.removeItem('mfa_verified');
    await api.auth.logout();
  }, []);

  const openSearch = useCallback(() => setSearchOpen(true), []);


  const getNavItems = () => {
    const isAdmin = user?.role === 'admin' || user?.app_role === 'admin';
    const isGerencial = user?.app_role === 'gerencial';
    const isJefatura = user?.app_role === 'jefatura';
    const isOperativo = user?.app_role === 'operativo';
    const isFinanciero = user?.app_role === 'financiero';
    const isAgent = user?.app_role === 'agente';

    const items = [];



    // All roles can see Clients
    items.push({ name: t('nav.clients'), icon: Users, path: 'Clients' });

    // All roles can see Policies (Financiero can see but not edit)
    items.push({ name: t('nav.policies'), icon: FileText, path: 'Policies' });

    // All roles can see Renewals
    items.push({ name: t('nav.renewals'), icon: RefreshCw, path: 'Renewals' });

    // Only Admin, Gerencial, and Operativo can see Claims
    if (isAdmin || isGerencial || isOperativo) {
      items.push({ name: t('nav.claims'), icon: Shield, path: 'Claims' });
    }

    // All roles can see Payments
    items.push({ name: t('nav.payments'), icon: DollarSign, path: 'Payments' });

    // All roles can see Tasks
    items.push({ name: t('nav.tasks'), icon: ClipboardList, path: 'MyTasks' });


    // All roles can see Reports
    items.push({ name: t('nav.reports'), icon: BarChart3, path: 'Reports' });

    // Only Admin, Gerencial, Jefatura, and Financiero can see Commissions
    if (isAdmin || isGerencial || isJefatura || isFinanciero) {
      items.push({ name: t('nav.commissions'), icon: TrendingUp, path: 'Commissions' });
    }

    // Admin, Jefatura and Gerencial can see Admin Panel
    if (isAdmin || isJefatura || isGerencial) {
      items.push({ name: t('nav.admin'), icon: Settings, path: 'AdminPanel' });
    }

    return items;
  };

  const navItems = useMemo(() => {
    const base = getNavItems();
    // El CRM aparece como un grupo propio antes de Clientes, si el plan lo incluye y el usuario tiene acceso
    const crm = user?.crm_access_enabled ? crmNavItems((id) => has(MODULE_FEATURE[id]), user?.crm_role) : [];
    const at = base.findIndex((i) => i.path === 'Clients');
    const merged = at >= 0 ? [...base.slice(0, at), ...crm, ...base.slice(at)] : [...base, ...crm];
    return merged.filter((i) => i.heading || pageEnabled(i.path));
  }, [user, t, has, pageEnabled]);

  const isActivePage = (path) => {
    return currentPageName === path || location.pathname.includes(path);
  };

  useEffect(() => {
    if (user && !user.mfa_enabled && user.mfa_grace_deadline && new Date(user.mfa_grace_deadline) <= new Date() && currentPageName !== 'MFASetup') {
      navigate('/MFASetup');
    }
  }, [user, currentPageName, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-foreground"></div>
      </div>
    );
  }

  if (!user || !user.app_role) {
    return <AccessDenied />;
  }

  const isMFASetupPage = currentPageName === 'MFASetup';
  const mfaEnabled = user?.mfa_enabled === true;
  const graceDeadline = user?.mfa_grace_deadline;
  const deadlinePassed = graceDeadline && new Date(graceDeadline) <= new Date();
  const needsGate = mfaEnabled && !mfaVerified && !isMFASetupPage;
  const needsBanner = !mfaEnabled && graceDeadline && !deadlinePassed && !isMFASetupPage;

  const mobileNavItems = [
        { name: t('nav.dashboard'), icon: Home, path: 'Dashboard' },
        { name: t('nav.policies'), icon: FileText, path: 'Policies' },
        { name: t('nav.payments'), icon: DollarSign, path: 'Payments' }
      ];

  const mobileMenuItems = getNavItems();

  return (
    <div className="min-h-screen bg-background">
      {needsGate && <MFAVerificationGate user={user} onVerified={() => setMfaVerified(true)} />}
    <Toaster position="top-right" richColors />
      {/* Mobile safe-area top cover — hides content scrolling behind notch / dynamic island */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-background z-30" style={{ height: 'env(safe-area-inset-top)' }} />
      {/* Desktop Sidebar - collapsible to the left */}
      <Sidebar
        user={user}
        sidebarCollapsed={sidebarCollapsed}
        setSidebarCollapsed={setSidebarCollapsed}
        navItems={navItems}
        onSearchOpen={openSearch}
        onLogout={handleLogout}
      />

      {/* Main Content with page transitions */}
      <main className={`transition-[margin] duration-300 ease-out ${sidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'} pb-28 lg:pb-0`}>
        {needsBanner && <MFABanner graceDeadline={graceDeadline} />}
        <div className="relative overflow-hidden">
          <AnimatePresence mode="popLayout">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="bg-background"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile Bottom Navigation - Only on mobile */}
      <nav 
        className="lg:hidden fixed bottom-0 left-0 right-0 z-50" 
        style={{ 
          paddingBottom: 'env(safe-area-inset-bottom)'
        }}
      >
        <div className="mx-3 mb-3 rounded-2xl bg-card/90 backdrop-blur-xl border border-border shadow-[0_6px_24px_rgba(16,24,40,0.10)]">
        <div className="grid grid-cols-4 px-2 py-2" style={{ minHeight: '56px' }}>
          {mobileNavItems.map((item) => {
            const Icon = item.icon;
            const active = isActivePage(item.path);
            return (
              <Link
                key={item.path}
                to={createPageUrl(item.path)}
                className={`flex flex-col items-center justify-center gap-0.5 rounded-2xl py-1 transition-all ${
                  active 
                    ? 'text-brand dark:text-brand-soft bg-brand/10 dark:bg-brand-soft/10' 
                    : 'text-muted-foreground '
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium">{item.name}</span>
              </Link>
            );
          })}
          
          {/* More Menu Button */}
          <Sheet open={mobileMenuDrawerOpen} onOpenChange={setMobileMenuDrawerOpen}>
            <SheetTrigger asChild>
              <button
                className="flex flex-col items-center justify-center gap-0.5 rounded-2xl py-1 transition-colors text-muted-foreground "
              >
                <MoreHorizontal className="h-5 w-5" />
                <span className="text-[10px] font-medium">{t('nav.more')}</span>
              </button>
            </SheetTrigger>
            <SheetContent side="bottom" className="bg-transparent p-0 border-0 shadow-none rounded-t-3xl">
              <div className="ios-bubble-up mx-3 mb-3 rounded-2xl bg-card/95 backdrop-blur-xl border border-border shadow-[0_6px_24px_rgba(16,24,40,0.16)] overflow-hidden max-h-[85vh] overflow-y-auto" style={{ paddingBottom: 'max(env(safe-area-inset-bottom), 12px)' }}>
                <div className="flex justify-center pt-2.5 pb-1">
                  <div className="h-1.5 w-10 rounded-full bg-slate-300/70 " />
                </div>
                <div className="px-4 pb-4 space-y-2">
                  {/* User Profile Link */}
                  <Link
                    to={createPageUrl('UserProfile')}
                    onClick={() => setMobileMenuDrawerOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 rounded-2xl transition-colors hover:bg-white/60 dark:hover:bg-white/10 border border-white/50 dark:border-white/10 bg-white/40 dark:bg-white/5"
                  >
                    <UserCircle className="h-5 w-5 text-brand dark:text-brand-soft" />
                    <div className="min-w-0">
                      <span className="font-medium block text-sm truncate">{user?.display_name || user?.full_name || 'Mi Perfil'}</span>
                      <span className="text-xs text-muted-foreground truncate">{user?.email}</span>
                    </div>
                  </Link>
                  <button type="button" onClick={toggleTheme} className="flex w-full items-center gap-3 px-4 py-3 rounded-2xl border border-border bg-card/60 text-left">
                    <span className="text-sm font-medium">{isDark ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}</span>
                  </button>
                  {mobileMenuItems.map((item) => {
                    const Icon = item.icon;
                    const active = isActivePage(item.path);
                    return (
                      <Link
                        key={item.path}
                        to={createPageUrl(item.path)}
                        onClick={() => setMobileMenuDrawerOpen(false)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-colors border ${
                          active 
                            ? 'bg-brand/15 text-brand dark:text-brand-soft border-brand/30' 
                            : 'hover:bg-white/60 dark:hover:bg-white/10 border-white/50 dark:border-white/10 bg-white/40 dark:bg-white/5'
                        }`}
                      >
                        <Icon className="h-5 w-5" />
                        <span className="font-medium">{item.name}</span>
                      </Link>
                    );
                  })}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
        </div>
      </nav>

      {/* Global Search */}
      <GlobalSearch open={searchOpen} onOpenChange={setSearchOpen} />

      {/* AI Assistant */}
      {has('ai') && <AIAssistant />}
      </div>
    );
  }