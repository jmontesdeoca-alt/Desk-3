import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
import { applyTheme, getTheme } from '@/lib/theme'

applyTheme(getTheme()) // antes del primer render: sin destello

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)
