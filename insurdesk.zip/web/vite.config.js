import react from '@vitejs/plugin-react'
import path from 'node:path'
import { defineConfig } from 'vite'

const API = process.env.VITE_DEV_API || 'http://localhost:3001'

// https://vite.dev/config/
export default defineConfig({
  logLevel: 'error',
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname, 'src') } },
  server: {
    port: 5173,
    proxy: {
      '/api': { target: API, changeOrigin: true },
      '/files': { target: API, changeOrigin: true },
      '/functions': { target: API, changeOrigin: true },
    },
  },
})
