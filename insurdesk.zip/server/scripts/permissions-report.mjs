// Genera PERMISOS.md: qué puede hacer cada rol sobre cada entidad, calculado con el MISMO motor que usa el servidor.
// Uso: npm run permisos
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

process.env.DATA_DIR ||= fs.mkdtempSync(path.join(os.tmpdir(), 'permisos-'));
process.env.PLAN ||= 'nivel3';
const { resolveRule, entityNames } = await import('../src/store.js');
const { ROOT } = await import('../src/config.js');
const policies = JSON.parse(fs.readFileSync(path.join(ROOT, 'policies.json'), 'utf8')).entities;

const PORTAL = ['admin', 'gerencial', 'jefatura', 'operativo', 'financiero', 'agente', 'gestor_ventas'];
const CRM = ['admin_crm', 'jefatura_crm', 'agente_crm'];
const OPS = [['read', 'L'], ['create', 'C'], ['update', 'E'], ['delete', 'B']];

function ctxFor(role, crm) {
  const appRole = crm ? 'agente' : role;
  return { user: { role: role === 'admin' ? 'admin' : 'user', app_role: appRole, crm_role: crm ? role : null, id: 'U1', email: 'u@x' }, roleData: { app_role: appRole, agent_id: 'AG1', status: 'active' }, agentId: 'AG1', teamAgentIds: ['AG1', 'AG2'], teamUserIds: ['U1'] };
}
function cell(entity, role, crm) {
  return OPS.map(([op, letter]) => {
    const r = resolveRule(entity, op, ctxFor(role, crm), role === 'admin' || role === 'admin_crm');
    return r === true ? letter : r === false ? '-' : letter.toLowerCase();
  }).join('');
}

const names = entityNames().sort();
const isCrm = (e) => policies[e]?.by === 'crm_role';
const rows = (list, roles, crm) => list.map((e) => `| ${e}${policies[e] ? '' : ' *(heredada)*'} | ${roles.map((r) => `\`${cell(e, r, crm)}\``).join(' | ')} |`).join('\n');
const portal = names.filter((e) => !isCrm(e) && !/^(Meta|WhatsApp)/.test(e));
const crmEntities = names.filter((e) => isCrm(e));

const md = `# Matriz de permisos

Generada con \`npm run permisos\` (en \`server/\`) a partir de \`server/policies.json\` y de las reglas heredadas de los esquemas.
Es lo que el **servidor** aplica; el menú de la interfaz solo oculta lo que no corresponde.

**Cómo leerla.** Cada celda son 4 letras, en este orden: **L**eer · **C**rear · **E**ditar · **B**orrar.

| Símbolo | Significado |
|---|---|
| \`L\` mayúscula | permitido sobre **todos** los registros |
| \`l\` minúscula | permitido solo sobre los **propios o de su estructura** (ver abajo) |
| \`-\` | no permitido |

Ejemplo: \`Lc--\` = ve todo, crea solo lo propio, no edita ni borra.

**Qué significa "propio" por entidad**
- Pólizas, comisiones, liquidaciones, metas: las del agente vinculado al usuario (y su estructura si el plan la incluye).
- Pagos, renovaciones, documentos: los de las pólizas de ese agente/estructura.
- Clientes: los que el usuario creó o los que tienen una póliza de su agente/estructura.
- CRM (prospectos, leads, actividades): los asignados al usuario.
- Notificaciones y mensajes: los dirigidos al usuario.

**Gerencial y jefatura** se muestran como si estuvieran vinculados a un agente (ven solo su estructura, por eso la \`l\` minúscula en lo que depende del agente). Sin ese vínculo ven **todo** (\`L\`).

**Estructura (upline).** Se ve hacia abajo, nunca hacia arriba: cada agente ve lo suyo y lo de todos sus subagentes. En el Nivel 1 (sin estructura) solo lo suyo.

**Seguridad por defecto.** Lo que no tenga regla (ni en esta matriz ni heredada) queda **solo para administradores**.
Los secretos de MFA y los tokens de Google nunca salen del servidor, ni siquiera para un administrador.

## Portal

| Entidad | ${PORTAL.join(' | ')} |
|---|${PORTAL.map(() => '---').join('|')}|
${rows(portal, PORTAL, false)}

## CRM

Los roles del CRM se derivan del rol del usuario (admin → admin_crm, gerencial/jefatura → jefatura_crm, agente → agente_crm)
y exigen además que el usuario tenga el acceso al CRM activado. Meta y WhatsApp: solo administradores.

| Entidad | ${CRM.join(' | ')} |
|---|${CRM.map(() => '---').join('|')}|
${rows(crmEntities, CRM, true)}
`;
fs.writeFileSync(path.resolve(ROOT, '..', 'PERMISOS.md'), md);
console.log(`PERMISOS.md: ${portal.length} entidades del portal y ${crmEntities.length} del CRM`);
process.exit(0);
