// Marca y remitente del producto. Todo lo que sale hacia el usuario (correos, MFA, PDF) lee de aquí.
import { config } from '../src/config.js';

const address = (config.mail.from.match(/<([^>]+)>/) || [])[1] || config.mail.from;

export const brand = {
  name: config.brandName,
  appUrl: config.appUrl,
  logo: `${config.appUrl}/logo.png`,            // para fondos claros
  logoOnDark: `${config.appUrl}/logo-dark.png`, // para encabezados oscuros
  address,
  /** Remitente con etiqueta opcional: brand.from('Siniestros') -> "InsurDesk Siniestros <noreply@…>" */
  from: (label = '') => `${config.brandName}${label ? ` ${label}` : ''} <${address}>`,
};
