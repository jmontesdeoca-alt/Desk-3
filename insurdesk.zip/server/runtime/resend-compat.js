// API de `resend` usada por las funciones del CRM, enrutada por el envío de correo del producto (Resend, SMTP o consola)
import { sendEmail } from '../src/integrations.js';

export class Resend {
  constructor() {
    this.emails = {
      send: async (p) => {
        try {
          const r = await sendEmail({ from: p.from, to: p.to, cc: p.cc, bcc: p.bcc, reply_to: p.reply_to || p.replyTo, subject: p.subject, html: p.html, text: p.text, attachments: p.attachments });
          return { data: { id: r.id || 'local' }, error: null };
        } catch (e) {
          console.error('[mail] error enviando:', e.message);
          return { data: null, error: { message: e.message } };
        }
      },
    };
  }
}
