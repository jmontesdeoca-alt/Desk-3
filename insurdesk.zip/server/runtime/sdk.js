// Reemplazo local de `npm:@sdk/sdk` para el código de las funciones backend.
import { entitiesProxy } from '../src/store.js';
import { userFromTokenSync, tokenFromHeaders, auth as authApi } from '../src/auth.js';
import { coreIntegrations } from '../src/integrations.js';
import { invokeFunction, INTERNAL_SECRET } from '../src/functions.js';

const SERVICE_USER = { id: 'service', email: 'service@system.local', full_name: 'Servicio', role: 'admin', app_role: 'admin', data: { app_role: 'admin' }, is_service: true };

export function createClientFromRequest(req) {
  const headers = req?.headers;
  const internal = headers?.get?.('x-internal-service') === INTERNAL_SECRET;
  const token = tokenFromHeaders(headers);
  const user = internal ? SERVICE_USER : userFromTokenSync(token);

  const functionsFor = (asService) => ({
    invoke: async (name, payload = {}) => invokeFunction(name, payload, { token, service: asService || internal }),
  });
  const authFor = {
    me: async () => { if (!user) throw Object.assign(new Error('Unauthorized'), { status: 401 }); return user; },
    isAuthenticated: async () => !!user,
    updateMe: async (patch) => { if (!user || user.is_service) throw Object.assign(new Error('Unauthorized'), { status: 401 }); return authApi.updateMe(user.id, patch); },
  };
  const userEntities = entitiesProxy({ user, service: !!user?.is_service });
  const serviceEntities = entitiesProxy({ service: true, user });

  return {
    auth: authFor,
    entities: userEntities,
    functions: functionsFor(false),
    integrations: { Core: coreIntegrations },
    users: { inviteUser: async (email, role) => authApi.inviteUser(email, role) },
    asServiceRole: {
      entities: serviceEntities,
      functions: functionsFor(true),
      integrations: { Core: coreIntegrations },
    },
  };
}
export const createClient = createClientFromRequest;
