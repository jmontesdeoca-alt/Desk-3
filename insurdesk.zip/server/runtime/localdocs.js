// Almacenamiento local de documentos de pólizas (sustituye a Azure Blob cuando no está configurado).
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR, config } from '../src/config.js';

export const DOCS_DIR = path.join(DATA_DIR, 'documents');
fs.mkdirSync(DOCS_DIR, { recursive: true });

const clean = (p) => String(p || '').split('/').filter((s) => s && s !== '.' && s !== '..').map((s) => s.replace(/[^\w.\- ()áéíóúñÁÉÍÓÚÑ]/g, '_')).join('/');
const abs = (blobPath) => {
  const f = path.resolve(DOCS_DIR, clean(blobPath));
  if (!f.startsWith(DOCS_DIR + path.sep)) throw new Error('Ruta inválida');
  return f;
};
const sign = (p, exp) => crypto.createHmac('sha256', config.jwtSecret).update(`${p}|${exp}`).digest('hex');

export function signedUrl(origin, blobPath, ttlMs = 30 * 60 * 1000) {
  const p = clean(blobPath); const exp = Date.now() + ttlMs;
  return `${origin}/api/documents/file?p=${encodeURIComponent(p)}&e=${exp}&s=${sign(p, exp)}`;
}
export function verifySigned(p, exp, sig) {
  if (!p || !exp || !sig || Date.now() > Number(exp)) return null;
  const good = sign(clean(p), exp);
  if (good.length !== String(sig).length || !crypto.timingSafeEqual(Buffer.from(good), Buffer.from(String(sig)))) return null;
  const f = abs(p);
  return fs.existsSync(f) ? f : null;
}

const originOf = (req) => { try { const u = new URL(req.url); return config.publicApiUrl || u.origin; } catch { return config.publicApiUrl; } };

export const local = {
  async upload(req, sdk, user) {
    const raw = await req.json(); const body = raw.payload ?? raw;
    const { fileBase64, fileName, mimeType, clienteId, polizaId, carpeta, tipoDocumento } = body;
    if (!fileBase64 || !clienteId || !polizaId || !fileName) return Response.json({ error: 'fileBase64, clienteId, polizaId y fileName son requeridos' }, { status: 400 });
    const bytes = Buffer.from(fileBase64, 'base64');
    const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const folder = carpeta || 'cliente'; const docType = tipoDocumento || 'documento';
    const blobPath = `clientes/${clienteId}/polizas/${polizaId}/${folder}/${docType}_${safeName}`;
    const f = abs(blobPath); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, bytes);
    await sdk.asServiceRole.entities.AzureDocument.create({ clienteId, polizaId, carpeta: folder, tipoDocumento: docType, blobPath, nombreOriginal: fileName, mimeType: mimeType || 'application/octet-stream', size: bytes.length, uploadedBy: user.email });
    return Response.json({ ok: true, blobPath, fileName, contentType: mimeType || 'application/octet-stream', size: bytes.length, url: signedUrl(originOf(req), blobPath) });
  },
  async url(req) {
    const raw = await req.json(); const { blobPath } = raw.payload ?? raw;
    if (!blobPath) return Response.json({ error: 'blobPath es requerido' }, { status: 400 });
    if (!fs.existsSync(abs(blobPath))) return Response.json({ error: 'Archivo no encontrado en storage' }, { status: 404 });
    return Response.json({ ok: true, url: signedUrl(originOf(req), blobPath) });
  },
  async remove(req, sdk) {
    const raw = await req.json(); const { documentId, blobPath } = raw.payload ?? raw;
    if (!documentId) return Response.json({ error: 'documentId es requerido' }, { status: 400 });
    if (blobPath) { try { fs.rmSync(abs(blobPath), { force: true }); } catch { /* ya no existe */ } }
    await sdk.asServiceRole.entities.Document.delete(documentId);
    return Response.json({ ok: true });
  },
};
