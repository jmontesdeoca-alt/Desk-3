// Almacén síncrono de entidades para los módulos (sin reglas RLS: es código de servidor de confianza).
// Misma base y mismo bus de eventos que la API de entidades, así tiempo real y automatizaciones lo ven todo.
import { db, newId, nowIso } from '../src/db.js';
import { toSql, orderBy } from '../src/query.js';
import { bus, getSchema } from '../src/store.js';

export { db, bus, newId };
const DEFAULT_LIMIT = 1000, MAX_LIMIT = 20000;
const RESERVED = ['id', 'created_date', 'updated_date', 'created_by'];
const hydrate = (r) => ({ ...JSON.parse(r.data), id: r.id, created_date: r.created_date, updated_date: r.updated_date, created_by: r.created_by });
const strip = (d) => { const o = { ...d }; for (const k of RESERVED) delete o[k]; return o; };
function assertEntity(e) { if (!getSchema(e)) throw Object.assign(new Error(`Entidad desconocida: ${e}`), { status: 404 }); }
function withDefaults(entity, data) {
  const out = { ...data };
  for (const [k, def] of Object.entries(getSchema(entity)?.properties || {})) if (out[k] === undefined && def && 'default' in def) out[k] = def.default;
  return out;
}
const emit = (entity, type, rec, prev) => bus.emit('entity', { entity, type, id: rec.id, data: rec, old_data: prev ?? null, prev: prev ?? null, timestamp: nowIso() });

export const store = {
  list(entity, sort, limit, skip = 0) { return this.filter(entity, {}, sort, limit, skip); },
  filter(entity, query = {}, sort, limit, skip = 0) {
    assertEntity(entity);
    const params = [entity];
    const where = toSql(query, params);
    const lim = Math.min(Math.max(parseInt(limit, 10) || DEFAULT_LIMIT, 1), MAX_LIMIT);
    const off = Math.max(parseInt(skip, 10) || 0, 0);
    return db.prepare(`SELECT * FROM records WHERE entity = ? AND (${where}) ORDER BY ${orderBy(sort)} LIMIT ${lim} OFFSET ${off}`).all(...params).map(hydrate);
  },
  count(entity, query = {}) {
    assertEntity(entity);
    const params = [entity];
    return db.prepare(`SELECT COUNT(*) c FROM records WHERE entity = ? AND (${toSql(query, params)})`).get(...params).c;
  },
  get(entity, id) {
    assertEntity(entity);
    const row = db.prepare('SELECT * FROM records WHERE entity = ? AND id = ?').get(entity, id);
    return row ? hydrate(row) : null;
  },
  create(entity, data, { createdBy = null, silent = false } = {}) {
    assertEntity(entity);
    const ts = nowIso(), id = newId();
    db.prepare('INSERT INTO records (id, entity, data, created_date, updated_date, created_by) VALUES (?,?,?,?,?,?)').run(id, entity, JSON.stringify(withDefaults(entity, strip(data || {}))), ts, ts, createdBy);
    const rec = this.get(entity, id);
    if (!silent) emit(entity, 'create', rec);
    return rec;
  },
  bulkCreate(entity, items, opts = {}) { return db.transaction((arr) => arr.map((d) => this.create(entity, d, opts)))(items || []); },
  update(entity, id, patch, { silent = false } = {}) {
    assertEntity(entity);
    const row = db.prepare('SELECT data FROM records WHERE entity = ? AND id = ?').get(entity, id);
    if (!row) throw Object.assign(new Error(`${entity} no encontrado`), { status: 404 });
    const prev = JSON.parse(row.data);
    db.prepare('UPDATE records SET data = ?, updated_date = ? WHERE entity = ? AND id = ?').run(JSON.stringify({ ...prev, ...strip(patch || {}) }), nowIso(), entity, id);
    const rec = this.get(entity, id);
    if (!silent) emit(entity, 'update', rec, { ...prev, id });
    return rec;
  },
  bulkUpdate(entity, updates) { return db.transaction((arr) => arr.map((u) => this.update(entity, u.id, u.data ?? u)))(updates || []); },
  delete(entity, id) {
    assertEntity(entity);
    const prev = this.get(entity, id);
    const res = db.prepare('DELETE FROM records WHERE entity = ? AND id = ?').run(entity, id);
    if (res.changes && prev) emit(entity, 'delete', prev, prev);
    return { success: res.changes > 0 };
  },
  deleteMany(entity, query = {}) { const rows = this.filter(entity, query, undefined, MAX_LIMIT); rows.forEach((r) => this.delete(entity, r.id)); return { deleted: rows.length }; },
};
