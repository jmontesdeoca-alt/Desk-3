// Utilidades de plataforma para las funciones del servidor
export const secrets = { get: (name) => process.env[name] };
export const waitUntil = (p) => { Promise.resolve(p).catch((e) => console.error('waitUntil:', e)); };
