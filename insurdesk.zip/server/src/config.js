import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Secreto JWT: variable de entorno o uno generado y persistido en el volumen de datos.
function loadJwtSecret() {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  const f = path.join(DATA_DIR, '.jwt_secret');
  if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8').trim();
  const s = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}

export const config = {
  brandName: process.env.BRAND_NAME || 'InsurDesk',
  allowRegistration: process.env.ALLOW_REGISTRATION !== 'false',
  port: Number(process.env.PORT || 3001),
  jwtSecret: loadJwtSecret(),
  tokenTtl: process.env.TOKEN_TTL || '30d',
  // URL pública de la app (para enlaces en correos y callbacks OAuth)
  appUrl: (process.env.APP_URL || (process.env.APP_DOMAIN ? (process.env.APP_DOMAIN.startsWith('http') ? process.env.APP_DOMAIN : `https://${process.env.APP_DOMAIN}`) : 'http://localhost:5173')).replace(/\/$/, ''),
  // URL pública del backend (para enlaces a archivos subidos)
  publicApiUrl: (process.env.PUBLIC_API_URL || '').replace(/\/$/, ''),
  adminEmail: (process.env.ADMIN_EMAIL || '').toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  adminName: process.env.ADMIN_NAME || 'Administrador',
  mail: {
    from: process.env.MAIL_FROM || 'InsurDesk <noreply@localhost>',
    resendKey: process.env.RESEND_API_KEY === 'local-mail-relay' ? '' : (process.env.RESEND_API_KEY || ''),
    smtp: process.env.SMTP_HOST ? {
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS || '' } : undefined,
    } : null,
  },
  llm: {
    anthropicKey: process.env.ANTHROPIC_API_KEY || '',
    model: process.env.LLM_MODEL || 'claude-sonnet-5-5',
  },
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID || '',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
  },
  reportingApiKey: process.env.REPORTING_API_KEY || '',
  timezone: process.env.TZ || 'America/Guayaquil',
  schedulerEnabled: process.env.SCHEDULER_ENABLED !== 'false',
};

// Sin proveedor real, los correos de las funciones se desvían a SMTP o a la consola (ver functions.js)
export const MAIL_RELAY_MARK = 'local-mail-relay';
if (!process.env.RESEND_API_KEY) process.env.RESEND_API_KEY = MAIL_RELAY_MARK;

export const mailConfigured = () => !!(config.mail.resendKey || config.mail.smtp);
