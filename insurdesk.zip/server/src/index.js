import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { config, ROOT, UPLOAD_DIR } from './config.js';
import './db.js';
import { entityApi, canRead, bus, HttpError, publicRecord, entitiesWithoutPolicy } from './store.js';
import { auth, seedAdmin, userFromTokenSync, tokenFromHeaders, publicUser } from './auth.js';
import { loadFunctions, runHandler, hasFunction, functionNames, assertFunctionAllowed } from './functions.js';
import { startScheduler } from './scheduler.js';
import { bootModules } from '../modules/kernel.js';
import './relations.js';
import { saveBuffer, coreIntegrations } from './integrations.js';
import { summary as licenseSummary, installLicense, loadLicense, featureEnabled, featureName, current as plan } from './license.js';
import { featureForEntity, featureForIntegration } from './features.js';
import { verifySigned } from '../runtime/localdocs.js';

const app = express();
app.set('trust proxy', true);
app.disable('x-powered-by');
app.use(cors({ origin: true, credentials: true }));

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const origin = (req) => config.publicApiUrl || `${req.protocol}://${req.get('host')}`;
const currentUser = (req) => userFromTokenSync(tokenFromHeaders(req.headers) || req.query.access_token);
const requireUser = (req) => { const u = currentUser(req); if (!u) throw HttpError(401, 'Authentication required'); return u; };

app.get('/api/health', (_req, res) => res.json({ ok: true, functions: functionNames().length }));

// ---------- Funciones backend (antes de json parser: cuerpo crudo) ----------
const fnRoute = wrap(async (req, res) => {
  const name = req.params.name;
  if (!hasFunction(name)) return res.status(404).json({ error: `Función no encontrada: ${name}` });
  assertFunctionAllowed(name, false);
  const headers = { ...req.headers }; delete headers['x-internal-service']; // nunca aceptar el sello interno desde fuera
  const hasBody = !['GET', 'HEAD'].includes(req.method) && req.body && req.body.length;
  const request = new Request(`${req.protocol}://${req.get('host')}${req.originalUrl}`, { method: req.method, headers, body: hasBody ? req.body : undefined });
  const out = await runHandler(name, request);
  res.status(out.status);
  out.headers.forEach((v, k) => { if (!['content-encoding', 'content-length', 'transfer-encoding'].includes(k)) res.setHeader(k, v); });
  res.send(Buffer.from(await out.arrayBuffer()));
});
app.all(['/api/functions/:name', '/functions/:name'], express.raw({ type: () => true, limit: '40mb' }), fnRoute);

app.use(express.json({ limit: '25mb' }));

// ---------- Plan / licencia ----------
app.get('/api/license', wrap(async (req, res) => { requireUser(req); res.json(licenseSummary()); }));
app.put('/api/license', wrap(async (req, res) => {
  const u = requireUser(req);
  if (u.role !== 'admin' && u.app_role !== 'admin') throw HttpError(403, 'Solo un administrador puede instalar la licencia');
  try { installLicense(req.body?.key); } catch (e) { throw HttpError(400, e.message); }
  res.json(licenseSummary());
}));

// ---------- Auth ----------
const ar = express.Router();
ar.get('/config', (_req, res) => res.json({ app_name: config.brandName, allow_registration: config.allowRegistration, google_enabled: !!config.google.clientId }));
ar.post('/login', wrap(async (req, res) => res.json(await auth.login(req.body || {}))));
ar.post('/register', wrap(async (req, res) => res.json(await auth.register(req.body || {}))));
ar.post('/verify-otp', wrap(async (req, res) => res.json(await auth.verifyOtp(req.body || {}))));
ar.post('/resend-otp', wrap(async (req, res) => res.json(await auth.resendOtp(req.body?.email))));
ar.post('/reset-password-request', wrap(async (req, res) => res.json(await auth.resetPasswordRequest(req.body?.email))));
ar.post('/reset-password', wrap(async (req, res) => res.json(await auth.resetPassword(req.body || {}))));
ar.get('/me', wrap(async (req, res) => res.json(requireUser(req))));
ar.patch('/me', wrap(async (req, res) => res.json(await auth.updateMe(requireUser(req).id, req.body || {}))));
ar.post('/invite', wrap(async (req, res) => {
  const u = requireUser(req); const { email, role } = req.body || {};
  if (u.role !== 'admin' && u.app_role !== 'admin' && String(email).toLowerCase() !== u.email.toLowerCase()) throw HttpError(403, 'Solo un administrador puede invitar usuarios');
  res.json(await auth.inviteUser(email, role));
}));
ar.get('/google', wrap(async (req, res) => res.redirect(auth.googleAuthUrl(req.query.return_to, `${origin(req)}/api/auth/google/callback`))));
ar.get('/google/callback', wrap(async (req, res) => {
  const { token, returnTo } = await auth.googleCallback(req.query.code, req.query.state, `${origin(req)}/api/auth/google/callback`);
  const sep = returnTo.includes('?') ? '&' : '?';
  res.redirect(`${config.appUrl}${returnTo}${sep}access_token=${encodeURIComponent(token)}`);
}));
app.use('/api/auth', ar);

// ---------- Entidades ----------
const er = express.Router();
const api = (req) => entityApi(req.params.name, { user: currentUser(req) });
const parseJson = (s) => { try { return s ? JSON.parse(s) : undefined; } catch { return undefined; } };
er.get('/:name/stream', (req, res) => {
  const user = currentUser(req); if (!user) return res.status(401).end();
  { const f = featureForEntity(req.params.name); if (f && !featureEnabled(f)) return res.status(403).end(); }
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders?.(); res.write(': ok\n\n');
  const h = (ev) => { if (ev.entity === req.params.name && canRead(ev.entity, user, ev.data)) res.write(`data: ${JSON.stringify({ type: ev.type, id: ev.id, data: publicRecord(ev.entity, ev.data), old_data: publicRecord(ev.entity, ev.old_data) })}\n\n`); };
  bus.on('entity', h);
  const ping = setInterval(() => res.write(': ping\n\n'), 25000);
  req.on('close', () => { clearInterval(ping); bus.off('entity', h); });
});
er.get('/:name', wrap(async (req, res) => {
  const { q, sort, limit, skip, fields } = req.query;
  const query = parseJson(q);
  res.json(query ? await api(req).filter(query, sort, limit, skip, fields?.split(',')) : await api(req).list(sort, limit, skip, fields?.split(',')));
}));
er.post('/:name/filter', wrap(async (req, res) => { const b = req.body || {}; res.json(await api(req).filter(b.query || {}, b.sort, b.limit, b.skip, b.fields)); }));
er.post('/:name/bulk', wrap(async (req, res) => res.json(await api(req).bulkCreate(req.body))));
er.post('/:name/bulk-update', wrap(async (req, res) => res.json(await api(req).bulkUpdate(req.body))));
er.post('/:name/delete-many', wrap(async (req, res) => res.json(await api(req).deleteMany(req.body?.query || req.body || {}))));
er.post('/:name', wrap(async (req, res) => res.status(201).json(await api(req).create(req.body || {}))));
er.get('/:name/:id', wrap(async (req, res) => res.json(await api(req).get(req.params.id))));
er.put('/:name/:id', wrap(async (req, res) => res.json(await api(req).update(req.params.id, req.body || {}))));
er.patch('/:name/:id', wrap(async (req, res) => res.json(await api(req).update(req.params.id, req.body || {}))));
er.delete('/:name/:id', wrap(async (req, res) => res.json(await api(req).delete(req.params.id))));
app.use('/api/entities', (req, _res, next) => { if (!/^\/[A-Za-z0-9_]+/.test(req.path)) return next(HttpError(404, 'Entidad inválida')); next(); }, er);

// ---------- Integraciones: archivos ----------
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 60 * 1024 * 1024 } });
app.post('/api/files/upload', upload.single('file'), wrap(async (req, res) => {
  requireUser(req);
  if (!req.file) throw HttpError(400, 'Falta el archivo');
  const name = saveBuffer(req.file.buffer, req.file.originalname);
  res.json({ file_url: `${origin(req)}/files/${name}`, file_name: req.file.originalname });
}));
const ACTIVE = new Set(['.html', '.htm', '.svg', '.xml', '.xhtml', '.js', '.mjs']);
app.get('/files/:name', (req, res) => {
  const f = path.join(UPLOAD_DIR, path.basename(req.params.name));
  if (!fs.existsSync(f)) return res.status(404).end();
  res.set('X-Content-Type-Options', 'nosniff');
  if (ACTIVE.has(path.extname(f).toLowerCase())) { res.set('Content-Type', 'text/plain; charset=utf-8'); res.set('Content-Disposition', 'attachment'); }
  res.sendFile(f);
});


// ---------- Integraciones: IA, correo, extracción de datos ----------
app.post('/api/integrations/core/:name', wrap(async (req, res) => {
  requireUser(req);
  const fn = coreIntegrations[req.params.name];
  if (!fn) throw HttpError(404, 'Integración no encontrada');
  { const f = featureForIntegration(req.params.name); if (f && !featureEnabled(f)) throw HttpError(403, `"${featureName(f)}" no está incluido en tu plan (${plan().planName})`, 'feature_disabled'); }
  res.json(await fn(req.body || {}));
}));

// ---------- Documentos de pólizas (almacenamiento local, enlaces firmados) ----------
app.get('/api/documents/file', (req, res) => {
  const f = verifySigned(req.query.p, req.query.e, req.query.s);
  if (!f) return res.status(403).send('Enlace inválido o vencido');
  res.set('X-Content-Type-Options', 'nosniff');
  const ext = path.extname(f).toLowerCase();
  if (ACTIVE.has(ext)) { res.set('Content-Type', 'text/plain; charset=utf-8'); }
  res.sendFile(f);
});

loadLicense();
await loadFunctions();
await bootModules(app);
{ const open = entitiesWithoutPolicy(); if (open.length) console.warn(`⚠ Entidades sin política de acceso (solo admin): ${open.join(', ')}`); }

// ---------- Frontend compilado (despliegue de un solo proceso) ----------
const dist = path.resolve(ROOT, '..', 'web', 'dist');
if (fs.existsSync(path.join(dist, 'index.html'))) {
  app.use(express.static(dist, { maxAge: '1h', index: false }));
  app.get(/^\/(?!api\/|files\/|functions\/).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ message: err.message || 'Error interno', error: err.message || 'Error interno', ...(err.code ? { code: err.code } : {}) });
});

await seedAdmin();
startScheduler();
app.listen(config.port, () => console.log(`✔ InsurDesk API escuchando en :${config.port}`));
