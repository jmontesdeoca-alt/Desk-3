import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import nodemailer from 'nodemailer';
import * as XLSX from 'xlsx';
import { config, mailConfigured, UPLOAD_DIR } from './config.js';

// ---------- Correo ----------
let smtpTransport;
export async function sendEmail({ to, subject, body, html, text, from_name, cc, bcc, from, reply_to }) {
  const list = (v) => (v ? (Array.isArray(v) ? v : String(v).split(',').map((s) => s.trim()).filter(Boolean)) : []);
  const toList = list(to);
  if (!toList.length) throw new Error('SendEmail: falta destinatario (to)');
  const htmlBody = html || body || '';
  const sender = from || (from_name ? `${from_name} <${(config.mail.from.match(/<(.+)>/) || [])[1] || config.mail.from}>` : config.mail.from);

  if (config.mail.resendKey) {
    const payload = { from: sender, to: toList, subject: subject || '(sin asunto)', html: htmlBody, text };
    if (list(cc).length) payload.cc = list(cc);
    if (list(bcc).length) payload.bcc = list(bcc);
    if (reply_to) payload.reply_to = reply_to;
    const r = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${config.mail.resendKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`Resend (${r.status}): ${j.message || JSON.stringify(j)}`);
    return { success: true, id: j.id };
  }
  if (config.mail.smtp) {
    smtpTransport ||= nodemailer.createTransport(config.mail.smtp);
    const info = await smtpTransport.sendMail({ from: sender, to: toList, cc: list(cc), bcc: list(bcc), subject, html: htmlBody, text, replyTo: reply_to });
    return { success: true, id: info.messageId };
  }
  console.warn(`[correo no configurado] Para: ${toList.join(', ')} | Asunto: ${subject}\n${String(text || htmlBody).replace(/<[^>]+>/g, ' ').slice(0, 400)}`);
  return { success: true, logged: true };
}
export { mailConfigured };

// ---------- Archivos ----------
export function saveBuffer(buf, originalName = 'file') {
  const ext = path.extname(originalName).slice(0, 12).replace(/[^.\w]/g, '');
  const name = `${crypto.randomBytes(16).toString('hex')}${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  return name;
}
export const fileUrl = (name, base = '') => `${base || config.publicApiUrl}/files/${name}`;

async function readFileFromUrl(url) {
  const m = String(url).match(/\/files\/([\w.\-]+)$/);
  if (m) return { buf: fs.readFileSync(path.join(UPLOAD_DIR, path.basename(m[1]))), name: m[1] };
  const r = await fetch(url);
  if (!r.ok) throw new Error(`No se pudo descargar el archivo (${r.status})`);
  return { buf: Buffer.from(await r.arrayBuffer()), name: String(url).split('/').pop().split('?')[0] };
}

// Extrae filas de un Excel/CSV subido; devuelve { status, output } con la forma del esquema pedido.
export async function extractDataFromUploadedFile({ file_url, json_schema }) {
  const { buf } = await readFileFromUrl(file_url);
  const wb = XLSX.read(buf, { type: 'buffer', cellDates: true });
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: null });
  const arrayKey = Object.keys(json_schema?.properties || {}).find((k) => json_schema.properties[k]?.type === 'array');
  return { status: 'success', output: arrayKey ? { [arrayKey]: rows } : rows };
}

// ---------- IA ----------
export async function invokeLLM({ prompt, response_json_schema, file_urls, model, system }) {
  if (!config.llm.anthropicKey) throw new Error('IA no configurada: define ANTHROPIC_API_KEY en el servidor');
  let userPrompt = String(prompt || '');
  if (response_json_schema) userPrompt += `\n\nResponde ÚNICAMENTE con JSON válido que cumpla este esquema, sin texto adicional ni bloques de código:\n${JSON.stringify(response_json_schema)}`;
  const content = [];
  for (const u of file_urls || []) {
    try {
      const { buf, name } = await readFileFromUrl(u);
      const ext = path.extname(name).toLowerCase();
      if (['.png', '.jpg', '.jpeg', '.webp', '.gif'].includes(ext)) content.push({ type: 'image', source: { type: 'base64', media_type: `image/${ext === '.jpg' ? 'jpeg' : ext.slice(1)}`, data: buf.toString('base64') } });
      else if (ext === '.pdf') content.push({ type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: buf.toString('base64') } });
    } catch (e) { console.warn('InvokeLLM: archivo omitido', e.message); }
  }
  content.push({ type: 'text', text: userPrompt });
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': config.llm.anthropicKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: config.llm.model, max_tokens: 4096, ...(system ? { system } : {}), messages: [{ role: 'user', content }] }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(`LLM (${r.status}): ${j.error?.message || JSON.stringify(j)}`);
  const text = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n').trim();
  if (!response_json_schema) return text;
  try { return JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch { throw new Error('La IA no devolvió JSON válido'); }
}

export const coreIntegrations = {
  SendEmail: (p) => sendEmail(p),
  InvokeLLM: (p) => invokeLLM(p),
  ExtractDataFromUploadedFile: (p) => extractDataFromUploadedFile(p),
};
