// Middleware de sesión para rutas Express de los módulos
import { userFromTokenSync, tokenFromHeaders } from './auth.js';

export const isAdmin = (u) => !!u && (u.role === 'admin' || u.app_role === 'admin');

export function requireAuth(req, res, next) {
  const user = userFromTokenSync(tokenFromHeaders(req.headers));
  if (!user) return res.status(401).json({ error: 'No autenticado', message: 'Authentication required' });
  req.user = user;
  next();
}
