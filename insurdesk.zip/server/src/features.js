// Qué entidades y funciones pertenecen a cada función del plan, y qué módulos hay instalados.
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from './config.js';
import { featureEnabled } from './license.js';

// Núcleo: funciones que se pueden apagar por plan
const ENTITY_FEATURE = {
  ReportTemplate: 'custom_reports',
  Incentive: 'incentives',
  SalesTarget: 'sales_targets', CompanyBudget: 'sales_targets',
  AgentCost: 'agent_profitability',
  Message: 'messaging',
};
const FUNCTION_FEATURE = {
  sendMonthlyIncentiveFollowup: 'incentives',
  sendMonthlyBudgetFollowup: 'sales_targets',
  clientPortalData: 'client_portal', clientPortalOTP: 'client_portal',
  aiQueryData: 'ai',
};
const INTEGRATION_FEATURE = { InvokeLLM: 'ai' };
const ENTITY_ACCESS = {};            // entidad -> 'crm' (requiere acceso al CRM)
const ADMIN_ONLY = new Set();        // entidades con credenciales de terceros

/** Entidades cuyo número de registros activos limita el plan: entidad -> { función del plan, sustantivo } */
export const ENTITY_LIMIT = { Pipeline: { feature: 'crm_pipelines', noun: 'pipeline(s) activo(s)' } };

// Módulos: server/modules/<id>/module.json
//   { id, name, feature, access?, schedules?, admin_only_entities?, entity_features?, function_features? }
// con subcarpetas opcionales schemas/ (*.json), functions/ (<n>.js o <n>/entry.ts), workflows/ y un index.js con register(ctx).
export const modules = [];
const modulesDir = path.join(ROOT, 'modules');
const names = (dir, re) => (fs.existsSync(dir) ? fs.readdirSync(dir) : []).filter((f) => !re || re.test(f));
if (fs.existsSync(modulesDir)) {
  for (const d of fs.readdirSync(modulesDir)) {
    if (d.startsWith('_') || d.startsWith('.')) continue;
    const manifest = path.join(modulesDir, d, 'module.json');
    if (!fs.existsSync(manifest)) continue;
    try {
      const m = JSON.parse(fs.readFileSync(manifest, 'utf8'));
      const dir = path.join(modulesDir, d);
      m.dir = dir; m.id ||= m.key || d; m.feature ||= m.id; m.schedules ||= [];
      for (const f of names(path.join(dir, 'schemas'), /\.jsonc?$/)) {
        const e = f.replace(/\.jsonc?$/, '');
        ENTITY_FEATURE[e] = m.entity_features?.[e] || m.feature;
        if (m.access) ENTITY_ACCESS[e] = m.access;
      }
      for (const f of names(path.join(dir, 'functions'))) {
        const fn = f.replace(/\.(js|ts)$/, '');
        FUNCTION_FEATURE[fn] = m.function_features?.[fn] || m.feature;
      }
      (m.admin_only_entities || []).forEach((e) => ADMIN_ONLY.add(e));
      modules.push(m);
    } catch (e) { console.warn(`Módulo inválido (${d}):`, e.message); }
  }
  modules.sort((a, b) => (a.order ?? 100) - (b.order ?? 100));
}
if (modules.length) console.log(`✔ Módulos: ${modules.map((m) => m.id).join(', ')}`);

export const featureForEntity = (e) => ENTITY_FEATURE[e];
export const featureForFunction = (f) => FUNCTION_FEATURE[f];
export const featureForIntegration = (i) => INTEGRATION_FEATURE[i];
export const functionEnabled = (name) => { const f = FUNCTION_FEATURE[name]; return !f || featureEnabled(f); };
export const entityEnabled = (name) => { const f = ENTITY_FEATURE[name]; return !f || featureEnabled(f); };
export const isAdminOnlyEntity = (e) => ADMIN_ONLY.has(e);
export const entityAccess = (e) => ENTITY_ACCESS[e];
export const moduleEnabled = (id) => { const m = modules.find((x) => x.id === id); return !!m && featureEnabled(m.feature); };

const ADMIN = (u) => !!u && (u.role === 'admin' || u.app_role === 'admin');
/** Acceso al CRM: administradores siempre; el resto, con el interruptor del usuario encendido. */
export const hasCrmAccess = (u) => ADMIN(u) || u?.crm_access_enabled === true;
