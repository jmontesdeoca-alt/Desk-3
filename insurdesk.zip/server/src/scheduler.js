import fs from 'node:fs';
import path from 'node:path';
import cron from 'node-cron';
import { ROOT, config } from './config.js';
import { bus } from './store.js';
import { invokeFunction, hasFunction, workflowContext, functionEnabled } from './functions.js';
import { modules } from './features.js';
import { isEnabled } from '../modules/kernel.js';

function steps(def) {
  return (def?.do || []).map((s) => Object.values(s)[0]).filter((s) => s?.with?.function_name).map((s) => ({ fn: s.with.function_name, args: s.with.args || {} }));
}

async function run(wf, payload) {
  const parent = workflowContext.getStore() || new Set();
  await workflowContext.run(new Set([...parent, wf.name]), async () => {
    for (const st of wf.steps) {
      if (!functionEnabled(st.fn)) continue; // función fuera del plan
      if (!hasFunction(st.fn)) { console.warn(`[workflow ${wf.name}] función inexistente: ${st.fn}`); continue; }
      try { await invokeFunction(st.fn, { ...st.args, ...payload }, { service: true }); }
      catch (e) { console.error(`[workflow ${wf.name}] ${st.fn} falló:`, e.message); }
    }
  });
}

export function startScheduler() {
  if (!config.schedulerEnabled) { console.log('Scheduler desactivado'); return; }
  const wfDirs = [path.join(ROOT, 'workflows')];
  const modRoot = path.join(ROOT, 'modules');
  if (fs.existsSync(modRoot)) for (const d of fs.readdirSync(modRoot)) { if (!d.startsWith('_') && fs.existsSync(path.join(modRoot, d, 'workflows'))) wfDirs.push(path.join(modRoot, d, 'workflows')); }
  const entityWfs = [];
  let scheduled = 0;
  for (const dir of wfDirs) for (const f of fs.readdirSync(dir)) {
    let j; try { j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch { continue; }
    const c = j.trigger?.config || {};
    const wf = { name: j.name || f, steps: steps(j.definition) };
    if (c.trigger_type === 'entity') entityWfs.push({ ...wf, entity: c.entity_name, events: c.events || [] });
    else if (c.trigger_type === 'scheduled' && c.cron_expression && cron.validate(c.cron_expression)) {
      cron.schedule(c.cron_expression, () => run(wf, {}), { timezone: c.timezone || 'UTC' });
      scheduled++;
    }
  }
  for (const m of modules) {
    for (const t of m.schedules || []) {
      if (!cron.validate(t.cron)) continue;
      cron.schedule(t.cron, () => {
        if (!isEnabled(m.id)) return;
        invokeFunction(t.function, {}, { service: true }).catch((e) => console.error(`[cron ${m.id}/${t.function}]`, e.message));
      }, { timezone: config.timezone });
      scheduled++;
    }
  }
  bus.on('entity', (ev) => {
    for (const wf of entityWfs) {
      if (wf.entity !== ev.entity || !wf.events.includes(ev.type)) continue;
      if (workflowContext.getStore()?.has(wf.name)) continue; // evita bucles
      const payload = { event: { type: ev.type, entity_name: ev.entity, entity_id: ev.id }, data: ev.type === 'delete' ? null : ev.data, old_data: ev.old_data };
      setImmediate(() => run(wf, payload));
    }
  });
  console.log(`✔ Scheduler: ${scheduled} tareas programadas, ${entityWfs.length} disparadores por evento`);
}
