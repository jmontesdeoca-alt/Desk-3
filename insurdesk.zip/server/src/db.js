import Database from 'better-sqlite3';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR } from './config.js';

export const db = new Database(path.join(DATA_DIR, 'insurdesk.db'));
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');

// Almacén genérico de documentos: cada entidad vive como JSON en `records`.
db.exec(`
CREATE TABLE IF NOT EXISTS records (
  id           TEXT PRIMARY KEY,
  entity       TEXT NOT NULL,
  data         TEXT NOT NULL,
  created_date TEXT NOT NULL,
  updated_date TEXT NOT NULL,
  created_by   TEXT
);
CREATE INDEX IF NOT EXISTS idx_records_entity_created ON records(entity, created_date);

CREATE TABLE IF NOT EXISTS credentials (
  user_id       TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT,
  verified      INTEGER NOT NULL DEFAULT 0,
  otp_code      TEXT,
  otp_expires   INTEGER,
  reset_token   TEXT,
  reset_expires INTEGER,
  google_sub    TEXT
);

CREATE TABLE IF NOT EXISTS connections (
  user_id    TEXT NOT NULL,
  connector  TEXT NOT NULL,
  data       TEXT NOT NULL,
  PRIMARY KEY (user_id, connector)
);

CREATE TABLE IF NOT EXISTS kv (
  k TEXT PRIMARY KEY,
  v TEXT
);
`);

// Función REGEXP/regex_match para $regex
db.function('regex_match', { deterministic: true }, (pattern, value, flags) => {
  if (value === null || value === undefined) return 0;
  try { return new RegExp(String(pattern), flags || '').test(String(value)) ? 1 : 0; } catch { return 0; }
});

export const newId = () => crypto.randomBytes(12).toString('hex');
export const nowIso = () => new Date().toISOString();
