import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DATA_DIR, ROOT } from './config.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_KEY = fs.readFileSync(path.join(here, 'license-public.pem'), 'utf8');
export const catalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'plans.json'), 'utf8'));
const KEY_FILE = path.join(DATA_DIR, 'license.key');
const b64u = (b) => Buffer.from(b).toString('base64url');

// Formato: GA1.<payload base64url>.<firma Ed25519 base64url>
export function verifyLicense(token) {
  const parts = String(token || '').trim().split('.');
  if (parts.length !== 3 || parts[0] !== 'GA1') throw new Error('Formato de licencia inválido');
  const ok = crypto.verify(null, Buffer.from(parts[1]), PUBLIC_KEY, Buffer.from(parts[2], 'base64url'));
  if (!ok) throw new Error('La firma de la licencia no es válida');
  const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  if (!catalog.plans[payload.plan]) throw new Error(`La licencia referencia un plan desconocido: ${payload.plan}`);
  if (payload.exp && Date.now() > payload.exp) throw new Error('La licencia está vencida');
  return payload;
}

let state = null;
export function loadLicense() {
  const token = process.env.LICENSE_KEY || (fs.existsSync(KEY_FILE) ? fs.readFileSync(KEY_FILE, 'utf8') : '');
  let source = 'none', payload = null, warning = null;
  if (token) {
    try { payload = verifyLicense(token); source = 'license'; }
    catch (e) { warning = e.message; }
  }
  if (!payload) {
    // Sin licencia válida: en desarrollo se puede forzar un plan con PLAN=...; en producción, Nivel 1.
    const forced = process.env.PLAN;
    if (forced && catalog.plans[forced] && process.env.NODE_ENV !== 'production') { payload = { plan: forced, customer: 'desarrollo' }; source = 'env'; }
    else { payload = { plan: 'nivel1', customer: null }; source = 'unlicensed'; }
  }
  const plan = catalog.plans[payload.plan];
  const values = { ...plan.features, ...(payload.overrides || {}) };
  state = { plan: payload.plan, planName: plan.name, tagline: plan.tagline, customer: payload.customer || null, expires: payload.exp || null, source, warning, values };
  if (warning) console.warn(`⚠ Licencia: ${warning} — se usa ${state.planName}`);
  console.log(`✔ Plan activo: ${state.planName}${state.customer ? ` (${state.customer})` : ''} [${source}]`);
  return state;
}
export const current = () => state || loadLicense();

export function installLicense(token) {
  verifyLicense(token);               // lanza si no es válida
  fs.writeFileSync(KEY_FILE, String(token).trim(), { mode: 0o600 });
  return loadLicense();
}

// ---- consulta de funciones ----
export function limitOf(key) {
  const v = current().values[key];
  if (v === null) return Infinity;
  if (typeof v === 'number') return v;
  return v ? Infinity : 0;
}
export function featureEnabled(key) {
  const def = catalog.features[key];
  if (!def) return true;                       // función no catalogada = abierta
  const v = current().values[key];
  if (def.type === 'limit') return v === null || (typeof v === 'number' && v > (def.enabledWhenAbove ?? 0));
  return v === true;
}
export const featureName = (key) => catalog.features[key]?.name || key;

// Resumen para el frontend
export function summary() {
  const s = current();
  const features = {};
  for (const [k, def] of Object.entries(catalog.features)) {
    features[k] = { name: def.name, description: def.description, type: def.type, unit: def.unit || null, enabled: featureEnabled(k), limit: def.type === 'limit' ? (s.values[k] === null ? null : s.values[k]) : undefined, external: !!def.externalModule };
  }
  return { plan: s.plan, planName: s.planName, tagline: s.tagline, customer: s.customer, expires: s.expires, source: s.source, warning: s.warning, features };
}
