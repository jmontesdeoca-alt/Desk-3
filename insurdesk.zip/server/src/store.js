import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { db, newId, nowIso } from './db.js';
import { ROOT } from './config.js';
import { toSql, orderBy, matchQuery } from './query.js';

const POLICIES = JSON.parse(fs.readFileSync(path.join(ROOT, 'policies.json'), 'utf8')).entities;
import { featureForEntity, isAdminOnlyEntity, entityAccess, hasCrmAccess, ENTITY_LIMIT } from './features.js';
import { featureEnabled, featureName, current as plan, limitOf } from './license.js';

export const bus = new EventEmitter();
// Ganchos de integridad (los registra relations.js): antes de escribir y antes de borrar
export const hooks = { beforeWrite: [], beforeDelete: [] };
bus.setMaxListeners(0);

// ---------- esquemas (valores por defecto y reglas RLS) ----------
const schemas = {};
const schemaDir = path.join(ROOT, 'schemas');
const schemaDirs = [schemaDir];
const modRoot = path.join(ROOT, 'modules');
if (fs.existsSync(modRoot)) for (const d of fs.readdirSync(modRoot)) { if (!d.startsWith('_') && fs.existsSync(path.join(modRoot, d, 'schemas'))) schemaDirs.push(path.join(modRoot, d, 'schemas')); }
for (const dir of schemaDirs) for (const f of fs.readdirSync(dir)) {
  if (!/\.jsonc?$/.test(f) || f.startsWith('_')) continue;
  try { const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); schemas[j.name || f.replace(/\.jsonc?$/, '')] = j; } catch (e) { console.warn('Esquema inválido', f, e.message); }
}
export const getSchema = (name) => schemas[name] || null;
export const entityNames = () => Object.keys(schemas);

const BUILTIN = ['id', 'created_date', 'updated_date', 'created_by'];
const HttpError = (status, message, code) => Object.assign(new Error(message), { status, ...(code ? { code } : {}) });
export { HttpError };

function rowToRecord(r, fields) {
  const o = JSON.parse(r.data);
  const rec = { id: r.id, created_date: r.created_date, updated_date: r.updated_date, created_by: r.created_by, ...o };
  if (Array.isArray(fields) && fields.length) { const out = {}; for (const k of [...fields, 'id']) if (k in rec) out[k] = rec[k]; return out; }
  return rec;
}
const splitData = (obj) => { const d = { ...obj }; for (const k of BUILTIN) delete d[k]; delete d.entity_name; return d; };

// ---------- RLS ----------
function substitute(v, ctx) {
  if (typeof v === 'string') {
    const g = v.match(/^\{\{\s*(agent_id|team_agent_ids|team_user_ids)\s*\}\}$/);
    if (g) { const x = g[1] === 'agent_id' ? ctx.agentId : g[1] === 'team_agent_ids' ? ctx.teamAgentIds : ctx.teamUserIds; return x == null ? '__none__' : x; }
    const m = v.match(/^\{\{\s*user\.([\w.]+)\s*\}\}$/);
    if (m) { const p = m[1].split('.'); let cur = { ...ctx.user, data: ctx.roleData }; for (const k of p) cur = cur == null ? undefined : cur[k]; return cur === undefined ? '__none__' : cur; }
    return v;
  }
  if (Array.isArray(v)) return v.map((x) => substitute(x, ctx));
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, substitute(x, ctx)]));
  return v;
}
function userCondition(cond, ctx) {
  return Object.entries(cond).every(([k, expected]) => {
    let actual;
    if (k.startsWith('data.')) actual = ctx.roleData?.[k.slice(5)];
    else actual = ctx.user?.[k] ?? ctx.roleData?.[k];
    if (expected && typeof expected === 'object' && expected.$in) return expected.$in.includes(actual);
    return actual === expected;
  });
}
// devuelve true (permitido sin filtro), false (denegado) o una consulta que limita los registros
export function evalRule(rule, ctx) {
  if (rule == null) return true;
  const keys = Object.keys(rule);
  if (!keys.length) return true;
  const queries = [];
  for (const key of keys) {
    const val = rule[key];
    if (key === 'user_condition') { if (!userCondition(val, ctx)) return false; continue; }
    if (key === '$or') {
      const branches = val.map((r) => evalRule(r, ctx));
      if (branches.some((b) => b === true)) continue;
      const qs = branches.filter((b) => b && typeof b === 'object');
      if (!qs.length) return false;
      queries.push(qs.length === 1 ? qs[0] : { $or: qs });
      continue;
    }
    if (key === '$and') {
      const branches = val.map((r) => evalRule(r, ctx));
      if (branches.some((b) => b === false)) return false;
      const qs = branches.filter((b) => b && typeof b === 'object');
      if (qs.length) queries.push({ $and: qs });
      continue;
    }
    queries.push({ [key]: substitute(val, ctx) });
  }
  if (!queries.length) return true;
  return queries.length === 1 ? queries[0] : { $and: queries };
}

// Estructura: el agente y todos sus descendientes (solo si el plan incluye estructura)
function teamAgentIdsFor(agentId) {
  if (!agentId) return [];
  if (limitOf('structure') <= 1) return [agentId];
  const seen = new Set([agentId]);
  let frontier = [agentId];
  while (frontier.length && seen.size < 5000) {
    const ph = frontier.map(() => '?').join(',');
    frontier = db.prepare(`SELECT id FROM records WHERE entity='Agent' AND json_extract(data,'$.upline_agent_id') IN (${ph})`).all(...frontier).map((r) => r.id).filter((id) => !seen.has(id));
    frontier.forEach((id) => seen.add(id));
  }
  return [...seen];
}
function teamUserIdsFor(agentIds, user) {
  const ids = new Set(user?.id ? [user.id] : []);
  if (agentIds.length) {
    const ph = agentIds.map(() => '?').join(',');
    const emails = db.prepare(`SELECT lower(json_extract(data,'$.email')) e FROM records WHERE entity='UserRole' AND json_extract(data,'$.agent_id') IN (${ph})`).all(...agentIds).map((r) => r.e).filter(Boolean);
    if (emails.length) {
      const p2 = emails.map(() => '?').join(',');
      db.prepare(`SELECT id FROM records WHERE entity='User' AND lower(json_extract(data,'$.email')) IN (${p2})`).all(...emails).forEach((r) => ids.add(r.id));
    }
  }
  return [...ids];
}
function makeCtx(user) {
  const roleData = roleDataFor(user);
  let team, teamUsers;
  return {
    user, roleData,
    get agentId() { return roleData.agent_id || null; },
    get teamAgentIds() { return (team ||= teamAgentIdsFor(roleData.agent_id)); },
    get teamUserIds() { return (teamUsers ||= teamUserIdsFor(this.teamAgentIds, user)); },
  };
}

// Convierte el alcance de un rol (all/own/team/team_or_all) en: true | false | consulta
function scopeToRule(pol, scope, c) {
  switch (scope) {
    case 'all': return true;
    case 'own': return pol.own ? substitute(pol.own, c) : false;
    case 'team': { const f = pol.team || pol.own; return f ? substitute(f, c) : false; }
    case 'team_or_all': { if (!c.agentId) return true; const f = pol.team || pol.own; return f ? substitute(f, c) : false; }
    default: return false;
  }
}
/** Regla efectiva de una operación: matriz central (policies.json) -> regla heredada del esquema -> denegar (salvo admin). */
export function resolveRule(entity, op, c, isAdmin) {
  const pol = POLICIES[entity];
  if (pol) {
    const roleKey = pol.by === 'crm_role' ? (c.user?.crm_role || null) : (isAdmin ? 'admin' : (c.roleData?.app_role || c.user?.app_role));
    return scopeToRule(pol, pol[op]?.[roleKey], c);
  }
  const legacy = schemas[entity]?.rls?.[op];
  if (legacy !== undefined) return evalRule(legacy, c);
  return !!isAdmin; // seguro por defecto
}
export const entitiesWithoutPolicy = () => Object.keys(schemas).filter((e) => !POLICIES[e] && !schemas[e]?.rls);

const HIDDEN_FIELDS = { UserCalendarConnection: ['access_token', 'refresh_token'], UserRole: ['mfa_secret', 'mfa_email_code', 'mfa_email_code_expires'] };
/** Quita campos que nunca deben salir al navegador. */
export function publicRecord(entity, rec) {
  const h = HIDDEN_FIELDS[entity];
  if (!h || !rec) return rec;
  const c = { ...rec };
  for (const k of h) delete c[k];
  return c;
}

function roleDataFor(user) {
  if (!user?.email) return {};
  const row = db.prepare(`SELECT data FROM records WHERE entity='UserRole' AND lower(json_extract(data,'$.email'))=lower(?) LIMIT 1`).get(user.email);
  return row ? JSON.parse(row.data) : {};
}

// ---------- API de entidad ----------
export function entityApi(entity, ctx = {}) {
  const service = !!ctx.service;
  const user = ctx.user || null;
  const schema = schemas[entity];
  let _ctx;
  const rlsCtx = () => (_ctx ||= makeCtx(user));

  const rule = (op) => {
    if (service) return true;
    if (!user) {
      throw HttpError(401, 'Authentication required');
    }
    const c = rlsCtx();
    const isAdmin = user.role === 'admin' || c.roleData?.app_role === 'admin';
    // Cuentas sin rol activo (recién registradas) no acceden a datos de negocio
    if (!isAdmin && c.roleData?.status !== 'active') {
      if (entity === 'User' || entity === 'UserRole') {
        if (op === 'read') return { $or: [{ email: user.email }, { id: user.id }] };
      }
      throw HttpError(403, 'Tu cuenta aún no ha sido activada por un administrador');
    }
    return resolveRule(entity, op, c, isAdmin);
  };
  const isAdminUser = () => service || user?.role === 'admin' || rlsCtx().roleData?.app_role === 'admin';
  const PROTECTED = { User: ['role', 'email'], UserRole: ['app_role', 'status', 'agent_id', 'crm_access_enabled', 'email', 'mfa_enabled', 'mfa_method', 'mfa_secret'] };
  const checkProtected = (d, op) => {
    if (isAdminUser()) return;
    for (const f of PROTECTED[entity] || []) {
      if (d && d[f] !== undefined) {
        if (op === 'update' && entity === 'User' && f === 'email') continue;
        throw HttpError(403, `Solo un administrador puede modificar "${f}"`);
      }
    }
  };
  const gate = () => {
    if (service) return;
    const f = featureForEntity(entity);
    if (f && !featureEnabled(f)) throw HttpError(403, `"${featureName(f)}" no está incluido en tu plan (${plan().planName})`, 'feature_disabled');
    if (entityAccess(entity) === 'crm' && !hasCrmAccess(user)) throw HttpError(403, 'No tienes acceso al CRM', 'no_crm_access');
    if (isAdminOnlyEntity(entity) && !isAdminUser()) throw HttpError(403, 'Solo un administrador puede acceder a esta configuración');
  };
  const hide = (rec) => (service ? rec : publicRecord(entity, rec));
  const guard = (op) => { gate(); const r = rule(op); if (r === false) throw HttpError(403, `No tienes permiso para ${op} en ${entity}`); return r; };

  const select = (query, sort, limit, skip, fields, rlsQuery) => {
    const params = [entity];
    let where = `entity = ?`;
    where += ` AND (${toSql(query, params)})`;
    if (rlsQuery && typeof rlsQuery === 'object') where += ` AND (${toSql(rlsQuery, params)})`;
    let sql = `SELECT * FROM records WHERE ${where} ORDER BY ${orderBy(sort)}`;
    const lim = limit == null ? -1 : Math.max(0, Number(limit));
    sql += ` LIMIT ${lim}`;
    if (skip) sql += ` OFFSET ${Math.max(0, Number(skip))}`;
    return db.prepare(sql).all(...params).map((r) => hide(rowToRecord(r, fields)));
  };

  const emit = (type, rec, old) => bus.emit('entity', { entity, type, id: rec.id, data: rec, old_data: old ?? null, prev: old ?? null, timestamp: nowIso() });

  const applyDefaults = (d) => {
    const props = schema?.properties || {};
    for (const [k, def] of Object.entries(props)) if (d[k] === undefined && def && def.default !== undefined) d[k] = def.default;
    return d;
  };

  // Límite de niveles de estructura (licencia). Aplica también al rol de servicio.
  const levelsBelow = (id) => {
    let level = 0, frontier = [id];
    while (frontier.length && level < 60) {
      const ph = frontier.map(() => '?').join(',');
      frontier = db.prepare(`SELECT id FROM records WHERE entity='Agent' AND json_extract(data,'$.upline_agent_id') IN (${ph})`).all(...frontier).map((r) => r.id);
      if (frontier.length) level++;
    }
    return level;
  };
  const checkStructure = (next, id, prev) => {
    if (entity !== 'Agent') return;
    const up = next.upline_agent_id;
    if (!up) return;
    if (prev && prev.upline_agent_id === up) return;       // sin cambio de upline: no se penalizan datos existentes
    const max = limitOf('structure');
    if (max <= 1) throw HttpError(403, `Tu plan (${plan().planName}) no incluye estructura de agentes: todos los agentes son de un solo nivel`, 'limit_exceeded');
    let depth = 1, cur = up; const seen = new Set(id ? [id] : []);
    while (cur) {
      if (seen.has(cur)) throw HttpError(400, 'La jerarquía no puede ser circular');
      seen.add(cur); depth++;
      cur = db.prepare(`SELECT json_extract(data,'$.upline_agent_id') u FROM records WHERE id=? AND entity='Agent'`).get(cur)?.u;
      if (depth > 60) break;
    }
    const total = depth + (id ? levelsBelow(id) : 0);
    if (total > max) throw HttpError(403, `Tu plan (${plan().planName}) permite hasta ${max} niveles de estructura; esta operación llegaría a ${total}`, 'limit_exceeded');
  };

  // Límite de registros activos por plan (p. ej. pipelines). Aplica también al rol de servicio.
  const checkEntityLimit = (excludeId) => {
    const lim = ENTITY_LIMIT[entity];
    if (!lim) return;
    const max = limitOf(lim.feature);
    if (!Number.isFinite(max)) return;
    const n = db.prepare(`SELECT COUNT(*) c FROM records WHERE entity=? AND id != ? AND COALESCE(json_extract(data,'$.is_active'),1) != 0`).get(entity, excludeId || '').c;
    if (n >= max) throw HttpError(403, `Tu plan (${plan().planName}) permite hasta ${max} ${lim.noun}`, 'limit_exceeded');
  };

  const insert = (obj) => {
    checkStructure(splitData(obj), null, null);
    if (ENTITY_LIMIT[entity] && obj.is_active !== false) checkEntityLimit();
    const id = newId(); const ts = nowIso();
    const data = applyDefaults(splitData(obj));
    for (const h of hooks.beforeWrite) h(entity, 'create', data, null, { service, id: null });
    const createdBy = (service ? obj.created_by : null) || user?.email || 'system';
    db.prepare(`INSERT INTO records (id, entity, data, created_date, updated_date, created_by) VALUES (?,?,?,?,?,?)`).run(id, entity, JSON.stringify(data), ts, ts, createdBy);
    const rec = { id, created_date: ts, updated_date: ts, created_by: createdBy, ...data };
    return rec;
  };

  const api = {
    async list(sort, limit, skip, fields) {
      const r = guard('read');
      return select({}, sort, limit, skip, fields, r);
    },
    async filter(query, sort, limit, skip, fields) {
      const r = guard('read');
      return select(query || {}, sort, limit, skip, fields, r);
    },
    async get(id) {
      const r = guard('read');
      const rows = select({ id }, null, 1, 0, null, r);
      if (!rows.length) throw HttpError(404, `${entity} no encontrado`);
      return rows[0];
    },
    async create(obj) {
      const r = guard('create');
      if (!service && entity === 'UserRole' && !isAdminUser()) throw HttpError(403, 'Solo un administrador puede crear roles');
      if (!service) checkProtected(obj, 'create');
      if (r && typeof r === 'object' && !service) {
        const probe = { ...splitData(obj || {}), created_by: user?.email, id: undefined };
        if (!matchQuery(probe, r)) throw HttpError(403, `No tienes permiso para create en ${entity}`);
      }
      const rec = insert(obj || {});
      emit('create', rec);
      return hide(rec);
    },
    async bulkCreate(arr) {
      const r = guard('create');
      if (!service && entity === 'UserRole' && !isAdminUser()) throw HttpError(403, 'Solo un administrador puede crear roles');
      if (!service) (arr || []).forEach((o) => checkProtected(o, 'create'));
      const out = [];
      const tx = db.transaction(() => { for (const o of arr || []) { if (r && typeof r === 'object' && !service && !matchQuery({ ...splitData(o), created_by: user?.email }, r)) throw HttpError(403, `No tienes permiso para create en ${entity}`); out.push(insert(o)); } });
      tx();
      out.forEach((rec) => emit('create', rec));
      return out.map(hide);
    },
    async update(id, patch) {
      const r = guard('update');
      if (!service) checkProtected(patch, 'update');
      const row = db.prepare(`SELECT * FROM records WHERE id=? AND entity=?`).get(id, entity);
      if (!row) throw HttpError(404, `${entity} no encontrado`);
      const old = rowToRecord(row);
      if (r && typeof r === 'object' && !matchQuery(old, r)) throw HttpError(403, `No tienes permiso para update en ${entity}`);
      const merged = { ...JSON.parse(row.data), ...splitData(patch || {}) };
      checkStructure(merged, id, JSON.parse(row.data));
      for (const h of hooks.beforeWrite) h(entity, 'update', merged, JSON.parse(row.data), { service, id });
      if (ENTITY_LIMIT[entity] && merged.is_active !== false && JSON.parse(row.data).is_active === false) checkEntityLimit(id);
      const ts = nowIso();
      db.prepare(`UPDATE records SET data=?, updated_date=? WHERE id=?`).run(JSON.stringify(merged), ts, id);
      const rec = { id, created_date: row.created_date, updated_date: ts, created_by: row.created_by, ...merged };
      emit('update', rec, old);
      return hide(rec);
    },
    async bulkUpdate(items) {
      const out = [];
      for (const it of items || []) { const { id, ...rest } = it; out.push(await api.update(id, rest)); }
      return out;
    },
    async delete(id) {
      const r = guard('delete');
      const row = db.prepare(`SELECT * FROM records WHERE id=? AND entity=?`).get(id, entity);
      if (!row) throw HttpError(404, `${entity} no encontrado`);
      const old = rowToRecord(row);
      if (r && typeof r === 'object' && !matchQuery(old, r)) throw HttpError(403, `No tienes permiso para delete en ${entity}`);
      if (!service) for (const h of hooks.beforeDelete) h(entity, id, old);
      db.prepare(`DELETE FROM records WHERE id=?`).run(id);
      emit('delete', old, old);
      return { success: true };
    },
    async deleteMany(query) {
      const r = guard('delete');
      const rows = select(query || {}, null, null, 0, null, r);
      if (!service) rows.forEach((rec) => hooks.beforeDelete.forEach((h) => h(entity, rec.id, rec)));
      const tx = db.transaction(() => { for (const rec of rows) db.prepare(`DELETE FROM records WHERE id=?`).run(rec.id); });
      tx();
      rows.forEach((rec) => emit('delete', rec, rec));
      return { success: true, deleted: rows.length };
    },
    subscribe(cb) {
      const h = (ev) => { if (ev.entity === entity) cb({ type: ev.type, id: ev.id, data: ev.data, old_data: ev.old_data }); };
      bus.on('entity', h);
      return () => bus.off('entity', h);
    },
    async schema() { return schema || { name: entity, properties: {} }; },
  };
  return api;
}

export function entitiesProxy(ctx) {
  const cache = {};
  return new Proxy({}, { get: (_, name) => (typeof name === 'string' ? (cache[name] ||= entityApi(name, ctx)) : undefined) });
}

// acceso directo (sin RLS) para módulos internos
export const raw = {
  count: (entity) => db.prepare(`SELECT COUNT(*) c FROM records WHERE entity=?`).get(entity).c,
  roleDataFor,
};

export function canRead(entity, user, rec) {
  if (!user) return false;
  const c = makeCtx(user);
  const isAdmin = user.role === 'admin' || c.roleData?.app_role === 'admin';
  if (!isAdmin && c.roleData?.status !== 'active') return false;
  const r = resolveRule(entity, 'read', c, isAdmin);
  if (r === false) return false;
  if (r === true) return true;
  return matchQuery(rec, r);
}
