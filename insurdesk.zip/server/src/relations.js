// Integridad de relaciones. La verdad de cada vínculo es el id; el nombre guardado junto al id es solo una copia
// para mostrar. Este módulo (1) da a cada registro maestro un código único e inmutable, (2) propaga los
// renombres a todas las copias, (3) impide borrar lo que otros registros usan y (4) repara datos importados.
import { db, nowIso, newId } from './db.js';
import { bus, hooks, HttpError } from './store.js';

const norm = (s) => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const fullName = (c) => (c?.client_type === 'persona' ? [c.first_name, c.last_name].filter(Boolean).join(' ') : (c?.company_name || ''));
const AGENT = (idF, nameF) => (['', idF, nameF]);

/** Registro maestro -> dónde se usa. children: [entidad, campo_id, campo_nombre]; lists: arreglos de nombres;
 *  nested: arreglos de objetos con id y nombre; viaPolicy: nombres que cuelgan de la póliza del cliente. */
export const REL = {
  InsuranceCompany: { label: 'compañía', name: 'name', code: 'CIA', unique: true, restrict: true,
    children: [['Policy', 'company_id', 'company_name'], ['Product', 'company_id', 'company_name'], ['Commission', 'company_id', 'company_name'], ['CommissionTable', 'company_id', 'company_name'], ['CompanyBudget', 'company_id', 'company_name'], ['AgentCommissionAssignment', 'company_id', 'company_name']],
    lists: [['SalesTarget', 'companies']] },
  InsuranceLine: { label: 'ramo', name: 'name', code: 'RAM', unique: true, restrict: true,
    children: [['Policy', 'line_id', 'line_name'], ['Product', 'line_id', 'line_name'], ['CommissionTable', 'line_id', 'line_name'], ['CompanyBudget', 'line_id', 'line_name'], ['AgentCommissionAssignment', 'line_id', 'line_name']],
    lists: [['InsuranceCompany', 'lines'], ['SalesTarget', 'lines']] },
  Branch: { label: 'sucursal', name: 'name', code: 'SUC', unique: true, restrict: true,
    children: [['InsuranceCompany', 'branch_id', 'branch_name'], ['Policy', 'branch_id', 'branch_name']] },
  Product: { label: 'producto', name: 'product_name', code: 'PRD', unique: true, uniqueBy: ['company_id', 'line_id'], restrict: true,
    children: [['Policy', 'product_id', 'product_name'], ['Commission', 'product_id', 'product_name']],
    nested: [['CommissionTable', 'product_commissions', 'product_id', 'product_name'], ['CompanyBudget', 'products', 'product_id', 'product_name']] },
  Agent: { label: 'agente', name: 'name', code: 'AGT', restrict: true,
    children: [['Policy', 'agent_id', 'agent_name'], ['Commission', 'agent_id', 'agent_name'], ['AgentBadge', 'agent_id', 'agent_name'], ['AgentCommissionAssignment', 'agent_id', 'agent_name'], ['AgentCost', 'agent_id', 'agent_name'], ['AgentNegativeBalance', 'agent_id', 'agent_name'], ['CommissionSettlement', 'agent_id', 'agent_name'], ['SalesTarget', 'agent_id', 'agent_name'], ['Agent', 'upline_agent_id', 'upline_agent_name']] },
  Client: { label: 'cliente', restrict: true, nameFn: fullName,
    children: [['Policy', 'client_id', 'client_name'], ['Policy', 'contractor_id', 'contractor_name'], ['Claim', 'client_id', 'client_name'], ['Task', 'related_client_id', 'related_client_name']],
    viaPolicy: [['Payment', 'policy_id', 'client_name'], ['Commission', 'policy_id', 'client_name'], ['Renewal', 'original_policy_id', 'client_name']] },
  Policy: { label: 'póliza', name: 'policy_number',
    children: [['Payment', 'policy_id', 'policy_number'], ['Commission', 'policy_id', 'policy_number'], ['Claim', 'policy_id', 'policy_number'], ['Endorsement', 'policy_id', 'policy_number'], ['Task', 'related_policy_id', 'related_policy_number']] },
  Badge: { label: 'insignia', name: 'name', restrict: true, children: [['AgentBadge', 'badge_id', 'badge_name']] },
  CommissionTable: { label: 'tabla de comisión', name: 'name', restrict: true, children: [['AgentCommissionAssignment', 'commission_table_id', 'commission_table_name']] },
};
void AGENT;
const nameOf = (entity, rec) => (REL[entity].nameFn ? REL[entity].nameFn(rec) : rec?.[REL[entity].name]);
const LABELS = { Policy: 'póliza(s)', Product: 'producto(s)', Commission: 'comisión(es)', CommissionTable: 'tabla(s) de comisión', CompanyBudget: 'presupuesto(s)', AgentCommissionAssignment: 'asignación(es) de comisión', InsuranceCompany: 'compañía(s)', SalesTarget: 'meta(s)', Claim: 'siniestro(s)', Task: 'tarea(s)', AgentBadge: 'insignia(s)', AgentCost: 'costo(s)', AgentNegativeBalance: 'saldo(s) negativo(s)', CommissionSettlement: 'liquidación(es)', Agent: 'agente(s) de su estructura', Payment: 'pago(s)', Renewal: 'renovación(es)' };

// ---------- códigos ----------
function nextCode(entity, prefix) {
  const rows = db.prepare(`SELECT json_extract(data,'$.code') c FROM records WHERE entity=? AND json_extract(data,'$.code') LIKE ?`).all(entity, `${prefix}-%`);
  let max = 0;
  for (const r of rows) { const n = parseInt(String(r.c).slice(prefix.length + 1), 10); if (n > max) max = n; }
  return `${prefix}-${String(max + 1).padStart(4, '0')}`;
}

// ---------- ramos de una compañía: nombres <-> ids ----------
function syncLineIds(data, prev) {
  const lines = db.prepare(`SELECT id, json_extract(data,'$.name') n FROM records WHERE entity='InsuranceLine'`).all();
  const same = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
  const namesChanged = !same(data.lines, prev?.lines);
  const idsChanged = !same(data.line_ids, prev?.line_ids);
  if (idsChanged && !namesChanged && Array.isArray(data.line_ids)) {
    data.lines = data.line_ids.map((id) => lines.find((l) => l.id === id)?.n).filter(Boolean);
  } else if (Array.isArray(data.lines)) {
    data.line_ids = data.lines.map((n) => lines.find((l) => norm(l.n) === norm(n))?.id).filter(Boolean);
  }
}

// ---------- validaciones al escribir ----------
hooks.beforeWrite.push((entity, op, data, prev, ctx = {}) => {
  const rel = REL[entity];
  if (!rel) return;
  if (rel.code) {
    if (prev?.code) data.code = prev.code;                        // el código nunca cambia
    else if (!data.code) data.code = nextCode(entity, rel.code);
    else if (db.prepare(`SELECT 1 FROM records WHERE entity=? AND json_extract(data,'$.code')=? AND id != ?`).get(entity, data.code, ctx.id || '')) throw HttpError(409, `El código ${data.code} ya está en uso`, 'duplicate_code');
  }
  if (rel.unique && rel.name && data[rel.name]) {
    let sql = `SELECT id FROM records WHERE entity=? AND lower(json_extract(data,'$.${rel.name}'))=lower(?) AND id != ?`;
    const params = [entity, String(data[rel.name]).trim(), ctx.id || ''];
    for (const f of rel.uniqueBy || []) { sql += ` AND json_extract(data,'$.${f}') IS ?`; params.push(data[f] ?? null); }
    if (db.prepare(sql).get(...params)) throw HttpError(409, `Ya existe ${rel.label === 'ramo' ? 'un' : 'una'} ${rel.label} llamad${rel.label === 'ramo' || rel.label === 'producto' ? 'o' : 'a'} «${data[rel.name]}»`, 'duplicate_name');
  }
  if (entity === 'InsuranceCompany') syncLineIds(data, prev);
});

// ---------- no borrar lo que está en uso ----------
function usage(entity, id, rec) {
  const rel = REL[entity], out = [];
  for (const [ce, idF] of rel.children || []) {
    const n = db.prepare(`SELECT COUNT(*) c FROM records WHERE entity=? AND json_extract(data,'$.${idF}')=?`).get(ce, id).c;
    if (n) out.push([ce, n]);
  }
  for (const [ce, f] of rel.lists || []) {
    const n = db.prepare(`SELECT COUNT(*) c FROM records WHERE entity=? AND EXISTS (SELECT 1 FROM json_each(data,'$.${f}') WHERE value=?)`).get(ce, nameOf(entity, rec)).c;
    if (n) out.push([ce, n]);
  }
  for (const [ce, f, idK] of rel.nested || []) {
    const n = db.prepare(`SELECT COUNT(*) c FROM records WHERE entity=? AND EXISTS (SELECT 1 FROM json_each(data,'$.${f}') WHERE json_extract(value,'$.${idK}')=?)`).get(ce, id).c;
    if (n) out.push([ce, n]);
  }
  const merged = {}; for (const [e, n] of out) merged[e] = (merged[e] || 0) + n;
  return merged;
}
hooks.beforeDelete.push((entity, id, rec) => {
  const rel = REL[entity];
  if (!rel?.restrict) return;
  const u = usage(entity, id, rec);
  const parts = Object.entries(u).map(([e, n]) => `${n} ${LABELS[e] || e}`);
  if (parts.length) throw HttpError(409, `No se puede eliminar ${rel.label} «${nameOf(entity, rec)}»: la usan ${parts.join(', ')}. Márcala como inactiva para conservar el historial.`, 'in_use');
});

// ---------- propagar renombres ----------
function cascade(entity, rec, oldName, newName) {
  const rel = REL[entity], ts = nowIso();
  let touched = 0;
  const run = (sql, ...p) => { touched += db.prepare(sql).run(...p).changes; };
  for (const [ce, idF, nameF] of rel.children || []) {
    run(`UPDATE records SET data=json_set(data,'$.${nameF}',?), updated_date=? WHERE entity=? AND json_extract(data,'$.${idF}')=? AND COALESCE(json_extract(data,'$.${nameF}'),'') != ?`, newName, ts, ce, rec.id, newName);
  }
  for (const [ce, f] of rel.lists || []) {
    run(`UPDATE records SET data=json_set(data,'$.${f}', json((SELECT json_group_array(CASE WHEN value=? THEN ? ELSE value END) FROM json_each(data,'$.${f}')))), updated_date=? WHERE entity=? AND EXISTS (SELECT 1 FROM json_each(data,'$.${f}') WHERE value=?)`, oldName, newName, ts, ce, oldName);
  }
  for (const [ce, f, idK, nameK] of rel.nested || []) {
    const rows = db.prepare(`SELECT id, data FROM records WHERE entity=? AND EXISTS (SELECT 1 FROM json_each(data,'$.${f}') WHERE json_extract(value,'$.${idK}')=?)`).all(ce, rec.id);
    for (const r of rows) {
      const d = JSON.parse(r.data);
      d[f] = (d[f] || []).map((x) => (x?.[idK] === rec.id ? { ...x, [nameK]: newName } : x));
      db.prepare('UPDATE records SET data=?, updated_date=? WHERE id=?').run(JSON.stringify(d), ts, r.id); touched++;
    }
  }
  for (const [ce, pf, nameF] of rel.viaPolicy || []) {
    run(`UPDATE records SET data=json_set(data,'$.${nameF}',?), updated_date=? WHERE entity=? AND json_extract(data,'$.${pf}') IN (SELECT id FROM records WHERE entity='Policy' AND json_extract(data,'$.client_id')=?)`, newName, ts, ce, rec.id);
  }
  return touched;
}
bus.on('entity', (ev) => {
  if (ev.type !== 'update' || !REL[ev.entity] || !ev.old_data || !ev.data) return;
  const oldName = nameOf(ev.entity, ev.old_data), newName = nameOf(ev.entity, ev.data);
  if (!newName || oldName === newName) return;
  try { cascade(ev.entity, ev.data, oldName, newName); } catch (e) { console.error(`[relaciones] error propagando renombre de ${ev.entity}:`, e.message); }
});

// ---------- reparación de datos (importados o heredados) ----------
export function repairRelations({ dryRun = true } = {}) {
  const report = { dryRun, codes_asignados: 0, vinculados_por_nombre: 0, nombres_actualizados: 0, listas_normalizadas: 0, huerfanos: [], sin_coincidencia: [], ambiguos: [] };
  const cache = new Map(), dirty = new Set();
  const rows = (e) => { if (!cache.has(e)) cache.set(e, db.prepare('SELECT id, data FROM records WHERE entity=?').all(e).map((r) => ({ id: r.id, entity: e, data: JSON.parse(r.data) }))); return cache.get(e); };
  const set = (row, patch) => { Object.assign(row.data, patch); dirty.add(row); };
  const seenU = new Set(), seenA = new Set();

  for (const [pe, rel] of Object.entries(REL)) {
    if (rel.code) for (const row of rows(pe)) if (!row.data.code) {
      report.codes_asignados++;
      const max = rows(pe).reduce((m, r) => Math.max(m, parseInt(String(r.data.code || '').slice(rel.code.length + 1), 10) || 0), 0);
      set(row, { code: `${rel.code}-${String(max + 1).padStart(4, '0')}` });
    }
  }
  for (const [pe, rel] of Object.entries(REL)) {
    const byId = new Map(rows(pe).map((r) => [r.id, r]));
    const byName = new Map();
    for (const r of rows(pe)) { const k = norm(nameOf(pe, r.data)); if (k) byName.set(k, byName.has(k) ? null : r); }
    for (const [ce, idF, nameF] of rel.children || []) for (const row of rows(ce)) {
      const cur = row.data[idF], nm = row.data[nameF];
      if (cur) {
        const p = byId.get(cur);
        if (!p) { if (report.huerfanos.length < 25) report.huerfanos.push({ entidad: ce, id: row.id, campo: idF, valor: cur }); continue; }
        const canon = nameOf(pe, p.data);
        if (canon && nm !== canon) { report.nombres_actualizados++; set(row, { [nameF]: canon }); }
      } else if (nm) {
        const p = byName.get(norm(nm));
        if (p) { report.vinculados_por_nombre++; set(row, { [idF]: p.id, [nameF]: nameOf(pe, p.data) }); }
        else {
          const key = `${ce}.${nameF}=${nm}`;
          const bucket = byName.has(norm(nm)) ? report.ambiguos : report.sin_coincidencia;
          const seen = byName.has(norm(nm)) ? seenA : seenU;
          if (!seen.has(key) && bucket.length < 25) { seen.add(key); bucket.push({ entidad: ce, campo: nameF, valor: nm }); }
        }
      }
    }
    for (const [ce, f] of rel.lists || []) for (const row of rows(ce)) {
      if (!Array.isArray(row.data[f])) continue;
      const fixed = row.data[f].map((n) => { const p = byName.get(norm(n)); return p ? nameOf(pe, p.data) : n; });
      if (JSON.stringify(fixed) !== JSON.stringify(row.data[f])) { report.listas_normalizadas++; set(row, { [f]: fixed }); }
    }
  }
  for (const row of rows('InsuranceCompany')) { const before = JSON.stringify(row.data.line_ids); syncLineIds(row.data, { lines: null, line_ids: row.data.line_ids }); if (JSON.stringify(row.data.line_ids) !== before) dirty.add(row); }
  if (!dryRun) {
    const upd = db.prepare('UPDATE records SET data=?, updated_date=? WHERE id=?'); const ts = nowIso();
    db.transaction(() => { for (const r of dirty) upd.run(JSON.stringify(r.data), ts, r.id); })();
  }
  report.registros_modificados = dirty.size;
  return report;
}


// ---------- referencias por id ----------
// Siempre: si un id viene informado, debe existir. Tras cerrar la importación inicial: los ids clave son obligatorios
// (ya no se admiten registros que solo traigan nombres).
const REQUIRED = {
  Policy: ['company_id', 'line_id', 'product_id', 'agent_id', 'client_id'],
  Product: ['company_id', 'line_id'],
  Commission: ['policy_id', 'agent_id'],
  Payment: ['policy_id'],
  Claim: ['policy_id'],
  Endorsement: ['policy_id'],
  CommissionTable: ['company_id', 'line_id'],
  CompanyBudget: ['company_id', 'line_id'],
  AgentCommissionAssignment: ['agent_id', 'company_id', 'line_id'],
};
const PARENT_OF = {};
for (const [pe, rel] of Object.entries(REL)) for (const [ce, idF] of rel.children || []) (PARENT_OF[ce] ||= {})[idF] = pe;
const REF_LABEL = { company_id: 'la compañía', line_id: 'el ramo', product_id: 'el producto', agent_id: 'el agente', client_id: 'el cliente', policy_id: 'la póliza' };

const SETTING = `SELECT id, data FROM records WHERE entity='AppSettings' AND json_extract(data,'$.setting_key')='initial_import_closed' LIMIT 1`;
let strict = { t: 0, v: false };
export function isInitialImportClosed() {
  const now = Date.now();
  if (now - strict.t < 1000) return strict.v;
  const r = db.prepare(SETTING).get();
  const v = r ? JSON.parse(r.data).setting_value : null;
  strict = { t: now, v: v === 'true' || v === true };
  return strict.v;
}
export function setInitialImportClosed(closed, by) {
  const row = db.prepare(SETTING).get(), ts = nowIso(), value = closed ? 'true' : 'false';
  if (row) { const d = { ...JSON.parse(row.data), setting_value: value }; db.prepare('UPDATE records SET data=?, updated_date=? WHERE id=?').run(JSON.stringify(d), ts, row.id); }
  else db.prepare("INSERT INTO records (id, entity, data, created_date, updated_date, created_by) VALUES (?,?,?,?,?,?)").run(newId(), 'AppSettings', JSON.stringify({ setting_key: 'initial_import_closed', setting_value: value, setting_type: 'boolean', description: 'Importación inicial cerrada: las relaciones se exigen por id' }), ts, ts, by || 'system');
  strict = { t: 0, v: closed };
}

hooks.beforeWrite.push((entity, op, data) => {
  const required = REQUIRED[entity];
  if (!required) return;
  const closed = isInitialImportClosed();
  for (const field of required) {
    const v = data[field];
    if (!v) {
      if (closed) throw HttpError(422, `Falta ${REF_LABEL[field] || field} (${field}): desde que se cerró la importación inicial las relaciones se hacen por id, no por nombre`, 'missing_reference');
      continue;
    }
    const parent = PARENT_OF[entity]?.[field];
    if (parent && !db.prepare('SELECT 1 FROM records WHERE entity=? AND id=?').get(parent, v)) throw HttpError(422, `No existe ${REF_LABEL[field] || field} indicado (${field}: ${v})`, 'invalid_reference');
  }
});
