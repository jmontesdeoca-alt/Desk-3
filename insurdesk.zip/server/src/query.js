// Traductor de consultas estilo Mongo (el formato de consulta de la API) a SQL sobre JSON,
// más un evaluador en memoria para verificar reglas RLS en altas.

import { db } from './db.js';

const BUILTIN = new Set(['id', 'created_date', 'updated_date', 'created_by']);

function colFor(field) {
  if (BUILTIN.has(field)) return field;
  const path = field.replace(/[^A-Za-z0-9_.\-]/g, '');
  return `json_extract(data,'$.${path}')`;
}
function arrFor(field) {
  const path = field.replace(/[^A-Za-z0-9_.\-]/g, '');
  return `json_each(data,'$.${path}')`;
}
const bind = (v) => (v === true ? 1 : v === false ? 0 : (v !== null && typeof v === 'object') ? JSON.stringify(v) : v);
const isOp = (o) => o && typeof o === 'object' && !Array.isArray(o) && Object.keys(o).some((k) => k.startsWith('$'));

export function toSql(query, params = []) {
  if (!query || typeof query !== 'object' || !Object.keys(query).length) return '1=1';
  const parts = [];
  for (const [key, val] of Object.entries(query)) {
    if (key === '$or' || key === '$and' || key === '$nor') {
      const subs = (val || []).map((q) => `(${toSql(q, params)})`);
      if (!subs.length) { parts.push(key === '$or' ? '0' : '1'); continue; }
      const sql = subs.join(key === '$and' ? ' AND ' : ' OR ');
      parts.push(key === '$nor' ? `NOT (${sql})` : `(${sql})`);
      continue;
    }
    const col = colFor(key);
    if (val === null || val === undefined) { parts.push(`${col} IS NULL`); continue; }
    if (isOp(val)) {
      const sub = [];
      for (const [op, v] of Object.entries(val)) {
        switch (op) {
          case '$eq': sub.push(`${col} = ?`); params.push(bind(v)); break;
          case '$ne': sub.push(`(${col} IS NULL OR ${col} != ?)`); params.push(bind(v)); break;
          case '$gt': sub.push(`${col} > ?`); params.push(bind(v)); break;
          case '$gte': sub.push(`${col} >= ?`); params.push(bind(v)); break;
          case '$lt': sub.push(`${col} < ?`); params.push(bind(v)); break;
          case '$lte': sub.push(`${col} <= ?`); params.push(bind(v)); break;
          case '$in': {
            const arr = Array.isArray(v) ? v : [v];
            if (!arr.length) { sub.push('0'); break; }
            const ph = arr.map(() => '?').join(',');
            sub.push(`(${col} IN (${ph}) OR EXISTS (SELECT 1 FROM ${arrFor(key)} WHERE value IN (${ph})))`);
            params.push(...arr.map(bind), ...arr.map(bind));
            break;
          }
          case '$nin': {
            const arr = Array.isArray(v) ? v : [v];
            if (!arr.length) break;
            const ph = arr.map(() => '?').join(',');
            sub.push(`(${col} IS NULL OR ${col} NOT IN (${ph}))`);
            params.push(...arr.map(bind));
            break;
          }
          case '$related': {
            // El campo debe estar entre los (v.field || id) de los registros de otra entidad que cumplan v.where
            const f = v.field ? colFor(v.field) : 'id';
            params.push(v.entity);
            const w = toSql(v.where || {}, params);
            sub.push(`${col} IN (SELECT ${f} FROM records WHERE entity = ? AND (${w}))`);
            break;
          }
          case '$exists': sub.push(v ? `${col} IS NOT NULL` : `${col} IS NULL`); break;
          case '$regex': sub.push(`regex_match(?, ${col}, ?)`); params.push(String(v instanceof RegExp ? v.source : v), val.$options || ''); break;
          case '$options': break;
          default: break;
        }
      }
      parts.push(sub.length ? `(${sub.join(' AND ')})` : '1=1');
      continue;
    }
    // igualdad simple (también coincide si el campo es un arreglo que contiene el valor)
    parts.push(`(${col} = ? OR EXISTS (SELECT 1 FROM ${arrFor(key)} WHERE value = ?))`);
    params.push(bind(val), bind(val));
  }
  return parts.length ? parts.join(' AND ') : '1=1';
}

export function orderBy(sort) {
  if (!sort || typeof sort !== 'string') return 'created_date DESC';
  return sort.split(',').map((s) => s.trim()).filter(Boolean).map((s) => {
    const desc = s.startsWith('-');
    const f = s.replace(/^[-+]/, '');
    return `${colFor(f)} ${desc ? 'DESC' : 'ASC'}`;
  }).join(', ');
}

// ---- evaluador en memoria ----
const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? undefined : a[k]), o);
export function matchQuery(rec, query) {
  if (!query || !Object.keys(query).length) return true;
  return Object.entries(query).every(([key, val]) => {
    if (key === '$or') return (val || []).some((q) => matchQuery(rec, q));
    if (key === '$and') return (val || []).every((q) => matchQuery(rec, q));
    if (key === '$nor') return !(val || []).some((q) => matchQuery(rec, q));
    const v = get(rec, key);
    if (val === null || val === undefined) return v === null || v === undefined;
    if (isOp(val)) {
      return Object.entries(val).every(([op, x]) => {
        switch (op) {
          case '$eq': return v === x;
          case '$ne': return v !== x;
          case '$gt': return v > x;
          case '$gte': return v >= x;
          case '$lt': return v < x;
          case '$lte': return v <= x;
          case '$in': return (Array.isArray(v) ? v.some((i) => x.includes(i)) : x.includes(v));
          case '$nin': return !x.includes(v);
          case '$exists': return x ? v != null : v == null;
          case '$related': {
            if (v == null) return false;
            const ps = [x.entity];
            const w = toSql(x.where || {}, ps);
            return !!db.prepare(`SELECT 1 FROM records WHERE entity = ? AND (${w}) AND ${x.field ? colFor(x.field) : 'id'} = ? LIMIT 1`).get(...ps, v);
          }
          case '$regex': return new RegExp(x, val.$options || '').test(String(v ?? ''));
          default: return true;
        }
      });
    }
    return Array.isArray(v) ? v.includes(val) : v === val;
  });
}
