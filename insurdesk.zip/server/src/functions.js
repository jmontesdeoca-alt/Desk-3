import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { AsyncLocalStorage } from 'node:async_hooks';
import { ROOT, MAIL_RELAY_MARK } from './config.js';
import { sendEmail } from './integrations.js';
import { featureForFunction, functionEnabled } from './features.js';
import { featureEnabled, featureName, current as plan } from './license.js';

export const INTERNAL_SECRET = crypto.randomBytes(24).toString('hex'); // solo vive en este proceso
export const workflowContext = new AsyncLocalStorage();

// Las funciones envían correo directamente contra la API de Resend. Si no hay una clave real
// (RESEND_API_KEY ausente), esa llamada se desvía a SMTP o, en desarrollo, a la consola.
const realFetch = globalThis.fetch.bind(globalThis);
globalThis.fetch = async (input, init) => {
  const url = typeof input === 'string' ? input : input?.url || String(input);
  if (process.env.RESEND_API_KEY === MAIL_RELAY_MARK && url.startsWith('https://api.resend.com/emails')) {
    try {
      const b = JSON.parse(init?.body || '{}');
      const r = await sendEmail({ to: b.to, subject: b.subject, html: b.html, text: b.text, cc: b.cc, bcc: b.bcc, from: b.from, reply_to: b.reply_to });
      return Response.json({ id: r.id || 'local' }, { status: 200 });
    } catch (e) { return Response.json({ message: e.message }, { status: 500 }); }
  }
  return realFetch(input, init);
};

// ---------- Registro de funciones ----------
// Cada función vive en <carpeta>/<nombre>/entry.(ts|js) y exporta por defecto un handler (Request) => Response.
const handlers = new Map();

function functionDirs() {
  const dirs = [path.join(ROOT, 'functions')];
  const modRoot = path.join(ROOT, 'modules');
  if (fs.existsSync(modRoot)) {
    for (const d of fs.readdirSync(modRoot)) {
      const dir = path.join(modRoot, d, 'functions');
      if (!d.startsWith('_') && fs.existsSync(dir)) dirs.push(dir);
    }
  }
  return dirs;
}

export async function loadFunctions() {
  for (const dir of functionDirs()) {
    for (const entryName of fs.readdirSync(dir).sort()) {
      const full = path.join(dir, entryName);
      const isDir = fs.statSync(full).isDirectory();
      const name = isDir ? entryName : entryName.replace(/\.(js|ts)$/, '');
      const file = isDir ? ['entry.ts', 'entry.js'].map((f) => path.join(full, f)).find((f) => fs.existsSync(f)) : (/\.(js|ts)$/.test(entryName) ? full : null);
      if (!file) continue;
      if (handlers.has(name)) { console.warn(`Función duplicada ignorada: ${name}`); continue; }
      try {
        const mod = await import(pathToFileURL(file).href);
        if (typeof mod.default === 'function') handlers.set(name, mod.default);
        else console.warn(`Función sin handler por defecto: ${name}`);
      } catch (e) { console.error(`✖ No se pudo cargar la función ${name}:`, e.message); }
    }
  }
  console.log(`✔ ${handlers.size} funciones cargadas`);
}

export const hasFunction = (n) => handlers.has(n);
export const functionNames = () => [...handlers.keys()];
export { functionEnabled };

/** Lanza 403 si la función pertenece a un módulo que el plan no incluye (el rol de servicio siempre pasa). */
export function assertFunctionAllowed(name, service) {
  if (service) return;
  const f = featureForFunction(name);
  if (f && !featureEnabled(f)) throw Object.assign(new Error(`"${featureName(f)}" no está incluido en tu plan (${plan().planName})`), { status: 403, code: 'feature_disabled' });
}

export async function runHandler(name, request) {
  const h = handlers.get(name);
  if (!h) return Response.json({ error: `Función no encontrada: ${name}` }, { status: 404 });
  try { return await h(request); } catch (e) { console.error(`Error en función ${name}:`, e); return Response.json({ error: e.message || 'Error interno' }, { status: 500 }); }
}

// Invocación en proceso (entre funciones, scheduler y automatizaciones)
export async function invokeFunction(name, payload = {}, { token, service } = {}) {
  assertFunctionAllowed(name, service);
  const headers = { 'content-type': 'application/json' };
  if (token) headers.authorization = `Bearer ${token}`;
  if (service) headers['x-internal-service'] = INTERNAL_SECRET;
  const res = await runHandler(name, new Request(`http://internal.local/api/functions/${name}`, { method: 'POST', headers, body: JSON.stringify(payload ?? {}) }));
  const text = await res.text();
  let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    const err = new Error((data && (data.error || data.message)) || `Error ${res.status} en ${name}`);
    err.status = res.status; err.data = data; err.response = { status: res.status, data };
    throw err;
  }
  return { data, status: res.status };
}
