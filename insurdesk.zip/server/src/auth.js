import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { db } from './db.js';
import { config, mailConfigured } from './config.js';
import { entityApi, raw, HttpError } from './store.js';
import { sendEmail } from './integrations.js';

const svc = () => entityApi('User', { service: true });
const norm = (e) => String(e || '').trim().toLowerCase();
const cred = (email) => db.prepare('SELECT * FROM credentials WHERE email=?').get(norm(email));

// limitador simple en memoria (por clave)
const hits = new Map();
export function rateLimit(key, max = 8, windowMs = 15 * 60 * 1000) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) throw HttpError(429, 'Demasiados intentos. Intenta de nuevo en unos minutos.');
  arr.push(now); hits.set(key, arr);
}

export const signToken = (u) => jwt.sign({ sub: u.id, email: u.email }, config.jwtSecret, { expiresIn: config.tokenTtl });
export function verifyToken(t) { try { return jwt.verify(t, config.jwtSecret); } catch { return null; } }

// Un solo sistema de perfiles: el rol de la plataforma (app_role) determina el rol dentro del CRM.
const CRM_ROLE = { admin: 'admin_crm', gerencial: 'jefatura_crm', jefatura: 'jefatura_crm', agente: 'agente_crm', gestor_ventas: 'agente_crm' };
export function publicUser(rec) {
  if (!rec) return null;
  const role = raw.roleDataFor(rec);
  const appRole = role.app_role ?? rec.app_role;
  return {
    ...rec,
    app_role: appRole,
    agent_id: role.agent_id ?? rec.agent_id,
    crm_role: role.crm_role || CRM_ROLE[appRole] || (rec.role === 'admin' ? 'admin_crm' : (role.crm_access_enabled === true ? 'agente_crm' : null)),
    crm_access_enabled: role.crm_access_enabled === true || appRole === 'admin' || rec.role === 'admin',
    is_active: role.status ? role.status === 'active' : true,
    data: { app_role: appRole, agent_id: role.agent_id ?? rec.agent_id },
  };
}
export async function userFromToken(token) {
  const p = token && verifyToken(token);
  if (!p) return null;
  try { return publicUser(await svc().get(p.sub)); } catch { return null; }
}
export const tokenFromHeaders = (headers) => {
  const h = typeof headers?.get === 'function' ? headers.get('authorization') : headers?.authorization;
  return h && /^Bearer /i.test(h) ? h.slice(7).trim() : null;
};

async function ensureUser(email, full_name, role = 'user') {
  const found = (await svc().filter({ email: norm(email) }, null, 1))[0];
  if (found) return found;
  return svc().create({ email: norm(email), full_name: full_name || norm(email).split('@')[0], role });
}

const otpMail = (code) => `<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto"><h2>Tu código de verificación</h2><p style="font-size:30px;letter-spacing:6px;font-weight:bold">${code}</p><p>Expira en 15 minutos.</p></div>`;
async function issueOtp(email) {
  const code = String(crypto.randomInt(100000, 999999));
  db.prepare('UPDATE credentials SET otp_code=?, otp_expires=? WHERE email=?').run(code, Date.now() + 15 * 60 * 1000, norm(email));
  await sendEmail({ to: email, subject: 'Tu código de verificación', html: otpMail(code), text: `Tu código: ${code}` });
  if (!mailConfigured()) console.warn(`[DEV] Código OTP para ${email}: ${code}`);
}

export const auth = {
  async register({ email, password, full_name }) {
    email = norm(email);
    if (!/^\S+@\S+\.\S+$/.test(email)) throw HttpError(400, 'Correo inválido');
    if (!password || password.length < 8) throw HttpError(400, 'La contraseña debe tener al menos 8 caracteres');
    if (!config.allowRegistration) throw HttpError(403, 'El registro está deshabilitado. Solicita una invitación al administrador.');
    rateLimit(`reg:${email}`, 5);
    const existing = cred(email);
    if (existing?.verified && existing.password_hash) throw HttpError(409, 'Ya existe una cuenta con este correo');
    const user = await ensureUser(email, full_name);
    const hash = bcrypt.hashSync(password, 10);
    const needVerify = mailConfigured();
    db.prepare(`INSERT INTO credentials (user_id,email,password_hash,verified) VALUES (?,?,?,?)
      ON CONFLICT(email) DO UPDATE SET password_hash=excluded.password_hash, verified=excluded.verified`).run(user.id, email, hash, needVerify ? 0 : 1);
    if (needVerify) await issueOtp(email);
    return { success: true, requires_verification: needVerify };
  },
  async verifyOtp({ email, otpCode }) {
    email = norm(email); rateLimit(`otp:${email}`, 8);
    const c = cred(email);
    if (!c || !c.otp_code || c.otp_code !== String(otpCode).trim() || Date.now() > (c.otp_expires || 0)) throw HttpError(400, 'Código inválido o vencido');
    db.prepare('UPDATE credentials SET verified=1, otp_code=NULL, otp_expires=NULL WHERE email=?').run(email);
    const user = publicUser(await svc().get(c.user_id));
    return { access_token: signToken(user), user };
  },
  async resendOtp(email) { rateLimit(`otpr:${norm(email)}`, 5); if (cred(email)) await issueOtp(email); return { success: true }; },
  async login({ email, password }) {
    email = norm(email); rateLimit(`login:${email}`, 10);
    const c = cred(email);
    if (!c?.password_hash || !bcrypt.compareSync(String(password || ''), c.password_hash)) throw HttpError(401, 'Correo o contraseña incorrectos');
    if (!c.verified) { await issueOtp(email); throw HttpError(403, 'Debes verificar tu correo. Te enviamos un nuevo código.'); }
    const user = publicUser(await svc().get(c.user_id));
    return { access_token: signToken(user), user };
  },
  async resetPasswordRequest(email) {
    email = norm(email); rateLimit(`rst:${email}`, 5);
    const c = cred(email);
    if (c) await sendResetLink(email);
    return { success: true }; // no revelar si existe
  },
  async resetPassword({ resetToken, newPassword }) {
    if (!newPassword || newPassword.length < 8) throw HttpError(400, 'La contraseña debe tener al menos 8 caracteres');
    const hash = crypto.createHash('sha256').update(String(resetToken || '')).digest('hex');
    const c = db.prepare('SELECT * FROM credentials WHERE reset_token=?').get(hash);
    if (!c || Date.now() > (c.reset_expires || 0)) throw HttpError(400, 'Enlace inválido o vencido');
    db.prepare('UPDATE credentials SET password_hash=?, verified=1, reset_token=NULL, reset_expires=NULL WHERE user_id=?').run(bcrypt.hashSync(newPassword, 10), c.user_id);
    return { success: true };
  },
  // Invitar usuario: crea la cuenta si no existe y envía un enlace para definir contraseña
  async inviteUser(email, role = 'user') {
    email = norm(email);
    const user = await ensureUser(email, null, role === 'admin' ? 'admin' : 'user');
    db.prepare(`INSERT INTO credentials (user_id,email,password_hash,verified) VALUES (?,?,NULL,1) ON CONFLICT(email) DO NOTHING`).run(user.id, email);
    await sendResetLink(email, true);
    return { success: true };
  },
  async updateMe(userId, patch) {
    const clean = { ...patch };
    for (const k of ['id', 'email', 'role', 'created_date', 'updated_date', 'created_by']) delete clean[k];
    return publicUser(await svc().update(userId, clean));
  },
  // login/registro con Google (flujo de código OAuth)
  googleAuthUrl(returnTo, redirectUri) {
    if (!config.google.clientId) throw HttpError(501, 'Google no está configurado (GOOGLE_CLIENT_ID)');
    const state = jwt.sign({ rt: returnTo || '/' }, config.jwtSecret, { expiresIn: '10m' });
    const q = new URLSearchParams({ client_id: config.google.clientId, redirect_uri: redirectUri, response_type: 'code', scope: 'openid email profile', state, prompt: 'select_account' });
    return `https://accounts.google.com/o/oauth2/v2/auth?${q}`;
  },
  async googleCallback(code, state, redirectUri) {
    let rt = '/'; try { rt = jwt.verify(state, config.jwtSecret).rt || '/'; } catch { throw HttpError(400, 'Estado inválido'); }
    const tr = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code, client_id: config.google.clientId, client_secret: config.google.clientSecret, redirect_uri: redirectUri, grant_type: 'authorization_code' }) });
    const tj = await tr.json(); if (!tr.ok) throw HttpError(400, tj.error_description || 'Error de Google');
    const info = await (await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tj.access_token}` } })).json();
    if (!info.email || info.email_verified === false) throw HttpError(400, 'Cuenta de Google sin correo verificado');
    const user = await ensureUser(info.email, info.name);
    db.prepare(`INSERT INTO credentials (user_id,email,password_hash,verified,google_sub) VALUES (?,?,NULL,1,?) ON CONFLICT(email) DO UPDATE SET verified=1, google_sub=excluded.google_sub`).run(user.id, norm(info.email), info.sub);
    return { token: signToken(user), returnTo: rt };
  },
};

async function sendResetLink(email, invite = false) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('UPDATE credentials SET reset_token=?, reset_expires=? WHERE email=?').run(crypto.createHash('sha256').update(token).digest('hex'), Date.now() + 24 * 60 * 60 * 1000, norm(email));
  const link = `${config.appUrl}/reset-password?token=${token}`;
  await sendEmail({
    to: email,
    subject: invite ? 'Has sido invitado — define tu contraseña' : 'Restablecer contraseña',
    html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto"><h2>${invite ? 'Bienvenido' : 'Restablecer contraseña'}</h2><p>Usa este enlace para definir tu contraseña (válido 24 horas):</p><p><a href="${link}" style="background:#0f172a;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Definir contraseña</a></p><p style="color:#64748b;font-size:12px">${link}</p></div>`,
    text: `Define tu contraseña: ${link}`,
  });
  if (!mailConfigured()) console.warn(`[DEV] Enlace para ${email}: ${link}`);
}

// Crea el administrador inicial a partir de variables de entorno
export async function seedAdmin() {
  if (!config.adminEmail || !config.adminPassword) return;
  if (cred(config.adminEmail)) return;
  const user = await ensureUser(config.adminEmail, config.adminName, 'admin');
  db.prepare('INSERT INTO credentials (user_id,email,password_hash,verified) VALUES (?,?,?,1)').run(user.id, config.adminEmail, bcrypt.hashSync(config.adminPassword, 10));
  const roles = entityApi('UserRole', { service: true });
  if (!(await roles.filter({ email: config.adminEmail }, null, 1)).length) await roles.create({ email: config.adminEmail, app_role: 'admin', status: 'active', crm_access_enabled: true });
  console.log(`✔ Administrador inicial creado: ${config.adminEmail}`);
}

// Versión síncrona (para construir el contexto RLS de una petición)
export function userFromTokenSync(token) {
  const p = token && verifyToken(token);
  if (!p) return null;
  const row = db.prepare(`SELECT * FROM records WHERE id=? AND entity='User'`).get(p.sub);
  if (!row) return null;
  return publicUser({ id: row.id, created_date: row.created_date, updated_date: row.updated_date, created_by: row.created_by, ...JSON.parse(row.data) });
}
