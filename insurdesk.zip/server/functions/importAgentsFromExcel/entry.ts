import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();

    if (user?.role !== 'admin' && user?.app_role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { file_url } = await req.json();

    if (!file_url) {
      return Response.json({ error: 'file_url is required' }, { status: 400 });
    }

    // Extract data from Excel
    const extractResult = await sdk.asServiceRole.integrations.Core.ExtractDataFromUploadedFile({
      file_url,
      json_schema: {
        type: "object",
        properties: {
          agents: {
            type: "array",
            items: {
              type: "object",
              properties: {
                Agencia: { type: "string" },
                "País": { type: "string" },
                "Agente Superior (Upline)": { type: ["string", "null"] }
              }
            }
          }
        }
      }
    });

    if (extractResult.status === 'error') {
      return Response.json({ error: 'Failed to extract data', details: extractResult.details }, { status: 400 });
    }

    const agents = extractResult.output.agents || extractResult.output;
    
    if (!Array.isArray(agents)) {
      return Response.json({ error: 'Invalid data format' }, { status: 400 });
    }

    // Get existing agents
    const existingAgents = await sdk.asServiceRole.entities.Agent.list();
    const existingNames = new Set(existingAgents.map(a => a.name.toUpperCase().trim()));

    // Create agents in order: first without upline, then with upline
    const agentsWithoutUpline = agents.filter(a => !a["Agente Superior (Upline)"]);
    const agentsWithUpline = agents.filter(a => a["Agente Superior (Upline)"]);

    const results = {
      created: [],
      skipped: [],
      errors: [],
      duplicates: []
    };

    // Create agents without upline first
    for (const agentData of agentsWithoutUpline) {
      const name = agentData.Agencia?.trim();
      
      if (!name) {
        results.errors.push({ name: 'Unknown', error: 'Missing agent name' });
        continue;
      }
      
      if (existingNames.has(name.toUpperCase())) {
        const existingAgent = existingAgents.find(a => a.name.toUpperCase().trim() === name.toUpperCase());
        results.duplicates.push({ 
          name, 
          country: agentData["País"] || '',
          existingCountry: existingAgent?.country || '',
          reason: 'Ya existe en la base de datos' 
        });
        results.skipped.push({ name, reason: 'Already exists' });
        continue;
      }

      try {
        const newAgent = await sdk.asServiceRole.entities.Agent.create({
          agent_type: 'agencia',
          name,
          email: '',
          phone: '',
          country: agentData["País"] || '',
          level: 1,
          status: 'activo',
          is_nivel_2: false,
          is_gapartner: false
        });
        
        results.created.push({ name, id: newAgent.id });
        existingNames.add(name.toUpperCase());
      } catch (error) {
        results.errors.push({ name, error: error.message });
      }
    }

    // Refresh agents list to get IDs
    const updatedAgents = await sdk.asServiceRole.entities.Agent.list();
    const agentNameToId = {};
    updatedAgents.forEach(agent => {
      agentNameToId[agent.name.toUpperCase().trim()] = agent.id;
    });

    // Create agents with upline
    for (const agentData of agentsWithUpline) {
      const name = agentData.Agencia?.trim();
      
      if (!name) {
        results.errors.push({ name: 'Unknown', error: 'Missing agent name' });
        continue;
      }
      
      if (existingNames.has(name.toUpperCase())) {
        const existingAgent = existingAgents.find(a => a.name.toUpperCase().trim() === name.toUpperCase());
        results.duplicates.push({ 
          name, 
          country: agentData["País"] || '',
          existingCountry: existingAgent?.country || '',
          upline: agentData["Agente Superior (Upline)"] || '',
          reason: 'Ya existe en la base de datos' 
        });
        results.skipped.push({ name, reason: 'Already exists' });
        continue;
      }

      const uplineName = agentData["Agente Superior (Upline)"]?.trim();
      const uplineId = uplineName ? agentNameToId[uplineName.toUpperCase()] : null;

      if (uplineName && !uplineId) {
        results.errors.push({ name, error: `Upline not found: ${uplineName}` });
        continue;
      }

      try {
        const newAgent = await sdk.asServiceRole.entities.Agent.create({
          agent_type: 'agencia',
          name,
          email: '',
          phone: '',
          country: agentData["País"] || '',
          level: 1,
          upline_agent_id: uplineId,
          upline_agent_name: uplineName || '',
          status: 'activo',
          is_nivel_2: false,
          is_gapartner: false
        });
        
        results.created.push({ name, id: newAgent.id, upline: uplineName });
        existingNames.add(name.toUpperCase());
      } catch (error) {
        results.errors.push({ name, error: error.message });
      }
    }

    return Response.json({
      success: true,
      results,
      summary: {
        total: agents.length,
        created: results.created.length,
        skipped: results.skipped.length,
        duplicates: results.duplicates.length,
        errors: results.errors.length
      }
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});