import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

// In-memory OTP store (works for single instance; for production use a DB entity)
// Persistencia en entidad (sin estado en memoria)
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const body = await req.json();
    const { action, email, otp } = body;

    if (action === 'send') {
      if (!email) return Response.json({ error: 'Email requerido' }, { status: 400 });

      // Look up client by email (try uppercase, lowercase, and original)
      let clients = await sdk.asServiceRole.entities.Client.filter({ email: email.toUpperCase() });
      if (!clients || clients.length === 0) {
        clients = await sdk.asServiceRole.entities.Client.filter({ email: email.toLowerCase() });
      }
      if (!clients || clients.length === 0) {
        clients = await sdk.asServiceRole.entities.Client.filter({ email: email.trim() });
      }
      if (!clients || clients.length === 0) {
        return Response.json({ error: 'No encontramos un cliente registrado con ese correo.' }, { status: 404 });
      }

      // Generate 6-digit OTP
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 min

      // Store OTP in AppSettings entity temporarily (keyed by email)
      const key = `otp_${email.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
      const existing = await sdk.asServiceRole.entities.AppSettings.filter({ setting_key: key });
      const otpValue = JSON.stringify({ code, expiresAt, email: email.toLowerCase() });

      if (existing.length > 0) {
        await sdk.asServiceRole.entities.AppSettings.update(existing[0].id, {
          setting_value: otpValue,
          setting_type: 'string',
          description: 'Portal Cliente OTP'
        });
      } else {
        await sdk.asServiceRole.entities.AppSettings.create({
          setting_key: key,
          setting_value: otpValue,
          setting_type: 'string',
          description: 'Portal Cliente OTP'
        });
      }

      // Send email via Resend
      const RESEND_API_KEY = process.env.RESEND_API_KEY;
      const clientName = clients[0].client_type === 'persona'
        ? `${clients[0].first_name || ''} ${clients[0].last_name || ''}`.trim()
        : clients[0].company_name || email;

      const emailRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: brand.from(),
          to: [email],
          subject: 'Tu código de acceso al Portal de Cliente',
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px 24px;">
              <div style="text-align: center; margin-bottom: 32px;">
                <h1 style="color: #001E2E; font-size: 28px; margin: 0;">GA<span style="color: #0A8FBE;">Portal</span></h1>
                <p style="color: #64748b; margin-top: 4px; font-size: 14px;">Portal de Cliente</p>
              </div>
              <p style="color: #334155; font-size: 16px;">Hola <strong>${clientName}</strong>,</p>
              <p style="color: #64748b; font-size: 15px;">Tu código de acceso es:</p>
              <div style="background: #f1f5f9; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0;">
                <span style="font-size: 42px; font-weight: 800; letter-spacing: 12px; color: #001E2E;">${code}</span>
              </div>
              <p style="color: #94a3b8; font-size: 13px; text-align: center;">Este código expira en <strong>10 minutos</strong>. No lo compartas con nadie.</p>
              <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 32px 0;" />
              <p style="color: #cbd5e1; font-size: 12px; text-align: center;">InsurDesk — Sistema de Gestión de Seguros</p>
            </div>
          `
        })
      });

      if (!emailRes.ok) {
        const err = await emailRes.text();
        console.error('Resend error:', err);
        return Response.json({ error: 'No se pudo enviar el correo. Intenta nuevamente.' }, { status: 500 });
      }

      return Response.json({ success: true, clientName });
    }

    if (action === 'verify') {
      if (!email || !otp) return Response.json({ error: 'Email y código requeridos' }, { status: 400 });

      const key = `otp_${email.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
      const existing = await sdk.asServiceRole.entities.AppSettings.filter({ setting_key: key });

      if (!existing || existing.length === 0) {
        return Response.json({ error: 'No hay código activo. Solicita uno nuevo.' }, { status: 400 });
      }

      let stored;
      try { stored = JSON.parse(existing[0].setting_value); } catch {
        return Response.json({ error: 'Código inválido.' }, { status: 400 });
      }

      if (new Date() > new Date(stored.expiresAt)) {
        return Response.json({ error: 'El código expiró. Solicita uno nuevo.' }, { status: 400 });
      }

      if (stored.code !== otp.trim()) {
        return Response.json({ error: 'Código incorrecto. Verifica e intenta de nuevo.' }, { status: 400 });
      }

      // Delete OTP after successful verification
      await sdk.asServiceRole.entities.AppSettings.delete(existing[0].id);

      // Return client data
      let clients = await sdk.asServiceRole.entities.Client.filter({ email: email.toUpperCase() });
      if (!clients || clients.length === 0) {
        clients = await sdk.asServiceRole.entities.Client.filter({ email: email.toLowerCase() });
      }
      if (!clients || clients.length === 0) {
        clients = await sdk.asServiceRole.entities.Client.filter({ email: email.trim() });
      }
      if (!clients || clients.length === 0) {
        return Response.json({ error: 'Cliente no encontrado.' }, { status: 404 });
      }

      const client = clients[0];

      // Generar token de sesión firmado de corta duración (30 min)
      const sessionToken = crypto.randomUUID();
      const sessionExpiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
      const sessionKey = `portal_session_${sessionToken}`;
      await sdk.asServiceRole.entities.AppSettings.create({
        setting_key: sessionKey,
        setting_value: JSON.stringify({ clientId: client.id, expiresAt: sessionExpiresAt }),
        setting_type: 'string',
        description: 'Portal Cliente Session'
      });

      return Response.json({ success: true, client, sessionToken });
    }

    return Response.json({ error: 'Acción no válida' }, { status: 400 });

  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});