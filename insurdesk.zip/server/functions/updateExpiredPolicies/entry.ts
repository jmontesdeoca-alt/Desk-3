import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const today = new Date().toISOString().split('T')[0];

    // Get all active policies that are expired (end_date < today)
    const activePolicies = await sdk.asServiceRole.entities.Policy.filter({ status: 'activa' });
    const expired = activePolicies.filter(p => p.end_date && p.end_date < today);

    if (expired.length === 0) {
      return Response.json({ updated: 0, message: 'No hay pólizas vencidas para actualizar' });
    }

    // Get all renewed policies in one call
    const renewedPolicies = await sdk.asServiceRole.entities.Policy.filter({ policy_type: 'renovacion' });
    const renewedFromIds = new Set(renewedPolicies.map(p => p.renewed_from_policy_id).filter(Boolean));

    // Update all in parallel
    const updates = expired.map(policy => {
      const newStatus = renewedFromIds.has(policy.id) ? 'renovada' : 'vencida';
      return sdk.asServiceRole.entities.Policy.update(policy.id, { status: newStatus });
    });

    await Promise.all(updates);

    return Response.json({ updated: expired.length, message: `${expired.length} pólizas actualizadas` });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});