import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    
    const user = await sdk.auth.me();
    if (!user || user.app_role !== 'admin') {
      return Response.json({ error: 'Unauthorized: Admin access required' }, { status: 403 });
    }

    // Obtener todas las pólizas
    const policies = await sdk.asServiceRole.entities.Policy.list();
    
    let updated = 0;
    let errors = 0;

    for (const policy of policies) {
      // Si no tiene issue_date, usar start_date
      if (!policy.issue_date && policy.start_date) {
        try {
          await sdk.asServiceRole.entities.Policy.update(policy.id, {
            issue_date: policy.start_date
          });
          updated++;
        } catch (error) {
          console.error(`Error updating policy ${policy.id}:`, error);
          errors++;
        }
      }
    }

    return Response.json({
      success: true,
      message: `Migración completada`,
      updated,
      errors,
      total: policies.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});