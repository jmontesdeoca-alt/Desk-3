import { createClientFromRequest } from '../../runtime/sdk.js';
import {
  CORS_HEADERS,
  unauthorizedResponse,
  checkAuth,
  handleOptionsAndMethod,
} from '../../shared/xrAuth.ts';

/**
 * GET xrFiltros
 * Devuelve las opciones para los filtros del tablero XR.
 * Requiere header: Authorization: Bearer <XR_READ_TOKEN>
 */
export default async function(req) {
  const earlyReturn = handleOptionsAndMethod(req);
  if (earlyReturn) return earlyReturn;
  if (!checkAuth(req)) return unauthorizedResponse();

  try {
    const sdk = createClientFromRequest(req);

    // Cargar pólizas y clientes en paralelo (service role bypassa RLS)
    const [policies, clients] = await Promise.all([
      sdk.asServiceRole.entities.Policy.list('-start_date', 10000),
      sdk.asServiceRole.entities.Client.list('-created_date', 10000),
    ]);

    // Excluir pólizas canceladas
    const activePolicies = policies.filter(p => p.status !== 'cancelada');

    // Mapa client_id → city (la ciudad vive en Client, no en Policy)
    const cityMap = {};
    clients.forEach(c => { if (c.id) cityMap[c.id] = c.city || ''; });

    // Listas únicas ordenadas alfabéticamente
    const ramos = [...new Set(activePolicies.map(p => p.line_name).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, 'es'));
    const companias = [...new Set(activePolicies.map(p => p.company_name).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, 'es'));
    const ejecutivos = [...new Set(activePolicies.map(p => p.agent_name).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, 'es'));
    const ciudades = [...new Set(Object.values(cityMap).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, 'es'));

    // Fechas min/max sobre start_date (vigencia desde)
    const dates = activePolicies.map(p => p.start_date).filter(Boolean).sort();
    const fechas = {
      min: dates[0] || null,
      max: dates[dates.length - 1] || null,
    };

    // Prima min/max sobre annual_premium
    const premiums = activePolicies
      .map(p => p.annual_premium)
      .filter(n => n != null && !isNaN(n));
    const prima = {
      min: premiums.length ? Math.min(...premiums) : 0,
      max: premiums.length ? Math.max(...premiums) : 0,
    };

    return Response.json(
      { ramos, companias, ejecutivos, ciudades, fechas, prima },
      { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return Response.json(
      { error: error.message },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}