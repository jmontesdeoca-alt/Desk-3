import { createClientFromRequest } from '../../runtime/sdk.js';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { original_policy_id, new_start_date, new_end_date, exclude_renewal_id } = body;

    if (!original_policy_id) {
      return Response.json({ error: 'original_policy_id es requerido' }, { status: 400 });
    }

    // 1. Verificar si ya existe una propuesta de renovación activa (propuesta o confirmada)
    //    Excluir la renovación que se está confirmando (exclude_renewal_id) para no bloquearse a sí misma
    const allExistingRenewals = await sdk.entities.Renewal.filter({
      original_policy_id,
      status: { $in: ['propuesta', 'confirmada'] }
    });
    const existingRenewals = exclude_renewal_id
      ? allExistingRenewals.filter(r => r.id !== exclude_renewal_id)
      : allExistingRenewals;

    // 2. Verificar si ya existe una póliza renovada a partir de la original
    const renewedPolicies = await sdk.entities.Policy.filter({
      renewed_from_policy_id: original_policy_id,
      status: { $in: ['activa', 'vencida', 'en_riesgo'] }
    });

    // 3. Si se proporcionan fechas, verificar solapamiento de período con renovaciones existentes
    let periodConflict = null;
    if (new_start_date && new_end_date && existingRenewals.length > 0) {
      const newStart = new Date(new_start_date);
      const newEnd = new Date(new_end_date);
      for (const r of existingRenewals) {
        if (r.new_start_date && r.new_end_date) {
          const rStart = new Date(r.new_start_date);
          const rEnd = new Date(r.new_end_date);
          // Solapamiento: newStart < rEnd && newEnd > rStart
          if (newStart < rEnd && newEnd > rStart) {
            periodConflict = {
              renewal_id: r.id,
              new_start_date: r.new_start_date,
              new_end_date: r.new_end_date,
              status: r.status
            };
            break;
          }
        }
      }
    }

    const hasActiveRenewal = existingRenewals.length > 0;
    const hasRenewedPolicy = renewedPolicies.length > 0;
    const canRenew = !hasActiveRenewal && !hasRenewedPolicy && !periodConflict;

    let reason = '';
    if (hasRenewedPolicy) {
      reason = 'Esta póliza ya fue renovada y tiene una póliza nueva activa asociada.';
    } else if (periodConflict) {
      reason = `Ya existe una renovación para el período ${periodConflict.new_start_date} a ${periodConflict.new_end_date}.`;
    } else if (hasActiveRenewal) {
      const propuesta = existingRenewals.find(r => r.status === 'propuesta');
      const confirmada = existingRenewals.find(r => r.status === 'confirmada');
      if (confirmada) {
        reason = 'Esta póliza ya tiene una renovación confirmada para este período.';
      } else if (propuesta) {
        reason = 'Esta póliza ya tiene una propuesta de renovación activa pendiente de confirmar.';
      }
    }

    return Response.json({
      canRenew,
      reason,
      hasActiveRenewal,
      hasRenewedPolicy,
      periodConflict,
      existingRenewals: existingRenewals.map(r => ({
        id: r.id,
        status: r.status,
        new_start_date: r.new_start_date,
        new_end_date: r.new_end_date
      })),
      renewedPolicies: renewedPolicies.map(p => ({
        id: p.id,
        policy_number: p.policy_number,
        start_date: p.start_date,
        end_date: p.end_date,
        status: p.status
      }))
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}