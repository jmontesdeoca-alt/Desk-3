import { createClientFromRequest } from '../../runtime/sdk.js';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'x-api-key, Content-Type',
};

function authError() {
  return Response.json({ error: 'Unauthorized: invalid or missing API key' }, { status: 401, headers: CORS_HEADERS });
}

function validateApiKey(req) {
  const key = req.headers.get('x-api-key');
  return key && key === process.env.REPORTING_API_KEY;
}

function parseParams(req) {
  const url = new URL(req.url);
  return {
    endpoint: url.searchParams.get('endpoint') || '',
    date_from: url.searchParams.get('date_from') || null,
    date_to: url.searchParams.get('date_to') || null,
    status: url.searchParams.get('status') || null,
    page: Math.max(1, parseInt(url.searchParams.get('page') || '1')),
    page_size: Math.min(5000, Math.max(1, parseInt(url.searchParams.get('page_size') || '1000'))),
  };
}

function paginate(arr, page, page_size) {
  const total = arr.length;
  const total_pages = Math.ceil(total / page_size) || 1;
  const data = arr.slice((page - 1) * page_size, page * page_size);
  return { data, pagination: { total, page, page_size, total_pages } };
}

function filterByDate(arr, dateField, date_from, date_to) {
  return arr.filter(item => {
    const d = item[dateField];
    if (!d) return true;
    if (date_from && d < date_from) return false;
    if (date_to && d > date_to) return false;
    return true;
  });
}

function filterByStatus(arr, status) {
  if (!status) return arr;
  return arr.filter(i => i.status === status);
}

// ── Endpoints ─────────────────────────────────────────────────────────────────

async function getPolicies(sdk, params) {
  let data = await sdk.asServiceRole.entities.Policy.list('-start_date', 5000);

  data = filterByDate(data, 'start_date', params.date_from, params.date_to);
  if (params.status) data = filterByStatus(data, params.status);

  const mapped = data.map(p => ({
    policy_id: p.id,
    policy_number: p.policy_number || null,
    client_name: p.client_name || p.contractor_name || null,
    agent_id: p.agent_id || null,
    agent_name: p.agent_name || null,
    company_id: p.company_id || null,
    company_name: p.company_name || null,
    line_id: p.line_id || null,
    line_name: p.line_name || null,
    branch_id: p.branch_id || null,
    branch_name: p.branch_name || null,
    policy_type: p.policy_type || null,
    policy_category: p.policy_category || null,
    status: p.status || null,
    issue_date: p.issue_date || null,
    start_date: p.start_date || null,
    end_date: p.end_date || null,
    annual_premium: p.annual_premium || 0,
    commissionable_premium: p.commissionable_premium || 0,
    payment_frequency: p.payment_frequency || null,
    currency: p.currency || null,
    country: p.country || null,
    insured_amount: p.insured_amount || null,
    deductible_1: p.deductible_1 || null,
    deductible_2: p.deductible_2 || null,
    sum_insured: p.sum_insured || null,
    created_date: p.created_date || null,
  }));

  return paginate(mapped, params.page, params.page_size);
}

async function getCommissions(sdk, params) {
  let data = await sdk.asServiceRole.entities.Commission.list('-generation_date', 5000);

  data = filterByDate(data, 'generation_date', params.date_from, params.date_to);
  if (params.status) data = filterByStatus(data, params.status);

  const mapped = data.map(c => ({
    commission_id: c.id,
    policy_id: c.policy_id || null,
    policy_number: c.policy_number || null,
    client_name: c.client_name || null,
    agent_id: c.agent_id || null,
    agent_name: c.agent_name || null,
    company_id: c.company_id || null,
    company_name: c.company_name || null,
    product_name: c.product_name || null,
    level: c.level || null,
    commission_pct: c.commission_pct || 0,
    base_amount: c.base_amount || 0,
    commission_amount: c.commission_amount || 0,
    currency: c.currency || null,
    status: c.status || null,
    source_type: c.source_type || null,
    generation_date: c.generation_date || null,
    released_date: c.released_date || null,
    payment_date: c.payment_date || null,
    installment_number: c.installment_number || null,
  }));

  return paginate(mapped, params.page, params.page_size);
}

async function getPayments(sdk, params) {
  let data = await sdk.asServiceRole.entities.Payment.list('-due_date', 5000);

  data = filterByDate(data, 'payment_date', params.date_from, params.date_to);
  if (params.status) data = filterByStatus(data, params.status);

  const mapped = data.map(p => ({
    payment_id: p.id,
    policy_id: p.policy_id || null,
    policy_number: p.policy_number || null,
    client_name: p.client_name || null,
    due_date: p.due_date || null,
    payment_date: p.payment_date || null,
    period: p.period || null,
    amount: p.amount || 0,
    currency: p.currency || null,
    payment_method: p.payment_method || null,
    status: p.status || null,
    installment_number: p.installment_number || null,
    payment_group: p.payment_group || null,
  }));

  return paginate(mapped, params.page, params.page_size);
}

async function getClaims(sdk, params) {
  let data = await sdk.asServiceRole.entities.Claim.list('-event_date', 5000);

  data = filterByDate(data, 'event_date', params.date_from, params.date_to);
  if (params.status) data = filterByStatus(data, params.status);

  const mapped = data.map(c => ({
    claim_id: c.id,
    claim_number: c.claim_number || null,
    policy_id: c.policy_id || null,
    policy_number: c.policy_number || null,
    client_id: c.client_id || null,
    client_name: c.client_name || null,
    corporate_member_name: c.corporate_member_name || null,
    affected_person: c.affected_person || null,
    dependent_name: c.dependent_name || null,
    claim_type: c.claim_type || null,
    event_date: c.event_date || null,
    claimed_amount: c.claimed_amount || 0,
    paid_amount: c.paid_amount || 0,
    currency: c.currency || null,
    status: c.status || null,
    payment_date: c.payment_date || null,
    observations: c.observations || null,
  }));

  return paginate(mapped, params.page, params.page_size);
}

async function getAgents(sdk, params) {
  let data = await sdk.asServiceRole.entities.Agent.list('name', 5000);

  if (params.status) data = filterByStatus(data, params.status);

  // Build upline map for structure info
  const agentMap = {};
  data.forEach(a => { agentMap[a.id] = a.name; });

  const mapped = data.map(a => ({
    agent_id: a.id,
    name: a.name || null,
    alias: a.alias || null,
    email: a.email || null,
    country: a.country || null,
    agent_type: a.agent_type || null,
    level: a.level || null,
    is_nivel_2: a.is_nivel_2 || false,
    is_gapartner: a.is_gapartner || false,
    upline_agent_id: a.upline_agent_id || null,
    upline_agent_name: a.upline_agent_name || agentMap[a.upline_agent_id] || null,
    status: a.status || null,
    created_date: a.created_date || null,
  }));

  return paginate(mapped, params.page, params.page_size);
}

// ── Main Handler ──────────────────────────────────────────────────────────────

export default (async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  if (req.method !== 'GET') {
    return Response.json({ error: 'Method not allowed' }, { status: 405, headers: CORS_HEADERS });
  }

  if (!validateApiKey(req)) return authError();

  const params = parseParams(req);
  const sdk = createClientFromRequest(req);

  const handlers = {
    policies: getPolicies,
    commissions: getCommissions,
    payments: getPayments,
    claims: getClaims,
    agents: getAgents,
  };

  const handler = handlers[params.endpoint];
  if (!handler) {
    return Response.json({
      error: 'Unknown endpoint. Use ?endpoint= with one of: policies, commissions, payments, claims, agents',
      available_endpoints: Object.keys(handlers),
    }, { status: 400, headers: CORS_HEADERS });
  }

  try {
    const result = await handler(sdk, params);
    return Response.json({
      endpoint: params.endpoint,
      filters: {
        date_from: params.date_from,
        date_to: params.date_to,
        status: params.status,
      },
      ...result,
    }, { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500, headers: CORS_HEADERS });
  }
});