import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Use service role to bypass RLS and fetch UserRole
    const allRoles = await sdk.asServiceRole.entities.UserRole.list();

    // SDK returns records with fields nested under .data
    const userRole = allRoles.find(ur => {
      const email = ur.data?.email || ur.email;
      return email?.toLowerCase() === user.email?.toLowerCase();
    });
    
    if (!userRole) {
      console.log(`No UserRole found for ${user.email}`);
      return Response.json({
        email: user.email,
        app_role: null,
        agent_id: null,
        status: 'pending_activation'
      });
    }

    // Fields are under .data when returned from service role list
    const roleData = userRole.data || userRole;
    const app_role = roleData.app_role;
    const agent_id = roleData.agent_id || null;
    const status = roleData.status;
    const roleId = userRole.id;

    console.log(`UserRole found for ${user.email}:`, { app_role, agent_id, status });

    // Sync app_role and agent_id into user.data so RLS policies can see them
    if (user.data?.app_role !== app_role || user.data?.agent_id !== agent_id) {
      try {
        await sdk.auth.updateMe({
          app_role,
          agent_id: agent_id || null,
        });
        console.log(`Synced app_role="${app_role}", agent_id="${agent_id}" to user.data for ${user.email}`);
      } catch (syncErr) {
        console.error('Failed to sync user.data:', syncErr.message);
      }
    }

    return Response.json({
      id: roleId,
      email: roleData.email,
      app_role,
      agent_id,
      status,
      mfa_enabled: roleData.mfa_enabled || false,
      mfa_method: roleData.mfa_method || null,
      mfa_setup_date: roleData.mfa_setup_date || null,
      mfa_grace_deadline: roleData.mfa_grace_deadline || null,
      crm_access_enabled: roleData.crm_access_enabled || false
    });
  } catch (error) {
    console.error('Error fetching user role:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});