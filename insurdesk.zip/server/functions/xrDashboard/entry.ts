import { createClientFromRequest } from '../../runtime/sdk.js';
import {
  CORS_HEADERS,
  unauthorizedResponse,
  checkAuth,
  handleOptionsAndMethod,
  dateStr,
} from '../../shared/xrAuth.ts';

/**
 * GET xrDashboard
 * Devuelve KPIs y datos agregados para el tablero XR.
 * Requiere header: Authorization: Bearer <XR_READ_TOKEN>
 *
 * Parámetros de consulta (todos opcionales, combinables):
 *   desde, hasta      — YYYY-MM-DD, sobre fecha de inicio de vigencia (start_date)
 *   ramo              — uno o varios separados por coma
 *   compania          — uno o varios separados por coma
 *   ejecutivo         — uno o varios separados por coma
 *   ciudad            — uno o varios separados por coma
 *   primaMin, primaMax — número
 */
export default async function(req) {
  const earlyReturn = handleOptionsAndMethod(req);
  if (earlyReturn) return earlyReturn;
  if (!checkAuth(req)) return unauthorizedResponse();

  try {
    const sdk = createClientFromRequest(req);
    const url = new URL(req.url);

    const desde = url.searchParams.get('desde');
    const hasta = url.searchParams.get('hasta');
    const ramos = parseListParam(url, 'ramo');
    const companias = parseListParam(url, 'compania');
    const ejecutivos = parseListParam(url, 'ejecutivo');
    const ciudades = parseListParam(url, 'ciudad');
    const primaMin = parseFloatParam(url, 'primaMin');
    const primaMax = parseFloatParam(url, 'primaMax');

    // Cargar pólizas y clientes en paralelo
    const [policies, clients] = await Promise.all([
      sdk.asServiceRole.entities.Policy.list('-start_date', 10000),
      sdk.asServiceRole.entities.Client.list('-created_date', 10000),
    ]);

    // Excluir pólizas canceladas
    const activePolicies = policies.filter(p => p.status !== 'cancelada');

    // Mapa client_id → city
    const cityMap = {};
    clients.forEach(c => { if (c.id) cityMap[c.id] = c.city || ''; });

    const getCity = (p) => cityMap[p.client_id] || '';

    // Filtros comunes: ramo, compania, ejecutivo, ciudad, prima
    const applyCommonFilters = (p) => {
      if (ramos && !ramos.includes(p.line_name)) return false;
      if (companias && !companias.includes(p.company_name)) return false;
      if (ejecutivos && !ejecutivos.includes(p.agent_name)) return false;
      if (ciudades && !ciudades.includes(getCity(p))) return false;
      const premium = p.annual_premium || 0;
      if (primaMin != null && premium < primaMin) return false;
      if (primaMax != null && premium > primaMax) return false;
      return true;
    };

    // ── KPIs y produccionPorRamo: aplican TODOS los filtros (incluido desde/hasta) ──
    let dashboardPolicies = activePolicies.filter(applyCommonFilters);
    if (desde) dashboardPolicies = dashboardPolicies.filter(p => p.start_date && p.start_date >= desde);
    if (hasta) dashboardPolicies = dashboardPolicies.filter(p => p.start_date && p.start_date <= hasta);

    const primaTotal = dashboardPolicies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
    const polizasCount = dashboardPolicies.length;
    const primaPromedio = polizasCount > 0 ? primaTotal / polizasCount : 0;

    // Producción por ramo (máx 6, ordenados por prima desc)
    const ramoMap = {};
    dashboardPolicies.forEach(p => {
      const ramo = p.line_name || 'Sin Ramo';
      ramoMap[ramo] = (ramoMap[ramo] || 0) + (p.annual_premium || 0);
    });
    const produccionPorRamo = Object.entries(ramoMap)
      .map(([ramo, prima]) => ({ ramo, prima: Math.round(prima * 100) / 100 }))
      .sort((a, b) => b.prima - a.prima)
      .slice(0, 6);

    // ── porCompania, porEjecutivo, porCiudad (mismo set que dashboardPolicies) ──
    const companiaAgg = {}, ejecutivoAgg = {}, ciudadAgg = {};
    dashboardPolicies.forEach(p => {
      const comp = p.company_name || 'Sin Compañía';
      const ej = p.agent_name || 'Sin Ejecutivo';
      const ciu = getCity(p) || 'Sin Ciudad';
      const prima = p.annual_premium || 0;
      if (!companiaAgg[comp]) companiaAgg[comp] = { prima: 0, polizas: 0 };
      companiaAgg[comp].prima += prima; companiaAgg[comp].polizas++;
      if (!ejecutivoAgg[ej]) ejecutivoAgg[ej] = { prima: 0, polizas: 0 };
      ejecutivoAgg[ej].prima += prima; ejecutivoAgg[ej].polizas++;
      if (!ciudadAgg[ciu]) ciudadAgg[ciu] = { prima: 0, polizas: 0 };
      ciudadAgg[ciu].prima += prima; ciudadAgg[ciu].polizas++;
    });
    const porCompania = Object.entries(companiaAgg)
      .map(([compania, v]) => ({ compania, prima: Math.round(v.prima * 100) / 100, polizas: v.polizas }))
      .sort((a, b) => b.prima - a.prima).slice(0, 6);
    const porEjecutivo = Object.entries(ejecutivoAgg)
      .map(([ejecutivo, v]) => ({ ejecutivo, prima: Math.round(v.prima * 100) / 100, polizas: v.polizas }))
      .sort((a, b) => b.prima - a.prima).slice(0, 6);
    const porCiudad = Object.entries(ciudadAgg)
      .map(([ciudad, v]) => ({ ciudad, prima: Math.round(v.prima * 100) / 100, polizas: v.polizas }))
      .sort((a, b) => b.prima - a.prima).slice(0, 6);

    // ── Renovaciones: aplican filtros comunes PERO NO desde/hasta ──
    const renewalPolicies = activePolicies.filter(applyCommonFilters);

    const now = new Date();
    const todayStr = dateStr(now);
    const max90dStr = dateStr(new Date(now.getTime() + 90 * 86400000));
    const max30dStr = dateStr(new Date(now.getTime() + 30 * 86400000));

    const renewalCandidates = renewalPolicies
      .filter(p => p.end_date && p.end_date >= todayStr && p.end_date <= max90dStr)
      .sort((a, b) => a.end_date.localeCompare(b.end_date));

    // Próximas 6 renovaciones
    const renovaciones = renewalCandidates.slice(0, 6).map(p => ({
      cliente: p.client_name || 'N/A',
      ramo: p.line_name || 'Sin Ramo',
      compania: p.company_name || 'N/A',
      fecha: p.end_date,
      prima: Math.round((p.annual_premium || 0) * 100) / 100,
    }));

    // Cantidad que renueva en los próximos 30 días
    const renovaciones30d = renewalCandidates.filter(p => p.end_date <= max30dStr).length;

    // ── tendenciaMensual (common filters, NO desde/hasta, excludes cancelada) ──
    const currentYear = now.getFullYear();
    const prevYear = currentYear - 1;
    const tendenciaActual = new Array(12).fill(0);
    const tendenciaAnterior = new Array(12).fill(0);
    renewalPolicies.forEach(p => {
      if (!p.start_date) return;
      const parts = p.start_date.split('-');
      const y = Number(parts[0]); const m = Number(parts[1]);
      if (y === currentYear) tendenciaActual[m - 1] += p.annual_premium || 0;
      else if (y === prevYear) tendenciaAnterior[m - 1] += p.annual_premium || 0;
    });
    const tendenciaMensual = {
      anioActual: currentYear,
      anioAnterior: prevYear,
      actual: tendenciaActual.map(v => Math.round(v * 100) / 100),
      anterior: tendenciaAnterior.map(v => Math.round(v * 100) / 100),
    };

    // ── calendarioRenovaciones (common filters, NO desde/hasta, excludes cancelada) ──
    const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const todayMs = todayMidnight.getTime();
    const semanas = [];
    for (let i = 0; i < 13; i++) {
      semanas.push({ inicio: dateStr(new Date(todayMs + i * 7 * 86400000)), polizas: 0, prima: 0 });
    }
    const d30End = dateStr(new Date(todayMs + 30 * 86400000));
    const d60End = dateStr(new Date(todayMs + 60 * 86400000));
    const d90End = dateStr(new Date(todayMs + 90 * 86400000));
    const d30 = { polizas: 0, prima: 0 }, d60 = { polizas: 0, prima: 0 }, d90 = { polizas: 0, prima: 0 };
    renewalPolicies.forEach(p => {
      if (!p.end_date) return;
      const parts = p.end_date.split('-');
      const endTs = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])).getTime();
      const diffDays = Math.floor((endTs - todayMs) / 86400000);
      if (diffDays >= 0 && diffDays <= 90) {
        const weekIdx = Math.floor(diffDays / 7);
        if (weekIdx < 13) {
          semanas[weekIdx].polizas++;
          semanas[weekIdx].prima += p.annual_premium || 0;
        }
      }
      if (p.end_date >= todayStr) {
        const prima = p.annual_premium || 0;
        if (p.end_date <= d30End) { d30.polizas++; d30.prima += prima; }
        if (p.end_date <= d60End) { d60.polizas++; d60.prima += prima; }
        if (p.end_date <= d90End) { d90.polizas++; d90.prima += prima; }
      }
    });
    semanas.forEach(s => s.prima = Math.round(s.prima * 100) / 100);
    const calendarioRenovaciones = {
      semanas,
      riesgo: {
        d30: { polizas: d30.polizas, prima: Math.round(d30.prima * 100) / 100 },
        d60: { polizas: d60.polizas, prima: Math.round(d60.prima * 100) / 100 },
        d90: { polizas: d90.polizas, prima: Math.round(d90.prima * 100) / 100 },
      },
    };

    // ── cancelaciones (ALL policies incl cancelada, common filters + desde/hasta) ──
    let allFilteredPolicies = policies.filter(applyCommonFilters);
    if (desde) allFilteredPolicies = allFilteredPolicies.filter(p => p.start_date && p.start_date >= desde);
    if (hasta) allFilteredPolicies = allFilteredPolicies.filter(p => p.start_date && p.start_date <= hasta);
    const cancelTotal = allFilteredPolicies.length;
    const canceladasCount = allFilteredPolicies.filter(p => p.status === 'cancelada').length;
    const cancelPct = cancelTotal > 0 ? (canceladasCount / cancelTotal) * 100 : 0;
    const cancelRamoMap = {};
    allFilteredPolicies.forEach(p => {
      const ramo = p.line_name || 'Sin Ramo';
      if (!cancelRamoMap[ramo]) cancelRamoMap[ramo] = { canceladas: 0, total: 0 };
      cancelRamoMap[ramo].total++;
      if (p.status === 'cancelada') cancelRamoMap[ramo].canceladas++;
    });
    const cancelaciones = {
      total: cancelTotal,
      canceladas: canceladasCount,
      porcentaje: Math.round(cancelPct * 100) / 100,
      porRamo: Object.entries(cancelRamoMap)
        .map(([ramo, v]) => ({
          ramo,
          canceladas: v.canceladas,
          total: v.total,
          porcentaje: v.total > 0 ? Math.round((v.canceladas / v.total) * 10000) / 100 : 0,
        }))
        .sort((a, b) => b.porcentaje - a.porcentaje).slice(0, 5),
    };

    return Response.json(
      {
        kpis: {
          primaTotal: Math.round(primaTotal * 100) / 100,
          polizas: polizasCount,
          primaPromedio: Math.round(primaPromedio * 100) / 100,
          renovaciones30d,
        },
        produccionPorRamo,
        porCompania,
        porEjecutivo,
        porCiudad,
        tendenciaMensual,
        calendarioRenovaciones,
        cancelaciones,
        renovaciones,
        actualizadoEn: new Date().toISOString(),
      },
      { status: 200, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return Response.json(
      { error: error.message },
      { status: 500, headers: CORS_HEADERS }
    );
  }
}

// ── Helpers ──
function parseListParam(url, key) {
  const val = url.searchParams.get(key);
  if (!val) return null;
  return val.split(',').map(s => s.trim()).filter(Boolean);
}

function parseFloatParam(url, key) {
  const val = url.searchParams.get(key);
  if (!val) return null;
  const n = parseFloat(val);
  return isNaN(n) ? null : n;
}