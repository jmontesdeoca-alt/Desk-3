import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';
import { generateEmailCode, findUserRoleByEmail, extractRoleData } from '../../shared/mfa-utils.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const userRole = await findUserRoleByEmail(sdk, user.email);
    if (!userRole) {
      return Response.json({ error: 'No se encontró el registro de usuario' }, { status: 404 });
    }

    const roleData = extractRoleData(userRole);
    const roleId = userRole.id;
    const code = generateEmailCode();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    await sdk.asServiceRole.entities.UserRole.update(roleId, {
      mfa_email_code: code,
      mfa_email_code_expires: expiresAt
    });

    const emailBody = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"/></head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 480px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(to right, #001E2E, #004B6F); padding: 20px; border-radius: 8px 8px 0 0;">
    <h1 style="color: white; margin: 0;">GA<span style="color: #76DDF9;">Portal</span></h1>
    <p style="color: #76DDF9; margin: 5px 0 0;">Verificación MFA</p>
  </div>
  <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p>Tu código de verificación es:</p>
    <div style="font-size: 32px; font-weight: bold; letter-spacing: 8px; text-align: center; padding: 20px; background: #f0f9ff; border-radius: 8px; color: #063f5c;">
      ${code}
    </div>
    <p style="color: #666; font-size: 14px;">Este código expira en 5 minutos.</p>
    <p style="color: #999; font-size: 12px;">Si no solicitaste este código, ignora este correo.</p>
  </div>
</body>
</html>`;

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) {
      return Response.json({ error: 'RESEND_API_KEY not configured' }, { status: 500 });
    }

    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: brand.from(),
        to: [user.email],
        subject: 'Código de verificación MFA - InsurDesk',
        html: emailBody
      })
    });

    if (!resendResponse.ok) {
      let errData;
      try { errData = await resendResponse.json(); } catch { errData = {}; }
      const errMsg = errData.message || errData.error || resendResponse.statusText;
      throw new Error(`Resend API (${resendResponse.status}): ${errMsg}`);
    }

    return Response.json({ success: true, message: 'Código enviado' });
  } catch (error) {
    console.error('Error in sendMFAEmailOTP:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}