import { createClientFromRequest } from '../../runtime/sdk.js';
import { local as localDocs } from '../../runtime/localdocs.js';
import { BlobServiceClient, StorageSharedKeyCredential, generateBlobSASQueryParameters, BlobSASPermissions } from '@azure/storage-blob';

function parseConnectionString(connStr) {
  const parts = {};
  for (const segment of connStr.split(';')) {
    const idx = segment.indexOf('=');
    if (idx > -1) {
      parts[segment.slice(0, idx)] = segment.slice(idx + 1);
    }
  }
  return {
    accountName: parts['AccountName'],
    accountKey: parts['AccountKey'],
    endpointSuffix: parts['EndpointSuffix'] || 'core.windows.net'
  };
}

export default (async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const sdk = createClientFromRequest(req);
  const user = await sdk.auth.me();
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const connStr = process.env.AZURE_STORAGE_CONNECTION_STRING;
  if (!connStr) {
    return await localDocs.url(req);
  }

  const body = await req.json();
  const { blobPath } = body.payload ?? body;

  if (!blobPath) {
    return Response.json({ error: 'blobPath es requerido' }, { status: 400 });
  }

  const containerName = 'documentos';
  const { accountName, accountKey, endpointSuffix } = parseConnectionString(connStr);

  const now = new Date();
  const startsOn = new Date(now.getTime() - 5 * 60 * 1000);   // 5 min before
  const expiresOn = new Date(now.getTime() + 30 * 60 * 1000); // 30 min after

  console.log('[getAzureDocumentUrl] blobPath:', blobPath);
  console.log('[getAzureDocumentUrl] containerName:', containerName);
  console.log('[getAzureDocumentUrl] startsOn:', startsOn.toISOString());
  console.log('[getAzureDocumentUrl] expiresOn:', expiresOn.toISOString());

  const sharedKeyCredential = new StorageSharedKeyCredential(accountName, accountKey);

  // Validate blob exists
  const blobServiceClient = new BlobServiceClient(
    `https://${accountName}.blob.${endpointSuffix}`,
    sharedKeyCredential
  );
  const containerClient = blobServiceClient.getContainerClient(containerName);
  const blobClient = containerClient.getBlobClient(blobPath);

  const exists = await blobClient.exists();
  if (!exists) {
    console.log('[getAzureDocumentUrl] Blob not found:', blobPath);
    return Response.json({ error: 'Archivo no encontrado en storage' }, { status: 404 });
  }

  // Generate SAS using official SDK
  const sasQueryParams = generateBlobSASQueryParameters(
    {
      containerName,
      blobName: blobPath,
      permissions: BlobSASPermissions.parse('r'),
      startsOn,
      expiresOn,
      protocol: 'https',
    },
    sharedKeyCredential
  );

  const readUrl = `${blobClient.url}?${sasQueryParams.toString()}`;
  console.log('[getAzureDocumentUrl] SAS URL generated successfully');

  return Response.json({ ok: true, url: readUrl });
});