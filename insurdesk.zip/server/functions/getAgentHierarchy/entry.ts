import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { agentId, includePolicies } = await req.json();

    if (!agentId) {
      return Response.json({ error: 'agentId is required' }, { status: 400 });
    }

    // Obtener rol del usuario que llama
    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const appRole = userRole?.app_role;

    // Fetch all agents using service role to bypass RLS
    const allAgents = await sdk.asServiceRole.entities.Agent.list();

    const buildDownline = (rootId) => {
      const ids = new Set();
      const walk = (currentId) => {
        ids.add(currentId);
        allAgents
          .filter(a => a.upline_agent_id === currentId)
          .forEach(a => walk(a.id));
      };
      walk(rootId);
      return ids;
    };

    // Roles con visibilidad total: sin restricción
    const fullAccessRoles = ['admin', 'gerencial', 'jefatura', 'operativo', 'financiero'];

    if (!fullAccessRoles.includes(appRole)) {
      // Rol "agente": solo puede pedir su propia jerarquía descendente
      const ownAgentId = userRole?.agent_id;
      if (!ownAgentId) {
        return Response.json({ error: 'Agente no vinculado' }, { status: 403 });
      }
      const ownDownline = buildDownline(ownAgentId);
      if (!ownDownline.has(agentId)) {
        return Response.json({ error: 'Sin acceso a esta jerarquía' }, { status: 403 });
      }
    }

    const hierarchyIds = Array.from(buildDownline(agentId));

    // If requested, also return all policies for the full structure (bypassing RLS)
    if (includePolicies) {
      const allPolicies = await sdk.asServiceRole.entities.Policy.list('-created_date', 5000);
      const structurePolicies = allPolicies.filter(p => hierarchyIds.includes(p.agent_id));
      return Response.json({ agentIds: hierarchyIds, policies: structurePolicies });
    }

    return Response.json({ agentIds: hierarchyIds });
  } catch (error) {
    console.error('Error fetching agent hierarchy:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});