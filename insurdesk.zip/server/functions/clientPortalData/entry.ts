import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const body = await req.json();
    const { clientId, sessionToken } = body;

    if (!clientId || !sessionToken) {
      return Response.json({ error: 'Sesión inválida' }, { status: 401 });
    }

    // Validar token de sesión emitido por clientPortalOTP
    const sessions = await sdk.asServiceRole.entities.AppSettings.filter({
      setting_key: `portal_session_${sessionToken}`
    });

    if (!sessions || sessions.length === 0) {
      return Response.json({ error: 'Sesión expirada o inválida' }, { status: 401 });
    }

    let session;
    try { session = JSON.parse(sessions[0].setting_value); } catch {
      return Response.json({ error: 'Sesión inválida' }, { status: 401 });
    }

    if (new Date() > new Date(session.expiresAt)) {
      // Limpiar sesión expirada
      await sdk.asServiceRole.entities.AppSettings.delete(sessions[0].id);
      return Response.json({ error: 'Sesión expirada' }, { status: 401 });
    }

    if (session.clientId !== clientId) {
      return Response.json({ error: 'Sin acceso a este cliente' }, { status: 403 });
    }

    // A partir de aquí, el código queda igual que antes
    const [clients, dependents, policies] = await Promise.all([
      sdk.asServiceRole.entities.Client.filter({ id: clientId }),
      sdk.asServiceRole.entities.Dependent.filter({ client_id: clientId }),
      sdk.asServiceRole.entities.Policy.filter({ client_id: clientId }),
    ]);

    const client = clients[0];
    if (!client) return Response.json({ error: 'Cliente no encontrado' }, { status: 404 });

    let payments = [];
    let claims = [];
    if (policies.length > 0) {
      const policyIds = policies.map(p => p.id);
      const [allPayments, allClaims] = await Promise.all([
        sdk.asServiceRole.entities.Payment.list('-due_date', 200),
        sdk.asServiceRole.entities.Claim.list('-event_date', 100),
      ]);
      payments = allPayments.filter(p => policyIds.includes(p.policy_id));
      claims = allClaims.filter(c => policyIds.includes(c.policy_id));
    }

    return Response.json({ client, dependents, policies, payments, claims });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});