import { createClientFromRequest } from '../../runtime/sdk.js';
import { getTRMBatch, convertToUSD } from '../../shared/currencyConversion.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const appRole = userRole?.app_role || 'admin';
    const agentId = userRole?.agent_id;
    const needsStructure = appRole === 'gerencial' && agentId;

    // Load policies (for scope filtering) + agents (for structure) + payments
    const [policies, payments, agents] = await Promise.all([
      sdk.asServiceRole.entities.Policy.list(),
      sdk.asServiceRole.entities.Payment.list(),
      sdk.asServiceRole.entities.Agent.list()
    ]);

    let allowedAgentIds = [];
    if (needsStructure) {
      allowedAgentIds = [agentId];
      const findDownline = (id) => {
        agents.filter(a => a.upline_agent_id === id).forEach(a => {
          allowedAgentIds.push(a.id);
          findDownline(a.id);
        });
      };
      findDownline(agentId);
    }

    const filteredPolicies = needsStructure
      ? policies.filter(p => allowedAgentIds.includes(p.agent_id))
      : policies;

    const policyIds = new Set(filteredPolicies.map(p => p.id));
    const filteredPayments = payments.filter(p => policyIds.has(p.policy_id));

    const overduePayments = filteredPayments.filter(p => p.status === 'atrasado').length;
    const pendingPayments = filteredPayments.filter(p => p.status === 'pendiente').length;

    // Montos convertidos a USD usando TRM de la fecha de emisión de cada póliza
    const policyMap = new Map(filteredPolicies.map(p => [p.id, p]));
    const copIssueDates = filteredPolicies
      .filter(p => p.currency === 'COP' && p.issue_date)
      .map(p => p.issue_date);
    const trmMap = await getTRMBatch(sdk.asServiceRole, copIssueDates);

    const overdueAmountUSD = filteredPayments
      .filter(p => p.status === 'atrasado')
      .reduce((sum, p) => {
        const policy = policyMap.get(p.policy_id);
        return sum + convertToUSD(p.amount || 0, policy?.currency || p.currency, policy?.issue_date, trmMap);
      }, 0);

    const pendingAmountUSD = filteredPayments
      .filter(p => p.status === 'pendiente')
      .reduce((sum, p) => {
        const policy = policyMap.get(p.policy_id);
        return sum + convertToUSD(p.amount || 0, policy?.currency || p.currency, policy?.issue_date, trmMap);
      }, 0);

    return Response.json({ overduePayments, pendingPayments, overdueAmountUSD, pendingAmountUSD });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}