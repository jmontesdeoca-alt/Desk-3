import { createClientFromRequest } from '../../runtime/sdk.js';
import { loadAll } from '../../shared/loadAll.js';

/**
 * Returns ALL policies using cursor-based pagination (bypasses the 5000-record SDK limit).
 * Intended for non-agent users (admin, operativo, jefatura, financiero, gerencial without agent_id).
 * Agents and gerencial-with-agent must use getAgentHierarchy instead.
 */
export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Verify user role
    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const appRole = userRole?.app_role || user.role;
    const agentId = userRole?.agent_id;

    // Agents and gerencial-with-agent must use getAgentHierarchy (not this function)
    const isAgentOrGerencial = (appRole === 'agente' || (appRole === 'gerencial' && agentId)) && appRole !== 'financiero';
    if (isAgentOrGerencial) {
      return Response.json({ error: 'Use getAgentHierarchy instead' }, { status: 403 });
    }

    // Paginate through all policies
    const policies = await loadAll(sdk.asServiceRole.entities.Policy, 'created_date');
    // Reverse to newest-first, matching Policy.list('-created_date')
    policies.reverse();

    return Response.json({ policies, total: policies.length });
  } catch (error) {
    console.error('Error in getAllPolicies:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}