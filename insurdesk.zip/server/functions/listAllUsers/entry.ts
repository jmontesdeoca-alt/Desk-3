import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Any authenticated user can list users (needed for task assignment)
    // Use service role to bypass RLS
    const users = await sdk.asServiceRole.entities.User.list();

    return Response.json({ users });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});