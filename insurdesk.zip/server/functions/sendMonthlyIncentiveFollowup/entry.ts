import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);

    // Parse body for optional test_email parameter
    let testEmail = null;
    let testAgentId = null;
    try {
      const body = await req.json();
      testEmail = body?.test_email || null;
      testAgentId = body?.test_agent_id || null;
    } catch {}

    // Check if automatic emails are enabled (skip in test mode)
    if (!testEmail) {
      const emailSettings = await sdk.asServiceRole.entities.AppSettings.filter({
        setting_key: 'automatic_emails_enabled'
      });
      if (emailSettings.length > 0 && emailSettings[0].setting_value !== 'true') {
        return Response.json({ success: true, message: 'Automatic emails disabled', sent: 0 });
      }
    }

    // Cutoff: last day of previous month
    const now = new Date();
    const cutoff = new Date(now.getFullYear(), now.getMonth(), 0);
    const cutoffStr = cutoff.toISOString().split('T')[0];
    const monthNames = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const cutoffLabel = `${monthNames[cutoff.getMonth()]} ${cutoff.getFullYear()}`;

    // Fetch data
    const [incentives, agents, policies] = await Promise.all([
      sdk.asServiceRole.entities.Incentive.filter({ status: 'active' }, '-created_date', 100),
      sdk.asServiceRole.entities.Agent.filter({ status: 'activo' }, 'name', 1000),
      sdk.asServiceRole.entities.Policy.list('-start_date', 5000)
    ]);

    if (!incentives || incentives.length === 0) {
      return Response.json({ success: true, message: 'No active incentives', sent: 0 });
    }

    // Helper: check if policy participates in incentive
    function isPolicyParticipant(policy, incentive) {
      const { participants } = incentive;
      if (!participants || (!participants.companies?.length && !participants.products?.length)) return true;
      const participantCompanyIds = new Set((participants.companies || []).map(c => c.id));
      const participantProductIds = new Set((participants.products || []).map(p => p.id));
      if (!participantCompanyIds.has(policy.company_id)) return false;
      const companyHasProductRestriction = (participants.products || []).some(p => p.company_id === policy.company_id);
      if (companyHasProductRestriction && !participantProductIds.has(policy.product_id)) return false;
      return true;
    }

    // Helper: get effective multiplier
    function getEffectiveMultiplier(policy, incentive) {
      const { rules = [], boost_rules = [] } = incentive;
      const companyMultipliers = {};
      const productMultipliers = {};
      rules.forEach(r => {
        if (r.rule_type === 'company') companyMultipliers[r.id] = parseFloat(r.multiplier);
        else productMultipliers[r.id] = parseFloat(r.multiplier);
      });
      let multiplier = 1;
      if (policy.product_id && productMultipliers[policy.product_id] !== undefined) {
        multiplier = productMultipliers[policy.product_id];
      } else if (policy.company_id && companyMultipliers[policy.company_id] !== undefined) {
        multiplier = companyMultipliers[policy.company_id];
      }
      boost_rules.forEach(b => {
        if (!b.start_date || !b.end_date || !b.id) return;
        if (policy.issue_date < b.start_date || policy.issue_date > b.end_date) return;
        const additional = parseFloat(b.additional_multiplier || 0);
        if (b.rule_type === 'product' && policy.product_id === b.id) {
          multiplier += additional;
        } else if (b.rule_type === 'company' && policy.company_id === b.id) {
          const hasProductRule = policy.product_id && productMultipliers[policy.product_id] !== undefined;
          if (!hasProductRule) multiplier += additional;
        }
      });
      return multiplier;
    }

    // Helper: calculate agent progress on incentive
    function calcAgentProgress(agentId, allPolicies, incentive) {
      const { start_date, end_date } = incentive;
      let total = 0;
      allPolicies.forEach(p => {
        if (p.agent_id !== agentId) return;
        if (p.policy_type !== 'nuevo_negocio') return;
        if (!p.issue_date || p.issue_date < start_date || p.issue_date > end_date) return;
        if (p.issue_date > cutoffStr) return;
        if (p.status === 'cancelada') return;
        if (!isPolicyParticipant(p, incentive)) return;
        const basePremium = parseFloat(p.annual_premium || p.commissionable_premium || 0);
        total += basePremium * getEffectiveMultiplier(p, incentive);
      });
      return total;
    }

    function getStageReached(amount, stages) {
      if (!stages || stages.length === 0) return null;
      const sorted = [...stages].sort((a, b) => b.threshold_amount - a.threshold_amount);
      return sorted.find(s => amount >= s.threshold_amount) || null;
    }

    function fmt(val, currency) {
      return new Intl.NumberFormat('es-EC', { style: 'currency', currency: currency || 'USD', maximumFractionDigits: 0 }).format(val || 0);
    }

    // Resend direct email helper
    async function sendViaResend(toEmail, subject, htmlBody) {
      const apiKey = process.env.RESEND_API_KEY;
      if (!apiKey) throw new Error('RESEND_API_KEY not configured');
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: brand.from(),
          to: [toEmail],
          subject: subject,
          html: htmlBody
        })
      });
      if (!response.ok) {
        const err = await response.text();
        throw new Error(`Resend API (${response.status}): ${err}`);
      }
      return await response.json();
    }

    const appDomain = process.env.APP_DOMAIN;
    const portalLink = appDomain ? (appDomain.startsWith('http') ? appDomain : `https://${appDomain}`) : null;

    // In test mode, only send to 10 random agents
    let agentsToSend = agents.filter(a => a.email);
    if (testAgentId) {
      agentsToSend = agentsToSend.filter(a => a.id === testAgentId);
    } else if (testEmail) {
      agentsToSend = [...agentsToSend].sort(() => Math.random() - 0.5).slice(0, 10);
    }

    let emailsSent = 0;
    const results = [];

    for (const agent of agentsToSend) {
      const recipientEmail = testEmail || agent.email;

      const rows = incentives.map(inc => {
        const target = parseFloat(inc.target_amount || 0);
        const current = calcAgentProgress(agent.id, policies, inc);
        const pct = target > 0 ? Math.min(Math.round((current / target) * 100), 100) : 0;
        const missing = Math.max(0, target - current);
        const stage = getStageReached(current, inc.stages);
        const won = current >= target;
        return { inc, target, current, pct, missing, stage, won };
      });

      // Skip agents with zero progress across all incentives (individual + agency)
      const totalProgress = rows.reduce((sum, r) => sum + r.current, 0);
      if (totalProgress === 0) {
        results.push({ agent: agent.name, email: recipientEmail, status: 'skipped', reason: 'Sin cumplimiento en todos los incentivos' });
        continue;
      }

      const rowsHtml = rows.map(r => {
        const pctColor = r.pct >= 100 ? '#10B981' : r.pct >= 70 ? '#3B82F6' : r.pct >= 40 ? '#F59E0B' : '#EF4444';
        const stageStr = r.won
          ? '<span style="color: #10B981; font-weight: bold;">🏆 Meta</span>'
          : r.stage
            ? `<span style="color: #F59E0B;">🎯 ${r.stage.reward_description}</span>`
            : '<span style="color: #999;">—</span>';
        const missingStr = r.won
          ? '<span style="color: #10B981; font-weight: bold;">✓ Cumplido</span>'
          : fmt(r.missing, r.inc.currency);
        return `<tr>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;">
            <div>${r.inc.name}</div>
            <div style="font-size: 11px; color: #999; margin-top: 2px;">Clasificación: ${((r.inc.target_for || []).map(t => t === 'agent_individual' ? 'Individual' : t === 'agent_agency' ? 'Agencia' : t).join(' / ')) || 'General'}</div>
          </td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right;">${fmt(r.target, r.inc.currency)}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: bold;">${fmt(r.current, r.inc.currency)}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: center; color: ${pctColor}; font-weight: bold;">${r.pct}%</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: center;">${stageStr}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right;">${missingStr}</td>
        </tr>`;
      }).join('');

      const subjectPrefix = testEmail ? `[PRUEBA - ${agent.name}] ` : '';
      const htmlBody = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(to right, #001E2E, #004B6F); padding: 20px; border-radius: 8px 8px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 22px;">GA<span style="color: #76DDF9;">Portal</span></h1>
            <p style="color: #76DDF9; margin: 5px 0 0; font-size: 14px;">Resumen Mensual de Incentivos</p>
          </div>
          <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
            <p style="color: #333; font-size: 16px;">Hola <strong>${agent.name}</strong>,</p>
            <p style="color: #666; font-size: 14px;">Aquí tienes tu resumen de incentivos con corte al <strong>${cutoffLabel}</strong>:</p>
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 13px;">
              <thead>
                <tr style="background: #004B6F; color: white;">
                  <th style="padding: 10px; text-align: left;">Incentivo</th>
                  <th style="padding: 10px; text-align: right;">Objetivo</th>
                  <th style="padding: 10px; text-align: right;">Alcanzado</th>
                  <th style="padding: 10px; text-align: center;">%</th>
                  <th style="padding: 10px; text-align: center;">Etapa</th>
                  <th style="padding: 10px; text-align: right;">Te falta</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>
            ${portalLink ? `<p style="text-align: center; margin-top: 20px;"><a href="${portalLink}/Incentives" style="background: #004B6F; color: white; padding: 10px 24px; text-decoration: none; border-radius: 6px; font-size: 14px;">Ver detalle en InsurDesk</a></p>` : ''}
            <p style="color: #999; font-size: 12px; text-align: center; margin-top: 20px;">Este es un correo automático generado por InsurDesk.</p>
          </div>
        </div>`;

      try {
        const resendRes = await sendViaResend(recipientEmail, `${subjectPrefix}Resumen Mensual de Incentivos - ${cutoffLabel}`, htmlBody);

        if (!testEmail) {
          await sdk.asServiceRole.entities.EmailLog.create({
            recipient_email: agent.email,
            recipient_name: agent.name,
            email_type: 'otro',
            subject: `Resumen Mensual de Incentivos - ${cutoffLabel}`,
            body: htmlBody,
            status: 'enviado',
            related_entity_type: 'Incentive',
            related_entity_id: agent.id,
            sent_date: new Date().toISOString().split('T')[0]
          });
        }

        emailsSent++;
        results.push({ agent: agent.name, email: recipientEmail, status: 'sent', id: resendRes?.id });
      } catch (error) {
        results.push({ agent: agent.name, email: recipientEmail, status: 'error', error: error.message });
      }
      await new Promise(r => setTimeout(r, 200));
    }

    return Response.json({ success: true, message: 'Incentive follow-up sent', emailsSent, cutoff: cutoffLabel, testMode: !!testEmail, results });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});