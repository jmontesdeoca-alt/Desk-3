import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);

    const body = await req.json();

    const {
      notification_type,
      recipient_type,
      recipient_id,
      recipient_name,
      recipient_email,
      title,
      message,
      related_entity_type,
      related_entity_id,
      notification_date
    } = body;

    const required = {
      notification_type,
      recipient_type,
      recipient_email,
      title,
      message,
      notification_date
    };
    for (const [key, value] of Object.entries(required)) {
      if (value === undefined || value === null || value === '') {
        return Response.json({ success: false, error: `Falta el campo requerido: ${key}` }, { status: 400 });
      }
    }

    const notification = await sdk.asServiceRole.entities.Notification.create({
      notification_type,
      recipient_type,
      recipient_id,
      recipient_name,
      recipient_email,
      title,
      message,
      related_entity_type,
      related_entity_id,
      notification_date
    });

    return Response.json({ success: true, notification_id: notification.id });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});