import { createClientFromRequest } from '../../runtime/sdk.js';
import { getTRMBatch, convertToUSD } from '../../shared/currencyConversion.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Get user role info
    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const appRole = userRole?.app_role || 'admin';
    const agentId = userRole?.agent_id;
    const needsStructure = appRole === 'gerencial' && agentId;

    // Load all entities in parallel (service role bypasses RLS for speed)
    // Payments are loaded separately by getDashboardPaymentKPIs (two-phase loading)
    const [policies, claims, commissions, agents, clients, tasks] = await Promise.all([
      sdk.asServiceRole.entities.Policy.list(),
      sdk.asServiceRole.entities.Claim.list(),
      sdk.asServiceRole.entities.Commission.list(),
      sdk.asServiceRole.entities.Agent.list(),
      sdk.asServiceRole.entities.Client.list(),
      sdk.asServiceRole.entities.Task.list()
    ]);

    // Pre-cargar TRMs para todas las fechas de emisión de pólizas COP (batch)
    const copIssueDates = policies
      .filter(p => p.currency === 'COP' && p.issue_date)
      .map(p => p.issue_date);
    const trmMap = await getTRMBatch(sdk.asServiceRole, copIssueDates);

    // Compute agent structure if needed (gerencial with linked agent)
    let allowedAgentIds = [];
    if (needsStructure) {
      allowedAgentIds = [agentId];
      const findDownline = (id) => {
        agents.filter(a => a.upline_agent_id === id).forEach(a => {
          allowedAgentIds.push(a.id);
          findDownline(a.id);
        });
      };
      findDownline(agentId);
    }

    // Filter by agent structure
    const filteredPolicies = needsStructure
      ? policies.filter(p => allowedAgentIds.includes(p.agent_id))
      : policies;

    const policyIds = new Set(filteredPolicies.map(p => p.id));
    const filteredClaims = needsStructure ? claims.filter(c => policyIds.has(c.policy_id)) : claims;
    const filteredCommissions = needsStructure ? commissions.filter(c => allowedAgentIds.includes(c.agent_id)) : commissions;

    // Compute KPIs
    const currentYear = new Date().getFullYear();
    const today = new Date();
    const todayTime = today.getTime();
    const todayStr = today.toDateString();

    const portfolioPolicies = filteredPolicies.filter(p => p.status === 'activa' || p.status === 'en_riesgo');
    const activePolicies = portfolioPolicies.length;
    const expiredPolicies = filteredPolicies.filter(p => p.status === 'vencida').length;
    const atRiskPolicies = filteredPolicies.filter(p => p.status === 'en_riesgo').length;

    const newBusinessThisYear = portfolioPolicies.filter(p => {
      if (p.policy_type !== 'nuevo_negocio') return false;
      return new Date(p.start_date).getFullYear() === currentYear;
    });
    const newBusinessCount = newBusinessThisYear.length;
    const annualProduction = newBusinessThisYear.reduce((sum, p) =>
      sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0);

    const totalPremiums = portfolioPolicies
      .filter(p => new Date(p.start_date).getFullYear() === currentYear)
      .reduce((sum, p) => sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0);

    const pendingClaims = filteredClaims.filter(c => c.status === 'en_proceso').length;
    // Para siniestros: usar la moneda y fecha de emisión de la póliza asociada
    const policyMap = new Map(filteredPolicies.map(p => [p.id, p]));
    const paidClaimsAmount = filteredClaims.filter(c => c.status === 'pagado').reduce((sum, c) => {
      const policy = policyMap.get(c.policy_id);
      return sum + convertToUSD(c.paid_amount || 0, policy?.currency, policy?.issue_date, trmMap);
    }, 0);

    // Comisiones: usar la moneda de la comisión (heredada de la póliza) y fecha de emisión de la póliza
    const commissionPolicyMap = new Map();
    filteredCommissions.forEach(c => {
      if (!commissionPolicyMap.has(c.policy_id)) {
        const pol = policyMap.get(c.policy_id);
        if (pol) commissionPolicyMap.set(c.policy_id, pol);
      }
    });
    const calculatedCommissions = filteredCommissions.filter(c => c.status === 'calculada').reduce((sum, c) => {
      const policy = commissionPolicyMap.get(c.policy_id);
      return sum + convertToUSD(c.commission_amount || 0, c.currency || policy?.currency, policy?.issue_date, trmMap);
    }, 0);
    const paidCommissions = filteredCommissions.filter(c => c.status === 'pagada').reduce((sum, c) => {
      const policy = commissionPolicyMap.get(c.policy_id);
      return sum + convertToUSD(c.commission_amount || 0, c.currency || policy?.currency, policy?.issue_date, trmMap);
    }, 0);

    // Upcoming renewals (active policies ending within 60 days)
    const upcomingRenewals = filteredPolicies
      .filter(p => {
        if (p.status !== 'activa' || !p.end_date) return false;
        const days = Math.floor((new Date(p.end_date).getTime() - todayTime) / 86400000);
        return days > 0 && days <= 60;
      })
      .sort((a, b) => new Date(a.end_date) - new Date(b.end_date))
      .map(p => ({ id: p.id, policy_number: p.policy_number, client_name: p.client_name, end_date: p.end_date }));

    // Chart: pie data by insurance line
    const lineDataMap = portfolioPolicies.reduce((acc, p) => {
      const line = p.line_name || 'Sin Ramo';
      acc[line] = (acc[line] || 0) + 1;
      return acc;
    }, {});
    const pieData = Object.entries(lineDataMap).map(([name, value]) => ({ name, value }));

    // Chart: top 5 agents by production (en USD)
    const agentProduction = agents
      .map(agent => {
        const total = portfolioPolicies
          .filter(p => p.agent_id === agent.id)
          .reduce((sum, p) => sum + convertToUSD(p.annual_premium || 0, p.currency, p.issue_date, trmMap), 0);
        return { name: agent.name?.split(' ')[0] || agent.name || 'N/A', fullName: agent.name || 'N/A', produccion: Math.round(total) };
      })
      .filter(a => a.produccion > 0)
      .sort((a, b) => b.produccion - a.produccion)
      .slice(0, 5);

    // Tasks: only current user's pending
    const myTasks = tasks.filter(t => t.assigned_to_user_id === user.id && t.status === 'pendiente');
    const overdueTasks = myTasks.filter(t => t.due_date && new Date(t.due_date).getTime() < todayTime).length;
    const todayTasks = myTasks.filter(t => t.due_date && new Date(t.due_date).toDateString() === todayStr).length;

    // Recent policies (5 most recent)
    const recentPolicies = [...filteredPolicies]
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
      .slice(0, 5)
      .map(p => ({ id: p.id, policy_number: p.policy_number, client_name: p.client_name, status: p.status, currency: p.currency, annual_premium: p.annual_premium }));

    // Birthdays today
    const todayMonth = today.getMonth() + 1;
    const todayDay = today.getDate();
    const birthdays = [];

    agents.forEach(agent => {
      if (agent.birth_date) {
        const [year, month, day] = agent.birth_date.split('-').map(Number);
        if (month === todayMonth && day === todayDay) {
          birthdays.push({ name: agent.name, type: 'Agente', email: agent.email, age: today.getFullYear() - year });
        }
      }
    });

    clients.forEach(client => {
      if (client.birth_date) {
        const [year, month, day] = client.birth_date.split('-').map(Number);
        if (month === todayMonth && day === todayDay) {
          const name = client.client_type === 'persona'
            ? `${client.first_name || ''} ${client.last_name || ''}`.trim()
            : client.company_name;
          birthdays.push({ name, type: 'Cliente', email: client.email, age: today.getFullYear() - year });
        }
      }
    });

    return Response.json({
      kpis: {
        activePolicies, expiredPolicies, atRiskPolicies,
        newBusinessCount, annualProduction, totalPremiums,
        pendingClaims, paidClaimsAmount,
        calculatedCommissions, paidCommissions
      },
      taskStats: { overdueTasks, todayTasks },
      upcomingRenewals,
      pieData,
      agentProduction,
      tasks: myTasks,
      recentPolicies,
      hasPolicies: filteredPolicies.length > 0,
      birthdays
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}