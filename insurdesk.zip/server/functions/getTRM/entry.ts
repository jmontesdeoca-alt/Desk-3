import { createClientFromRequest } from '../../runtime/sdk.js';
import { getTRMForDate, getCurrentTRM, getTRMBatch } from '../../shared/currencyConversion.ts';

/**
 * Retorna la TRM (COP por 1 USD).
 * Modos:
 *   - Sin params: TRM actual (hoy)
 *   - { date: 'YYYY-MM-DD' }: TRM de una fecha específica
 *   - { dates: ['YYYY-MM-DD', ...] }: batch, retorna { rates: { 'YYYY-MM-DD': rate, ... } }
 */
export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));

    // Modo batch: array de fechas
    if (Array.isArray(body.dates)) {
      const trmMap = await getTRMBatch(sdk.asServiceRole, body.dates);
      const rates = {};
      for (const [date, rate] of trmMap.entries()) {
        rates[date] = rate;
      }
      return Response.json({ rates, currency: 'COP' });
    }

    // Modo individual: una fecha o hoy
    const date = body.date;
    let trm;
    if (date) {
      trm = await getTRMForDate(sdk.asServiceRole, date);
    } else {
      trm = await getCurrentTRM(sdk.asServiceRole);
    }

    return Response.json({
      date: trm.date,
      rate: trm.rate,
      source: trm.source,
      currency: 'COP'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}