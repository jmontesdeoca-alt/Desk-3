import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

const STATUS_LABEL = {
  en_proceso: 'En Proceso',
  aprobado: 'Aprobado',
  rechazado: 'Rechazado',
  pagado: 'Pagado',
  pagado_parcial: 'Pagado Parcial',
};

const STATUS_COLOR = {
  en_proceso: '#f59e0b',
  aprobado: '#10b981',
  rechazado: '#ef4444',
  pagado: '#3b82f6',
  pagado_parcial: '#f97316',
};

function fmt(n) {
  return (n ?? 0).toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function buildNotificationHTML(claim, agentName, eventType) {
  const currency = claim.currency || 'USD';
  const addendumsClaimed = (claim.addendums || []).reduce((s, a) => s + (a.additional_amount || 0), 0);
  const addendumsPaid    = (claim.addendums || []).reduce((s, a) => s + (a.paid_amount || 0), 0);
  const totalClaimed     = (claim.claimed_amount || 0) + addendumsClaimed;
  const totalPaid        = (claim.paid_amount || 0) + addendumsPaid;
  const difference       = totalClaimed - totalPaid;

  const statusColor = STATUS_COLOR[claim.status] || '#6b7280';
  const statusLabel = STATUS_LABEL[claim.status] || claim.status;

  const eventTitle = eventType === 'create'
    ? '🆕 Nuevo siniestro registrado'
    : claim.status === 'pagado'
      ? '✅ Siniestro marcado como Pagado'
      : '❌ Siniestro Rechazado';

  const affectedPerson = claim.affected_person === 'dependiente' && claim.dependent_name
    ? `Dependiente: ${claim.dependent_name}`
    : claim.corporate_member_name
      ? `Afiliado: ${claim.corporate_member_name}`
      : 'Titular';

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Notificación de Siniestro</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; color: #1e293b; }
    .wrapper { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
    .header { background: linear-gradient(135deg, #001E2E 0%, #004B6F 60%, #0A8FBE 100%); padding: 28px 32px; color: white; }
    .brand { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; margin-bottom: 16px; }
    .brand span { color: #76DDF9; }
    .event-title { font-size: 18px; font-weight: 700; margin-bottom: 4px; }
    .claim-number { font-size: 13px; color: rgba(255,255,255,0.7); }
    .status-pill { display: inline-block; background: ${statusColor}; color: white; border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; margin-top: 10px; text-transform: uppercase; }
    .content { padding: 28px 32px; }
    .greeting { font-size: 14px; color: #475569; margin-bottom: 20px; }
    .section { margin-bottom: 20px; }
    .section-title { font-size: 10px; font-weight: 700; color: #0A8FBE; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px; padding-bottom: 5px; border-bottom: 2px solid #e2e8f0; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .field-label { font-size: 10px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px; }
    .field-value { font-size: 13px; color: #1e293b; font-weight: 500; }
    .fin-row { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #f1f5f9; }
    .fin-row:last-child { border-bottom: none; }
    .fin-label { font-size: 12px; color: #64748b; }
    .fin-value { font-size: 14px; font-weight: 700; }
    .fin-value.claimed { color: #334155; }
    .fin-value.paid { color: #059669; }
    .fin-value.diff { color: ${difference > 0 ? '#b45309' : '#16a34a'}; }
    .diff-note { background: #fffbeb; border: 1px solid #fde68a; border-left: 4px solid #f59e0b; border-radius: 8px; padding: 12px 14px; margin-top: 16px; }
    .diff-note-title { font-size: 10px; font-weight: 700; color: #92400e; text-transform: uppercase; margin-bottom: 4px; }
    .diff-note-text { font-size: 12px; color: #78350f; line-height: 1.5; }
    .footer { background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 16px 32px; text-align: center; }
    .footer p { font-size: 11px; color: #94a3b8; }
  </style>
</head>
<body>
<div class="wrapper">
  <div class="header">
    <div class="brand">GA<span>Portal</span></div>
    <div class="event-title">${eventTitle}</div>
    <div class="claim-number">Siniestro N.° ${claim.claim_number || '—'}</div>
    <div class="status-pill">${statusLabel}</div>
  </div>

  <div class="content">
    <p class="greeting">Hola <strong>${agentName}</strong>, te informamos sobre el siguiente siniestro en tu cartera:</p>

    <div class="section">
      <div class="section-title">Información General</div>
      <div class="grid-2">
        <div>
          <div class="field-label">Póliza</div>
          <div class="field-value">${claim.policy_number || '—'}</div>
        </div>
        <div>
          <div class="field-label">Cliente / Asegurado</div>
          <div class="field-value">${claim.client_name || '—'}</div>
        </div>
        <div>
          <div class="field-label">Persona Afectada</div>
          <div class="field-value">${affectedPerson}</div>
        </div>
        <div>
          <div class="field-label">Tipo de Siniestro</div>
          <div class="field-value">${claim.claim_type || '—'}</div>
        </div>
        <div>
          <div class="field-label">Fecha del Evento</div>
          <div class="field-value">${claim.event_date || '—'}</div>
        </div>
        ${claim.payment_date ? `<div>
          <div class="field-label">Fecha de Pago</div>
          <div class="field-value">${claim.payment_date}</div>
        </div>` : ''}
      </div>
    </div>

    <div class="section">
      <div class="section-title">Resumen Financiero (${currency})</div>
      <div class="fin-row">
        <span class="fin-label">Monto Reclamado</span>
        <span class="fin-value claimed">${currency} ${fmt(totalClaimed)}</span>
      </div>
      <div class="fin-row">
        <span class="fin-label">Monto Pagado</span>
        <span class="fin-value paid">${currency} ${fmt(totalPaid)}</span>
      </div>
      ${difference > 0 ? `<div class="fin-row">
        <span class="fin-label">Diferencia</span>
        <span class="fin-value diff">${currency} ${fmt(difference)}</span>
      </div>` : ''}
    </div>

    ${claim.difference_note ? `
    <div class="diff-note">
      <div class="diff-note-title">⚠ Nota de diferencia</div>
      <div class="diff-note-text">${claim.difference_note}</div>
    </div>` : ''}

    ${claim.observations ? `
    <div class="section" style="margin-top:16px;">
      <div class="section-title">Observaciones</div>
      <p style="font-size:13px;color:#475569;line-height:1.6;">${claim.observations}</p>
    </div>` : ''}
  </div>

  <div class="footer">
    <p><strong>InsurDesk</strong> — Sistema de Gestión de Seguros</p>
    <p>Esta es una notificación automática. No responder a este correo.</p>
  </div>
</div>
</body>
</html>`;
}

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const payload = await req.json();

    const { event, data: claim, old_data } = payload;
    if (!claim) return Response.json({ skipped: true, reason: 'No claim data' });

    const eventType = event?.type; // 'create' or 'update'

    // Only notify on: create, or update where status changed to 'pagado' or 'rechazado'
    if (eventType === 'update') {
      const statusChanged = old_data?.status !== claim.status;
      const isRelevantStatus = claim.status === 'pagado' || claim.status === 'rechazado';
      if (!statusChanged || !isRelevantStatus) {
        return Response.json({ skipped: true, reason: 'Status not relevant or unchanged' });
      }
    }

    // Get policy to find agent
    const policies = await sdk.asServiceRole.entities.Policy.filter({ id: claim.policy_id });
    const policy = policies[0];
    if (!policy?.agent_id) return Response.json({ skipped: true, reason: 'No policy/agent found' });

    const agents = await sdk.asServiceRole.entities.Agent.filter({ id: policy.agent_id });
    const agent = agents[0];
    if (!agent?.email) return Response.json({ skipped: true, reason: 'Agent email not found' });

    // Find Nivel 2 upline
    let nivel2Agent = null;
    if (!agent.is_nivel_2) {
      let currentAgent = agent;
      while (currentAgent.upline_agent_id && !nivel2Agent) {
        const uplineAgents = await sdk.asServiceRole.entities.Agent.filter({ id: currentAgent.upline_agent_id });
        if (uplineAgents.length > 0) {
          currentAgent = uplineAgents[0];
          if (currentAgent.is_nivel_2) nivel2Agent = currentAgent;
        } else break;
      }
    }

    const statusLabel = STATUS_LABEL[claim.status] || claim.status;
    const subject = eventType === 'create'
      ? `Nuevo Siniestro Registrado N.° ${claim.claim_number} — ${claim.client_name}`
      : `Siniestro N.° ${claim.claim_number} — ${statusLabel} — ${claim.client_name}`;

    const html = buildNotificationHTML(claim, agent.name, eventType);
    const bcc = nivel2Agent?.email || undefined;
    const cc  = agent.operational_email || undefined;

    await sdk.asServiceRole.functions.invoke('sendEmail', {
      to: agent.email,
      ...(bcc && { bcc }),
      ...(cc && { cc }),
      subject,
      body: html,
      from_name: `${brand.name} Siniestros`,
    });

    console.log(`Notificación enviada a ${agent.email} | Siniestro: ${claim.claim_number} | Evento: ${eventType}`);
    return Response.json({ success: true, sent_to: agent.email, bcc: bcc || null });

  } catch (error) {
    console.error('notifyAgentClaimUpdate error:', error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});