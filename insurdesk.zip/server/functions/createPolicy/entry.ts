import { createClientFromRequest } from '../../runtime/sdk.js';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const policyData = body?.policyData;
    if (!policyData || typeof policyData !== 'object') {
      return Response.json({ error: 'policyData es requerido' }, { status: 400 });
    }

    const companyId = policyData.company_id;
    const policyNumber = String(policyData.policy_number || '').trim();

    // Validación centralizada de unicidad: compañía + número de póliza
    if (companyId && policyNumber) {
      const existing = await sdk.entities.Policy.filter({
        company_id: companyId,
        policy_number: policyNumber
      });
      if (existing.length > 0) {
        const ex = existing[0];
        return Response.json({
          success: false,
          duplicate: true,
          message: `Ya existe una póliza con el número "${policyNumber}" para la compañía "${ex.company_name || ''}".`,
          existing: {
            id: ex.id,
            policy_number: ex.policy_number,
            client_name: ex.client_name,
            contractor_name: ex.contractor_name,
            company_name: ex.company_name,
            status: ex.status,
            created_date: ex.created_date
          }
        });
      }
    }

    const created = await sdk.entities.Policy.create(policyData);
    return Response.json({ success: true, policy: created });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}