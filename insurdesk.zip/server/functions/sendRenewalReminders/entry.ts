import { createClientFromRequest } from '../../runtime/sdk.js';
import { parseLocalDate, todayInTimezone, differenceInDaysSafe } from '../../shared/dateUtils.ts';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    
    // Check if automatic emails are enabled
    const emailSettings = await sdk.asServiceRole.entities.AppSettings.filter({ 
      setting_key: 'automatic_emails_enabled' 
    });
    
    if (emailSettings.length > 0 && emailSettings[0].setting_value !== 'true') {
      return Response.json({ 
        success: true, 
        message: 'Automatic emails are disabled',
        sent: 0
      });
    }
    
    // Get all active policies
    const policies = await sdk.asServiceRole.entities.Policy.filter({ status: 'activa' });
    
    if (!policies || policies.length === 0) {
      return Response.json({ 
        success: true, 
        message: 'No active policies found',
        sent: 0
      });
    }
    
    const today = parseLocalDate(todayInTimezone('UTC'));
    let emailsSent = 0;
    const results = [];
    
    for (const policy of policies) {
      if (!policy.end_date) continue;
      
      const endDate = parseLocalDate(policy.end_date);
      if (!endDate) continue;
      
      const daysUntilEnd = differenceInDaysSafe(policy.end_date, todayInTimezone('UTC'));
      
      // Send reminders at 60 and 30 days before expiration
      if (daysUntilEnd === 60 || daysUntilEnd === 30) {
        // Get agent info
        const agents = await sdk.asServiceRole.entities.Agent.filter({ id: policy.agent_id });
        const agent = agents[0];
        
        if (!agent || !agent.email) {
          results.push({ 
            policy: policy.policy_number, 
            status: 'skipped', 
            reason: 'Agent email not found' 
          });
          continue;
        }
        
        // Find Nivel 2 agent in upline structure
        let nivel2Agent = null;
        let currentAgent = agent;
        
        // If the agent itself is Nivel 2, don't search upline
        if (agent.is_nivel_2) {
          nivel2Agent = null; // Will send only once to the agent
        } else {
          // Search upline for Nivel 2 agent
          while (currentAgent.upline_agent_id && !nivel2Agent) {
            const uplineAgents = await sdk.asServiceRole.entities.Agent.filter({ id: currentAgent.upline_agent_id });
            if (uplineAgents.length > 0) {
              currentAgent = uplineAgents[0];
              if (currentAgent.is_nivel_2) {
                nivel2Agent = currentAgent;
              }
            } else {
              break;
            }
          }
        }
        
        try {
          // Prepare BCC recipients: Nivel 2 + correo operativo del agente receptor (si existe)
          const bccRecipients = [];
          if (nivel2Agent && nivel2Agent.email) {
            bccRecipients.push(nivel2Agent.email);
          }
          // CC: correo operativo del agente (va como parámetro cc separado)
          
          // Send email using sendEmail function with RENEWAL_REMINDER type
          await sdk.asServiceRole.functions.invoke('sendEmail', {
            to: agent.email,
            bcc: bccRecipients.length > 0 ? bccRecipients.join(',') : undefined,
            cc: agent.operational_email || undefined,
            type: 'RENEWAL_REMINDER',
            data: {
              agente: agent.name,
              poliza: policy.policy_number,
              cliente: policy.client_name,
              compania: policy.company_name,
              producto: policy.product_name,
              moneda: policy.currency,
              monto: policy.annual_premium || 0,
              fecha_inicio: policy.start_date,
              fecha_fin: policy.end_date,
              dias: daysUntilEnd
            }
          });
          
          // Log envío exitoso al agente
           await sdk.asServiceRole.entities.EmailLog.create({
             recipient_email: agent.email,
             recipient_name: agent.name,
             email_type: 'renovacion_recordatorio',
             subject: `Renovación de Póliza ${policy.policy_number} - Vence en ${daysUntilEnd} días`,
             body: `Recordatorio de renovación para ${policy.client_name}`,
             status: 'enviado',
             related_entity_type: 'Policy',
             related_entity_id: policy.id,
             related_entity_reference: policy.policy_number,
             sent_date: new Date().toISOString().split('T')[0]
           });
          
          emailsSent++;
          
          // Log envío al nivel 2 si existe
          if (nivel2Agent && nivel2Agent.email) {
            await sdk.asServiceRole.entities.EmailLog.create({
              recipient_email: nivel2Agent.email,
              recipient_name: nivel2Agent.name,
              email_type: 'renovacion_recordatorio',
              subject: `Renovación de Póliza ${policy.policy_number} - Vence en ${daysUntilEnd} días`,
              body: `Recordatorio de renovación para ${policy.client_name}`,
              status: 'enviado',
              related_entity_type: 'Policy',
              related_entity_id: policy.id,
              related_entity_reference: policy.policy_number,
              sent_date: new Date().toISOString().split('T')[0]
            });
            
            emailsSent++;
          }
          
          results.push({ 
            policy: policy.policy_number, 
            agent: agent.name,
            nivel2: nivel2Agent?.name || 'N/A',
            daysUntilEnd,
            status: 'sent' 
          });
        } catch (error) {
          // Log de error
           await sdk.asServiceRole.entities.EmailLog.create({
             recipient_email: agent.email,
             recipient_name: agent.name,
             email_type: 'renovacion_recordatorio',
             subject: `Renovación de Póliza ${policy.policy_number} - Vence en ${daysUntilEnd} días`,
             body: '<div style="padding: 20px; color: #666;"><p>Error al procesar el correo</p></div>',
             status: 'error',
             error_message: error.message,
             related_entity_type: 'Policy',
             related_entity_id: policy.id,
             related_entity_reference: policy.policy_number,
             sent_date: new Date().toISOString().split('T')[0]
           });
          
          results.push({ 
            policy: policy.policy_number, 
            status: 'error', 
            error: error.message 
          });
        }
      }
    }
    
    return Response.json({ 
      success: true, 
      message: `Renewal reminders processed`,
      emailsSent,
      results 
    });
    
  } catch (error) {
    return Response.json({ 
      success: false, 
      error: error.message 
    }, { status: 500 });
  }
});