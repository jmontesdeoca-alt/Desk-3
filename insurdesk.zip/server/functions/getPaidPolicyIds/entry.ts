import { createClientFromRequest } from '../../runtime/sdk.js';
import { loadAll } from '../../shared/loadAll.js';

/**
 * Returns the set of policy_ids that have at least one payment with status 'pagado'.
 * Lightweight alternative to loading all payments — only returns policy ID strings.
 * Used by the Reports page for isPolicyPaid() checks.
 */
export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Only load paid payments (fraction of total), extract unique policy_ids
    const paidPayments = await loadAll(sdk.asServiceRole.entities.Payment, 'due_date', { status: 'pagado' });
    const paidPolicyIds = [...new Set(paidPayments.map(p => p.policy_id).filter(Boolean))];

    return Response.json({ paidPolicyIds });
  } catch (error) {
    console.error('Error in getPaidPolicyIds:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}