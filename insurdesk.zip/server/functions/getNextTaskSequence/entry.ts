import { createClientFromRequest } from '../../runtime/sdk.js';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const svc = sdk.asServiceRole;
    const existing = await svc.entities.AppSettings.filter({ setting_key: 'task_sequence_counter' });
    let next;
    if (existing && existing.length > 0) {
      const rec = existing[0];
      next = (parseInt(rec.setting_value, 10) || 0) + 1;
      await svc.entities.AppSettings.update(rec.id, { setting_value: String(next) });
    } else {
      next = 1;
      await svc.entities.AppSettings.create({
        setting_key: 'task_sequence_counter',
        setting_value: '1',
        setting_type: 'number',
        description: 'Contador de secuencial de tareas'
      });
    }
    return Response.json({ sequence: next });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}