import { createClientFromRequest } from '../../runtime/sdk.js';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    // Obtener todas las pólizas (service role para bypass de RLS — función admin-only)
    const allPolicies = await sdk.asServiceRole.entities.Policy.list(undefined, 10000);

    // Agrupar por company_id + '|' + policy_number (normalizado)
    const groups = {};
    for (const p of allPolicies) {
      const number = String(p.policy_number || '').trim();
      if (!number) continue;
      const key = `${p.company_id || ''}|${number}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(p);
    }

    // Recolectar solo los IDs de pólizas que están en grupos duplicados
    const duplicateGroups = [];
    const duplicatePolicyIds = new Set();
    for (const copies of Object.values(groups)) {
      if (copies.length > 1) {
        copies.forEach(c => duplicatePolicyIds.add(c.id));
        duplicateGroups.push({
          company_id: copies[0].company_id,
          company_name: copies[0].company_name,
          policy_number: copies[0].policy_number,
          copies: copies.map(c => ({
            id: c.id,
            policy_number: c.policy_number,
            client_name: c.client_name,
            contractor_name: c.contractor_name,
            agent_name: c.agent_name,
            company_name: c.company_name,
            status: c.status,
            created_date: c.created_date,
          })),
        });
      }
    }

    if (duplicateGroups.length === 0) {
      return Response.json({ success: true, groups: [] });
    }

    // Cargar los 4 tipos de registros vinculados UNA sola vez cada uno y contar por policy_id
    const [payments, commissions, claims, endorsements] = await Promise.all([
      sdk.asServiceRole.entities.Payment.list(undefined, 10000),
      sdk.asServiceRole.entities.Commission.list(undefined, 10000),
      sdk.asServiceRole.entities.Claim.list(undefined, 10000),
      sdk.asServiceRole.entities.Endorsement.list(undefined, 10000),
    ]);

    const countByPolicy = (records) => {
      const map = {};
      for (const r of records) {
        const pid = r.policy_id;
        if (pid && duplicatePolicyIds.has(pid)) {
          map[pid] = (map[pid] || 0) + 1;
        }
      }
      return map;
    };

    const payMap = countByPolicy(payments);
    const comMap = countByPolicy(commissions);
    const claMap = countByPolicy(claims);
    const endMap = countByPolicy(endorsements);

    // Adjuntar los conteos a cada copia
    for (const g of duplicateGroups) {
      for (const c of g.copies) {
        c.counts = {
          payments: payMap[c.id] || 0,
          commissions: comMap[c.id] || 0,
          claims: claMap[c.id] || 0,
          endorsements: endMap[c.id] || 0,
        };
      }
      // Ordenar por fecha de creación ascendente (la más antigua primero)
      g.copies.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    }

    return Response.json({ success: true, groups: duplicateGroups });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}