// Estado de la importación inicial. Mientras está abierta se admite enlazar por nombre (y luego reparar con repairRelations).
// Al cerrarla, todo vínculo clave exige su id. Solo administradores.
import { createClientFromRequest } from '../../runtime/sdk.js';
import { repairRelations, isInitialImportClosed, setInitialImportClosed } from '../../src/relations.js';

export default (async (req) => {
  const sdk = createClientFromRequest(req);
  const user = await sdk.auth.me().catch(() => null);
  if (!user || (user.role !== 'admin' && user.app_role !== 'admin')) return Response.json({ error: 'Solo un administrador' }, { status: 403 });
  const { action = 'status', force = false } = await req.json().catch(() => ({}));
  if (action === 'status') return Response.json({ closed: isInitialImportClosed() });
  if (action === 'reopen') { setInitialImportClosed(false, user.email); return Response.json({ closed: false }); }
  if (action === 'close') {
    const report = repairRelations({ dryRun: true });
    const pending = report.codes_asignados + report.vinculados_por_nombre + report.nombres_actualizados + report.listas_normalizadas + report.huerfanos.length + report.sin_coincidencia.length + report.ambiguos.length;
    if (pending && !force) return Response.json({ error: 'Aún hay relaciones por reparar. Corre "Reparar relaciones" y revisa lo que no coincide antes de cerrar.', report }, { status: 409 });
    setInitialImportClosed(true, user.email);
    return Response.json({ closed: true });
  }
  return Response.json({ error: 'Acción no válida' }, { status: 400 });
});
