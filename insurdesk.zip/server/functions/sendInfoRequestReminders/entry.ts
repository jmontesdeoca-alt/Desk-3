import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

// Called weekly by automation — no user auth needed, uses service role
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);

    // Get all pending (unfulfilled) info requests
    const allRequests = await sdk.asServiceRole.entities.AdditionalInfoRequest.list('-created_date', 500);
    const pending = allRequests.filter(r => !r.is_fulfilled);

    if (pending.length === 0) {
      return Response.json({ success: true, message: 'No hay solicitudes pendientes', sent: 0 });
    }

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) return Response.json({ error: 'RESEND_API_KEY not configured' }, { status: 500 });

    let sent = 0;

    for (const request of pending) {
      const subject = `RECORDATORIO: Información pendiente - Siniestro ${request.claim_number}`;

      const htmlBody = `
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"/><style>
body { font-family: Arial, sans-serif; color: #1e293b; background: #f8fafc; margin: 0; padding: 0; }
.wrapper { max-width: 600px; margin: 0 auto; background: #fff; }
.header { background: linear-gradient(135deg, #001E2E 0%, #7c3aed 100%); padding: 28px 32px; color: white; }
.brand { font-size: 22px; font-weight: 800; } .brand span { color: #c4b5fd; }
.content { padding: 28px 32px; }
.reminder-box { background: #fef3c7; border: 1px solid #f59e0b; border-left: 4px solid #d97706; border-radius: 8px; padding: 16px; margin: 16px 0; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 16px 0; }
.info-item label { font-size: 11px; color: #64748b; text-transform: uppercase; font-weight: 600; }
.info-item p { font-size: 14px; color: #1e293b; margin: 2px 0 0; font-weight: 500; }
.desc-box { background: #f1f5f9; border-radius: 8px; padding: 14px; font-size: 14px; color: #334155; line-height: 1.6; margin: 16px 0; }
.footer { background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 16px 32px; text-align: center; font-size: 11px; color: #94a3b8; }
</style></head>
<body>
<div class="wrapper">
  <div class="header">
    <div class="brand">GA<span>Portal</span></div>
    <p style="margin:8px 0 0;font-size:13px;color:rgba(255,255,255,0.8)">Recordatorio Semanal — Información Pendiente</p>
  </div>
  <div class="content">
    <p>Estimado/a <strong>${request.client_name || 'Cliente'}</strong>,</p>
    
    <div class="reminder-box">
      <strong>🔔 Recordatorio Semanal</strong><br/>
      Aún tenemos pendiente la información adicional que fue solicitada para su siniestro. Por favor, proporcione la documentación a la brevedad para continuar con el trámite.
    </div>

    <div class="info-grid">
      <div class="info-item">
        <label>N° Siniestro</label>
        <p>${request.claim_number}</p>
      </div>
      <div class="info-item">
        <label>N° Póliza</label>
        <p>${request.policy_number || '—'}</p>
      </div>
      <div class="info-item">
        <label>Fecha de solicitud</label>
        <p>${request.request_date}</p>
      </div>
      ${request.due_date ? `<div class="info-item">
        <label>Fecha límite</label>
        <p style="color:#dc2626;font-weight:700">${request.due_date}</p>
      </div>` : ''}
    </div>

    <p style="font-size:13px;font-weight:600;color:#475569;margin:16px 0 6px">Información solicitada:</p>
    <div class="desc-box">${request.description}</div>

    <p style="margin-top:20px;line-height:1.6;font-size:13px;color:#475569">
      Por favor comuníquese con su agente <strong>${request.agent_name || ''}</strong> para coordinar la entrega de los documentos.
    </p>
  </div>
  <div class="footer">
    <p><strong>InsurDesk</strong> — Sistema de Gestión de Seguros</p>
    <p>Este recordatorio se enviará semanalmente hasta que la información sea marcada como recibida.</p>
  </div>
</div>
</body></html>`;

      // Send to client
      if (request.client_email) {
        const res = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            from: brand.from('Recordatorio'),
            to: [request.client_email],
            cc: request.agent_email && request.agent_email !== request.client_email ? [request.agent_email] : undefined,
            subject,
            html: htmlBody
          })
        });
        if (res.ok) sent++;
      }

      // CC agent separately if no client email
      if (request.agent_email && request.agent_email !== request.client_email && !request.client_email) {
        const res = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            from: brand.from('Recordatorio'),
            to: [request.agent_email],
            subject: `[Copia] ${subject}`,
            html: htmlBody
          })
        });
        if (!res.ok) console.error('Error sending to agent:', await res.text());
      }

      await new Promise(r => setTimeout(r, 200));
    }

    return Response.json({ success: true, sent, total_pending: pending.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});