import { createClientFromRequest } from '../../runtime/sdk.js';
import { loadAll } from '../../shared/loadAll.js';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const svc = sdk.asServiceRole;
    // Load all tasks sorted ascending by created_date
    const allTasks = await loadAll(svc.entities.Task, 'created_date');

    let maxSeq = 0;
    allTasks.forEach(t => { if (t.task_sequence && t.task_sequence > maxSeq) maxSeq = t.task_sequence; });

    let nextSeq = maxSeq;
    let assigned = 0;
    for (const t of allTasks) {
      if (!t.task_sequence) {
        nextSeq++;
        await svc.entities.Task.update(t.id, { task_sequence: nextSeq });
        assigned++;
      }
    }

    // Ensure the counter reflects the highest sequence used
    const finalValue = nextSeq;
    const counterRecs = await svc.entities.AppSettings.filter({ setting_key: 'task_sequence_counter' });
    if (counterRecs && counterRecs.length > 0) {
      await svc.entities.AppSettings.update(counterRecs[0].id, { setting_value: String(finalValue) });
    } else {
      await svc.entities.AppSettings.create({
        setting_key: 'task_sequence_counter',
        setting_value: String(finalValue),
        setting_type: 'number',
        description: 'Contador de secuencial de tareas'
      });
    }

    return Response.json({
      success: true,
      totalTasks: allTasks.length,
      assigned,
      nextSequence: finalValue
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}