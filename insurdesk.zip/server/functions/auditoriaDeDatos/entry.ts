import { createClientFromRequest } from '../../runtime/sdk.js';

const normalize = (str) => (str ?? '').toString().toUpperCase().replace(/[.,;:!?'"`()]/g, ' ').replace(/\s+/g, ' ').trim();
const normalizeNumber = (str) => (str ?? '').toString().toUpperCase().trim().replace(/\s+/g, '');
const removeAccents = (str) => (str ?? '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
// Compara nombres como conjuntos de palabras (ignora orden y acentos)
const normalizeNameForCompare = (str) => removeAccents(normalize(str)).split(' ').filter(Boolean).sort().join(' ');
// Invierte orden: apellidos-primero <-> nombres-primero (mitad-mitad)
const reverseNameOrder = (str) => {
  const words = (str ?? '').toString().trim().split(/\s+/).filter(Boolean);
  if (words.length <= 1) return (str ?? '').toString().trim();
  const mid = Math.floor(words.length / 2);
  return [...words.slice(mid), ...words.slice(0, mid)].join(' ');
};
const BATCH_SIZE = 100;

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Verificar permisos
    let userRole = null;
    try {
      const roleResp = await sdk.functions.invoke('getUserRoleInfo', {});
      userRole = roleResp?.data || roleResp;
    } catch {}
    const appRole = userRole?.app_role;
    const isAdmin = user?.role === 'admin' || appRole === 'admin' || appRole === 'jefatura' || appRole === 'gerencial';
    if (!isAdmin) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json();
    const { policies } = body;
    if (!Array.isArray(policies) || policies.length === 0) {
      return Response.json({ error: 'policies (array de datos mapeados) es requerido' }, { status: 400 });
    }

    const rows = policies;

    // Detectar qué columnas están presentes en los datos mapeados
    const hasPrima = rows.some(r => r.prima !== undefined && r.prima !== null && r.prima !== '');
    const hasAgente = rows.some(r => r.agente !== undefined && r.agente !== null && r.agente !== '');
    const hasCompania = rows.some(r => r.compania !== undefined && r.compania !== null && r.compania !== '');
    let extractionWarning = null;
    if (!hasPrima && !hasAgente) {
      extractionWarning = 'El archivo no incluye prima ni agente. Análisis limitado a número de póliza y titular.';
    } else if (!hasPrima) {
      extractionWarning = 'El archivo no incluye prima.';
    } else if (!hasAgente) {
      extractionWarning = 'El archivo no incluye agente.';
    }

    // 1. Recopilar números de póliza y titulares únicos del Excel
    const excelNumbers = new Set();
    const excelClients = new Set();
    for (const row of rows) {
      const num = normalizeNumber(row.numero_poliza);
      if (num) excelNumbers.add(num);
      const client = normalize(row.titular);
      if (client) excelClients.add(client);
    }

    // 2. Consultar pólizas por número en bloques (evita cargar toda la BD)
    const policyByNumber = new Map();
    const policiesByClientName = new Map();
    const policiesByClientNameSorted = new Map();
    const allFoundPolicies = [];
    const seenIds = new Set();

    const addPolicy = (p) => {
      if (seenIds.has(p.id)) return;
      seenIds.add(p.id);
      allFoundPolicies.push(p);
      const num = normalizeNumber(p.policy_number);
      if (num) {
        if (!policyByNumber.has(num)) policyByNumber.set(num, []);
        policyByNumber.get(num).push(p);
      }
      const client = normalize(p.client_name);
      if (client) {
        if (!policiesByClientName.has(client)) policiesByClientName.set(client, []);
        policiesByClientName.get(client).push(p);
      }
      const clientSorted = normalizeNameForCompare(p.client_name);
      if (clientSorted) {
        if (!policiesByClientNameSorted.has(clientSorted)) policiesByClientNameSorted.set(clientSorted, []);
        policiesByClientNameSorted.get(clientSorted).push(p);
      }
    };

    const numArray = [...excelNumbers];
    for (let i = 0; i < numArray.length; i += BATCH_SIZE) {
      const batch = numArray.slice(i, i + BATCH_SIZE);
      const found = await sdk.asServiceRole.entities.Policy.filter({
        policy_number: { $in: batch }
      });
      for (const p of found) addPolicy(p);
    }

    // 3. Para filas no encontradas por número, buscar por titular en bloques
    // También buscar con el orden invertido (apellidos-primero <-> nombres-primero)
    const notFoundClients = new Set();
    for (const row of rows) {
      const num = normalizeNumber(row.numero_poliza);
      if (!policyByNumber.has(num)) {
        const client = normalize(row.titular);
        if (client) {
          notFoundClients.add(client);
          const reversed = normalize(reverseNameOrder(row.titular));
          if (reversed && reversed !== client) notFoundClients.add(reversed);
        }
      }
    }

    const clientArray = [...notFoundClients];
    for (let i = 0; i < clientArray.length; i += BATCH_SIZE) {
      const batch = clientArray.slice(i, i + BATCH_SIZE);
      const found = await sdk.asServiceRole.entities.Policy.filter({
        client_name: { $in: batch }
      });
      for (const p of found) addPolicy(p);
    }

    // 4. Buscar versiones renovadas para pólizas marcadas como "renovada"
    const renewedFromIds = [];
    for (const p of allFoundPolicies) {
      if (p.status === 'renovada') renewedFromIds.push(p.id);
    }

    const renewedMap = new Map(); // baseId -> renewed policy
    for (let i = 0; i < renewedFromIds.length; i += BATCH_SIZE) {
      const batch = renewedFromIds.slice(i, i + BATCH_SIZE);
      const found = await sdk.asServiceRole.entities.Policy.filter({
        renewed_from_policy_id: { $in: batch }
      });
      for (const p of found) {
        if (p.renewed_from_policy_id) renewedMap.set(p.renewed_from_policy_id, p);
      }
    }

    // También buscar por sufijo -R entre las pólizas ya encontradas
    const renewedByBaseNumber = new Map();
    for (const p of allFoundPolicies) {
      const num = normalizeNumber(p.policy_number);
      const match = num.match(/^(.+)-R\d+$/);
      if (match) renewedByBaseNumber.set(match[1], p);
    }

    const findRenewedVersion = (basePolicy) => {
      if (renewedMap.has(basePolicy.id)) return renewedMap.get(basePolicy.id);
      const baseNum = normalizeNumber(basePolicy.policy_number);
      if (renewedByBaseNumber.has(baseNum)) return renewedByBaseNumber.get(baseNum);
      return null;
    };

    // 5. Comparar cada fila del Excel contra la BD
    const results = [];
    let correctCount = 0, errorCount = 0, warningCount = 0;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 2;
      const excelNum = normalizeNumber(row.numero_poliza);
      const excelTitular = normalize(row.titular);
      const excelPrima = Number(row.prima) || 0;
      const excelAgente = normalize(row.agente);
      const excelCompania = normalize(row.compania);

      const findings = [];
      let status = 'correct';
      let dbPolicyId = null;
      let dbPolicyNumber = null;
      let dbStatus = null;
      let dbTitular = null;
      let dbPrima = null;
      let dbAgente = null;

      const exactMatches = policyByNumber.get(excelNum) || [];

      if (exactMatches.length > 0) {
        let policy = exactMatches[0];
        dbPolicyId = policy.id;
        dbPolicyNumber = policy.policy_number;
        dbStatus = policy.status;
        dbTitular = policy.client_name;
        dbPrima = Number(policy.annual_premium) || 0;
        dbAgente = policy.agent_name;

        // Si está renovada, validar contra la versión renovada
        if (policy.status === 'renovada') {
          const renewed = findRenewedVersion(policy);
          if (renewed) {
            findings.push(`Póliza renovada en BD (versión ${renewed.policy_number}). Validación contra renovación.`);
            dbPolicyNumber = renewed.policy_number;
            dbStatus = renewed.status;
            policy = renewed;
          } else {
            findings.push(`Póliza marcada como renovada pero no se encontró versión renovada en BD.`);
          }
        }

        // Comparar titular (comparación inteligente: ignora orden de palabras y acentos)
        const dbTitularSorted = normalizeNameForCompare(policy.client_name);
        const excelTitularSorted = normalizeNameForCompare(row.titular);
        if (excelTitularSorted && dbTitularSorted && excelTitularSorted !== dbTitularSorted) {
          findings.push(`Titular no coincide: Excel="${row.titular}" vs BD="${policy.client_name}"`);
          status = 'error';
        }

        // Validar estado de la póliza en BD
        if (policy.status && policy.status !== 'activa' && policy.status !== 'renovada') {
          const estadoLabels = { 'cancelada': 'CANCELADA', 'vencida': 'VENCIDA', 'en_riesgo': 'EN RIESGO' };
          const label = estadoLabels[policy.status] || policy.status.toUpperCase();
          findings.push(`Póliza ${label} en BD`);
          if (status === 'correct') status = 'warning';
        }

        // Comparar prima (tolerancia 0.01) - solo si el Excel incluye prima
        if (hasPrima) {
          const dbPrima = Number(policy.annual_premium) || 0;
          if (excelPrima > 0 && dbPrima > 0 && Math.abs(excelPrima - dbPrima) > 0.01) {
            findings.push(`Prima no coincide: Excel=${excelPrima} vs BD=${dbPrima}`);
            status = 'error';
          }
        }

        // Comparar agente - coincidencia inteligente (subset de palabras)
        if (hasAgente) {
          const dbAgenteSorted = normalizeNameForCompare(policy.agent_name);
          const excelAgenteSorted = normalizeNameForCompare(row.agente);
          if (excelAgenteSorted && dbAgenteSorted && excelAgenteSorted !== dbAgenteSorted) {
            const excelWords = new Set(excelAgenteSorted.split(' '));
            const dbWords = new Set(dbAgenteSorted.split(' '));
            const isSubset = [...excelWords].every(w => dbWords.has(w)) || [...dbWords].every(w => excelWords.has(w));
            if (isSubset) {
              findings.push(`Agente coincide parcialmente: Excel="${row.agente}" vs BD="${policy.agent_name}"`);
              if (status === 'correct') status = 'warning';
            } else {
              findings.push(`Agente no coincide: Excel="${row.agente}" vs BD="${policy.agent_name}"`);
              status = 'error';
            }
          }
        }

        // Novedades por columnas faltantes en el archivo
        if (!hasPrima && !hasAgente) {
          findings.push('Archivo no incluye prima ni agente - validación limitada a número y titular');
        } else if (!hasPrima) {
          findings.push('Archivo no incluye prima');
        } else if (!hasAgente) {
          findings.push('Archivo no incluye agente');
        }

        if (status === 'correct') findings.push('Todos los datos coinciden');
      } else {
        // No encontrada por número - buscar por titular (exacto o por palabras ordenadas)
        const clientPolicies = policiesByClientName.get(excelTitular) || policiesByClientNameSorted.get(normalizeNameForCompare(row.titular)) || [];

        if (clientPolicies.length > 0) {
          const companiesInBD = new Set(clientPolicies.map(p => normalize(p.company_name)).filter(Boolean));

          if (excelCompania && companiesInBD.has(excelCompania)) {
            const sameCompanyPolicies = clientPolicies.filter(p => normalize(p.company_name) === excelCompania);
            findings.push(`Cliente existe pero número de póliza no coincide con ${sameCompanyPolicies.length} póliza(s) de la misma compañía. Números en BD: ${sameCompanyPolicies.map(p => p.policy_number).join(', ')}`);
            status = 'error';
          } else {
            findings.push(`Cliente existe en BD con ${clientPolicies.length} póliza(s) pero ninguna pertenece a la compañía "${row.compania || 'no especificada'}". Pólizas: ${clientPolicies.map(p => p.policy_number + ' (' + (p.company_name || 'N/A') + ')').join(', ')}`);
            status = 'warning';
          }
        } else {
          findings.push('Póliza no encontrada y cliente no existe en BD');
          status = 'error';
        }
      }

      if (status === 'correct') correctCount++;
      else if (status === 'warning') warningCount++;
      else errorCount++;

      results.push({
        fila: rowNum,
        numero_poliza: row.numero_poliza,
        titular: row.titular,
        prima: row.prima,
        agente: row.agente,
        compania: row.compania,
        poliza_bd: dbPolicyNumber,
        policy_id: dbPolicyId,
        estado_bd: dbStatus,
        titular_bd: dbTitular,
        prima_bd: dbPrima,
        agente_bd: dbAgente,
        status,
        findings: findings.join(' | ')
      });
    }

    return Response.json({
      total: rows.length,
      correct: correctCount,
      warnings: warningCount,
      errors: errorCount,
      extraction_warning: extractionWarning,
      has_prima: hasPrima,
      has_agente: hasAgente,
      results
    });
  } catch (error) {
    console.error('Error en auditoriaDeDatos:', error);
    return Response.json({ error: error.message || 'Error interno' }, { status: 500 });
  }
}