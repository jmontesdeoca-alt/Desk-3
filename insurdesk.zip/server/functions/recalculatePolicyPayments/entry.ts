import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      policyId,
      paymentFrequency,
      annualPremium,
      installmentMonths,
      installmentAmount,
      startDate,
      currency,
      clientName,
      policyNumber,
      policyCategory,
      contractorName
    } = body;

    if (!policyId || !paymentFrequency || !startDate || !currency) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Check for existing PAID base payments
    const existingPayments = await sdk.asServiceRole.entities.Payment.filter({
      policy_id: policyId,
      status: 'pagado'
    });

    const hasPaidBasePayments = existingPayments.some(p => !p.payment_group || p.payment_group === 'base');
    
    if (hasPaidBasePayments) {
      return Response.json({
        success: false,
        error: 'No se puede modificar la frecuencia de pago o el valor de la prima porque la póliza ya tiene pagos registrados.',
        blocked: true
      }, { status: 200 });
    }

    // Delete existing base payments (non-paid)
    const allBasePayments = await sdk.asServiceRole.entities.Payment.filter({
      policy_id: policyId
    });

    for (const p of allBasePayments) {
      if (!p.payment_group || p.payment_group === 'base') {
        await sdk.asServiceRole.entities.Payment.delete(p.id);
      }
    }

    // Generate new payments
    const displayName = policyCategory === 'CORPORATIVA' ? contractorName : clientName;
    const payments = [];

    if (policyCategory === 'CORPORATIVA') {
      const start = new Date(startDate + 'T00:00:00');
      for (let i = 0; i < 12; i++) {
        const dueDate = new Date(start.getFullYear(), start.getMonth() + i, start.getDate());
        payments.push({
          policy_id: policyId,
          policy_number: policyNumber,
          client_name: displayName,
          due_date: dueDate.toISOString().split('T')[0],
          period: new Intl.DateTimeFormat('es').format(dueDate),
          amount: 0,
          currency,
          status: 'pendiente',
          installment_number: i + 1
        });
      }
    } else {
      const frequencies = {
        mensual: parseInt(installmentMonths) || 12,
        trimestral: 4,
        semestral: 2,
        anual: 1,
        unico: 1
      };
      const numPayments = frequencies[paymentFrequency] || 12;
      const start = new Date(startDate + 'T00:00:00');
      const originalDay = start.getDate();

      for (let i = 0; i < numPayments; i++) {
        let targetMonth, targetYear;
        if (paymentFrequency === 'mensual') {
          targetMonth = start.getMonth() + i;
        } else if (paymentFrequency === 'trimestral') {
          targetMonth = start.getMonth() + (i * 3);
        } else if (paymentFrequency === 'semestral') {
          targetMonth = start.getMonth() + (i * 6);
        } else {
          targetMonth = start.getMonth();
        }
        targetYear = start.getFullYear() + Math.floor(targetMonth / 12);
        targetMonth = targetMonth % 12;

        const lastDayOfTargetMonth = new Date(targetYear, targetMonth + 1, 0).getDate();
        const targetDay = Math.min(originalDay, lastDayOfTargetMonth);
        const dueDate = new Date(targetYear, targetMonth, targetDay);

        payments.push({
          policy_id: policyId,
          policy_number: policyNumber,
          client_name: displayName,
          due_date: dueDate.toISOString().split('T')[0],
          period: new Intl.DateTimeFormat('es', { month: 'long', year: 'numeric' }).format(dueDate),
          amount: parseFloat(installmentAmount || 0),
          currency,
          status: 'pendiente',
          installment_number: i + 1
        });
      }
    }

    if (payments.length > 0) {
      await sdk.asServiceRole.entities.Payment.bulkCreate(payments);
    }

    return Response.json({
      success: true,
      message: `Se generaron ${payments.length} nuevas cuotas.`,
      count: payments.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});