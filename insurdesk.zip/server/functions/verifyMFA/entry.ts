import { createClientFromRequest } from '../../runtime/sdk.js';
import { validateTOTPCode, findUserRoleByEmail, extractRoleData } from '../../shared/mfa-utils.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const code = body?.code;
    const isSetup = body?.setup === true;

    if (!code) {
      return Response.json({ error: 'Código requerido' }, { status: 400 });
    }

    const userRole = await findUserRoleByEmail(sdk, user.email);
    if (!userRole) {
      return Response.json({ error: 'No se encontró el registro de usuario' }, { status: 404 });
    }

    const roleData = extractRoleData(userRole);
    const roleId = userRole.id;
    const method = roleData.mfa_method;

    if (!method) {
      return Response.json({ error: 'MFA no configurado' }, { status: 400 });
    }

    let isValid = false;

    if (method === 'totp') {
      const secret = roleData.mfa_secret;
      if (!secret) {
        return Response.json({ error: 'Secret TOTP no encontrado' }, { status: 400 });
      }
      isValid = validateTOTPCode(secret, code);
    } else if (method === 'email') {
      const storedCode = roleData.mfa_email_code;
      const expiresAt = roleData.mfa_email_code_expires;
      if (!storedCode || !expiresAt) {
        return Response.json({ error: 'No hay código enviado. Solicita uno nuevo.' }, { status: 400 });
      }
      if (new Date(expiresAt) < new Date()) {
        return Response.json({ error: 'El código ha expirado. Solicita uno nuevo.' }, { status: 400 });
      }
      isValid = storedCode === code;
    }

    if (!isValid) {
      return Response.json({ success: false, error: 'Código incorrecto' }, { status: 200 });
    }

    // If this is a setup verification, mark MFA as enabled
    if (isSetup) {
      await sdk.asServiceRole.entities.UserRole.update(roleId, {
        mfa_enabled: true,
        mfa_setup_date: new Date().toISOString().split('T')[0],
        mfa_email_code: null,
        mfa_email_code_expires: null
      });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error in verifyMFA:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}