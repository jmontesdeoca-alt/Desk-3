import { createClientFromRequest } from '../../runtime/sdk.js';

// Función de apoyo para la IA: extrae y agrega datos del sistema con filtros precisos
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { query_type, date_from, date_to, date_field, company_id, agent_id, line_id, policy_type, status, limit } = body;

    const maxLimit = Math.min(limit || 2000, 5000);

    // Cargar compañías y líneas para enriquecer respuesta
    const [companies, lines] = await Promise.all([
      sdk.asServiceRole.entities.InsuranceCompany.list('name', 500),
      sdk.asServiceRole.entities.InsuranceLine.list('name', 500),
    ]);

    if (query_type === 'policies_summary') {
      let policies = await sdk.asServiceRole.entities.Policy.list('-issue_date', maxLimit);

      // Filtrar por rango de fechas
      if (date_from || date_to) {
        const field = date_field || 'issue_date';
        policies = policies.filter(p => {
          const d = p[field];
          if (!d) return false;
          if (date_from && d < date_from) return false;
          if (date_to && d > date_to) return false;
          return true;
        });
      }

      // Filtros adicionales
      if (company_id) policies = policies.filter(p => p.company_id === company_id);
      if (agent_id) policies = policies.filter(p => p.agent_id === agent_id);
      if (line_id) policies = policies.filter(p => p.line_id === line_id);
      if (policy_type) policies = policies.filter(p => p.policy_type === policy_type);
      if (status) policies = policies.filter(p => p.status === status);

      // Agregar resultados
      const total = policies.length;
      const totalPremium = policies.reduce((sum, p) => sum + (p.annual_premium || 0), 0);
      const totalCommissionable = policies.reduce((sum, p) => sum + (p.commissionable_premium || 0), 0);

      // Agrupar por compañía
      const byCompany = {};
      policies.forEach(p => {
        const key = p.company_name || 'Sin compañía';
        if (!byCompany[key]) byCompany[key] = { count: 0, premium: 0 };
        byCompany[key].count++;
        byCompany[key].premium += (p.annual_premium || 0);
      });

      // Agrupar por tipo
      const byType = {};
      policies.forEach(p => {
        const key = p.policy_type || 'sin_tipo';
        if (!byType[key]) byType[key] = { count: 0, premium: 0 };
        byType[key].count++;
        byType[key].premium += (p.annual_premium || 0);
      });

      // Agrupar por agente (top 10)
      const byAgent = {};
      policies.forEach(p => {
        const key = p.agent_name || 'Sin agente';
        if (!byAgent[key]) byAgent[key] = { count: 0, premium: 0 };
        byAgent[key].count++;
        byAgent[key].premium += (p.annual_premium || 0);
      });
      const topAgents = Object.entries(byAgent)
        .sort((a, b) => b[1].premium - a[1].premium)
        .slice(0, 10)
        .map(([name, data]) => ({ agent: name, count: data.count, premium: data.premium }));

      // Agrupar por ramo
      const byLine = {};
      policies.forEach(p => {
        const key = p.line_name || 'Sin ramo';
        if (!byLine[key]) byLine[key] = { count: 0, premium: 0 };
        byLine[key].count++;
        byLine[key].premium += (p.annual_premium || 0);
      });

      // Monedas presentes
      const currencies = [...new Set(policies.map(p => p.currency).filter(Boolean))];

      return Response.json({
        query_type,
        filters_applied: { date_from, date_to, date_field: date_field || 'issue_date', company_id, agent_id, line_id, policy_type, status },
        summary: {
          total_policies: total,
          total_annual_premium: Math.round(totalPremium * 100) / 100,
          total_commissionable_premium: Math.round(totalCommissionable * 100) / 100,
          currencies,
        },
        by_company: Object.entries(byCompany)
          .sort((a, b) => b[1].premium - a[1].premium)
          .map(([name, d]) => ({ company: name, count: d.count, premium: Math.round(d.premium * 100) / 100 })),
        by_type: Object.entries(byType)
          .map(([type, d]) => ({ type, count: d.count, premium: Math.round(d.premium * 100) / 100 })),
        by_line: Object.entries(byLine)
          .sort((a, b) => b[1].premium - a[1].premium)
          .map(([name, d]) => ({ line: name, count: d.count, premium: Math.round(d.premium * 100) / 100 })),
        top_agents: topAgents,
      });
    }

    if (query_type === 'commissions_summary') {
      let commissions = await sdk.asServiceRole.entities.Commission.list('-generation_date', maxLimit);

      if (date_from || date_to) {
        const field = date_field || 'generation_date';
        commissions = commissions.filter(c => {
          const d = c[field];
          if (!d) return false;
          if (date_from && d < date_from) return false;
          if (date_to && d > date_to) return false;
          return true;
        });
      }

      if (company_id) commissions = commissions.filter(c => c.company_id === company_id);
      if (agent_id) commissions = commissions.filter(c => c.agent_id === agent_id);
      if (status) commissions = commissions.filter(c => c.status === status);

      const total = commissions.length;
      const totalAmount = commissions.reduce((sum, c) => sum + (c.commission_amount || 0), 0);

      const byStatus = {};
      commissions.forEach(c => {
        const k = c.status || 'sin_estado';
        if (!byStatus[k]) byStatus[k] = { count: 0, amount: 0 };
        byStatus[k].count++;
        byStatus[k].amount += (c.commission_amount || 0);
      });

      return Response.json({
        query_type,
        filters_applied: { date_from, date_to, company_id, agent_id, status },
        summary: {
          total_commissions: total,
          total_amount: Math.round(totalAmount * 100) / 100,
        },
        by_status: Object.entries(byStatus).map(([s, d]) => ({
          status: s, count: d.count, amount: Math.round(d.amount * 100) / 100
        })),
      });
    }

    if (query_type === 'payments_summary') {
      let payments = await sdk.asServiceRole.entities.Payment.list('-due_date', maxLimit);

      if (date_from || date_to) {
        const field = date_field || 'due_date';
        payments = payments.filter(p => {
          const d = p[field];
          if (!d) return false;
          if (date_from && d < date_from) return false;
          if (date_to && d > date_to) return false;
          return true;
        });
      }
      if (status) payments = payments.filter(p => p.status === status);

      const total = payments.length;
      const totalAmount = payments.reduce((sum, p) => sum + (p.amount || 0), 0);

      const byStatus = {};
      payments.forEach(p => {
        const k = p.status || 'sin_estado';
        if (!byStatus[k]) byStatus[k] = { count: 0, amount: 0 };
        byStatus[k].count++;
        byStatus[k].amount += (p.amount || 0);
      });

      return Response.json({
        query_type,
        filters_applied: { date_from, date_to, date_field: date_field || 'due_date', status },
        summary: { total_payments: total, total_amount: Math.round(totalAmount * 100) / 100 },
        by_status: Object.entries(byStatus).map(([s, d]) => ({
          status: s, count: d.count, amount: Math.round(d.amount * 100) / 100
        })),
      });
    }

    if (query_type === 'catalog') {
      // Devuelve catálogos para que la IA pueda mapear nombres a IDs
      const [agents, compData, lineData] = await Promise.all([
        sdk.asServiceRole.entities.Agent.list('name', 1000),
        sdk.asServiceRole.entities.InsuranceCompany.list('name', 200),
        sdk.asServiceRole.entities.InsuranceLine.list('name', 100),
      ]);
      return Response.json({
        query_type: 'catalog',
        agents: agents.map(a => ({ id: a.id, name: a.name, alias: a.alias || null, status: a.status })),
        companies: compData.map(c => ({ id: c.id, name: c.name })),
        lines: lineData.map(l => ({ id: l.id, name: l.name })),
      });
    }

    return Response.json({ error: 'query_type no reconocido. Opciones: policies_summary, commissions_summary, payments_summary, catalog' }, { status: 400 });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});