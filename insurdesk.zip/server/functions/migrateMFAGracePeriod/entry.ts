import { createClientFromRequest } from '../../runtime/sdk.js';
import { findUserRoleByEmail } from '../../shared/mfa-utils.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Admin-only
    if (user.role !== 'admin') {
      const userRole = await findUserRoleByEmail(sdk, user.email);
      const roleData = userRole?.data || userRole;
      if (roleData?.app_role !== 'admin') {
        return Response.json({ error: 'Forbidden - Admin only' }, { status: 403 });
      }
    }

    const allRoles = await sdk.asServiceRole.entities.UserRole.list();
    const graceDeadline = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    let updated = 0;
    for (const role of allRoles) {
      const roleData = role.data || role;
      const roleId = role.id;
      const alreadyEnabled = roleData.mfa_enabled === true;
      const hasDeadline = !!roleData.mfa_grace_deadline;

      if (!alreadyEnabled && !hasDeadline) {
        await sdk.asServiceRole.entities.UserRole.update(roleId, {
          mfa_grace_deadline: graceDeadline
        });
        updated++;
      }
    }

    return Response.json({
      success: true,
      totalUsers: allRoles.length,
      updated,
      graceDeadline
    });
  } catch (error) {
    console.error('Error in migrateMFAGracePeriod:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}