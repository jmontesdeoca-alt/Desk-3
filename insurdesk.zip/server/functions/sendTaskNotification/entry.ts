import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';
import { formatDateInTimezone } from '../../shared/dateUtils.ts';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { assignedUserEmail, assignedUserName, taskTitle, taskDescription, taskPriority, taskDueDate, createdByName, taskCode } = await req.json();

    // Obtener timezone del usuario asignado (si está disponible)
    let assignedTimezone = 'UTC';
    try {
      const users = await sdk.asServiceRole.entities.User.filter({ email: assignedUserEmail });
      if (users.length > 0 && users[0].timezone) {
        assignedTimezone = users[0].timezone;
      }
    } catch {}

    const priorityLabel = taskPriority === 'alta' ? '🔴 Alta' : taskPriority === 'media' ? '🟡 Media' : '🟢 Baja';
    const codeLabel = taskCode || '';
    const formattedDate = taskDueDate ? formatDateInTimezone(taskDueDate, assignedTimezone, { day: '2-digit', month: 'long', year: 'numeric' }) : 'Sin fecha límite';

    const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background-color:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 6px rgba(0,0,0,0.07);">
          
          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,#001E2E 0%,#004B6F 50%,#001E2E 100%);padding:32px 40px;text-align:center;">
              <img src="${brand.logoOnDark}" alt="InsurDesk" style="height:48px;margin-bottom:12px;" />
              <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700;letter-spacing:1px;">GA<span style="color:#76DDF9;">Portal</span></h1>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:40px 40px 32px;">
              <p style="margin:0 0 8px;color:#64748b;font-size:14px;">Hola,</p>
              <h2 style="margin:0 0 24px;color:#0f172a;font-size:20px;font-weight:700;">
                📋 Tienes una nueva tarea asignada
              </h2>
              <p style="margin:0 0 24px;color:#475569;font-size:15px;line-height:1.6;">
                <strong>${createdByName || 'Un usuario'}</strong> te ha asignado la siguiente tarea:
              </p>

              <!-- Task Card -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:24px;">
                <tr>
                  <td style="padding:24px;">
                    ${codeLabel ? `<div style="display:inline-block;background:#001E2E;color:#76DDF9;font-size:12px;font-weight:700;letter-spacing:0.5px;padding:4px 10px;border-radius:6px;margin-bottom:12px;">${codeLabel}</div>` : ''}
                    <h3 style="margin:0 0 16px;color:#0f172a;font-size:17px;font-weight:700;">${taskTitle}</h3>
                    ${taskDescription ? `<p style="margin:0 0 16px;color:#475569;font-size:14px;line-height:1.6;">${taskDescription}</p>` : ''}
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding:6px 0;">
                          <span style="color:#94a3b8;font-size:13px;">Prioridad:</span>
                          <span style="color:#334155;font-size:13px;font-weight:600;margin-left:8px;">${priorityLabel}</span>
                        </td>
                      </tr>
                      <tr>
                        <td style="padding:6px 0;">
                          <span style="color:#94a3b8;font-size:13px;">Fecha límite:</span>
                          <span style="color:#334155;font-size:13px;font-weight:600;margin-left:8px;">${formattedDate}</span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 24px;color:#475569;font-size:14px;line-height:1.6;">
                Ingresa a InsurDesk para ver el detalle completo y gestionar esta tarea.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color:#f8fafc;border-top:1px solid #e2e8f0;padding:20px 40px;text-align:center;">
              <p style="margin:0;color:#94a3b8;font-size:12px;">Este es un mensaje automático de InsurDesk. Por favor no responda a este correo.</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) return Response.json({ error: 'RESEND_API_KEY not configured' }, { status: 500 });

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: brand.from('Tareas'),
        to: [assignedUserEmail],
        subject: `📋 ${codeLabel ? `[${codeLabel}] ` : ''}Nueva tarea asignada: ${taskTitle}`,
        html: emailBody
      })
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Resend error (${res.status}): ${err}`);
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});