import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const { to, subject, body, from_name, type, data, bcc, cc } = payload;

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) {
      return Response.json({ error: 'RESEND_API_KEY not configured' }, { status: 500 });
    }

    const sender = from_name ? `${from_name} <${brand.address}>` : brand.from();

    // Construir destinatarios principales
    const toList = Array.isArray(to) ? to : [to];
    const bccList = bcc ? (Array.isArray(bcc) ? bcc : bcc.split(',').map(e => e.trim())) : [];
    const ccList = cc ? (Array.isArray(cc) ? cc : cc.split(',').map(e => e.trim())) : [];

    // Construir el cuerpo del correo según el tipo
    let htmlBody;
    let emailSubject;

    if (type === 'NEW_POLICY' && data) {
      emailSubject = `Nueva Póliza Emitida - ${data.poliza}`;
      htmlBody = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(to right, #001E2E, #004B6F); padding: 20px; border-radius: 8px 8px 0 0;">
    <h1 style="color: white; margin: 0;">GA<span style="color: #76DDF9;">Portal</span></h1>
    <p style="color: #76DDF9; margin: 5px 0 0;">Nueva Póliza Emitida</p>
  </div>
  <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p>Se ha emitido una nueva póliza con los siguientes detalles:</p>
    <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Agente:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.agente || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Póliza:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.poliza || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Cliente:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.cliente || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Compañía:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.compania || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Producto:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.producto || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Prima:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.moneda || 'USD'} ${data.monto || 0}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Vigencia:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.fecha_inicio || '—'} al ${data.fecha_fin || '—'}</td></tr>
    </table>
    <p style="color: #999; font-size: 12px; text-align: center;">Este es un correo automático generado por InsurDesk.</p>
  </div>
</body>
</html>`;
    } else if (type === 'RENEWAL_REMINDER' && data) {
      emailSubject = `Renovación de Póliza ${data.poliza} - Vence en ${data.dias} días`;
      htmlBody = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(to right, #001E2E, #004B6F); padding: 20px; border-radius: 8px 8px 0 0;">
    <h1 style="color: white; margin: 0;">GA<span style="color: #76DDF9;">Portal</span></h1>
    <p style="color: #76DDF9; margin: 5px 0 0;">Recordatorio de Renovación</p>
  </div>
  <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p>Estimado/a <strong>${data.agente || 'Agente'}</strong>,</p>
    <p>Le informamos que la póliza <strong>${data.poliza}</strong> vence en <strong>${data.dias} días</strong>.</p>
    <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Cliente:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.cliente || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Compañía:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.compania || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Producto:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.producto || '—'}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Prima:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.moneda || 'USD'} ${data.monto || 0}</td></tr>
      <tr><td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold;">Vigencia:</td><td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${data.fecha_inicio || '—'} al ${data.fecha_fin || '—'}</td></tr>
    </table>
    <p>Por favor coordine con el cliente la renovación a la brevedad.</p>
    <p style="color: #999; font-size: 12px; text-align: center;">Este es un correo automático generado por InsurDesk.</p>
  </div>
</body>
</html>`;
    } else {
      // Correo genérico
      if (!to || !subject || !body) {
        return Response.json({ error: 'Missing required fields: to, subject, body' }, { status: 400 });
      }
      emailSubject = subject;
      htmlBody = body.includes('<html') ? body : `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
  ${body}
</body>
</html>`;
    }

    // Enviar email usando Resend
    const resendBody = {
      from: sender,
      to: toList,
      subject: emailSubject,
      html: htmlBody
    };
    if (ccList.length > 0) resendBody.cc = ccList;
    if (bccList.length > 0) resendBody.bcc = bccList;

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(resendBody)
    });

    let responseData;
    try {
      responseData = await response.json();
    } catch {
      throw new Error(`Resend API error: ${response.status} ${response.statusText}`);
    }

    if (!response.ok) {
      const errorMsg = responseData.message || responseData.error || JSON.stringify(responseData);
      throw new Error(`Resend API (${response.status}): ${errorMsg}`);
    }

    return Response.json({ 
      success: true,
      message: 'Email sent successfully via Resend',
      email_id: responseData.id
    });

  } catch (error) {
    console.error('Error sending email:', error);
    return Response.json({ 
      success: false,
      error: error.message || 'Error al enviar correo'
    }, { status: 500 });
  }
});