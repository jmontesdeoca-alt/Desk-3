import { createClientFromRequest } from '../../runtime/sdk.js';
import { local as localDocs } from '../../runtime/localdocs.js';

function parseConnectionString(connStr) {
  const parts = {};
  for (const segment of connStr.split(';')) {
    const idx = segment.indexOf('=');
    if (idx > -1) {
      parts[segment.slice(0, idx)] = segment.slice(idx + 1);
    }
  }
  return {
    accountName: parts['AccountName'],
    accountKey: parts['AccountKey'],
    endpointSuffix: parts['EndpointSuffix'] || 'core.windows.net'
  };
}

async function hmacSha256(key, message) {
  const cryptoKey = await crypto.subtle.importKey(
    'raw', key, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', cryptoKey, new TextEncoder().encode(message));
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}

async function deleteBlob(accountName, accountKey, endpointSuffix, containerName, blobName) {
  const date = new Date().toUTCString();
  const version = '2020-10-02';

  // Azure Shared Key Lite for Blob - canonicalized resource uses decoded path
  const canonicalizedResource = `/${accountName}/${containerName}/${blobName}`;

  // StringToSign for SharedKey (full, 13 fields for blob service)
  const stringToSign = [
    'DELETE',   // HTTP Verb
    '',          // Content-Encoding
    '',          // Content-Language
    '',          // Content-Length (empty for DELETE)
    '',          // Content-MD5
    '',          // Content-Type
    '',          // Date (empty when x-ms-date is used)
    '',          // If-Modified-Since
    '',          // If-Match
    '',          // If-None-Match
    '',          // If-Unmodified-Since
    '',          // Range
    `x-ms-date:${date}\nx-ms-version:${version}`,  // CanonicalizedHeaders
    canonicalizedResource  // CanonicalizedResource
  ].join('\n');

  const keyBytes = Uint8Array.from(atob(accountKey), c => c.charCodeAt(0));
  const signature = await hmacSha256(keyBytes, stringToSign);

  // URL-encode each segment of the blob path separately
  const encodedBlobName = blobName.split('/').map(s => encodeURIComponent(s)).join('/');
  const url = `https://${accountName}.blob.${endpointSuffix}/${containerName}/${encodedBlobName}`;

  const response = await fetch(url, {
    method: 'DELETE',
    headers: {
      'x-ms-date': date,
      'x-ms-version': version,
      'Authorization': `SharedKey ${accountName}:${signature}`
    }
  });

  if (!response.ok && response.status !== 404) {
    const errText = await response.text();
    throw new Error(`Azure delete failed (${response.status}): ${errText}`);
  }
}

export default (async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const sdk = createClientFromRequest(req);
  const user = await sdk.auth.me();
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const connStr = process.env.AZURE_STORAGE_CONNECTION_STRING;
  if (!connStr) {
    return await localDocs.remove(req, sdk);
  }

  const raw = await req.json();
  const body = raw.payload ?? raw;
  const { documentId, blobPath, fileUrl } = body;

  if (!documentId) {
    return Response.json({ error: 'documentId es requerido' }, { status: 400 });
  }

  const { accountName, accountKey, endpointSuffix } = parseConnectionString(connStr);
  const containerName = 'documentos';

  // Resolve the blob path: use explicit blobPath, or extract from fileUrl
  let resolvedBlobPath = blobPath || null;
  if (!resolvedBlobPath && fileUrl) {
    // fileUrl format: https://<account>.blob.core.windows.net/<container>/<blobPath>
    try {
      const urlObj = new URL(fileUrl);
      // pathname is "/<container>/<blobPath...>"
      const parts = urlObj.pathname.split('/');
      // parts[0]='', parts[1]=containerName, rest=blobPath
      resolvedBlobPath = parts.slice(2).join('/');
    } catch {}
  }

  if (resolvedBlobPath) {
    await deleteBlob(accountName, accountKey, endpointSuffix, containerName, resolvedBlobPath);
  }

  // Delete the Document entity record
  await sdk.asServiceRole.entities.Document.delete(documentId);

  return Response.json({ ok: true });
});