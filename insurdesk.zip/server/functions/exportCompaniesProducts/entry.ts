import { createClientFromRequest } from '../../runtime/sdk.js';
import * as XLSX from 'xlsx';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const [companies, products] = await Promise.all([
      sdk.asServiceRole.entities.InsuranceCompany.list(),
      sdk.asServiceRole.entities.Product.list()
    ]);

    const wb = XLSX.utils.book_new();

    // Hoja 1: Compañías aseguradoras
    const companiesData = companies.map(c => ({
      'Nombre': c.name || '',
      'País': c.country || '',
      'Branch': c.branch_name || '',
      'Email de contacto': c.contact_email || '',
      'Teléfono de contacto': c.contact_phone || '',
      'Ramos': (c.lines || []).join(', '),
      'Pago nuevo negocio': c.new_business_payment_type || '',
      'Pago renovación': c.renewal_payment_type || '',
      'Pago directo a agentes': c.direct_payment_to_agents ? 'Sí' : 'No',
      'Estado': c.status || '',
      'Notas': c.notes || ''
    }));
    const wsCompanies = XLSX.utils.json_to_sheet(companiesData);
    wsCompanies['!cols'] = [
      { wch: 30 }, { wch: 18 }, { wch: 16 }, { wch: 28 }, { wch: 18 },
      { wch: 35 }, { wch: 18 }, { wch: 18 }, { wch: 20 }, { wch: 12 }, { wch: 30 }
    ];
    XLSX.utils.book_append_sheet(wb, wsCompanies, 'Compañías');

    // Hoja 2: Productos
    const productsData = products.map(p => ({
      'Compañía': p.company_name || '',
      'Ramo': p.line_name || '',
      'Nombre del producto': p.product_name || '',
      'Categoría': p.product_category || '',
      'Monto asegurado': p.insured_amount || '',
      'Opciones deducible 1': (p.deductible_1_options || []).join(', '),
      'Opciones deducible 2': (p.deductible_2_options || []).join(', '),
      'Permite renovación': p.allows_renewal ? 'Sí' : 'No',
      'Período renovación por defecto': p.default_renewal_period || '',
      'Estado': p.status || ''
    }));
    const wsProducts = XLSX.utils.json_to_sheet(productsData);
    wsProducts['!cols'] = [
      { wch: 30 }, { wch: 18 }, { wch: 35 }, { wch: 14 }, { wch: 16 },
      { wch: 25 }, { wch: 25 }, { wch: 18 }, { wch: 28 }, { wch: 12 }
    ];
    XLSX.utils.book_append_sheet(wb, wsProducts, 'Productos');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    return new Response(buf, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': 'attachment; filename="Companias_Productos_GA.xlsx"'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});