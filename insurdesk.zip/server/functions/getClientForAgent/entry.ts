import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: 'No autenticado' }, { status: 401 });
    }

    const { client_id } = await req.json();
    if (!client_id) {
      return Response.json({ error: 'client_id requerido' }, { status: 400 });
    }

    // Get user's app role info
    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const appRole = userRole?.app_role;

    // If not agente, they can use the normal client page
    if (appRole !== 'agente') {
      const clients = await sdk.asServiceRole.entities.Client.filter({ id: client_id });
      const client = clients[0];
      if (!client) return Response.json({ error: 'Cliente no encontrado' }, { status: 404 });
      return Response.json({ client });
    }

    // For agente: verify they have at least one policy with this client (within their hierarchy)
    const agentId = userRole?.agent_id;
    if (!agentId) {
      return Response.json({ error: 'Agente no vinculado' }, { status: 403 });
    }

    // Get all descendant agent IDs (including the agent themselves)
    const allAgents = await sdk.asServiceRole.entities.Agent.list();
    const hierarchyIds = new Set();
    const findSubordinates = (currentId) => {
      hierarchyIds.add(currentId);
      allAgents
        .filter(a => a.upline_agent_id === currentId)
        .forEach(a => findSubordinates(a.id));
    };
    findSubordinates(agentId);
    const allowedAgentIds = Array.from(hierarchyIds);

    // Fetch all policies in hierarchy and filter for this client
    const allPolicies = await sdk.asServiceRole.entities.Policy.list('-created_date', 5000);
    const clientPolicies = allPolicies.filter(p =>
      allowedAgentIds.includes(p.agent_id) &&
      (p.client_id === client_id || p.contractor_id === client_id)
    );

    if (clientPolicies.length === 0) {
      return Response.json({ error: 'Sin acceso a este cliente' }, { status: 403 });
    }

    // Fetch client data
    const clients = await sdk.asServiceRole.entities.Client.filter({ id: client_id });
    const client = clients[0];
    if (!client) return Response.json({ error: 'Cliente no encontrado' }, { status: 404 });

    const policies = clientPolicies.map(p => ({
      id: p.id,
      policy_number: p.policy_number,
      product_name: p.product_name,
      company_name: p.company_name,
      status: p.status
    }));

    return Response.json({ client, policies });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});