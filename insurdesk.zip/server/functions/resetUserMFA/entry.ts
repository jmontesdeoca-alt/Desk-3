import { createClientFromRequest } from '../../runtime/sdk.js';
import { findUserRoleByEmail } from '../../shared/mfa-utils.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Admin-only
    if (user.role !== 'admin') {
      const userRole = await findUserRoleByEmail(sdk, user.email);
      const roleData = userRole?.data || userRole;
      if (roleData?.app_role !== 'admin') {
        return Response.json({ error: 'Forbidden - Admin only' }, { status: 403 });
      }
    }

    const body = await req.json();
    const targetEmail = body?.email;

    if (!targetEmail) {
      return Response.json({ error: 'Email del usuario requerido' }, { status: 400 });
    }

    const targetUserRole = await findUserRoleByEmail(sdk, targetEmail);
    if (!targetUserRole) {
      return Response.json({ error: 'Usuario no encontrado' }, { status: 404 });
    }

    const roleId = targetUserRole.id;

    await sdk.asServiceRole.entities.UserRole.update(roleId, {
      mfa_enabled: false,
      mfa_method: null,
      mfa_secret: null,
      mfa_setup_date: null,
      mfa_email_code: null,
      mfa_email_code_expires: null
    });

    return Response.json({ success: true, message: 'MFA reseteado correctamente' });
  } catch (error) {
    console.error('Error in resetUserMFA:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}