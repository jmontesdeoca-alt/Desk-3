import { createClientFromRequest } from '../../runtime/sdk.js';

const FIELDS = {
  annual_premium: { type: 'number', label: 'Prima anual' },
  client_name: { type: 'string', label: 'Titular' },
  agent_name: { type: 'string', label: 'Agente' }
};

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Verificar permisos
    let userRole = null;
    try {
      const roleResp = await sdk.functions.invoke('getUserRoleInfo', {});
      userRole = roleResp?.data || roleResp;
    } catch {}
    const appRole = userRole?.app_role;
    const isAdmin = user?.role === 'admin' || appRole === 'admin' || appRole === 'jefatura' || appRole === 'gerencial';
    if (!isAdmin) return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json();
    const { policy_id, field, value } = body;

    if (!policy_id) return Response.json({ error: 'policy_id es requerido' }, { status: 400 });
    if (!field || !FIELDS[field]) return Response.json({ error: `field inválido. Permitidos: ${Object.keys(FIELDS).join(', ')}` }, { status: 400 });

    // Castear valor al tipo correcto
    let castValue = value;
    if (FIELDS[field].type === 'number') {
      castValue = Number(value);
      if (isNaN(castValue)) return Response.json({ error: `Valor inválido para ${FIELDS[field].label} (debe ser numérico)` }, { status: 400 });
    } else {
      castValue = (value ?? '').toString().trim();
      if (!castValue) return Response.json({ error: `Valor inválido para ${FIELDS[field].label}` }, { status: 400 });
    }

    // Obtener valor anterior para auditoría
    const policy = await sdk.asServiceRole.entities.Policy.get(policy_id);
    const oldValue = policy?.[field];

    // Actualizar
    await sdk.asServiceRole.entities.Policy.update(policy_id, { [field]: castValue });

    // Registrar en AuditLog
    try {
      await sdk.asServiceRole.entities.AuditLog.create({
        user_email: user.email || 'unknown',
        action: 'AUDIT_UPDATE',
        entity_type: 'Policy',
        entity_id: policy_id,
        details: `Corrección desde auditoría de datos: campo "${field}" actualizado de "${oldValue}" a "${castValue}"`,
        changes: { field, old_value: oldValue, new_value: castValue, source: 'data_audit' }
      });
    } catch (e) {
      console.error('No se pudo registrar AuditLog:', e);
    }

    return Response.json({
      success: true,
      policy_id,
      field,
      old_value: oldValue,
      new_value: castValue
    });
  } catch (error) {
    console.error('Error en actualizarPolizaAuditada:', error);
    return Response.json({ error: error.message || 'Error interno' }, { status: 500 });
  }
}