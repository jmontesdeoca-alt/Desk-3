import { createClientFromRequest } from '../../runtime/sdk.js';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    const body = await req.json();
    const policyId = body?.policyId;
    if (!policyId) return Response.json({ error: 'policyId es requerido' }, { status: 400 });

    const step = async (name, fn) => {
      try {
        await fn();
      } catch (e) {
        throw new Error(`Paso "${name}" falló: ${e.message || e}`);
      }
    };

    // Eliminar en cascada los registros vinculados, luego la póliza
    await step('Payment', () => sdk.asServiceRole.entities.Payment.deleteMany({ policy_id: policyId }));
    await step('Commission', () => sdk.asServiceRole.entities.Commission.deleteMany({ policy_id: policyId }));
    await step('Claim', () => sdk.asServiceRole.entities.Claim.deleteMany({ policy_id: policyId }));
    await step('Endorsement', () => sdk.asServiceRole.entities.Endorsement.deleteMany({ policy_id: policyId }));
    await step('Policy', () => sdk.asServiceRole.entities.Policy.delete(policyId));

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}