import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);

    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { claim_id, recipient_type, html_body } = await req.json();
    if (!claim_id || !recipient_type || !html_body) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Fetch claim
    const claims = await sdk.asServiceRole.entities.Claim.filter({ id: claim_id });
    const claim = claims[0];
    if (!claim) return Response.json({ error: 'Claim not found' }, { status: 404 });

    const subject = `Informe de Siniestro N.° ${claim.claim_number} — ${claim.client_name}`;

    if (recipient_type === 'client') {
      // Get client email
      const clients = await sdk.asServiceRole.entities.Client.filter({ id: claim.client_id });
      const client = clients[0];
      if (!client?.email) {
        return Response.json({ error: 'El cliente no tiene correo registrado' }, { status: 400 });
      }

      await sdk.asServiceRole.functions.invoke('sendEmail', {
        to: client.email,
        subject,
        body: html_body,
        from_name: `${brand.name} Siniestros`,
      });

      return Response.json({ success: true, sent_to: client.email });
    }

    if (recipient_type === 'agent') {
      // Get policy to find agent
      const policies = await sdk.asServiceRole.entities.Policy.filter({ id: claim.policy_id });
      const policy = policies[0];
      if (!policy?.agent_id) {
        return Response.json({ error: 'No se encontró la póliza o el agente' }, { status: 400 });
      }

      const agents = await sdk.asServiceRole.entities.Agent.filter({ id: policy.agent_id });
      const agent = agents[0];
      if (!agent?.email) {
        return Response.json({ error: 'El agente no tiene correo registrado' }, { status: 400 });
      }

      // Find Nivel 2 upline (same pattern as sendRenewalReminders)
      let nivel2Agent = null;
      if (!agent.is_nivel_2) {
        let currentAgent = agent;
        while (currentAgent.upline_agent_id && !nivel2Agent) {
          const uplineAgents = await sdk.asServiceRole.entities.Agent.filter({ id: currentAgent.upline_agent_id });
          if (uplineAgents.length > 0) {
            currentAgent = uplineAgents[0];
            if (currentAgent.is_nivel_2) nivel2Agent = currentAgent;
          } else break;
        }
      }

      const bcc = nivel2Agent?.email || undefined;
      const cc  = agent.operational_email || undefined;

      await sdk.asServiceRole.functions.invoke('sendEmail', {
        to: agent.email,
        ...(bcc && { bcc }),
        ...(cc && { cc }),
        subject,
        body: html_body,
        from_name: `${brand.name} Siniestros`,
      });

      return Response.json({
        success: true,
        sent_to: agent.email,
        bcc: bcc || null,
        cc: cc || null,
      });
    }

    return Response.json({ error: 'Invalid recipient_type' }, { status: 400 });

  } catch (error) {
    console.error('sendClaimReport error:', error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});