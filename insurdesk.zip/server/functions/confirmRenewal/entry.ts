import { createClientFromRequest } from '../../runtime/sdk.js';
import { confirmSingleRenewal } from '../../shared/renewalConfirmation.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { renewal_id } = body;

    if (!renewal_id) {
      return Response.json({ error: 'renewal_id es requerido' }, { status: 400 });
    }

    const result = await confirmSingleRenewal(sdk, renewal_id, null);

    return Response.json(result);
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
}