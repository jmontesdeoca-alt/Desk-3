import { createClientFromRequest } from '../../runtime/sdk.js';
import { confirmSingleRenewal } from '../../shared/renewalConfirmation.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { renewal_ids } = body;

    if (!renewal_ids || !Array.isArray(renewal_ids) || renewal_ids.length === 0) {
      return Response.json({ error: 'renewal_ids[] es requerido' }, { status: 400 });
    }

    // Load reference data ONCE for all renewals in the batch
    const refData = {
      agents: await sdk.asServiceRole.entities.Agent.list(),
      assignments: await sdk.asServiceRole.entities.AgentCommissionAssignment.list(),
      commissionTables: await sdk.asServiceRole.entities.CommissionTable.list()
    };

    const confirmed = [];
    const failed = [];

    // Process sequentially — each renewal depends on the prior one's state changes
    for (const renewalId of renewal_ids) {
      try {
        const result = await confirmSingleRenewal(sdk, renewalId, refData);
        confirmed.push({
          renewal_id: renewalId,
          new_policy_number: result.new_policy_number,
          new_policy_id: result.new_policy_id
        });
      } catch (error) {
        failed.push({
          renewal_id: renewalId,
          error: error.message
        });
      }
    }

    return Response.json({
      success: true,
      total: renewal_ids.length,
      confirmed_count: confirmed.length,
      failed_count: failed.length,
      confirmed,
      failed
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}