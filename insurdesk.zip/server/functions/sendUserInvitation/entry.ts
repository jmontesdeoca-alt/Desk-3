import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

const RESEND_API_KEY = process.env.RESEND_API_KEY;

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();

    if (!user || (user.role !== 'admin' && user.app_role !== 'admin')) {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { email, fullName, appRole, agentId, crmAccess } = await req.json();

    console.log('Received invitation request:', { email, fullName, appRole, agentId });

    if (!email || !fullName || !appRole) {
      return Response.json({ error: 'Missing required fields: email=' + !!email + ', fullName=' + !!fullName + ', appRole=' + !!appRole }, { status: 400 });
    }

    // Generate invitation token and link using brand.appUrl.replace(/^https?:\/\//, '')
    const appDomain = brand.appUrl.replace(/^https?:\/\//, '');
    const baseUrl = appDomain.startsWith('http') ? appDomain : `https://${appDomain}`;
    const invitationLink = `${baseUrl}/login?email=${encodeURIComponent(email)}`;

    // Build HTML email with role details and domain info
    const roleDescriptions = {
      admin: 'Administrador del sistema con acceso completo',
      gerencial: 'Acceso a reportes y análisis (solo lectura)',
      jefatura: 'Gestión de agentes y estructura organizacional',
      operativo: 'Creación y edición de pólizas y pagos',
      financiero: 'Gestión de pagos y análisis financiero',
      agente: 'Portal individual con pólizas y comisiones'
    };

    const htmlEmail = `
      <!DOCTYPE html>
      <html lang="es">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #001E2E 0%, #004B6F 100%);
            margin: 0;
            padding: 20px;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 30, 46, 0.2);
          }
          .header {
            background: linear-gradient(135deg, #001E2E 0%, #004B6F 50%, #001E2E 100%);
            color: white;
            padding: 40px 20px 32px;
            text-align: center;
            border-bottom: 3px solid #0A8FBE;
          }
          .header-brand {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 10px;
          }
          .header-brand img {
            height: 42px;
            width: auto;
          }
          .logo {
            font-size: 30px;
            font-weight: bold;
            line-height: 1;
          }
          .logo-accent {
            color: #76DDF9;
          }
          .content {
            padding: 40px;
          }
          .welcome {
            font-size: 20px;
            font-weight: bold;
            color: #001E2E;
            margin-bottom: 10px;
          }
          .info-block {
            background: #f0f9ff;
            border-left: 4px solid #0A8FBE;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
          }
          .info-label {
            font-size: 12px;
            color: #0A8FBE;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          .info-value {
            font-size: 16px;
            color: #001E2E;
            font-weight: 500;
          }
          .role-description {
            color: #666;
            font-size: 14px;
            margin-top: 8px;
          }
          .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, #0A8FBE 0%, #004B6F 100%);
            color: #ffffff !important;
            padding: 14px 36px;
            border-radius: 8px;
            text-decoration: none !important;
            font-weight: 700 !important;
            font-size: 15px;
            margin: 30px 0;
            text-align: center;
            letter-spacing: 0.3px;
            box-shadow: 0 4px 15px rgba(10, 143, 190, 0.35);
          }
          .cta-button:hover {
            opacity: 0.9;
          }
          .footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            font-size: 12px;
            color: #666;
            border-top: 1px solid #eee;
          }
          .domain-info {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
          }
          .domain-label {
            font-size: 12px;
            color: #856404;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          .domain-value {
            font-size: 14px;
            color: #333;
            font-family: monospace;
            word-break: break-all;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="header-brand">
              <img src="${brand.logoOnDark}" alt="InsurDesk" />
              <div class="logo">GA<span class="logo-accent">Portal</span></div>
            </div>
            <p style="margin: 0; color: #94d8f0; font-size: 14px; letter-spacing: 0.5px;">Sistema de Gestión de Seguros</p>
          </div>
          
          <div class="content">
            <div class="welcome">¡Bienvenido a InsurDesk!</div>
            <p>Hola <strong>${fullName}</strong>,</p>
            <p>Ha sido invitado a acceder a InsurDesk, nuestra plataforma de gestión de seguros.</p>
            
            <div class="info-block">
              <div class="info-label">Usuario (Email)</div>
              <div class="info-value">${email}</div>
            </div>
            
            <div class="info-block">
              <div class="info-label">Rol Asignado</div>
              <div class="info-value">${appRole.charAt(0).toUpperCase() + appRole.slice(1)}</div>
              <div class="role-description">${roleDescriptions[appRole] || 'Rol personalizado'}</div>
            </div>
            
            <p style="margin-top: 30px; color: #666;">Para acceder a InsurDesk, haga clic en el botón de abajo:</p>
            
            <center>
              <a href="${invitationLink}" class="cta-button">Acceder a InsurDesk</a>
            </center>
            
            <p style="font-size: 13px; color: #999; margin-top: 30px;">
              Si el botón no funciona, copie y pegue esta URL en su navegador:<br>
              <code style="background: #f5f5f5; padding: 8px; display: block; margin-top: 10px; word-break: break-all;">${invitationLink}</code>
            </p>
            
            <p style="margin-top: 30px; color: #666; font-size: 13px;">
              Si tiene preguntas o necesita ayuda, no dude en contactarnos.
            </p>
          </div>
          
          <div class="footer">
            <p>© 2026 InsurDesk. Todos los derechos reservados.</p>
            <p>Este es un correo automático. Por favor no responda a este mensaje.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    // 1. Create UserRole record FIRST (app-specific data)
    try {
      await sdk.entities.UserRole.create({
        email: email.toLowerCase(),
        app_role: appRole,
        agent_id: agentId || null,
        status: 'active',
        crm_access_enabled: crmAccess || false
      });
    } catch (err) {
      // If UserRole exists, update it
      try {
        const existingRoles = await sdk.entities.UserRole.filter({ email: email.toLowerCase() });
        if (existingRoles.length > 0) {
          await sdk.entities.UserRole.update(existingRoles[0].id, {
            app_role: appRole,
            agent_id: agentId || null,
            status: 'active',
            crm_access_enabled: crmAccess || false
          });
        }
      } catch (updateErr) {
        console.error('Error updating UserRole:', updateErr);
        return Response.json({ error: 'Failed to create or update user role' }, { status: 500 });
      }
    }

    // 2. Create User record (system role only)
    let newUser;
    try {
      newUser = await sdk.entities.User.create({
        email: email.toLowerCase(),
        role: 'user',
        full_name: fullName
      });
    } catch (err) {
      // If user exists, get it
      const existingUsers = await sdk.entities.User.list();
      newUser = existingUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    }

    // 3. Send email via Resend
    console.log('Sending email to:', email, 'with RESEND_API_KEY:', RESEND_API_KEY ? 'PRESENT' : 'MISSING');
    
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: brand.from(),
        to: email,
        subject: `Invitación a InsurDesk - ${fullName}`,
        html: htmlEmail,
      }),
    });

    console.log('Resend response status:', response.status);
    
    if (!response.ok) {
      const error = await response.json();
      console.error('Resend error:', error);
      return Response.json({ error: 'Failed to send email: ' + JSON.stringify(error), status: 500 });
    }

    const result = await response.json();
    console.log('Email sent successfully, ID:', result.id);
    
    return Response.json({
      success: true,
      message: 'Invitation email sent successfully',
      email,
      fullName,
      appRole,
      emailId: result.id
    });
  } catch (error) {
    console.error('Error in sendUserInvitation:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});