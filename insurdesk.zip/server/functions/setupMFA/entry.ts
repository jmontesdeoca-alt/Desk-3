import { createClientFromRequest } from '../../runtime/sdk.js';
import { generateTOTPConfig, findUserRoleByEmail, extractRoleData } from '../../shared/mfa-utils.ts';

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const method = body?.method;

    if (!method || !['totp', 'email'].includes(method)) {
      return Response.json({ error: 'Método inválido. Debe ser "totp" o "email"' }, { status: 400 });
    }

    const userRole = await findUserRoleByEmail(sdk, user.email);
    if (!userRole) {
      return Response.json({ error: 'No se encontró el registro de usuario' }, { status: 404 });
    }

    const roleData = extractRoleData(userRole);
    const roleId = userRole.id;

    if (method === 'totp') {
      const { base32Secret, otpauthUrl } = generateTOTPConfig(user.email);
      await sdk.asServiceRole.entities.UserRole.update(roleId, {
        mfa_secret: base32Secret,
        mfa_method: 'totp'
      });
      return Response.json({ method: 'totp', otpauthUrl, secret: base32Secret });
    } else {
      await sdk.asServiceRole.entities.UserRole.update(roleId, {
        mfa_method: 'email'
      });
      return Response.json({ method: 'email' });
    }
  } catch (error) {
    console.error('Error in setupMFA:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}