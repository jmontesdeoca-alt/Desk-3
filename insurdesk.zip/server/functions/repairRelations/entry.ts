// Repara vínculos por id: asigna códigos únicos, enlaza por nombre lo que solo tenía nombre y refresca nombres.
// Úsala tras importar datos. Por defecto solo simula (dryRun: true); con dryRun: false aplica los cambios.
import { createClientFromRequest } from '../../runtime/sdk.js';
import { repairRelations } from '../../src/relations.js';

export default (async (req) => {
  const sdk = createClientFromRequest(req);
  const user = await sdk.auth.me().catch(() => null);
  if (!user || (user.role !== 'admin' && user.app_role !== 'admin')) return Response.json({ error: 'Solo un administrador puede reparar relaciones' }, { status: 403 });
  const { dryRun = true } = await req.json().catch(() => ({}));
  return Response.json({ success: true, ...repairRelations({ dryRun: dryRun !== false }) });
});
