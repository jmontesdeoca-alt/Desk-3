import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    
    // Only admin can delete settlements
    if (user?.role !== 'admin' && user?.app_role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }
    
    const { settlement_id } = await req.json();
    
    if (!settlement_id) {
      return Response.json({ error: 'settlement_id is required' }, { status: 400 });
    }
    
    // Get settlement
    const settlements = await sdk.asServiceRole.entities.CommissionSettlement.filter({ id: settlement_id });
    if (settlements.length === 0) {
      return Response.json({ error: 'Settlement not found' }, { status: 404 });
    }
    
    const settlement = settlements[0];
    
    // Get all commissions in this settlement
    const allCommissions = await sdk.asServiceRole.entities.Commission.list();
    const settlementCommissions = allCommissions.filter(c => settlement.commission_ids?.includes(c.id));
    
    // Update all commissions back to pendiente_liberar and clear released_date
    for (const commission of settlementCommissions) {
      await sdk.asServiceRole.entities.Commission.update(commission.id, {
        status: 'pendiente_liberar',
        released_date: null
      });
    }

    // Delete any AgentNegativeBalance originated from this settlement
    let negativeBalanceDeleted = false;
    try {
      const negBalances = await sdk.asServiceRole.entities.AgentNegativeBalance.filter({
        origin_settlement_id: settlement_id
      });
      for (const nb of negBalances) {
        await sdk.asServiceRole.entities.AgentNegativeBalance.delete(nb.id);
        negativeBalanceDeleted = true;
      }
    } catch (e) {
      console.warn('Could not clean negative balance:', e.message);
    }

    // Delete the settlement
    await sdk.asServiceRole.entities.CommissionSettlement.delete(settlement_id);

    return Response.json({
      success: true,
      message: 'Liquidación eliminada, comisiones liberadas y balance negativo limpiado',
      commissions_released: settlementCommissions.length,
      negative_balance_deleted: negativeBalanceDeleted
    });
    
  } catch (error) {
    console.error('Error deleting settlement:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});