import { createClientFromRequest } from '../../runtime/sdk.js';
import { local as localDocs } from '../../runtime/localdocs.js';
import { BlobServiceClient, StorageSharedKeyCredential } from '@azure/storage-blob';

function parseConnectionString(connStr) {
  const parts = {};
  for (const segment of connStr.split(';')) {
    const idx = segment.indexOf('=');
    if (idx > -1) {
      parts[segment.slice(0, idx)] = segment.slice(idx + 1);
    }
  }
  return {
    accountName: parts['AccountName'],
    accountKey: parts['AccountKey'],
    endpointSuffix: parts['EndpointSuffix'] || 'core.windows.net'
  };
}

export default (async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const sdk = createClientFromRequest(req);
  const user = await sdk.auth.me();
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const connStr = process.env.AZURE_STORAGE_CONNECTION_STRING;
  if (!connStr) {
    return await localDocs.upload(req, sdk, user);
  }

  const raw = await req.json();
  const body = raw.payload ?? raw;
  const { fileBase64, fileName, mimeType, clienteId, polizaId, carpeta, tipoDocumento } = body;

  if (!fileBase64 || !clienteId || !polizaId || !fileName) {
    return Response.json({ error: 'fileBase64, clienteId, polizaId y fileName son requeridos' }, { status: 400 });
  }

  const contentType = mimeType || 'application/octet-stream';
  const binaryStr = atob(fileBase64);
  const bytes = new Uint8Array(binaryStr.length);
  for (let i = 0; i < binaryStr.length; i++) {
    bytes[i] = binaryStr.charCodeAt(i);
  }
  const size = bytes.byteLength;

  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
  const folder = carpeta || 'cliente';
  const docType = tipoDocumento || 'documento';
  const blobPath = `clientes/${clienteId}/polizas/${polizaId}/${folder}/${docType}_${safeName}`;
  const containerName = 'documentos';

  const { accountName, accountKey, endpointSuffix } = parseConnectionString(connStr);
  const sharedKeyCredential = new StorageSharedKeyCredential(accountName, accountKey);
  const blobServiceClient = new BlobServiceClient(
    `https://${accountName}.blob.${endpointSuffix}`,
    sharedKeyCredential
  );

  const containerClient = blobServiceClient.getContainerClient(containerName);
  const blockBlobClient = containerClient.getBlockBlobClient(blobPath);

  console.log('[uploadAzureDocument] Uploading blobPath:', blobPath);

  await blockBlobClient.uploadData(bytes, {
    blobHTTPHeaders: { blobContentType: contentType }
  });

  console.log('[uploadAzureDocument] Upload successful');

  // Save record in AzureDocument entity
  await sdk.asServiceRole.entities.AzureDocument.create({
    clienteId,
    polizaId,
    carpeta: folder,
    tipoDocumento: docType,
    blobPath,
    nombreOriginal: fileName,
    mimeType: contentType,
    size,
    uploadedBy: user.email
  });

  return Response.json({
    ok: true,
    blobPath,
    fileName,
    contentType,
    size,
    url: blockBlobClient.url
  });
});