import { createClientFromRequest } from '../../runtime/sdk.js';

const PENDING_DAYS = 45;

/**
 * Loads all records from an entity accessor using cursor-based pagination.
 * Sorts ascending by sortField and uses $gt cursor to get subsequent batches.
 */
async function loadAll(entityAccessor, sortField, extraFilter = {}) {
  const all = [];
  let cursor = null;
  let iterations = 0;
  const MAX_ITERATIONS = 200; // safety limit — 200 * 5000 = 1,000,000 records max

  while (iterations < MAX_ITERATIONS) {
    const query = { ...extraFilter };
    if (cursor) query[sortField] = { $gt: cursor };
    const batch = await entityAccessor.filter(query, sortField, 5000);
    all.push(...batch);
    if (batch.length < 5000) break;
    cursor = batch[batch.length - 1][sortField];
    iterations++;
  }
  return all;
}

export default async function(req) {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Verify user has appropriate role to view commission reports
    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const allowedRoles = ['admin', 'gerencial', 'jefatura', 'financiero'];
    if (!userRole || !allowedRoles.includes(userRole.app_role)) {
      return Response.json({ error: 'Forbidden — insufficient permissions' }, { status: 403 });
    }

    // Parse request body for filters
    const body = await req.json().catch(() => ({}));
    const branchFilter = body.branchFilter || 'all';
    const companyFilter = body.companyFilter || 'all';

    // Load all data with pagination (asServiceRole bypasses RLS for full report access)
    const [policiesData, paymentsData, commissionsData, companiesData, branchesData] = await Promise.all([
      loadAll(sdk.asServiceRole.entities.Policy, 'created_date'),
      loadAll(sdk.asServiceRole.entities.Payment, 'due_date'),
      loadAll(sdk.asServiceRole.entities.Commission, 'generation_date'),
      sdk.asServiceRole.entities.InsuranceCompany.list('name', 1000),
      sdk.asServiceRole.entities.Branch.list('name', 100),
    ]);

    // Only active or at-risk policies with agent and company
    const activePolicies = policiesData.filter(
      (p) =>
        (p.status === 'activa' || p.status === 'en_riesgo') &&
        p.agent_id &&
        p.company_id
    );

    // Group ALL base payments by policy_id — payment status is NOT a filter
    const paymentsByPolicy = {};
    paymentsData
      .filter((p) => !p.payment_group || p.payment_group === 'base')
      .forEach((p) => {
        if (!paymentsByPolicy[p.policy_id]) paymentsByPolicy[p.policy_id] = [];
        paymentsByPolicy[p.policy_id].push(p);
      });

    // Build commission lookup: policy_id → Set of installment_numbers
    // Also track if ANY commission exists (for anualizada type)
    const commissionsByPolicy = {};
    const hasAnyCommissionByPolicy = {};
    commissionsData.forEach((c) => {
      if (!commissionsByPolicy[c.policy_id]) commissionsByPolicy[c.policy_id] = new Set();
      if (c.installment_number) commissionsByPolicy[c.policy_id].add(c.installment_number);
      hasAnyCommissionByPolicy[c.policy_id] = true;
    });

    // Apply branch filter via company IDs
    const branchCompanyIds = branchFilter !== 'all'
      ? new Set(companiesData.filter((c) => c.branch_id === branchFilter).map((c) => c.id))
      : null;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const report = [];
    let totalPending = 0;

    for (const policy of activePolicies) {
      // Apply company/branch filters
      if (branchCompanyIds && !branchCompanyIds.has(policy.company_id)) continue;
      if (companyFilter !== 'all' && policy.company_id !== companyFilter) continue;

      const company = companiesData.find((c) => c.id === policy.company_id);
      if (!company) continue;

      // Determine payment type
      const isRenewal = policy.policy_type === 'renovacion';
      const paymentType = isRenewal
        ? (company.renewal_payment_type || 'segun_cliente')
        : (company.new_business_payment_type || 'anualizada');

      const policyCommissionInstallments = commissionsByPolicy[policy.id] || new Set();
      const hasCommission = hasAnyCommissionByPolicy[policy.id] || false;

      const pendingInstallments = [];

      if (paymentType === 'anualizada') {
        // Anualizada: single commission based on emission/renewal date
        // 45 days counted from policy start_date (emisión/renovación), NOT from payment date
        const obligationDateStr = policy.start_date || policy.issue_date;
        if (obligationDateStr) {
          const obligationDate = new Date(obligationDateStr + 'T00:00:00');
          const diffDays = (today - obligationDate) / (1000 * 60 * 60 * 24);
          if (diffDays > PENDING_DAYS && !hasCommission) {
            pendingInstallments.push({
              installment_number: 1,
              due_date: obligationDateStr,
              amount: policy.commissionable_premium || policy.annual_premium || 0,
            });
          }
        }
      } else {
        // Segun_cliente: check each installment (regardless of payment status)
        // 45 days counted from each installment's due_date (fecha de la cuota)
        const policyPayments = (paymentsByPolicy[policy.id] || []).slice().sort(
          (a, b) => (a.installment_number || 0) - (b.installment_number || 0)
        );

        for (const payment of policyPayments) {
          const instNum = payment.installment_number;
          if (!instNum) continue;
          if (policyCommissionInstallments.has(instNum)) continue;
          if (!payment.due_date) continue;

          const dueDate = new Date(payment.due_date + 'T00:00:00');
          const diffDays = (today - dueDate) / (1000 * 60 * 60 * 24);
          if (diffDays <= PENDING_DAYS) continue;

          pendingInstallments.push({
            installment_number: instNum,
            due_date: payment.due_date,
            amount: payment.amount,
          });
        }
      }

      if (pendingInstallments.length > 0) {
        // Oldest pending first
        pendingInstallments.sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
        const oldest = pendingInstallments[0];

        report.push({
          policy_number: policy.policy_number,
          client_name: policy.client_name || policy.contractor_name || '-',
          branch_name: company.branch_name || '-',
          company_name: policy.company_name || company.name,
          issue_date: policy.start_date || policy.issue_date,
          pending_due_date: oldest.due_date,
          pending_installment_number: oldest.installment_number,
          installment_value:
            paymentType === 'anualizada'
              ? (policy.commissionable_premium || policy.annual_premium || 0)
              : (oldest.amount || 0),
          pending_count: pendingInstallments.length,
          currency: policy.currency || 'USD',
        });
        totalPending += pendingInstallments.length;
      }
    }

    // Sort by pending_due_date (oldest first)
    report.sort((a, b) => new Date(a.pending_due_date) - new Date(b.pending_due_date));

    return Response.json({
      report,
      totalPending,
      stats: {
        totalPolicies: activePolicies.length,
        totalPayments: paymentsData.length,
        totalCommissions: commissionsData.length,
      },
    });
  } catch (error) {
    console.error('Error in getPendingCommissionsReport:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}