import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Fetch all users with admin privileges
    const allUsers = await sdk.asServiceRole.entities.User.list();
    
    const userRoles = [];
    for (const u of allUsers) {
      // Get all user data (including custom fields like app_role, agent_id)
      const userData = await sdk.asServiceRole.entities.User.get(u.id);
      
      userRoles.push({
        email: userData.email,
        app_role: userData.app_role || 'agente',
        agent_id: userData.agent_id || null,
        status: userData.status === 'active' ? 'active' : (userData.status === 'pending_activation' ? 'pending_activation' : 'inactive')
      });
    }

    // Bulk create UserRole records
    if (userRoles.length > 0) {
      await sdk.asServiceRole.entities.UserRole.bulkCreate(userRoles);
    }

    return Response.json({
      success: true,
      migratedCount: userRoles.length,
      message: `${userRoles.length} usuarios migrados a UserRole`
    });
  } catch (error) {
    console.error('Migration error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});