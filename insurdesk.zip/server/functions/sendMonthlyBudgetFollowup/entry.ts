import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);

    // Parse body for optional test_email parameter
    let testEmail = null;
    try {
      const body = await req.json();
      testEmail = body?.test_email || null;
    } catch {}

    // Check if automatic emails are enabled (skip in test mode)
    if (!testEmail) {
      const emailSettings = await sdk.asServiceRole.entities.AppSettings.filter({
        setting_key: 'automatic_emails_enabled'
      });
      if (emailSettings.length > 0 && emailSettings[0].setting_value !== 'true') {
        return Response.json({ success: true, message: 'Automatic emails disabled', sent: 0 });
      }
    }

    // Cutoff: last day of previous month
    const now = new Date();
    const cutoff = new Date(now.getFullYear(), now.getMonth(), 0);
    const cutoffStr = cutoff.toISOString().split('T')[0];
    const monthNames = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const cutoffLabel = `${monthNames[cutoff.getMonth()]} ${cutoff.getFullYear()}`;

    // Fetch data
    const [targets, agents, policies] = await Promise.all([
      sdk.asServiceRole.entities.SalesTarget.filter({ status: 'activo' }, '-created_date', 500),
      sdk.asServiceRole.entities.Agent.list('name', 1000),
      sdk.asServiceRole.entities.Policy.list('-start_date', 5000)
    ]);

    if (!targets || targets.length === 0) {
      return Response.json({ success: true, message: 'No active targets', sent: 0 });
    }

    // Helper: get agent structure (downlines) recursively
    function getAgentStructure(agentId, allAgents) {
      const result = [agentId];
      const findDownlines = (id) => {
        allAgents.filter(a => a.upline_agent_id === id).forEach(child => {
          result.push(child.id);
          findDownlines(child.id);
        });
      };
      findDownlines(agentId);
      return result;
    }

    // Helper: calculate target current progress
    function calculateTargetCurrent(target, allPolicies, allAgents) {
      let relevant = allPolicies.filter(p => {
        if (!p.start_date || p.status === 'cancelada') return false;
        if (p.start_date > cutoffStr) return false;
        const d = new Date(p.start_date + 'T00:00:00');
        const start = new Date(target.start_date + 'T00:00:00');
        const end = new Date(target.end_date + 'T00:00:00');
        return d >= start && d <= end;
      });

      if (target.target_type === 'individual') {
        relevant = relevant.filter(p => p.agent_id === target.agent_id);
      } else if (target.target_type === 'structure') {
        const ids = new Set(getAgentStructure(target.agent_id, allAgents));
        relevant = relevant.filter(p => ids.has(p.agent_id));
      }

      if (target.companies && target.companies.length > 0) {
        const ids = new Set(target.companies.map(c => c.company_id));
        relevant = relevant.filter(p => ids.has(p.company_id));
      }

      if (!target.all_lines && target.lines && target.lines.length > 0) {
        const ids = new Set(target.lines.map(l => l.line_id));
        relevant = relevant.filter(p => ids.has(p.line_id));
      }

      const getValue = (p) => {
        switch (target.metric) {
          case 'new_policies': return 1;
          case 'premium_volume': return p.annual_premium || 0;
          case 'commission_value': return p.commissionable_premium || 0;
          default: return 0;
        }
      };

      return relevant.reduce((sum, p) => sum + getValue(p), 0);
    }

    const metricLabel = { new_policies: 'Pólizas', premium_volume: 'Prima', commission_value: 'Comisiones' };
    function fmtValue(val, metric, currency) {
      if (metric === 'new_policies') return Math.round(val).toString();
      return new Intl.NumberFormat('es-EC', { style: 'currency', currency: currency || 'USD', maximumFractionDigits: 0 }).format(val || 0);
    }

    // Resend direct email helper
    async function sendViaResend(toEmail, subject, htmlBody) {
      const apiKey = process.env.RESEND_API_KEY;
      if (!apiKey) throw new Error('RESEND_API_KEY not configured');
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: brand.from(),
          to: [toEmail],
          subject: subject,
          html: htmlBody
        })
      });
      if (!response.ok) {
        const err = await response.text();
        throw new Error(`Resend API (${response.status}): ${err}`);
      }
      return await response.json();
    }

    // Group targets by agent_id
    const targetsByAgent = {};
    targets.forEach(t => {
      if (!t.agent_id) return;
      if (!targetsByAgent[t.agent_id]) targetsByAgent[t.agent_id] = [];
      targetsByAgent[t.agent_id].push(t);
    });

    // In test mode, only send to 10 random agents
    let agentIdsToSend = Object.keys(targetsByAgent);
    if (testEmail) {
      agentIdsToSend = [...agentIdsToSend].sort(() => Math.random() - 0.5).slice(0, 10);
    }

    const appDomain = process.env.APP_DOMAIN;
    const portalLink = appDomain ? (appDomain.startsWith('http') ? appDomain : `https://${appDomain}`) : null;

    let emailsSent = 0;
    const results = [];

    for (const agentId of agentIdsToSend) {
      const agent = agents.find(a => a.id === agentId);
      if (!agent) continue;
      const recipientEmail = testEmail || agent.email;
      if (!recipientEmail) {
        results.push({ agent: agent.name, status: 'skipped', reason: 'No email' });
        continue;
      }

      const agentTargets = targetsByAgent[agentId];
      const rows = agentTargets.map(t => {
        const current = calculateTargetCurrent(t, policies, agents);
        const targetVal = t.target_value || 0;
        const pct = targetVal > 0 ? Math.min(Math.round((current / targetVal) * 100), 100) : 0;
        const missing = Math.max(0, targetVal - current);
        return { t, current, targetVal, pct, missing };
      });

      const rowsHtml = rows.map(r => {
        const pctColor = r.pct >= 100 ? '#10B981' : r.pct >= 70 ? '#3B82F6' : r.pct >= 40 ? '#F59E0B' : '#EF4444';
        const missingStr = r.missing <= 0
          ? '<span style="color: #10B981; font-weight: bold;">✓ Cumplido</span>'
          : fmtValue(r.missing, r.t.metric, r.t.currency);
        return `<tr>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;">
            <div>${r.t.target_type === 'individual' ? 'Individual' : 'Estructura'} · ${metricLabel[r.t.metric] || r.t.metric}</div>
            <div style="font-size: 11px; color: #999; margin-top: 2px;">${(r.t.companies && r.t.companies.length > 0) ? r.t.companies.map(c => c.company_name).join(', ') : 'Todas las compañías'}</div>
          </td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right;">${fmtValue(r.targetVal, r.t.metric, r.t.currency)}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: bold;">${fmtValue(r.current, r.t.metric, r.t.currency)}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: center; color: ${pctColor}; font-weight: bold;">${r.pct}%</td>
          <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right;">${missingStr}</td>
        </tr>`;
      }).join('');

      const subjectPrefix = testEmail ? `[PRUEBA - ${agent.name}] ` : '';
      const htmlBody = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(to right, #001E2E, #004B6F); padding: 20px; border-radius: 8px 8px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 22px;">GA<span style="color: #76DDF9;">Portal</span></h1>
            <p style="color: #76DDF9; margin: 5px 0 0; font-size: 14px;">Resumen Mensual de Presupuestos</p>
          </div>
          <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
            <p style="color: #333; font-size: 16px;">Hola <strong>${agent.name}</strong>,</p>
            <p style="color: #666; font-size: 14px;">Aquí tienes tu resumen de presupuestos con corte al <strong>${cutoffLabel}</strong>:</p>
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 13px;">
              <thead>
                <tr style="background: #004B6F; color: white;">
                  <th style="padding: 10px; text-align: left;">Presupuesto</th>
                  <th style="padding: 10px; text-align: right;">Objetivo</th>
                  <th style="padding: 10px; text-align: right;">Alcanzado</th>
                  <th style="padding: 10px; text-align: center;">%</th>
                  <th style="padding: 10px; text-align: right;">Te falta</th>
                </tr>
              </thead>
              <tbody>${rowsHtml}</tbody>
            </table>
            ${portalLink ? `<p style="text-align: center; margin-top: 20px;"><a href="${portalLink}/SalesTargets" style="background: #004B6F; color: white; padding: 10px 24px; text-decoration: none; border-radius: 6px; font-size: 14px;">Ver detalle en InsurDesk</a></p>` : ''}
            <p style="color: #999; font-size: 12px; text-align: center; margin-top: 20px;">Este es un correo automático generado por InsurDesk.</p>
          </div>
        </div>`;

      try {
        const resendRes = await sendViaResend(recipientEmail, `${subjectPrefix}Resumen Mensual de Presupuestos - ${cutoffLabel}`, htmlBody);

        if (!testEmail) {
          await sdk.asServiceRole.entities.EmailLog.create({
            recipient_email: agent.email,
            recipient_name: agent.name,
            email_type: 'otro',
            subject: `Resumen Mensual de Presupuestos - ${cutoffLabel}`,
            body: htmlBody,
            status: 'enviado',
            related_entity_type: 'SalesTarget',
            related_entity_id: agentId,
            sent_date: new Date().toISOString().split('T')[0]
          });
        }

        emailsSent++;
        results.push({ agent: agent.name, email: recipientEmail, status: 'sent', id: resendRes?.id });
      } catch (error) {
        results.push({ agent: agent.name, email: recipientEmail, status: 'error', error: error.message });
      }
      await new Promise(r => setTimeout(r, 200));
    }

    return Response.json({ success: true, message: 'Budget follow-up sent', emailsSent, cutoff: cutoffLabel, testMode: !!testEmail, results });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});