import { brand } from '../../runtime/brand.js';
import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { info_request_id } = await req.json();
    if (!info_request_id) return Response.json({ error: 'info_request_id requerido' }, { status: 400 });

    const infoReq = await sdk.asServiceRole.entities.AdditionalInfoRequest.filter({ id: info_request_id });
    const request = infoReq[0];
    if (!request) return Response.json({ error: 'Solicitud no encontrada' }, { status: 404 });

    const subject = `Solicitud de Información Adicional - Siniestro ${request.claim_number}`;

    const htmlBody = `
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"/><style>
body { font-family: Arial, sans-serif; color: #1e293b; background: #f8fafc; margin: 0; padding: 0; }
.wrapper { max-width: 600px; margin: 0 auto; background: #fff; }
.header { background: linear-gradient(135deg, #001E2E 0%, #004B6F 60%, #0A8FBE 100%); padding: 28px 32px; color: white; }
.brand { font-size: 22px; font-weight: 800; } .brand span { color: #76DDF9; }
.content { padding: 28px 32px; }
.alert-box { background: #fffbeb; border: 1px solid #fde68a; border-left: 4px solid #f59e0b; border-radius: 8px; padding: 16px; margin: 16px 0; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 16px 0; }
.info-item label { font-size: 11px; color: #64748b; text-transform: uppercase; font-weight: 600; }
.info-item p { font-size: 14px; color: #1e293b; margin: 2px 0 0; font-weight: 500; }
.desc-box { background: #f1f5f9; border-radius: 8px; padding: 14px; font-size: 14px; color: #334155; line-height: 1.6; margin: 16px 0; }
.footer { background: #f8fafc; border-top: 1px solid #e2e8f0; padding: 16px 32px; text-align: center; font-size: 11px; color: #94a3b8; }
</style></head>
<body>
<div class="wrapper">
  <div class="header">
    <div class="brand">GA<span>Portal</span></div>
    <p style="margin:8px 0 0;font-size:13px;color:rgba(255,255,255,0.8)">Solicitud de Información Adicional para Siniestro</p>
  </div>
  <div class="content">
    <p>Estimado/a <strong>${request.client_name || 'Cliente'}</strong>,</p>
    <p style="margin:12px 0;line-height:1.6">Le informamos que la aseguradora ha solicitado información adicional para procesar su siniestro. Por favor, proporcione la documentación indicada a la brevedad posible para continuar con el trámite.</p>
    
    <div class="alert-box">
      <strong>⚠ Acción Requerida</strong><br/>
      Se requiere información adicional para continuar con el procesamiento de su siniestro.
    </div>

    <div class="info-grid">
      <div class="info-item">
        <label>N° Siniestro</label>
        <p>${request.claim_number}</p>
      </div>
      <div class="info-item">
        <label>N° Póliza</label>
        <p>${request.policy_number || '—'}</p>
      </div>
      <div class="info-item">
        <label>Solicitado por</label>
        <p>${request.requested_by}</p>
      </div>
      <div class="info-item">
        <label>Fecha de solicitud</label>
        <p>${request.request_date}</p>
      </div>
      ${request.due_date ? `<div class="info-item">
        <label>Fecha límite</label>
        <p style="color:#dc2626;font-weight:700">${request.due_date}</p>
      </div>` : ''}
    </div>

    <p style="font-size:13px;font-weight:600;color:#475569;margin:16px 0 6px">Información solicitada:</p>
    <div class="desc-box">${request.description}</div>

    ${request.notes ? `<p style="font-size:13px;color:#64748b;margin-top:12px"><strong>Notas:</strong> ${request.notes}</p>` : ''}

    <p style="margin-top:20px;line-height:1.6;font-size:13px;color:#475569">
      Su agente de seguros, <strong>${request.agent_name || 'su agente'}</strong>, está en copia de este correo y puede asistirle en la recopilación de la información requerida.
    </p>
    <p style="margin-top:12px;line-height:1.6;font-size:13px;color:#475569">
      Una vez que tenga la información, comuníquese con su agente para coordinar la entrega.
    </p>
  </div>
  <div class="footer">
    <p><strong>InsurDesk</strong> — Sistema de Gestión de Seguros</p>
    <p>Este es un mensaje automático del sistema. Por favor no responda directamente a este correo.</p>
  </div>
</div>
</body></html>`;

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) return Response.json({ error: 'RESEND_API_KEY not configured' }, { status: 500 });

    const results = [];

    // Send to client
    if (request.client_email) {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: brand.from('Siniestros'),
          to: [request.client_email],
          cc: request.agent_email && request.agent_email !== request.client_email ? [request.agent_email] : undefined,
          subject,
          html: htmlBody
        })
      });
      if (!res.ok) throw new Error(`Resend error: ${res.status} ${await res.text()}`);
      results.push(`Cliente: ${request.client_email}`);
    }

    // CC to agent (separate email if no client email or same)
    if (request.agent_email && request.agent_email !== request.client_email && !request.client_email) {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: brand.from('Siniestros'),
          to: [request.agent_email],
          subject: `[Copia] ${subject}`,
          html: htmlBody
        })
      });
      if (!res.ok) throw new Error(`Resend error: ${res.status} ${await res.text()}`);
      results.push(`Agente: ${request.agent_email}`);
    }

    return Response.json({ success: true, sent_to: results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});