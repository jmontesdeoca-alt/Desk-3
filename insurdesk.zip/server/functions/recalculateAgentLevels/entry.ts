import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event } = payload;
    
    // Solo procesar actualizaciones
    if (event.type !== 'update') {
      return Response.json({ success: true, message: 'No action needed' });
    }
    
    const agentId = event.entity_id;
    
    // Obtener todos los agentes usando service role
    const allAgents = await sdk.asServiceRole.entities.Agent.list();
    
    // Crear mapa de agentes para búsqueda rápida
    const agentsMap = new Map(allAgents.map(a => [a.id, a]));
    
    // Función para calcular el nivel de un agente
    const calculateLevel = (agentId, visited = new Set()) => {
      // Prevenir ciclos infinitos
      if (visited.has(agentId)) {
        return 1;
      }
      visited.add(agentId);
      
      const agent = agentsMap.get(agentId);
      if (!agent || !agent.upline_agent_id) {
        return 1; // Nivel base
      }
      
      return calculateLevel(agent.upline_agent_id, visited) + 1;
    };
    
    // Función para obtener todos los descendientes de un agente
    const getDescendants = (agentId) => {
      const descendants = [];
      const findChildren = (id) => {
        const children = allAgents.filter(a => a.upline_agent_id === id);
        children.forEach(child => {
          descendants.push(child);
          findChildren(child.id);
        });
      };
      findChildren(agentId);
      return descendants;
    };
    
    // Obtener el agente actualizado y todos sus descendientes
    const updatedAgent = agentsMap.get(agentId);
    if (!updatedAgent) {
      return Response.json({ 
        success: false, 
        error: 'Agent not found' 
      }, { status: 404 });
    }
    
    const descendantsToUpdate = getDescendants(agentId);
    
    // Agregar el agente actualizado a la lista
    const agentsToUpdate = [updatedAgent, ...descendantsToUpdate];
    
    // Recalcular niveles y actualizar
    const updates = [];
    for (const agent of agentsToUpdate) {
      const newLevel = calculateLevel(agent.id);
      
      if (agent.level !== newLevel) {
        updates.push({
          id: agent.id,
          name: agent.name,
          oldLevel: agent.level,
          newLevel: newLevel
        });
        
        await sdk.asServiceRole.entities.Agent.update(agent.id, {
          level: newLevel
        });
      }
    }
    
    return Response.json({ 
      success: true, 
      message: `Recalculados ${updates.length} niveles`,
      updates: updates
    });
    
  } catch (error) {
    console.error('Error recalculating agent levels:', error);
    return Response.json({ 
      success: false, 
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});