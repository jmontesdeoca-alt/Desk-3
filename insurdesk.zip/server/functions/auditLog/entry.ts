import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    
    const payload = await req.json();
    const { event, data, old_data } = payload;

    // Para CREATE: el created_by es el usuario que creó el registro.
    // Para UPDATE: el created_by es el CREADOR ORIGINAL, no quien actualizó.
    //   Usamos data.updated_by si existe (campo explícito), si no, marcamos como sistema.
    let userEmail = 'sistema';
    if (event.type === 'create') {
      userEmail = data?.created_by || 'sistema';
    } else if (event.type === 'update') {
      // updated_by es un campo que el frontend puede haber seteado explícitamente
      userEmail = data?.updated_by || 'sistema (actualización automática)';
    } else if (event.type === 'delete') {
      userEmail = old_data?.created_by || 'sistema';
    }

    // Build changes object for updates
    let changes = null;
    if (event.type === 'update' && old_data && data) {
      changes = {};
      for (const key in data) {
        if (data[key] !== old_data[key]) {
          changes[key] = {
            old: old_data[key],
            new: data[key]
          };
        }
      }
    }

    // Build details string
    let details = `${event.type.toUpperCase()}: ${event.entity_name}`;
    if (data?.name) details += ` - ${data.name}`;
    if (data?.policy_number) details += ` - ${data.policy_number}`;
    if (data?.client_name) details += ` - ${data.client_name}`;

    // Create audit log entry
    await sdk.asServiceRole.entities.AuditLog.create({
      user_email: userEmail,
      action: event.type.toUpperCase(),
      entity_type: event.entity_name,
      entity_id: event.entity_id,
      details: details,
      changes: changes,
      ip_address: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown'
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Audit log error:', error);
    return Response.json({ 
      success: false, 
      error: error.message 
    }, { status: 500 });
  }
});