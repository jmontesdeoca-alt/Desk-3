import { createClientFromRequest } from '../../runtime/sdk.js';

export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: 'No autenticado' }, { status: 401 });
    }

    const { policy_id } = await req.json();
    if (!policy_id) {
      return Response.json({ error: 'policy_id requerido' }, { status: 400 });
    }

    // Get user role info
    const userRoles = await sdk.asServiceRole.entities.UserRole.filter({ email: user.email });
    const userRole = userRoles[0];
    const appRole = userRole?.app_role;

    // Non-agents: fetch directly with service role
    if (appRole !== 'agente') {
      const allPolicies = await sdk.asServiceRole.entities.Policy.filter({ id: policy_id });
      const policy = allPolicies[0];
      if (!policy) return Response.json({ error: 'Póliza no encontrada' }, { status: 404 });
      return Response.json({ policy });
    }

    // Agente: must verify the policy belongs to their hierarchy
    const agentId = userRole?.agent_id;
    if (!agentId) {
      return Response.json({ error: 'Agente no vinculado' }, { status: 403 });
    }

    // Build full downline hierarchy
    const allAgents = await sdk.asServiceRole.entities.Agent.list();
    const hierarchyIds = new Set();
    const findSubordinates = (currentId) => {
      hierarchyIds.add(currentId);
      allAgents
        .filter(a => a.upline_agent_id === currentId)
        .forEach(a => findSubordinates(a.id));
    };
    findSubordinates(agentId);

    // Fetch the policy with service role
    const allPolicies = await sdk.asServiceRole.entities.Policy.filter({ id: policy_id });
    const policy = allPolicies[0];
    if (!policy) return Response.json({ error: 'Póliza no encontrada' }, { status: 404 });

    // Verify the policy's agent is within the hierarchy
    if (!hierarchyIds.has(policy.agent_id)) {
      return Response.json({ error: 'Sin acceso a esta póliza' }, { status: 403 });
    }

    return Response.json({ policy });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});