// Herramientas de IA del módulo CRM (solo lectura + control de acceso por rol).
// El módulo IA no conoce leads: simplemente ofrece al asistente lo que cada módulo registra.
import { store } from '../../runtime/crm-db.js';

const privileged = (u) => u.role === 'admin' || u.crm_role === 'admin_crm' || u.crm_role === 'jefatura_crm';

const leadBrief = (l) => ({
  id: l.id, external_id: l.external_id, prospect_name: l.prospect_name, branch: l.branch,
  pipeline: l.pipeline_name, stage: l.pipeline_stage, status: l.lead_status, agent: l.assigned_agent_name,
  premium_estimated: l.premium_estimated, currency: l.currency, company: l.company_name, product: l.product_name,
  last_activity_at: l.last_activity_at, created_date: l.created_date, notes: (l.notes || '').slice(0, 500),
});

function canSeeLead(user, lead) {
  return !!lead && (privileged(user) || lead.assigned_agent_id === user.id);
}

export const TOOLS = [
  {
    name: 'buscar_leads',
    description: 'Busca leads del CRM. Filtros opcionales por estado, etapa o texto en el nombre del prospecto.',
    input_schema: { type: 'object', properties: {
      texto: { type: 'string', description: 'Texto a buscar en el nombre del prospecto' },
      lead_status: { type: 'string', enum: ['ACTIVO', 'ARCHIVADO', 'ABANDONADO'] },
      pipeline_stage: { type: 'string', description: 'Clave de la etapa del pipeline' },
      limite: { type: 'number', description: 'Máximo de resultados (por defecto 20, máx 50)' },
    } },
  },
  {
    name: 'obtener_lead',
    description: 'Obtiene el detalle de un lead por su ID.',
    input_schema: { type: 'object', properties: { lead_id: { type: 'string' } }, required: ['lead_id'] },
  },
  {
    name: 'actividades_lead',
    description: 'Lista las actividades recientes (llamadas, notas, correos, etc.) de un lead.',
    input_schema: { type: 'object', properties: { lead_id: { type: 'string' }, limite: { type: 'number' } }, required: ['lead_id'] },
  },
  {
    name: 'recordatorios',
    description: 'Lista recordatorios de seguimiento pendientes (propios; si eres admin/jefatura, de todos). Puede filtrarse por lead.',
    input_schema: { type: 'object', properties: { lead_id: { type: 'string' }, status: { type: 'string' } } },
  },
  {
    name: 'obtener_prospecto',
    description: 'Obtiene los datos de contacto de un prospecto por su ID.',
    input_schema: { type: 'object', properties: { prospect_id: { type: 'string' } }, required: ['prospect_id'] },
  },
];


export function runTool(name, input, user) {
  const lim = (n, d = 20) => Math.min(Math.max(parseInt(n, 10) || d, 1), 50);
  switch (name) {
    case 'buscar_leads': {
      const q = {};
      if (!privileged(user)) q.assigned_agent_id = user.id;
      if (input.lead_status) q.lead_status = input.lead_status;
      if (input.pipeline_stage) q.pipeline_stage = input.pipeline_stage;
      if (input.texto) q.prospect_name = { $regex: input.texto };
      return store.filter('Lead', q, '-last_activity_at', lim(input.limite)).map(leadBrief);
    }
    case 'obtener_lead': {
      const l = store.get('Lead', input.lead_id);
      return canSeeLead(user, l) ? leadBrief(l) : { error: 'No tienes acceso a ese lead o no existe.' };
    }
    case 'actividades_lead': {
      const l = store.get('Lead', input.lead_id);
      if (!canSeeLead(user, l)) return { error: 'No tienes acceso a ese lead o no existe.' };
      return store.filter('LeadActivity', { lead_id: l.id }, '-created_date', lim(input.limite, 15)).map((a) => ({
        tipo: a.activity_type, descripcion: (a.description || '').slice(0, 400), fecha: a.created_date, por: a.created_by_name,
      }));
    }
    case 'recordatorios': {
      const q = {};
      if (!privileged(user)) q.assigned_to_id = user.id;
      if (input.status) q.status = input.status; else q.status = 'pendiente';
      if (input.lead_id) {
        const l = store.get('Lead', input.lead_id);
        if (!canSeeLead(user, l)) return { error: 'No tienes acceso a ese lead o no existe.' };
        q.lead_id = l.id;
      }
      return store.filter('FollowUpReminder', q, 'reminder_date', 30);
    }
    case 'obtener_prospecto': {
      const p = store.get('Prospect', input.prospect_id);
      if (!p) return { error: 'Prospecto no encontrado.' };
      if (!privileged(user) && p.assigned_agent_id !== user.id) {
        const mine = store.filter('Lead', { prospect_id: p.id, assigned_agent_id: user.id }, undefined, 1);
        if (!mine.length) return { error: 'No tienes acceso a ese prospecto.' };
      }
      const { id, full_name, email, phone, city, country, source, tags, notes } = p;
      return { id, full_name, email, phone, city, country, source, tags, notes: (notes || '').slice(0, 500) };
    }
    default:
      return { error: `Herramienta desconocida: ${name}` };
  }
}

