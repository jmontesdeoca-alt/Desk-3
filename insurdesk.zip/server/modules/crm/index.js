// Módulo CRM base: lo único que registra hacia afuera son las herramientas de IA sobre leads y prospectos.
import { TOOLS, runTool } from './ai-tools.js';

export function register(ctx) {
  for (const tool of TOOLS) ctx.ai.registerTool({ ...tool, run: (input, user) => runTool(tool.name, input, user) });
}
