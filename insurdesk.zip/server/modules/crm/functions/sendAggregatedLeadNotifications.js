import { brand } from '../../../runtime/brand.js';
// Portado de sdk/functions/sendAggregatedLeadNotifications/entry.ts
import { config } from "../../../src/config.js";
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { Resend } from "../../../runtime/resend-compat.js";
const resend = new Resend(process.env.RESEND_API_KEY);
function buildEmailHtml(agentName, leads) {
  const leadsRows = leads.map((lead, i) => `
    <tr style="background: ${i % 2 === 0 ? "#f8fafc" : "#ffffff"};">
      <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0; font-weight: 600; color: #1e293b;">
        ${lead.prospect_name || "-"}
      </td>
      <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0; color: #475569;">
        ${lead.pipeline_name || "-"}
      </td>
      <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0; color: #475569;">
        ${lead.branch || "-"}
      </td>
      <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0; color: #475569; font-size: 13px;">
        ${lead.assigned_by_name || "-"}
      </td>
      <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0; color: #94a3b8; font-size: 12px;">
        ${lead.lead_external_id || lead.lead_id?.slice(-6)?.toUpperCase() || "-"}
      </td>
    </tr>
  `).join("");
  return `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Nuevos Leads Asignados</title>
</head>
<body style="margin:0; padding:0; background-color:#f1f5f9; font-family: Arial, Helvetica, sans-serif;">

  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="620" cellpadding="0" cellspacing="0" style="max-width:620px; width:100%;">

          <!-- HEADER -->
          <tr>
            <td style="background: #171C28; border-radius: 12px 12px 0 0; padding: 32px 40px; text-align: center;">
              <div style="display:inline-flex; align-items:center; gap:10px; justify-content:center;">
                <img src="${config.appUrl}/logo.svg" alt="GA" style="height:40px; width:40px; object-fit:contain;" />
                <span style="font-size: 28px; font-weight: 900; letter-spacing: -0.5px; font-family: Arial, sans-serif;">
                  <span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span>
                </span>
              </div>
              <div style="margin-top: 8px; color: #9DB1E3; font-size: 13px; letter-spacing: 2px; text-transform: uppercase; font-weight: 500;">
                Sistema de Gestión de Leads
              </div>
              <h1 style="color: #ffffff; font-size: 20px; margin: 20px 0 0; font-weight: 700;">
                Nuevos Leads Asignados
              </h1>
            </td>
          </tr>

          <!-- BODY -->
          <tr>
            <td style="background: #ffffff; padding: 36px 40px;">

              <p style="color: #334155; font-size: 15px; margin: 0 0 8px;">
                Hola <strong>${agentName || "Agente"}</strong>,
              </p>
              <p style="color: #64748b; font-size: 14px; margin: 0 0 28px; line-height: 1.6;">
                En las últimas horas se te han asignado <strong>${leads.length} lead${leads.length > 1 ? "s" : ""}</strong>. 
                Accede al CRM para revisar los detalles y comenzar el seguimiento.
              </p>

              <!-- TABLA DE LEADS -->
              <table width="100%" cellpadding="0" cellspacing="0" style="border-radius: 8px; overflow: hidden; border: 1px solid #e2e8f0;">
                <thead>
                  <tr style="background: #171C28;">
                    <th style="padding: 12px 16px; text-align: left; color: #9DB1E3; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Prospecto</th>
                    <th style="padding: 12px 16px; text-align: left; color: #9DB1E3; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Pipeline</th>
                    <th style="padding: 12px 16px; text-align: left; color: #9DB1E3; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Ramo</th>
                    <th style="padding: 12px 16px; text-align: left; color: #9DB1E3; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Asignado por</th>
                    <th style="padding: 12px 16px; text-align: left; color: #9DB1E3; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">ID</th>
                  </tr>
                </thead>
                <tbody>
                  ${leadsRows}
                </tbody>
              </table>

              <!-- CTA -->
              <div style="text-align: center; margin-top: 32px;">
                <a href="${config.appUrl}" 
                   style="display: inline-block; background: #2F4F9D; color: #ffffff; text-decoration: none; padding: 14px 36px; border-radius: 8px; font-weight: 700; font-size: 14px; letter-spacing: 0.3px;">
                  Ver mis Leads en el CRM →
                </a>
              </div>

            </td>
          </tr>

          <!-- FOOTER -->
          <tr>
            <td style="background: #f8fafc; border-top: 1px solid #e2e8f0; border-radius: 0 0 12px 12px; padding: 20px 40px; text-align: center;">
              <p style="color: #94a3b8; font-size: 12px; margin: 0; line-height: 1.6;">
                Este es un correo automático generado por <strong>InsurDesk</strong>.<br/>
                Por favor no respondas a este mensaje.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>
  `;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const pending = await sdk.asServiceRole.entities.LeadAssignmentNotification.filter({ processed: false });
    if (!pending || pending.length === 0) {
      console.log("No hay notificaciones pendientes de enviar.");
      return Response.json({ success: true, sent: 0, message: "Sin pendientes" });
    }
    console.log(`Procesando ${pending.length} notificaciones pendientes...`);
    const byAgent = {};
    for (const notif of pending) {
      const key = notif.assigned_agent_id;
      if (!byAgent[key]) {
        byAgent[key] = {
          agent_id: notif.assigned_agent_id,
          agent_name: notif.assigned_agent_name,
          agent_email: notif.assigned_agent_email,
          leads: [],
          notif_ids: []
        };
      }
      byAgent[key].leads.push({
        lead_id: notif.lead_id,
        lead_external_id: notif.lead_external_id,
        prospect_name: notif.prospect_name,
        pipeline_name: notif.pipeline_name,
        branch: notif.branch,
        assigned_by_name: notif.assigned_by_name
      });
      byAgent[key].notif_ids.push(notif.id);
    }
    let emailsSent = 0;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    for (const agentData of Object.values(byAgent)) {
      if (!agentData.agent_email) continue;
      const subject = agentData.leads.length === 1 ? `Nuevo lead asignado: ${agentData.leads[0].prospect_name || "Sin nombre"}` : `${agentData.leads.length} nuevos leads asignados a tu cuenta`;
      const htmlBody = buildEmailHtml(agentData.agent_name, agentData.leads);
      const { error } = await resend.emails.send({
        from: brand.from(),
        to: agentData.agent_email,
        subject,
        html: htmlBody
      });
      if (error) {
        console.error(`Error enviando correo a ${agentData.agent_email}:`, error);
        continue;
      }
      console.log(`Correo enviado a ${agentData.agent_email} con ${agentData.leads.length} lead(s).`);
      emailsSent++;
      for (const notifId of agentData.notif_ids) {
        await sdk.asServiceRole.entities.LeadAssignmentNotification.update(notifId, {
          processed: true,
          processed_at: now
        });
      }
    }
    return Response.json({ success: true, sent: emailsSent, total_leads: pending.length });
  } catch (error) {
    console.error("Error en sendAggregatedLeadNotifications:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
