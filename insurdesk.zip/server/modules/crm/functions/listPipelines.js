// Portado de sdk/functions/listPipelines/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const pipelines = await sdk.asServiceRole.entities.Pipeline.filter({ is_active: true }, "sort_order", 100);
    return Response.json({ pipelines });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
