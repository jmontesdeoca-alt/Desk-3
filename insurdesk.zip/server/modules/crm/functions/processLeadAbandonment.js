// Portado de sdk/functions/processLeadAbandonment/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const rules = await sdk.asServiceRole.entities.AutomationRule.filter({
      is_active: true,
      rule_type: "abandon_inactive_leads"
    });
    if (rules.length === 0) {
      return Response.json({
        message: "No hay reglas activas",
        processed: 0
      });
    }
    let totalProcessed = 0;
    for (const rule of rules) {
      const leads = await sdk.asServiceRole.entities.Lead.filter({
        lead_status: "ACTIVO"
      });
      const excludeStages = rule.exclude_stages ? rule.exclude_stages.split(",").map((s) => s.trim()) : ["GANADO", "PERDIDO"];
      const now = /* @__PURE__ */ new Date();
      const inactivityThreshold = new Date(now.getTime() - rule.inactivity_days * 24 * 60 * 60 * 1e3);
      for (const lead of leads) {
        if (excludeStages.includes(lead.pipeline_stage)) {
          continue;
        }
        const lastActivity = lead.last_activity_at ? new Date(lead.last_activity_at) : new Date(lead.created_date);
        if (lastActivity < inactivityThreshold) {
          await sdk.asServiceRole.entities.Lead.update(lead.id, {
            lead_status: "ABANDONADO",
            notes: (lead.notes || "") + `
[Sistema] Abandonado automáticamente por inactividad de ${rule.inactivity_days} días el ${now.toLocaleString("es-ES")}`
          });
          totalProcessed++;
        }
      }
    }
    return Response.json({
      message: `Procesados ${totalProcessed} leads`,
      processed: totalProcessed,
      rules_applied: rules.length
    });
  } catch (error) {
    console.error("Error processing lead abandonment:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
