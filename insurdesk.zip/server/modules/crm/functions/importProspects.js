// Portado de sdk/functions/importProspects/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { parsePhoneNumber, isValidPhoneNumber } from "libphonenumber-js";
export default (async (req) => {
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const body = await req.json();
    const { rows, mapping, options } = body;
    if (!rows || !Array.isArray(rows) || rows.length === 0) {
      return Response.json({ error: "No rows provided" }, { status: 400 });
    }
    const agentList = options?.agent_ids && options.agent_ids.length > 0 ? options.agent_ids.map((id, i) => ({ id, name: (options.agent_names || [])[i] || "" })) : [{ id: options?.agent_id || user.id, name: options?.agent_name || user.full_name }];
    const createLeads = !!options?.create_leads;
    const tags = options?.tags || [];
    const skipHistory = !!options?.skip_history;
    const rrOffset = options?.rr_offset || 0;
    const results = { created: 0, leads_created: 0, skipped: 0, errors: [], failed_rows: [], prospect_ids: [], lead_ids: [] };
    const getValue = (row, fieldKey) => {
      const col = mapping?.[fieldKey];
      if (col && row[col] !== void 0 && row[col] !== "") return String(row[col]).trim();
      return "";
    };
    const COUNTRY_ISO = {
      "Ecuador": "EC",
      "Colombia": "CO",
      "Perú": "PE",
      "Peru": "PE",
      "México": "MX",
      "Mexico": "MX",
      "Argentina": "AR",
      "Chile": "CL",
      "Venezuela": "VE",
      "Bolivia": "BO",
      "Paraguay": "PY",
      "Uruguay": "UY",
      "Costa Rica": "CR",
      "Panamá": "PA",
      "Panama": "PA",
      "Guatemala": "GT",
      "Honduras": "HN",
      "El Salvador": "SV",
      "Nicaragua": "NI",
      "República Dominicana": "DO",
      "Cuba": "CU",
      "Puerto Rico": "PR",
      "Estados Unidos": "US",
      "USA": "US",
      "España": "ES",
      "Canada": "CA",
      "Canadá": "CA",
      "Brasil": "BR",
      "Brazil": "BR",
      "Alemania": "DE",
      "Francia": "FR",
      "Italia": "IT",
      "Reino Unido": "GB",
      "Portugal": "PT"
    };
    const COUNTRY_NAMES = Object.fromEntries(Object.entries(COUNTRY_ISO).map(([name, iso]) => [iso, name]));
    const parsePhone = (raw, countryHint = "") => {
      if (!raw) return { normalized: "", country: "" };
      const isoHint = COUNTRY_ISO[countryHint] || null;
      if (raw.startsWith("+")) {
        try {
          if (isValidPhoneNumber(raw)) {
            const parsed = parsePhoneNumber(raw);
            const iso = parsed.country || isoHint || "";
            return { normalized: parsed.format("E.164"), country: COUNTRY_NAMES[iso] || countryHint };
          }
        } catch (_) {
        }
        return { normalized: raw, country: countryHint };
      }
      if (isoHint) {
        try {
          const parsed = parsePhoneNumber(raw, isoHint);
          if (parsed.isValid()) return { normalized: parsed.format("E.164"), country: countryHint };
        } catch (_) {
        }
      }
      const withPlus = `+${raw}`;
      try {
        if (isValidPhoneNumber(withPlus)) {
          const parsed = parsePhoneNumber(withPlus);
          const iso = parsed.country || "";
          return { normalized: parsed.format("E.164"), country: COUNTRY_NAMES[iso] || countryHint };
        }
      } catch (_) {
      }
      return { normalized: raw, country: countryHint };
    };
    let rrIndex = rrOffset;
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    const parseBirthDate = (raw) => {
      if (!raw) return void 0;
      const n = Number(raw);
      if (!isNaN(n) && n > 100) {
        const d2 = new Date(Math.round((n - 25569) * 86400 * 1e3));
        if (!isNaN(d2)) return d2.toISOString().split("T")[0];
      }
      const d = new Date(raw);
      if (!isNaN(d)) return d.toISOString().split("T")[0];
      return void 0;
    };
    const processRow = async (row) => {
      const fullName = getValue(row, "full_name");
      const email = getValue(row, "email");
      if (!fullName && !email) {
        results.skipped++;
        return;
      }
      const agent = agentList[rrIndex % agentList.length];
      rrIndex++;
      const explicitCountry = getValue(row, "country");
      const rawPhone = getValue(row, "phone");
      const parsedPhone = parsePhone(rawPhone, explicitCountry);
      const prospectData = {
        full_name: fullName || email,
        email,
        phone: parsedPhone.normalized,
        phone_secondary: getValue(row, "phone_secondary"),
        country: explicitCountry || parsedPhone.country,
        state: getValue(row, "state"),
        city: getValue(row, "city"),
        address: getValue(row, "address"),
        id_type: getValue(row, "id_type") || void 0,
        id_number: getValue(row, "id_number"),
        birth_date: parseBirthDate(getValue(row, "birth_date")),
        sex: getValue(row, "sex") || void 0,
        marital_status: getValue(row, "marital_status") || void 0,
        occupation: getValue(row, "occupation"),
        nationality: getValue(row, "nationality"),
        source: "manual",
        source_channel: getValue(row, "source_channel") || "importacion_excel",
        notes: getValue(row, "notes"),
        assigned_agent_id: agent.id,
        assigned_agent_name: agent.name
      };
      Object.keys(prospectData).forEach((k) => {
        if (prospectData[k] === "") prospectData[k] = void 0;
      });
      let prospect;
      try {
        prospect = await sdk.asServiceRole.entities.Prospect.create(prospectData);
        results.created++;
        results.prospect_ids.push(prospect.id);
      } catch (e) {
        results.errors.push(`Fila "${fullName || email}": ${e.message}`);
        results.failed_rows.push(row);
        return;
      }
      if (createLeads && prospect?.id) {
        try {
          const lead = await sdk.asServiceRole.entities.Lead.create({
            prospect_id: prospect.id,
            prospect_name: prospect.full_name,
            assigned_agent_id: agent.id,
            assigned_agent_name: agent.name,
            pipeline_id: options.pipeline_id,
            pipeline_name: options.pipeline_name || "",
            pipeline_stage: options.pipeline_stage,
            branch: options.branch || "General",
            premium_estimated: 0,
            lead_status: "ACTIVO",
            source: "manual",
            tags
          });
          results.leads_created++;
          results.lead_ids.push(lead.id);
        } catch (e) {
          results.errors.push(`Lead para "${prospect.full_name}": ${e.message}`);
        }
      }
    };
    const ROW_DELAY_MS = 150;
    for (let i = 0; i < rows.length; i++) {
      await processRow(rows[i]);
      if (i < rows.length - 1) {
        await sleep(ROW_DELAY_MS);
      }
    }
    if (!skipHistory) {
      const totalCreated = (options?.accumulated_created || 0) + results.created;
      const totalLeads = (options?.accumulated_leads || 0) + results.leads_created;
      const allProspectIds = [...options?.accumulated_prospect_ids || [], ...results.prospect_ids];
      const allLeadIds = [...options?.accumulated_lead_ids || [], ...results.lead_ids];
      const status = results.errors.length === 0 ? "success" : totalCreated > 0 ? "partial" : "failed";
      await sdk.asServiceRole.entities.ImportHistory.create({
        file_name: options?.file_name || "archivo_importado",
        imported_by_id: user.id,
        imported_by_name: user.full_name,
        prospects_created: totalCreated,
        leads_created: totalLeads,
        skipped: results.skipped,
        errors_count: results.errors.length,
        status,
        prospect_ids: allProspectIds,
        lead_ids: allLeadIds,
        assigned_agent_ids: agentList.map((a) => a.id),
        assigned_agent_names: agentList.map((a) => a.name),
        pipeline_name: options?.pipeline_name || "",
        reverted: false
      });
    }
    return Response.json({ success: true, ...results, rr_offset: rrIndex }, { status: 200 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
