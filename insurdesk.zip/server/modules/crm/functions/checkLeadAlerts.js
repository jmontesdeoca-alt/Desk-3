// Portado de sdk/functions/checkLeadAlerts/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const INACTIVITY_DAYS = 3;
    const now = /* @__PURE__ */ new Date();
    const [activeLeads, allPipelines] = await Promise.all([
      sdk.asServiceRole.entities.Lead.filter({ lead_status: "ACTIVO" }),
      sdk.asServiceRole.entities.Pipeline.list()
    ]);
    const pipelineStageMap = {};
    for (const pipeline of allPipelines) {
      pipelineStageMap[pipeline.id] = {};
      for (const stage of pipeline.stages || []) {
        pipelineStageMap[pipeline.id][stage.key] = stage;
      }
    }
    const inactivityThreshold = new Date(now.getTime() - INACTIVITY_DAYS * 24 * 60 * 60 * 1e3);
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1e3);
    const recentInactivityNotifs = await sdk.asServiceRole.entities.Notification.filter({
      type: "reminder"
    });
    const inactivityNotifByLead = {};
    for (const n of recentInactivityNotifs) {
      if (n.title && n.title.includes("sin actividad") && n.lead_id) {
        const existing = inactivityNotifByLead[n.lead_id];
        if (!existing || new Date(n.created_date) > new Date(existing.created_date)) {
          inactivityNotifByLead[n.lead_id] = n;
        }
      }
    }
    let inactivityAlerts = 0;
    for (const lead of activeLeads) {
      if (!lead.assigned_agent_id) continue;
      const pipelineStages = pipelineStageMap[lead.pipeline_id] || {};
      const currentStage = pipelineStages[lead.pipeline_stage] || {};
      if (currentStage.is_won || currentStage.is_lost) continue;
      const terminalStages = ["GANADO", "PERDIDO", "ganado", "perdido"];
      if (terminalStages.some((s) => (lead.pipeline_stage || "").toLowerCase() === s.toLowerCase())) continue;
      const lastActivity = lead.last_activity_at ? new Date(lead.last_activity_at) : new Date(lead.created_date);
      if (lastActivity >= inactivityThreshold) continue;
      const lastNotif = inactivityNotifByLead[lead.id];
      if (lastNotif && new Date(lastNotif.created_date) > yesterday) continue;
      const daysInactive = Math.floor((now - lastActivity) / (24 * 60 * 60 * 1e3));
      await sdk.asServiceRole.entities.Notification.create({
        user_id: lead.assigned_agent_id,
        type: "reminder",
        title: `⚠️ Lead sin actividad (${daysInactive} días)`,
        message: `El lead de ${lead.prospect_name || "prospecto"} lleva ${daysInactive} días sin actividad. Etapa: ${lead.pipeline_stage || "—"}.`,
        lead_id: lead.id,
        read: false
      });
      inactivityAlerts++;
    }
    const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1e3);
    const pendingReminders = await sdk.asServiceRole.entities.FollowUpReminder.filter({
      status: "pendiente"
    });
    const reminderNotifs = await sdk.asServiceRole.entities.Notification.filter({
      type: "reminder"
    });
    const reminderNotifByReminderId = /* @__PURE__ */ new Set();
    for (const n of reminderNotifs) {
      if (n.title && n.title.includes("Recordatorio próximo") && n.lead_id && new Date(n.created_date) > yesterday) {
        reminderNotifByReminderId.add(n.lead_id + "_reminder");
      }
    }
    let reminderAlerts = 0;
    for (const reminder of pendingReminders) {
      if (!reminder.assigned_to_id || !reminder.reminder_date) continue;
      const reminderDate = new Date(reminder.reminder_date);
      if (reminderDate < now || reminderDate > in24h) continue;
      const key = reminder.lead_id + "_reminder";
      if (reminderNotifByReminderId.has(key)) continue;
      const hoursLeft = Math.round((reminderDate - now) / (60 * 60 * 1e3));
      const timeLabel = hoursLeft <= 1 ? "menos de 1 hora" : `${hoursLeft} horas`;
      await sdk.asServiceRole.entities.Notification.create({
        user_id: reminder.assigned_to_id,
        type: "reminder",
        title: `🔔 Recordatorio próximo (en ${timeLabel})`,
        message: `${reminder.reminder_type === "seguimiento" ? "Seguimiento" : reminder.reminder_type} con ${reminder.prospect_name || reminder.lead_name || "prospecto"}: ${reminder.description || "—"}`,
        lead_id: reminder.lead_id,
        read: false
      });
      reminderAlerts++;
    }
    return Response.json({
      success: true,
      inactivity_alerts: inactivityAlerts,
      reminder_alerts: reminderAlerts,
      checked_at: now.toISOString()
    });
  } catch (error) {
    console.error("checkLeadAlerts error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
