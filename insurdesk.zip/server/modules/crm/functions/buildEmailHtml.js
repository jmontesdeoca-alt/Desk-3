// Portado de sdk/functions/buildEmailHtml/entry.ts
import { config } from "../../../src/config.js";
import { createClientFromRequest } from "../../../runtime/sdk.js";
function buildHtmlEmail({ body, senderName, senderEmail, senderPhone, senderJobTitle, attachments }) {
  const bodyHtml = body.split("\n").map((line) => line.trim() === "" ? "<br/>" : `<p style="margin:0 0 12px 0;color:#1e293b;font-size:15px;line-height:1.6;">${line}</p>`).join("");
  const attachmentsHtml = attachments && attachments.length > 0 ? `<div style="margin-top:24px;padding-top:16px;border-top:1px solid #e2e8f0;">
        <p style="margin:0 0 8px 0;font-size:13px;color:#64748b;font-weight:600;">ARCHIVOS ADJUNTOS</p>
        ${attachments.map((a) => `<a href="${a.url}" style="display:block;font-size:13px;color:#2F4F9D;text-decoration:none;margin-bottom:4px;">📎 ${a.name}</a>`).join("")}
       </div>` : "";
  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
</head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:32px 16px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
          <tr>
            <td style="background:#171C28;padding:24px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td>
                    <span style="font-size:26px;font-weight:700;font-family:'Helvetica Neue',Arial,sans-serif;letter-spacing:-0.5px;">
                      <span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span>
                    </span>
                  </td>
                  <td align="right">
                    <span style="color:rgba(255,255,255,0.5);font-size:12px;">${new URL(config.appUrl).host}</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="padding:32px 32px 24px 32px;">
              ${bodyHtml}
              ${attachmentsHtml}
            </td>
          </tr>
          <tr>
            <td style="background:#171C28;padding:20px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="border-left:3px solid #9DB1E3;padding-left:12px;">
                    <p style="margin:0 0 3px 0;font-size:14px;font-weight:700;color:#ffffff;">${senderName}</p>
                    ${senderJobTitle ? `<p style="margin:0 0 3px 0;font-size:12px;color:#9DB1E3;">${senderJobTitle}</p>` : ""}
                    ${senderPhone ? `<p style="margin:0 0 3px 0;font-size:12px;color:rgba(255,255,255,0.7);">📞 ${senderPhone}</p>` : ""}
                    <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.7);">✉ ${senderEmail}</p>
                  </td>
                  <td align="right" valign="bottom">
                    <p style="margin:0;font-size:10px;color:rgba(255,255,255,0.35);">Enviado desde InsurDesk</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { body, senderName, senderEmail, senderPhone, senderJobTitle, attachments } = await req.json();
    const html = buildHtmlEmail({ body, senderName, senderEmail, senderPhone, senderJobTitle, attachments: attachments || [] });
    return Response.json({ html });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
