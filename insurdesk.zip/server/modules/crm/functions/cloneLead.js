// Portado de sdk/functions/cloneLead/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { lead_id, target_pipeline_id, target_stage, assigned_agent_id, assigned_agent_name, caller_name } = await req.json();
    if (!lead_id || !target_pipeline_id || !target_stage) {
      return Response.json({ error: "lead_id, target_pipeline_id y target_stage son requeridos" }, { status: 400 });
    }
    const [lead, targetPipeline] = await Promise.all([
      sdk.asServiceRole.entities.Lead.get(lead_id),
      sdk.asServiceRole.entities.Pipeline.get(target_pipeline_id)
    ]);
    if (!lead) return Response.json({ error: "Lead no encontrado" }, { status: 404 });
    if (!targetPipeline) return Response.json({ error: "Pipeline destino no encontrado" }, { status: 404 });
    const clonedLead = await sdk.asServiceRole.entities.Lead.create({
      prospect_id: lead.prospect_id,
      prospect_name: lead.prospect_name,
      assigned_agent_id: assigned_agent_id || lead.assigned_agent_id,
      assigned_agent_name: assigned_agent_name || lead.assigned_agent_name,
      branch: lead.branch,
      pipeline_id: targetPipeline.id,
      pipeline_name: targetPipeline.name,
      company_name: lead.company_name || "",
      product_name: lead.product_name || "",
      premium_estimated: lead.premium_estimated || 0,
      currency: lead.currency || "USD",
      deductible_estimated: lead.deductible_estimated || 0,
      pipeline_stage: target_stage,
      lead_status: "ACTIVO",
      tags: lead.tags || [],
      notes: `Clonado desde pipeline "${lead.pipeline_name || ""}" (etapa: ${lead.pipeline_stage || ""}).
Lead original ID: ${lead.external_id || lead.id}${lead.notes ? "\n\nNotas originales:\n" + lead.notes : ""}`,
      external_id: `CRM-LEAD-${Date.now()}`,
      last_activity_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    const backgroundTasks = [];
    const agentIdToNotify = assigned_agent_id || lead.assigned_agent_id;
    if (agentIdToNotify) {
      backgroundTasks.push(
        (async () => {
          const agents = await sdk.asServiceRole.entities.User.filter({ id: agentIdToNotify });
          const agentEmail = agents[0]?.email || "";
          await Promise.all([
            sdk.asServiceRole.entities.Notification.create({
              user_id: agentIdToNotify,
              user_email: agentEmail,
              type: "lead_cloned",
              title: "📋 Nuevo lead asignado (clon)",
              message: `Se te asignó el lead de ${clonedLead.prospect_name || "prospecto"} en el pipeline "${targetPipeline.name}" — etapa "${target_stage}". Clonado por ${caller_name || "un usuario"}.`,
              lead_id: clonedLead.id,
              read: false
            }),
            agentEmail ? sdk.asServiceRole.entities.LeadAssignmentNotification.create({
              assigned_agent_id: agentIdToNotify,
              assigned_agent_name: assigned_agent_name || lead.assigned_agent_name || "",
              assigned_agent_email: agentEmail,
              lead_id: clonedLead.id,
              lead_external_id: clonedLead.external_id || "",
              prospect_name: clonedLead.prospect_name || "",
              pipeline_name: targetPipeline.name || "",
              branch: clonedLead.branch || "",
              processed: false
            }) : Promise.resolve()
          ]);
        })()
      );
    }
    backgroundTasks.push(
      sdk.asServiceRole.entities.LeadActivity.create({
        lead_id: lead.id,
        lead_external_id: lead.external_id,
        activity_type: "nota",
        description: `Lead clonado al pipeline "${targetPipeline.name}" en etapa "${target_stage}" por ${caller_name || "un usuario"}. Nuevo lead ID: ${clonedLead.external_id || clonedLead.id}`,
        created_by_name: caller_name || ""
      })
    );
    Promise.all(backgroundTasks).catch((e) => console.error("Error en tareas background de cloneLead:", e));
    return Response.json({
      success: true,
      cloned_lead_id: clonedLead.id,
      cloned_lead_external_id: clonedLead.external_id,
      pipeline_name: targetPipeline.name,
      stage: target_stage
    });
  } catch (error) {
    console.error("Error clonando lead:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
