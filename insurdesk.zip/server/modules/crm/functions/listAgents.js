// Portado de sdk/functions/listAgents/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const users = await sdk.asServiceRole.entities.User.list();
    const agents = users.map((u) => ({
      id: u.id,
      full_name: u.full_name,
      email: u.email,
      crm_role: u.crm_role
    }));
    return Response.json({ agents });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
