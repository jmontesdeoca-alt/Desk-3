// Portado de sdk/functions/trackEmailOpen/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
const PIXEL_GIF = new Uint8Array([
  71,
  73,
  70,
  56,
  57,
  97,
  1,
  0,
  1,
  0,
  128,
  0,
  0,
  255,
  255,
  255,
  0,
  0,
  0,
  33,
  249,
  4,
  0,
  0,
  0,
  0,
  0,
  44,
  0,
  0,
  0,
  0,
  1,
  0,
  1,
  0,
  0,
  2,
  2,
  68,
  1,
  0,
  59
]);
export default (async (req) => {
  try {
    const url = new URL(req.url);
    const activityId = url.searchParams.get("aid");
    const leadId = url.searchParams.get("lid");
    const pixelResponse = new Response(PIXEL_GIF, {
      status: 200,
      headers: {
        "Content-Type": "image/gif",
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache"
      }
    });
    if (!activityId || !leadId) {
      return pixelResponse;
    }
    const userAgent = req.headers.get("user-agent") || "";
    const ipAddress = req.headers.get("x-forwarded-for") || req.headers.get("cf-connecting-ip") || "";
    const openedAt = (/* @__PURE__ */ new Date()).toISOString();
    const sdk = createClientFromRequest(req);
    const existing = await sdk.asServiceRole.entities.EmailOpenTracking.filter({ activity_id: activityId });
    if (existing.length > 0) {
      await sdk.asServiceRole.entities.EmailOpenTracking.update(existing[0].id, {
        open_count: (existing[0].open_count || 1) + 1,
        opened_at: openedAt,
        user_agent: userAgent,
        ip_address: ipAddress
      });
    } else {
      let emailSubject = "";
      let emailTo = "";
      let leadExternalId = "";
      try {
        const activities = await sdk.asServiceRole.entities.LeadActivity.filter({ id: activityId });
        if (activities.length > 0) {
          emailSubject = activities[0].email_subject || "";
          emailTo = activities[0].email_to || "";
        }
        const leads = await sdk.asServiceRole.entities.Lead.filter({ id: leadId });
        if (leads.length > 0) {
          leadExternalId = leads[0].external_id || "";
        }
      } catch (_) {
      }
      await sdk.asServiceRole.entities.EmailOpenTracking.create({
        activity_id: activityId,
        lead_id: leadId,
        lead_external_id: leadExternalId,
        email_subject: emailSubject,
        email_to: emailTo,
        opened_at: openedAt,
        open_count: 1,
        user_agent: userAgent,
        ip_address: ipAddress
      });
    }
    return pixelResponse;
  } catch (_error) {
    return new Response(PIXEL_GIF, {
      status: 200,
      headers: { "Content-Type": "image/gif", "Cache-Control": "no-store" }
    });
  }
});
