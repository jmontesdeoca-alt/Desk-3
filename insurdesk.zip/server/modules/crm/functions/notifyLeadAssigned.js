// Portado de sdk/functions/notifyLeadAssigned/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const { lead_id, lead_external_id, assigned_agent_id, assigned_agent_name, assigned_agent_email, prospect_name, pipeline_name, branch, assigned_by_name } = await req.json();
    if (!assigned_agent_id || !lead_id) {
      return Response.json({ error: "assigned_agent_id y lead_id son requeridos" }, { status: 400 });
    }
    await sdk.asServiceRole.entities.Notification.create({
      user_id: assigned_agent_id,
      user_email: assigned_agent_email || "",
      type: "lead_assigned",
      title: "Nuevo lead asignado",
      message: `Se te asignó el lead de ${prospect_name || "un prospecto"} en el pipeline "${pipeline_name || ""}" (${branch || ""})`,
      lead_id,
      read: false
    });
    if (assigned_agent_email) {
      await sdk.asServiceRole.entities.LeadAssignmentNotification.create({
        assigned_agent_id,
        assigned_agent_name: assigned_agent_name || "",
        assigned_agent_email,
        lead_id,
        lead_external_id: lead_external_id || "",
        prospect_name: prospect_name || "",
        pipeline_name: pipeline_name || "",
        branch: branch || "",
        assigned_by_name: assigned_by_name || "",
        processed: false
      });
    }
    return Response.json({ success: true });
  } catch (error) {
    console.error("Error en notifyLeadAssigned:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
