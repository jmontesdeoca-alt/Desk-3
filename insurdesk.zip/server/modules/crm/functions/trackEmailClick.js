// Portado de sdk/functions/trackEmailClick/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { events } from "../../kernel.js";
export default (async (req) => {
  try {
    const url = new URL(req.url);
    const token = url.pathname.split("/").pop();
    const sdk = createClientFromRequest(req);
    const trackings = await sdk.asServiceRole.entities.EmailTracking.filter({
      link_token: token
    });
    if (!trackings || trackings.length === 0) {
      return Response.json({ error: "Link no encontrado" }, { status: 404 });
    }
    const tracking = trackings[0];
    await sdk.asServiceRole.entities.EmailTracking.update(tracking.id, {
      clicked: true,
      clicked_at: (/* @__PURE__ */ new Date()).toISOString(),
      click_count: (tracking.click_count || 0) + 1,
      user_agent: req.headers.get("user-agent"),
      ip_address: req.headers.get("x-forwarded-for") || "unknown"
    });
    // Las automatizaciones (si el módulo está activo) reaccionan a este evento
    await events.emit("email.link_clicked", { lead_id: tracking.lead_id, link_label: tracking.link_label });
    return Response.redirect(tracking.link_url, 302);
  } catch (error) {
    console.error("Error en tracking:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
