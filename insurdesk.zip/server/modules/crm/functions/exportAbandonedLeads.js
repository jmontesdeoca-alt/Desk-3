// Portado de sdk/functions/exportAbandonedLeads/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const leads = await sdk.entities.Lead.filter({ lead_status: "ABANDONADO" });
    const headers = [
      "ID Externo",
      "Prospecto",
      "Agente",
      "Ramo",
      "Compañía",
      "Producto",
      "Prima Estimada",
      "Moneda",
      "Etapa",
      "Última Actividad",
      "Fecha Creación",
      "Notas"
    ];
    const rows = leads.map((lead) => [
      lead.external_id || "",
      lead.prospect_name || "",
      lead.assigned_agent_name || "",
      lead.branch || "",
      lead.company_name || "",
      lead.product_name || "",
      lead.premium_estimated || "",
      lead.currency || "",
      lead.pipeline_stage || "",
      lead.last_activity_at ? new Date(lead.last_activity_at).toLocaleString("es-ES") : "",
      lead.created_date ? new Date(lead.created_date).toLocaleString("es-ES") : "",
      (lead.notes || "").replace(/"/g, '""')
    ]);
    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(","))
    ].join("\n");
    const bom = "\uFEFF";
    const csvWithBom = bom + csvContent;
    return new Response(csvWithBom, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="leads_abandonados_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv"`
      }
    });
  } catch (error) {
    console.error("Error exporting leads:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
