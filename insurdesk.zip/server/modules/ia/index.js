// Módulo IA: el asistente conversacional (/api/agents). Las herramientas que puede usar las aportan los demás módulos.
import express from 'express';
import { agentsRouter } from './assistant/agent.js';

export function register(ctx) {
  ctx.mount('/api/agents', express.json({ limit: '1mb' }), agentsRouter);
}
