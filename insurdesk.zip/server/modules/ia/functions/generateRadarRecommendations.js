// Portado de sdk/functions/generateRadarRecommendations/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { differenceInDays, addDays } from "date-fns";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const b44 = sdk.asServiceRole;
    let config = {
      max_days_no_followup: 3,
      days_after_quote: 2,
      min_score_high_priority: 70,
      max_daily_actions_per_agent: 10
    };
    try {
      const configs = await b44.entities.RadarConfig.list();
      if (configs.length > 0) config = configs[0];
    } catch (e) {
    }
    let activeLeads = [];
    let hasMore = true;
    const batchSize = 200;
    let skip = 0;
    while (hasMore && activeLeads.length < 1e3) {
      try {
        const batch = await b44.entities.Lead.filter({ lead_status: "ACTIVO" }, "-created_date", batchSize, skip);
        if (batch.length === 0) {
          hasMore = false;
          break;
        }
        activeLeads.push(...batch);
        skip += batchSize;
        if (batch.length < batchSize) hasMore = false;
      } catch (e) {
        hasMore = false;
      }
    }
    if (activeLeads.length === 0) {
      return Response.json({ success: true, generated: 0 });
    }
    const closedKeywords = ["ganad", "cierr", "perdid"];
    activeLeads = activeLeads.filter((l) => {
      const s = (l.pipeline_stage || "").toLowerCase();
      return !closedKeywords.some((k) => s.includes(k));
    });
    const leadIds = activeLeads.map((l) => l.id);
    const activitiesMap = {};
    try {
      let actSkip = 0;
      let actHasMore = true;
      while (actHasMore) {
        const actBatch = await b44.entities.LeadActivity.filter({}, "-created_date", 500, actSkip);
        if (actBatch.length === 0) {
          actHasMore = false;
          break;
        }
        for (const a of actBatch) {
          if (!activitiesMap[a.lead_id]) activitiesMap[a.lead_id] = [];
          activitiesMap[a.lead_id].push(a);
        }
        actSkip += 500;
        if (actBatch.length < 500) actHasMore = false;
        if (actSkip > 3e3) actHasMore = false;
      }
    } catch (e) {
      console.log("Error loading activities:", e.message);
    }
    const confirmedAppointments = /* @__PURE__ */ new Set();
    try {
      const appointments = await b44.entities.AppointmentRequest.filter({ status: "confirmed" }, "-confirmed_at", 500);
      for (const a of appointments) {
        if (a.lead_id) confirmedAppointments.add(a.lead_id);
      }
    } catch (e) {
    }
    const calendarLeads = /* @__PURE__ */ new Set();
    try {
      const cutoff = /* @__PURE__ */ new Date();
      cutoff.setDate(cutoff.getDate() - 30);
      const events = await b44.entities.CalendarEvent.filter({}, "-start_datetime", 200);
      for (const ev of events) {
        if (ev.lead_id && new Date(ev.start_datetime) >= cutoff) {
          calendarLeads.add(ev.lead_id);
        }
      }
    } catch (e) {
    }
    const now = /* @__PURE__ */ new Date();
    const leadsByAgent = {};
    for (const lead of activeLeads) {
      if (!lead.assigned_agent_id) continue;
      const activities = activitiesMap[lead.id] || [];
      const stage = (lead.pipeline_stage || "").toLowerCase();
      const isCotizacion = stage.includes("cotizaci");
      const isNegociacion = stage.includes("negocia");
      const contactAttempts = activities.filter(
        (a) => a.activity_type === "llamada" || a.activity_type === "whatsapp"
      );
      const hasResponseNote = activities.some(
        (a) => a.activity_type === "nota" && (a.description || "").toLowerCase().match(/contest|confirm|acept|interesad|reuni|cita|respond|ok|sí|si |afirm/)
      );
      const noResponseAttempts = !hasResponseNote ? contactAttempts.length : 0;
      if (noResponseAttempts >= 3) continue;
      let lastRealActivity = null;
      if (activities.length > 0) {
        const sorted = activities.slice().sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        lastRealActivity = new Date(sorted[0].created_date);
      }
      const lastActivityDate = lastRealActivity || (lead.last_activity_at ? new Date(lead.last_activity_at) : null) || new Date(lead.updated_date || lead.created_date);
      const daysSinceActivity = differenceInDays(now, lastActivityDate);
      const hasFutureAppointment = confirmedAppointments.has(lead.id);
      const hasRecentCalendarEvent = calendarLeads.has(lead.id);
      if (hasFutureAppointment && daysSinceActivity <= 7) continue;
      let action = null;
      let reason = "";
      if (noResponseAttempts === 2) {
        action = "Último intento de contacto";
        reason = `Se han registrado 2 intentos de contacto sin respuesta. Considerar marcar como perdido si no responde.`;
      } else if (daysSinceActivity > 30) {
        action = "Reactivar o marcar como perdido";
        reason = `El lead lleva más de 30 días sin actividad en el CRM (${daysSinceActivity} días).`;
      } else if (isCotizacion && daysSinceActivity > config.days_after_quote) {
        action = "Llamar para seguimiento de cotización";
        reason = `Cotización enviada hace más de ${config.days_after_quote} días sin seguimiento registrado.`;
      } else if (isNegociacion && daysSinceActivity > 2) {
        action = "Retomar negociación";
        reason = `Lead en etapa de negociación sin actividad en ${daysSinceActivity} días.`;
      } else if (hasFutureAppointment && daysSinceActivity > 3) {
        action = "Confirmar asistencia a cita";
        reason = `Tiene cita confirmada pero sin contacto reciente (${daysSinceActivity} días). Enviar recordatorio.`;
      } else if (hasRecentCalendarEvent && daysSinceActivity > 5) {
        action = "Seguimiento post-reunión";
        reason = `Hubo una reunión reciente. Hacer seguimiento de los acuerdos tomados.`;
      } else if (daysSinceActivity > config.max_days_no_followup) {
        action = "Enviar seguimiento";
        reason = `Han pasado ${daysSinceActivity} días desde la última interacción registrada.`;
      }
      if (!action) continue;
      let score = 50;
      const hasPhone = !!lead.prospect_name;
      if (lead.product_name || lead.branch) score += 10;
      if (activities.length > 0) score += 10;
      if (activities.length >= 3) score += 10;
      if (daysSinceActivity <= 7) score += 20;
      if (daysSinceActivity > 14) score -= 10;
      if (daysSinceActivity > 30) score -= 20;
      if (noResponseAttempts === 2) score -= 20;
      if (noResponseAttempts === 1) score -= 10;
      if (isNegociacion) score += 15;
      if (isCotizacion) score += 10;
      if (hasFutureAppointment) score += 10;
      if (hasRecentCalendarEvent) score += 10;
      if (!lead.premium_estimated) score -= 5;
      score = Math.max(0, Math.min(100, score));
      let priority = "Baja";
      if (score >= config.min_score_high_priority) priority = "Alta";
      else if (score >= 40) priority = "Media";
      if (isNegociacion && daysSinceActivity <= 3) {
        priority = "Alta";
        score = Math.max(score, config.min_score_high_priority);
      }
      const rec = {
        agent_id: lead.assigned_agent_id,
        lead_id: lead.id,
        lead_name: lead.prospect_name || "Lead Desconocido",
        product: lead.product_name || lead.branch || "General",
        pipeline_stage: lead.pipeline_stage || "Inicial",
        action_recommended: action,
        priority,
        score,
        reason,
        deadline: addDays(now, 1).toISOString(),
        status: "pending"
      };
      if (!leadsByAgent[rec.agent_id]) leadsByAgent[rec.agent_id] = [];
      leadsByAgent[rec.agent_id].push(rec);
    }
    const allToSave = [];
    for (const agentId in leadsByAgent) {
      const sorted = leadsByAgent[agentId].sort((a, b) => b.score - a.score);
      const seenLeads = /* @__PURE__ */ new Set();
      const deduplicated = sorted.filter((r) => {
        if (seenLeads.has(r.lead_id)) return false;
        seenLeads.add(r.lead_id);
        return true;
      });
      allToSave.push(...deduplicated.slice(0, config.max_daily_actions_per_agent));
    }
    try {
      let hasMoreToDelete = true;
      while (hasMoreToDelete) {
        const toDelete = await b44.entities.RadarRecommendation.filter({ status: "pending" }, "-created_date", 50);
        if (toDelete.length === 0) {
          hasMoreToDelete = false;
          break;
        }
        for (const r of toDelete) {
          await b44.entities.RadarRecommendation.delete(r.id);
        }
        if (toDelete.length < 50) hasMoreToDelete = false;
      }
    } catch (e) {
      console.log("delete pending warning:", e.message);
    }
    let created = 0;
    const chunkSize = 50;
    for (let i = 0; i < allToSave.length; i += chunkSize) {
      const chunk = allToSave.slice(i, i + chunkSize);
      await b44.entities.RadarRecommendation.bulkCreate(chunk);
      created += chunk.length;
    }
    return Response.json({ success: true, generated: created, leads_analyzed: activeLeads.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
