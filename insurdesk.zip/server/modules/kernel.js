// Kernel de módulos: eventos, servicios y herramientas de IA entre módulos.
// Un módulo está "encendido" cuando la licencia incluye su función (plans.json). Apagar un módulo bloquea
// sus funciones, entidades, rutas, tareas programadas y oyentes; los datos se conservan.
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { bus } from '../src/store.js';
import { invokeFunction, workflowContext } from '../src/functions.js';
import { modules, moduleEnabled } from '../src/features.js';
import { featureName, current as plan } from '../src/license.js';

export class ModuleDisabledError extends Error {
  constructor(id, what = 'Esta función') {
    const m = modules.find((x) => x.id === id);
    super(`${what} requiere "${m ? featureName(m.feature) : id}", que no está incluido en tu plan (${plan().planName}).`);
    this.status = 403; this.code = 'feature_disabled'; this.module = id;
  }
}
export const isEnabled = (id) => moduleEnabled(id);
export const assertEnabled = (id, what) => { if (!isEnabled(id)) throw new ModuleDisabledError(id, what); };

const listeners = new Map(); // evento -> [{ owner, fn }]
const providers = new Map(); // servicio -> { owner, fn }
const aiTools = [];

export const events = {
  on(owner, name, fn) { if (!listeners.has(name)) listeners.set(name, []); listeners.get(name).push({ owner, fn }); },
  /** Los fallos de un oyente se registran pero nunca rompen al emisor. */
  async emit(name, payload = {}) {
    const targets = (listeners.get(name) || []).filter((l) => isEnabled(l.owner));
    const results = await Promise.allSettled(targets.map((l) => l.fn(payload)));
    results.forEach((r, i) => { if (r.status === 'rejected') console.error(`[events] ${name} -> ${targets[i].owner}:`, r.reason?.message || r.reason); });
    return results.length;
  },
};
export const services = {
  provide(owner, name, fn) { providers.set(name, { owner, fn }); },
  has: (name) => providers.has(name) && isEnabled(providers.get(name).owner),
  async call(name, ...args) {
    const p = providers.get(name);
    if (!p) throw new Error(`Servicio no disponible: ${name}`);
    assertEnabled(p.owner, 'Esta acción');
    return p.fn(...args);
  },
};
export const ai = {
  register(owner, tool) { aiTools.push({ owner, ...tool }); },
  list: () => aiTools.filter((t) => isEnabled(t.owner)).map(({ name, description, input_schema }) => ({ name, description, input_schema })),
  run(name, input, user) {
    const t = aiTools.find((x) => x.name === name && isEnabled(x.owner));
    return t ? t.run(input, user) : { error: `Herramienta no disponible: ${name}` };
  },
};

const gate = (id) => (_req, res, next) => (isEnabled(id) ? next() : res.status(403).json({ error: new ModuleDisabledError(id).message, code: 'feature_disabled', module: id }));

export async function bootModules(app) {
  for (const m of modules) {
    const entry = path.join(m.dir, 'index.js');
    if (!fs.existsSync(entry)) continue;
    const mod = await import(pathToFileURL(entry).href);
    if (typeof mod.register !== 'function') continue;
    await mod.register({
      id: m.id,
      events: { on: (name, fn) => events.on(m.id, name, fn), emit: events.emit },
      ai: { registerTool: (tool) => ai.register(m.id, tool) },
      services: { provide: (name, fn) => services.provide(m.id, name, fn), call: services.call, has: services.has },
      /** Oyente de cambios de entidades; se silencia solo si el plan no incluye el módulo. */
      onEntity: (fn) => bus.on('entity', (evt) => { if (isEnabled(m.id)) fn(evt); }),
      /** Monta una ruta HTTP detrás de la compuerta del módulo. */
      mount: (route, ...handlers) => app.use(route, gate(m.id), ...handlers),
      invokeFunction: (name, payload) => invokeFunction(name, payload, { service: true }),
      workflowContext,
      isEnabled,
    });
  }
  console.log(`✔ Módulos activos en este plan: ${modules.filter((m) => isEnabled(m.id)).map((m) => m.id).join(', ') || '(ninguno)'}`);
}
