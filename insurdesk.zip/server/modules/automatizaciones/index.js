// Módulo Automatizaciones: escucha eventos de los demás módulos y dispara los flujos configurados.
//   workflow.trigger   { trigger_event, lead_id?, prospect_id?, form_id? }  → triggerWorkflows
//   email.link_clicked { lead_id, link_label }                              → flujos con disparador "email_clicked"
import { store } from '../../runtime/crm-db.js';

export function register(ctx) {
  // Evita disparos duplicados (p. ej. un lead creado por Meta que ya avisó por su cuenta)
  const recent = new Map();
  ctx.events.on('workflow.trigger', (payload) => {
    const k = [payload.trigger_event, payload.lead_id || payload.prospect_id || '', payload.new_stage || '', payload.tag || ''].join(':');
    const now = Date.now();
    if (now - (recent.get(k) || 0) < 3000) return;
    recent.set(k, now);
    if (recent.size > 500) for (const [key, t] of recent) if (now - t > 10000) recent.delete(key);
    // Lo que una automatización modifique no vuelve a disparar automatizaciones (evita bucles)
    return ctx.workflowContext.run(new Set([...(ctx.workflowContext.getStore() || []), 'automation']), () => ctx.invokeFunction('triggerWorkflows', payload));
  });

  // Disparos desde el servidor: lead nuevo y cambio de etapa (antes los enviaba el navegador)
  ctx.onEntity((evt) => {
    if (evt.entity !== 'Lead' || ctx.workflowContext.getStore()?.has('automation')) return;
    if (evt.type === 'create') ctx.events.emit('workflow.trigger', { trigger_event: 'lead_created', lead_id: evt.id });
    if (evt.type === 'update' && evt.prev && evt.data && evt.prev.pipeline_stage !== evt.data.pipeline_stage) {
      ctx.events.emit('workflow.trigger', { trigger_event: 'lead_stage_changed', lead_id: evt.id, new_stage: evt.data.pipeline_stage });
    }
  });

  ctx.events.on('email.link_clicked', async ({ lead_id, link_label }) => {
    const workflows = store.filter('WorkflowAutomation', { trigger_type: 'email_clicked', is_active: true });
    for (const workflow of workflows) {
      const cfg = workflow.trigger_config || {};
      if (!cfg.link_labels || cfg.link_labels.includes(link_label)) {
        await ctx.invokeFunction('executeWorkflow', { workflow_id: workflow.id, lead_id, trigger_event: `email_clicked:${link_label}` });
      }
    }
  });

  // Un correo abierto también dispara los flujos "email_clicked" (comportamiento heredado del original)
  ctx.onEntity((evt) => {
    if (evt.entity === 'EmailOpenTracking' && evt.type === 'create' && evt.data?.lead_id) {
      ctx.events.emit('workflow.trigger', { trigger_event: 'email_clicked', lead_id: evt.data.lead_id });
    }
  });
}
