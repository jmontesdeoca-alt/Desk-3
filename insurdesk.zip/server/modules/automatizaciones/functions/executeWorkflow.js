// Portado de sdk/functions/executeWorkflow/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { services } from "../../kernel.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const { workflow_id, lead_id, prospect_id, trigger_event } = await req.json();
    const startTime = Date.now();
    const workflow = await sdk.asServiceRole.entities.WorkflowAutomation.get(workflow_id);
    if (!workflow || !workflow.is_active) {
      return Response.json({ error: "Workflow no encontrado o inactivo" }, { status: 404 });
    }
    let lead = null;
    let prospect = null;
    if ((trigger_event === "prospect_created" || trigger_event === "form_submitted") && prospect_id) {
      prospect = await sdk.asServiceRole.entities.Prospect.get(prospect_id);
      if (!prospect) return Response.json({ error: "Prospecto no encontrado" }, { status: 404 });
      lead = { ...prospect, prospect_id: prospect.id, prospect_name: prospect.full_name, tags: prospect.tags || [] };
    } else if (lead_id) {
      lead = await sdk.asServiceRole.entities.Lead.get(lead_id);
      if (!lead) return Response.json({ error: "Lead no encontrado" }, { status: 404 });
    } else {
      return Response.json({ error: "Se requiere lead_id o prospect_id" }, { status: 400 });
    }
    if (lead.custom_fields && typeof lead.custom_fields === "object") {
      const fieldMap = {
        "Ramo": "branch",
        "ramo": "branch",
        "branch": "branch",
        "Producto": "product_name",
        "producto": "product_name",
        "Ciudad": "city",
        "ciudad": "city",
        "País": "country",
        "pais": "country",
        "Ocupación": "occupation",
        "ocupacion": "occupation"
      };
      for (const [cfKey, cfValue] of Object.entries(lead.custom_fields)) {
        const mappedKey = fieldMap[cfKey] || cfKey.toLowerCase().replace(/\s+/g, "_");
        if (!lead[mappedKey]) {
          lead[mappedKey] = cfValue;
        }
      }
    }
    const conditionsMet = evaluateConditions(workflow.conditions || [], lead);
    const actions = conditionsMet ? workflow.actions || [] : workflow.actions_if_false || [];
    const execution = await sdk.asServiceRole.entities.WorkflowExecution.create({
      workflow_id: workflow.id,
      workflow_name: workflow.name,
      lead_id: lead.id,
      lead_external_id: lead.external_id,
      trigger_event,
      conditions_met: conditionsMet,
      actions_executed: [],
      status: "waiting",
      execution_time_ms: 0
    });
    if (actions.length === 0) {
      await sdk.asServiceRole.entities.WorkflowExecution.update(execution.id, { status: "completed", execution_time_ms: Date.now() - startTime });
      return Response.json({ success: true, message: "Sin acciones que ejecutar", conditions_met: conditionsMet });
    }
    const actionsExecuted = [];
    for (let i = 0; i < actions.length; i++) {
      const action = actions[i];
      try {
        if (action.type === "wait") {
          const waitUntil = calculateWaitTime(action.config);
          await sdk.asServiceRole.entities.WorkflowExecution.update(execution.id, { status: "waiting", wait_until: waitUntil, actions_executed: actionsExecuted, execution_time_ms: Date.now() - startTime });
          await sdk.asServiceRole.entities.AutomationLog.create({ workflow_id: workflow.id, workflow_name: workflow.name, execution_id: execution.id, lead_id: lead.id, lead_external_id: lead.external_id, action_type: "wait", action_details: action, status: "success", execution_time_ms: Date.now() - startTime });
          actionsExecuted.push({ action_type: "wait", status: "waiting", result: { wait_until: waitUntil } });
          return Response.json({ success: true, execution, status: "waiting", wait_until: waitUntil });
        }
        const result = await executeAction(sdk, action, lead, workflow);
        actionsExecuted.push({ action_type: action.type, status: "success", result });
        await sdk.asServiceRole.entities.AutomationLog.create({ workflow_id: workflow.id, workflow_name: workflow.name, execution_id: execution.id, lead_id: lead.id, lead_external_id: lead.external_id, action_type: action.type, action_details: action, status: "success", execution_time_ms: Date.now() - startTime });
        if (action.sub_conditions?.length > 0) {
          const subMet = evaluateConditions(action.sub_conditions, lead);
          const subActions = subMet ? action.sub_actions_if_true || [] : action.sub_actions_if_false || [];
          for (const subAction of subActions) {
            try {
              const subResult = await executeAction(sdk, subAction, lead, workflow);
              actionsExecuted.push({ action_type: `sub:${subAction.type}`, status: "success", result: subResult });
              await sdk.asServiceRole.entities.AutomationLog.create({ workflow_id: workflow.id, workflow_name: workflow.name, execution_id: execution.id, lead_id: lead.id, lead_external_id: lead.external_id, action_type: `sub:${subAction.type}`, action_details: subAction, status: "success", execution_time_ms: Date.now() - startTime });
            } catch (subErr) {
              actionsExecuted.push({ action_type: `sub:${subAction.type}`, status: "failed", error: subErr.message });
              await sdk.asServiceRole.entities.AutomationLog.create({ workflow_id: workflow.id, workflow_name: workflow.name, execution_id: execution.id, lead_id: lead.id, lead_external_id: lead.external_id, action_type: `sub:${subAction.type}`, action_details: subAction, status: "failed", error_message: subErr.message, execution_time_ms: Date.now() - startTime });
            }
          }
        }
      } catch (error) {
        actionsExecuted.push({ action_type: action.type, status: "failed", error: error.message });
        await sdk.asServiceRole.entities.AutomationLog.create({ workflow_id: workflow.id, workflow_name: workflow.name, execution_id: execution.id, lead_id: lead.id, lead_external_id: lead.external_id, action_type: action.type, action_details: action, status: "failed", error_message: error.message, execution_time_ms: Date.now() - startTime });
      }
    }
    await sdk.asServiceRole.entities.WorkflowExecution.update(execution.id, { actions_executed: actionsExecuted, status: "completed", execution_time_ms: Date.now() - startTime });
    await sdk.asServiceRole.entities.WorkflowAutomation.update(workflow.id, { execution_count: (workflow.execution_count || 0) + 1 });
    return Response.json({ success: true, execution, actions_executed: actionsExecuted.length });
  } catch (error) {
    console.error("Error ejecutando workflow:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
function calculateWaitTime(config) {
  const { wait_type, wait_amount } = config;
  const now = /* @__PURE__ */ new Date();
  if (wait_type === "minutes") now.setMinutes(now.getMinutes() + wait_amount);
  else if (wait_type === "hours") now.setHours(now.getHours() + wait_amount);
  else if (wait_type === "days") now.setDate(now.getDate() + wait_amount);
  else if (wait_type === "weeks") now.setDate(now.getDate() + wait_amount * 7);
  return now.toISOString();
}
function evaluateConditions(conditions, lead) {
  if (!conditions || conditions.length === 0) return true;
  for (const condition of conditions) {
    const { field, operator, value, logic } = condition;
    let result = false;
    const fieldValue = lead[field];
    switch (operator) {
      case "equals":
        result = fieldValue === value;
        break;
      case "not_equals":
        result = fieldValue !== value;
        break;
      case "contains":
        result = typeof fieldValue === "string" && fieldValue.includes(value);
        break;
      case "greater_than":
        result = Number(fieldValue) > Number(value);
        break;
      case "less_than":
        result = Number(fieldValue) < Number(value);
        break;
      case "in":
        result = Array.isArray(value) ? value.includes(fieldValue) : false;
        break;
      case "has_tag":
        result = Array.isArray(lead.tags) && lead.tags.some((t) => (typeof t === "object" ? t.name : t) === value);
        break;
      default:
        result = true;
    }
    if (logic === "AND" && !result) return false;
    if (logic === "OR" && result) return true;
  }
  return true;
}
async function executeAction(sdk, action, lead, workflow) {
  const { type, config } = action;
  switch (type) {
    case "send_email":
      return await sendEmail(sdk, lead, config);
    case "change_stage":
      if (lead.external_id || lead.pipeline_id) {
        await sdk.asServiceRole.entities.Lead.update(lead.id, { pipeline_stage: config.new_stage });
      }
      return { stage: config.new_stage };
    case "assign_agent":
      if (lead.external_id || lead.pipeline_id) {
        await sdk.asServiceRole.entities.Lead.update(lead.id, { assigned_agent_id: config.agent_id, assigned_agent_name: config.agent_name });
      } else {
        await sdk.asServiceRole.entities.Prospect.update(lead.id, { assigned_agent_id: config.agent_id, assigned_agent_name: config.agent_name });
      }
      return { agent: config.agent_name };
    case "assign_agent_roundrobin": {
      const rrAgents = config.agents || [];
      if (rrAgents.length === 0) throw new Error("No hay agentes configurados en el round-robin");
      let queues = await sdk.asServiceRole.entities.RoundRobinQueue.filter({ workflow_id: workflow.id });
      let queue = queues.find((q) => JSON.stringify((q.agents || []).map((a) => a.id)) === JSON.stringify(rrAgents.map((a) => a.id)));
      if (!queue) {
        queue = await sdk.asServiceRole.entities.RoundRobinQueue.create({ workflow_id: workflow.id, agents: rrAgents, current_index: 0, total_assigned: 0 });
      }
      const currentIdx = queue.current_index || 0;
      const assignedAgent = rrAgents[currentIdx % rrAgents.length];
      const nextIdx = (currentIdx + 1) % rrAgents.length;
      await sdk.asServiceRole.entities.RoundRobinQueue.update(queue.id, { current_index: nextIdx, total_assigned: (queue.total_assigned || 0) + 1 });
      if (lead.external_id || lead.pipeline_id) {
        await sdk.asServiceRole.entities.Lead.update(lead.id, { assigned_agent_id: assignedAgent.id, assigned_agent_name: assignedAgent.full_name });
      } else {
        await sdk.asServiceRole.entities.Prospect.update(lead.id, { assigned_agent_id: assignedAgent.id, assigned_agent_name: assignedAgent.full_name });
      }
      try {
        await sdk.asServiceRole.entities.Notification.create({ user_id: assignedAgent.id, user_email: assignedAgent.email, type: "lead_assigned", title: "Nuevo lead asignado", message: `Se te asignó el lead de ${lead.prospect_name || lead.full_name || "prospecto"} vía asignación secuencial`, lead_id: lead.id, read: false });
      } catch (_) {
      }
      return { agent: assignedAgent.full_name, assigned_index: currentIdx, next_index: nextIdx };
    }
    case "create_task":
      await sdk.asServiceRole.entities.FollowUpReminder.create({
        lead_id: lead.external_id ? lead.id : void 0,
        lead_name: lead.branch ? `${lead.branch} - ${lead.company_name || ""}` : lead.full_name,
        prospect_name: lead.prospect_name || lead.full_name,
        assigned_to_id: lead.assigned_agent_id,
        assigned_to_name: lead.assigned_agent_name,
        reminder_date: config.due_date || (/* @__PURE__ */ new Date()).toISOString(),
        reminder_type: config.task_type || "seguimiento",
        description: config.description || "Tarea creada por automatización"
      });
      return { task_created: true };
    case "create_note":
      if (lead.external_id || lead.pipeline_id) {
        await sdk.asServiceRole.entities.LeadActivity.create({ lead_id: lead.id, lead_external_id: lead.external_id, activity_type: "nota", description: config.note_text || "Nota creada por automatización", created_by_name: "Sistema" });
      }
      return { note_created: true };
    case "add_tag": {
      const tagName = config.tag_name;
      if (!tagName) throw new Error("Nombre de tag no configurado");
      const tagColor = config.tag_color || "#2F4F9D";
      let tagRecord = null;
      try {
        const existingTags = await sdk.asServiceRole.entities.Tag.filter({ name: tagName });
        if (existingTags.length > 0) {
          tagRecord = existingTags[0];
        } else {
          tagRecord = await sdk.asServiceRole.entities.Tag.create({ name: tagName, color: tagColor });
        }
      } catch (_) {
        tagRecord = { id: `tag_${tagName}`, name: tagName, color: tagColor };
      }
      const newTag = { id: tagRecord.id, name: tagRecord.name, color: tagRecord.color };
      const isLead = !!(lead.external_id || lead.pipeline_id);
      if (isLead) {
        const currentTags = lead.tags || [];
        const alreadyHas = currentTags.some((t) => (typeof t === "object" ? t.name : t) === tagName);
        if (!alreadyHas) {
          await sdk.asServiceRole.entities.Lead.update(lead.id, { tags: [...currentTags, newTag] });
          lead.tags = [...currentTags, newTag];
        }
      } else {
        const currentTags = lead.tags || [];
        const alreadyHas = currentTags.some((t) => (typeof t === "object" ? t.name : t) === tagName);
        if (!alreadyHas) {
          await sdk.asServiceRole.entities.Prospect.update(lead.id, { tags: [...currentTags, newTag] });
          lead.tags = [...currentTags, newTag];
        }
      }
      return { tag_added: tagName };
    }
    case "clone_to_pipeline": {
      const targetPipeline = await sdk.asServiceRole.entities.Pipeline.get(config.target_pipeline_id);
      if (!targetPipeline) throw new Error("Pipeline destino no encontrado");
      const firstStage = config.target_stage || targetPipeline.stages?.[0]?.key || "NUEVO";
      const clonedLead = await sdk.asServiceRole.entities.Lead.create({
        prospect_id: lead.prospect_id || lead.id,
        prospect_name: lead.prospect_name || lead.full_name,
        assigned_agent_id: config.assigned_agent_id || lead.assigned_agent_id,
        assigned_agent_name: config.assigned_agent_name || lead.assigned_agent_name,
        branch: lead.branch || "General",
        pipeline_id: targetPipeline.id,
        pipeline_name: targetPipeline.name,
        company_name: lead.company_name || "",
        product_name: lead.product_name || "",
        premium_estimated: lead.premium_estimated || 0,
        currency: lead.currency || "USD",
        pipeline_stage: firstStage,
        lead_status: "ACTIVO",
        tags: lead.tags || [],
        notes: `Clonado desde pipeline "${lead.pipeline_name || ""}" — Lead original: ${lead.external_id || lead.id}`,
        external_id: `CRM-LEAD-${Date.now()}`,
        last_activity_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      return { cloned: true, new_lead_id: clonedLead.id, target_pipeline: targetPipeline.name, stage: firstStage };
    }
    case "create_lead": {
      let prospectData = null;
      if (lead.prospect_id) {
        prospectData = await sdk.asServiceRole.entities.Prospect.get(lead.prospect_id);
      } else if (lead.email) {
        prospectData = lead;
      }
      if (!prospectData) throw new Error("Prospecto no encontrado para crear lead");
      let pipelineId = config.pipeline_id || "";
      let pipelineName = config.pipeline_name || "";
      let pipelineStage = config.pipeline_stage || "NUEVO";
      if (pipelineId) {
        const pipeline = await sdk.asServiceRole.entities.Pipeline.get(pipelineId);
        if (pipeline) {
          pipelineName = pipeline.name;
          pipelineStage = config.pipeline_stage || pipeline.stages?.[0]?.key || "NUEVO";
        }
      }
      const newLead = await sdk.asServiceRole.entities.Lead.create({
        prospect_id: prospectData.id,
        prospect_name: prospectData.full_name,
        assigned_agent_id: config.assigned_agent_id || prospectData.assigned_agent_id || "",
        assigned_agent_name: config.assigned_agent_name || prospectData.assigned_agent_name || "",
        branch: config.branch || "General",
        pipeline_id: pipelineId,
        pipeline_name: pipelineName,
        company_name: config.company_name || "",
        premium_estimated: config.premium_estimated || 0,
        pipeline_stage: pipelineStage,
        lead_status: "ACTIVO",
        tags: prospectData.tags || [],
        external_id: `CRM-LEAD-${Date.now()}`,
        last_activity_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      return { lead_created: true, lead_id: newLead.id };
    }
    case "webhook": {
      const webhookResponse = await fetch(config.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lead, workflow: workflow.name })
      });
      return { webhook_status: webhookResponse.status };
    }
    case "send_meta_conversion": {
      if (!lead.external_id && !lead.pipeline_id) {
        throw new Error("Esta acción solo funciona con leads, no con prospectos");
      }
      const capiResponse = await services.call("meta.sendConversion", {
        lead_id: lead.id,
        event_name: config.event_name || "Purchase",
        value: config.value || lead.premium_estimated || 0,
        currency: lead.currency || "USD"
      });
      return { meta_conversion: capiResponse.data || capiResponse };
    }
    case "wait":
      return { wait_until: config.wait_until };
    default:
      return { action: "unknown" };
  }
}
async function sendEmail(sdk, lead, config) {
  const { template_id, to_email } = config;
  const template = await sdk.asServiceRole.entities.EmailTemplate.get(template_id);
  if (!template) throw new Error("Plantilla no encontrada");
  let subject = template.subject;
  let body = template.body;
  const variables = {
    prospect_name: lead.prospect_name || lead.full_name || "Cliente",
    company_name: lead.company_name || "",
    branch: lead.branch || "",
    agent_name: lead.assigned_agent_name || ""
  };
  for (const [key, value] of Object.entries(variables)) {
    subject = subject.replace(new RegExp(`{{${key}}}`, "g"), value);
    body = body.replace(new RegExp(`{{${key}}}`, "g"), value);
  }
  const recipientEmail = to_email || lead.prospect_email || lead.email;
  if (!recipientEmail) throw new Error("No hay email de destinatario disponible");
  await sdk.asServiceRole.integrations.Core.SendEmail({ to: recipientEmail, subject, body });
  await sdk.asServiceRole.entities.EmailTemplate.update(template.id, { usage_count: (template.usage_count || 0) + 1 });
  return { email_sent: true, template: template.name };
}
