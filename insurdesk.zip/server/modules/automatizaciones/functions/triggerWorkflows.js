// Portado de sdk/functions/triggerWorkflows/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const { trigger_event, lead_id, prospect_id, new_stage, tag, form_id } = await req.json();
    if (!trigger_event) return Response.json({ error: "trigger_event es requerido" }, { status: 400 });
    const allWorkflowsRaw = await sdk.asServiceRole.entities.WorkflowAutomation.filter({ is_active: true });
    const allWorkflows = (allWorkflowsRaw || []).filter((wf) => {
      if (wf.trigger_type === trigger_event) return true;
      if (Array.isArray(wf.triggers)) return wf.triggers.some((t) => t.trigger_type === trigger_event);
      return false;
    });
    if (!allWorkflows || allWorkflows.length === 0) {
      return Response.json({ triggered: 0, message: `No hay workflows activos para "${trigger_event}"` });
    }
    let lead = null;
    if (lead_id) {
      lead = await sdk.asServiceRole.entities.Lead.get(lead_id);
      if (!lead) return Response.json({ error: "Lead no encontrado" }, { status: 404 });
    }
    const triggered = [];
    const skipped = [];
    for (const workflow of allWorkflows) {
      const matchingTrigger = Array.isArray(workflow.triggers) ? workflow.triggers.find((t) => t.trigger_type === trigger_event) : workflow.trigger_type === trigger_event ? { trigger_type: trigger_event, trigger_config: workflow.trigger_config || {} } : null;
      const tc = matchingTrigger?.trigger_config || workflow.trigger_config || {};
      let matches = true;
      if (trigger_event === "lead_stage_changed") {
        if (tc.pipeline_id && tc.pipeline_id !== "any" && tc.pipeline_id !== "" && lead) {
          if (tc.pipeline_id !== lead.pipeline_id) matches = false;
        }
        if (matches && tc.stage && tc.stage !== "any" && tc.stage !== "") {
          if (tc.stage !== new_stage) matches = false;
        }
      }
      if (trigger_event === "tag_added") {
        if (tc.tag && tc.tag !== "") {
          if (tc.tag !== tag) matches = false;
        }
      }
      if (trigger_event === "form_submitted") {
        if (tc.form_id && tc.form_id !== "any" && tc.form_id !== "") {
          if (tc.form_id !== form_id) matches = false;
        }
      }
      if (!matches) {
        skipped.push({ workflow_id: workflow.id, workflow_name: workflow.name, reason: "trigger_config no coincide" });
        continue;
      }
      try {
        const execPayload = {
          workflow_id: workflow.id,
          trigger_event,
          ...lead_id && { lead_id },
          ...prospect_id && { prospect_id }
        };
        await sdk.asServiceRole.functions.invoke("executeWorkflow", execPayload);
        triggered.push({ workflow_id: workflow.id, workflow_name: workflow.name });
      } catch (err) {
        console.error(`Error disparando workflow ${workflow.id}:`, err.message);
        skipped.push({ workflow_id: workflow.id, workflow_name: workflow.name, reason: err.message });
      }
    }
    return Response.json({ triggered: triggered.length, skipped: skipped.length, triggered_workflows: triggered, skipped_workflows: skipped });
  } catch (error) {
    console.error("Error en triggerWorkflows:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
