// Portado de sdk/functions/handleCalendarCallback/entry.ts
import { config } from "../../../src/config.js";
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const url = new URL(req.url);
    const code = url.searchParams.get("code");
    const userId = url.searchParams.get("state");
    const errorParam = url.searchParams.get("error");
    if (errorParam) {
      return new Response(
        `<html><body style="font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#fef2f2">
          <div style="text-align:center">
            <h1 style="color:#dc2626">Error de autorización</h1>
            <p style="color:#64748b">${errorParam}</p>
            <button onclick="window.close()" style="background:#dc2626;color:white;border:none;padding:12px 24px;border-radius:8px;cursor:pointer">Cerrar</button>
          </div>
        </body></html>`,
        { headers: { "Content-Type": "text/html" } }
      );
    }
    if (!code || !userId) {
      return new Response("<html><body><h1>Error: Parámetros faltantes</h1></body></html>", {
        headers: { "Content-Type": "text/html" }
      });
    }
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
    const redirectUri = `${config.appUrl}/api/functions/handleCalendarCallback`;
    if (!clientId || !clientSecret) {
      return new Response("<html><body><h1>Error: OAuth no configurado</h1></body></html>", {
        headers: { "Content-Type": "text/html" }
      });
    }
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: "authorization_code"
      })
    });
    if (!tokenResponse.ok) {
      const error = await tokenResponse.text();
      console.error("Token exchange error:", error);
      return new Response("<html><body><h1>Error al conectar con Google</h1></body></html>", {
        headers: { "Content-Type": "text/html" }
      });
    }
    const tokens = await tokenResponse.json();
    const userInfoRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { "Authorization": `Bearer ${tokens.access_token}` }
    });
    const userInfo = await userInfoRes.json();
    const expiryTime = new Date(Date.now() + (tokens.expires_in || 3600) * 1e3);
    const existingConnections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      user_id: userId,
      provider: "google"
    });
    if (existingConnections.length > 0) {
      await sdk.asServiceRole.entities.UserCalendarConnection.update(existingConnections[0].id, {
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token || existingConnections[0].refresh_token,
        token_expiry: expiryTime.toISOString(),
        connected_email: userInfo.email,
        is_active: true
      });
    } else {
      let userEmail = userInfo.email;
      try {
        const userRecord = await sdk.asServiceRole.entities.User.get(userId);
        userEmail = userRecord.email;
      } catch (_) {
      }
      await sdk.asServiceRole.entities.UserCalendarConnection.create({
        user_id: userId,
        user_email: userEmail,
        provider: "google",
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        token_expiry: expiryTime.toISOString(),
        connected_email: userInfo.email,
        is_active: true
      });
    }
    return new Response(
      `<html>
        <body style="font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#f0fdf4">
          <div style="text-align:center">
            <div style="font-size:48px;margin-bottom:16px">✅</div>
            <h1 style="color:#16a34a;margin-bottom:8px">¡Calendario Conectado!</h1>
            <p style="color:#64748b;margin-bottom:24px">Tu cuenta <strong>${userInfo.email}</strong> fue conectada exitosamente</p>
            <button onclick="window.close()" style="background:#16a34a;color:white;border:none;padding:12px 24px;border-radius:8px;cursor:pointer;font-size:14px">
              Cerrar Ventana
            </button>
          </div>
          <script>
            // Notify the opener immediately
            if (window.opener) {
              window.opener.postMessage({ type: 'calendar_connected' }, '*');
            }
            // Close this popup after a short delay
            setTimeout(() => { window.close(); }, 1500);
          <\/script>
        </body>
      </html>`,
      { headers: { "Content-Type": "text/html" } }
    );
  } catch (error) {
    console.error("Error in callback:", error);
    return new Response(`<html><body><h1>Error: ${error.message}</h1></body></html>`, {
      headers: { "Content-Type": "text/html" }
    });
  }
});
