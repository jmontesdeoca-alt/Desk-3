// Portado de sdk/functions/disconnectCalendar/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const connections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      user_id: user.id,
      provider: "google"
    });
    if (connections.length > 0) {
      await sdk.asServiceRole.entities.UserCalendarConnection.update(connections[0].id, {
        is_active: false
      });
    }
    return Response.json({
      success: true,
      message: "Calendario desconectado exitosamente"
    });
  } catch (error) {
    console.error("Error disconnecting calendar:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
