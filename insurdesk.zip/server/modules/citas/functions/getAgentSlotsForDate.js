// Portado de sdk/functions/getAgentSlotsForDate/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { createEcuadorTime, getBusyRanges, generateDaySlots } from "../lib/bookingUtils.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { token, date } = await req.json();
    if (!token || !date) {
      return Response.json({ error: "Se requiere token y date (YYYY-MM-DD)" }, { status: 400 });
    }
    const configs = await sdk.asServiceRole.entities.AgentAvailability.filter({
      public_token: token,
      is_active: true
    });
    if (configs.length === 0) {
      return Response.json({ error: "Configuración no encontrada" }, { status: 404 });
    }
    const config = configs[0];
    const [year, month, day] = date.split("-").map(Number);
    const dateObj = createEcuadorTime(year, month, day, 0, 0);
    const dayOfWeek = dateObj.getDay();
    const dayStart = createEcuadorTime(year, month, day, 0, 0);
    const dayEnd = createEcuadorTime(year, month, day, 23, 59);
    const busyRanges = await getBusyRanges(sdk, config.agent_id, dayStart, dayEnd);
    const availableSlots = generateDaySlots(config, year, month, day, busyRanges);
    return Response.json({ slots: availableSlots });
  } catch (error) {
    console.error("Error in getAgentSlotsForDate:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
