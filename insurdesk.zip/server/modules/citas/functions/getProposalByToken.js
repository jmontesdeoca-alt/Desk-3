// Portado de sdk/functions/getProposalByToken/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { token } = await req.json();
    if (!token) return Response.json({ error: "Token requerido" }, { status: 400 });
    const proposals = await sdk.asServiceRole.entities.AppointmentRequest.filter(
      { token },
      "created_date",
      1
    );
    if (!proposals || proposals.length === 0) {
      return Response.json({ error: "Propuesta no encontrada" }, { status: 404 });
    }
    const p = proposals[0];
    return Response.json({
      proposal: {
        status: p.status,
        agent_name: p.agent_name,
        client_name: p.client_name || null,
        client_email: p.client_email,
        proposed_slots: p.proposed_slots || [],
        title: p.title,
        description: p.description || null,
        duration_minutes: p.duration_minutes || 30,
        expires_at: p.expires_at || null
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
