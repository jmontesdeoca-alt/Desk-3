import { brand } from '../../../runtime/brand.js';
// Portado de sdk/functions/confirmAppointment/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { Resend } from "../../../runtime/resend-compat.js";
async function refreshTokenIfNeeded(connection, sdk) {
  if (!connection.token_expiry) return connection.access_token;
  const expiryTime = new Date(connection.token_expiry);
  if (expiryTime.getTime() - Date.now() < 5 * 60 * 1e3) {
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.GOOGLE_OAUTH_CLIENT_ID,
        client_secret: process.env.GOOGLE_OAUTH_CLIENT_SECRET,
        refresh_token: connection.refresh_token,
        grant_type: "refresh_token"
      })
    });
    if (!tokenResponse.ok) return connection.access_token;
    const tokens = await tokenResponse.json();
    await sdk.asServiceRole.entities.UserCalendarConnection.update(connection.id, {
      access_token: tokens.access_token,
      token_expiry: new Date(Date.now() + (tokens.expires_in || 3600) * 1e3).toISOString()
    });
    return tokens.access_token;
  }
  return connection.access_token;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { token, selected_datetime, client_name, client_email, client_phone, notes } = await req.json();
    if (!token || !selected_datetime) {
      return Response.json({ error: "Faltan campos: token, selected_datetime" }, { status: 400 });
    }
    const proposals = await sdk.asServiceRole.entities.AppointmentRequest.filter({ token }, "created_date", 1);
    if (!proposals || proposals.length === 0) {
      return Response.json({ error: "Enlace inválido o no encontrado" }, { status: 404 });
    }
    const proposal = proposals[0];
    if (proposal.status !== "pending") {
      return Response.json({ error: "Este enlace ya fue usado o expiró" }, { status: 409 });
    }
    if (proposal.expires_at && new Date(proposal.expires_at) < /* @__PURE__ */ new Date()) {
      await sdk.asServiceRole.entities.AppointmentRequest.update(proposal.id, { status: "expired" });
      return Response.json({ error: "Este enlace ha expirado" }, { status: 410 });
    }
    const isValidSlot = proposal.proposed_slots.some((s) => s.datetime === selected_datetime);
    if (!isValidSlot) {
      return Response.json({ error: "Horario seleccionado no válido" }, { status: 400 });
    }
    const slotStart = new Date(selected_datetime);
    const durMin = proposal.duration_minutes || 30;
    const slotEnd = new Date(slotStart.getTime() + durMin * 6e4);
    const agentEvents = await sdk.asServiceRole.entities.CalendarEvent.filter(
      { assigned_to_id: proposal.agent_id },
      "start_datetime",
      300
    );
    const hasConflict = agentEvents.some((event) => {
      if (event.status === "cancelado") return false;
      const eStart = new Date(event.start_datetime);
      const eEnd = new Date(event.end_datetime);
      return slotStart < eEnd && slotEnd > eStart;
    });
    if (hasConflict) {
      return Response.json({ error: "Ese horario acaba de ser ocupado. Por favor recarga y elige otro." }, { status: 409 });
    }
    const finalName = client_name || proposal.client_name || "Cliente";
    const finalEmail = client_email || proposal.client_email;
    const finalPhone = client_phone || proposal.client_phone || null;
    let prospectId = proposal.prospect_id;
    if (!prospectId) {
      const newProspect = await sdk.asServiceRole.entities.Prospect.create({
        full_name: finalName,
        email: finalEmail,
        phone_raw: finalPhone,
        assigned_agent_id: proposal.agent_id,
        assigned_agent_name: proposal.agent_name,
        source: "web",
        notes: notes ? `Cita agendada: ${notes}` : `Cita agendada desde propuesta de ${proposal.agent_name}`
      });
      prospectId = newProspect.id;
    }
    const calendarEvent = await sdk.asServiceRole.entities.CalendarEvent.create({
      title: `${proposal.title} - ${finalName}`,
      description: `Cita con ${finalName} (${finalEmail})${finalPhone ? "\nTel: " + finalPhone : ""}${notes ? "\nNotas: " + notes : ""}`,
      event_type: "reunión",
      start_datetime: slotStart.toISOString(),
      end_datetime: slotEnd.toISOString(),
      assigned_to_id: proposal.agent_id,
      assigned_to_name: proposal.agent_name,
      attendees: finalEmail,
      status: "programado",
      prospect_id: prospectId,
      lead_id: proposal.lead_id || null
    });
    await sdk.asServiceRole.entities.AppointmentRequest.update(proposal.id, {
      status: "confirmed",
      confirmed_datetime: selected_datetime,
      confirmed_at: (/* @__PURE__ */ new Date()).toISOString(),
      calendar_event_id: calendarEvent.id,
      client_name: finalName,
      client_email: finalEmail,
      client_phone: finalPhone,
      prospect_id: prospectId
    });
    let googleEventLink = null;
    let meetLink = null;
    const connections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      user_id: proposal.agent_id,
      provider: "google",
      is_active: true
    });
    if (connections.length > 0) {
      const accessToken = await refreshTokenIfNeeded(connections[0], sdk);
      const gcalRes = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1", {
        method: "POST",
        headers: { "Authorization": `Bearer ${accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          summary: `${proposal.title} - ${finalName}`,
          description: `Cliente: ${finalName} (${finalEmail})${finalPhone ? "\nTel: " + finalPhone : ""}${notes ? "\nNotas: " + notes : ""}`,
          start: { dateTime: slotStart.toISOString(), timeZone: "America/Guayaquil" },
          end: { dateTime: slotEnd.toISOString(), timeZone: "America/Guayaquil" },
          attendees: [{ email: finalEmail }],
          conferenceData: {
            createRequest: {
              requestId: `${proposal.id}-${Date.now()}`,
              conferenceSolutionKey: { type: "hangoutsMeet" }
            }
          }
        })
      });
      if (gcalRes.ok) {
        const gcalData = await gcalRes.json();
        googleEventLink = gcalData.htmlLink;
        meetLink = gcalData.conferenceData?.entryPoints?.find((e) => e.entryPointType === "video")?.uri || null;
        if (!meetLink && gcalData.conferenceData?.createRequest?.status === "pending") {
          await new Promise((r) => setTimeout(r, 3e3));
          const pollRes = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${gcalData.id}`, {
            headers: { "Authorization": `Bearer ${accessToken}` }
          });
          if (pollRes.ok) {
            const polledData = await pollRes.json();
            meetLink = polledData.conferenceData?.entryPoints?.find((e) => e.entryPointType === "video")?.uri || null;
          }
        }
        await sdk.asServiceRole.entities.AppointmentRequest.update(proposal.id, { google_event_id: gcalData.id });
        await sdk.asServiceRole.entities.CalendarEvent.update(calendarEvent.id, {
          google_event_id: gcalData.id,
          location: meetLink
        });
      } else {
        console.error("Google Calendar API error:", await gcalRes.text());
      }
    }
    const dateStr = slotStart.toLocaleDateString("es-EC", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      timeZone: "America/Guayaquil"
    });
    const timeStr = slotStart.toLocaleTimeString("es-EC", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "America/Guayaquil"
    });
    const resend = new Resend(process.env.RESEND_API_KEY);
    const clientHtml = `<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"/></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Helvetica Neue',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
        <tr><td style="background:#171C28;padding:28px 32px;">
          <span style="font-size:26px;font-weight:700;"><span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span></span>
        </td></tr>
        <tr><td style="padding:36px 32px;">
          <h2 style="margin:0 0 8px 0;color:#171C28;font-size:22px;">✅ ¡Cita confirmada!</h2>
          <p style="margin:0 0 24px 0;color:#64748b;font-size:14px;">Hola ${finalName}, hemos registrado tu cita con éxito.</p>
          <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:20px 24px;margin-bottom:24px;">
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Motivo</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;">${proposal.title}</p>
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Fecha</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;text-transform:capitalize;">${dateStr}</p>
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Hora</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;">${timeStr} (Ecuador)</p>
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Tu agente</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;">${proposal.agent_name}</p>
            ${meetLink ? `
            <div style="background:#e0f2fe;border:1px solid #bae6fd;border-radius:10px;padding:16px 20px;margin-bottom:16px;">
              <p style="margin:0 0 8px 0;font-size:12px;color:#0284c7;text-transform:uppercase;font-weight:600;">🔗 Enlace de Google Meet</p>
              <p style="margin:0;font-size:14px;color:#1e293b;">Únete a la reunión haciendo clic aquí:</p>
              <a href="${meetLink}" target="_blank" style="display:inline-block;margin-top:10px;padding:10px 24px;background:#2F4F9D;color:#fff;text-decoration:none;border-radius:8px;font-size:14px;font-weight:600;">Unirse a la reunión</a>
            </div>` : ""}
          </div>
          <p style="color:#94a3b8;font-size:13px;margin:0;">Para cancelar o cambiar, contacta a ${proposal.agent_name} en ${proposal.agent_email}</p>
        </td></tr>
        <tr><td style="background:#171C28;padding:20px 32px;">
          <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.5);">Mensaje automático de InsurDesk</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
    const emailPayload = {
      from: `${proposal.agent_name} <${brand.address}>`,
      reply_to: proposal.agent_email,
      to: [finalEmail],
      subject: `✅ Cita confirmada: ${proposal.title} — ${dateStr}`,
      html: clientHtml
    };
    if (proposal.agent_email) emailPayload.cc = [proposal.agent_email];
    await resend.emails.send(emailPayload);
    await sdk.asServiceRole.entities.Notification.create({
      user_id: proposal.agent_id,
      user_email: proposal.agent_email,
      type: "general",
      title: `Nueva cita agendada: ${finalName}`,
      message: `${finalName} confirmó la cita "${proposal.title}" para el ${dateStr} a las ${timeStr}.`
    });
    return Response.json({
      success: true,
      confirmed_datetime: selected_datetime,
      prospect_id: prospectId,
      calendar_event_id: calendarEvent.id,
      agent_name: proposal.agent_name,
      agent_email: proposal.agent_email,
      title: proposal.title,
      google_event_link: googleEventLink
    });
  } catch (error) {
    console.error("Error confirming appointment:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
