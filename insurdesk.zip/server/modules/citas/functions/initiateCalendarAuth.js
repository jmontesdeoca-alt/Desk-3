// Portado de sdk/functions/initiateCalendarAuth/entry.ts
import { config } from "../../../src/config.js";
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    if (!clientId) {
      return Response.json({ error: "Google OAuth no configurado" }, { status: 500 });
    }
    const redirectUri = `${config.appUrl}/api/functions/handleCalendarCallback`;
    const scope = [
      "https://www.googleapis.com/auth/calendar",
      "https://www.googleapis.com/auth/calendar.events",
      "https://www.googleapis.com/auth/userinfo.email"
    ].join(" ");
    const authUrl = "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: "code",
      scope,
      access_type: "offline",
      prompt: "consent",
      state: user.id
    }).toString();
    return Response.json({ auth_url: authUrl });
  } catch (error) {
    console.error("Error initiating auth:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
