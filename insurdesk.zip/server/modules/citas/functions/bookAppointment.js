import { brand } from '../../../runtime/brand.js';
// Portado de sdk/functions/bookAppointment/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { Resend } from "../../../runtime/resend-compat.js";
async function refreshTokenIfNeeded(connection, sdk) {
  if (!connection.token_expiry) return connection.access_token;
  const expiryTime = new Date(connection.token_expiry);
  const now = /* @__PURE__ */ new Date();
  if (expiryTime.getTime() - now.getTime() < 5 * 60 * 1e3) {
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
    if (!connection.refresh_token) return connection.access_token;
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: connection.refresh_token,
        grant_type: "refresh_token"
      })
    });
    if (!tokenResponse.ok) return connection.access_token;
    const tokens = await tokenResponse.json();
    const newExpiry = new Date(Date.now() + (tokens.expires_in || 3600) * 1e3);
    await sdk.asServiceRole.entities.UserCalendarConnection.update(connection.id, {
      access_token: tokens.access_token,
      token_expiry: newExpiry.toISOString()
    });
    return tokens.access_token;
  }
  return connection.access_token;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { slot_id, client_name, client_email, client_phone, notes } = await req.json();
    if (!slot_id || !client_name || !client_email) {
      return Response.json({ error: "Faltan campos requeridos: slot_id, client_name, client_email" }, { status: 400 });
    }
    const slot = await sdk.asServiceRole.entities.AppointmentSlot.get(slot_id);
    if (!slot) return Response.json({ error: "Slot no encontrado" }, { status: 404 });
    if (slot.status !== "available") return Response.json({ error: "Este horario ya no está disponible" }, { status: 409 });
    const slotStart = new Date(slot.datetime);
    if (slotStart <= /* @__PURE__ */ new Date()) return Response.json({ error: "Este horario ya pasó" }, { status: 409 });
    const slotEnd = new Date(slotStart.getTime() + (slot.duration_minutes || 30) * 6e4);
    const agentEvents = await sdk.asServiceRole.entities.CalendarEvent.filter({ assigned_to_id: slot.agent_id }, "start_datetime", 200);
    const hasConflict = agentEvents.some((event) => {
      if (event.status === "cancelado") return false;
      const eStart = new Date(event.start_datetime);
      const eEnd = new Date(event.end_datetime);
      return slotStart < eEnd && slotEnd > eStart;
    });
    if (hasConflict) return Response.json({ error: "El horario ya fue ocupado. Por favor elige otro." }, { status: 409 });
    const prospect = await sdk.asServiceRole.entities.Prospect.create({
      full_name: client_name,
      email: client_email,
      phone_raw: client_phone || null,
      assigned_agent_id: slot.agent_id,
      assigned_agent_name: slot.agent_name,
      source: "web",
      notes: notes ? `Cita agendada: ${notes}` : "Cita agendada desde landing de reserva"
    });
    const calendarEvent = await sdk.asServiceRole.entities.CalendarEvent.create({
      title: `${slot.title} - ${client_name}`,
      description: `Cita con ${client_name} (${client_email})${notes ? "\n\nNotas: " + notes : ""}`,
      event_type: "reunión",
      start_datetime: slotStart.toISOString(),
      end_datetime: slotEnd.toISOString(),
      assigned_to_id: slot.agent_id,
      assigned_to_name: slot.agent_name,
      attendees: client_email,
      status: "programado",
      prospect_id: prospect.id
    });
    await sdk.asServiceRole.entities.AppointmentSlot.update(slot_id, {
      status: "booked",
      booked_by_name: client_name,
      booked_by_email: client_email,
      booked_by_phone: client_phone || null,
      booked_at: (/* @__PURE__ */ new Date()).toISOString(),
      prospect_id: prospect.id,
      calendar_event_id: calendarEvent.id,
      notes: notes || null
    });
    let googleEventLink = null;
    const connections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      user_id: slot.agent_id,
      provider: "google",
      is_active: true
    });
    if (connections.length > 0) {
      const accessToken = await refreshTokenIfNeeded(connections[0], sdk);
      const googleEvent = {
        summary: `${slot.title} - ${client_name}`,
        description: `Cita agendada por ${client_name}
Email: ${client_email}${client_phone ? "\nTel: " + client_phone : ""}${notes ? "\nNotas: " + notes : ""}`,
        start: { dateTime: slotStart.toISOString(), timeZone: "America/Guayaquil" },
        end: { dateTime: slotEnd.toISOString(), timeZone: "America/Guayaquil" },
        attendees: [{ email: client_email }]
      };
      const gcalRes = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
        method: "POST",
        headers: { "Authorization": `Bearer ${accessToken}`, "Content-Type": "application/json" },
        body: JSON.stringify(googleEvent)
      });
      if (gcalRes.ok) {
        const gcalData = await gcalRes.json();
        googleEventLink = gcalData.htmlLink;
        await sdk.asServiceRole.entities.AppointmentSlot.update(slot_id, { google_event_id: gcalData.id });
        await sdk.asServiceRole.entities.CalendarEvent.update(calendarEvent.id, { google_event_id: gcalData.id });
      }
    }
    const resend = new Resend(process.env.RESEND_API_KEY);
    const dateStr = slotStart.toLocaleDateString("es-EC", { weekday: "long", year: "numeric", month: "long", day: "numeric", timeZone: "America/Guayaquil" });
    const timeStr = slotStart.toLocaleTimeString("es-EC", { hour: "2-digit", minute: "2-digit", timeZone: "America/Guayaquil" });
    const confirmationHtml = `<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/></head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:32px 16px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#171C28;padding:28px 32px;">
            <span style="font-size:26px;font-weight:700;font-family:'Helvetica Neue',Arial,sans-serif;">
              <span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span>
            </span>
          </td>
        </tr>
        <tr>
          <td style="padding:36px 32px 24px 32px;">
            <h2 style="margin:0 0 8px 0;color:#171C28;font-size:22px;">¡Tu cita está confirmada! ✅</h2>
            <p style="margin:0 0 24px 0;color:#64748b;font-size:14px;">Hola ${client_name}, hemos registrado tu cita con éxito.</p>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:20px 24px;margin-bottom:24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:6px 0;border-bottom:1px solid #e2e8f0;">
                  <span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Motivo</span><br/>
                  <span style="font-size:15px;color:#1e293b;font-weight:600;">${slot.title}</span>
                </td></tr>
                <tr><td style="padding:10px 0 6px 0;border-bottom:1px solid #e2e8f0;">
                  <span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Fecha</span><br/>
                  <span style="font-size:15px;color:#1e293b;font-weight:600;">${dateStr}</span>
                </td></tr>
                <tr><td style="padding:10px 0 6px 0;border-bottom:1px solid #e2e8f0;">
                  <span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Hora</span><br/>
                  <span style="font-size:15px;color:#1e293b;font-weight:600;">${timeStr} (Ecuador)</span>
                </td></tr>
                <tr><td style="padding:10px 0 0 0;">
                  <span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Agente</span><br/>
                  <span style="font-size:15px;color:#1e293b;font-weight:600;">${slot.agent_name}</span>
                </td></tr>
              </table>
            </div>
            ${slot.description ? `<p style="color:#475569;font-size:14px;margin:0 0 20px 0;">${slot.description}</p>` : ""}
            <p style="color:#94a3b8;font-size:13px;margin:0;">Si necesitas cancelar o reprogramar, por favor contacta directamente a tu agente. Te esperamos.</p>
          </td>
        </tr>
        <tr>
          <td style="background:#171C28;padding:20px 32px;">
            <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.5);">Este es un mensaje automático de InsurDesk</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
    await resend.emails.send({
      from: `${slot.agent_name} <${brand.address}>`,
      reply_to: slot.agent_email,
      to: [client_email],
      subject: `✅ Cita confirmada: ${slot.title} - ${dateStr}`,
      html: confirmationHtml
    });
    await sdk.asServiceRole.entities.Notification.create({
      user_id: slot.agent_id,
      user_email: slot.agent_email,
      type: "general",
      title: `Nueva cita agendada: ${client_name}`,
      message: `${client_name} (${client_email}) agendó una cita para el ${dateStr} a las ${timeStr}.`
    });
    return Response.json({
      success: true,
      message: "Cita reservada exitosamente",
      prospect_id: prospect.id,
      calendar_event_id: calendarEvent.id,
      google_event_link: googleEventLink
    });
  } catch (error) {
    console.error("Error booking appointment:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
