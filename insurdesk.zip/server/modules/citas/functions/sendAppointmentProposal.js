import { brand } from '../../../runtime/brand.js';
// Portado de sdk/functions/sendAppointmentProposal/entry.ts
import { config } from "../../../src/config.js";
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { Resend } from "../../../runtime/resend-compat.js";
import { getBusyRanges, hasConflict } from "../lib/bookingUtils.js";
async function refreshTokenIfNeeded(connection, sdk) {
  if (!connection.token_expiry) return connection.access_token;
  const expiryTime = new Date(connection.token_expiry);
  if (expiryTime.getTime() - Date.now() < 5 * 60 * 1e3) {
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.GOOGLE_OAUTH_CLIENT_ID,
        client_secret: process.env.GOOGLE_OAUTH_CLIENT_SECRET,
        refresh_token: connection.refresh_token,
        grant_type: "refresh_token"
      })
    });
    if (!tokenResponse.ok) return connection.access_token;
    const tokens = await tokenResponse.json();
    const newExpiry = new Date(Date.now() + (tokens.expires_in || 3600) * 1e3);
    await sdk.asServiceRole.entities.UserCalendarConnection.update(connection.id, {
      access_token: tokens.access_token,
      token_expiry: newExpiry.toISOString()
    });
    return tokens.access_token;
  }
  return connection.access_token;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "No autorizado" }, { status: 401 });
    const { client_name, client_email, client_phone, proposed_slots, title, description, duration_minutes, lead_id, prospect_id, app_url } = await req.json();
    if (!client_email || !proposed_slots || proposed_slots.length < 1 || !title) {
      return Response.json({ error: "Faltan campos: client_email, proposed_slots, title" }, { status: 400 });
    }
    const durMin = duration_minutes || 30;
    const slotDates = proposed_slots.map((s) => new Date(s.datetime).getTime());
    const rangeStart = new Date(Math.min(...slotDates));
    rangeStart.setHours(0, 0, 0, 0);
    const rangeEnd = new Date(Math.max(...slotDates) + durMin * 6e4);
    rangeEnd.setHours(23, 59, 59, 999);
    const busyRanges = await getBusyRanges(sdk, user.id, rangeStart, rangeEnd);
    const conflictingSlots = [];
    for (const slot of proposed_slots) {
      const slotStart = new Date(slot.datetime);
      const slotEnd = new Date(slotStart.getTime() + durMin * 6e4);
      if (slotStart <= /* @__PURE__ */ new Date()) {
        conflictingSlots.push(slot.datetime);
        continue;
      }
      if (hasConflict(slotStart, slotEnd, busyRanges)) {
        conflictingSlots.push(slot.datetime);
      }
    }
    if (conflictingSlots.length > 0) {
      return Response.json({
        error: "Algunos horarios tienen conflicto con tu calendario o ya están reservados",
        conflicting_slots: conflictingSlots
      }, { status: 409 });
    }
    const token = crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "");
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString();
    const proposal = await sdk.asServiceRole.entities.AppointmentRequest.create({
      token,
      status: "pending",
      agent_id: user.id,
      agent_name: user.full_name,
      agent_email: user.email,
      client_name: client_name || null,
      client_email,
      client_phone: client_phone || null,
      proposed_slots: proposed_slots.map((s) => ({ datetime: s.datetime, duration_minutes: durMin })),
      title,
      description: description || null,
      duration_minutes: durMin,
      lead_id: lead_id || null,
      prospect_id: prospect_id || null,
      expires_at: expiresAt,
      email_sent_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    const bookingUrl = `${app_url || config.appUrl}/PublicBooking?t=${token}`;
    const formatSlot = (slot) => {
      const dt = new Date(slot.datetime);
      const dateStr = dt.toLocaleDateString("es-EC", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        timeZone: "America/Guayaquil"
      });
      const timeStr = dt.toLocaleTimeString("es-EC", {
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "America/Guayaquil"
      });
      return `${dateStr} a las ${timeStr}`;
    };
    const slotsHtml = proposed_slots.map((slot, i) => `
      <tr>
        <td style="padding:10px 16px;border-bottom:1px solid #e2e8f0;">
          <span style="display:inline-block;width:24px;height:24px;background:#2F4F9D;color:white;border-radius:50%;text-align:center;line-height:24px;font-size:12px;font-weight:700;margin-right:10px;">${i + 1}</span>
          <span style="font-size:14px;color:#1e293b;font-weight:500;text-transform:capitalize;">${formatSlot(slot)}</span>
        </td>
      </tr>
    `).join("");
    const emailHtml = `<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/></head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:32px 16px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#171C28;padding:28px 32px;">
            <span style="font-size:26px;font-weight:700;">
              <span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span>
            </span>
          </td>
        </tr>
        <tr>
          <td style="padding:36px 32px 24px 32px;">
            <h2 style="margin:0 0 8px 0;color:#171C28;font-size:22px;">📅 ${user.full_name} te invita a una cita</h2>
            <p style="margin:0 0 24px 0;color:#64748b;font-size:14px;">${client_name ? `Hola ${client_name},` : "Hola,"} te ofrezco los siguientes horarios para <strong>${title}</strong>. Elige el que mejor te convenga:</p>
            
            <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;margin-bottom:28px;">
              ${slotsHtml}
            </table>

            ${description ? `<p style="color:#475569;font-size:14px;margin:0 0 24px 0;padding:16px;background:#f8fafc;border-radius:8px;border-left:3px solid #2F4F9D;">${description}</p>` : ""}

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
              <tr>
                <td align="center">
                  <a href="${bookingUrl}" style="display:inline-block;background:#2F4F9D;color:white;text-decoration:none;padding:16px 40px;border-radius:8px;font-size:16px;font-weight:700;">
                    Elegir mi horario →
                  </a>
                </td>
              </tr>
            </table>

            <p style="color:#94a3b8;font-size:12px;text-align:center;margin:0;">Este enlace expira en 7 días. Solo puede usarse una vez.</p>
          </td>
        </tr>
        <tr>
          <td style="background:#171C28;padding:20px 32px;">
            <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.5);">Enviado por ${user.full_name} · ${user.email}</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
    const resend = new Resend(process.env.RESEND_API_KEY);
    await resend.emails.send({
      from: `${user.full_name} <${brand.address}>`,
      reply_to: user.email,
      to: [client_email],
      subject: `📅 ${user.full_name} te propone horarios para: ${title}`,
      html: emailHtml
    });
    return Response.json({ success: true, proposal_id: proposal.id, token, booking_url: bookingUrl });
  } catch (error) {
    console.error("Error sending proposal:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
