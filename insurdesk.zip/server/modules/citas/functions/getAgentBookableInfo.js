// Portado de sdk/functions/getAgentBookableInfo/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { token } = await req.json();
    if (!token) {
      return Response.json({ error: "Token requerido" }, { status: 400 });
    }
    const configs = await sdk.asServiceRole.entities.AgentAvailability.filter({
      public_token: token,
      is_active: true
    });
    if (configs.length === 0) {
      return Response.json({ error: "Configuración no encontrada o inactiva" }, { status: 404 });
    }
    const config = configs[0];
    const availableDays = (config.schedule || []).map((s) => s.day_of_week);
    return Response.json({
      agent_name: config.agent_name,
      booking_title: config.booking_title || "Consulta",
      booking_description: config.booking_description || "",
      duration_minutes: config.duration_minutes || 30,
      available_days: availableDays,
      timezone: "America/Guayaquil (GMT-5)"
    });
  } catch (error) {
    console.error("Error in getAgentBookableInfo:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
