// Portado de sdk/functions/syncAllAgentCalendars/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { refreshTokenIfNeeded } from "../lib/bookingUtils.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const connections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      provider: "google",
      is_active: true
    }, void 0, 100);
    if (connections.length === 0) {
      return Response.json({ success: true, synced_agents: 0, message: "No hay calendarios conectados" });
    }
    const now = /* @__PURE__ */ new Date();
    const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1e3);
    const timeMin = now.toISOString();
    const timeMax = thirtyDaysLater.toISOString();
    let totalSynced = 0;
    let totalUpdated = 0;
    let totalCancelled = 0;
    const errors = [];
    for (const connection of connections) {
      try {
        let accessToken;
        try {
          accessToken = await refreshTokenIfNeeded(connection, sdk);
        } catch (tokenErr) {
          await sdk.asServiceRole.entities.UserCalendarConnection.update(connection.id, { is_active: false });
          errors.push({ agent_id: connection.user_id, error: "Token refresh failed — connection desactivada" });
          continue;
        }
        const gcalRes = await fetch(
          `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMin}&timeMax=${timeMax}&singleEvents=true&orderBy=startTime&maxResults=250`,
          { headers: { "Authorization": `Bearer ${accessToken}` } }
        );
        if (!gcalRes.ok) {
          errors.push({ agent_id: connection.user_id, error: `Google API error: ${gcalRes.status}` });
          continue;
        }
        const gcalData = await gcalRes.json();
        const googleEvents = gcalData.items || [];
        const existingEvents = await sdk.asServiceRole.entities.CalendarEvent.filter({
          assigned_to_id: connection.user_id
        }, "-start_datetime", 200);
        const existingByGoogleId = /* @__PURE__ */ new Map();
        for (const e of existingEvents) {
          if (e.google_event_id) existingByGoogleId.set(e.google_event_id, e);
        }
        const newEvents = [];
        const updates = [];
        const seenGoogleIds = /* @__PURE__ */ new Set();
        for (const gEvent of googleEvents) {
          seenGoogleIds.add(gEvent.id);
          const startDateTime = gEvent.start?.dateTime || gEvent.start?.date;
          const endDateTime = gEvent.end?.dateTime || gEvent.end?.date;
          if (!startDateTime || !endDateTime) continue;
          const existing = existingByGoogleId.get(gEvent.id);
          if (!existing) {
            newEvents.push({
              title: gEvent.summary || "Sin título",
              description: gEvent.description || "",
              event_type: "otro",
              start_datetime: startDateTime,
              end_datetime: endDateTime,
              google_event_id: gEvent.id,
              assigned_to_id: connection.user_id,
              assigned_to_name: connection.full_name || "",
              location: gEvent.location || "",
              status: gEvent.status === "cancelled" ? "cancelado" : "programado"
            });
          } else {
            const needsUpdate = existing.title !== (gEvent.summary || "Sin título") || existing.start_datetime !== startDateTime || existing.end_datetime !== endDateTime || gEvent.status === "cancelled" && existing.status !== "cancelado";
            if (needsUpdate) {
              updates.push({
                id: existing.id,
                title: gEvent.summary || "Sin título",
                description: gEvent.description || existing.description || "",
                start_datetime: startDateTime,
                end_datetime: endDateTime,
                location: gEvent.location || existing.location || "",
                status: gEvent.status === "cancelled" ? "cancelado" : existing.status
              });
            }
          }
        }
        const cancellations = [];
        for (const [gId, existing] of existingByGoogleId) {
          if (!seenGoogleIds.has(gId) && existing.status === "programado") {
            const eventStart = new Date(existing.start_datetime);
            if (eventStart >= now && eventStart <= thirtyDaysLater) {
              cancellations.push(existing.id);
            }
          }
        }
        if (newEvents.length > 0) {
          await sdk.asServiceRole.entities.CalendarEvent.bulkCreate(newEvents);
          totalSynced += newEvents.length;
        }
        if (updates.length > 0) {
          await sdk.asServiceRole.entities.CalendarEvent.bulkUpdate(updates);
          totalUpdated += updates.length;
        }
        for (const eventId of cancellations) {
          try {
            await sdk.asServiceRole.entities.CalendarEvent.update(eventId, { status: "cancelado" });
            totalCancelled++;
          } catch (_) {
          }
        }
      } catch (agentErr) {
        errors.push({ agent_id: connection.user_id, error: agentErr.message });
      }
    }
    return Response.json({
      success: true,
      agents_processed: connections.length,
      new_events: totalSynced,
      updated_events: totalUpdated,
      cancelled_events: totalCancelled,
      errors: errors.length > 0 ? errors : void 0
    });
  } catch (error) {
    console.error("Error in syncAllAgentCalendars:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
