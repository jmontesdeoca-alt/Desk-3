// Portado de sdk/functions/createUserGoogleCalendarEvent/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
async function refreshTokenIfNeeded(connection, sdk) {
  if (!connection.token_expiry) return connection.access_token;
  const expiryTime = new Date(connection.token_expiry);
  const now = /* @__PURE__ */ new Date();
  if (expiryTime.getTime() - now.getTime() < 5 * 60 * 1e3) {
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
    if (!connection.refresh_token) {
      throw new Error("No hay refresh token. El usuario debe reconectar su Google Calendar.");
    }
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: connection.refresh_token,
        grant_type: "refresh_token"
      })
    });
    if (!tokenResponse.ok) {
      const err = await tokenResponse.text();
      throw new Error("Failed to refresh token: " + err);
    }
    const tokens = await tokenResponse.json();
    const newExpiry = new Date(Date.now() + (tokens.expires_in || 3600) * 1e3);
    await sdk.asServiceRole.entities.UserCalendarConnection.update(connection.id, {
      access_token: tokens.access_token,
      token_expiry: newExpiry.toISOString()
    });
    return tokens.access_token;
  }
  return connection.access_token;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { eventData } = await req.json();
    if (!eventData || !eventData.title || !eventData.start_datetime || !eventData.end_datetime) {
      return Response.json({ error: "Faltan campos requeridos" }, { status: 400 });
    }
    const dbEventData = {
      title: eventData.title,
      description: eventData.description || "",
      event_type: eventData.event_type || "reunión",
      start_datetime: eventData.start_datetime,
      end_datetime: eventData.end_datetime,
      lead_id: eventData.lead_id || null,
      lead_name: eventData.lead_name || null,
      prospect_id: eventData.prospect_id || null,
      assigned_to_id: user.id,
      assigned_to_name: user.full_name,
      location: eventData.location || null,
      attendees: eventData.attendees || null,
      status: "programado"
    };
    const dbEvent = await sdk.asServiceRole.entities.CalendarEvent.create(dbEventData);
    const assignedUserId = user.id;
    const connections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      user_id: assignedUserId,
      provider: "google",
      is_active: true
    });
    if (connections.length > 0) {
      const connection = connections[0];
      const accessToken = await refreshTokenIfNeeded(connection, sdk);
      const googleEvent = {
        summary: eventData.title,
        description: eventData.description || "",
        location: eventData.location || "",
        start: {
          dateTime: eventData.start_datetime,
          timeZone: "America/Guayaquil"
        },
        end: {
          dateTime: eventData.end_datetime,
          timeZone: "America/Guayaquil"
        }
      };
      if (eventData.attendees) {
        googleEvent.attendees = eventData.attendees.split(",").map((email) => ({
          email: email.trim()
        }));
      }
      const calendarResponse = await fetch(
        "https://www.googleapis.com/calendar/v3/calendars/primary/events",
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(googleEvent)
        }
      );
      if (calendarResponse.ok) {
        const createdGoogleEvent = await calendarResponse.json();
        await sdk.asServiceRole.entities.CalendarEvent.update(dbEvent.id, {
          google_event_id: createdGoogleEvent.id
        });
        return Response.json({
          success: true,
          event: { ...dbEvent, google_event_id: createdGoogleEvent.id },
          google_event_link: createdGoogleEvent.htmlLink,
          synced_to_google: true
        });
      } else {
        const errorText = await calendarResponse.text();
        console.error("Google Calendar sync error:", errorText);
      }
    }
    return Response.json({
      success: true,
      event: dbEvent,
      synced_to_google: false,
      message: "Evento creado. Conecta tu Google Calendar para sincronización automática."
    });
  } catch (error) {
    console.error("Error creating calendar event:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
