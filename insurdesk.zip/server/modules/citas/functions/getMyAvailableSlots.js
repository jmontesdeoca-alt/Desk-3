// Portado de sdk/functions/getMyAvailableSlots/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { createEcuadorTime, getBusyRanges, generateDaySlots } from "../lib/bookingUtils.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) return Response.json({ error: "No autorizado" }, { status: 401 });
    const configs = await sdk.asServiceRole.entities.AgentAvailability.filter({
      agent_id: user.id,
      is_active: true
    });
    if (configs.length === 0) {
      return Response.json({ has_availability_config: false, days: [] });
    }
    const config = configs[0];
    const nowStr = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "America/Guayaquil" });
    const [y0, m0, d0] = nowStr.split("-").map(Number);
    const todayMidnight = createEcuadorTime(y0, m0, d0, 0, 0);
    const days = [];
    for (let dayOffset = 0; dayOffset < 14; dayOffset++) {
      const dateObj = new Date(todayMidnight.getTime() + dayOffset * 24 * 60 * 60 * 1e3);
      const dayOfWeek = dateObj.getDay();
      const hasSchedule = (config.schedule || []).some((s) => s.day_of_week === dayOfWeek && s.time_slots && s.time_slots.length > 0);
      if (!hasSchedule) continue;
      const ecuadorDateStr = dateObj.toLocaleDateString("en-CA", { timeZone: "America/Guayaquil" });
      const [year, month, day] = ecuadorDateStr.split("-").map(Number);
      const dayStart = createEcuadorTime(year, month, day, 0, 0);
      const dayEnd = createEcuadorTime(year, month, day, 23, 59);
      const busyRanges = await getBusyRanges(sdk, user.id, dayStart, dayEnd);
      const daySlots = generateDaySlots(config, year, month, day, busyRanges);
      if (daySlots.length > 0) {
        days.push({ date: ecuadorDateStr, slots: daySlots });
      }
    }
    return Response.json({
      has_availability_config: true,
      duration_minutes: config.duration_minutes || 30,
      days
    });
  } catch (error) {
    console.error("Error in getMyAvailableSlots:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
