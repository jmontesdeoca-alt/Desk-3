// Portado de sdk/functions/syncUserGoogleCalendar/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
async function refreshTokenIfNeeded(connection, sdk) {
  if (!connection.token_expiry) return connection.access_token;
  const expiryTime = new Date(connection.token_expiry);
  const now = /* @__PURE__ */ new Date();
  if (expiryTime.getTime() - now.getTime() < 5 * 60 * 1e3) {
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
    if (!connection.refresh_token) {
      throw new Error("No hay refresh token. El usuario debe reconectar su Google Calendar.");
    }
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: connection.refresh_token,
        grant_type: "refresh_token"
      })
    });
    if (!tokenResponse.ok) {
      const err = await tokenResponse.text();
      throw new Error("Failed to refresh token: " + err);
    }
    const tokens = await tokenResponse.json();
    const newExpiry = new Date(Date.now() + (tokens.expires_in || 3600) * 1e3);
    await sdk.asServiceRole.entities.UserCalendarConnection.update(connection.id, {
      access_token: tokens.access_token,
      token_expiry: newExpiry.toISOString()
    });
    return tokens.access_token;
  }
  return connection.access_token;
}
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const user = await sdk.auth.me();
    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const connections = await sdk.asServiceRole.entities.UserCalendarConnection.filter({
      user_id: user.id,
      provider: "google",
      is_active: true
    });
    if (connections.length === 0) {
      return Response.json({ error: "No tienes Google Calendar conectado" }, { status: 403 });
    }
    const connection = connections[0];
    const accessToken = await refreshTokenIfNeeded(connection, sdk);
    const now = /* @__PURE__ */ new Date();
    const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1e3);
    const calendarResponse = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${now.toISOString()}&timeMax=${thirtyDaysLater.toISOString()}&singleEvents=true&orderBy=startTime`,
      {
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json"
        }
      }
    );
    if (!calendarResponse.ok) {
      const error = await calendarResponse.text();
      console.error("Google Calendar error:", error);
      return Response.json({ error: "Error al acceder a Google Calendar", details: error }, { status: 500 });
    }
    const data = await calendarResponse.json();
    const googleEvents = data.items || [];
    const existingEvents = await sdk.asServiceRole.entities.CalendarEvent.filter({
      assigned_to_id: user.id
    }, "-start_datetime", 200);
    const existingGoogleIds = new Set(existingEvents.map((e) => e.google_event_id).filter(Boolean));
    const newEvents = [];
    for (const gEvent of googleEvents) {
      if (!existingGoogleIds.has(gEvent.id)) {
        const startDateTime = gEvent.start?.dateTime || gEvent.start?.date;
        const endDateTime = gEvent.end?.dateTime || gEvent.end?.date;
        if (!startDateTime || !endDateTime) continue;
        newEvents.push({
          title: gEvent.summary || "Sin título",
          description: gEvent.description || "",
          event_type: "otro",
          start_datetime: startDateTime,
          end_datetime: endDateTime,
          google_event_id: gEvent.id,
          assigned_to_id: user.id,
          assigned_to_name: user.full_name,
          location: gEvent.location || "",
          status: "programado"
        });
      }
    }
    if (newEvents.length > 0) {
      await sdk.asServiceRole.entities.CalendarEvent.bulkCreate(newEvents);
    }
    return Response.json({
      success: true,
      synced: newEvents.length,
      message: `Se sincronizaron ${newEvents.length} eventos nuevos desde tu Google Calendar`
    });
  } catch (error) {
    console.error("Error syncing calendar:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
