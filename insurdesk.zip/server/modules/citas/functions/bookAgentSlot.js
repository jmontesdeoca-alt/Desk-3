import { brand } from '../../../runtime/brand.js';
// Portado de sdk/functions/bookAgentSlot/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { Resend } from "../../../runtime/resend-compat.js";
import { createEcuadorTime, getBusyRanges, hasConflict, getGoogleConnection, refreshTokenIfNeeded } from "../lib/bookingUtils.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { token, datetime, client_name, client_email, client_phone, notes } = await req.json();
    if (!token || !datetime || !client_name || !client_email) {
      return Response.json({ error: "Faltan campos requeridos: token, datetime, client_name, client_email" }, { status: 400 });
    }
    const configs = await sdk.asServiceRole.entities.AgentAvailability.filter({
      public_token: token,
      is_active: true
    });
    if (configs.length === 0) {
      return Response.json({ error: "Configuración no encontrada" }, { status: 404 });
    }
    const config = configs[0];
    const slotStart = new Date(datetime);
    const durationMs = (config.duration_minutes || 30) * 6e4;
    const slotEnd = new Date(slotStart.getTime() + durationMs);
    if (slotStart <= /* @__PURE__ */ new Date()) {
      return Response.json({ error: "Este horario ya pasó" }, { status: 409 });
    }
    const [datePart, timePart] = datetime.split("T");
    const [year, month, day] = datePart.split("-").map(Number);
    const [hours, minutes] = timePart.split(":").map(Number);
    const slotDate = createEcuadorTime(year, month, day, 0, 0);
    const dayOfWeek = slotDate.getDay();
    const daySchedule = (config.schedule || []).find((s) => s.day_of_week === dayOfWeek);
    if (!daySchedule || !daySchedule.time_slots) {
      return Response.json({ error: "El agente no atiende este día" }, { status: 409 });
    }
    const slotTime = createEcuadorTime(year, month, day, hours, minutes);
    const isInSchedule = daySchedule.time_slots.some((range) => {
      const [sH, sM] = range.start_time.split(":").map(Number);
      const [eH, eM] = range.end_time.split(":").map(Number);
      const rangeStart = createEcuadorTime(year, month, day, sH, sM);
      const rangeEnd = createEcuadorTime(year, month, day, eH, eM);
      return slotTime >= rangeStart && slotEnd <= rangeEnd;
    });
    if (!isInSchedule) {
      return Response.json({ error: "Este horario no está dentro del horario de atención" }, { status: 409 });
    }
    const dayStart = createEcuadorTime(year, month, day, 0, 0);
    const dayEnd = createEcuadorTime(year, month, day, 23, 59);
    const busyRanges = await getBusyRanges(sdk, config.agent_id, dayStart, dayEnd);
    if (hasConflict(slotStart, slotEnd, busyRanges)) {
      return Response.json({ error: "El horario acaba de ser ocupado. Por favor elige otro." }, { status: 409 });
    }
    const prospect = await sdk.asServiceRole.entities.Prospect.create({
      full_name: client_name,
      email: client_email,
      phone_raw: client_phone || null,
      assigned_agent_id: config.agent_id,
      assigned_agent_name: config.agent_name,
      source: "web",
      notes: notes ? `Cita agendada: ${notes}` : "Cita agendada desde landing de reserva"
    });
    const title = config.booking_title || "Consulta";
    const calendarEvent = await sdk.asServiceRole.entities.CalendarEvent.create({
      title: `${title} - ${client_name}`,
      description: `Cita con ${client_name} (${client_email})${client_phone ? "\nTel: " + client_phone : ""}${notes ? "\n\nNotas: " + notes : ""}`,
      event_type: "reunión",
      start_datetime: slotStart.toISOString(),
      end_datetime: slotEnd.toISOString(),
      assigned_to_id: config.agent_id,
      assigned_to_name: config.agent_name,
      attendees: client_email,
      status: "programado",
      prospect_id: prospect.id
    });
    let googleEventLink = null;
    const connection = await getGoogleConnection(sdk, config.agent_id);
    if (connection) {
      try {
        const accessToken = await refreshTokenIfNeeded(connection, sdk);
        const googleEvent = {
          summary: `${title} - ${client_name}`,
          description: `Cita agendada por ${client_name}
Email: ${client_email}${client_phone ? "\nTel: " + client_phone : ""}${notes ? "\nNotas: " + notes : ""}`,
          start: { dateTime: slotStart.toISOString(), timeZone: "America/Guayaquil" },
          end: { dateTime: slotEnd.toISOString(), timeZone: "America/Guayaquil" },
          attendees: [{ email: client_email }]
        };
        const gcalRes = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
          method: "POST",
          headers: { "Authorization": `Bearer ${accessToken}`, "Content-Type": "application/json" },
          body: JSON.stringify(googleEvent)
        });
        if (gcalRes.ok) {
          const gcalData = await gcalRes.json();
          googleEventLink = gcalData.htmlLink;
          await sdk.asServiceRole.entities.CalendarEvent.update(calendarEvent.id, { google_event_id: gcalData.id });
        }
      } catch (gcalErr) {
        console.error("Google Calendar event creation failed:", gcalErr);
      }
    }
    const resend = new Resend(process.env.RESEND_API_KEY);
    const dateStr = slotStart.toLocaleDateString("es-EC", { weekday: "long", year: "numeric", month: "long", day: "numeric", timeZone: "America/Guayaquil" });
    const timeStr = slotStart.toLocaleTimeString("es-EC", { hour: "2-digit", minute: "2-digit", timeZone: "America/Guayaquil" });
    const confirmationHtml = `<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/></head>
<body style="margin:0;padding:0;background-color:#f1f5f9;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:32px 16px;"><tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
<tr><td style="background:#171C28;padding:28px 32px;">
<span style="font-size:26px;font-weight:700;"><span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span></span>
</td></tr>
<tr><td style="padding:36px 32px 24px 32px;">
<h2 style="margin:0 0 8px 0;color:#171C28;font-size:22px;">¡Tu cita está confirmada! ✅</h2>
<p style="margin:0 0 24px 0;color:#64748b;font-size:14px;">Hola ${client_name}, hemos registrado tu cita con éxito.</p>
<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:20px 24px;margin-bottom:24px;">
<table width="100%" cellpadding="0" cellspacing="0">
<tr><td style="padding:6px 0;border-bottom:1px solid #e2e8f0;">
<span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Motivo</span><br/>
<span style="font-size:15px;color:#1e293b;font-weight:600;">${title}</span>
</td></tr>
<tr><td style="padding:10px 0 6px 0;border-bottom:1px solid #e2e8f0;">
<span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Fecha</span><br/>
<span style="font-size:15px;color:#1e293b;font-weight:600;">${dateStr}</span>
</td></tr>
<tr><td style="padding:10px 0 6px 0;border-bottom:1px solid #e2e8f0;">
<span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Hora</span><br/>
<span style="font-size:15px;color:#1e293b;font-weight:600;">${timeStr} (Ecuador)</span>
</td></tr>
<tr><td style="padding:10px 0 0 0;">
<span style="font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Agente</span><br/>
<span style="font-size:15px;color:#1e293b;font-weight:600;">${config.agent_name}</span>
</td></tr>
</table>
</div>
<p style="color:#94a3b8;font-size:13px;margin:0;">Si necesitas cancelar o reprogramar, por favor contacta directamente a tu agente. Te esperamos.</p>
</td></tr>
<tr><td style="background:#171C28;padding:20px 32px;">
<p style="margin:0;font-size:12px;color:rgba(255,255,255,0.5);">Este es un mensaje automático de InsurDesk</p>
</td></tr>
</table>
</td></tr></table>
</body></html>`;
    await resend.emails.send({
      from: `${config.agent_name} <${brand.address}>`,
      reply_to: config.agent_email,
      to: [client_email],
      subject: `✅ Cita confirmada: ${title} - ${dateStr}`,
      html: confirmationHtml
    });
    await sdk.asServiceRole.entities.Notification.create({
      user_id: config.agent_id,
      user_email: config.agent_email,
      type: "general",
      title: `Nueva cita agendada: ${client_name}`,
      message: `${client_name} (${client_email}) agendó una cita para el ${dateStr} a las ${timeStr}.`
    });
    return Response.json({
      success: true,
      message: "Cita reservada exitosamente",
      title,
      confirmed_datetime: slotStart.toISOString(),
      agent_name: config.agent_name,
      calendar_event_id: calendarEvent.id,
      google_event_link: googleEventLink
    });
  } catch (error) {
    console.error("Error in bookAgentSlot:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
