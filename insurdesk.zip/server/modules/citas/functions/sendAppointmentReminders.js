import { brand } from '../../../runtime/brand.js';
// Portado de sdk/functions/sendAppointmentReminders/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { Resend } from "../../../runtime/resend-compat.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const isAuthenticated = await sdk.auth.isAuthenticated();
    if (!isAuthenticated) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const now = /* @__PURE__ */ new Date();
    const resend = new Resend(process.env.RESEND_API_KEY);
    const confirmed = await sdk.asServiceRole.entities.AppointmentRequest.filter(
      { status: "confirmed" },
      "confirmed_datetime",
      500
    );
    let sent24h = 0;
    let sent1h = 0;
    for (const appt of confirmed) {
      if (!appt.confirmed_datetime) continue;
      const apptTime = new Date(appt.confirmed_datetime);
      const hoursUntil = (apptTime - now) / (1e3 * 60 * 60);
      const clientName = appt.client_name || "Cliente";
      const agentName = appt.agent_name || "Tu asesor";
      const dateStr = apptTime.toLocaleDateString("es-EC", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        timeZone: "America/Guayaquil"
      });
      const timeStr = apptTime.toLocaleTimeString("es-EC", {
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "America/Guayaquil"
      });
      const reminderHtml = (heading, intro) => `<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"/></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Helvetica Neue',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
        <tr><td style="background:#171C28;padding:28px 32px;">
          <span style="font-size:26px;font-weight:700;"><span style="color:#ffffff;">Desk</span><span style="color:#9DB1E3;font-weight:400;">CRM</span></span>
        </td></tr>
        <tr><td style="padding:36px 32px;">
          <h2 style="margin:0 0 8px 0;color:#171C28;font-size:22px;">${heading}</h2>
          <p style="margin:0 0 24px 0;color:#64748b;font-size:14px;">${intro}</p>
          <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:20px 24px;margin-bottom:24px;">
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Motivo</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;">${appt.title}</p>
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Fecha</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;text-transform:capitalize;">${dateStr}</p>
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Hora</p>
            <p style="margin:0 0 16px 0;font-size:15px;color:#1e293b;font-weight:600;">${timeStr} (Ecuador)</p>
            <p style="margin:0 0 8px 0;font-size:12px;color:#94a3b8;text-transform:uppercase;font-weight:600;">Tu asesor</p>
            <p style="margin:0;font-size:15px;color:#1e293b;font-weight:600;">${agentName}</p>
          </div>
          <p style="color:#94a3b8;font-size:13px;margin:0;">Para cancelar o cambiar la cita, contacta a ${agentName} en ${appt.agent_email || ""}</p>
        </td></tr>
        <tr><td style="background:#171C28;padding:20px 32px;">
          <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.5);">Mensaje automático de InsurDesk</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
      if (!appt.reminder_24h_sent && hoursUntil >= 23 && hoursUntil <= 25) {
        const r24payload = {
          from: `${agentName} <${brand.address}>`,
          reply_to: appt.agent_email,
          to: [appt.client_email],
          subject: `⏰ Recordatorio: tu cita mañana — ${appt.title}`,
          html: reminderHtml("⏰ Tu cita es mañana", `Hola ${clientName}, te recordamos que tienes una cita programada para mañana.`)
        };
        if (appt.agent_email) r24payload.cc = [appt.agent_email];
        await resend.emails.send(r24payload);
        await sdk.asServiceRole.entities.AppointmentRequest.update(appt.id, {
          reminder_24h_sent: true
        });
        sent24h++;
      }
      if (!appt.reminder_1h_sent && hoursUntil >= 0.916 && hoursUntil <= 1.083) {
        const r1payload = {
          from: `${agentName} <${brand.address}>`,
          reply_to: appt.agent_email,
          to: [appt.client_email],
          subject: `🔔 Tu cita comienza en 1 hora — ${appt.title}`,
          html: reminderHtml("🔔 Tu cita es en 1 hora", `Hola ${clientName}, tu cita comienza en aproximadamente 1 hora. ¡Que todo salga bien!`)
        };
        if (appt.agent_email) r1payload.cc = [appt.agent_email];
        await resend.emails.send(r1payload);
        await sdk.asServiceRole.entities.AppointmentRequest.update(appt.id, {
          reminder_1h_sent: true
        });
        sent1h++;
      }
    }
    return Response.json({
      success: true,
      processed: confirmed.length,
      sent_24h: sent24h,
      sent_1h: sent1h,
      timestamp: now.toISOString()
    });
  } catch (error) {
    console.error("Error sending reminders:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
