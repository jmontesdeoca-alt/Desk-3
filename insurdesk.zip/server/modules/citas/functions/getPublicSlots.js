// Portado de sdk/functions/getPublicSlots/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  try {
    const sdk = createClientFromRequest(req);
    const { agent_id, token } = await req.json();
    if (!agent_id && !token) {
      return Response.json({ error: "Se requiere agent_id o token" }, { status: 400 });
    }
    const query = token ? { public_token: token, status: "available" } : { agent_id, status: "available" };
    const slots = await sdk.asServiceRole.entities.AppointmentSlot.filter(query, "datetime", 50);
    const now = /* @__PURE__ */ new Date();
    const futureSlots = slots.filter((s) => new Date(s.datetime) > now);
    const agentId = futureSlots.length > 0 ? futureSlots[0].agent_id : agent_id;
    const agentEvents = await sdk.asServiceRole.entities.CalendarEvent.filter({
      assigned_to_id: agentId
    }, "start_datetime", 200);
    const availableSlots = futureSlots.filter((slot) => {
      const slotStart = new Date(slot.datetime);
      const slotEnd = new Date(slotStart.getTime() + (slot.duration_minutes || 30) * 6e4);
      const hasConflict = agentEvents.some((event) => {
        if (event.status === "cancelado") return false;
        const eventStart = new Date(event.start_datetime);
        const eventEnd = new Date(event.end_datetime);
        return slotStart < eventEnd && slotEnd > eventStart;
      });
      return !hasConflict;
    });
    const publicSlots = availableSlots.map((s) => ({
      id: s.id,
      datetime: s.datetime,
      duration_minutes: s.duration_minutes || 30,
      title: s.title,
      description: s.description,
      agent_name: s.agent_name,
      public_token: s.public_token
    }));
    return Response.json({ slots: publicSlots });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
