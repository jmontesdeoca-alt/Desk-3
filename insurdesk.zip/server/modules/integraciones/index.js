// Módulo Integraciones (Meta, WhatsApp, formularios web).
import { installMetaHooks } from './lib/meta.js';

export function register(ctx) {
  // Lead creado / cambio de etapa → eventos de la API de conversiones de Meta
  installMetaHooks(ctx.onEntity);
  // Servicio para otros módulos (p. ej. la acción "Enviar conversión a Meta" de las automatizaciones)
  ctx.services.provide('meta.sendConversion', (payload) => ctx.invokeFunction('sendMetaConversionEvent', payload));
}
