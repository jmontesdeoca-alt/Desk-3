// Envía al CRM un aviso de lead FIRMADO igual que lo haría Meta. Sirve para probar tu servidor sin esperar a Meta.
//   node server/dev/send-webhook.js --url http://localhost:3001 --secret TU_APP_SECRET --leadgen 444000111 --form form_1 --page 1111111111
import crypto from 'node:crypto';

const a = Object.fromEntries(process.argv.slice(2).reduce((acc, v, i, arr) => (v.startsWith('--') ? [...acc, [v.slice(2), arr[i + 1]]] : acc), []));
const url = (a.url || 'http://localhost:3001').replace(/\/+$/, '') + '/api/functions/metaWebhook';
if (!a.secret) { console.error('Falta --secret (el App Secret de tu app de Meta)'); process.exit(1); }

const payload = JSON.stringify({
  object: 'page',
  entry: [{ id: a.page || '1111111111', time: Math.floor(Date.now() / 1000), changes: [{ field: 'leadgen', value: {
    leadgen_id: a.leadgen || String(Date.now()), page_id: a.page || '1111111111', form_id: a.form || 'form_1',
    ad_id: a.ad || '', adgroup_id: a.adset || '', created_time: Math.floor(Date.now() / 1000) } }] }],
});
const signature = 'sha256=' + crypto.createHmac('sha256', a.secret).update(payload).digest('hex');
const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', 'x-hub-signature-256': a.bad ? 'sha256=firma_falsa' : signature }, body: payload });
console.log(res.status, await res.text());
