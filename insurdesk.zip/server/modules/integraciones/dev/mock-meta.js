// Servidor "Meta" de mentira para PROBAR sin cuenta de Meta (desarrollo y demos).
// Imita lo mínimo de la Graph API: /me, /debug_token, páginas y suscripciones, leads, formularios y /{pixel}/events.
// Uso:  node server/dev/mock-meta.js      (puerto 4010)    →  arranca el CRM con META_GRAPH_URL=http://localhost:4010/v21.0
import http from 'node:http';

const PORT = Number(process.env.MOCK_META_PORT || 4010);
const GOOD = process.env.MOCK_META_TOKEN || 'TOKEN_VALIDO';
const APP_ID = process.env.MOCK_META_APP_ID || '1234567890';
const PAGE_ID = process.env.MOCK_META_PAGE_ID || '1111111111';
const PIXEL_ID = process.env.MOCK_META_PIXEL_ID || '9999999999';

const state = { subscribed: false, leads: new Map(), events: [], failLeadFetch: 0, expired: false };

const json = (res, code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
const err = (res, code, message, errCode) => json(res, code, { error: { message, type: 'OAuthException', code: errCode } });
const body = (req) => new Promise((r) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });

const page = () => `<!doctype html><meta charset="utf-8"><title>Meta · Events Manager (simulado)</title>
<style>body{font:14px system-ui;background:#f0f2f5;margin:0;color:#1c1e21}header{background:#1877f2;color:#fff;padding:14px 24px;font-weight:700;font-size:18px}
main{max-width:1100px;margin:20px auto;padding:0 16px}h2{margin:18px 0 8px}table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px #0002}
th,td{padding:9px 12px;text-align:left;border-bottom:1px solid #e4e6eb;vertical-align:top}th{background:#f7f8fa;font-size:12px;text-transform:uppercase;color:#65676b}
.pill{display:inline-block;padding:2px 9px;border-radius:99px;background:#e7f3ff;color:#1877f2;font-weight:600;font-size:12px}.ok{background:#e6f4ea;color:#188038}
code{font:12px ui-monospace,monospace;background:#f0f2f5;padding:1px 5px;border-radius:4px;word-break:break-all}.muted{color:#65676b}</style>
<header>Meta · Events Manager <span class="muted" style="color:#cfe3ff;font-weight:400">(servidor simulado para pruebas)</span></header><main>
<p class="muted">Pixel <b>${PIXEL_ID}</b> · Página <b>${PAGE_ID}</b> · Suscripción a leadgen: <span class="pill ${state.subscribed ? 'ok' : ''}">${state.subscribed ? 'ACTIVA' : 'no suscrita'}</span></p>
<h2>Eventos recibidos (${state.events.length})</h2>
<table><tr><th>Hora</th><th>Evento</th><th>Origen</th><th>lead_id / fbp</th><th>Datos de usuario (hasheados)</th><th>Valor</th><th>event_id</th></tr>
${state.events.slice().reverse().map((e) => { const u = e.user_data || {}; return `<tr><td>${new Date(e.received_at).toLocaleTimeString('es-EC')}</td><td><span class="pill">${e.event_name}</span>${e.test_event_code ? ' <span class="muted">(prueba)</span>' : ''}</td>
<td>${e.action_source}${e.custom_data?.event_source ? ' · ' + e.custom_data.event_source : ''}</td><td><code>${u.lead_id || u.fbp || '—'}</code></td>
<td>${['em', 'ph', 'fn', 'ln', 'external_id'].filter((k) => u[k]).map((k) => `${k}: <code>${String(u[k][0]).slice(0, 10)}…</code>`).join('<br>') || '—'}</td>
<td>${e.custom_data?.value != null ? e.custom_data.currency + ' ' + e.custom_data.value : '—'}</td><td><code>${e.event_id || '—'}</code></td></tr>`; }).join('') || '<tr><td colspan="7" class="muted">Sin eventos todavía</td></tr>'}
</table></main>`;

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname.replace(/^\/v\d+\.\d+/, '');
  const token = url.searchParams.get('access_token') || '';
  const q = (k) => url.searchParams.get(k);

  // ── Utilidades de la demo
  if (path === '/' || path === '/events') { res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); return res.end(page()); }
  if (path === '/__events') return json(res, 200, state.events);
  if (path === '/__state') return json(res, 200, { ...state, leads: [...state.leads.keys()] });
  if (path === '/__lead' && req.method === 'POST') { const l = await body(req); state.leads.set(l.id, l); return json(res, 200, { ok: true }); }
  if (path === '/__fail' && req.method === 'POST') { const b = await body(req); state.failLeadFetch = b.times ?? 1; state.expired = !!b.expired; return json(res, 200, { ok: true }); }
  if (path === '/__reset' && req.method === 'POST') { state.events = []; state.subscribed = false; state.leads.clear(); state.failLeadFetch = 0; state.expired = false; return json(res, 200, { ok: true }); }

  // ── Graph API simulada
  if (path === '/debug_token') {
    const input = q('input_token');
    if (input !== GOOD || state.expired) return json(res, 200, { data: { is_valid: false } });
    return json(res, 200, { data: { app_id: APP_ID, is_valid: true, expires_at: 0, scopes: ['leads_retrieval', 'pages_manage_metadata', 'pages_show_list', 'ads_management'] } });
  }
  if (!token.split('|')[1] && token !== GOOD) return err(res, 400, 'Invalid OAuth access token - Cannot parse access token', 190);
  if (state.expired && token === GOOD) return err(res, 400, 'Error validating access token: Session has expired', 190);

  if (path === '/me') return json(res, 200, { id: '17841400000', name: 'Sistema CRM (usuario del sistema)' });
  if (path === `/${PAGE_ID}` ) return json(res, 200, { id: PAGE_ID, name: 'Seguros Demo Ecuador', access_token: GOOD });
  if (path === `/${PAGE_ID}/subscribed_apps`) {
    if (req.method === 'POST') { state.subscribed = true; return json(res, 200, { success: true }); }
    return json(res, 200, { data: state.subscribed ? [{ id: APP_ID, name: 'CRM Leads', subscribed_fields: ['leadgen'] }] : [] });
  }
  if (path === `/${PIXEL_ID}`) return json(res, 200, { id: PIXEL_ID, name: 'Pixel Seguros Demo' });
  if (path === `/${PIXEL_ID}/events` && req.method === 'POST') {
    const b = await body(req);
    for (const e of b.data || []) state.events.push({ ...e, test_event_code: b.test_event_code, received_at: Date.now() });
    return json(res, 200, { events_received: (b.data || []).length, messages: [], fbtrace_id: 'MOCK' + Math.random().toString(36).slice(2, 8).toUpperCase() });
  }
  const form = path.match(/^\/(form_\d+)$/);
  if (form) return json(res, 200, { id: form[1], name: 'Cotiza tu Seguro de Vida' });
  const id = path.slice(1);
  if (state.leads.has(id)) {
    if (state.failLeadFetch > 0) { state.failLeadFetch--; return err(res, 500, 'An unexpected error has occurred. Please retry your request later.', 2); }
    return json(res, 200, state.leads.get(id));
  }
  return err(res, 400, `Unsupported get request. Object with ID '${id}' does not exist`, 100);
}).listen(PORT, () => console.log(`Meta simulado en http://localhost:${PORT}  (token válido: ${GOOD}, página ${PAGE_ID}, pixel ${PIXEL_ID})`));
