// Reintenta ahora mismo todos los leads de Meta con error (solo administradores).
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { retryPending } from "../lib/meta.js";

export default async (req) => {
  try {
    const user = await createClientFromRequest(req).auth.me();
    if (user.crm_role !== "admin_crm" && user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });
    const r = await retryPending({ includePermanent: true });
    return Response.json({ reprocessed: r.leads, events_retried: r.events });
  } catch (error) {
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
