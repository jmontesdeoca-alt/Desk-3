// Datos NO secretos que necesita el código embebible de los formularios web (el Pixel ID es público).
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { getMetaConfig } from "../lib/meta.js";

export default async (req) => {
  try {
    await createClientFromRequest(req).auth.me();
    const cfg = getMetaConfig();
    return Response.json({ pixel_id: cfg?.pixel_id || "", enabled: !!cfg?.pixel_id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
