// Envío manual / desde automatizaciones de un evento de conversión a Meta para un lead.
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { store } from "../../../runtime/crm-db.js";
import { sendLeadEvent } from "../lib/meta.js";

export default async (req) => {
  try {
    const user = await createClientFromRequest(req).auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const { lead_id, event_name, value } = await req.json();
    if (!lead_id) return Response.json({ error: "lead_id es requerido" }, { status: 400 });
    const lead = store.get("Lead", lead_id);
    if (!lead) return Response.json({ error: "Lead no encontrado" }, { status: 404 });
    const r = await sendLeadEvent(lead, event_name || "Purchase", { value, force: true });
    if (r.skipped) return Response.json({ success: false, skipped: true, reason: r.reason });
    if (!r.ok) return Response.json({ error: "Error enviando evento a Meta", details: r.error }, { status: 500 });
    return Response.json({ success: true, event_name: event_name || "Purchase", meta_response: r.response });
  } catch (error) {
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
