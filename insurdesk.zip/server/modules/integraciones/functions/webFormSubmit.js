// Portado de sdk/functions/webFormSubmit/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { sendWebFormEvent } from "../lib/meta.js";
import { events } from "../../kernel.js";
export default (async (req) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405, headers: corsHeaders });
  }
  try {
    const sdk = createClientFromRequest(req);
    const body = await req.json();
    const { form_token, data } = body;
    const meta = body.meta && typeof body.meta === "object" ? body.meta : {};
    if (!form_token || !data) {
      return Response.json({ error: "Missing form_token or data" }, { status: 400, headers: corsHeaders });
    }
    const forms = await sdk.asServiceRole.entities.WebForm.filter({ form_token, is_active: true });
    if (!forms || forms.length === 0) {
      return Response.json({ error: "Form not found or inactive" }, { status: 404, headers: corsHeaders });
    }
    const form = forms[0];
    const prospectData = {
      full_name: data.full_name || data.nombre || `${data.first_name || ""} ${data.last_name || ""}`.trim() || "Sin nombre",
      email: data.email || "",
      phone: data.phone || data.telefono || "",
      country: data.country || data.pais || "",
      city: data.city || data.ciudad || "",
      source: "web",
      source_channel: `webform:${form.name}`,
      source_form_id: form.id,
      custom_fields: data,
      ...(meta.fbp ? { meta_fbp: String(meta.fbp).slice(0, 200) } : {}),
      ...(meta.fbc ? { meta_fbc: String(meta.fbc).slice(0, 300) } : {}),
      assigned_agent_id: form.default_assigned_agent_id || "",
      assigned_agent_name: form.default_assigned_agent_name || ""
    };
    const prospect = await sdk.asServiceRole.entities.Prospect.create(prospectData);
    // Pixel (navegador) + API de conversiones (servidor) con el mismo event_id → Meta cuenta un solo Lead
    const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim();
    sendWebFormEvent({
      prospect, form,
      meta: { event_id: String(meta.event_id || "").slice(0, 100) || undefined, fbp: meta.fbp, fbc: meta.fbc, source_url: String(meta.source_url || "").slice(0, 500) },
      ip, userAgent: req.headers.get("user-agent") || "",
    }).catch((e) => console.error("[webFormSubmit] evento Meta:", e.message));
    await sdk.asServiceRole.entities.WebForm.update(form.id, {
      submissions_count: (form.submissions_count || 0) + 1
    });
    try {
      await events.emit("workflow.trigger", {
        trigger_event: "form_submitted",
        prospect_id: prospect.id,
        form_id: form.id
      });
      await events.emit("workflow.trigger", {
        trigger_event: "prospect_created",
        prospect_id: prospect.id
      });
    } catch (_) {
    }
    return Response.json(
      { success: true, message: form.success_message || "¡Gracias! Nos pondremos en contacto pronto." },
      { status: 200, headers: corsHeaders }
    );
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500, headers: corsHeaders });
  }
});
