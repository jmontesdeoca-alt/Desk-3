// Guarda la configuración de Meta, valida las credenciales y suscribe la página a los leads en un solo paso.
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { store } from "../../../runtime/crm-db.js";
import { ensureMetaConfig, buildStatus, diagnose, subscribePage, explain, retryPending, logEvent, META_EVENTS } from "../lib/meta.js";

const SECRETS = ["app_secret", "access_token", "capi_access_token"];
const STRINGS = ["app_id", "page_id", "pixel_id", "capi_test_event_code", "default_pipeline_id", "default_branch", "default_agent_id", "agent_mode", "default_country"];

export default async (req) => {
  try {
    const user = await createClientFromRequest(req).auth.me();
    if (user.crm_role !== "admin_crm" && user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });
    const body = await req.json();
    const cfg0 = ensureMetaConfig();
    const patch = {};

    for (const k of STRINGS) if (typeof body[k] === "string") patch[k] = body[k].trim();
    for (const k of SECRETS) if (typeof body[k] === "string" && body[k].trim()) patch[k] = body[k].trim(); // vacío = conservar el guardado
    if (body.clear_capi_token) patch.capi_access_token = "";
    for (const k of ["auto_send_events", "auto_create_lead", "is_active"]) if (typeof body[k] === "boolean") patch[k] = body[k];
    if (body.default_premium_estimated !== undefined) patch.default_premium_estimated = Number(body.default_premium_estimated) || 0;
    if (Array.isArray(body.round_robin_agent_ids)) patch.round_robin_agent_ids = body.round_robin_agent_ids.filter((x) => typeof x === "string");
    if (body.event_map && typeof body.event_map === "object") {
      const clean = {};
      for (const [k, v] of Object.entries(body.event_map)) clean[String(k)] = typeof v === "string" ? v.trim().slice(0, 40) : "";
      patch.event_map = clean;
    }
    if (patch.agent_mode && !["fixed", "round_robin"].includes(patch.agent_mode)) delete patch.agent_mode;
    if (patch.default_country) patch.default_country = patch.default_country.toUpperCase().slice(0, 2);

    if (patch.default_pipeline_id !== undefined) {
      const pl = patch.default_pipeline_id ? store.get("Pipeline", patch.default_pipeline_id) : null;
      patch.default_pipeline_name = pl?.name || "";
    }
    if (patch.default_agent_id !== undefined) {
      const ag = patch.default_agent_id ? store.get("User", patch.default_agent_id) : null;
      patch.default_agent_name = ag?.full_name || "";
    }
    // Cambiar de página invalida lo que se sabía de la anterior
    if (patch.page_id !== undefined && patch.page_id !== (cfg0.page_id || "")) patch.page_name = "";

    let cfg = store.update("MetaIntegrationConfig", cfg0.id, { ...patch, is_active: patch.is_active ?? true });

    // Credenciales nuevas: reintentar enseguida los leads/eventos que fallaron por token o permisos
    if (patch.access_token || patch.capi_access_token || patch.app_secret) {
      setImmediate(async () => {
        try {
          const r = await retryPending({ includePermanent: true });
          if (r.leads || r.events) logEvent({ kind: "system", status: "ok", title: "Recuperación automática", message: `Con las credenciales nuevas se reintentaron ${r.leads} lead(s) y ${r.events} evento(s)` });
        } catch (e) { console.error("[metaConnect] recuperación:", e.message); }
      });
    }

    const notes = [];
    if (body.verify !== false) {
      let checks = await diagnose(cfg);
      const page = checks.find((c) => c.id === "page");
      if (page?.status === "warn" && page.action?.id === "subscribe") {
        try {
          await subscribePage(cfg);
          notes.push("La página fue suscrita automáticamente al evento de leads.");
        } catch (e) {
          notes.push(`No se pudo suscribir la página: ${explain(e)}`);
        }
      }
      const final = await buildStatus(cfg);
      cfg = store.get("MetaIntegrationConfig", cfg.id);
      const pageOk = final.checks.find((c) => c.id === "page")?.status === "ok";
      store.update("MetaIntegrationConfig", cfg.id, {
        connection_status: final.status,
        last_validated_at: final.status === "ok" ? new Date().toISOString() : cfg.last_validated_at,
        webhook_subscribed: pageOk,
        error_message: final.checks.filter((c) => c.status === "error").map((c) => c.detail).join(" · "),
      }, { silent: true });
      return Response.json({ ...(await buildStatus(store.get("MetaIntegrationConfig", cfg.id))), notes, events: META_EVENTS });
    }
    return Response.json({ ...(await buildStatus(cfg)), notes });
  } catch (error) {
    console.error("metaConnect:", error);
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
