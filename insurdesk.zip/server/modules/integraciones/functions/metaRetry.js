// Tarea programada: reintenta leads y eventos de Meta que fallaron por causas temporales.
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { retryPending } from "../lib/meta.js";

export default async (req) => {
  try {
    const user = await createClientFromRequest(req).auth.me();
    if (user.crm_role !== "admin_crm" && user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });
    return Response.json({ success: true, ...(await retryPending()) });
  } catch (error) {
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
