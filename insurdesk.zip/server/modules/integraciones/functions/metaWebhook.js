// Webhook de Meta (Lead Ads). Reescrito: el token de verificación vive en la base de datos (se genera solo y se
// copia desde la pantalla), la firma es obligatoria y el procesamiento no bloquea la respuesta a Meta.
import crypto from "node:crypto";
import { store } from "../../../runtime/crm-db.js";
import { getMetaConfig, processLeadgen, logEvent } from "../lib/meta.js";

const safeEqual = (a, b) => {
  const x = Buffer.from(String(a ?? ""));
  const y = Buffer.from(String(b ?? ""));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

export default async (req) => {
  try {
    const url = new URL(req.url);
    const cfg = getMetaConfig();

    // ── Verificación (GET) que Meta hace al guardar la URL del webhook
    if (req.method === "GET") {
      const mode = url.searchParams.get("hub.mode");
      const token = url.searchParams.get("hub.verify_token") || "";
      const challenge = url.searchParams.get("hub.challenge") || "";
      const accepted = [cfg?.verify_token, process.env.META_VERIFY_TOKEN].filter(Boolean);
      if (mode === "subscribe" && accepted.some((t) => safeEqual(t, token))) {
        if (cfg) store.update("MetaIntegrationConfig", cfg.id, { webhook_verified_at: new Date().toISOString() });
        logEvent({ kind: "system", status: "ok", title: "Meta verificó el webhook", message: "La URL y el token de verificación son correctos" });
        return new Response(challenge, { status: 200, headers: { "Content-Type": "text/plain" } });
      }
      logEvent({ kind: "system", status: "error", title: "Verificación del webhook rechazada",
        message: accepted.length ? "El token de verificación que escribiste en Meta no coincide con el del CRM. Cópialo de nuevo desde esta pantalla." : "El CRM aún no tiene un token de verificación: abre la pantalla de Meta para generarlo." });
      return new Response("Token de verificación incorrecto", { status: 403 });
    }

    if (req.method !== "POST") return Response.json({ error: "Método no permitido" }, { status: 405 });

    // ── Aviso de lead (POST firmado)
    if (!cfg) return Response.json({ error: "Meta no está configurado" }, { status: 503 });
    const rawBody = await req.text();
    if (!cfg.app_secret) {
      logEvent({ kind: "system", status: "error", title: "Aviso de Meta no procesado", message: "Falta el App Secret en la configuración: sin él no se puede comprobar la firma del aviso" });
      return Response.json({ error: "App Secret no configurado" }, { status: 503 });
    }
    const signature = req.headers.get("x-hub-signature-256") || "";
    const expected = "sha256=" + crypto.createHmac("sha256", cfg.app_secret).update(rawBody).digest("hex");
    if (!safeEqual(signature, expected)) {
      logEvent({ kind: "webhook", status: "error", title: "Aviso rechazado: firma inválida",
        message: signature ? "La firma no coincide. Revisa que el App Secret guardado sea el de esta app de Meta." : "El aviso llegó sin firma" });
      return Response.json({ error: "Firma inválida" }, { status: 403 });
    }

    let body;
    try { body = JSON.parse(rawBody); } catch { return Response.json({ error: "JSON inválido" }, { status: 400 }); }

    const leadgens = [];
    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        if (change.field === "leadgen" && change.value?.leadgen_id) leadgens.push({ page_id: entry.id, ...change.value });
      }
    }
    store.update("MetaIntegrationConfig", cfg.id, { last_webhook_at: new Date().toISOString() }, { silent: true });
    logEvent({ kind: "webhook", status: "ok", title: "Aviso recibido de Meta",
      message: leadgens.length ? `${leadgens.length} lead(s): ${leadgens.map((l) => l.leadgen_id).join(", ")}` : `Evento sin leads (${(body.entry || []).flatMap((e) => (e.changes || []).map((c) => c.field)).join(", ") || body.object})` });

    // Responder ya a Meta (exige respuesta rápida) y procesar en segundo plano; lo que falle se reintenta solo
    setImmediate(async () => {
      for (const lg of leadgens) {
        try { await processLeadgen(lg, { cfg }); } catch (e) { console.error("[metaWebhook] error inesperado:", e); }
      }
    });
    return Response.json({ success: true, received: leadgens.length });
  } catch (error) {
    console.error("Error en webhook de Meta:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
};
