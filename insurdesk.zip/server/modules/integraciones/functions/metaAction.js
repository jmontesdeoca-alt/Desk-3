// Acciones puntuales de la integración con Meta (solo administradores)
import crypto from "node:crypto";
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { store } from "../../../runtime/crm-db.js";
import { ensureMetaConfig, simulateLead, sendTestEvent, subscribePage, processLeadgen, retryPending, buildStatus, explain } from "../lib/meta.js";

export default async (req) => {
  try {
    const user = await createClientFromRequest(req).auth.me();
    if (user.crm_role !== "admin_crm" && user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });
    const body = await req.json();
    const cfg = ensureMetaConfig();

    switch (body.action) {
      case "subscribe": {
        if (!cfg.page_id) return Response.json({ error: "Primero indica el ID de la página" }, { status: 400 });
        try { await subscribePage(cfg); } catch (e) { return Response.json({ error: explain(e) }, { status: 400 }); }
        return Response.json({ success: true, ...(await buildStatus(cfg)) });
      }
      case "simulate_lead": {
        const result = await simulateLead(cfg, body);
        return Response.json({ success: result.status !== "error", result });
      }
      case "test_event": {
        try {
          const r = await sendTestEvent(cfg);
          return Response.json({ success: r.ok, error: r.error, test_mode: !!cfg.capi_test_event_code });
        } catch (e) { return Response.json({ error: e.message }, { status: 400 }); }
      }
      case "retry_lead": {
        const ml = store.get("MetaLead", body.meta_lead_id);
        if (!ml) return Response.json({ error: "Lead de Meta no encontrado" }, { status: 404 });
        const result = await processLeadgen({ leadgen_id: ml.leadgen_id, form_id: ml.form_id, page_id: ml.page_id, ad_id: ml.ad_id, adgroup_id: ml.adset_id, created_time: ml.created_time },
          { cfg, force: true, simulated: !!ml.is_test, leadData: ml.is_test ? ml.raw_data : null });
        return Response.json({ success: result.status !== "error", result });
      }
      case "retry_all":
        return Response.json({ success: true, ...(await retryPending({ includePermanent: true })) });
      case "regenerate_token": {
        store.update("MetaIntegrationConfig", cfg.id, { verify_token: crypto.randomBytes(24).toString("hex"), webhook_verified_at: null });
        return Response.json({ success: true, ...(await buildStatus(store.get("MetaIntegrationConfig", cfg.id))) });
      }
      default:
        return Response.json({ error: "Acción desconocida" }, { status: 400 });
    }
  } catch (error) {
    console.error("metaAction:", error);
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
