// Estado de la integración con Meta (solo administradores): checklist de diagnóstico + estadísticas.
import { createClientFromRequest } from "../../../runtime/sdk.js";
import { ensureMetaConfig, buildStatus } from "../lib/meta.js";

export default async (req) => {
  try {
    const user = await createClientFromRequest(req).auth.me();
    if (user.crm_role !== "admin_crm" && user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });
    const light = new URL(req.url).searchParams.get("light") === "1" || (await req.clone().json().catch(() => ({}))).light === true;
    return Response.json(await buildStatus(ensureMetaConfig(), { light }));
  } catch (error) {
    return Response.json({ error: error.message }, { status: error.status || 500 });
  }
};
