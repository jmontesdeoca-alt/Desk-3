// Portado de sdk/functions/whatsappWebhook/entry.ts
import { createClientFromRequest } from "../../../runtime/sdk.js";
export default (async (req) => {
  const sdk = createClientFromRequest(req);
  const url = new URL(req.url);
  if (req.method === "GET") {
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge");
    const configs = await sdk.asServiceRole.entities.WhatsAppConfig.list();
    const verifyToken = configs[0]?.verify_token;
    if (mode === "subscribe" && verifyToken && token === verifyToken) {
      return new Response(challenge, { status: 200 });
    }
    return new Response("Forbidden", { status: 403 });
  }
  if (req.method === "POST") {
    try {
      const body = await req.json();
      const entry = body?.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      if (!value?.messages) {
        return Response.json({ ok: true });
      }
      const message = value.messages[0];
      const contact = value.contacts?.[0];
      const phoneNumber = message.from;
      const senderName = contact?.profile?.name || phoneNumber;
      const messageText = message.text?.body || "[Mensaje multimedia]";
      const allProspects = await sdk.asServiceRole.entities.Prospect.list();
      const normalizedIncoming = phoneNumber.replace(/\D/g, "");
      const prospect = allProspects.find((p) => {
        const ph = (p.phone || p.phone_raw || "").replace(/\D/g, "");
        return ph && (ph.endsWith(normalizedIncoming) || normalizedIncoming.endsWith(ph));
      });
      let leadInfo = "";
      let notifyUserIds = [];
      if (prospect) {
        const leads = await sdk.asServiceRole.entities.Lead.filter({
          prospect_id: prospect.id,
          lead_status: "ACTIVO"
        });
        if (leads.length > 0) {
          const lead = leads[0];
          leadInfo = ` — Lead ${lead.external_id || lead.id}`;
          await sdk.asServiceRole.entities.LeadActivity.create({
            lead_id: lead.id,
            lead_external_id: lead.external_id || "",
            activity_type: "whatsapp",
            description: `WhatsApp recibido de ${senderName}: "${messageText}"`,
            created_by_name: senderName
          });
          await sdk.asServiceRole.entities.Lead.update(lead.id, {
            last_activity_at: (/* @__PURE__ */ new Date()).toISOString()
          });
          if (lead.assigned_agent_id) {
            const users = await sdk.asServiceRole.entities.User.filter({ id: lead.assigned_agent_id });
            if (users.length > 0) notifyUserIds = [{ id: users[0].id, email: users[0].email }];
          }
        }
      }
      if (notifyUserIds.length === 0) {
        const allUsers = await sdk.asServiceRole.entities.User.list();
        notifyUserIds = allUsers.filter((u) => u.crm_role === "admin_crm" || u.role === "admin").map((u) => ({ id: u.id, email: u.email }));
      }
      await Promise.all(notifyUserIds.map(
        (u) => sdk.asServiceRole.entities.Notification.create({
          user_id: u.id,
          user_email: u.email,
          type: "whatsapp_message",
          title: `💬 Nuevo WhatsApp de ${senderName}`,
          message: `"${messageText.slice(0, 100)}${messageText.length > 100 ? "…" : ""}"${leadInfo}`,
          lead_id: prospect ? void 0 : void 0,
          read: false
        })
      ));
      return Response.json({ ok: true });
    } catch (error) {
      console.error("WhatsApp webhook error:", error);
      return Response.json({ error: error.message }, { status: 500 });
    }
  }
  return new Response("Method not allowed", { status: 405 });
});
