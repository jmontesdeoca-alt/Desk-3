/**
 * Loads all records from an entity accessor using cursor-based pagination.
 * Sorts ascending by sortField and uses $gt cursor to get subsequent batches.
 * Overcomes the 5000-record SDK limit by fetching in pages of 5000.
 */
export async function loadAll(entityAccessor, sortField, extraFilter = {}) {
  const all = [];
  let cursor = null;
  let iterations = 0;
  const MAX_ITERATIONS = 200; // safety limit — 200 * 5000 = 1,000,000 records max

  while (iterations < MAX_ITERATIONS) {
    const query = { ...extraFilter };
    if (cursor) query[sortField] = { $gt: cursor };
    const batch = await entityAccessor.filter(query, sortField, 5000);
    all.push(...batch);
    if (batch.length < 5000) break;
    cursor = batch[batch.length - 1][sortField];
    iterations++;
  }
  return all;
}