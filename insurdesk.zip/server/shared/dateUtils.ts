/**
 * Utilidades de fecha para backend functions (Deno runtime).
 *
 * PROBLEMA: new Date("2026-03-01") interpreta como UTC midnight.
 * En zonas negativas (UTC-5), esto se vuelve "2026-02-28".
 *
 * SOLUCIÓN: parseLocalDate parsea date-only strings como medianoche local.
 */

/**
 * Parsea un string de fecha-only (YYYY-MM-DD) como medianoche LOCAL.
 * Si tiene componente de hora (ISO), lo parsea normalmente.
 */
export function parseLocalDate(str: string | Date | null | undefined): Date | null {
  if (!str) return null;
  if (str instanceof Date) return isNaN(str.getTime()) ? null : str;
  if (typeof str !== 'string') return null;

  // Date-only: YYYY-MM-DD → parse as local midnight
  if (/^\d{4}-\d{2}-\d{2}$/.test(str.trim())) {
    const [y, m, d] = str.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    return isNaN(date.getTime()) ? null : date;
  }

  // ISO datetime: parse normally
  const date = new Date(str);
  return isNaN(date.getTime()) ? null : date;
}

/**
 * Obtiene la fecha actual (YYYY-MM-DD) en una zona horaria específica.
 * Por defecto usa UTC para funciones scheduled que no tienen contexto de usuario.
 */
export function todayInTimezone(timezone: string = 'UTC'): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(new Date());

  const y = parts.find(p => p.type === 'year')?.value;
  const m = parts.find(p => p.type === 'month')?.value;
  const d = parts.find(p => p.type === 'day')?.value;

  return `${y}-${m}-${d}`;
}

/**
 * Formatea una fecha (date-only o datetime) para display en una zona horaria.
 */
export function formatDateInTimezone(
  date: string | Date | null | undefined,
  timezone: string = 'UTC',
  options: Intl.DateTimeFormatOptions = { day: '2-digit', month: 'long', year: 'numeric' }
): string {
  if (!date) return '';
  const d = parseLocalDate(date);
  if (!d) return '';
  return new Intl.DateTimeFormat('es-ES', { ...options, timeZone: timezone }).format(d);
}

/**
 * Calcula días de diferencia entre dos fechas, parseando date-only strings correctamente.
 */
export function differenceInDaysSafe(endDateStr: string, startDateStr: string): number {
  const end = parseLocalDate(endDateStr);
  const start = parseLocalDate(startDateStr);
  if (!end || !start) return 0;
  const diffMs = end.getTime() - start.getTime();
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}