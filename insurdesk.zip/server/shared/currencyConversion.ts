/**
 * Utilidades de conversión de moneda COP → USD usando TRM cacheada en la entidad ExchangeRate.
 * Compartido entre backend functions (getDashboardData, getDashboardPaymentKPIs, reportes).
 */

/**
 * Obtiene la TRM (COP por 1 USD) para una fecha dada.
 * 1. Busca en caché (entidad ExchangeRate) por fecha exacta.
 * 2. Si no existe, consulta dolar-colombia.com/{fecha}, extrae el valor y lo guarda.
 * 3. Si el fetch falla o no hay TRM para esa fecha (fin de semana/festivo), usa TRM de hoy.
 * 4. Si hoy tampoco disponible, usa la última TRM conocida.
 *
 * @param sdk - cliente sdk (asServiceRole)
 * @param dateStr - fecha en formato YYYY-MM-DD
 * @returns { rate: number, source: string, date: string }
 */
export async function getTRMForDate(sdk, dateStr) {
  if (!dateStr) {
    // Sin fecha → usar TRM actual
    return getTRMForDate(sdk, todayStr());
  }

  // 1. Caché exacta
  const cached = await sdk.entities.ExchangeRate.filter({ date: dateStr });
  if (cached && cached.length > 0 && cached[0].rate) {
    return { rate: cached[0].rate, source: cached[0].source || 'cache', date: dateStr };
  }

  // 2. Fetch a dolar-colombia.com
  const fetched = await fetchTRMFromWeb(dateStr);
  if (fetched) {
    try {
      await sdk.entities.ExchangeRate.create({
        date: dateStr,
        currency: 'COP',
        rate: fetched,
        source: 'dolar-colombia.com'
      });
    } catch (e) {
      // Puede fallar si ya existe por concurrencia; ignorar
    }
    return { rate: fetched, source: 'dolar-colombia.com', date: dateStr };
  }

  // 3. Fallback: TRM de hoy
  if (dateStr !== todayStr()) {
    const todayRate = await getTRMForDate(sdk, todayStr());
    return { ...todayRate, source: todayRate.source + ' (fallback)' };
  }

  // 4. Última TRM conocida
  const allRates = await sdk.entities.ExchangeRate.list('-date', 1);
  if (allRates && allRates.length > 0 && allRates[0].rate) {
    return { rate: allRates[0].rate, source: 'last-known', date: allRates[0].date };
  }

  // 5. Último recurso: tasa de emergencia hardcodeada (raro que llegue aquí)
  return { rate: 4000, source: 'emergency-fallback', date: dateStr };
}

/**
 * Obtiene las TRMs necesarias para un conjunto de fechas, en batch.
 * Retorna un Map<dateStr, rate> para acceso O(1).
 */
export async function getTRMBatch(sdk, dateStrs) {
  const uniqueDates = [...new Set(dateStrs.filter(Boolean))];
  const result = new Map();

  if (uniqueDates.length === 0) return result;

  // Una sola consulta a ExchangeRate para todas las fechas cacheadas
  const allRates = await sdk.entities.ExchangeRate.list('-date', 5000);
  const cacheMap = new Map();
  for (const r of allRates || []) {
    if (r.date && r.rate) cacheMap.set(r.date, r.rate);
  }

  const missingDates = [];
  for (const date of uniqueDates) {
    if (cacheMap.has(date)) {
      result.set(date, cacheMap.get(date));
    } else {
      missingDates.push(date);
    }
  }

  // Para las fechas faltantes, hacer fetch individual (con fallback interno a TRM de hoy)
  if (missingDates.length > 0) {
    const fetchPromises = missingDates.map(d =>
      getTRMForDate(sdk, d).then(trm => ({ date: d, rate: trm.rate }))
    );
    const fetchedResults = await Promise.all(fetchPromises);
    for (const { date, rate } of fetchedResults) {
      result.set(date, rate);
    }
  }

  return result;
}

/**
 * Convierte un monto a USD dado su currency y fecha de emisión.
 * @param amount - monto original
 * @param currency - moneda del monto (USD, COP, etc.)
 * @param issueDate - fecha de emisión (YYYY-MM-DD) para buscar TRM
 * @param trmMap - Map<dateStr, rate> pre-cargado (de getTRMBatch)
 * @returns monto en USD
 */
export function convertToUSD(amount, currency, issueDate, trmMap) {
  if (!amount || amount === 0) return 0;
  if (!currency || currency === 'USD') return amount;

  // Para COP usamos el trmMap; si no está, fallback a TRM de hoy
  if (currency === 'COP') {
    const rate = trmMap?.get(issueDate) || trmMap?.get(todayStr());
    if (!rate || rate === 0) return amount; // sin TRM, devolver original (no debería pasar)
    return amount / rate;
  }

  // Otras monedas futuras: por ahora devolver tal cual (no hay TRM configurada)
  return amount;
}

/**
 * Obtiene la TRM actual (fecha de hoy) consultando la API.
 */
export async function getCurrentTRM(sdk) {
  return getTRMForDate(sdk, todayStr());
}

// ---- Helpers internos ----

function todayStr() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

async function fetchTRMFromWeb(dateStr) {
  try {
    const url = `https://trm-colombia.vercel.app/?date=${dateStr}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const json = await res.json();

    const rate = json?.data?.value;
    if (typeof rate !== 'number' || rate <= 0) return null;

    return rate;
  } catch (e) {
    console.error('Error fetching TRM:', e);
    return null;
  }
}