import { brand } from '../runtime/brand.js';
import { Secret, TOTP } from 'otpauth';

export function generateTOTPConfig(email) {
  const secret = new Secret({ size: 20 });
  const totp = new TOTP({
    issuer: brand.name,
    label: email,
    algorithm: "SHA1",
    digits: 6,
    period: 30,
    secret: secret
  });
  return {
    base32Secret: secret.base32,
    otpauthUrl: totp.toString()
  };
}

export function validateTOTPCode(base32Secret, token) {
  try {
    const totp = new TOTP({
      issuer: brand.name,
      algorithm: "SHA1",
      digits: 6,
      period: 30,
      secret: Secret.fromBase32(base32Secret)
    });
    const delta = totp.validate({ token, window: 1 });
    return delta !== null;
  } catch {
    return false;
  }
}

export function generateEmailCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function findUserRoleByEmail(sdk, email) {
  const allRoles = await sdk.asServiceRole.entities.UserRole.list();
  return allRoles.find(ur => {
    const roleEmail = ur.data?.email || ur.email;
    return roleEmail?.toLowerCase() === email?.toLowerCase();
  });
}

export function extractRoleData(userRole) {
  return userRole.data || userRole;
}