import { secrets } from '../runtime/platform.js';

// ── Configuración: cambiar aquí el origen permitido para CORS ──
export const ALLOWED_ORIGIN = process.env.XR_ALLOWED_ORIGIN || '';

export const CORS_HEADERS = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
};

export function unauthorizedResponse() {
  return Response.json(
    { error: 'Unauthorized: token inválido o ausente' },
    { status: 401, headers: CORS_HEADERS }
  );
}

export function checkAuth(req) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return false;
  const token = auth.slice(7).trim();
  const expected = secrets.get('XR_READ_TOKEN');
  if (!expected) return false;
  return token === expected;
}

// Devuelve un Response si hay que cortar (OPTIONS o método no permitido), o null si continúa
export function handleOptionsAndMethod(req) {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== 'GET') {
    return Response.json(
      { error: 'Method not allowed' },
      { status: 405, headers: CORS_HEADERS }
    );
  }
  return null;
}

// Convierte un Date a string local "YYYY-MM-DD" (sin desfase UTC)
export function dateStr(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}