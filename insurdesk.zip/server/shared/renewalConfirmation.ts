// Shared logic for confirming a renewal — used by both confirmRenewal and confirmRenewalBatch.
// Moves the entire confirmation process server-side to avoid ~18 frontend HTTP round trips.

export async function confirmSingleRenewal(sdk, renewalId, refData) {
  // refData: { agents, assignments, commissionTables } — pre-loaded once for batch calls
  // If refData is null, load it here (single confirmation case)
  const agents = refData?.agents ?? await sdk.asServiceRole.entities.Agent.list();
  const assignments = refData?.assignments ?? await sdk.asServiceRole.entities.AgentCommissionAssignment.list();
  const commissionTables = refData?.commissionTables ?? await sdk.asServiceRole.entities.CommissionTable.list();

  // 1. Get the renewal record
  const renewal = await sdk.asServiceRole.entities.Renewal.get(renewalId);
  if (!renewal) throw new Error('Renovación no encontrada');
  if (renewal.status !== 'propuesta') throw new Error('La renovación ya no está en estado propuesta');

  // 2. Validate (inline, excluding self)
  const allExistingRenewals = await sdk.asServiceRole.entities.Renewal.filter({
    original_policy_id: renewal.original_policy_id,
    status: { $in: ['propuesta', 'confirmada'] }
  });
  const otherRenewals = allExistingRenewals.filter(r => r.id !== renewalId);
  const renewedPolicies = await sdk.asServiceRole.entities.Policy.filter({
    renewed_from_policy_id: renewal.original_policy_id,
    status: { $in: ['activa', 'vencida', 'en_riesgo'] }
  });

  if (otherRenewals.length > 0) {
    throw new Error('Esta póliza ya tiene otra renovación activa para este período.');
  }
  if (renewedPolicies.length > 0) {
    throw new Error('Esta póliza ya fue renovada y tiene una póliza nueva activa asociada.');
  }

  // 3. Get original policy
  const policy = await sdk.asServiceRole.entities.Policy.get(renewal.original_policy_id);
  if (!policy) throw new Error('Póliza original no encontrada');

  // 4. Calculate installment amount
  const frequency = renewal.payment_frequency || policy.payment_frequency;
  const frequencyMap = { mensual: 12, trimestral: 4, semestral: 2, anual: 1, unico: 1 };
  const installments = frequencyMap[frequency] || 12;
  const installmentAmount = renewal.new_premium / installments;

  // 5. Create new policy
  const newPolicyNumber = `${policy.policy_number}-R${new Date().getFullYear()}`;
  const { id: _omitId, ...policyFields } = policy;
  const newPolicy = await sdk.asServiceRole.entities.Policy.create({
    ...policyFields,
    policy_number: newPolicyNumber,
    annual_premium: renewal.new_premium,
    commissionable_premium: renewal.new_commissionable_premium || renewal.new_premium,
    payment_frequency: frequency,
    installment_amount: installmentAmount,
    start_date: renewal.new_start_date,
    end_date: renewal.new_end_date,
    status: 'activa',
    policy_type: 'renovacion',
    renewed_from_policy_id: policy.id,
    notes: `Renovación de póliza ${policy.policy_number}`,
    ...(renewal.deductible_1 != null && { deductible_1: renewal.deductible_1 }),
    ...(renewal.deductible_2 != null && { deductible_2: renewal.deductible_2 }),
  });

  // 6. CRITICAL: Update renewal status + original policy status IMMEDIATELY after new policy creation.
  // This ensures the core state change is committed before any non-critical side effects (payments, commissions).
  // If payments/commissions fail later, the renewal is still correctly marked as confirmed.
  await Promise.all([
    sdk.asServiceRole.entities.Renewal.update(renewalId, {
      status: 'confirmada',
      new_policy_id: newPolicy.id,
      confirmed_date: new Date().toISOString()
    }),
    sdk.asServiceRole.entities.Policy.update(policy.id, { status: 'renovada' })
  ]);

  // 7. Generate payment schedule in bulk (non-critical — failure here doesn't undo the renewal)
  try {
    const startDate = new Date(renewal.new_start_date);
    const payments = [];
    for (let i = 0; i < installments; i++) {
      const dueDate = new Date(startDate);
      if (frequency === 'mensual') dueDate.setMonth(dueDate.getMonth() + i);
      else if (frequency === 'trimestral') dueDate.setMonth(dueDate.getMonth() + (i * 3));
      else if (frequency === 'semestral') dueDate.setMonth(dueDate.getMonth() + (i * 6));

      payments.push({
        policy_id: newPolicy.id,
        policy_number: newPolicyNumber,
        client_name: policy.client_name,
        due_date: dueDate.toISOString().split('T')[0],
        period: `${dueDate.toLocaleString('es', { month: 'long', year: 'numeric' })}`,
        amount: installmentAmount,
        currency: policy.currency,
        status: 'pendiente',
        installment_number: i + 1
      });
    }
    await sdk.asServiceRole.entities.Payment.bulkCreate(payments);
  } catch (payErr) {
    console.error('Error generating payments for renewal', renewalId, payErr.message);
  }

  // 8. Generate renewal commissions (non-critical)
  try {
    const commissions = [];
    const generatedFor = new Set();

    const walkUpHierarchy = (agentId, level) => {
      if (!agentId || generatedFor.has(agentId)) return;

      const agent = agents.find(a => a.id === agentId);
      if (!agent) return;

      const assignment = assignments.find(a =>
        a.agent_id === agentId &&
        a.company_id === policy.company_id &&
        a.line_id === policy.line_id
      );

      if (assignment) {
        const table = commissionTables.find(t => t.id === assignment.commission_table_id);
        if (table) {
          const productComm = table.product_commissions.find(pc => pc.product_id === policy.product_id);
          if (productComm && productComm.renewal_percentage) {
            const baseAmount = renewal.new_commissionable_premium || renewal.new_premium;

            let commissionPct = productComm.renewal_percentage;
            const downlineAssignment = assignments.find(a =>
              agents.find(ag => ag.id === a.agent_id && ag.upline_agent_id === agentId) &&
              a.company_id === policy.company_id &&
              a.line_id === policy.line_id
            );

            if (downlineAssignment) {
              const downlineTable = commissionTables.find(t => t.id === downlineAssignment.commission_table_id);
              if (downlineTable) {
                const downlineProductComm = downlineTable.product_commissions.find(pc => pc.product_id === policy.product_id);
                if (downlineProductComm) {
                  commissionPct = Math.max(0, commissionPct - downlineProductComm.renewal_percentage);
                }
              }
            }

            if (commissionPct > 0) {
              commissions.push({
                policy_id: newPolicy.id,
                policy_number: newPolicyNumber,
                product_id: policy.product_id,
                product_name: policy.product_name,
                company_id: policy.company_id,
                company_name: policy.company_name,
                agent_id: agentId,
                agent_name: agent.name,
                client_name: policy.client_name,
                level: level,
                base_amount: baseAmount,
                commission_pct: commissionPct,
                commission_amount: baseAmount * (commissionPct / 100),
                currency: policy.currency,
                generation_date: new Date().toISOString().split('T')[0],
                status: 'pendiente_liberar',
                source_type: 'renovacion'
              });
              generatedFor.add(agentId);
            }
          }
        }
      }

      if (agent.upline_agent_id) {
        walkUpHierarchy(agent.upline_agent_id, level + 1);
      }
    };

    walkUpHierarchy(policy.agent_id, 1);

    if (commissions.length > 0) {
      await sdk.asServiceRole.entities.Commission.bulkCreate(commissions);
    }
  } catch (commErr) {
    console.error('Error generating commissions for renewal', renewalId, commErr.message);
  }

  return {
    success: true,
    renewal_id: renewalId,
    new_policy_id: newPolicy.id,
    new_policy_number: newPolicyNumber,
    original_policy_id: policy.id
  };
}